	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_file_flow_declarations ; -- Begin function nvm_file_flow_declarations
	.globl	_nvm_file_flow_declarations
	.p2align	2
_nvm_file_flow_declarations:            ; @nvm_file_flow_declarations
	.cfi_startproc
; %bb.0:
	mov	w2, #0                          ; =0x0
	b	_file_flow_declarations_mode
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_flow_declarations_mode
_file_flow_declarations_mode:           ; @file_flow_declarations_mode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w28, #1                         ; =0x1
	cbz	x0, LBB1_25
; %bb.1:
	cbz	x1, LBB1_25
; %bb.2:
	mov	x21, x0
	ldr	w8, [x0, #272]
	cbz	w8, LBB1_24
; %bb.3:
	ldr	x9, [x21, #256]
	cbz	x9, LBB1_24
; %bb.4:
	cmp	w8, #64
	b.ls	LBB1_6
LBB1_5:
	mov	w28, #3                         ; =0x3
	b	LBB1_25
LBB1_6:
	ldr	w10, [x21, #424]
	cbnz	w10, LBB1_8
; %bb.7:
	ldr	w10, [x21, #448]
	cbz	w10, LBB1_9
LBB1_8:
	mov	w28, #2                         ; =0x2
	b	LBB1_25
LBB1_9:
	mov	x22, #0                         ; =0x0
	add	x9, x9, #16
LBB1_10:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w11, [x9, #-12]
	ldrh	w10, [x9]
	cmp	w11, w10
	b.hi	LBB1_24
; %bb.11:                               ;   in Loop: Header=BB1_10 Depth=1
	ldrb	w11, [x9, #5]
	cmp	w11, #1
	b.hi	LBB1_24
; %bb.12:                               ;   in Loop: Header=BB1_10 Depth=1
	ldrh	w11, [x9, #2]
	cbnz	w11, LBB1_8
; %bb.13:                               ;   in Loop: Header=BB1_10 Depth=1
	cmp	w10, #256
	b.hi	LBB1_5
; %bb.14:                               ;   in Loop: Header=BB1_10 Depth=1
	cmn	x10, x22
	b.hs	LBB1_5
; %bb.15:                               ;   in Loop: Header=BB1_10 Depth=1
	add	x22, x22, x10
	add	x9, x9, #24
	subs	x8, x8, #1
	b.ne	LBB1_10
; %bb.16:
	mov	x8, #-114                       ; =0xffffffffffffff8e
	movk	x8, #4095, lsl #48
	cmp	x22, x8
	b.hi	LBB1_5
; %bb.17:
	mov	x20, x2
	mov	x24, x1
	add	x1, sp, #88
	mov	w0, #65536                      ; =0x10000
	bl	_nvm_file_nominal_storage_bound
	mov	w28, #3                         ; =0x3
	cbz	w0, LBB1_25
; %bb.18:
	mov	w8, #65422                      ; =0xff8e
	movk	w8, #15, lsl #16
	cmp	x22, x8
	b.hi	LBB1_25
; %bb.19:
	lsl	x19, x22, #4
	ldr	x8, [sp, #88]
	mov	w9, #63720                      ; =0xf8e8
	movk	w9, #255, lsl #16
	sub	x9, x9, x19
	cmp	x8, x9
	b.hi	LBB1_5
; %bb.20:
	str	xzr, [sp, #80]
	add	x1, sp, #80
	mov	x0, x21
	bl	_nvm_file_nominal_plan
	cbz	w0, LBB1_26
; %bb.21:
	cmp	w0, #2
	b.eq	LBB1_5
; %bb.22:
	cmp	w0, #3
	b.ne	LBB1_24
; %bb.23:
	mov	w28, #4                         ; =0x4
	b	LBB1_25
LBB1_24:
	mov	w28, #1                         ; =0x1
LBB1_25:
	mov	x0, x28
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB1_26:
	add	x1, x19, #1816
	mov	w0, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB1_35
; %bb.27:
	mov	x19, x0
	ldr	w23, [x21, #272]
	mov	w9, #1                          ; =0x1
	stp	w9, w23, [x0]
	ldr	x10, [sp, #80]
	stp	x9, x10, [x0, #8]
	mov	w28, #1                         ; =0x1
	ldr	x1, [x21, #296]
	ldr	w2, [x21, #304]
	add	x0, sp, #56
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_34
; %bb.28:
	ldr	w8, [sp, #52]
	cmp	w8, #1
	b.ne	LBB1_34
; %bb.29:
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_33
; %bb.30:
	ldr	w25, [sp, #48]
	ldr	x0, [sp, #80]
	bl	_nvm_file_nominal_layout_count
	cmp	w25, w0
	b.ne	LBB1_33
; %bb.31:
	ldr	w1, [sp, #48]
	add	x0, sp, #56
	add	x2, sp, #32
	bl	_nvm_v2_take
	cbnz	w0, LBB1_33
; %bb.32:
	add	x0, sp, #56
	bl	_nvm_v2_align4
	cbz	w0, LBB1_36
LBB1_33:
	mov	w28, #1                         ; =0x1
LBB1_34:
	mov	x0, x19
	bl	_nvm_file_flow_declarations_free
	b	LBB1_25
LBB1_35:
	ldr	x0, [sp, #80]
	bl	_nvm_file_nominal_plan_free
	mov	w28, #4                         ; =0x4
	b	LBB1_25
LBB1_36:
	add	x0, sp, #56
	add	x1, sp, #44
	bl	_nvm_v2_u32
	mov	w28, #1                         ; =0x1
	cbnz	w0, LBB1_34
; %bb.37:
	ldr	w8, [sp, #44]
	cmp	w8, w23
	b.ne	LBB1_34
; %bb.38:
	cbz	w23, LBB1_57
; %bb.39:
	mov	x27, #0                         ; =0x0
	add	x8, x19, #24
	stp	x8, xzr, [sp, #16]              ; 16-byte Folded Spill
	add	x9, x19, #1560
	add	x8, x19, #1816
	stp	x8, x9, [sp]                    ; 16-byte Folded Spill
LBB1_40:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_52 Depth 2
	add	x8, x27, x27, lsl #1
	lsl	x23, x8, #3
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x25, x8, x23
	ldr	x26, [x21, #256]
	add	x0, sp, #56
	add	x1, x25, #2
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_33
; %bb.41:                               ;   in Loop: Header=BB1_40 Depth=1
	add	x0, sp, #56
	mov	x1, x25
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_33
; %bb.42:                               ;   in Loop: Header=BB1_40 Depth=1
	add	x23, x26, x23
	ldurh	w8, [x25, #2]
	ldrh	w9, [x23, #16]
	cmp	w8, w9
	b.ne	LBB1_33
; %bb.43:                               ;   in Loop: Header=BB1_40 Depth=1
	ldrh	w8, [x25]
	ldrh	w9, [x23, #4]
	cmp	w8, w9
	b.ne	LBB1_33
; %bb.44:                               ;   in Loop: Header=BB1_40 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	w8, [x9, x27, lsl #2]
	ldrb	w8, [x23, #21]
	strb	w8, [x25, #4]
	ldr	x1, [sp, #80]
	add	x0, sp, #56
	add	x2, x25, #8
	mov	x3, x20
	bl	_read_declaration
                                        ; kill: def $w0 killed $w0 def $x0
	cbnz	w0, LBB1_61
; %bb.45:                               ;   in Loop: Header=BB1_40 Depth=1
	ldrb	w8, [x25, #9]
	cbnz	w8, LBB1_33
; %bb.46:                               ;   in Loop: Header=BB1_40 Depth=1
	ldrb	w8, [x25, #4]
	cbz	w8, LBB1_48
; %bb.47:                               ;   in Loop: Header=BB1_40 Depth=1
	ldrb	w8, [x23, #20]
LBB1_48:                                ;   in Loop: Header=BB1_40 Depth=1
	ldrb	w9, [x25, #8]
	cmp	w8, w9
	b.ne	LBB1_33
; %bb.49:                               ;   in Loop: Header=BB1_40 Depth=1
	ldurh	w8, [x25, #2]
	cbz	w8, LBB1_55
; %bb.50:                               ;   in Loop: Header=BB1_40 Depth=1
	mov	x26, #0                         ; =0x0
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	add	x23, x9, x8, lsl #4
	b	LBB1_52
LBB1_51:                                ;   in Loop: Header=BB1_52 Depth=2
	add	x26, x26, #1
	ldurh	w8, [x25, #2]
	add	x23, x23, #16
	cmp	x26, x8
	b.hs	LBB1_56
LBB1_52:                                ;   Parent Loop BB1_40 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x1, [sp, #80]
	add	x0, sp, #56
	mov	x2, x23
	mov	x3, x20
	bl	_read_declaration
                                        ; kill: def $w0 killed $w0 def $x0
	cbnz	w0, LBB1_61
; %bb.53:                               ;   in Loop: Header=BB1_52 Depth=2
	ldrh	w8, [x25]
	cmp	x26, x8
	b.lo	LBB1_51
; %bb.54:                               ;   in Loop: Header=BB1_52 Depth=2
	ldrb	w8, [x23, #1]
	cbz	w8, LBB1_51
	b	LBB1_33
LBB1_55:                                ;   in Loop: Header=BB1_40 Depth=1
	mov	x8, #0                          ; =0x0
LBB1_56:                                ;   in Loop: Header=BB1_40 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	add	x9, x9, x8
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	add	x27, x27, #1
	ldr	w8, [x19, #4]
	cmp	x27, x8
	b.lo	LBB1_40
	b	LBB1_58
LBB1_57:
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
LBB1_58:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	cmp	x8, x22
	b.ne	LBB1_33
; %bb.59:
	ldp	x9, x8, [sp, #64]
	cmp	x8, x9
	b.ne	LBB1_33
; %bb.60:
	mov	w28, #0                         ; =0x0
	str	x19, [x24]
	b	LBB1_25
LBB1_61:
	mov	x28, x0
	b	LBB1_34
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_declarations_free ; -- Begin function nvm_file_flow_declarations_free
	.globl	_nvm_file_flow_declarations_free
	.p2align	2
_nvm_file_flow_declarations_free:       ; @nvm_file_flow_declarations_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_2
; %bb.1:
	ldr	w8, [x0]
	subs	w8, w8, #1
	str	w8, [x0]
	b.eq	LBB2_3
LBB2_2:
	ret
LBB2_3:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #16]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_file_nominal_plan_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_function ; -- Begin function nvm_file_flow_function
	.globl	_nvm_file_flow_function
	.p2align	2
_nvm_file_flow_function:                ; @nvm_file_flow_function
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB3_4
; %bb.1:
	cbz	x2, LBB3_4
; %bb.2:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB3_5
; %bb.3:
	mov	w9, #24                         ; =0x18
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #24]
	ldr	x8, [x8, #40]
	str	x8, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB3_4:
	ret
LBB3_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_declaration ; -- Begin function nvm_file_flow_declaration
	.globl	_nvm_file_flow_declaration
	.p2align	2
_nvm_file_flow_declaration:             ; @nvm_file_flow_declaration
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB4_5
; %bb.1:
	cbz	x3, LBB4_5
; %bb.2:
	ldr	w8, [x0, #4]
	cmp	w1, w8
	b.hs	LBB4_6
; %bb.3:
	mov	w8, #24                         ; =0x18
	umaddl	x8, w1, w8, x0
	ldrh	w8, [x8, #26]
	cmp	w2, w8
	b.hs	LBB4_6
; %bb.4:
	mov	w8, w1
	add	x8, x0, x8, lsl #2
	ldr	w8, [x8, #1560]
	add	w8, w8, w2
	add	x8, x0, w8, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w8, #1                          ; =0x1
LBB4_5:
	mov	x0, x8
	ret
LBB4_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_file_flow_state
lCPI5_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_file_flow_state
	.globl	_nvm_file_flow_state
	.p2align	2
_nvm_file_flow_state:                   ; @nvm_file_flow_state
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	cbz	x0, LBB5_12
; %bb.1:
	cbz	x2, LBB5_12
; %bb.2:
	ldr	w8, [x0, #4]
	cmp	w1, w8
	b.hs	LBB5_11
; %bb.3:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w19, [x0]
	cmn	w19, #1
	b.eq	LBB5_15
; %bb.4:
	mov	w8, #24                         ; =0x18
	umaddl	x22, w1, w8, x0
	mov	w21, w1
	ldrh	w20, [x22, #24]!
	cbz	w20, LBB5_13
; %bb.5:
	add	x8, x0, #1816
	add	x9, x0, x21, lsl #2
	ldr	w9, [x9, #1560]
	cmp	w20, #8
	b.hs	LBB5_28
; %bb.6:
	mov	x10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w12, #1                         ; =0x1
LBB5_7:
	add	w9, w9, w10
	sub	x10, x20, x10
LBB5_8:                                 ; =>This Inner Loop Header: Depth=1
	add	x13, x8, w9, uxtw #4
	ldrb	w14, [x13, #1]
	lsl	x14, x14, #8
	ldr	w13, [x13, #12]
	sub	x13, x13, #1
	cmp	x14, #0
	cset	w14, eq
	cset	w15, ne
	cmp	x13, #2
	csel	w13, wzr, w14, hs
	add	w11, w11, w13
	csinc	w13, w15, wzr, hs
	add	w12, w12, w13
	add	w9, w9, #1
	subs	x10, x10, #1
	b.ne	LBB5_8
LBB5_9:
	cmp	w11, #256
	b.hi	LBB5_15
; %bb.10:
	mov	w8, w12
	b	LBB5_14
LBB5_11:
	mov	w8, #1                          ; =0x1
LBB5_12:
	mov	x0, x8
	ret
LBB5_13:
	mov	w8, #1                          ; =0x1
LBB5_14:
	ldr	x23, [x0, #8]
	cmn	x23, x8
	b.lo	LBB5_17
LBB5_15:
	mov	w8, #3                          ; =0x3
LBB5_16:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB5_17:
	mov	x26, x1
	mov	x27, x0
	mov	x24, x2
	mov	w25, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #47152                      ; =0xb830
	bl	_calloc
	cbz	x0, LBB5_34
; %bb.18:
	mov	x9, x27
	str	x27, [x0]
	str	w26, [x0, #8]
	add	x5, x23, #1
	str	x5, [x27, #8]
	str	x23, [x0, #24]
	strb	w25, [x0, #40]
	ldrh	w8, [x22, #2]
	mov	x10, x24
	cbz	x8, LBB5_33
; %bb.19:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	add	x13, x9, #1816
	add	x14, x9, x21, lsl #2
	ldr	w14, [x14, #1560]
	mov	w15, #14384                     ; =0x3830
	add	x15, x0, x15
	mov	w16, #34868                     ; =0x8834
	mov	w17, #34866                     ; =0x8832
	mov	w1, #20480                      ; =0x5000
	mov	w2, #1                          ; =0x1
	mov	w3, #20481                      ; =0x5001
	mov	w4, #20512                      ; =0x5020
	b	LBB5_21
LBB5_20:                                ;   in Loop: Header=BB5_21 Depth=1
	add	x12, x12, #1
	add	w14, w14, #1
	add	x11, x11, #40
	add	x16, x16, #40
	add	x17, x17, #40
	mov	x5, x6
	cmp	x12, x8
	b.hs	LBB5_33
LBB5_21:                                ; =>This Inner Loop Header: Depth=1
	add	x22, x13, w14, uxtw #4
	ldp	x7, x21, [x22]
	cmp	x12, x20
	b.hs	LBB5_23
; %bb.22:                               ;   in Loop: Header=BB5_21 Depth=1
	and	x6, x7, #0xff00
	lsr	x23, x21, #32
	sub	x23, x23, #1
	cmp	x6, #0
	ccmp	x23, #1, #2, eq
	b.ls	LBB5_24
LBB5_23:                                ;   in Loop: Header=BB5_21 Depth=1
	mov	x6, x5
	mov	x5, #0                          ; =0x0
	b	LBB5_25
LBB5_24:                                ;   in Loop: Header=BB5_21 Depth=1
	add	x6, x5, #1
	str	x6, [x9, #8]
LBB5_25:                                ;   in Loop: Header=BB5_21 Depth=1
	ldr	q0, [x22]
	add	x22, x0, x11
	lsr	x21, x21, #33
	cmp	x21, #1
	cset	w21, eq
	str	q0, [x22, #14384]
	str	x5, [x22, #14408]
	str	w21, [x22, #14416]
	str	wzr, [x22, #14420]
	cmp	x12, x20
	cset	w5, lo
	add	x21, x15, x11
	strb	w5, [x21, #16]
	b.hs	LBB5_20
; %bb.26:                               ;   in Loop: Header=BB5_21 Depth=1
	ubfx	w5, w7, #8, #8
	cbz	w5, LBB5_20
; %bb.27:                               ;   in Loop: Header=BB5_21 Depth=1
	add	x7, x15, x11
	strb	w2, [x7, x1]
	strb	w2, [x7, x3]
	strh	w12, [x0, x17]
	str	wzr, [x0, x16]
	str	x6, [x7, #20488]
	str	x6, [x7, #20496]
	add	x6, x6, #1
	str	x6, [x9, #8]
	cmp	w5, #1
	cset	w5, eq
	str	xzr, [x7, #20504]
	strb	w5, [x7, x4]
	b	LBB5_20
LBB5_28:
	mov	w11, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	sub	x13, x20, #1
	mov	w12, #1                         ; =0x1
	cmn	w9, w13
	b.hs	LBB5_7
; %bb.29:
	lsr	x13, x13, #32
	cbnz	x13, LBB5_7
; %bb.30:
Lloh0:
	adrp	x10, lCPI5_0@PAGE
Lloh1:
	ldr	q0, [x10, lCPI5_0@PAGEOFF]
	and	x10, x20, #0xfff8
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0x0000000000ff00
	movi.2d	v3, #0xffffffffffffffff
	mov	w11, #2                         ; =0x2
	dup.2d	v4, x11
	mov	x11, x9
	mov	x12, x10
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
LBB5_31:                                ; =>This Inner Loop Header: Depth=1
	add	x13, x8, w11, uxtw #4
	ld2.2d	{ v16, v17 }, [x13], #32
	add	w14, w11, #4
	ld2.2d	{ v18, v19 }, [x13]
	add	x13, x8, w14, uxtw #4
	ld2.2d	{ v20, v21 }, [x13], #32
	ld2.2d	{ v22, v23 }, [x13]
	and.16b	v7, v18, v2
	and.16b	v24, v16, v2
	and.16b	v25, v20, v2
	and.16b	v26, v22, v2
	cmeq.2d	v24, v24, #0
	cmeq.2d	v7, v7, #0
	uzp1.4s	v7, v24, v7
	cmeq.2d	v24, v25, #0
	ushr.2d	v16, v17, #32
	cmeq.2d	v17, v26, #0
	ushr.2d	v18, v19, #32
	ushr.2d	v19, v21, #32
	ushr.2d	v20, v23, #32
	add.2d	v18, v18, v3
	add.2d	v16, v16, v3
	add.2d	v20, v20, v3
	add.2d	v19, v19, v3
	cmhi.2d	v16, v4, v16
	cmhi.2d	v18, v4, v18
	uzp1.4s	v16, v16, v18
	cmhi.2d	v18, v4, v19
	uzp1.4s	v17, v24, v17
	cmhi.2d	v19, v4, v20
	uzp1.4s	v18, v18, v19
	and.16b	v19, v7, v16
	and.16b	v20, v17, v18
	sub.4s	v1, v1, v19
	sub.4s	v6, v6, v20
	orn.16b	v7, v16, v7
	orn.16b	v16, v18, v17
	sub.4s	v0, v0, v7
	sub.4s	v5, v5, v16
	add	w11, w11, #8
	subs	x12, x12, #8
	b.ne	LBB5_31
; %bb.32:
	add.4s	v1, v6, v1
	addv.4s	s1, v1
	fmov	w11, s1
	add.4s	v0, v5, v0
	addv.4s	s0, v0
	fmov	w12, s0
	cmp	x10, x20
	b.ne	LBB5_7
	b	LBB5_9
LBB5_33:
	mov	w8, #0                          ; =0x0
	add	w11, w19, #1
	str	w11, [x9]
	str	x0, [x10]
	b	LBB5_16
LBB5_34:
	mov	w8, #4                          ; =0x4
	b	LBB5_16
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_state_free ; -- Begin function nvm_file_flow_state_free
	.globl	_nvm_file_flow_state_free
	.p2align	2
_nvm_file_flow_state_free:              ; @nvm_file_flow_state_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_5
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x19, [x0]
	cbz	x19, LBB6_4
; %bb.2:
	ldr	w8, [x19]
	subs	w8, w8, #1
	str	w8, [x19]
	b.ne	LBB6_4
; %bb.3:
	ldr	x8, [x19, #16]
	mov	x20, x0
	mov	x0, x8
	bl	_nvm_file_nominal_plan_free
	mov	x0, x19
	bl	_free
	mov	x0, x20
LBB6_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB6_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_local    ; -- Begin function nvm_file_flow_local
	.globl	_nvm_file_flow_local
	.p2align	2
_nvm_file_flow_local:                   ; @nvm_file_flow_local
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB7_4
; %bb.1:
	cbz	x2, LBB7_4
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB7_5
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	ldr	q0, [x8, #14384]
	ldr	q1, [x8, #14400]
	ldr	x8, [x8, #14416]
	str	x8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w8, #1                          ; =0x1
LBB7_4:
	mov	x0, x8
	ret
LBB7_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_stack    ; -- Begin function nvm_file_flow_stack
	.globl	_nvm_file_flow_stack
	.p2align	2
_nvm_file_flow_stack:                   ; @nvm_file_flow_stack
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB8_4
; %bb.1:
	cbz	x2, LBB8_4
; %bb.2:
	ldrh	w9, [x8, #12]
	cmp	w1, w9
	b.hs	LBB8_5
; %bb.3:
	mov	w9, #40                         ; =0x28
	umaddl	x8, w1, w9, x8
	ldr	q0, [x8, #24624]
	ldr	q1, [x8, #24640]
	ldr	x8, [x8, #24656]
	str	x8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB8_4:
	ret
LBB8_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_reference ; -- Begin function nvm_file_flow_reference
	.globl	_nvm_file_flow_reference
	.p2align	2
_nvm_file_flow_reference:               ; @nvm_file_flow_reference
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x2, #0, #4, ne
	mov	w9, #256                        ; =0x100
	ccmp	w1, w9, #2, ne
	cset	w0, lo
	cmp	w0, #1
	b.ne	LBB9_2
; %bb.1:
	mov	w9, #40                         ; =0x28
	umaddl	x8, w1, w9, x8
	mov	w9, #34864                      ; =0x8830
	add	x9, x8, x9
	ldr	q0, [x8, #34864]
	ldr	q1, [x8, #34880]
	ldr	x8, [x9, #32]
	str	x8, [x2, #32]
	stp	q0, q1, [x2]
LBB9_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_counts   ; -- Begin function nvm_file_flow_counts
	.globl	_nvm_file_flow_counts
	.p2align	2
_nvm_file_flow_counts:                  ; @nvm_file_flow_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB10_31
; %bb.1:
	ldrh	w9, [x8, #12]
	ldr	x10, [x8]
	ldr	w11, [x8, #8]
	mov	w12, #24                        ; =0x18
	umaddl	x10, w11, w12, x10
	ldrh	w11, [x10, #26]
	cbz	w11, LBB10_4
; %bb.2:
	cmp	w11, #4
	b.hi	LBB10_5
; %bb.3:
	mov	x12, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB10_13
LBB10_4:
	mov	w10, #0                         ; =0x0
	b	LBB10_15
LBB10_5:
	cmp	w11, #17
	b.hs	LBB10_7
; %bb.6:
	mov	x12, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB10_10
LBB10_7:
	mov	w10, #14408                     ; =0x3848
	add	x10, x8, x10
	ands	x12, x11, #0xf
	mov	w13, #16                        ; =0x10
	csel	x13, x13, x12, eq
	sub	x12, x11, x13
	movi.2d	v0, #0000000000000000
	mov	x14, x11
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
LBB10_8:                                ; =>This Inner Loop Header: Depth=1
	add	x15, x10, #40
	add	x16, x10, #120
	add	x17, x10, #200
	add	x2, x10, #280
	add	x3, x10, #360
	add	x4, x10, #440
	add	x5, x10, #520
	add	x6, x10, #600
	ldr	d4, [x10]
	ld1.d	{ v4 }[1], [x15]
	ldr	d5, [x10, #80]
	ld1.d	{ v5 }[1], [x16]
	ldr	d6, [x10, #160]
	ld1.d	{ v6 }[1], [x17]
	ldr	d7, [x10, #240]
	ld1.d	{ v7 }[1], [x2]
	ldr	d16, [x10, #320]
	ld1.d	{ v16 }[1], [x3]
	ldr	d17, [x10, #400]
	ld1.d	{ v17 }[1], [x4]
	ldr	d18, [x10, #480]
	ld1.d	{ v18 }[1], [x5]
	ldr	d19, [x10, #560]
	ld1.d	{ v19 }[1], [x6]
	cmeq.2d	v5, v5, #0
	cmeq.2d	v4, v4, #0
	uzp1.4s	v4, v4, v5
	mvn.16b	v4, v4
	xtn.4h	v4, v4
	cmeq.2d	v5, v7, #0
	cmeq.2d	v6, v6, #0
	uzp1.4s	v5, v6, v5
	mvn.16b	v5, v5
	xtn.4h	v5, v5
	cmeq.2d	v6, v17, #0
	cmeq.2d	v7, v16, #0
	uzp1.4s	v6, v7, v6
	mvn.16b	v6, v6
	xtn.4h	v6, v6
	cmeq.2d	v7, v19, #0
	cmeq.2d	v16, v18, #0
	uzp1.4s	v7, v16, v7
	mvn.16b	v7, v7
	xtn.4h	v7, v7
	sub.4h	v0, v0, v4
	sub.4h	v1, v1, v5
	sub.4h	v2, v2, v6
	sub.4h	v3, v3, v7
	sub	x14, x14, #16
	add	x10, x10, #640
	cmp	x13, x14
	b.ne	LBB10_8
; %bb.9:
	add.4h	v0, v1, v0
	add.4h	v1, v3, v2
	add.4h	v0, v1, v0
	addv.4h	h0, v0
	fmov	w10, s0
	cmp	x13, #5
	b.lo	LBB10_13
LBB10_10:
	mov	x13, x12
	ands	x12, x11, #0x3
	mov	w14, #4                         ; =0x4
	csel	x14, x14, x12, eq
	mov	w12, #40                        ; =0x28
	madd	x15, x13, x12, x8
	sub	x12, x11, x14
	movi.2d	v0, #0000000000000000
	mov.h	v0[0], w10
	add	x10, x14, x13
	sub	x10, x10, x11
	mov	w13, #14408                     ; =0x3848
	add	x13, x15, x13
LBB10_11:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x13, #40
	ldr	d1, [x13]
	ld1.d	{ v1 }[1], [x14]
	add	x14, x13, #120
	ldr	d2, [x13, #80]
	ld1.d	{ v2 }[1], [x14]
	cmeq.2d	v2, v2, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v1, v1, v2
	mvn.16b	v1, v1
	xtn.4h	v1, v1
	sub.4h	v0, v0, v1
	add	x13, x13, #160
	adds	x10, x10, #4
	b.ne	LBB10_11
; %bb.12:
	addv.4h	h0, v0
	fmov	w10, s0
LBB10_13:
	mov	w13, #40                        ; =0x28
	madd	x13, x12, x13, x8
	mov	w14, #14408                     ; =0x3848
	add	x13, x13, x14
	sub	x11, x11, x12
LBB10_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x13], #40
	cmp	x12, #0
	cinc	w10, w10, ne
	subs	x11, x11, #1
	b.ne	LBB10_14
LBB10_15:
	cbz	w9, LBB10_28
; %bb.16:
	cmp	w9, #4
	b.hi	LBB10_18
; %bb.17:
	mov	x11, #0                         ; =0x0
	b	LBB10_26
LBB10_18:
	cmp	w9, #17
	b.hs	LBB10_20
; %bb.19:
	mov	x11, #0                         ; =0x0
	b	LBB10_23
LBB10_20:
	mov	w11, #24648                     ; =0x6048
	add	x13, x8, x11
	ands	x11, x9, #0xf
	mov	w12, #16                        ; =0x10
	csel	x12, x12, x11, eq
	sub	x11, x9, x12
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.h	v1[0], w10
	mov	x10, x9
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
LBB10_21:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x13, #40
	add	x15, x13, #120
	add	x16, x13, #200
	add	x17, x13, #280
	add	x2, x13, #360
	add	x3, x13, #440
	add	x4, x13, #520
	add	x5, x13, #600
	ldr	d4, [x13]
	ld1.d	{ v4 }[1], [x14]
	ldr	d5, [x13, #80]
	ld1.d	{ v5 }[1], [x15]
	ldr	d6, [x13, #160]
	ld1.d	{ v6 }[1], [x16]
	ldr	d7, [x13, #240]
	ld1.d	{ v7 }[1], [x17]
	ldr	d16, [x13, #320]
	ld1.d	{ v16 }[1], [x2]
	ldr	d17, [x13, #400]
	ld1.d	{ v17 }[1], [x3]
	ldr	d18, [x13, #480]
	ld1.d	{ v18 }[1], [x4]
	ldr	d19, [x13, #560]
	ld1.d	{ v19 }[1], [x5]
	cmeq.2d	v5, v5, #0
	cmeq.2d	v4, v4, #0
	uzp1.4s	v4, v4, v5
	mvn.16b	v4, v4
	xtn.4h	v4, v4
	cmeq.2d	v5, v7, #0
	cmeq.2d	v6, v6, #0
	uzp1.4s	v5, v6, v5
	mvn.16b	v5, v5
	xtn.4h	v5, v5
	cmeq.2d	v6, v17, #0
	cmeq.2d	v7, v16, #0
	uzp1.4s	v6, v7, v6
	mvn.16b	v6, v6
	xtn.4h	v6, v6
	cmeq.2d	v7, v19, #0
	cmeq.2d	v16, v18, #0
	uzp1.4s	v7, v16, v7
	mvn.16b	v7, v7
	xtn.4h	v7, v7
	sub.4h	v1, v1, v4
	sub.4h	v0, v0, v5
	sub.4h	v2, v2, v6
	sub.4h	v3, v3, v7
	sub	x10, x10, #16
	add	x13, x13, #640
	cmp	x12, x10
	b.ne	LBB10_21
; %bb.22:
	add.4h	v0, v0, v1
	add.4h	v1, v3, v2
	add.4h	v0, v1, v0
	addv.4h	h0, v0
	fmov	w10, s0
	cmp	x12, #5
	b.lo	LBB10_26
LBB10_23:
	mov	x12, x11
	ands	x11, x9, #0x3
	mov	w13, #4                         ; =0x4
	csel	x13, x13, x11, eq
	mov	w11, #40                        ; =0x28
	madd	x14, x12, x11, x8
	sub	x11, x9, x13
	movi.2d	v0, #0000000000000000
	mov.h	v0[0], w10
	add	x10, x13, x12
	sub	x10, x10, x9
	mov	w12, #24648                     ; =0x6048
	add	x12, x14, x12
LBB10_24:                               ; =>This Inner Loop Header: Depth=1
	add	x13, x12, #40
	ldr	d1, [x12]
	ld1.d	{ v1 }[1], [x13]
	add	x13, x12, #120
	ldr	d2, [x12, #80]
	ld1.d	{ v2 }[1], [x13]
	cmeq.2d	v2, v2, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v1, v1, v2
	mvn.16b	v1, v1
	xtn.4h	v1, v1
	sub.4h	v0, v0, v1
	add	x12, x12, #160
	adds	x10, x10, #4
	b.ne	LBB10_24
; %bb.25:
	addv.4h	h0, v0
	fmov	w10, s0
LBB10_26:
	mov	w12, #40                        ; =0x28
	madd	x12, x11, x12, x8
	mov	w13, #24648                     ; =0x6048
	add	x12, x12, x13
	sub	x11, x9, x11
LBB10_27:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x12], #40
	cmp	x13, #0
	cinc	w10, w10, ne
	subs	x11, x11, #1
	b.ne	LBB10_27
LBB10_28:
	ldrh	w13, [x8, #14]
	ldr	x11, [x8, #32]
	ldrh	w12, [x8, #16]
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	ldrb	w14, [x8, #40]
	mov	w15, #34864                     ; =0x8830
	add	x15, x8, x15
	mov	w8, #256                        ; =0x100
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
LBB10_29:                               ; =>This Inner Loop Header: Depth=1
	add	x16, x15, #40
	prfm	pldl1keep, [x15, #2560]
	prfm	pldl1keep, [x15, #2640]
	ldr	b16, [x15]
	ld1.b	{ v16 }[1], [x16]
	add	x16, x15, #80
	prfm	pldl1keep, [x15, #2720]
	ld1.b	{ v16 }[2], [x16]
	add	x16, x15, #120
	ld1.b	{ v16 }[3], [x16]
	add	x16, x15, #160
	prfm	pldl1keep, [x15, #2800]
	ld1.b	{ v16 }[4], [x16]
	add	x16, x15, #200
	ld1.b	{ v16 }[5], [x16]
	add	x16, x15, #240
	prfm	pldl1keep, [x15, #2880]
	ld1.b	{ v16 }[6], [x16]
	add	x16, x15, #280
	ld1.b	{ v16 }[7], [x16]
	add	x16, x15, #360
	prfm	pldl1keep, [x15, #2960]
	ldr	b17, [x15, #320]
	ld1.b	{ v17 }[1], [x16]
	add	x16, x15, #400
	prfm	pldl1keep, [x15, #3040]
	ld1.b	{ v17 }[2], [x16]
	add	x16, x15, #440
	ld1.b	{ v17 }[3], [x16]
	add	x16, x15, #480
	prfm	pldl1keep, [x15, #3120]
	ld1.b	{ v17 }[4], [x16]
	add	x16, x15, #520
	ld1.b	{ v17 }[5], [x16]
	add	x16, x15, #560
	prfm	pldl1keep, [x15, #3200]
	ld1.b	{ v17 }[6], [x16]
	add	x16, x15, #600
	ld1.b	{ v17 }[7], [x16]
	add	x16, x15, #680
	prfm	pldl1keep, [x15, #3280]
	ldr	b18, [x15, #640]
	ld1.b	{ v18 }[1], [x16]
	add	x16, x15, #720
	prfm	pldl1keep, [x15, #3360]
	ld1.b	{ v18 }[2], [x16]
	add	x16, x15, #760
	ld1.b	{ v18 }[3], [x16]
	add	x16, x15, #800
	prfm	pldl1keep, [x15, #3440]
	ld1.b	{ v18 }[4], [x16]
	add	x16, x15, #840
	ld1.b	{ v18 }[5], [x16]
	add	x16, x15, #880
	prfm	pldl1keep, [x15, #3520]
	ld1.b	{ v18 }[6], [x16]
	add	x16, x15, #920
	ld1.b	{ v18 }[7], [x16]
	add	x16, x15, #1000
	prfm	pldl1keep, [x15, #3600]
	ldr	b19, [x15, #960]
	ld1.b	{ v19 }[1], [x16]
	add	x16, x15, #1040
	prfm	pldl1keep, [x15, #3680]
	ld1.b	{ v19 }[2], [x16]
	add	x16, x15, #1080
	ld1.b	{ v19 }[3], [x16]
	add	x16, x15, #1120
	prfm	pldl1keep, [x15, #3760]
	ld1.b	{ v19 }[4], [x16]
	add	x16, x15, #1160
	ld1.b	{ v19 }[5], [x16]
	add	x16, x15, #1200
	prfm	pldl1keep, [x15, #3840]
	ld1.b	{ v19 }[6], [x16]
	add	x16, x15, #1240
	ld1.b	{ v19 }[7], [x16]
	add	x16, x15, #1320
	prfm	pldl1keep, [x15, #3920]
	ldr	b20, [x15, #1280]
	ld1.b	{ v20 }[1], [x16]
	add	x16, x15, #1360
	prfm	pldl1keep, [x15, #4000]
	ld1.b	{ v20 }[2], [x16]
	add	x16, x15, #1400
	ld1.b	{ v20 }[3], [x16]
	add	x16, x15, #1440
	prfm	pldl1keep, [x15, #4080]
	ld1.b	{ v20 }[4], [x16]
	add	x16, x15, #1480
	ld1.b	{ v20 }[5], [x16]
	add	x16, x15, #1520
	prfm	pldl1keep, [x15, #4160]
	ld1.b	{ v20 }[6], [x16]
	add	x16, x15, #1560
	ld1.b	{ v20 }[7], [x16]
	add	x16, x15, #1640
	prfm	pldl1keep, [x15, #4240]
	ldr	b21, [x15, #1600]
	ld1.b	{ v21 }[1], [x16]
	add	x16, x15, #1680
	prfm	pldl1keep, [x15, #4320]
	ld1.b	{ v21 }[2], [x16]
	add	x16, x15, #1720
	ld1.b	{ v21 }[3], [x16]
	add	x16, x15, #1760
	prfm	pldl1keep, [x15, #4400]
	ld1.b	{ v21 }[4], [x16]
	add	x16, x15, #1800
	ld1.b	{ v21 }[5], [x16]
	add	x16, x15, #1840
	prfm	pldl1keep, [x15, #4480]
	ld1.b	{ v21 }[6], [x16]
	add	x16, x15, #1880
	ld1.b	{ v21 }[7], [x16]
	add	x16, x15, #1960
	prfm	pldl1keep, [x15, #4560]
	ldr	b22, [x15, #1920]
	ld1.b	{ v22 }[1], [x16]
	add	x16, x15, #2000
	prfm	pldl1keep, [x15, #4640]
	ld1.b	{ v22 }[2], [x16]
	add	x16, x15, #2040
	ld1.b	{ v22 }[3], [x16]
	add	x16, x15, #2080
	prfm	pldl1keep, [x15, #4720]
	ld1.b	{ v22 }[4], [x16]
	add	x16, x15, #2120
	ld1.b	{ v22 }[5], [x16]
	add	x16, x15, #2160
	prfm	pldl1keep, [x15, #4800]
	ld1.b	{ v22 }[6], [x16]
	add	x16, x15, #2200
	ld1.b	{ v22 }[7], [x16]
	add	x16, x15, #2280
	prfm	pldl1keep, [x15, #4880]
	ldr	b23, [x15, #2240]
	ld1.b	{ v23 }[1], [x16]
	add	x16, x15, #2320
	prfm	pldl1keep, [x15, #4960]
	ld1.b	{ v23 }[2], [x16]
	add	x16, x15, #2360
	ld1.b	{ v23 }[3], [x16]
	add	x16, x15, #2400
	prfm	pldl1keep, [x15, #5040]
	ld1.b	{ v23 }[4], [x16]
	add	x16, x15, #2440
	ld1.b	{ v23 }[5], [x16]
	add	x16, x15, #2480
	ld1.b	{ v23 }[6], [x16]
	add	x16, x15, #2520
	ld1.b	{ v23 }[7], [x16]
	uaddw.8h	v0, v0, v16
	uaddw.8h	v1, v1, v17
	uaddw.8h	v3, v3, v18
	uaddw.8h	v4, v4, v19
	add	x15, x15, #2560
	uaddw.8h	v5, v5, v20
	uaddw.8h	v2, v2, v21
	uaddw.8h	v7, v7, v22
	uaddw.8h	v6, v6, v23
	subs	x8, x8, #64
	b.ne	LBB10_29
; %bb.30:
	add.8h	v0, v3, v0
	add.8h	v1, v4, v1
	add.8h	v3, v7, v5
	add.8h	v0, v3, v0
	add.8h	v2, v6, v2
	add.8h	v1, v2, v1
	strh	w9, [x1]
	add.8h	v0, v0, v1
	strh	w13, [x1, #2]
	strh	w10, [x1, #4]
	addv.8h	h0, v0
	str	h0, [x1, #6]
	str	x11, [x1, #8]
	strh	w12, [x1, #16]
	strb	w14, [x1, #18]
	stur	wzr, [x1, #19]
	strb	wzr, [x1, #23]
LBB10_31:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_push_scalar ; -- Begin function nvm_file_flow_push_scalar
	.globl	_nvm_file_flow_push_scalar
	.p2align	2
_nvm_file_flow_push_scalar:             ; @nvm_file_flow_push_scalar
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w1 killed $w1 def $x1
	cbz	x0, LBB11_5
; %bb.1:
	mov	x8, x0
	mov	w9, #250                        ; =0xfa
	mov	w0, #2                          ; =0x2
	tst	w1, w9
	b.ne	LBB11_7
; %bb.2:
	ldrb	w9, [x8, #40]
	tbz	w9, #0, LBB11_7
; %bb.3:
	ldrh	w9, [x8, #12]
	cmp	x9, #256
	b.ne	LBB11_6
; %bb.4:
	mov	w0, #3                          ; =0x3
	ret
LBB11_5:
	mov	w0, #1                          ; =0x1
	ret
LBB11_6:
	mov	w0, #0                          ; =0x0
	add	w10, w9, #1
	strh	w10, [x8, #12]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	orr	x9, x1, #0xffffffff00000000
	str	x9, [x8, #24624]
	mov	w9, #-1                         ; =0xffffffff
	str	x9, [x8, #24632]
	mov	w9, #24624                      ; =0x6030
	add	x9, x8, x9
	mov	w10, #1                         ; =0x1
	strb	w10, [x9, #16]
	str	xzr, [x8, #24656]
	stur	xzr, [x9, #25]
	stur	xzr, [x9, #17]
LBB11_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_load     ; -- Begin function nvm_file_flow_load
	.globl	_nvm_file_flow_load
	.p2align	2
_nvm_file_flow_load:                    ; @nvm_file_flow_load
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB12_8
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB12_9
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB12_8
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #14384                      ; =0x3830
	add	x8, x8, x9
	ldrb	w9, [x8, #16]
	cmp	w9, #1
	b.ne	LBB12_8
; %bb.4:
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB12_8
; %bb.5:
	ldr	w9, [x8, #12]
	sub	x9, x9, #1
	ldrb	w10, [x8, #1]
	cmp	w10, #0
	ccmp	x9, #2, #2, eq
	b.lo	LBB12_8
; %bb.6:
	ldrh	w9, [x0, #12]
	cmp	x9, #256
	b.ne	LBB12_10
; %bb.7:
	mov	w0, #3                          ; =0x3
	ret
LBB12_8:
	mov	w0, #1                          ; =0x1
	ret
LBB12_9:
	mov	w0, #2                          ; =0x2
	ret
LBB12_10:
	mov	w11, #40                        ; =0x28
	umaddl	x11, w9, w11, x0
	add	w9, w9, #1
	strh	w9, [x0, #12]
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8, #32]
	ldp	q1, q0, [x8]
	str	q1, [x11, #24624]
	str	q0, [x11, #24640]
	str	x9, [x11, #24656]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_store    ; -- Begin function nvm_file_flow_store
	.globl	_nvm_file_flow_store
	.p2align	2
_nvm_file_flow_store:                   ; @nvm_file_flow_store
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_11
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB13_12
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB13_11
; %bb.3:
	ldrh	w9, [x0, #12]
	cbz	x9, LBB13_11
; %bb.4:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	mov	w8, #24624                      ; =0x6030
	add	x8, x0, x8
	mov	w14, #40                        ; =0x28
	umaddl	x10, w9, w14, x8
	ldp	x11, x12, [x10, #-40]
	ldurb	w13, [x10, #-24]
	ldur	w15, [x10, #-23]
	str	w15, [sp, #8]
	ldur	w15, [x10, #-20]
	stur	w15, [sp, #11]
	ldp	x15, x10, [x10, #-16]
	cmp	x15, #0
	cset	w15, eq
	and	w15, w13, w15
	and	x16, x11, #0xffffffff0000ffff
	cmp	w15, #1
	mov	x17, #-4294967296               ; =0xffffffff00000000
	ccmp	x16, x17, #0, eq
	b.ne	LBB13_13
; %bb.5:
	umaddl	x14, w1, w14, x0
	mov	w16, #14384                     ; =0x3830
	add	x14, x14, x16
	ldrb	w16, [x14]
	cbz	w16, LBB13_13
; %bb.6:
	ldrb	w10, [x14, #1]
	cbnz	w10, LBB13_18
; %bb.7:
	ldr	x10, [x14, #8]
	ldrb	w11, [x14, #1]
	cbnz	w11, LBB13_9
; %bb.8:
	lsr	x11, x10, #32
	sub	x11, x11, #1
	cmp	x11, #2
	b.lo	LBB13_18
LBB13_9:
	lsr	x10, x10, #33
	cmp	x10, #1
	cset	w10, eq
	stp	xzr, xzr, [x14, #16]
	stp	w10, wzr, [x14, #32]
LBB13_10:
	mov	w14, #0                         ; =0x0
	sub	w9, w9, #1
	strh	w9, [x0, #12]
	and	x9, x9, #0xffff
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	xzr, [x8, #32]
	b	LBB13_19
LBB13_11:
	mov	w0, #1                          ; =0x1
	ret
LBB13_12:
	mov	w0, #2                          ; =0x2
	ret
LBB13_13:
	cbz	w15, LBB13_18
; %bb.14:
	mov	w14, #40                        ; =0x28
	umaddl	x14, w1, w14, x0
	mov	w15, #14384                     ; =0x3830
	add	x15, x14, x15
	ldrb	w14, [x15, #1]
	cbnz	w14, LBB13_18
; %bb.15:
	ldp	x14, x16, [x15]
	and	x17, x14, #0xff00
	cbnz	x17, LBB13_17
; %bb.16:
	lsr	x17, x16, #32
	sub	x17, x17, #1
	cmp	x17, #2
	b.lo	LBB13_18
LBB13_17:
	eor	x17, x14, x11
	tst	x17, #0xff
	b.eq	LBB13_20
LBB13_18:
	mov	w14, #1                         ; =0x1
LBB13_19:
	mov	x0, x14
	add	sp, sp, #16
	ret
LBB13_20:
	mov	x1, #-256                       ; =0xffffffffffffff00
	movk	x1, #0, lsl #16
	mov	w14, #1                         ; =0x1
	tst	x17, x1
	b.ne	LBB13_19
; %bb.21:
	cmp	x12, x16
	b.ne	LBB13_19
; %bb.22:
	stp	x11, x12, [x15]
	strb	w13, [x15, #16]
	ldr	w11, [sp, #8]
	stur	w11, [x15, #17]
	ldur	w11, [sp, #11]
	str	w11, [x15, #20]
	stp	xzr, x10, [x15, #24]
	b	LBB13_10
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_clear_copy ; -- Begin function nvm_file_flow_clear_copy
	.globl	_nvm_file_flow_clear_copy
	.p2align	2
_nvm_file_flow_clear_copy:              ; @nvm_file_flow_clear_copy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB14_6
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB14_6
; %bb.2:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB14_7
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #14384                      ; =0x3830
	add	x8, x8, x9
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB14_6
; %bb.4:
	ldr	x9, [x8, #8]
	lsr	x10, x9, #32
	sub	x10, x10, #1
	ldrb	w11, [x8, #1]
	cmp	w11, #0
	ccmp	x10, #2, #2, eq
	b.lo	LBB14_6
; %bb.5:
	mov	w0, #0                          ; =0x0
	lsr	x9, x9, #33
	cmp	x9, #1
	stp	xzr, xzr, [x8, #16]
	cset	w9, eq
	stp	w9, wzr, [x8, #32]
	ret
LBB14_6:
	mov	w0, #1                          ; =0x1
	ret
LBB14_7:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_dup      ; -- Begin function nvm_file_flow_dup
	.globl	_nvm_file_flow_dup
	.p2align	2
_nvm_file_flow_dup:                     ; @nvm_file_flow_dup
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB15_4
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB15_5
; %bb.2:
	ldrh	w8, [x0, #12]
	cbz	x8, LBB15_4
; %bb.3:
	mov	w9, #24624                      ; =0x6030
	add	x9, x0, x9
	sub	w10, w8, #1
	mov	w11, #40                        ; =0x28
	umaddl	x10, w10, w11, x9
	ldr	x11, [x10, #24]
	cbz	x11, LBB15_6
LBB15_4:
	mov	w0, #1                          ; =0x1
	ret
LBB15_5:
	mov	w0, #2                          ; =0x2
	ret
LBB15_6:
	cmp	w8, #256
	b.ne	LBB15_8
; %bb.7:
	mov	w0, #3                          ; =0x3
	ret
LBB15_8:
	mov	x11, x0
	mov	w0, #0                          ; =0x0
	mov	w12, #40                        ; =0x28
	umaddl	x9, w8, w12, x9
	ldp	q0, q1, [x10]
	ldr	x10, [x10, #32]
	str	x10, [x9, #32]
	stp	q0, q1, [x9]
	add	w8, w8, #1
	strh	w8, [x11, #12]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_pop      ; -- Begin function nvm_file_flow_pop
	.globl	_nvm_file_flow_pop
	.p2align	2
_nvm_file_flow_pop:                     ; @nvm_file_flow_pop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_4
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB16_5
; %bb.2:
	ldrh	w8, [x0, #12]
	cbz	x8, LBB16_4
; %bb.3:
	sub	w9, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x9, w9, w10, x0
	ldr	x9, [x9, #24648]
	cbz	x9, LBB16_6
LBB16_4:
	mov	w0, #1                          ; =0x1
	ret
LBB16_5:
	mov	w0, #2                          ; =0x2
	ret
LBB16_6:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	sub	w8, w8, #1
	and	x10, x8, #0xffff
	mov	w11, #40                        ; =0x28
	umaddl	x10, w10, w11, x9
	strh	w8, [x9, #12]
	movi.2d	v0, #0000000000000000
	str	q0, [x10, #24624]
	str	q0, [x10, #24640]
	str	xzr, [x10, #24656]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_move     ; -- Begin function nvm_file_flow_move
	.globl	_nvm_file_flow_move
	.p2align	2
_nvm_file_flow_move:                    ; @nvm_file_flow_move
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB17_15
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB17_10
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w10, [x8, #26]
	cmp	w1, w10
	b.hs	LBB17_15
; %bb.3:
	mov	w8, #14384                      ; =0x3830
	add	x12, x0, x8
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x12
	mov	x9, x8
	ldrb	w11, [x9, #16]!
	cmp	w11, #1
	b.ne	LBB17_15
; %bb.4:
	ldr	x14, [x8, #24]
	cbz	x14, LBB17_15
; %bb.5:
	ldp	x13, x11, [x8]
	and	x15, x13, #0xff00
	lsr	x16, x11, #32
	sub	x16, x16, #1
	cmp	x15, #0
	ccmp	x16, #1, #2, eq
	b.hi	LBB17_15
; %bb.6:
	mov	w15, #34872                     ; =0x8838
	add	x15, x0, x15
	mov	w16, #256                       ; =0x100
	b	LBB17_8
LBB17_7:                                ;   in Loop: Header=BB17_8 Depth=1
	add	x15, x15, #40
	subs	x16, x16, #1
	b.eq	LBB17_11
LBB17_8:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w17, [x15, #-8]
	cmp	w17, #1
	b.ne	LBB17_7
; %bb.9:                                ;   in Loop: Header=BB17_8 Depth=1
	ldr	x17, [x15]
	cmp	x17, x14
	b.ne	LBB17_7
	b	LBB17_15
LBB17_10:
	mov	w0, #2                          ; =0x2
	ret
LBB17_11:
	cmp	w2, w10
	b.hs	LBB17_15
; %bb.12:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w2, w10, x12
	ldrb	w12, [x10, #16]
	tbnz	w12, #0, LBB17_15
; %bb.13:
	ldr	x12, [x10]
	eor	x12, x12, x13
	tst	x12, #0xff
	b.ne	LBB17_15
; %bb.14:
	ldr	x13, [x10, #8]
	and	x12, x12, #0xffffffffffffff00
	and	x12, x12, #0xffffffff0000ffff
	cmp	x12, #0
	ccmp	x11, x13, #0, eq
	b.eq	LBB17_16
LBB17_15:
	mov	w0, #1                          ; =0x1
	ret
LBB17_16:
	ldr	x11, [x8, #32]
	ldp	q1, q0, [x8]
	str	x11, [x10, #32]
	stp	q1, q0, [x10]
	ldr	w11, [x10, #12]
	cmp	w11, #2
	b.ne	LBB17_18
; %bb.17:
	mov	w11, #1                         ; =0x1
	str	w11, [x10, #32]
LBB17_18:
	mov	w0, #0                          ; =0x0
	ldr	x10, [x8, #8]
	lsr	x10, x10, #33
	cmp	x10, #1
	cset	w10, eq
	stp	xzr, xzr, [x9]
	stp	w10, wzr, [x8, #32]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_take     ; -- Begin function nvm_file_flow_take
	.globl	_nvm_file_flow_take
	.p2align	2
_nvm_file_flow_take:                    ; @nvm_file_flow_take
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB18_10
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB18_11
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB18_10
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #14384                      ; =0x3830
	add	x8, x8, x9
	mov	x9, x8
	ldrb	w10, [x9, #16]!
	cmp	w10, #1
	b.ne	LBB18_10
; %bb.4:
	ldr	x10, [x8, #24]
	cbz	x10, LBB18_10
; %bb.5:
	ldr	w11, [x8, #12]
	sub	x11, x11, #1
	ldrb	w12, [x8, #1]
	cmp	w12, #0
	ccmp	x11, #1, #2, eq
	b.hi	LBB18_10
; %bb.6:
	mov	w11, #34872                     ; =0x8838
	add	x11, x0, x11
	mov	w12, #256                       ; =0x100
	b	LBB18_8
LBB18_7:                                ;   in Loop: Header=BB18_8 Depth=1
	add	x11, x11, #40
	subs	x12, x12, #1
	b.eq	LBB18_12
LBB18_8:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x11, #-8]
	cmp	w13, #1
	b.ne	LBB18_7
; %bb.9:                                ;   in Loop: Header=BB18_8 Depth=1
	ldr	x13, [x11]
	cmp	x13, x10
	b.ne	LBB18_7
LBB18_10:
	mov	w0, #1                          ; =0x1
	ret
LBB18_11:
	mov	w0, #2                          ; =0x2
	ret
LBB18_12:
	ldrh	w10, [x0, #12]
	cmp	x10, #256
	b.ne	LBB18_14
; %bb.13:
	mov	w0, #3                          ; =0x3
	ret
LBB18_14:
	mov	w11, #40                        ; =0x28
	umaddl	x12, w10, w11, x0
	mov	w11, #24624                     ; =0x6030
	add	x11, x12, x11
	ldr	x13, [x8, #32]
	ldp	q1, q0, [x8]
	str	q1, [x12, #24624]
	str	x13, [x12, #24656]
	str	q0, [x12, #24640]
	ldr	w12, [x11, #12]
	cmp	w12, #2
	b.ne	LBB18_16
; %bb.15:
	mov	w12, #1                         ; =0x1
	str	w12, [x11, #32]
LBB18_16:
	add	w10, w10, #1
	strh	w10, [x0, #12]
	mov	w0, #0                          ; =0x0
	ldr	x10, [x8, #8]
	lsr	x10, x10, #33
	cmp	x10, #1
	cset	w10, eq
	stp	xzr, xzr, [x9]
	stp	w10, wzr, [x8, #32]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_put      ; -- Begin function nvm_file_flow_put
	.globl	_nvm_file_flow_put
	.p2align	2
_nvm_file_flow_put:                     ; @nvm_file_flow_put
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB19_9
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB19_10
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB19_9
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #14384                      ; =0x3830
	add	x8, x8, x9
	ldrb	w9, [x8, #16]
	tbnz	w9, #0, LBB19_9
; %bb.4:
	ldrh	w10, [x0, #12]
	cbz	x10, LBB19_9
; %bb.5:
	mov	w9, #24624                      ; =0x6030
	add	x9, x0, x9
	sub	w11, w10, #1
	mov	w12, #40                        ; =0x28
	umaddl	x12, w11, w12, x9
	ldr	x11, [x12, #24]
	cbz	x11, LBB19_9
; %bb.6:
	ldp	x13, x15, [x12]
	and	x16, x13, #0xff00
	lsr	x14, x15, #32
	sub	x17, x14, #1
	cmp	x16, #0
	ccmp	x17, #1, #2, eq
	b.hi	LBB19_9
; %bb.7:
	ldr	x16, [x8]
	eor	x16, x16, x13
	tst	x16, #0xff
	b.ne	LBB19_9
; %bb.8:
	ldr	x17, [x8, #8]
	and	x16, x16, #0xffffffffffffff00
	and	x16, x16, #0xffffffff0000ffff
	cmp	x16, #0
	ccmp	x15, x17, #0, eq
	b.eq	LBB19_11
LBB19_9:
	mov	w0, #1                          ; =0x1
	ret
LBB19_10:
	mov	w0, #2                          ; =0x2
	ret
LBB19_11:
	ldur	q0, [x12, #8]
	cmp	x14, #2
	ldp	w14, w12, [x12, #32]
	csinc	w14, w14, wzr, ne
	str	x13, [x8]
	stur	q0, [x8, #8]
	str	x11, [x8, #24]
	stp	w14, w12, [x8, #32]
	sub	w8, w10, #1
	strh	w8, [x0, #12]
	mov	w0, #0                          ; =0x0
	and	x8, x8, #0xffff
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_drop_local ; -- Begin function nvm_file_flow_drop_local
	.globl	_nvm_file_flow_drop_local
	.p2align	2
_nvm_file_flow_drop_local:              ; @nvm_file_flow_drop_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB20_10
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB20_11
; %bb.2:
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB20_10
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #14384                      ; =0x3830
	add	x8, x8, x9
	mov	x9, x8
	ldrb	w10, [x9, #16]!
	cmp	w10, #1
	b.ne	LBB20_10
; %bb.4:
	ldr	x11, [x8, #24]
	cbz	x11, LBB20_10
; %bb.5:
	ldr	x10, [x8, #8]
	lsr	x12, x10, #32
	sub	x12, x12, #1
	ldrb	w13, [x8, #1]
	cmp	w13, #0
	ccmp	x12, #1, #2, eq
	b.hi	LBB20_10
; %bb.6:
	mov	w12, #34872                     ; =0x8838
	add	x12, x0, x12
	mov	w13, #256                       ; =0x100
	b	LBB20_8
LBB20_7:                                ;   in Loop: Header=BB20_8 Depth=1
	add	x12, x12, #40
	subs	x13, x13, #1
	b.eq	LBB20_12
LBB20_8:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w14, [x12, #-8]
	cmp	w14, #1
	b.ne	LBB20_7
; %bb.9:                                ;   in Loop: Header=BB20_8 Depth=1
	ldr	x14, [x12]
	cmp	x14, x11
	b.ne	LBB20_7
LBB20_10:
	mov	w0, #1                          ; =0x1
	ret
LBB20_11:
	mov	w0, #2                          ; =0x2
	ret
LBB20_12:
	ldr	x11, [x0, #32]
	cmn	x11, #1
	b.eq	LBB20_14
; %bb.13:
	add	x11, x11, #1
	str	x11, [x0, #32]
	mov	w0, #0                          ; =0x0
	lsr	x10, x10, #33
	cmp	x10, #1
	cset	w10, eq
	stp	xzr, xzr, [x9]
	stp	w10, wzr, [x8, #32]
	ret
LBB20_14:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_drop_stack ; -- Begin function nvm_file_flow_drop_stack
	.globl	_nvm_file_flow_drop_stack
	.p2align	2
_nvm_file_flow_drop_stack:              ; @nvm_file_flow_drop_stack
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB21_6
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB21_7
; %bb.2:
	ldrh	w8, [x0, #12]
	cbz	x8, LBB21_6
; %bb.3:
	sub	w9, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x9, w9, w10, x0
	ldr	x9, [x9, #24648]
	cbz	x9, LBB21_6
; %bb.4:
	ldr	x9, [x0, #32]
	cmn	x9, #1
	b.eq	LBB21_8
; %bb.5:
	mov	x10, x0
	mov	w0, #0                          ; =0x0
	add	x9, x9, #1
	str	x9, [x10, #32]
	sub	w8, w8, #1
	and	x9, x8, #0xffff
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	strh	w8, [x10, #12]
	movi.2d	v0, #0000000000000000
	str	q0, [x9, #24624]
	str	q0, [x9, #24640]
	str	xzr, [x9, #24656]
	ret
LBB21_6:
	mov	w0, #1                          ; =0x1
	ret
LBB21_7:
	mov	w0, #2                          ; =0x2
	ret
LBB21_8:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_region_begin ; -- Begin function nvm_file_flow_region_begin
	.globl	_nvm_file_flow_region_begin
	.p2align	2
_nvm_file_flow_region_begin:            ; @nvm_file_flow_region_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB22_5
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB22_6
; %bb.2:
	ldrh	w8, [x0, #14]
	cmp	x8, #256
	b.eq	LBB22_7
; %bb.3:
	ldr	x10, [x0]
	ldr	x9, [x10, #8]
	cmn	x9, #1
	b.eq	LBB22_7
; %bb.4:
	mov	x11, x0
	mov	w0, #0                          ; =0x0
	add	x12, x9, #1
	str	x12, [x10, #8]
	add	x10, x11, x8, lsl #3
	add	w8, w8, #1
	strh	w8, [x11, #14]
	mov	w8, #45104                      ; =0xb030
	str	x9, [x10, x8]
	ret
LBB22_5:
	mov	w0, #1                          ; =0x1
	ret
LBB22_6:
	mov	w0, #2                          ; =0x2
	ret
LBB22_7:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_region_end ; -- Begin function nvm_file_flow_region_end
	.globl	_nvm_file_flow_region_end
	.p2align	2
_nvm_file_flow_region_end:              ; @nvm_file_flow_region_end
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB23_9
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB23_10
; %bb.2:
	ldrh	w8, [x0, #14]
	cbz	x8, LBB23_9
; %bb.3:
	mov	w9, #45104                      ; =0xb030
	add	x9, x0, x9
	sub	w10, w8, #1
	ldr	x10, [x9, w10, uxtw #3]
	mov	w11, #34864                     ; =0x8830
	add	x11, x0, x11
	mov	w12, #256                       ; =0x100
	movi.2d	v0, #0000000000000000
	b	LBB23_5
LBB23_4:                                ;   in Loop: Header=BB23_5 Depth=1
	add	x11, x11, #40
	subs	x12, x12, #1
	b.eq	LBB23_11
LBB23_5:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w13, [x11]
	cmp	w13, #1
	b.ne	LBB23_4
; %bb.6:                                ;   in Loop: Header=BB23_5 Depth=1
	ldrb	w13, [x11, #1]
	tbnz	w13, #0, LBB23_4
; %bb.7:                                ;   in Loop: Header=BB23_5 Depth=1
	ldr	x13, [x11, #24]
	cmp	x13, x10
	b.ne	LBB23_4
; %bb.8:                                ;   in Loop: Header=BB23_5 Depth=1
	str	xzr, [x11, #32]
	stp	q0, q0, [x11]
	b	LBB23_4
LBB23_9:
	mov	w0, #1                          ; =0x1
	ret
LBB23_10:
	mov	w0, #2                          ; =0x2
	ret
LBB23_11:
	sub	w8, w8, #1
	strh	w8, [x0, #14]
	mov	w0, #0                          ; =0x0
	and	x8, x8, #0xffff
	str	xzr, [x9, x8, lsl #3]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_borrow   ; -- Begin function nvm_file_flow_borrow
	.globl	_nvm_file_flow_borrow
	.p2align	2
_nvm_file_flow_borrow:                  ; @nvm_file_flow_borrow
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_file_flow_borrow_mode
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_flow_borrow_mode
_file_flow_borrow_mode:                 ; @file_flow_borrow_mode
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB25_6
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB25_8
; %bb.2:
	ldr	x9, [x0]
	ldr	w8, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w8, w10, x9
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB25_6
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w10, #14384                     ; =0x3830
	add	x11, x8, x10
	ldrb	w8, [x11, #16]
	cmp	w8, #1
	b.ne	LBB25_6
; %bb.4:
	ldr	x10, [x11, #24]
	cbz	x10, LBB25_6
; %bb.5:
	ldrb	w8, [x11, #1]
	cbz	w8, LBB25_9
LBB25_6:
	mov	w8, #1                          ; =0x1
LBB25_7:
	mov	x0, x8
	ret
LBB25_8:
	mov	w0, #2                          ; =0x2
	ret
LBB25_9:
	mov	w8, #1                          ; =0x1
	cmp	w2, #255
	b.hi	LBB25_7
; %bb.10:
	ldr	w11, [x11, #12]
	cmp	w11, #1
	b.ne	LBB25_7
; %bb.11:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w2, w8, x0
	mov	w11, #34864                     ; =0x8830
	add	x11, x8, x11
	ldrb	w8, [x11]
	tbnz	w8, #0, LBB25_6
; %bb.12:
	ldrh	w12, [x0, #14]
	cbz	x12, LBB25_6
; %bb.13:
	mov	w8, #34896                      ; =0x8850
	add	x8, x0, x8
	mov	w13, #256                       ; =0x100
	b	LBB25_15
LBB25_14:                               ;   in Loop: Header=BB25_15 Depth=1
	add	x8, x8, #40
	subs	x13, x13, #1
	b.eq	LBB25_19
LBB25_15:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w14, [x8, #-32]
	cmp	w14, #1
	b.ne	LBB25_14
; %bb.16:                               ;   in Loop: Header=BB25_15 Depth=1
	ldur	x14, [x8, #-24]
	cmp	x14, x10
	b.ne	LBB25_14
; %bb.17:                               ;   in Loop: Header=BB25_15 Depth=1
	cbz	w3, LBB25_6
; %bb.18:                               ;   in Loop: Header=BB25_15 Depth=1
	ldrb	w14, [x8]
	cmp	w14, #1
	b.eq	LBB25_14
	b	LBB25_6
LBB25_19:
	ldr	x13, [x9, #8]
	cmn	x13, #1
	b.eq	LBB25_21
; %bb.20:
	add	x14, x13, #1
	str	x14, [x9, #8]
	add	x9, x0, x12, lsl #3
	mov	w12, #45096                     ; =0xb028
	ldr	x9, [x9, x12]
	mov	w12, #1                         ; =0x1
	strh	w12, [x11]
	strh	w1, [x11, #2]
	str	wzr, [x11, #4]
	stp	x10, x13, [x11, #8]
	str	x9, [x11, #24]
	strb	w3, [x11, #32]
	stur	wzr, [x11, #33]
	str	wzr, [x11, #36]
	mov	w0, #0                          ; =0x0
	ret
LBB25_21:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_borrow_shared ; -- Begin function nvm_file_flow_borrow_shared
	.globl	_nvm_file_flow_borrow_shared
	.p2align	2
_nvm_file_flow_borrow_shared:           ; @nvm_file_flow_borrow_shared
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_file_flow_borrow_mode
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_end_borrow ; -- Begin function nvm_file_flow_end_borrow
	.globl	_nvm_file_flow_end_borrow
	.p2align	2
_nvm_file_flow_end_borrow:              ; @nvm_file_flow_end_borrow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB27_5
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB27_6
; %bb.2:
	cmp	w1, #255
	b.hi	LBB27_5
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #34864                      ; =0x8830
	add	x8, x8, x9
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB27_5
; %bb.4:
	ldrb	w9, [x8, #1]
	tbz	w9, #0, LBB27_7
LBB27_5:
	mov	w0, #1                          ; =0x1
	ret
LBB27_6:
	mov	w0, #2                          ; =0x2
	ret
LBB27_7:
	mov	w0, #0                          ; =0x0
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_can_exit ; -- Begin function nvm_file_flow_can_exit
	.globl	_nvm_file_flow_can_exit
	.p2align	2
_nvm_file_flow_can_exit:                ; @nvm_file_flow_can_exit
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB28_17
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB28_19
; %bb.2:
	ldrh	w8, [x0, #14]
	cbnz	w8, LBB28_17
; %bb.3:
	ldr	x8, [x0]
	mov	w9, #24                         ; =0x18
	ldr	w10, [x0, #8]
	umaddl	x8, w10, w9, x8
	ldrh	w10, [x0, #12]
	ldurb	w9, [x8, #28]
	cmp	w10, w9
	b.ne	LBB28_17
; %bb.4:
	cbz	w9, LBB28_9
; %bb.5:
	mov	w9, #24640                      ; =0x6040
	ldrb	w9, [x0, x9]
	tbz	w9, #0, LBB28_17
; %bb.6:
	ldr	x9, [x0, #24624]
	ldur	x10, [x8, #32]
	eor	x11, x10, x9
	tst	x11, #0xff
	b.ne	LBB28_17
; %bb.7:
	ldr	x10, [x0, #24632]
	ldur	x12, [x8, #40]
	and	x11, x11, #0xffffffffffffff00
	and	x11, x11, #0xffffffff0000ffff
	cmp	x11, #0
	ccmp	x10, x12, #0, eq
	b.ne	LBB28_17
; %bb.8:
	ldr	x11, [x0, #24648]
	lsr	x10, x10, #32
	sub	x10, x10, #1
	tst	x9, #0xff00
	ccmp	x10, #2, #2, eq
	cset	w9, lo
	cmp	x11, #0
	cset	w10, eq
	cmp	w10, w9
	b.eq	LBB28_17
LBB28_9:
	ldurh	w8, [x8, #26]
	cbz	x8, LBB28_13
; %bb.10:
	mov	w9, #14408                      ; =0x3848
	add	x9, x0, x9
LBB28_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9], #40
	cbnz	x10, LBB28_17
; %bb.12:                               ;   in Loop: Header=BB28_11 Depth=1
	subs	x8, x8, #1
	b.ne	LBB28_11
LBB28_13:
	mov	w8, #34865                      ; =0x8831
	add	x8, x0, x8
	mov	w9, #256                        ; =0x100
	b	LBB28_15
LBB28_14:                               ;   in Loop: Header=BB28_15 Depth=1
	mov	w0, #0                          ; =0x0
	add	x8, x8, #40
	subs	x9, x9, #1
	b.eq	LBB28_18
LBB28_15:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x8, #-1]
	cmp	w10, #1
	b.ne	LBB28_14
; %bb.16:                               ;   in Loop: Header=BB28_15 Depth=1
	ldrb	w10, [x8]
	cmp	w10, #1
	b.eq	LBB28_14
LBB28_17:
	mov	w0, #1                          ; =0x1
LBB28_18:
	ret
LBB28_19:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_obligation ; -- Begin function nvm_file_flow_obligation
	.globl	_nvm_file_flow_obligation
	.p2align	2
_nvm_file_flow_obligation:              ; @nvm_file_flow_obligation
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB29_4
; %bb.1:
	cbz	x2, LBB29_4
; %bb.2:
	ldrh	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB29_5
; %bb.3:
	mov	w9, #56                         ; =0x38
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #44]
	ldur	q1, [x8, #60]
	ldur	q2, [x8, #76]
	ldur	x8, [x8, #92]
	str	x8, [x2, #48]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB29_4:
	ret
LBB29_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_clone    ; -- Begin function nvm_file_flow_clone
	.globl	_nvm_file_flow_clone
	.p2align	2
_nvm_file_flow_clone:                   ; @nvm_file_flow_clone
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	cbz	x19, LBB30_7
; %bb.1:
	cbz	x1, LBB30_7
; %bb.2:
	ldr	x21, [x19]
	ldr	w22, [x21]
	cmn	w22, #1
	b.eq	LBB30_5
; %bb.3:
	mov	x23, x1
	mov	w0, #47152                      ; =0xb830
	bl	_malloc
	cbz	x0, LBB30_6
; %bb.4:
	mov	x20, x0
	mov	x1, x19
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	add	w8, w22, #1
	str	w8, [x21]
	str	x20, [x23]
	b	LBB30_7
LBB30_5:
	mov	w0, #3                          ; =0x3
	b	LBB30_7
LBB30_6:
	mov	w0, #4                          ; =0x4
LBB30_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_refine   ; -- Begin function nvm_file_flow_refine
	.globl	_nvm_file_flow_refine
	.p2align	2
_nvm_file_flow_refine:                  ; @nvm_file_flow_refine
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	cmp	x2, x3
	b.eq	LBB31_11
; %bb.1:
	cbz	x20, LBB31_11
; %bb.2:
	cbz	x2, LBB31_11
; %bb.3:
	cbz	x3, LBB31_11
; %bb.4:
	ldr	x22, [x20]
	ldr	w9, [x20, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w9, w10, x22
	ldrh	w9, [x9, #26]
	cmp	w1, w9
	b.hs	LBB31_11
; %bb.5:
	ldrb	w9, [x20, #40]
	cmp	w9, #1
	b.ne	LBB31_10
; %bb.6:
	mov	w9, #40                         ; =0x28
	umaddl	x9, w1, w9, x20
	mov	w10, #14384                     ; =0x3830
	add	x10, x9, x10
	ldrb	w11, [x10, #16]
	tbz	w11, #0, LBB31_11
; %bb.7:
	ldr	x11, [x10, #8]
	ldrb	w10, [x10, #1]
	lsl	x10, x10, #8
	lsr	x11, x11, #33
	cmp	x11, #1
	ccmp	x10, #0, #0, eq
	b.ne	LBB31_11
; %bb.8:
	ldr	w26, [x22]
	cmn	w26, #3
	b.ls	LBB31_12
; %bb.9:
	mov	w0, #3                          ; =0x3
	b	LBB31_11
LBB31_10:
	mov	w0, #2                          ; =0x2
LBB31_11:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB31_12:
	mov	x21, x1
	mov	x24, x2
	mov	x23, x3
	ldr	w25, [x9, #14416]
	mov	w0, #47152                      ; =0xb830
	bl	_malloc
	cbz	x0, LBB31_15
; %bb.13:
	mov	x19, x0
	mov	x1, x20
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	add	w8, w26, #1
	str	w8, [x22]
	mov	w0, #47152                      ; =0xb830
	bl	_malloc
	cbz	x0, LBB31_16
; %bb.14:
	mov	w27, w21
	mov	x21, x0
	mov	x1, x20
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	add	w8, w26, #2
	str	w8, [x22]
	cmp	w25, #3
	cset	w8, ne
	strb	w8, [x19, #40]
	cmp	w25, #2
	cset	w8, ne
	strb	w8, [x21, #40]
	add	x8, x27, x27, lsl #2
	lsl	x8, x8, #3
	add	x9, x19, x8
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #14416]
	add	x8, x21, x8
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #14416]
	str	x19, [x24]
	str	x21, [x23]
	b	LBB31_11
LBB31_15:
	mov	w0, #4                          ; =0x4
	b	LBB31_11
LBB31_16:
	mov	x0, x19
	bl	_nvm_file_flow_state_free
	mov	w0, #4                          ; =0x4
	b	LBB31_11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_join     ; -- Begin function nvm_file_flow_join
	.globl	_nvm_file_flow_join
	.p2align	2
_nvm_file_flow_join:                    ; @nvm_file_flow_join
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	cbz	x0, LBB32_14
; %bb.1:
	cbz	x1, LBB32_14
; %bb.2:
	cbz	x2, LBB32_14
; %bb.3:
	ldr	x9, [x0]
	ldr	x8, [x1]
	cmp	x9, x8
	b.ne	LBB32_13
; %bb.4:
	ldr	w10, [x0, #8]
	ldr	w8, [x1, #8]
	cmp	w10, w8
	b.ne	LBB32_13
; %bb.5:
	ldr	x8, [x0, #24]
	ldr	x11, [x1, #24]
	cmp	x8, x11
	b.ne	LBB32_13
; %bb.6:
	sub	sp, sp, #144
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldrb	w8, [x1, #40]
	cmp	w8, #1
	b.ne	LBB32_15
; %bb.7:
	ldrb	w8, [x0, #40]
	tbz	w8, #0, LBB32_16
; %bb.8:
	ldrh	w19, [x0, #12]
	ldrh	w8, [x1, #12]
	cmp	w19, w8
	b.ne	LBB32_57
; %bb.9:
	ldrh	w8, [x0, #14]
	ldrh	w11, [x1, #14]
	cmp	w8, w11
	b.ne	LBB32_57
; %bb.10:
	ldr	x11, [x0, #32]
	ldr	x12, [x1, #32]
	cmp	x11, x12
	b.ne	LBB32_57
; %bb.11:
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	ldrh	w9, [x9, #26]
	cbz	x9, LBB32_25
; %bb.12:
	mov	w10, #0                         ; =0x0
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	mov	w13, #14416                     ; =0x3850
	add	x12, x0, x13
	add	x13, x1, x13
	mov	x14, x9
	b	LBB32_19
LBB32_13:
	mov	w8, #2                          ; =0x2
LBB32_14:
	mov	x0, x8
	ret
LBB32_15:
	mov	w9, #0                          ; =0x0
	b	LBB32_17
LBB32_16:
	mov	x19, x2
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	mov	x2, x19
	mov	w9, #1                          ; =0x1
LBB32_17:
	mov	w8, #0                          ; =0x0
	strb	w9, [x2]
	b	LBB32_58
LBB32_18:                               ;   in Loop: Header=BB32_19 Depth=1
	add	x12, x12, #40
	add	x13, x13, #40
	subs	x14, x14, #1
	b.eq	LBB32_26
LBB32_19:                               ; =>This Inner Loop Header: Depth=1
	ldur	x15, [x12, #-32]
	ldur	x16, [x13, #-32]
	eor	x17, x16, x15
	tst	x17, #0xff
	b.ne	LBB32_57
; %bb.20:                               ;   in Loop: Header=BB32_19 Depth=1
	ldur	x15, [x12, #-24]
	ldurb	w16, [x12, #-16]
	ldur	x3, [x13, #-8]
	ldur	x4, [x12, #-8]
	ldurb	w5, [x13, #-16]
	ldur	x6, [x13, #-24]
	and	x17, x17, x11
	cmp	x17, #0
	ccmp	x15, x6, #0, eq
	ccmp	w16, w5, #0, eq
	ccmp	x4, x3, #0, eq
	b.ne	LBB32_57
; %bb.21:                               ;   in Loop: Header=BB32_19 Depth=1
	tbz	w16, #0, LBB32_18
; %bb.22:                               ;   in Loop: Header=BB32_19 Depth=1
	ldr	w16, [x12]
	ldr	w17, [x13]
	cmp	w16, w17
	b.eq	LBB32_18
; %bb.23:                               ;   in Loop: Header=BB32_19 Depth=1
	lsr	x15, x15, #33
	cmp	x15, #1
	b.ne	LBB32_57
; %bb.24:                               ;   in Loop: Header=BB32_19 Depth=1
	cmp	w16, #1
	cset	w15, ne
	orr	w10, w10, w15
	b	LBB32_18
LBB32_25:
	mov	w10, #0                         ; =0x0
LBB32_26:
	mov	w12, #24656                     ; =0x6050
	add	x11, x1, x12
	add	x12, x0, x12
	cbz	w19, LBB32_34
; %bb.27:
	mov	x13, #-256                      ; =0xffffffffffffff00
	movk	x13, #0, lsl #16
	mov	x14, x11
	mov	x15, x19
	mov	x16, x12
	b	LBB32_30
LBB32_28:                               ;   in Loop: Header=BB32_30 Depth=1
	cmp	w3, #1
	cset	w17, ne
	orr	w10, w10, w17
LBB32_29:                               ;   in Loop: Header=BB32_30 Depth=1
	add	x16, x16, #40
	add	x14, x14, #40
	subs	x15, x15, #1
	b.eq	LBB32_34
LBB32_30:                               ; =>This Inner Loop Header: Depth=1
	ldur	x17, [x16, #-32]
	ldur	x3, [x14, #-32]
	eor	x3, x3, x17
	tst	x3, #0xff
	b.ne	LBB32_57
; %bb.31:                               ;   in Loop: Header=BB32_30 Depth=1
	ldur	x17, [x16, #-24]
	ldur	x4, [x14, #-8]
	ldur	x5, [x16, #-8]
	ldurb	w6, [x14, #-16]
	ldur	x7, [x14, #-24]
	ldurb	w20, [x16, #-16]
	and	x3, x3, x13
	cmp	x3, #0
	ccmp	x17, x7, #0, eq
	ccmp	w20, w6, #0, eq
	ccmp	x5, x4, #0, eq
	b.ne	LBB32_57
; %bb.32:                               ;   in Loop: Header=BB32_30 Depth=1
	ldr	w3, [x16]
	ldr	w4, [x14]
	cmp	w3, w4
	b.eq	LBB32_29
; %bb.33:                               ;   in Loop: Header=BB32_30 Depth=1
	lsr	x17, x17, #33
	cmp	x17, #1
	b.eq	LBB32_28
	b	LBB32_57
LBB32_34:
	cbz	w8, LBB32_38
; %bb.35:
	mov	w14, #45104                     ; =0xb030
	add	x13, x1, x14
	add	x14, x0, x14
LBB32_36:                               ; =>This Inner Loop Header: Depth=1
	ldr	x15, [x14], #8
	ldr	x16, [x13], #8
	cmp	x15, x16
	b.ne	LBB32_57
; %bb.37:                               ;   in Loop: Header=BB32_36 Depth=1
	subs	x8, x8, #1
	b.ne	LBB32_36
LBB32_38:
	mov	x13, #0                         ; =0x0
	mov	w8, #34864                      ; =0x8830
	add	x14, x0, x8
	mov	w8, #34866                      ; =0x8832
	add	x15, x1, x8
	mov	w17, #34880                     ; =0x8840
	add	x16, x0, x17
	add	x17, x1, x17
	add	x3, x0, x8
	mov	w8, #34896                      ; =0x8850
	add	x4, x1, x8
	mov	w5, #256                        ; =0x100
	b	LBB32_40
LBB32_39:                               ;   in Loop: Header=BB32_40 Depth=1
	add	x13, x13, #40
	subs	x5, x5, #1
	b.eq	LBB32_48
LBB32_40:                               ; =>This Inner Loop Header: Depth=1
	add	x6, x14, x13
	add	x7, x4, x13
	ldrb	w8, [x6]
	ldurb	w20, [x7, #-32]
	cmp	w8, w20
	b.ne	LBB32_57
; %bb.41:                               ;   in Loop: Header=BB32_40 Depth=1
	tbz	w8, #0, LBB32_39
; %bb.42:                               ;   in Loop: Header=BB32_40 Depth=1
	ldrb	w20, [x6, #1]
	ldurb	w21, [x7, #-31]
	mov	w8, #2                          ; =0x2
	cmp	w20, w21
	b.ne	LBB32_58
; %bb.43:                               ;   in Loop: Header=BB32_40 Depth=1
	ldrh	w20, [x3, x13]
	ldrh	w21, [x15, x13]
	cmp	w20, w21
	b.ne	LBB32_58
; %bb.44:                               ;   in Loop: Header=BB32_40 Depth=1
	add	x20, x16, x13
	ldur	x22, [x20, #-8]
	add	x21, x17, x13
	ldur	x23, [x21, #-8]
	cmp	x22, x23
	b.ne	LBB32_58
; %bb.45:                               ;   in Loop: Header=BB32_40 Depth=1
	ldr	x22, [x20]
	ldr	x23, [x21]
	cmp	x22, x23
	b.ne	LBB32_58
; %bb.46:                               ;   in Loop: Header=BB32_40 Depth=1
	ldr	x20, [x20, #8]
	ldr	x21, [x21, #8]
	cmp	x20, x21
	b.ne	LBB32_58
; %bb.47:                               ;   in Loop: Header=BB32_40 Depth=1
	ldrb	w6, [x6, #32]
	ldrb	w7, [x7]
	cmp	w6, w7
	b.eq	LBB32_39
	b	LBB32_58
LBB32_48:
	stp	x11, x12, [sp, #8]              ; 16-byte Folded Spill
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	str	w10, [sp, #36]                  ; 4-byte Folded Spill
	stp	x2, x1, [sp, #40]               ; 16-byte Folded Spill
	ldrh	w21, [x1, #16]
	ldrh	w22, [x0, #16]
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	cbz	w21, LBB32_59
; %bb.49:
	mov	x23, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	add	x24, x0, #44
	add	x25, x1, #44
	mov	w26, #56                        ; =0x38
	b	LBB32_52
LBB32_50:                               ;   in Loop: Header=BB32_52 Depth=1
	add	w20, w20, #1
LBB32_51:                               ;   in Loop: Header=BB32_52 Depth=1
	add	x23, x23, #1
	cmp	x23, x21
	b.eq	LBB32_60
LBB32_52:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_54 Depth 2
	cbz	w22, LBB32_50
; %bb.53:                               ;   in Loop: Header=BB32_52 Depth=1
	madd	x1, x23, x26, x25
	ldr	w8, [x1, #4]
	mov	x9, x22
	mov	x0, x24
LBB32_54:                               ;   Parent Loop BB32_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w10, [x0, #4]
	cmp	w10, w8
	b.eq	LBB32_56
; %bb.55:                               ;   in Loop: Header=BB32_54 Depth=2
	add	x0, x0, #56
	subs	x9, x9, #1
	b.ne	LBB32_54
	b	LBB32_50
LBB32_56:                               ;   in Loop: Header=BB32_52 Depth=1
	bl	_obligation_same
	cbnz	w0, LBB32_51
LBB32_57:
	mov	w8, #2                          ; =0x2
LBB32_58:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #144
	mov	x0, x8
	ret
LBB32_59:
	mov	w20, #0                         ; =0x0
LBB32_60:
	add	w8, w22, w20, uxth
	cmp	w8, #256
	b.ls	LBB32_62
; %bb.61:
	mov	w8, #3                          ; =0x3
	b	LBB32_58
LBB32_62:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	cbz	w8, LBB32_68
; %bb.63:
	mov	w11, #14416                     ; =0x3850
	ldp	x9, x10, [sp, #48]              ; 16-byte Folded Reload
	add	x9, x9, x11
	add	x10, x10, x11
	mov	w11, #1                         ; =0x1
	b	LBB32_65
LBB32_64:                               ;   in Loop: Header=BB32_65 Depth=1
	add	x10, x10, #40
	add	x9, x9, #40
	subs	x8, x8, #1
	b.eq	LBB32_68
LBB32_65:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-16]
	cmp	w12, #1
	b.ne	LBB32_64
; %bb.66:                               ;   in Loop: Header=BB32_65 Depth=1
	ldr	w12, [x10]
	ldr	w13, [x9]
	cmp	w12, w13
	b.eq	LBB32_64
; %bb.67:                               ;   in Loop: Header=BB32_65 Depth=1
	str	w11, [x10]
	b	LBB32_64
LBB32_68:
	cbz	w19, LBB32_87
; %bb.69:
	cmp	w19, #20
	b.lo	LBB32_81
; %bb.70:
	mov	w8, #24656                      ; =0x6050
	ldp	x11, x9, [sp, #48]              ; 16-byte Folded Reload
	add	x10, x9, x8
	add	x8, x11, x8
	mov	w12, #40                        ; =0x28
	mov	w13, #24620                     ; =0x602c
	umaddl	x12, w19, w12, x13
	add	x9, x9, x12
	add	x11, x11, x12
	cmp	x10, x11
	ccmp	x8, x9, #2, lo
	b.lo	LBB32_81
; %bb.71:
	and	x8, x19, #0xfffc
	ldp	x9, x10, [sp, #8]               ; 16-byte Folded Reload
	add	x9, x9, #80
	add	x10, x10, #80
	mov	w11, #1                         ; =0x1
	mov	x12, x8
	b	LBB32_73
LBB32_72:                               ;   in Loop: Header=BB32_73 Depth=1
	add	x9, x9, #160
	add	x10, x10, #160
	subs	x12, x12, #4
	b.eq	LBB32_86
LBB32_73:                               ; =>This Inner Loop Header: Depth=1
	sub	x13, x10, #40
	ldur	s0, [x10, #-80]
	ld1.s	{ v0 }[1], [x13]
	ld1.s	{ v0 }[2], [x10]
	add	x13, x10, #40
	ld1.s	{ v0 }[3], [x13]
	sub	x13, x9, #40
	add	x14, x9, #40
	ldur	s1, [x9, #-80]
	ld1.s	{ v1 }[1], [x13]
	ld1.s	{ v1 }[2], [x9]
	ld1.s	{ v1 }[3], [x14]
	cmeq.4s	v0, v0, v1
	mvn.16b	v0, v0
	xtn.4h	v0, v0
	umov.h	w13, v0[0]
	tbz	w13, #0, LBB32_77
; %bb.74:                               ;   in Loop: Header=BB32_73 Depth=1
	stur	w11, [x10, #-80]
	umov.h	w13, v0[1]
	tbnz	w13, #0, LBB32_78
LBB32_75:                               ;   in Loop: Header=BB32_73 Depth=1
	umov.h	w13, v0[2]
	tbz	w13, #0, LBB32_79
LBB32_76:                               ;   in Loop: Header=BB32_73 Depth=1
	str	w11, [x10]
	umov.h	w13, v0[3]
	tbz	w13, #0, LBB32_72
	b	LBB32_80
LBB32_77:                               ;   in Loop: Header=BB32_73 Depth=1
	umov.h	w13, v0[1]
	tbz	w13, #0, LBB32_75
LBB32_78:                               ;   in Loop: Header=BB32_73 Depth=1
	stur	w11, [x10, #-40]
	umov.h	w13, v0[2]
	tbnz	w13, #0, LBB32_76
LBB32_79:                               ;   in Loop: Header=BB32_73 Depth=1
	umov.h	w13, v0[3]
	tbz	w13, #0, LBB32_72
LBB32_80:                               ;   in Loop: Header=BB32_73 Depth=1
	str	w11, [x10, #40]
	b	LBB32_72
LBB32_81:
	mov	x8, #0                          ; =0x0
LBB32_82:
	mov	w9, #40                         ; =0x28
	mov	w10, #24656                     ; =0x6050
	umaddl	x11, w8, w9, x10
	ldp	x9, x10, [sp, #48]              ; 16-byte Folded Reload
	add	x9, x9, x11
	add	x10, x10, x11
	sub	x8, x19, x8
	mov	w11, #1                         ; =0x1
	b	LBB32_84
LBB32_83:                               ;   in Loop: Header=BB32_84 Depth=1
	add	x10, x10, #40
	subs	x8, x8, #1
	b.eq	LBB32_87
LBB32_84:                               ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x10]
	ldr	w13, [x9], #40
	cmp	w12, w13
	b.eq	LBB32_83
; %bb.85:                               ;   in Loop: Header=BB32_84 Depth=1
	str	w11, [x10]
	b	LBB32_83
LBB32_86:
	cmp	x8, x19
	b.ne	LBB32_82
LBB32_87:
	ldp	x8, x9, [sp, #48]               ; 16-byte Folded Reload
	cbz	w21, LBB32_96
; %bb.88:
	mov	x10, #0                         ; =0x0
	add	x11, x9, #48
	add	x12, x8, #48
	add	x13, x9, #44
	add	x14, x8, #44
	mov	w15, #56                        ; =0x38
                                        ; kill: def $w22 killed $w22 killed $x22 def $x22
	b	LBB32_92
LBB32_89:                               ;   in Loop: Header=BB32_92 Depth=1
	mov	x16, #0                         ; =0x0
LBB32_90:                               ;   in Loop: Header=BB32_92 Depth=1
	add	w22, w22, #1
	strh	w22, [x9, #16]
	umaddl	x16, w16, w15, x13
	madd	x17, x10, x15, x14
	ldp	q0, q1, [x17]
	ldr	q2, [x17, #32]
	ldr	x17, [x17, #48]
	str	x17, [x16, #48]
	stp	q1, q2, [x16, #16]
	str	q0, [x16]
	ldrh	w21, [x8, #16]
LBB32_91:                               ;   in Loop: Header=BB32_92 Depth=1
	add	x10, x10, #1
	cmp	x10, w21, uxtw
	b.hs	LBB32_96
LBB32_92:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_94 Depth 2
	tst	w22, #0xffff
	b.eq	LBB32_89
; %bb.93:                               ;   in Loop: Header=BB32_92 Depth=1
	mul	x16, x10, x15
	ldr	w17, [x12, x16]
	and	x16, x22, #0xffff
	mov	x0, x16
	mov	x1, x11
LBB32_94:                               ;   Parent Loop BB32_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w2, [x1], #56
	cmp	w2, w17
	b.eq	LBB32_91
; %bb.95:                               ;   in Loop: Header=BB32_94 Depth=2
	subs	x0, x0, #1
	b.ne	LBB32_94
	b	LBB32_90
LBB32_96:
	tst	w20, #0xffff
	cset	w9, ne
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	orr	w8, w8, w9
	and	w9, w8, #0x1
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	b	LBB32_17
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function obligation_same
_obligation_same:                       ; @obligation_same
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	ldr	w9, [x1]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.1:
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.2:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.3:
	ldr	w8, [x0, #12]
	ldr	w9, [x1, #12]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.4:
	ldr	w8, [x0, #16]
	ldr	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.5:
	ldr	w8, [x0, #20]
	ldr	w9, [x1, #20]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.6:
	ldrh	w8, [x0, #24]
	ldrh	w9, [x1, #24]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.7:
	ldrh	w8, [x0, #26]
	ldrh	w9, [x1, #26]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.8:
	ldrh	w8, [x0, #28]
	ldrh	w9, [x1, #28]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.9:
	ldrb	w8, [x0, #30]
	ldrb	w9, [x1, #30]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.10:
	ldr	x8, [x0, #32]
	ldr	x9, [x1, #32]
	eor	x9, x9, x8
	tst	x9, #0xff
	b.eq	LBB33_12
LBB33_11:
	mov	w0, #0                          ; =0x0
	ret
LBB33_12:
	mov	w8, #0                          ; =0x0
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	tst	x9, x10
	b.ne	LBB33_16
; %bb.13:
	ldr	x9, [x1, #40]
	ldr	x10, [x0, #40]
	cmp	x10, x9
	b.ne	LBB33_16
; %bb.14:
	ldr	w8, [x0, #48]
	ldr	w9, [x1, #48]
	cmp	w8, w9
	b.ne	LBB33_11
; %bb.15:
	ldr	w8, [x0, #52]
	ldr	w9, [x1, #52]
	cmp	w8, w9
	cset	w8, eq
LBB33_16:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_construct ; -- Begin function nvm_file_flow_construct
	.globl	_nvm_file_flow_construct
	.p2align	2
_nvm_file_flow_construct:               ; @nvm_file_flow_construct
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB34_12
; %bb.1:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB34_8
; %bb.2:
	mov	x22, x2
	mov	x20, x0
	ldr	x8, [x0]
	ldr	x0, [x8, #16]
	add	x2, sp, #24
	mov	x19, x1
	bl	_nvm_file_nominal_type
	tbz	w0, #0, LBB34_12
; %bb.3:
	ldrb	w8, [sp, #36]
	cmp	w8, #0
	mov	w8, #10                         ; =0xa
	mov	w9, #8                          ; =0x8
	csel	x23, x9, x8, eq
	ldr	w21, [sp, #40]
	sub	w8, w21, #1
	cmp	w8, #2
	b.lo	LBB34_12
; %bb.4:
	ldp	w25, w24, [sp, #24]
	mov	w0, w19
	bl	_nl_file_catalog_type
	cbz	x0, LBB34_12
; %bb.5:
	cmp	w21, #4
	b.ne	LBB34_9
; %bb.6:
	cbnz	w22, LBB34_12
; %bb.7:
	mov	x8, x20
	mov	x9, x22
	ldr	x19, [x0, #32]
	b	LBB34_11
LBB34_8:
	mov	w19, #2                         ; =0x2
	b	LBB34_13
LBB34_9:
	ldr	x8, [x0, #32]
	mov	w19, #1                         ; =0x1
	cmp	x8, w22, uxtw
	b.ls	LBB34_13
; %bb.10:
	mov	x9, x22
	mov	x8, x20
LBB34_11:
	ldrh	w10, [x8, #12]
	subs	x17, x10, x19
	b.hs	LBB34_14
LBB34_12:
	mov	w19, #1                         ; =0x1
LBB34_13:
	mov	x0, x19
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB34_14:
	cmp	x17, #255
	b.ls	LBB34_16
; %bb.15:
	mov	w19, #3                         ; =0x3
	b	LBB34_13
LBB34_16:
	cbz	x19, LBB34_27
; %bb.17:
	stp	x17, x24, [sp]                  ; 16-byte Folded Spill
	mov	x27, #0                         ; =0x0
	mov	w8, w9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w8, #40                         ; =0x28
	umull	x9, w10, w8
	msub	x8, x19, x8, x9
	mov	w9, #24640                      ; =0x6040
	add	x28, x8, x9
	mov	w9, #24624                      ; =0x6030
	add	x26, x8, x9
LBB34_18:                               ; =>This Inner Loop Header: Depth=1
	mov	x24, x0
	ldr	x8, [x0, #24]
	cmp	w21, #4
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	csel	x9, x27, x9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	add	x2, sp, #24
	mov	x0, x20
	bl	_member_type
	cbz	w0, LBB34_12
; %bb.19:                               ;   in Loop: Header=BB34_18 Depth=1
	ldp	x10, x9, [sp, #24]
	and	x11, x10, #0xff00
	lsr	x12, x9, #32
	sub	x12, x12, #1
	cmp	x11, #0
	ccmp	x12, #2, #2, eq
	b.lo	LBB34_12
; %bb.20:                               ;   in Loop: Header=BB34_18 Depth=1
	mov	x8, x20
	ldrb	w11, [x20, x28]
	tbz	w11, #0, LBB34_12
; %bb.21:                               ;   in Loop: Header=BB34_18 Depth=1
	add	x11, x8, x26
	ldr	x12, [x11, #24]
	cbnz	x12, LBB34_12
; %bb.22:                               ;   in Loop: Header=BB34_18 Depth=1
	ldr	x11, [x11]
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB34_12
; %bb.23:                               ;   in Loop: Header=BB34_18 Depth=1
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB34_12
; %bb.24:                               ;   in Loop: Header=BB34_18 Depth=1
	add	x10, x8, x26
	ldr	x10, [x10, #8]
	cmp	x9, x10
	b.ne	LBB34_12
; %bb.25:                               ;   in Loop: Header=BB34_18 Depth=1
	add	x27, x27, #1
	add	x28, x28, #40
	add	x26, x26, #40
	cmp	x19, x27
	mov	x0, x24
	b.ne	LBB34_18
; %bb.26:
	ldrh	w10, [x8, #12]
	mov	x12, x10
	mov	x9, x22
	ldp	x17, x24, [sp]                  ; 16-byte Folded Reload
	b	LBB34_28
LBB34_27:
	mov	x12, x10
LBB34_28:
	orr	x13, x23, x25, lsl #32
	orr	x11, x24, x21, lsl #32
	cmp	x17, x10
	b.hs	LBB34_31
; %bb.29:
	mov	w10, #24624                     ; =0x6030
	add	x14, x8, x10
	mov	w15, #40                        ; =0x28
	movi.2d	v0, #0000000000000000
LBB34_30:                               ; =>This Inner Loop Header: Depth=1
	sub	w12, w12, #1
	and	x10, x12, #0xffff
	umaddl	x16, w10, w15, x14
	str	xzr, [x16, #32]
	stp	q0, q0, [x16]
	cmp	x17, x10
	b.lo	LBB34_30
LBB34_31:
	mov	w19, #0                         ; =0x0
	and	x14, x21, #0xfffffffe
	cmp	x14, #2
	cset	w14, eq
	cmp	w9, #0
	mov	w9, #40                         ; =0x28
	umaddl	x9, w10, w9, x8
	add	w10, w12, #1
	strh	w10, [x8, #12]
	str	x13, [x9, #24624]
	mov	w8, #2                          ; =0x2
	mov	w10, #24624                     ; =0x6030
	add	x10, x9, x10
	str	x11, [x9, #24632]
	mov	w11, #1                         ; =0x1
	strb	w11, [x10, #16]
	cinc	w8, w8, ne
	str	xzr, [x9, #24648]
	stur	xzr, [x10, #17]
	cmp	w21, #4
	csel	w8, w14, w8, eq
	stp	w8, wzr, [x10, #32]
	b	LBB34_13
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function member_type
lCPI35_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
lCPI35_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI35_2:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI35_3:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_member_type:                           ; @member_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x1, LBB35_21
; %bb.1:
	mov	x21, x1
	mov	x20, x0
Lloh2:
	adrp	x1, l_.str@PAGE
Lloh3:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB35_22
; %bb.2:
Lloh4:
	adrp	x1, l_.str.1@PAGE
Lloh5:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB35_23
; %bb.3:
Lloh6:
	adrp	x1, l_.str.2@PAGE
Lloh7:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB35_24
; %bb.4:
	mov	x0, #0                          ; =0x0
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_6
; %bb.5:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_27
LBB35_6:
	mov	w0, #1                          ; =0x1
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_8
; %bb.7:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_28
LBB35_8:
	mov	w0, #2                          ; =0x2
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_10
; %bb.9:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_29
LBB35_10:
	mov	w0, #3                          ; =0x3
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_12
; %bb.11:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_30
LBB35_12:
	mov	w0, #4                          ; =0x4
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_14
; %bb.13:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_31
LBB35_14:
	mov	w0, #5                          ; =0x5
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_16
; %bb.15:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_32
LBB35_16:
	mov	w0, #6                          ; =0x6
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_18
; %bb.17:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_33
LBB35_18:
	mov	w0, #7                          ; =0x7
	bl	_nl_file_catalog_type
	cbz	x0, LBB35_20
; %bb.19:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB35_34
LBB35_20:
	mov	w8, #0                          ; =0x0
                                        ; implicit-def: $w0
	b	LBB35_38
LBB35_21:
Lloh8:
	adrp	x8, lCPI35_3@PAGE
Lloh9:
	ldr	q0, [x8, lCPI35_3@PAGEOFF]
	b	LBB35_25
LBB35_22:
Lloh10:
	adrp	x8, lCPI35_2@PAGE
Lloh11:
	ldr	q0, [x8, lCPI35_2@PAGEOFF]
	b	LBB35_25
LBB35_23:
Lloh12:
	adrp	x8, lCPI35_1@PAGE
Lloh13:
	ldr	q0, [x8, lCPI35_1@PAGEOFF]
	b	LBB35_25
LBB35_24:
Lloh14:
	adrp	x8, lCPI35_0@PAGE
Lloh15:
	ldr	q0, [x8, lCPI35_0@PAGEOFF]
LBB35_25:
	str	q0, [x19]
	mov	w0, #1                          ; =0x1
LBB35_26:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB35_27:
	mov	w1, #0                          ; =0x0
	b	LBB35_35
LBB35_28:
	mov	w1, #1                          ; =0x1
	b	LBB35_35
LBB35_29:
	mov	w1, #2                          ; =0x2
	b	LBB35_35
LBB35_30:
	mov	w1, #3                          ; =0x3
	b	LBB35_35
LBB35_31:
	mov	w1, #4                          ; =0x4
	b	LBB35_35
LBB35_32:
	mov	w1, #5                          ; =0x5
	b	LBB35_35
LBB35_33:
	mov	w1, #6                          ; =0x6
	b	LBB35_35
LBB35_34:
	mov	w1, #7                          ; =0x7
LBB35_35:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	add	x2, sp, #8
	bl	_nvm_file_nominal_type
	cbz	w0, LBB35_37
; %bb.36:
	ldrb	w8, [sp, #20]
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	cmp	w8, #0
	csel	w8, w10, w9, eq
	ldr	w9, [sp, #24]
	strb	w8, [x19]
	strb	wzr, [x19, #1]
	strh	wzr, [x19, #2]
	ldr	d0, [sp, #8]
	stur	d0, [x19, #4]
	str	w9, [x19, #12]
LBB35_37:
	mov	w8, #1                          ; =0x1
LBB35_38:
	and	w0, w8, w0
	b	LBB35_26
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_field    ; -- Begin function nvm_file_flow_field
	.globl	_nvm_file_flow_field
	.p2align	2
_nvm_file_flow_field:                   ; @nvm_file_flow_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB36_10
; %bb.1:
	ldrh	w8, [x0, #12]
	cbz	x8, LBB36_10
; %bb.2:
	ldrb	w9, [x0, #40]
	cmp	w9, #1
	b.ne	LBB36_11
; %bb.3:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	w9, #24624                      ; =0x6030
	add	x20, x0, x9
	mov	w9, #40                         ; =0x28
	umaddl	x8, w8, w9, x20
	ldur	w9, [x8, #-28]
	ldur	x10, [x8, #-16]
	cmp	x10, #0
	ccmp	w9, #4, #0, eq
	b.ne	LBB36_12
; %bb.4:
	mov	x21, x1
	mov	x19, x0
	sub	x8, x8, #40
	ldr	w0, [x8, #8]
	bl	_nl_file_catalog_type
	cbz	x0, LBB36_12
; %bb.5:
	mov	w8, w21
	ldr	x9, [x0, #32]
	cmp	x9, x8
	b.ls	LBB36_12
; %bb.6:
	ldr	x9, [x0, #24]
	add	x8, x9, x8, lsl #5
	ldr	x1, [x8, #16]
	mov	x2, sp
	mov	x0, x19
	bl	_member_type
	cbz	w0, LBB36_12
; %bb.7:
	ldrb	w8, [sp]
	mov	w9, #250                        ; =0xfa
	mov	w0, #1                          ; =0x1
	tst	w8, w9
	b.ne	LBB36_13
; %bb.8:
	ldr	w8, [sp, #4]
	cmn	w8, #1
	b.ne	LBB36_13
; %bb.9:
	mov	w0, #0                          ; =0x0
	ldrh	w8, [x19, #12]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w8, w9, x20
	ldr	x9, [sp, #8]
	ldr	q0, [sp]
	lsr	x9, x9, #33
	cmp	x9, #1
	mov	w9, #1                          ; =0x1
	sturb	w9, [x8, #-24]
	cset	w9, eq
	stur	q0, [x8, #-40]
	stur	xzr, [x8, #-23]
	stur	xzr, [x8, #-16]
	stp	w9, wzr, [x8, #-8]
	b	LBB36_13
LBB36_10:
	mov	w0, #1                          ; =0x1
	ret
LBB36_11:
	mov	w0, #2                          ; =0x2
	ret
LBB36_12:
	mov	w0, #1                          ; =0x1
LBB36_13:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_take_result ; -- Begin function nvm_file_flow_take_result
	.globl	_nvm_file_flow_take_result
	.p2align	2
_nvm_file_flow_take_result:             ; @nvm_file_flow_take_result
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB37_8
; %bb.1:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	ldr	x8, [x0]
	ldr	w9, [x0, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w8, [x8, #26]
	cmp	w1, w8
	b.hs	LBB37_18
; %bb.2:
	ldrb	w8, [x19, #40]
	cmp	w8, #1
	b.ne	LBB37_9
; %bb.3:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x19
	mov	w9, #14384                      ; =0x3830
	add	x20, x8, x9
	mov	x21, x20
	ldrb	w9, [x21, #16]!
	tbz	w9, #0, LBB37_18
; %bb.4:
	sub	w9, w2, #4
	mov	w0, #1                          ; =0x1
	cmn	w9, #2
	b.lo	LBB37_19
; %bb.5:
	ldr	x22, [x8, #14392]
	ldr	w9, [x20, #32]
	and	x10, x22, #0xfffffffe00000000
	mov	x11, #8589934592                ; =0x200000000
	cmp	x10, x11
	ccmp	w9, w2, #0, eq
	b.ne	LBB37_19
; %bb.6:
	ldrh	w9, [x19, #12]
	cmp	w9, #256
	b.ne	LBB37_10
; %bb.7:
	mov	w0, #3                          ; =0x3
	b	LBB37_19
LBB37_8:
	mov	w0, #1                          ; =0x1
	ret
LBB37_9:
	mov	w0, #2                          ; =0x2
	b	LBB37_19
LBB37_10:
	mov	x24, x2
	ldr	x23, [x8, #14408]
	mov	w0, w22
	bl	_nl_file_catalog_type
	cbz	x0, LBB37_18
; %bb.11:
	ldr	x8, [x0, #32]
	cmp	x8, #2
	b.ne	LBB37_18
; %bb.12:
	ldr	x8, [x0, #24]
	cmp	w24, #3
	cset	w9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	mov	x2, sp
	mov	x0, x19
	bl	_member_type
	cbz	w0, LBB37_18
; %bb.13:
	mov	x9, #0                          ; =0x0
	ldp	x10, x8, [sp]
	and	x11, x10, #0xff00
	cbnz	x11, LBB37_17
; %bb.14:
	lsr	x11, x8, #32
	sub	x11, x11, #1
	cmp	x11, #1
	b.hi	LBB37_17
; %bb.15:
	mov	w0, #1                          ; =0x1
	cbz	x23, LBB37_19
; %bb.16:
	and	x11, x22, #0x300000000
	mov	x12, #8589934592                ; =0x200000000
	mov	x9, x23
	cmp	x11, x12
	b.ne	LBB37_19
LBB37_17:
	mov	w0, #0                          ; =0x0
	mov	w11, #40                        ; =0x28
	ldrh	w12, [x19, #12]
	umaddl	x11, w12, w11, x19
	add	w12, w12, #1
	strh	w12, [x19, #12]
	lsr	x12, x8, #33
	cmp	x12, #1
	mov	w12, #24624                     ; =0x6030
	add	x12, x11, x12
	str	x10, [x11, #24624]
	cset	w10, eq
	str	x8, [x11, #24632]
	mov	w8, #1                          ; =0x1
	strb	w8, [x12, #16]
	stur	wzr, [x12, #17]
	str	wzr, [x12, #20]
	str	x9, [x11, #24648]
	stp	w10, wzr, [x12, #32]
	ldr	x8, [x20, #8]
	lsr	x8, x8, #33
	cmp	x8, #1
	cset	w8, eq
	stp	xzr, xzr, [x21]
	stp	w8, wzr, [x20, #32]
	b	LBB37_19
LBB37_18:
	mov	w0, #1                          ; =0x1
LBB37_19:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_service  ; -- Begin function nvm_file_flow_service
	.globl	_nvm_file_flow_service
	.p2align	2
_nvm_file_flow_service:                 ; @nvm_file_flow_service
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x28, x27, [sp, #224]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #240]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #256]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh16:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh17:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh18:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB38_25
; %bb.1:
	mov	x20, x0
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB38_7
; %bb.2:
	mov	x19, x2
	mov	x21, x3
	mov	x23, x1
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	add	x2, sp, #112
	mov	w1, #0                          ; =0x0
	bl	_nvm_file_nominal_import
	ldr	w8, [sp, #112]
	cmp	w0, #0
	ccmp	w8, w19, #0, ne
	b.eq	LBB38_8
; %bb.3:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	mov	w22, #1                         ; =0x1
	add	x2, sp, #112
	mov	w1, #1                          ; =0x1
	bl	_nvm_file_nominal_import
	ldr	w8, [sp, #112]
	cmp	w0, #0
	ccmp	w8, w19, #0, ne
	b.eq	LBB38_9
; %bb.4:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	mov	w22, #2                         ; =0x2
	add	x2, sp, #112
	mov	w1, #2                          ; =0x2
	bl	_nvm_file_nominal_import
	ldr	w8, [sp, #112]
	cmp	w0, #0
	ccmp	w8, w19, #0, ne
	b.eq	LBB38_9
; %bb.5:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	mov	w22, #3                         ; =0x3
	add	x2, sp, #112
	mov	w1, #3                          ; =0x3
	bl	_nvm_file_nominal_import
	ldr	w8, [sp, #112]
	cmp	w0, #0
	ccmp	w8, w19, #0, ne
	b.eq	LBB38_9
; %bb.6:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	mov	w22, #4                         ; =0x4
	add	x2, sp, #112
	mov	w1, #4                          ; =0x4
	bl	_nvm_file_nominal_import
	ldr	w8, [sp, #112]
	cmp	w8, w19
	cset	w8, eq
	tst	w0, w8
	cinc	x22, x22, eq
	b	LBB38_9
LBB38_7:
	mov	w0, #2                          ; =0x2
	b	LBB38_26
LBB38_8:
	mov	x22, #0                         ; =0x0
LBB38_9:
	mov	x0, x22
	bl	_nl_file_catalog_method
	cbz	x0, LBB38_25
; %bb.10:
	ldr	x8, [x0, #56]
	cbz	x8, LBB38_25
; %bb.11:
	mov	x22, x0
	ldr	x9, [x0, #48]
	mov	w10, #48                        ; =0x30
	madd	x8, x8, x10, x9
	ldur	x1, [x8, #-32]
	sub	x2, x29, #128
	mov	x0, x20
	bl	_member_type
	cbz	w0, LBB38_25
; %bb.12:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	add	x2, sp, #112
	mov	w1, #0                          ; =0x0
	bl	_nvm_file_nominal_type
	tbz	w0, #0, LBB38_25
; %bb.13:
	ldrb	w8, [sp, #124]
	cmp	w8, #0
	mov	w8, #10                         ; =0xa
	mov	w9, #8                          ; =0x8
	csel	x9, x9, x8, eq
	ldp	w10, w15, [sp, #112]
	ldr	w11, [sp, #128]
	mov	x8, x22
	ldr	x27, [x22, #56]
	ldur	q0, [x29, #-128]
	stur	q0, [x29, #-112]
	ldp	w24, w26, [x22, #36]
	ldr	w12, [x22, #64]
	cmp	w12, #2
	csel	w13, w12, wzr, eq
	cmp	w12, #1
	csinc	w28, w13, wzr, ne
	ldr	w12, [x22, #80]
	cmp	w12, #2
	csel	w13, w12, wzr, eq
	cmp	w12, #1
	csinc	w13, w13, wzr, ne
	sub	x14, x27, #1
	ldr	w25, [x22, #44]
	sub	w12, w25, #3
	cmn	w12, #2
	b.lo	LBB38_15
; %bb.14:
	cbz	x14, LBB38_25
LBB38_15:
	lsl	x17, x11, #32
	orr	x0, x9, x10, lsl #32
	cmp	w25, #1
	b.ne	LBB38_22
; %bb.16:
	stp	w28, w13, [sp, #80]             ; 8-byte Folded Spill
	mov	x28, x0
	str	x17, [sp, #88]                  ; 8-byte Folded Spill
	str	w15, [sp, #96]                  ; 4-byte Folded Spill
	str	x14, [sp, #104]                 ; 8-byte Folded Spill
	add	x2, sp, #112
	mov	x0, x20
	mov	x1, x21
	bl	_live_reference
	cbz	w0, LBB38_25
; %bb.17:
	orr	x28, x28, #0x200
	ldr	x8, [sp, #112]
	eor	x8, x8, x28
	tst	x8, #0xff
	b.ne	LBB38_25
; %bb.18:
	mov	x9, #-256                       ; =0xffffffffffffff00
	movk	x9, #0, lsl #16
	tst	x8, x9
	b.ne	LBB38_25
; %bb.19:
	ldr	x8, [sp, #120]
	ldr	w9, [sp, #96]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB38_25
; %bb.20:
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	eor	x8, x8, x9
	mov	w0, #1                          ; =0x1
	lsr	x8, x8, #32
	cbnz	x8, LBB38_26
; %bb.21:
	str	w26, [sp, #64]                  ; 4-byte Folded Spill
	mov	w11, #415                       ; =0x19f
	mov	w10, #1                         ; =0x1
	mov	x8, x22
	ldr	x14, [sp, #104]                 ; 8-byte Folded Reload
	ldr	w15, [sp, #96]                  ; 4-byte Folded Reload
	ldr	x17, [sp, #88]                  ; 8-byte Folded Reload
	mov	x0, x28
	ldp	w28, w13, [sp, #80]             ; 8-byte Folded Reload
	b	LBB38_24
LBB38_22:
	mov	w9, #65535                      ; =0xffff
	cmp	w21, w9
	b.ne	LBB38_25
; %bb.23:
	str	w26, [sp, #64]                  ; 4-byte Folded Spill
	mov	w10, #0                         ; =0x0
	mov	w11, #399                       ; =0x18f
LBB38_24:
	cmp	w25, #1
	cset	w16, eq
	ldrh	w26, [x20, #12]
	sub	x12, x14, x16
	cmp	x12, x26
	b.ls	LBB38_28
LBB38_25:
	mov	w0, #1                          ; =0x1
LBB38_26:
	ldur	x8, [x29, #-96]
Lloh19:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh20:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh21:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB38_61
; %bb.27:
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #272]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #256]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #240]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
LBB38_28:
	cmp	x14, x16
	b.ls	LBB38_45
; %bb.29:
	str	x17, [sp, #88]                  ; 8-byte Folded Spill
	str	w15, [sp, #96]                  ; 4-byte Folded Spill
	stp	x12, x16, [sp, #8]              ; 16-byte Folded Spill
	str	x14, [sp, #104]                 ; 8-byte Folded Spill
	str	w11, [sp, #68]                  ; 4-byte Folded Spill
	str	w10, [sp, #4]                   ; 4-byte Folded Spill
	stp	w28, w13, [sp, #80]             ; 8-byte Folded Spill
	str	w24, [sp, #28]                  ; 4-byte Folded Spill
	str	wzr, [sp, #44]                  ; 4-byte Folded Spill
	mov	w9, #24624                      ; =0x6030
	add	x9, x20, x9
	stp	x0, x9, [sp, #48]               ; 16-byte Folded Spill
	ldr	x8, [x8, #48]
	mov	w9, #34872                      ; =0x8838
	add	x9, x20, x9
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	mov	w12, #48                        ; =0x30
LBB38_30:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_39 Depth 2
	ldrh	w9, [x20, #12]
	sub	x10, x16, x27
	add	x9, x10, x9
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	mov	w11, #40                        ; =0x28
	madd	x9, x9, x11, x10
	ldp	x21, x24, [x9, #40]
	ldr	x26, [x9, #64]
	str	x16, [sp, #72]                  ; 8-byte Folded Spill
	madd	x8, x16, x12, x8
	ldr	x1, [x8, #16]
	ldrb	w28, [x9, #56]
	add	x2, sp, #112
	mov	x0, x20
	bl	_member_type
	cbz	w0, LBB38_25
; %bb.31:                               ;   in Loop: Header=BB38_30 Depth=1
	tbz	w28, #0, LBB38_25
; %bb.32:                               ;   in Loop: Header=BB38_30 Depth=1
	ldr	x9, [sp, #112]
	eor	x10, x9, x21
	tst	x10, #0xff
	b.ne	LBB38_25
; %bb.33:                               ;   in Loop: Header=BB38_30 Depth=1
	ldr	x11, [sp, #120]
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	and	x10, x10, x12
	cmp	x10, #0
	ccmp	x11, x24, #0, eq
	b.ne	LBB38_25
; %bb.34:                               ;   in Loop: Header=BB38_30 Depth=1
	mov	x8, x22
	cmp	w25, #2
	b.ne	LBB38_41
; %bb.35:                               ;   in Loop: Header=BB38_30 Depth=1
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	cbnz	x10, LBB38_41
; %bb.36:                               ;   in Loop: Header=BB38_30 Depth=1
	cmp	x26, #0
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	eor	x9, x9, x10
	and	x10, x9, #0xff
	ccmp	x10, #0, #0, ne
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	and	x9, x9, x10
	ldr	x10, [sp, #88]                  ; 8-byte Folded Reload
	eor	x10, x24, x10
	ccmp	x9, #0, #0, eq
	ldr	w9, [sp, #96]                   ; 4-byte Folded Reload
	ccmp	w9, w24, #0, eq
	lsr	x9, x10, #32
	ccmp	x9, #0, #0, eq
	b.ne	LBB38_25
; %bb.37:                               ;   in Loop: Header=BB38_30 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w10, #256                       ; =0x100
	b	LBB38_39
LBB38_38:                               ;   in Loop: Header=BB38_39 Depth=2
	add	x9, x9, #40
	subs	x10, x10, #1
	b.eq	LBB38_42
LBB38_39:                               ;   Parent Loop BB38_30 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x9, #-8]
	cmp	w11, #1
	b.ne	LBB38_38
; %bb.40:                               ;   in Loop: Header=BB38_39 Depth=2
	ldr	x11, [x9]
	cmp	x11, x26
	b.ne	LBB38_38
	b	LBB38_25
LBB38_41:                               ;   in Loop: Header=BB38_30 Depth=1
	and	x9, x9, #0xff00
	lsr	x10, x24, #32
	sub	x10, x10, #1
	cmp	x10, #2
	ccmp	x9, #0, #0, lo
	ccmp	x26, #0, #0, ne
	b.eq	LBB38_43
	b	LBB38_25
LBB38_42:                               ;   in Loop: Header=BB38_30 Depth=1
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #44]                   ; 4-byte Folded Spill
LBB38_43:                               ;   in Loop: Header=BB38_30 Depth=1
	ldr	x8, [x8, #48]
	mov	w12, #48                        ; =0x30
	ldr	x16, [sp, #72]                  ; 8-byte Folded Reload
	madd	x9, x16, x12, x8
	ldr	w9, [x9, #40]
	ldr	w11, [sp, #68]                  ; 4-byte Folded Reload
	orr	w10, w11, #0x20
	cmp	w9, #1
	csel	w11, w10, w11, eq
	str	w11, [sp, #68]                  ; 4-byte Folded Spill
	add	x16, x16, #1
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	cmp	x16, x9
	b.ne	LBB38_30
; %bb.44:
	ldrh	w26, [x20, #12]
	mov	x9, x23
	ldp	w28, w13, [sp, #80]             ; 8-byte Folded Reload
	ldr	w24, [sp, #28]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #4]                   ; 4-byte Folded Reload
	ldr	w11, [sp, #68]                  ; 4-byte Folded Reload
	ldr	x14, [sp, #104]                 ; 8-byte Folded Reload
	ldr	w25, [sp, #44]                  ; 4-byte Folded Reload
	ldp	x12, x16, [sp, #8]              ; 16-byte Folded Reload
	b	LBB38_46
LBB38_45:
	mov	x9, x23
	mov	w25, #0                         ; =0x0
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
LBB38_46:
	sub	w8, w26, w12, uxth
	sub	w8, w8, #256
	cmn	w8, #257
	b.hs	LBB38_48
LBB38_47:
	mov	w0, #3                          ; =0x3
	b	LBB38_26
LBB38_48:
	stp	x12, x16, [sp, #8]              ; 16-byte Folded Spill
	str	w24, [sp, #28]                  ; 4-byte Folded Spill
	ldp	x12, x8, [x29, #-128]
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	lsr	x8, x8, #32
	sub	x8, x8, #1
	stp	x12, x14, [sp, #96]             ; 16-byte Folded Spill
	tst	x12, #0xff00
	ccmp	x8, #2, #2, eq
	cset	w21, lo
	cmp	w21, #1
	b.ne	LBB38_51
; %bb.49:
	str	w25, [sp, #44]                  ; 4-byte Folded Spill
	mov	x25, x11
	mov	x24, x10
	mov	x22, x13
	add	x1, sp, #112
	mov	x0, x20
	bl	_nvm_file_flow_counts
	ldrh	w8, [sp, #116]
	cmp	w8, #256
	b.eq	LBB38_47
; %bb.50:
	ldr	x8, [x20]
	ldr	x8, [x8, #8]
	cmn	x8, #1
	mov	x9, x23
	mov	x13, x22
	mov	x10, x24
	mov	x11, x25
	ldr	w25, [sp, #44]                  ; 4-byte Folded Reload
	b.eq	LBB38_47
LBB38_51:
	sub	w27, w27, #1
	stp	wzr, w9, [sp, #112]
	stp	w19, w11, [sp, #120]
	mov	x24, x11
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	ldr	w8, [sp, #64]                   ; 4-byte Folded Reload
	stp	w9, w8, [sp, #128]
	strh	w27, [sp, #136]
	strh	w25, [sp, #138]
	mov	x22, x10
	strh	w10, [sp, #140]
	mov	w8, #1                          ; =0x1
	strh	w8, [sp, #142]
	ldur	q0, [x29, #-112]
	str	q0, [sp, #144]
	stp	w28, w13, [sp, #160]
	str	w13, [sp, #84]                  ; 4-byte Folded Spill
	add	x1, sp, #112
	sub	x2, x29, #130
	mov	x0, x20
	bl	_obligation_slot
	cbnz	w0, LBB38_26
; %bb.52:
	mov	x14, x25
	cbz	w21, LBB38_54
; %bb.53:
	ldr	x9, [x20]
	ldr	x8, [x9, #8]
	add	x10, x8, #1
	str	x10, [x9, #8]
	b	LBB38_55
LBB38_54:
	mov	x8, #0                          ; =0x0
LBB38_55:
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x9, x10
	b.ne	LBB38_57
; %bb.56:
	mov	w10, w26
	add	w9, w26, #1
	b	LBB38_59
LBB38_57:
	mov	w9, #24624                      ; =0x6030
	add	x11, x20, x9
	mov	w12, #40                        ; =0x28
	movi.2d	v0, #0000000000000000
	ldr	x15, [sp, #8]                   ; 8-byte Folded Reload
LBB38_58:                               ; =>This Inner Loop Header: Depth=1
	mov	x9, x26
	sub	w26, w26, #1
	and	x10, x26, #0xffff
	umaddl	x13, w10, w12, x11
	str	xzr, [x13, #32]
	stp	q0, q0, [x13]
	sub	w15, w15, #1
	tst	w15, #0xffff
	b.ne	LBB38_58
LBB38_59:
	mov	w11, #40                        ; =0x28
	strh	w9, [x20, #12]
	umaddl	x10, w10, w11, x20
	mov	w9, #24624                      ; =0x6030
	add	x11, x10, x9
	ldr	x13, [sp, #88]                  ; 8-byte Folded Reload
	lsr	x9, x13, #33
	cmp	x9, #1
	cset	w12, eq
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	str	x9, [x10, #24624]
	str	x13, [x10, #24632]
	mov	w9, #1                          ; =0x1
	strb	w9, [x11, #16]
	stur	wzr, [x11, #17]
	str	wzr, [x11, #20]
	str	x8, [x10, #24648]
	stp	w12, wzr, [x11, #32]
	ldurh	w8, [x29, #-130]
	ldrh	w10, [x20, #16]
	cmp	w8, w10
	b.ne	LBB38_26
; %bb.60:
	add	w10, w8, #1
	strh	w10, [x20, #16]
	mov	w10, #56                        ; =0x38
	umaddl	x8, w8, w10, x20
	stp	wzr, w23, [x8, #44]
	stp	w19, w24, [x8, #52]
	ldr	w11, [sp, #28]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #64]                  ; 4-byte Folded Reload
	stp	w11, w10, [x8, #60]
	strh	w27, [x8, #68]
	strh	w14, [x8, #70]
	strh	w22, [x8, #72]
	strh	w9, [x8, #74]
	ldur	q0, [x29, #-112]
	stur	q0, [x8, #76]
	ldr	w9, [sp, #84]                   ; 4-byte Folded Reload
	stp	w28, w9, [x8, #92]
	b	LBB38_26
LBB38_61:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh16, Lloh17, Lloh18
	.loh AdrpLdrGotLdr	Lloh19, Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function live_reference
_live_reference:                        ; @live_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh22:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh23:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh24:
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	cmp	w1, #255
	b.hi	LBB39_8
; %bb.1:
	mov	w8, #40                         ; =0x28
	umaddl	x8, w1, w8, x0
	mov	w9, #34864                      ; =0x8830
	add	x8, x8, x9
	ldrb	w9, [x8]
	tbz	w9, #0, LBB39_8
; %bb.2:
	ldrh	w12, [x8, #2]
	ldr	x9, [x0]
	ldr	w10, [x0, #8]
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	ldrh	w9, [x9, #26]
	cmp	w12, w9
	b.hs	LBB39_8
; %bb.3:
	mov	w11, #0                         ; =0x0
	ldrb	w14, [x8, #1]
	ldr	x13, [x8, #8]
	ldr	x10, [x8, #24]
	ldrb	w8, [x8, #32]
	mov	w9, #40                         ; =0x28
	umaddl	x16, w12, w9, x0
	mov	w9, #14384                      ; =0x3830
	add	x17, x16, x9
	ldrb	w9, [x17]
	ldur	x15, [x17, #2]
	str	x15, [sp, #8]
	ldrh	w15, [x17, #10]
	strh	w15, [sp, #16]
	ldrb	w15, [x17, #1]
	ldrb	w17, [x17, #16]
	tbz	w17, #0, LBB39_29
; %bb.4:
	ldr	w17, [x16, #14396]
	cmp	w17, #1
	b.ne	LBB39_29
; %bb.5:
	ldr	x11, [x16, #14408]
	tbz	w14, #0, LBB39_11
; %bb.6:
	cmp	w1, w12
	b.ne	LBB39_28
; %bb.7:
	tst	w8, #0x1
	mov	w10, #1                         ; =0x1
	cinc	w10, w10, eq
	cmp	w10, w15
	ccmp	x11, #0, #0, eq
	b.eq	LBB39_27
	b	LBB39_28
LBB39_8:
	mov	w0, #0                          ; =0x0
LBB39_9:
	ldur	x8, [x29, #-8]
Lloh25:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh26:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh27:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB39_30
; %bb.10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB39_11:
	cmp	w15, #0
	ccmp	x11, x13, #0, eq
	b.ne	LBB39_28
; %bb.12:
	ldrh	w11, [x0, #14]
	cbz	w11, LBB39_29
; %bb.13:
	cmp	w11, #4
	b.hs	LBB39_15
; %bb.14:
	mov	x12, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	b	LBB39_24
LBB39_15:
	dup.2d	v0, x10
	cmp	w11, #32
	b.hs	LBB39_17
; %bb.16:
	mov	x12, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	b	LBB39_21
LBB39_17:
	and	x12, x11, #0xffe0
	mov	w13, #45232                     ; =0xb0b0
	add	x13, x0, x13
	movi.2d	v1, #0000000000000000
	mov	x14, x12
	movi.2d	v2, #0000000000000000
LBB39_18:                               ; =>This Inner Loop Header: Depth=1
	ldp	q4, q3, [x13, #-32]
	ldp	q6, q5, [x13, #-64]
	ldp	q16, q7, [x13, #-96]
	ldp	q17, q18, [x13, #-128]
	ldp	q20, q19, [x13, #96]
	ldp	q22, q21, [x13, #64]
	ldp	q24, q23, [x13, #32]
	ldp	q25, q26, [x13], #256
	cmeq.2d	v18, v18, v0
	cmeq.2d	v17, v17, v0
	uzp1.4s	v17, v17, v18
	cmeq.2d	v16, v16, v0
	cmeq.2d	v7, v7, v0
	uzp1.4s	v7, v16, v7
	uzp1.8h	v7, v17, v7
	cmeq.2d	v6, v6, v0
	cmeq.2d	v5, v5, v0
	uzp1.4s	v5, v6, v5
	cmeq.2d	v4, v4, v0
	cmeq.2d	v3, v3, v0
	uzp1.4s	v3, v4, v3
	uzp1.8h	v3, v5, v3
	uzp1.16b	v3, v7, v3
	cmeq.2d	v4, v26, v0
	cmeq.2d	v5, v25, v0
	uzp1.4s	v4, v5, v4
	cmeq.2d	v5, v24, v0
	cmeq.2d	v6, v23, v0
	uzp1.4s	v5, v5, v6
	uzp1.8h	v4, v4, v5
	cmeq.2d	v5, v22, v0
	cmeq.2d	v6, v21, v0
	uzp1.4s	v5, v5, v6
	cmeq.2d	v6, v20, v0
	cmeq.2d	v7, v19, v0
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	uzp1.16b	v4, v4, v5
	orr.16b	v1, v1, v3
	orr.16b	v2, v2, v4
	subs	x14, x14, #32
	b.ne	LBB39_18
; %bb.19:
	orr.16b	v1, v2, v1
	shl.16b	v1, v1, #7
	cmlt.16b	v1, v1, #0
	umaxv.16b	b1, v1
	fmov	w13, s1
	and	w13, w13, #0x1
	cmp	x12, x11
	b.eq	LBB39_26
; %bb.20:
	tst	x11, #0x1c
	b.eq	LBB39_24
LBB39_21:
	mov	x14, x12
	and	x12, x11, #0xfffc
	movi.2d	v1, #0000000000000000
	mov.h	v1[0], w13
	sub	x13, x14, x12
	add	x14, x0, x14, lsl #3
	mov	w15, #45104                     ; =0xb030
	add	x14, x14, x15
LBB39_22:                               ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x14], #32
	cmeq.2d	v3, v3, v0
	cmeq.2d	v2, v2, v0
	uzp1.4s	v2, v2, v3
	xtn.4h	v2, v2
	orr.8b	v1, v1, v2
	adds	x13, x13, #4
	b.ne	LBB39_22
; %bb.23:
	shl.4h	v0, v1, #15
	cmlt.4h	v0, v0, #0
	umaxv.4h	h0, v0
	fmov	w13, s0
	and	w13, w13, #0x1
	cmp	x12, x11
	b.eq	LBB39_26
LBB39_24:
	add	x14, x0, x12, lsl #3
	mov	w15, #45104                     ; =0xb030
	add	x14, x14, x15
	sub	x11, x11, x12
LBB39_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x14], #8
	cmp	x12, x10
	cset	w12, eq
	orr	w13, w13, w12
	subs	x11, x11, #1
	b.ne	LBB39_25
LBB39_26:
	tbz	w13, #0, LBB39_28
LBB39_27:
	and	w8, w8, #0x1
	mov	w10, #2                         ; =0x2
	sub	w8, w10, w8
	strb	w9, [x2]
	strb	w8, [x2, #1]
	ldr	x8, [sp, #8]
	stur	x8, [x2, #2]
	ldrh	w8, [sp, #16]
	strh	w8, [x2, #10]
	mov	w8, #1                          ; =0x1
	mov	w11, #1                         ; =0x1
	str	w8, [x2, #12]
	b	LBB39_29
LBB39_28:
	mov	w11, #0                         ; =0x0
LBB39_29:
	mov	x0, x11
	b	LBB39_9
LBB39_30:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh22, Lloh23, Lloh24
	.loh AdrpLdrGotLdr	Lloh25, Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function obligation_slot
lCPI40_0:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	8                               ; 0x8
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_obligation_slot:                       ; @obligation_slot
	.cfi_startproc
; %bb.0:
	ldr	w8, [x1, #4]
	cmn	w8, #1
	b.eq	LBB40_7
; %bb.1:
	ldrh	w12, [x0, #16]
	cbz	w12, LBB40_16
; %bb.2:
	mov	x11, #0                         ; =0x0
	mov	x9, #0                          ; =0x0
	lsl	x10, x12, #6
	sub	x13, x10, x12, lsl #3
LBB40_3:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x0, x11
	ldr	w14, [x10, #48]
	cmp	w14, w8
	b.eq	LBB40_8
; %bb.4:                                ;   in Loop: Header=BB40_3 Depth=1
	add	x9, x9, #1
	add	x11, x11, #56
	cmp	x13, x11
	b.ne	LBB40_3
; %bb.5:
	cmp	w12, #256
	b.ne	LBB40_16
; %bb.6:
	mov	w8, #3                          ; =0x3
	b	LBB40_17
LBB40_7:
	mov	w0, #1                          ; =0x1
	ret
LBB40_8:
	ldr	w15, [x10, #44]
	ldrh	w8, [x10, #68]
	and	w8, w8, #0xffff
	ldrh	w12, [x10, #70]
	and	w13, w12, #0xffff
	ldrh	w12, [x10, #72]
	and	w14, w12, #0xffff
	ldr	w16, [x1]
	ldrh	w12, [x1, #24]
	ldrh	w17, [x1, #26]
	ldrh	w3, [x1, #28]
	cmp	w8, w12, uxth
	cset	w12, eq
	cmp	w13, w17, uxth
	cset	w13, eq
	cmp	w14, w3, uxth
	cset	w14, eq
	mov	w8, #2                          ; =0x2
	cmp	w15, w16
	b.ne	LBB40_17
; %bb.9:
	ldrb	w15, [x10, #74]
	ldrb	w16, [x1, #30]
	ldur	q0, [x10, #52]
	ldur	q1, [x1, #8]
	cmeq.4s	v0, v0, v1
Lloh28:
	adrp	x17, lCPI40_0@PAGE
Lloh29:
	ldr	q1, [x17, lCPI40_0@PAGEOFF]
	and.16b	v0, v0, v1
	addv.4s	s0, v0
	fmov	w17, s0
	mov	w3, #15                         ; =0xf
	bic	w17, w3, w17
	cmp	w17, #0
	ccmp	w12, #0, #4, eq
	ccmp	w13, #0, #4, ne
	ccmp	w14, #0, #4, ne
	ccmp	w15, w16, #0, ne
	b.ne	LBB40_17
; %bb.10:
	ldr	x8, [x1, #32]
	add	x11, x0, x11
	ldur	x11, [x11, #76]
	eor	x11, x11, x8
	tst	x11, #0xff
	b.eq	LBB40_12
; %bb.11:
	mov	w0, #2                          ; =0x2
	ret
LBB40_12:
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	mov	w8, #2                          ; =0x2
	tst	x11, x12
	b.ne	LBB40_17
; %bb.13:
	ldur	x11, [x10, #84]
	ldr	x12, [x1, #40]
	cmp	x11, x12
	b.ne	LBB40_17
; %bb.14:
	ldr	w11, [x10, #92]
	ldr	w12, [x1, #48]
	cmp	w11, w12
	b.ne	LBB40_17
; %bb.15:
	ldr	w10, [x10, #96]
	ldr	w11, [x1, #52]
	mov	x12, x9
	cmp	w10, w11
	b.ne	LBB40_17
LBB40_16:
	strh	w12, [x2]
	mov	w0, #0                          ; =0x0
	ret
LBB40_17:
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_flow_call     ; -- Begin function nvm_file_flow_call
	.globl	_nvm_file_flow_call
	.p2align	2
_nvm_file_flow_call:                    ; @nvm_file_flow_call
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	d13, d12, [sp, #240]            ; 16-byte Folded Spill
	stp	d11, d10, [sp, #256]            ; 16-byte Folded Spill
	stp	d9, d8, [sp, #272]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #304]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #320]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #336]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
Lloh30:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh31:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh32:
	ldr	x8, [x8]
	stur	x8, [x29, #-144]
	cbz	x0, LBB41_76
; %bb.1:
	ldr	x22, [x0]
	ldr	w8, [x22, #4]
	cmp	w2, w8
	b.hs	LBB41_76
; %bb.2:
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB41_4
; %bb.3:
	ldr	w10, [x0, #8]
	cmp	w2, w10
	b.ne	LBB41_5
LBB41_4:
	mov	w19, #2                         ; =0x2
	b	LBB41_77
LBB41_5:
	mov	w8, #24                         ; =0x18
	umaddl	x21, w2, w8, x22
	ldrh	w8, [x21, #24]!
	cmp	w4, w8
	b.ne	LBB41_76
; %bb.6:
	cbnz	x3, LBB41_8
; %bb.7:
	cbnz	w4, LBB41_76
LBB41_8:
	cbz	w4, LBB41_11
; %bb.9:
	mov	w8, w2
	add	x8, x22, x8, lsl #2
	ldr	w12, [x8, #1560]
	add	x11, x22, x12, lsl #4
	add	x28, x11, #1816
	mov	w17, w4
	cmp	w4, #3
	b.hi	LBB41_14
; %bb.10:
	mov	x13, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	b	LBB41_25
LBB41_11:
	mov	w24, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	mov	x27, x0
	ldrh	w9, [x27, #12]!
	mov	x26, x9
LBB41_12:
	ldrb	w20, [x21, #4]
	add	w8, w20, w9, uxth
	cmp	w8, #256
	b.ls	LBB41_16
LBB41_13:
	mov	w19, #3                         ; =0x3
	b	LBB41_77
LBB41_14:
	cmp	w4, #16
	b.hs	LBB41_18
; %bb.15:
	mov	x13, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	b	LBB41_22
LBB41_16:
	stp	w2, w4, [sp, #8]                ; 8-byte Folded Spill
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	cbz	w20, LBB41_74
; %bb.17:
	ldr	w8, [x21, #20]
	ldrb	w9, [x21, #9]
	sub	x8, x8, #1
	cmp	w9, #0
	ccmp	x8, #2, #2, eq
	cset	w28, lo
	b	LBB41_75
LBB41_18:
	mov	x20, x17
	and	x13, x17, #0xfff0
	movi.2d	v0, #0000000000000000
	movi.8h	v1, #1
	movi.2d	v2, #0x0000000000ff00
	movi.2d	v3, #0xffffffffffffffff
	mov	w8, #2                          ; =0x2
	dup.2d	v7, x8
	mov	x14, x13
	mov	x15, x28
	movi.2d	v17, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
LBB41_19:                               ; =>This Inner Loop Header: Depth=1
	add	x8, x15, #17
	add	x9, x15, #33
	add	x16, x15, #49
	add	x17, x15, #65
	add	x5, x15, #81
	add	x6, x15, #97
	add	x7, x15, #113
	add	x19, x15, #145
	ldr	b18, [x15, #1]
	ld1.b	{ v18 }[1], [x8]
	ld1.b	{ v18 }[2], [x9]
	add	x8, x15, #161
	add	x9, x15, #177
	ld1.b	{ v18 }[3], [x16]
	ld1.b	{ v18 }[4], [x17]
	add	x16, x15, #193
	ld1.b	{ v18 }[5], [x5]
	ld1.b	{ v18 }[6], [x6]
	ld1.b	{ v18 }[7], [x7]
	ldur	b23, [x15, #129]
	ld1.b	{ v23 }[1], [x19]
	ld1.b	{ v23 }[2], [x8]
	add	x8, x15, #209
	add	x17, x15, #225
	ld1.b	{ v23 }[3], [x9]
	ld1.b	{ v23 }[4], [x16]
	add	x9, x15, #241
	ld1.b	{ v23 }[5], [x8]
	ld1.b	{ v23 }[6], [x17]
	ld1.b	{ v23 }[7], [x9]
	mov	x8, x15
	ld2.2d	{ v19, v20 }, [x8], #32
	add	x9, x15, #64
	ld2.2d	{ v21, v22 }, [x9]
	add	x9, x15, #96
	ld2.2d	{ v24, v25 }, [x9]
	add	x9, x15, #128
	ld2.2d	{ v26, v27 }, [x9]
	add	x9, x15, #160
	ld2.2d	{ v28, v29 }, [x9]
	add	x9, x15, #192
	ld2.2d	{ v30, v31 }, [x9]
	add	x9, x15, #224
	ld2.2d	{ v8, v9 }, [x9]
	zip1.2d	v18, v18, v23
	and.16b	v23, v26, v2
	and.16b	v10, v30, v2
	and.16b	v11, v8, v2
	cmeq.2d	v11, v11, #0
	cmeq.2d	v10, v10, #0
	uzp1.4s	v10, v10, v11
	and.16b	v11, v28, v2
	cmeq.2d	v11, v11, #0
	cmeq.2d	v23, v23, #0
	uzp1.4s	v23, v23, v11
	and.16b	v11, v21, v2
	uzp1.8h	v23, v23, v10
	and.16b	v10, v24, v2
	cmeq.2d	v10, v10, #0
	cmeq.2d	v11, v11, #0
	uzp1.4s	v10, v11, v10
	cmeq.16b	v11, v18, #0
	ushr.2d	v8, v9, #32
	ushll.8h	v9, v11, #0
	and.16b	v9, v9, v1
	ushll2.8h	v11, v11, #0
	and.16b	v11, v11, v1
	add.8h	v17, v17, v11
	ushr.2d	v30, v31, #32
	ld2.2d	{ v11, v12 }, [x8]
	add.8h	v0, v0, v9
	and.16b	v31, v11, v2
	ushr.2d	v28, v29, #32
	and.16b	v29, v19, v2
	cmeq.2d	v29, v29, #0
	cmeq.2d	v31, v31, #0
	uzp1.4s	v29, v29, v31
	ushr.2d	v26, v27, #32
	ushr.2d	v24, v25, #32
	ushr.2d	v21, v22, #32
	ushr.2d	v19, v20, #32
	ushr.2d	v20, v12, #32
	uzp1.8h	v22, v29, v10
	add.2d	v25, v30, v3
	add.2d	v27, v8, v3
	cmhi.2d	v27, v7, v27
	cmhi.2d	v25, v7, v25
	uzp1.4s	v25, v25, v27
	add.2d	v26, v26, v3
	add.2d	v27, v28, v3
	cmhi.2d	v27, v7, v27
	cmhi.2d	v26, v7, v26
	uzp1.4s	v26, v26, v27
	uzp1.8h	v25, v26, v25
	add.2d	v21, v21, v3
	add.2d	v24, v24, v3
	cmhi.2d	v24, v7, v24
	cmhi.2d	v21, v7, v21
	uzp1.4s	v21, v21, v24
	add.2d	v19, v19, v3
	add.2d	v20, v20, v3
	cmhi.2d	v19, v7, v19
	cmhi.2d	v20, v7, v20
	uzp1.4s	v19, v19, v20
	uzp1.8h	v19, v19, v21
	and.16b	v20, v22, v1
	and.16b	v19, v20, v19
	and.16b	v20, v23, v25
	sub.8h	v16, v16, v20
	add.8h	v6, v6, v19
	cmtst.16b	v18, v18, v18
	ushll2.8h	v19, v18, #0
	and.16b	v19, v19, v1
	add.8h	v5, v5, v19
	ushll.8h	v18, v18, #0
	and.16b	v18, v18, v1
	add.8h	v4, v4, v18
	add	x15, x15, #256
	subs	x14, x14, #16
	b.ne	LBB41_19
; %bb.20:
	add.8h	v0, v0, v17
	addv.8h	h0, v0
	fmov	w25, s0
	add.8h	v0, v6, v16
	addv.8h	h0, v0
	fmov	w23, s0
	add.8h	v0, v4, v5
	addv.8h	h0, v0
	fmov	w24, s0
	mov	x17, x20
	cmp	x13, x20
	b.eq	LBB41_27
; %bb.21:
	tst	x17, #0xc
	b.eq	LBB41_25
LBB41_22:
	mov	x9, x13
	and	x13, x17, #0xfffc
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.h	v1[0], w25
	movi.2d	v2, #0000000000000000
	mov.h	v2[0], w23
	mov.h	v0[0], w24
	lsl	x8, x9, #4
	add	x8, x8, x12, lsl #4
	add	x8, x8, x22
	add	x8, x8, #1816
	sub	x14, x9, x13
	movi.2d	v3, #0x0000000000ff00
	movi.2d	v4, #0xffffffffffffffff
	mov	w9, #2                          ; =0x2
	dup.2d	v5, x9
LBB41_23:                               ; =>This Inner Loop Header: Depth=1
	add	x9, x8, #1
	add	x15, x8, #17
	add	x16, x8, #33
	ld1.b	{ v6 }[0], [x9]
	add	x9, x8, #49
	ld1.b	{ v6 }[2], [x15]
	ld1.b	{ v6 }[4], [x16]
	ld1.b	{ v6 }[6], [x9]
	mov	x9, x8
	ld2.2d	{ v16, v17 }, [x9], #32
	ld2.2d	{ v18, v19 }, [x9]
	bic.4h	v6, #255, lsl #8
	and.16b	v7, v16, v3
	ushr.2d	v16, v17, #32
	cmeq.4h	v17, v6, #0
	and.16b	v20, v18, v3
	cmeq.2d	v7, v7, #0
	cmeq.2d	v20, v20, #0
	ushr.2d	v18, v19, #32
	add.2d	v18, v18, v4
	uzp1.4s	v7, v7, v20
	add.2d	v16, v16, v4
	cmhi.2d	v16, v5, v16
	cmhi.2d	v18, v5, v18
	uzp1.4s	v16, v16, v18
	and.16b	v7, v7, v16
	sub.4h	v1, v1, v17
	xtn.4h	v7, v7
	sub.4h	v2, v2, v7
	cmtst.4h	v6, v6, v6
	sub.4h	v0, v0, v6
	add	x8, x8, #64
	adds	x14, x14, #4
	b.ne	LBB41_23
; %bb.24:
	addv.4h	h1, v1
	fmov	w25, s1
	addv.4h	h1, v2
	fmov	w23, s1
	addv.4h	h0, v0
	fmov	w24, s0
	cmp	x13, x17
	b.eq	LBB41_27
LBB41_25:
	sub	x8, x17, x13
	lsl	x9, x13, #4
	add	x9, x9, x12, lsl #4
	add	x9, x9, x22
	add	x9, x9, #1816
LBB41_26:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x9, #1]
	ldr	w13, [x9, #12]
	sub	x13, x13, #1
	cmp	w12, #0
	cset	w12, eq
	cinc	w25, w25, eq
	cinc	w24, w24, ne
	cmp	x13, #2
	csel	w12, wzr, w12, hs
	add	w23, w23, w12
	add	x9, x9, #16
	subs	x8, x8, #1
	b.ne	LBB41_26
LBB41_27:
	mov	x27, x0
	ldrh	w26, [x27, #12]!
	cmp	w26, w25, uxth
	b.lo	LBB41_76
; %bb.28:
	mov	x12, #0                         ; =0x0
	mov	w8, #45232                      ; =0xb0b0
	mov	w9, #34872                      ; =0x8838
	add	x8, x0, x8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x8, x0, x9
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	x16, #-256                      ; =0xffffffffffffff00
	movk	x16, #0, lsl #16
	sub	w9, w26, w25
	mov	w8, #34864                      ; =0x8830
	add	x8, x0, x8
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	add	x8, x10, x10, lsl #1
	lsl	x8, x8, #3
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	add	x8, x22, #26
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	mov	w8, #14384                      ; =0x3830
	add	x8, x0, x8
	stp	x28, x8, [sp, #72]              ; 16-byte Folded Spill
	mov	w8, #34872                      ; =0x8838
	add	x6, x0, x8
	mov	w8, #24624                      ; =0x6030
	add	x8, x0, x8
	stp	x8, x17, [sp, #56]              ; 16-byte Folded Spill
	mov	w8, #45104                      ; =0xb030
	add	x8, x0, x8
	stp	x8, x9, [sp, #32]               ; 16-byte Folded Spill
	add	x8, x11, #1817
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	mov	w30, #40                        ; =0x28
	mov	x5, x9
LBB41_29:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB41_55 Depth 2
                                        ;     Child Loop BB41_59 Depth 2
                                        ;     Child Loop BB41_62 Depth 2
                                        ;     Child Loop BB41_69 Depth 2
                                        ;     Child Loop BB41_46 Depth 2
	add	x15, x28, x12, lsl #4
	ldrb	w14, [x15, #1]
	ldrh	w20, [x3, x12, lsl #1]
	cbz	w14, LBB41_38
; %bb.30:                               ;   in Loop: Header=BB41_29 Depth=1
	cmp	w20, #255
	b.hi	LBB41_76
; %bb.31:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	umaddl	x9, w20, w30, x8
	ldrb	w8, [x9]
	tbz	w8, #0, LBB41_76
; %bb.32:                               ;   in Loop: Header=BB41_29 Depth=1
	ldrh	w8, [x9, #2]
	ldp	x11, x10, [sp, #88]             ; 16-byte Folded Reload
	ldrh	w10, [x11, x10]
	cmp	w8, w10
	b.hs	LBB41_76
; %bb.33:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	umaddl	x13, w8, w30, x10
	ldrb	w10, [x13, #16]
	mov	w19, #1                         ; =0x1
	tbz	w10, #0, LBB41_77
; %bb.34:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	w10, [x13, #12]
	cmp	w10, #1
	b.ne	LBB41_77
; %bb.35:                               ;   in Loop: Header=BB41_29 Depth=1
	str	x5, [sp, #112]                  ; 8-byte Folded Spill
	ldrb	w19, [x9, #1]
	ldrb	w5, [x9, #32]
	ldrb	w7, [x13]
	ldrb	w16, [x13, #1]
	ldrh	w10, [x13, #6]
	ldur	w17, [x13, #2]
	ldr	w11, [x13, #8]
	ldr	x13, [x13, #24]
	tbz	w19, #0, LBB41_48
; %bb.36:                               ;   in Loop: Header=BB41_29 Depth=1
	mov	w19, #1                         ; =0x1
	cmp	w20, w8
	b.ne	LBB41_77
; %bb.37:                               ;   in Loop: Header=BB41_29 Depth=1
	tst	w5, #0x1
	cinc	w8, w19, eq
	cmp	w8, w16
	ccmp	x13, #0, #0, eq
	b.eq	LBB41_64
	b	LBB41_77
LBB41_38:                               ;   in Loop: Header=BB41_29 Depth=1
	mov	w8, #65535                      ; =0xffff
	cmp	w20, w8
	b.ne	LBB41_76
; %bb.39:                               ;   in Loop: Header=BB41_29 Depth=1
	and	x8, x5, #0xffff
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w8, w30, x9
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB41_76
; %bb.40:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x10, [x8]
	ldr	x9, [x15]
	eor	x11, x9, x10
	tst	x11, #0xff
	b.ne	LBB41_76
; %bb.41:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x10, [x15, #8]
	ldr	x13, [x8, #8]
	and	x11, x11, x16
	cmp	x11, #0
	ccmp	x13, x10, #0, eq
	b.ne	LBB41_76
; %bb.42:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x8, [x8, #24]
	lsr	x10, x10, #32
	sub	x10, x10, #1
	tst	x9, #0xff00
	ccmp	x10, #2, #2, eq
	cset	w9, lo
	cmp	x8, #0
	cset	w10, ne
	eor	w9, w10, w9
	tbnz	w9, #0, LBB41_76
; %bb.43:                               ;   in Loop: Header=BB41_29 Depth=1
	add	w5, w5, #1
	cbz	x8, LBB41_72
; %bb.44:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w10, #256                       ; =0x100
	b	LBB41_46
LBB41_45:                               ;   in Loop: Header=BB41_46 Depth=2
	add	x9, x9, #40
	subs	x10, x10, #1
	b.eq	LBB41_72
LBB41_46:                               ;   Parent Loop BB41_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x9, #-8]
	cmp	w11, #1
	b.ne	LBB41_45
; %bb.47:                               ;   in Loop: Header=BB41_46 Depth=2
	ldr	x11, [x9]
	cmp	x11, x8
	b.ne	LBB41_45
	b	LBB41_76
LBB41_48:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x8, [x9, #8]
	cmp	w16, #0
	ccmp	x13, x8, #0, eq
	b.ne	LBB41_76
; %bb.49:                               ;   in Loop: Header=BB41_29 Depth=1
	ldrh	w8, [x0, #14]
	cbz	w8, LBB41_76
; %bb.50:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x19, [x9, #24]
	cmp	w8, #4
	b.hs	LBB41_52
; %bb.51:                               ;   in Loop: Header=BB41_29 Depth=1
	mov	x13, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	b	LBB41_61
LBB41_52:                               ;   in Loop: Header=BB41_29 Depth=1
	dup.2d	v0, x19
	cmp	w8, #32
	b.hs	LBB41_54
; %bb.53:                               ;   in Loop: Header=BB41_29 Depth=1
	mov	x13, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	b	LBB41_58
LBB41_54:                               ;   in Loop: Header=BB41_29 Depth=1
	and	x13, x8, #0xffe0
	movi.2d	v1, #0000000000000000
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	mov	x16, x13
	movi.2d	v2, #0000000000000000
LBB41_55:                               ;   Parent Loop BB41_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q4, q3, [x9, #-32]
	ldp	q6, q5, [x9, #-64]
	ldp	q16, q7, [x9, #-96]
	ldp	q17, q18, [x9, #-128]
	ldp	q20, q19, [x9, #96]
	ldp	q22, q21, [x9, #64]
	ldp	q24, q23, [x9, #32]
	ldp	q25, q26, [x9], #256
	cmeq.2d	v18, v18, v0
	cmeq.2d	v17, v17, v0
	uzp1.4s	v17, v17, v18
	cmeq.2d	v16, v16, v0
	cmeq.2d	v7, v7, v0
	uzp1.4s	v7, v16, v7
	uzp1.8h	v7, v17, v7
	cmeq.2d	v6, v6, v0
	cmeq.2d	v5, v5, v0
	uzp1.4s	v5, v6, v5
	cmeq.2d	v4, v4, v0
	cmeq.2d	v3, v3, v0
	uzp1.4s	v3, v4, v3
	uzp1.8h	v3, v5, v3
	uzp1.16b	v3, v7, v3
	cmeq.2d	v4, v26, v0
	cmeq.2d	v5, v25, v0
	uzp1.4s	v4, v5, v4
	cmeq.2d	v5, v24, v0
	cmeq.2d	v6, v23, v0
	uzp1.4s	v5, v5, v6
	uzp1.8h	v4, v4, v5
	cmeq.2d	v5, v22, v0
	cmeq.2d	v6, v21, v0
	uzp1.4s	v5, v5, v6
	cmeq.2d	v6, v20, v0
	cmeq.2d	v7, v19, v0
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	uzp1.16b	v4, v4, v5
	orr.16b	v1, v1, v3
	orr.16b	v2, v2, v4
	subs	x16, x16, #32
	b.ne	LBB41_55
; %bb.56:                               ;   in Loop: Header=BB41_29 Depth=1
	orr.16b	v1, v2, v1
	shl.16b	v1, v1, #7
	cmlt.16b	v1, v1, #0
	umaxv.16b	b1, v1
	fmov	w9, s1
	and	w9, w9, #0x1
	cmp	x13, x8
	b.eq	LBB41_63
; %bb.57:                               ;   in Loop: Header=BB41_29 Depth=1
	tst	x8, #0x1c
	b.eq	LBB41_61
LBB41_58:                               ;   in Loop: Header=BB41_29 Depth=1
	mov	x16, x13
	and	x13, x8, #0xfffc
	movi.2d	v1, #0000000000000000
	mov.h	v1[0], w9
	sub	x9, x16, x13
	ldr	x28, [sp, #32]                  ; 8-byte Folded Reload
	add	x16, x28, x16, lsl #3
LBB41_59:                               ;   Parent Loop BB41_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q3, [x16], #32
	cmeq.2d	v3, v3, v0
	cmeq.2d	v2, v2, v0
	uzp1.4s	v2, v2, v3
	xtn.4h	v2, v2
	orr.8b	v1, v1, v2
	adds	x9, x9, #4
	b.ne	LBB41_59
; %bb.60:                               ;   in Loop: Header=BB41_29 Depth=1
	shl.4h	v0, v1, #15
	cmlt.4h	v0, v0, #0
	umaxv.4h	h0, v0
	fmov	w9, s0
	and	w9, w9, #0x1
	cmp	x13, x8
	b.eq	LBB41_63
LBB41_61:                               ;   in Loop: Header=BB41_29 Depth=1
	sub	x8, x8, x13
	ldr	x16, [sp, #32]                  ; 8-byte Folded Reload
	add	x13, x16, x13, lsl #3
LBB41_62:                               ;   Parent Loop BB41_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x16, [x13], #8
	cmp	x16, x19
	cset	w16, eq
	orr	w9, w9, w16
	subs	x8, x8, #1
	b.ne	LBB41_62
LBB41_63:                               ;   in Loop: Header=BB41_29 Depth=1
	tbz	w9, #0, LBB41_76
LBB41_64:                               ;   in Loop: Header=BB41_29 Depth=1
	orr	x8, x17, x10, lsl #32
	and	w9, w5, #0x1
	mov	w10, #2                         ; =0x2
	sub	w9, w10, w9
	ldr	x10, [x15]
	ubfiz	x9, x9, #8, #32
	orr	x8, x9, x8, lsl #16
	orr	x8, x8, x7
	eor	x8, x10, x8
	tst	x8, #0xff
	b.ne	LBB41_76
; %bb.65:                               ;   in Loop: Header=BB41_29 Depth=1
	ldr	x9, [x15, #8]
	mov	x16, #-256                      ; =0xffffffffffffff00
	movk	x16, #0, lsl #16
	and	x8, x8, x16
	eor	x10, x9, #0x100000000
	cmp	x8, #0
	ccmp	w11, w9, #0, eq
	lsr	x8, x10, #32
	ccmp	x8, #0, #0, eq
	b.ne	LBB41_76
; %bb.66:                               ;   in Loop: Header=BB41_29 Depth=1
	cbz	x12, LBB41_71
; %bb.67:                               ;   in Loop: Header=BB41_29 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x20, x20, lsl #2
	lsl	x9, x9, #3
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	ldp	x17, x28, [sp, #64]             ; 16-byte Folded Reload
	ldr	x5, [sp, #112]                  ; 8-byte Folded Reload
	b	LBB41_69
LBB41_68:                               ;   in Loop: Header=BB41_69 Depth=2
	add	x8, x8, #1
	cmp	x12, x8
	b.eq	LBB41_72
LBB41_69:                               ;   Parent Loop BB41_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w11, [x10], #16
	cbz	w11, LBB41_68
; %bb.70:                               ;   in Loop: Header=BB41_69 Depth=2
	cmp	w14, #1
	ldrh	w13, [x3, x8, lsl #1]
	umull	x13, w13, w30
	ldr	x13, [x6, x13]
	ldr	x15, [x6, x9]
	ccmp	w11, #1, #0, eq
	cset	w11, eq
	cmp	x13, x15
	ccmp	w11, #0, #0, eq
	b.ne	LBB41_68
	b	LBB41_76
LBB41_71:                               ;   in Loop: Header=BB41_29 Depth=1
	ldp	x17, x28, [sp, #64]             ; 16-byte Folded Reload
	ldr	x5, [sp, #112]                  ; 8-byte Folded Reload
LBB41_72:                               ;   in Loop: Header=BB41_29 Depth=1
	add	x12, x12, #1
	cmp	x12, x17
	b.ne	LBB41_29
; %bb.73:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	b	LBB41_12
LBB41_74:
	mov	w28, #0                         ; =0x0
LBB41_75:
	add	x1, sp, #184
	str	x0, [sp, #112]                  ; 8-byte Folded Spill
	bl	_nvm_file_flow_counts
	ldrh	w8, [sp, #188]
	cmp	w8, w23, uxth
	b.hs	LBB41_79
LBB41_76:
	mov	w19, #1                         ; =0x1
LBB41_77:
	ldur	x8, [x29, #-144]
Lloh33:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh34:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh35:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_99
; %bb.78:
	mov	x0, x19
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #352]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #336]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #320]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #272]              ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #256]            ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
LBB41_79:
	sub	w8, w8, w23
	add	w8, w28, w8, uxth
	cmp	w8, #256
	b.hi	LBB41_13
; %bb.80:
	cbz	w28, LBB41_82
; %bb.81:
	ldr	x8, [x22, #8]
	cmn	x8, #1
	b.eq	LBB41_13
LBB41_82:
	ldur	q0, [x21, #8]
	stur	q0, [x29, #-160]
	mov	w9, #1                          ; =0x1
	ldp	w10, w8, [sp, #4]               ; 8-byte Folded Reload
	stp	w9, w10, [sp, #124]
	mov	w9, #448                        ; =0x1c0
	stp	w8, w9, [sp, #132]
	stur	xzr, [sp, #140]
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	strh	w8, [sp, #148]
	strh	w23, [sp, #150]
	strh	w24, [sp, #152]
	strb	w20, [sp, #154]
	strb	wzr, [sp, #155]
	stur	q0, [sp, #156]
	stur	xzr, [sp, #172]
	add	x1, sp, #124
	add	x2, sp, #182
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	bl	_obligation_slot
	mov	x19, x0
	cbnz	w0, LBB41_77
; %bb.83:
	cbz	w28, LBB41_85
; %bb.84:
	ldr	x28, [x22, #8]
	add	x8, x28, #1
	str	x8, [x22, #8]
	b	LBB41_86
LBB41_85:
	mov	x28, #0                         ; =0x0
LBB41_86:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	tst	w25, #0xffff
	b.eq	LBB41_89
; %bb.87:
	sub	w9, w26, #1
	and	x9, x9, #0xffff
	mov	w10, #40                        ; =0x28
	umull	x9, w9, w10
	sub	w10, w25, #1
	and	x11, x10, #0xffff
	add	x10, x11, w10, uxth #2
	lsl	x10, x10, #3
	sub	x9, x9, x10
	mov	w11, #24624                     ; =0x6030
	add	x8, x8, x11
	add	x0, x9, x8
	add	x1, x10, #40
	bl	_bzero
	mov	w26, w26
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	and	x9, x8, #0xffff
	sub	x8, x26, #1
	cmp	x8, x9
	csel	x8, x8, x9, lo
	sub	x8, x26, x8
	cmp	x8, #4
	b.hs	LBB41_90
; %bb.88:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	b	LBB41_93
LBB41_89:
	mov	x9, x20
	b	LBB41_95
LBB41_90:
	and	x10, x8, #0xfffffffffffffffc
	sub	x26, x26, x10
	mov	x11, x10
LBB41_91:                               ; =>This Inner Loop Header: Depth=1
	subs	x11, x11, #4
	b.ne	LBB41_91
; %bb.92:
	cmp	x8, x10
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	b.eq	LBB41_94
LBB41_93:                               ; =>This Inner Loop Header: Depth=1
	sub	x26, x26, #1
	cmp	x26, x9
	b.hi	LBB41_93
LBB41_94:
	strh	w26, [x27]
	ldrb	w9, [x21, #4]
LBB41_95:
	cbz	w9, LBB41_97
; %bb.96:
	mov	x9, x26
	and	x9, x9, #0xffff
	mov	w10, #40                        ; =0x28
	umaddl	x9, w9, w10, x8
	add	w10, w26, #1
	strh	w10, [x8, #12]
	mov	w10, #24624                     ; =0x6030
	add	x10, x9, x10
	ldr	x11, [x21, #16]
	ldur	q0, [x21, #8]
	str	q0, [x9, #24624]
	lsr	x11, x11, #33
	mov	w12, #1                         ; =0x1
	strb	w12, [x10, #16]
	cmp	x11, #1
	cset	w11, eq
	stur	wzr, [x10, #17]
	str	wzr, [x10, #20]
	str	x28, [x9, #24648]
	stp	w11, wzr, [x10, #32]
LBB41_97:
	ldrh	w9, [sp, #182]
	ldrh	w8, [x8, #16]
	cmp	w9, w8
	b.ne	LBB41_77
; %bb.98:
	add	w8, w9, #1
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	strh	w8, [x10, #16]
	mov	w8, #56                         ; =0x38
	umaddl	x9, w9, w8, x10
	mov	w10, #1                         ; =0x1
	ldp	w11, w8, [sp, #4]               ; 8-byte Folded Reload
	stp	w10, w11, [x9, #44]
	mov	w10, #448                       ; =0x1c0
	stp	w8, w10, [x9, #52]
	stur	xzr, [x9, #60]
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	strh	w8, [x9, #68]
	strh	w23, [x9, #70]
	strh	w24, [x9, #72]
	strb	w20, [x9, #74]
	strb	wzr, [x9, #75]
	ldur	q0, [x29, #-160]
	stur	q0, [x9, #76]
	stur	xzr, [x9, #92]
	b	LBB41_77
LBB41_99:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh30, Lloh31, Lloh32
	.loh AdrpLdrGotLdr	Lloh33, Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_free     ; -- Begin function nvm_file_code_free
	.globl	_nvm_file_code_free
	.p2align	2
_nvm_file_code_free:                    ; @nvm_file_code_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB42_5
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x19, [x0]
	cbz	x19, LBB42_4
; %bb.2:
	ldr	w8, [x19]
	subs	w8, w8, #1
	str	w8, [x19]
	b.ne	LBB42_4
; %bb.3:
	ldr	x8, [x19, #16]
	mov	x20, x0
	mov	x0, x8
	bl	_nvm_file_nominal_plan_free
	mov	x0, x19
	bl	_free
	mov	x0, x20
LBB42_4:
	ldr	x8, [x0, #16]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB42_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_prepare  ; -- Begin function nvm_file_code_prepare
	.globl	_nvm_file_code_prepare
	.p2align	2
_nvm_file_code_prepare:                 ; @nvm_file_code_prepare
	.cfi_startproc
; %bb.0:
	mov	w2, #1                          ; =0x1
	mov	w3, #0                          ; =0x0
	b	_file_code_prepare_profile
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_function_count ; -- Begin function nvm_file_code_function_count
	.globl	_nvm_file_code_function_count
	.p2align	2
_nvm_file_code_function_count:          ; @nvm_file_code_function_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB44_2
; %bb.1:
	ldr	w0, [x0, #24]
LBB44_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_function ; -- Begin function nvm_file_code_function
	.globl	_nvm_file_code_function
	.p2align	2
_nvm_file_code_function:                ; @nvm_file_code_function
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB45_4
; %bb.1:
	cbz	x2, LBB45_4
; %bb.2:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB45_5
; %bb.3:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8, #48]
	ldr	w8, [x8, #80]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB45_4:
	ret
LBB45_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_local    ; -- Begin function nvm_file_code_local
	.globl	_nvm_file_code_local
	.p2align	2
_nvm_file_code_local:                   ; @nvm_file_code_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB46_6
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB46_6
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB46_6
; %bb.3:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB46_7
; %bb.4:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB46_7
; %bb.5:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
LBB46_6:
	ret
LBB46_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_instruction ; -- Begin function nvm_file_code_instruction
	.globl	_nvm_file_code_instruction
	.p2align	2
_nvm_file_code_instruction:             ; @nvm_file_code_instruction
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB47_5
; %bb.1:
	cbz	x3, LBB47_5
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w1, w8
	b.hs	LBB47_6
; %bb.3:
	mov	w8, #36                         ; =0x24
	umaddl	x8, w1, w8, x0
	ldrh	w8, [x8, #56]
	cmp	w2, w8
	b.hs	LBB47_6
; %bb.4:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, w1
	ldr	x9, [x0, #16]
	add	x8, x0, x8, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #600                       ; =0x258
	umaddl	x1, w8, w10, x9
	mov	x0, x3
	mov	w2, #600                        ; =0x258
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB47_5:
	mov	x0, x8
	ret
LBB47_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_instruction_order ; -- Begin function nvm_file_code_instruction_order
	.globl	_nvm_file_code_instruction_order
	.p2align	2
_nvm_file_code_instruction_order:       ; @nvm_file_code_instruction_order
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB48_5
; %bb.1:
	cbz	x3, LBB48_5
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w1, w8
	b.hs	LBB48_6
; %bb.3:
	mov	w8, #36                         ; =0x24
	umaddl	x8, w1, w8, x0
	ldrh	w8, [x8, #56]
	cmp	w2, w8
	b.hs	LBB48_6
; %bb.4:
	mov	w8, w1
	add	x8, x0, x8, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	add	x8, x0, w8, uxtw #1
	ldrh	w8, [x8, #2864]
	strh	w8, [x3]
	mov	w8, #1                          ; =0x1
LBB48_5:
	mov	x0, x8
	ret
LBB48_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_code_function_order ; -- Begin function nvm_file_code_function_order
	.globl	_nvm_file_code_function_order
	.p2align	2
_nvm_file_code_function_order:          ; @nvm_file_code_function_order
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB49_4
; %bb.1:
	cbz	x2, LBB49_4
; %bb.2:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB49_5
; %bb.3:
	add	x8, x8, w1, uxtw #2
	ldr	w8, [x8, #2608]
	str	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB49_4:
	ret
LBB49_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_body_free     ; -- Begin function nvm_file_body_free
	.globl	_nvm_file_body_free
	.p2align	2
_nvm_file_body_free:                    ; @nvm_file_body_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB50_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB50_6
; %bb.2:
	ldr	x21, [x20]
	cbz	x21, LBB50_5
; %bb.3:
	ldr	w8, [x21]
	subs	w8, w8, #1
	str	w8, [x21]
	b.ne	LBB50_5
; %bb.4:
	ldr	x0, [x21, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x21
	bl	_free
LBB50_5:
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #8]
	bl	_free
	mov	x0, x20
	bl	_free
LBB50_6:
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB50_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_body_analyze  ; -- Begin function nvm_file_body_analyze
	.globl	_nvm_file_body_analyze
	.p2align	2
_nvm_file_body_analyze:                 ; @nvm_file_body_analyze
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB51_10
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x1
	stur	xzr, [x29, #-104]
	sub	x1, x29, #104
	mov	w2, #1                          ; =0x1
	mov	w3, #0                          ; =0x0
	bl	_file_code_prepare_profile
	cbnz	w0, LBB51_9
; %bb.2:
	mov	w8, #65456                      ; =0xffb0
	movk	w8, #255, lsl #16
	ldur	x21, [x29, #-104]
	ldr	x9, [x21, #40]
	cmp	x9, x8
	b.hi	LBB51_5
; %bb.3:
	ldr	w22, [x21, #32]
	add	x10, x22, x22, lsl #2
	lsl	x10, x10, #4
	sub	x11, x8, x9
	cmp	x10, x11
	b.hi	LBB51_5
; %bb.4:
	add	x9, x9, x10
	add	x20, x9, #80
	sub	x8, x8, #2512
	cmp	x20, x8
	b.ls	LBB51_11
LBB51_5:
	ldr	x19, [x21]
	cbz	x19, LBB51_8
; %bb.6:
	ldr	w8, [x19]
	subs	w8, w8, #1
	str	w8, [x19]
	b.ne	LBB51_8
; %bb.7:
	ldr	x0, [x19, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x19
	bl	_free
LBB51_8:
	ldr	x0, [x21, #16]
	bl	_free
	ldr	x0, [x21, #8]
	bl	_free
	mov	x0, x21
	bl	_free
	mov	w0, #3                          ; =0x3
LBB51_9:
	add	sp, sp, #2208
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB51_10:
	mov	w0, #1                          ; =0x1
	ret
LBB51_11:
	mov	w0, #1                          ; =0x1
	mov	w1, #80                         ; =0x50
	bl	_calloc
	cbz	x0, LBB51_56
; %bb.12:
	mov	x24, x0
	str	x21, [x0]
	mov	x0, x22
	mov	w1, #80                         ; =0x50
	bl	_calloc
	str	x0, [x24, #8]
	cbz	x0, LBB51_57
; %bb.13:
	mov	x23, x0
	add	x22, x20, #2592
	add	x28, sp, #104
	add	x20, x28, #8
	mov	x0, x20
	mov	w1, #2072                       ; =0x818
	bl	_bzero
	str	x22, [sp, #104]
	ldr	w8, [x21, #24]
	str	x24, [sp, #32]                  ; 8-byte Folded Spill
	cbz	w8, LBB51_58
; %bb.14:
	mov	x25, #0                         ; =0x0
	mov	w8, #18385                      ; =0x47d1
	movk	w8, #255, lsl #16
	add	x26, x21, #2608
	add	x9, x24, #16
	stp	x9, x26, [sp]                   ; 16-byte Folded Spill
	add	x10, x21, #56
	add	x9, x21, #2864
	stp	x9, x10, [sp, #72]              ; 16-byte Folded Spill
	add	x9, x21, #2352
	str	x9, [sp, #64]                   ; 8-byte Folded Spill
	str	x23, [sp, #24]                  ; 8-byte Folded Spill
	str	x20, [sp, #96]                  ; 8-byte Folded Spill
LBB51_15:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB51_22 Depth 2
                                        ;       Child Loop BB51_47 Depth 3
	cmp	x22, x8
	b.hs	LBB51_60
; %bb.16:                               ;   in Loop: Header=BB51_15 Depth=1
	ldr	w27, [x26, x25, lsl #2]
	ldr	x0, [x21]
	mov	x1, x27
	mov	x2, x20
	bl	_nvm_file_flow_state
	cbnz	w0, LBB51_61
; %bb.17:                               ;   in Loop: Header=BB51_15 Depth=1
	ldr	x8, [sp, #104]
	mov	w9, #47152                      ; =0xb830
	add	x22, x8, x9
	str	x22, [sp, #104]
	add	x8, x27, x27, lsl #3
	lsl	x9, x8, #2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	stp	x27, x9, [sp, #40]              ; 16-byte Folded Spill
	ldrh	w8, [x8, x9]
	cbz	w8, LBB51_82
; %bb.18:                               ;   in Loop: Header=BB51_15 Depth=1
	str	x25, [sp, #16]                  ; 8-byte Folded Spill
	mov	w12, #0                         ; =0x0
	str	wzr, [sp, #92]                  ; 4-byte Folded Spill
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	b	LBB51_22
LBB51_19:                               ;   in Loop: Header=BB51_22 Depth=2
	str	x22, [sp, #104]
	ldp	x23, x24, [sp, #24]             ; 16-byte Folded Reload
	ldr	x20, [sp, #96]                  ; 8-byte Folded Reload
LBB51_20:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	ldr	w12, [sp, #60]                  ; 4-byte Folded Reload
LBB51_21:                               ;   in Loop: Header=BB51_22 Depth=2
	add	w12, w12, #1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, x9]
	cmp	w12, w8
	b.hs	LBB51_54
LBB51_22:                               ;   Parent Loop BB51_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB51_47 Depth 3
	ldp	x8, x10, [sp, #64]              ; 16-byte Folded Reload
	ldr	w8, [x8, x11, lsl #2]
	add	w9, w8, w12
	ldrh	w9, [x10, w9, uxtw #1]
	ldr	x10, [x20, x9, lsl #3]
	str	x10, [sp, #2160]
	str	xzr, [x20, x9, lsl #3]
	ldr	x26, [sp, #2160]
	cbz	x26, LBB51_21
; %bb.23:                               ;   in Loop: Header=BB51_22 Depth=2
	str	w12, [sp, #60]                  ; 4-byte Folded Spill
	ldr	x10, [x21, #16]
	add	w8, w8, w9
	mov	w9, #80                         ; =0x50
	umaddl	x27, w8, w9, x23
	mov	w9, #1                          ; =0x1
	strb	w9, [x27]
	ldrh	w9, [x26, #12]
	strh	w9, [x27, #4]
	mov	w9, #600                        ; =0x258
	umaddl	x25, w8, w9, x10
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x27, #8]
	mov	w8, #128                        ; =0x80
	str	w8, [x27, #20]
	mov	x0, x24
	mov	x1, x26
	mov	x2, x25
	mov	x3, x27
	bl	_file_body_transfer
	cbnz	w0, LBB51_61
; %bb.24:                               ;   in Loop: Header=BB51_22 Depth=2
	ldrh	w8, [x26, #12]
	strh	w8, [x27, #6]
	ldrb	w8, [x27, #1]
	ldr	w9, [sp, #92]                   ; 4-byte Folded Reload
	and	w9, w9, #0x1
	orr	w8, w8, w9
	cmp	w8, #0
	cset	w9, ne
	ldrb	w8, [x25, #8]
	cmp	w8, #146
	str	w9, [sp, #92]                   ; 4-byte Folded Spill
	b.ne	LBB51_28
; %bb.25:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	w8, #36769                      ; =0x8fa1
	movk	w8, #254, lsl #16
	cmp	x22, x8
	b.hs	LBB51_60
; %bb.26:                               ;   in Loop: Header=BB51_22 Depth=2
	ldrh	w1, [x25, #16]
	add	x2, x28, #2064
	add	x3, x28, #2072
	mov	x0, x26
	bl	_nvm_file_flow_refine
	cbnz	w0, LBB51_61
; %bb.27:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x8, [sp, #104]
	ldr	x26, [sp, #2160]
	mov	w9, #28768                      ; =0x7060
	movk	w9, #1, lsl #16
	add	x22, x8, x9
	str	x22, [sp, #104]
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #2]
	cbnz	x26, LBB51_39
	b	LBB51_43
LBB51_28:                               ;   in Loop: Header=BB51_22 Depth=2
	ldrb	w8, [x25, #76]
	cbz	w8, LBB51_39
; %bb.29:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	w8, #18385                      ; =0x47d1
	movk	w8, #255, lsl #16
	cmp	x22, x8
	b.hs	LBB51_60
; %bb.30:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x20, [x26]
	ldr	w23, [x20]
	cmn	w23, #1
	b.eq	LBB51_60
; %bb.31:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	w0, #47152                      ; =0xb830
	bl	_malloc
	cbz	x0, LBB51_81
; %bb.32:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	x27, x0
	mov	x1, x26
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	add	w8, w23, #1
	str	w8, [x20]
	mov	w8, #47152                      ; =0xb830
	add	x8, x22, x8
	str	x27, [sp, #2168]
	str	x8, [sp, #104]
	ldrb	w9, [x25, #76]
	cmp	w9, #2
	b.ne	LBB51_37
; %bb.33:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	w8, #36769                      ; =0x8fa1
	movk	w8, #254, lsl #16
	cmp	x22, x8
	b.hs	LBB51_60
; %bb.34:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x20, [x26]
	ldr	w23, [x20]
	cmn	w23, #1
	b.eq	LBB51_60
; %bb.35:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	w0, #47152                      ; =0xb830
	bl	_malloc
	cbz	x0, LBB51_81
; %bb.36:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	x27, x0
	mov	x1, x26
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	add	w8, w23, #1
	str	w8, [x20]
	mov	w8, #28768                      ; =0x7060
	movk	w8, #1, lsl #16
	add	x22, x22, x8
	str	x27, [sp, #2176]
	str	x22, [sp, #104]
	b	LBB51_38
LBB51_37:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	x22, x8
LBB51_38:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x23, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x20, [sp, #96]                  ; 8-byte Folded Reload
LBB51_39:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x27, [x26]
	cbz	x27, LBB51_42
; %bb.40:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	w8, [x27]
	subs	w8, w8, #1
	str	w8, [x27]
	b.ne	LBB51_42
; %bb.41:                               ;   in Loop: Header=BB51_22 Depth=2
	ldr	x0, [x27, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x27
	bl	_free
LBB51_42:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	x0, x26
	bl	_free
	mov	x8, #-47152                     ; =0xffffffffffff47d0
	add	x22, x22, x8
	str	xzr, [sp, #2160]
	str	x22, [sp, #104]
LBB51_43:                               ;   in Loop: Header=BB51_22 Depth=2
	ldrb	w8, [x25, #76]
	cbz	w8, LBB51_20
; %bb.44:                               ;   in Loop: Header=BB51_22 Depth=2
	mov	x24, #0                         ; =0x0
	add	x23, x25, #72
	b	LBB51_47
LBB51_45:                               ;   in Loop: Header=BB51_47 Depth=3
	mov	x0, x26
	bl	_free
	str	xzr, [x20, #2064]
	mov	x8, #-47152                     ; =0xffffffffffff47d0
	add	x22, x22, x8
LBB51_46:                               ;   in Loop: Header=BB51_47 Depth=3
	add	x24, x24, #1
	ldrb	w8, [x25, #76]
	cmp	x24, x8
	b.hs	LBB51_19
LBB51_47:                               ;   Parent Loop BB51_15 Depth=1
                                        ;     Parent Loop BB51_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x20, x28, x24, lsl #3
	ldr	x26, [x20, #2064]
	ldrb	w8, [x26, #40]
	tbz	w8, #0, LBB51_50
; %bb.48:                               ;   in Loop: Header=BB51_47 Depth=3
	ldrh	w8, [x23, x24, lsl #1]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	ldr	x0, [x9, x8, lsl #3]
	cbz	x0, LBB51_53
; %bb.49:                               ;   in Loop: Header=BB51_47 Depth=3
	sub	x2, x29, #89
	mov	x1, x26
	bl	_nvm_file_flow_join
	cbnz	w0, LBB51_59
LBB51_50:                               ;   in Loop: Header=BB51_47 Depth=3
	ldr	x27, [x26]
	cbz	x27, LBB51_45
; %bb.51:                               ;   in Loop: Header=BB51_47 Depth=3
	ldr	w8, [x27]
	subs	w8, w8, #1
	str	w8, [x27]
	b.ne	LBB51_45
; %bb.52:                               ;   in Loop: Header=BB51_47 Depth=3
	ldr	x0, [x27, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x27
	bl	_free
	b	LBB51_45
LBB51_53:                               ;   in Loop: Header=BB51_47 Depth=3
	str	x26, [x9, x8, lsl #3]
	str	xzr, [x20, #2064]
	b	LBB51_46
LBB51_54:                               ;   in Loop: Header=BB51_15 Depth=1
	ldr	w8, [sp, #92]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB51_82
; %bb.55:                               ;   in Loop: Header=BB51_15 Depth=1
	mov	w0, #0                          ; =0x0
	ldp	x8, x26, [sp]                   ; 16-byte Folded Reload
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, x11]
	ldr	x25, [sp, #16]                  ; 8-byte Folded Reload
	add	x25, x25, #1
	ldr	w8, [x21, #24]
	cmp	x25, x8
	mov	w8, #18385                      ; =0x47d1
	movk	w8, #255, lsl #16
	b.lo	LBB51_15
	b	LBB51_61
LBB51_56:
	mov	x0, x21
	bl	_nvm_file_code_free
	mov	w0, #4                          ; =0x4
	b	LBB51_9
LBB51_57:
	mov	x0, x24
	bl	_nvm_file_body_free
	mov	w0, #4                          ; =0x4
	b	LBB51_9
LBB51_58:
	mov	w0, #0                          ; =0x0
	b	LBB51_61
LBB51_59:
	str	x22, [sp, #104]
	b	LBB51_61
LBB51_60:
	mov	w0, #3                          ; =0x3
LBB51_61:
	mov	x20, x0
	add	x0, sp, #104
	add	x1, x28, #2056
	bl	_file_body_release
	mov	w22, #8                         ; =0x8
	ldr	x23, [sp, #104]
	mov	x24, #-47152                    ; =0xffffffffffff47d0
	b	LBB51_64
LBB51_62:                               ;   in Loop: Header=BB51_64 Depth=1
	bl	_free
	str	xzr, [x28, x22]
	add	x23, x23, x24
LBB51_63:                               ;   in Loop: Header=BB51_64 Depth=1
	add	x22, x22, #8
	cmp	x22, #2056
	b.eq	LBB51_68
LBB51_64:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x28, x22]
	cbz	x0, LBB51_63
; %bb.65:                               ;   in Loop: Header=BB51_64 Depth=1
	ldr	x21, [x0]
	cbz	x21, LBB51_62
; %bb.66:                               ;   in Loop: Header=BB51_64 Depth=1
	ldr	w8, [x21]
	subs	w8, w8, #1
	str	w8, [x21]
	b.ne	LBB51_62
; %bb.67:                               ;   in Loop: Header=BB51_64 Depth=1
	ldr	x8, [x21, #16]
	mov	x25, x0
	mov	x0, x8
	bl	_nvm_file_nominal_plan_free
	mov	x0, x21
	bl	_free
	mov	x0, x25
	b	LBB51_62
LBB51_68:
	ldr	x21, [sp, #2168]
	mov	x0, x20
	ldr	x23, [sp, #32]                  ; 8-byte Folded Reload
	cbz	x21, LBB51_73
; %bb.69:
	ldr	x22, [x21]
	cbz	x22, LBB51_72
; %bb.70:
	ldr	w8, [x22]
	subs	w8, w8, #1
	str	w8, [x22]
	b.ne	LBB51_72
; %bb.71:
	ldr	x0, [x22, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x22
	bl	_free
LBB51_72:
	mov	x0, x21
	bl	_free
	mov	x0, x20
LBB51_73:
	ldr	x21, [sp, #2176]
	cbz	x21, LBB51_78
; %bb.74:
	ldr	x22, [x21]
	cbz	x22, LBB51_77
; %bb.75:
	ldr	w8, [x22]
	subs	w8, w8, #1
	str	w8, [x22]
	b.ne	LBB51_77
; %bb.76:
	ldr	x0, [x22, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x22
	bl	_free
LBB51_77:
	mov	x0, x21
	bl	_free
	mov	x0, x20
LBB51_78:
	cbz	w0, LBB51_80
; %bb.79:
	mov	x0, x23
	bl	_nvm_file_body_free
	mov	x0, x20
	b	LBB51_9
LBB51_80:
	str	x23, [x19]
	b	LBB51_9
LBB51_81:
	mov	w0, #4                          ; =0x4
	b	LBB51_61
LBB51_82:
	mov	w0, #1                          ; =0x1
	b	LBB51_61
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_release
_file_body_release:                     ; @file_body_release
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x0, [x1]
	cbz	x0, LBB52_5
; %bb.1:
	mov	x20, x1
	ldr	x21, [x0]
	cbz	x21, LBB52_4
; %bb.2:
	ldr	w8, [x21]
	subs	w8, w8, #1
	str	w8, [x21]
	b.ne	LBB52_4
; %bb.3:
	ldr	x8, [x21, #16]
	mov	x22, x0
	mov	x0, x8
	bl	_nvm_file_nominal_plan_free
	mov	x0, x21
	bl	_free
	mov	x0, x22
LBB52_4:
	bl	_free
	str	xzr, [x20]
	ldr	x8, [x19]
	mov	x9, #-47152                     ; =0xffffffffffff47d0
	add	x8, x8, x9
	str	x8, [x19]
LBB52_5:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_body_function_count ; -- Begin function nvm_file_body_function_count
	.globl	_nvm_file_body_function_count
	.p2align	2
_nvm_file_body_function_count:          ; @nvm_file_body_function_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB53_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB53_3
; %bb.2:
	ldr	w0, [x8, #24]
	ret
LBB53_3:
	mov	w0, #0                          ; =0x0
LBB53_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_body_function ; -- Begin function nvm_file_body_function
	.globl	_nvm_file_body_function
	.p2align	2
_nvm_file_body_function:                ; @nvm_file_body_function
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB54_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB54_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB54_5
; %bb.3:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB54_6
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8, #48]
	ldr	w8, [x8, #80]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB54_5:
	ret
LBB54_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_body_local    ; -- Begin function nvm_file_body_local
	.globl	_nvm_file_body_local
	.p2align	2
_nvm_file_body_local:                   ; @nvm_file_body_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB55_8
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB55_7
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB55_8
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB55_8
; %bb.4:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB55_7
; %bb.5:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB55_7
; %bb.6:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB55_7:
	mov	w0, #0                          ; =0x0
LBB55_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_body_instruction ; -- Begin function nvm_file_body_instruction
	.globl	_nvm_file_body_instruction
	.p2align	2
_nvm_file_body_instruction:             ; @nvm_file_body_instruction
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB56_6
; %bb.1:
	cbz	x3, LBB56_6
; %bb.2:
	cbz	x4, LBB56_6
; %bb.3:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB56_7
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB56_7
; %bb.5:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	w9, w1
	ldr	x10, [x8, #16]
	lsl	x19, x9, #2
	add	x8, x8, x19
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x20, x0
	mov	x0, x3
	mov	x21, x2
	mov	w2, #600                        ; =0x258
	mov	x22, x4
	bl	_memcpy
	ldp	x9, x8, [x20]
	add	x9, x9, x19
	ldr	w9, [x9, #2352]
	add	w9, w9, w21
	mov	w10, #80                        ; =0x50
	umaddl	x8, w9, w10, x8
	ldr	q0, [x8]
	str	q0, [x22]
	ldp	q0, q1, [x8, #48]
	ldp	q3, q2, [x8, #16]
	stp	q0, q1, [x22, #48]
	stp	q3, q2, [x22, #16]
	mov	w8, #1                          ; =0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB56_6:
	mov	x0, x8
	ret
LBB56_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_free   ; -- Begin function nvm_file_hosted_free
	.globl	_nvm_file_hosted_free
	.p2align	2
_nvm_file_hosted_free:                  ; @nvm_file_hosted_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB57_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_file_body_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB57_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_prepare ; -- Begin function nvm_file_hosted_prepare
	.globl	_nvm_file_hosted_prepare
	.p2align	2
_nvm_file_hosted_prepare:               ; @nvm_file_hosted_prepare
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB58_7
; %bb.1:
	sub	sp, sp, #384
	stp	x24, x23, [sp, #320]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #336]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x21, x0
	mov	x22, x2
	sub	x2, x29, #96
	sub	x3, x29, #104
	bl	_file_hosted_preflight
	cbnz	w0, LBB58_9
; %bb.2:
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB58_8
; %bb.3:
	mov	x19, x0
	add	x23, sp, #16
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	str	xzr, [sp, #256]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #208]
	stp	q0, q0, [x23, #176]
	stp	q0, q0, [x23, #144]
	str	q0, [x23, #128]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #8]
	add	x2, sp, #16
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_v2_module_deserialize
	cbnz	w0, LBB58_5
; %bb.4:
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_to_nvm_module
	cbz	w0, LBB58_10
LBB58_5:
	mov	w21, #2                         ; =0x2
LBB58_6:
	ldr	x0, [sp, #8]
	bl	_nvm_module_free
	add	x0, sp, #16
	bl	_nvm_v2_module_free
	mov	x0, x19
	bl	_free
	mov	x0, x21
	b	LBB58_9
LBB58_7:
	mov	w0, #1                          ; =0x1
	ret
LBB58_8:
	mov	w0, #4                          ; =0x4
LBB58_9:
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #352]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #336]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
LBB58_10:
	ldr	x21, [sp, #8]
	cbz	x21, LBB58_5
; %bb.11:
	ldr	w2, [x21, #288]
	ldr	x8, [sp, #192]
	cmp	x8, x2
	b.ne	LBB58_5
; %bb.12:
	ldr	x0, [x21, #280]
	cbz	x0, LBB58_5
; %bb.13:
	ldr	x1, [sp, #184]
	bl	_memcmp
	cbnz	w0, LBB58_5
; %bb.14:
	mov	w0, #1                          ; =0x1
	mov	w1, #4672                       ; =0x1240
	bl	_calloc
	cbz	x0, LBB58_19
; %bb.15:
	mov	x20, x0
	ldur	w8, [x29, #-88]
	str	w8, [x0, #20]
	ldur	x8, [x29, #-104]
	str	x8, [x0, #56]
	mov	x0, x21
	mov	x1, x20
	bl	_nvm_file_body_analyze
	cbnz	w0, LBB58_18
; %bb.16:
	ldr	x2, [sp, #8]
	add	x1, sp, #16
	mov	x0, x20
	bl	_file_hosted_start
	cbnz	w0, LBB58_18
; %bb.17:
	add	x1, sp, #16
	mov	x0, x20
	bl	_file_hosted_bounds
	cbz	w0, LBB58_20
LBB58_18:
	mov	x21, x0
	ldr	x0, [x20]
	bl	_nvm_file_body_free
	mov	x0, x20
	bl	_free
	b	LBB58_6
LBB58_19:
	mov	w21, #4                         ; =0x4
	b	LBB58_6
LBB58_20:
	mov	w21, #0                         ; =0x0
	str	x20, [x22]
	b	LBB58_6
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_preflight
_file_hosted_preflight:                 ; @file_hosted_preflight
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB59_3
; %bb.1:
	mov	w8, #16777216                   ; =0x1000000
	cmp	x1, x8
	b.ls	LBB59_4
; %bb.2:
	mov	w0, #3                          ; =0x3
	ret
LBB59_3:
	mov	w0, #1                          ; =0x1
	ret
LBB59_4:
	sub	sp, sp, #368
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x2
	mov	x23, x3
	mov	x21, x0
	mov	x19, x1
	bl	_nvm_v2_validate
	cbnz	w0, LBB59_44
; %bb.5:
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	bl	_nvm_v2_read_header
	cbnz	w0, LBB59_44
; %bb.6:
	ldr	x8, [x20, #16]
	cmp	x8, x19
	b.ne	LBB59_44
; %bb.7:
	mov	x2, x20
	ldrh	w8, [x20, #6]
	cmp	w8, #2
	b.ne	LBB59_44
; %bb.8:
	ldr	w8, [x2, #8]
	mov	w9, #898                        ; =0x382
	bics	wzr, w9, w8
	b.ne	LBB59_44
; %bb.9:
	mov	w9, #-907                       ; =0xfffffc75
	tst	w8, w9
	b.eq	LBB59_11
; %bb.10:
	mov	w0, #2                          ; =0x2
	b	LBB59_45
LBB59_11:
	str	xzr, [sp, #288]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	str	q0, [sp, #80]
	ldr	w8, [x2, #28]
	cbz	w8, LBB59_44
; %bb.12:
	mov	x1, x19
	mov	w22, #0                         ; =0x0
LBB59_13:                               ; =>This Inner Loop Header: Depth=1
	add	x4, sp, #56
	mov	x0, x21
	mov	x3, x22
	bl	_nvm_v2_read_section
	cbnz	w0, LBB59_44
; %bb.14:                               ;   in Loop: Header=BB59_13 Depth=1
	ldur	q0, [sp, #56]
	str	q0, [sp, #32]
	ldr	x8, [sp, #72]
	str	x8, [sp, #48]
	add	x1, sp, #32
	add	x2, sp, #80
	mov	x0, x21
	bl	_file_hosted_section
	cbnz	w0, LBB59_45
; %bb.15:                               ;   in Loop: Header=BB59_13 Depth=1
	add	w22, w22, #1
	mov	x2, x20
	ldr	w8, [x20, #28]
	cmp	w22, w8
	mov	x1, x19
	b.lo	LBB59_13
; %bb.16:
	ldp	w21, w8, [sp, #96]
	ldr	w9, [sp, #88]
	ldr	x10, [sp, #176]
	str	xzr, [sp, #56]
	cbz	w8, LBB59_44
; %bb.17:
	ldr	w11, [x2, #32]
	mov	w0, #1                          ; =0x1
	cmp	w11, w8
	b.hs	LBB59_45
; %bb.18:
	ldr	x11, [sp, #256]
	cbz	x11, LBB59_45
; %bb.19:
	ldr	x22, [sp, #248]
	cbz	x22, LBB59_45
; %bb.20:
	stp	x10, x8, [sp, #8]               ; 16-byte Folded Spill
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x20, [sp, #192]
	cbz	x20, LBB59_45
; %bb.21:
	add	x1, sp, #56
	mov	x0, x21
	bl	_nvm_file_nominal_storage_bound
	cbz	w0, LBB59_43
; %bb.22:
	ldr	x8, [sp, #264]
	mov	w9, #67108864                   ; =0x4000000
	sub	x9, x9, x19
	cmp	x8, x9
	b.hi	LBB59_43
; %bb.23:
	ldr	x9, [sp, #272]
	tbnz	x9, #63, LBB59_43
; %bb.24:
	lsl	x9, x9, #1
	mov	w11, #67108864                  ; =0x4000000
	add	x10, x19, x8
	sub	x8, x11, x10
	cmp	x9, x8
	b.hi	LBB59_43
; %bb.25:
	lsl	x8, x21, #4
	mov	w11, #67108864                  ; =0x4000000
	add	x9, x10, x9
	sub	x10, x11, x9
	cmp	x8, x10
	b.hi	LBB59_43
; %bb.26:
	mov	w10, #59440                     ; =0xe830
	movk	w10, #767, lsl #16
	add	x8, x9, x8
	cmp	x8, x10
	b.hi	LBB59_43
; %bb.27:
	mov	w9, #6096                       ; =0x17d0
	movk	w9, #256, lsl #16
	add	x8, x8, x9
	str	x8, [sp, #32]
	add	x0, sp, #32
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	w2, #64                         ; =0x40
	mov	w3, #12                         ; =0xc
	bl	_file_hosted_array
	cbz	w0, LBB59_43
; %bb.28:
	add	x0, sp, #32
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	mov	w2, #32                         ; =0x20
	mov	w3, #32                         ; =0x20
	bl	_file_hosted_array
	cbz	w0, LBB59_43
; %bb.29:
	add	x0, sp, #32
	mov	x1, x20
	mov	w2, #4096                       ; =0x1000
	mov	w3, #1                          ; =0x1
	bl	_file_hosted_array
	cbz	w0, LBB59_43
; %bb.30:
	ldr	w1, [sp, #120]
	add	x0, sp, #32
	mov	w2, #256                        ; =0x100
	mov	w3, #12                         ; =0xc
	bl	_file_hosted_array
	cbz	w0, LBB59_43
; %bb.31:
	ldr	w1, [sp, #84]
	add	x0, sp, #32
	mov	w2, #8                          ; =0x8
	mov	w3, #8                          ; =0x8
	bl	_file_hosted_array
	cbz	w0, LBB59_43
; %bb.32:
	ldr	w19, [sp, #112]
	add	x0, sp, #32
	mov	x1, x19
	mov	w2, #32                         ; =0x20
	mov	w3, #20                         ; =0x14
	bl	_file_hosted_array
	cbz	w0, LBB59_43
; %bb.33:
	ldr	x8, [sp, #32]
	mov	w9, #67108800                   ; =0x3ffffc0
	cmp	x8, x9
	b.hi	LBB59_43
; %bb.34:
	ldr	x10, [sp, #280]
	mov	w9, #67108800                   ; =0x3ffffc0
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB59_43
; %bb.35:
	ldrh	w11, [sp, #288]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	add	x9, x19, x9
	mul	x9, x9, x11
	mov	w11, #67108800                  ; =0x3ffffc0
	add	x8, x8, x10
	sub	x10, x11, x8
	cmp	x9, x10
	b.hi	LBB59_43
; %bb.36:
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	tbnz	x10, #63, LBB59_43
; %bb.37:
	add	x10, x8, #64
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	lsl	x8, x8, #1
	mov	w11, #67108864                  ; =0x4000000
	add	x9, x9, x10
	sub	x10, x11, x9
	cmp	x8, x10
	b.hi	LBB59_43
; %bb.38:
	mov	w10, #67108864                  ; =0x4000000
	add	x8, x9, x8
	sub	x9, x10, x8
	cmp	x22, x9
	b.hi	LBB59_43
; %bb.39:
	mov	w9, #65416                      ; =0xff88
	movk	w9, #1023, lsl #16
	add	x8, x8, x22
	cmp	x8, x9
	b.hi	LBB59_43
; %bb.40:
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #2
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB59_43
; %bb.41:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	lsl	x9, x9, #5
	mov	w11, #65416                     ; =0xff88
	movk	w11, #1023, lsl #16
	add	x8, x8, x10
	sub	x10, x11, x8
	cmp	x9, x10
	b.hi	LBB59_43
; %bb.42:
	add	x10, x8, #120
	ldr	x8, [sp, #56]
	mov	w11, #67108864                  ; =0x4000000
	add	x9, x10, x9
	sub	x10, x11, x9
	cmp	x8, x10
	b.ls	LBB59_46
LBB59_43:
	mov	w0, #3                          ; =0x3
	b	LBB59_45
LBB59_44:
	mov	w0, #1                          ; =0x1
LBB59_45:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB59_46:
	mov	w0, #0                          ; =0x0
	add	x8, x9, x8
	str	x8, [x23]
	b	LBB59_45
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_start
_file_hosted_start:                     ; @file_hosted_start
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x8, [x0]
	ldr	x21, [x8]
	ldr	w9, [x1, #4]
	mov	w8, #-1                         ; =0xffffffff
	stp	w9, w8, [x0, #8]
	ldr	w8, [x21, #24]
	str	w8, [x0, #16]
	ldrb	w10, [x2, #8]
	tbz	w10, #0, LBB60_23
; %bb.1:
	ldr	w10, [x2, #12]
	cmp	w10, w9
	b.ne	LBB60_23
; %bb.2:
	mov	w10, #36                        ; =0x24
	umaddl	x9, w9, w10, x21
	ldrh	w10, [x9, #60]
	cbnz	w10, LBB60_6
; %bb.3:
	ldurb	w10, [x9, #64]
	cmp	w10, #1
	b.ne	LBB60_6
; %bb.4:
	ldurb	w10, [x9, #69]
	cbnz	w10, LBB60_6
; %bb.5:
	ldur	w10, [x9, #72]
	cmn	w10, #1
	b.eq	LBB60_7
LBB60_6:
	mov	w8, #2                          ; =0x2
	b	LBB60_24
LBB60_7:
	ldurb	w9, [x9, #68]
	cmp	w9, #4
	ccmp	w9, #1, #4, ne
	b.ne	LBB60_6
; %bb.8:
	cbz	w8, LBB60_24
; %bb.9:
	mov	x22, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	ldr	x24, [x2, #256]
	ldr	w25, [x2, #248]
	add	x8, x8, x8, lsl #3
	lsl	x26, x8, #2
	mov	w19, #-1                        ; =0xffffffff
	b	LBB60_12
LBB60_10:                               ;   in Loop: Header=BB60_12 Depth=1
	mov	w19, #-1                        ; =0xffffffff
LBB60_11:                               ;   in Loop: Header=BB60_12 Depth=1
	mov	w8, #0                          ; =0x0
	add	w23, w23, #1
	add	x22, x22, #36
	cmp	x26, x22
	mov	x2, x28
	mov	x0, x27
	b.eq	LBB60_24
LBB60_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24], #24
	cmp	w8, w25
	b.hs	LBB60_23
; %bb.13:                               ;   in Loop: Header=BB60_12 Depth=1
	ldr	x9, [x2, #232]
	ldr	x20, [x9, x8, lsl #3]
	cbz	x20, LBB60_23
; %bb.14:                               ;   in Loop: Header=BB60_12 Depth=1
	mov	x27, x0
	mov	x28, x2
	ldr	x9, [x2, #240]
	ldr	w2, [x9, x8, lsl #2]
	mov	x0, x20
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB60_23
; %bb.15:                               ;   in Loop: Header=BB60_12 Depth=1
	cmn	w19, #1
	b.ne	LBB60_11
; %bb.16:                               ;   in Loop: Header=BB60_12 Depth=1
	mov	x0, x20
Lloh36:
	adrp	x1, l_.str.3@PAGE
Lloh37:
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB60_10
; %bb.17:                               ;   in Loop: Header=BB60_12 Depth=1
	add	x8, x21, x22
	ldrh	w9, [x8, #60]
	cbnz	w9, LBB60_6
; %bb.18:                               ;   in Loop: Header=BB60_12 Depth=1
	ldrb	w9, [x8, #64]
	cbnz	w9, LBB60_6
; %bb.19:                               ;   in Loop: Header=BB60_12 Depth=1
	add	x9, x21, x22
	ldrb	w10, [x9, #68]
	cbnz	w10, LBB60_6
; %bb.20:                               ;   in Loop: Header=BB60_12 Depth=1
	ldrb	w9, [x9, #69]
	cbnz	w9, LBB60_6
; %bb.21:                               ;   in Loop: Header=BB60_12 Depth=1
	add	x9, x21, x22
	ldr	w9, [x9, #72]
	cmn	w9, #1
	b.ne	LBB60_6
; %bb.22:                               ;   in Loop: Header=BB60_12 Depth=1
	str	w23, [x27, #12]
	mov	x19, x23
	b	LBB60_11
LBB60_23:
	mov	w8, #1                          ; =0x1
LBB60_24:
	mov	x0, x8
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_bounds
_file_hosted_bounds:                    ; @file_hosted_bounds
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	ldr	x9, [x0]
	ldr	x10, [x9]
	ldr	w8, [x10, #24]
	cbz	w8, LBB61_37
; %bb.1:
	mov	x11, #0                         ; =0x0
	add	x12, x10, #2608
	add	x13, x0, #64
	add	x14, x10, #48
	add	x15, x10, #2352
	mov	w16, #72                        ; =0x48
	mov	w17, #36                        ; =0x24
	mov	w2, #65537                      ; =0x10001
	movi.2s	v0, #1, lsl #8
	mov	w3, #49216                      ; =0xc040
	mov	w4, #80                         ; =0x50
LBB61_2:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB61_5 Depth 2
                                        ;     Child Loop BB61_20 Depth 2
	ldr	w7, [x12, x11, lsl #2]
	umaddl	x8, w7, w16, x13
	umaddl	x5, w7, w17, x14
	ldp	q1, q2, [x5]
	ldr	w6, [x5, #32]
	str	w6, [x8, #32]
	stp	q1, q2, [x8]
	ldr	x6, [x1, #72]
	add	x6, x6, x7, lsl #5
	ldrh	w6, [x6, #28]
	strh	w6, [x8, #36]
	ldrh	w19, [x5, #14]
	strh	w19, [x8, #40]
	stur	w2, [x8, #42]
	ldrh	w5, [x5, #8]
	cbz	x5, LBB61_15
; %bb.3:                                ;   in Loop: Header=BB61_2 Depth=1
	ldr	x20, [x9, #8]
	ldr	w22, [x15, x7, lsl #2]
	mov	w21, #1                         ; =0x1
	mov	x23, x5
	b	LBB61_5
LBB61_4:                                ;   in Loop: Header=BB61_5 Depth=2
	add	w22, w22, #1
	subs	x23, x23, #1
	b.eq	LBB61_14
LBB61_5:                                ;   Parent Loop BB61_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umaddl	x24, w22, w4, x20
	ldrb	w25, [x24]
	cmp	w25, #1
	b.ne	LBB61_4
; %bb.6:                                ;   in Loop: Header=BB61_5 Depth=2
	ldrh	w25, [x24, #4]
	ldrh	w26, [x8, #38]
	cmp	w25, w26
	b.ls	LBB61_8
; %bb.7:                                ;   in Loop: Header=BB61_5 Depth=2
	strh	w25, [x8, #38]
	mov	x26, x25
LBB61_8:                                ;   in Loop: Header=BB61_5 Depth=2
	ldrh	w25, [x24, #6]
	cmp	w25, w26
	b.ls	LBB61_10
; %bb.9:                                ;   in Loop: Header=BB61_5 Depth=2
	strh	w25, [x8, #38]
LBB61_10:                               ;   in Loop: Header=BB61_5 Depth=2
	ldrb	w25, [x24, #3]
	cmp	w25, #1
	b.ne	LBB61_4
; %bb.11:                               ;   in Loop: Header=BB61_5 Depth=2
	ldr	w25, [x24, #24]
	cmp	w25, #1
	b.ne	LBB61_4
; %bb.12:                               ;   in Loop: Header=BB61_5 Depth=2
	ldrh	w24, [x24, #48]
	cmp	w24, w21, uxth
	b.lo	LBB61_4
; %bb.13:                               ;   in Loop: Header=BB61_5 Depth=2
	add	w21, w24, #1
	strh	w21, [x8, #42]
	b	LBB61_4
LBB61_14:                               ;   in Loop: Header=BB61_2 Depth=1
	and	x22, x21, #0xffff
	b	LBB61_16
LBB61_15:                               ;   in Loop: Header=BB61_2 Depth=1
	mov	w22, #1                         ; =0x1
LBB61_16:                               ;   in Loop: Header=BB61_2 Depth=1
	ldrh	w20, [x8, #38]
	cmp	w6, #0
	ccmp	w6, w20, #2, ne
	b.lo	LBB61_59
; %bb.17:                               ;   in Loop: Header=BB61_2 Depth=1
	add	x6, x20, x19
	add	x6, x6, x22
	stp	x6, x6, [x8, #56]
	cbz	w5, LBB61_33
; %bb.18:                               ;   in Loop: Header=BB61_2 Depth=1
	ldr	w20, [x15, x7, lsl #2]
	ldr	x21, [x9, #8]
	add	x22, x22, x19
	mov	w23, #1                         ; =0x1
	mov	x7, x6
	mov	x19, x6
	b	LBB61_20
LBB61_19:                               ;   in Loop: Header=BB61_20 Depth=2
	add	w20, w20, #1
	subs	x5, x5, #1
	b.eq	LBB61_32
LBB61_20:                               ;   Parent Loop BB61_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umaddl	x24, w20, w4, x21
	ldrb	w25, [x24]
	cmp	w25, #1
	b.ne	LBB61_19
; %bb.21:                               ;   in Loop: Header=BB61_20 Depth=2
	ldrb	w25, [x24, #3]
	cmp	w25, #1
	b.ne	LBB61_19
; %bb.22:                               ;   in Loop: Header=BB61_20 Depth=2
	ldr	w25, [x24, #24]
	cmp	w25, #1
	b.ne	LBB61_19
; %bb.23:                               ;   in Loop: Header=BB61_20 Depth=2
	ldr	w25, [x24, #32]
	ldr	w26, [x10, #24]
	cmp	w25, w26
	b.hs	LBB61_59
; %bb.24:                               ;   in Loop: Header=BB61_20 Depth=2
	ldrh	w26, [x24, #52]
	ldrh	w27, [x24, #48]
	subs	w26, w27, w26
	b.lo	LBB61_59
; %bb.25:                               ;   in Loop: Header=BB61_20 Depth=2
	ldrh	w27, [x24, #4]
	cmp	w26, w27
	b.hi	LBB61_59
; %bb.26:                               ;   in Loop: Header=BB61_20 Depth=2
	umaddl	x24, w25, w16, x13
	ldr	x25, [x24, #56]
	sub	x26, x22, w26, uxtw
	add	x26, x26, x27
	add	x25, x26, x25
	cmp	x25, x19
	b.ls	LBB61_28
; %bb.27:                               ;   in Loop: Header=BB61_20 Depth=2
	str	x25, [x8, #56]
	mov	x19, x25
LBB61_28:                               ;   in Loop: Header=BB61_20 Depth=2
	ldr	x25, [x24, #64]
	add	x25, x25, x6
	cmp	x25, x7
	b.ls	LBB61_30
; %bb.29:                               ;   in Loop: Header=BB61_20 Depth=2
	str	x25, [x8, #64]
	mov	x7, x25
LBB61_30:                               ;   in Loop: Header=BB61_20 Depth=2
	ldrh	w24, [x24, #44]
	cmp	w24, w23, uxth
	b.lo	LBB61_19
; %bb.31:                               ;   in Loop: Header=BB61_20 Depth=2
	add	w23, w24, #1
	strh	w23, [x8, #44]
	b	LBB61_19
LBB61_32:                               ;   in Loop: Header=BB61_2 Depth=1
	and	w5, w23, #0xffff
	ubfiz	w6, w23, #8, #16
	stp	w6, w6, [x8, #48]
	cmp	w5, #64
	b.ls	LBB61_34
	b	LBB61_62
LBB61_33:                               ;   in Loop: Header=BB61_2 Depth=1
	str	d0, [x8, #48]
	mov	x19, x6
	mov	x7, x6
LBB61_34:                               ;   in Loop: Header=BB61_2 Depth=1
	mov	w8, #3                          ; =0x3
	cmp	x19, x3
	b.hi	LBB61_61
; %bb.35:                               ;   in Loop: Header=BB61_2 Depth=1
	cmp	x7, x3
	b.hi	LBB61_61
; %bb.36:                               ;   in Loop: Header=BB61_2 Depth=1
	add	x11, x11, #1
	ldr	w8, [x10, #24]
	cmp	x11, x8
	b.lo	LBB61_2
LBB61_37:
	ldp	w10, w8, [x0, #8]
	add	x9, x0, #64
	cmn	w10, #1
	b.eq	LBB61_48
; %bb.38:
	mov	w11, #72                        ; =0x48
	umaddl	x10, w10, w11, x9
	ldr	x11, [x10, #56]
	ldr	x12, [x0, #24]
	cmp	x11, x12
	b.ls	LBB61_40
; %bb.39:
	str	x11, [x0, #24]
LBB61_40:
	ldr	x11, [x10, #64]
	ldr	x12, [x0, #32]
	cmp	x11, x12
	b.ls	LBB61_42
; %bb.41:
	str	x11, [x0, #32]
LBB61_42:
	ldrh	w11, [x10, #44]
	ldrh	w12, [x0, #40]
	cmp	w11, w12
	b.ls	LBB61_44
; %bb.43:
	strh	w11, [x0, #40]
LBB61_44:
	ldr	w11, [x10, #48]
	ldr	w12, [x0, #44]
	cmp	w11, w12
	b.ls	LBB61_46
; %bb.45:
	str	w11, [x0, #44]
LBB61_46:
	ldr	w10, [x10, #52]
	ldr	w11, [x0, #48]
	cmp	w10, w11
	b.ls	LBB61_48
; %bb.47:
	str	w10, [x0, #48]
LBB61_48:
	cmn	w8, #1
	b.eq	LBB61_60
; %bb.49:
	mov	w10, #72                        ; =0x48
	umaddl	x8, w8, w10, x9
	ldr	x9, [x8, #56]
	ldr	x10, [x0, #24]
	cmp	x9, x10
	b.ls	LBB61_51
; %bb.50:
	str	x9, [x0, #24]
LBB61_51:
	ldr	x9, [x8, #64]
	ldr	x10, [x0, #32]
	cmp	x9, x10
	b.ls	LBB61_53
; %bb.52:
	str	x9, [x0, #32]
LBB61_53:
	ldrh	w9, [x8, #44]
	ldrh	w10, [x0, #40]
	cmp	w9, w10
	b.ls	LBB61_55
; %bb.54:
	strh	w9, [x0, #40]
LBB61_55:
	ldr	w9, [x8, #48]
	ldr	w10, [x0, #44]
	cmp	w9, w10
	b.ls	LBB61_57
; %bb.56:
	str	w9, [x0, #44]
LBB61_57:
	ldr	w9, [x8, #52]
	ldr	w8, [x0, #48]
	cmp	w9, w8
	b.ls	LBB61_60
; %bb.58:
	mov	w8, #0                          ; =0x0
	str	w9, [x0, #48]
	b	LBB61_61
LBB61_59:
	mov	w8, #1                          ; =0x1
	b	LBB61_61
LBB61_60:
	mov	w8, #0                          ; =0x0
LBB61_61:
	mov	x0, x8
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB61_62:
	mov	w8, #3                          ; =0x3
	b	LBB61_61
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_startup ; -- Begin function nvm_file_hosted_startup
	.globl	_nvm_file_hosted_startup
	.p2align	2
_nvm_file_hosted_startup:               ; @nvm_file_hosted_startup
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB62_2
; %bb.1:
	ldur	q0, [x8, #8]
	ldur	q1, [x8, #24]
	ldur	q2, [x8, #40]
	ldr	x8, [x8, #56]
	str	x8, [x1, #48]
	stp	q1, q2, [x1, #16]
	str	q0, [x1]
LBB62_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_function ; -- Begin function nvm_file_hosted_function
	.globl	_nvm_file_hosted_function
	.p2align	2
_nvm_file_hosted_function:              ; @nvm_file_hosted_function
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB63_4
; %bb.1:
	cbz	x2, LBB63_4
; %bb.2:
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB63_5
; %bb.3:
	mov	w9, #72                         ; =0x48
	umaddl	x8, w1, w9, x8
	ldr	q0, [x8, #64]
	str	q0, [x2]
	ldp	q0, q1, [x8, #80]
	ldr	q2, [x8, #112]
	ldr	x8, [x8, #128]
	str	x8, [x2, #64]
	stp	q1, q2, [x2, #32]
	str	q0, [x2, #16]
	mov	w0, #1                          ; =0x1
LBB63_4:
	ret
LBB63_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_local  ; -- Begin function nvm_file_hosted_local
	.globl	_nvm_file_hosted_local
	.p2align	2
_nvm_file_hosted_local:                 ; @nvm_file_hosted_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB64_9
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB64_8
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB64_8
; %bb.3:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB64_9
; %bb.4:
	ldr	x8, [x8]
	cbz	x8, LBB64_9
; %bb.5:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB64_8
; %bb.6:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB64_8
; %bb.7:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB64_8:
	mov	w0, #0                          ; =0x0
LBB64_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_instruction ; -- Begin function nvm_file_hosted_instruction
	.globl	_nvm_file_hosted_instruction
	.p2align	2
_nvm_file_hosted_instruction:           ; @nvm_file_hosted_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB65_9
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x4, LBB65_9
; %bb.2:
	cbz	x3, LBB65_9
; %bb.3:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x19, [x8]
	cbz	x19, LBB65_8
; %bb.4:
	ldr	x8, [x19]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB65_7
; %bb.5:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB65_7
; %bb.6:
	mov	w9, w1
	ldr	x10, [x8, #16]
	lsl	x20, x9, #2
	add	x8, x8, x20
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x0, x3
	mov	x21, x2
	mov	w2, #600                        ; =0x258
	mov	x22, x4
	bl	_memcpy
	ldp	x9, x8, [x19]
	add	x9, x9, x20
	ldr	w9, [x9, #2352]
	add	w9, w9, w21
	mov	w10, #80                        ; =0x50
	umaddl	x8, w9, w10, x8
	ldr	q0, [x8]
	str	q0, [x22]
	ldp	q0, q1, [x8, #48]
	ldp	q3, q2, [x8, #16]
	stp	q0, q1, [x22, #48]
	stp	q3, q2, [x22, #16]
	mov	w0, #1                          ; =0x1
	b	LBB65_8
LBB65_7:
	mov	w0, #0                          ; =0x0
LBB65_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB65_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_type   ; -- Begin function nvm_file_hosted_type
	.globl	_nvm_file_hosted_type
	.p2align	2
_nvm_file_hosted_type:                  ; @nvm_file_hosted_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB66_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_type
LBB66_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_hosted_import ; -- Begin function nvm_file_hosted_import
	.globl	_nvm_file_hosted_import
	.p2align	2
_nvm_file_hosted_import:                ; @nvm_file_hosted_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB67_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_import
LBB67_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_free   ; -- Begin function nvm_file_cyclic_free
	.globl	_nvm_file_cyclic_free
	.p2align	2
_nvm_file_cyclic_free:                  ; @nvm_file_cyclic_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB68_15
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	ldr	x0, [x0, #8]
	cbz	x0, LBB68_9
; %bb.2:
	ldr	x8, [x19]
	ldr	w9, [x8, #32]
	cbz	w9, LBB68_9
; %bb.3:
	mov	x20, #0                         ; =0x0
	mov	w21, #8                         ; =0x8
	mov	w22, #136                       ; =0x88
	b	LBB68_5
LBB68_4:                                ;   in Loop: Header=BB68_5 Depth=1
	add	x20, x20, #1
	ldr	w9, [x8, #32]
	add	x21, x21, #136
	cmp	x20, x9
	b.hs	LBB68_9
LBB68_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB68_7 Depth 2
	mul	x9, x20, x22
	ldrb	w9, [x0, x9]
	cbz	w9, LBB68_4
; %bb.6:                                ;   in Loop: Header=BB68_5 Depth=1
	mov	x23, #0                         ; =0x0
	mov	x24, x21
LBB68_7:                                ;   Parent Loop BB68_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x0, [x0, x24]
	bl	_free
	add	x23, x23, #1
	ldr	x0, [x19, #8]
	mul	x8, x20, x22
	ldrb	w8, [x0, x8]
	add	x24, x24, #8
	cmp	x23, x8
	b.lo	LBB68_7
; %bb.8:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	x8, [x19]
	b	LBB68_4
LBB68_9:
	bl	_free
	ldr	x20, [x19]
	cbz	x20, LBB68_14
; %bb.10:
	ldr	x21, [x20]
	cbz	x21, LBB68_13
; %bb.11:
	ldr	w8, [x21]
	subs	w8, w8, #1
	str	w8, [x21]
	b.ne	LBB68_13
; %bb.12:
	ldr	x0, [x21, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x21
	bl	_free
LBB68_13:
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #8]
	bl	_free
	mov	x0, x20
	bl	_free
LBB68_14:
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	b	_free
LBB68_15:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_analyze ; -- Begin function nvm_file_cyclic_analyze
	.globl	_nvm_file_cyclic_analyze
	.p2align	2
_nvm_file_cyclic_analyze:               ; @nvm_file_cyclic_analyze
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	b	_file_cyclic_analyze_extended
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_analyze_extended
_file_cyclic_analyze_extended:          ; @file_cyclic_analyze_extended
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x28, x27, [sp, #224]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #240]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #256]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x1, LBB70_3
; %bb.1:
	mov	x19, x2
	mov	x20, x0
	mov	x22, x1
	cbz	x2, LBB70_4
; %bb.2:
	ldr	x23, [x19]
	b	LBB70_5
LBB70_3:
	mov	w26, #1                         ; =0x1
	b	LBB70_21
LBB70_4:
	mov	x23, #0                         ; =0x0
LBB70_5:
	sub	x1, x29, #96
	sub	x2, x29, #104
	mov	x0, x20
	bl	_file_code_preflight
	mov	x26, x0
	cbnz	w0, LBB70_21
; %bb.6:
	ldr	w8, [x20, #272]
	cbz	w8, LBB70_9
; %bb.7:
	ldr	x9, [x20, #256]
	cmp	w8, #4
	b.hs	LBB70_10
; %bb.8:
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	b	LBB70_13
LBB70_9:
	mov	w24, #1816                      ; =0x718
	b	LBB70_16
LBB70_10:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x8, #0xfffffffc
	add	x15, x9, #64
	mov	x16, x10
LBB70_11:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w17, [x15, #-48]
	ldurh	w0, [x15, #-24]
	ldrh	w1, [x15]
	add	x11, x11, x17
	add	x12, x12, x0
	ldrh	w17, [x15, #24]
	add	x13, x13, x1
	add	x14, x14, x17
	add	x15, x15, #96
	subs	x16, x16, #4
	b.ne	LBB70_11
; %bb.12:
	add	x11, x12, x11
	add	x12, x14, x13
	add	x11, x12, x11
	cmp	x10, x8
	b.eq	LBB70_15
LBB70_13:
	sub	x8, x8, x10
	mov	w12, #24                        ; =0x18
	umaddl	x9, w10, w12, x9
	add	x9, x9, #16
LBB70_14:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x9], #24
	add	x11, x11, x10
	subs	x8, x8, #1
	b.ne	LBB70_14
LBB70_15:
	lsl	x8, x11, #4
	add	x24, x8, #1816
LBB70_16:
	mov	w9, #65480                      ; =0xffc8
	movk	w9, #255, lsl #16
	ldur	x8, [x29, #-104]
	cmp	x8, x9
	b.hi	LBB70_20
; %bb.17:
	ldur	w21, [x29, #-96]
	add	x10, x21, w21, uxtw #4
	lsl	x10, x10, #3
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB70_20
; %bb.18:
	add	x8, x8, x10
	add	x8, x8, #56
	mov	w9, #23912                      ; =0x5d68
	movk	w9, #254, lsl #16
	sub	x10, x9, x8
	cmp	x8, x9
	ccmp	x24, x10, #2, ls
	b.hi	LBB70_20
; %bb.19:
	mov	w9, #41624                      ; =0xa298
	movk	w9, #1, lsl #16
	add	x8, x8, x24
	add	x8, x8, x9
	mov	w9, #16777216                   ; =0x1000000
	sub	x9, x9, x8
	cmp	x23, x9
	b.ls	LBB70_22
LBB70_20:
	mov	w26, #3                         ; =0x3
LBB70_21:
	mov	x0, x26
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #272]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #256]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #240]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
LBB70_22:
	cmp	x19, #0
	cset	w3, ne
	add	x23, x8, x23
	stp	xzr, x23, [x29, #-112]
	sub	x1, x29, #112
	mov	x0, x20
	mov	w2, #0                          ; =0x0
	bl	_file_code_prepare_profile
	mov	x26, x0
	cbnz	w0, LBB70_21
; %bb.23:
	cbz	x19, LBB70_32
; %bb.24:
	ldur	x20, [x29, #-112]
	ldr	w8, [x20, #24]
	cbz	w8, LBB70_32
; %bb.25:
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x20, #2608
	mov	w12, #1                         ; =0x1
LBB70_26:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB70_28 Depth 2
	mov	x13, #0                         ; =0x0
	mvn	x14, x10
	b	LBB70_28
LBB70_27:                               ;   in Loop: Header=BB70_28 Depth=2
	add	x13, x13, #1
	cmp	x8, x13
	b.eq	LBB70_125
LBB70_28:                               ;   Parent Loop BB70_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x15, x10, x13
	tbnz	w15, #0, LBB70_27
; %bb.29:                               ;   in Loop: Header=BB70_28 Depth=2
	ldr	x15, [x19, #8]
	ldr	x15, [x15, x13, lsl #3]
	tst	x15, x14
	b.ne	LBB70_27
; %bb.30:                               ;   in Loop: Header=BB70_26 Depth=1
	cmp	w8, w13
	b.eq	LBB70_125
; %bb.31:                               ;   in Loop: Header=BB70_26 Depth=1
	str	w13, [x11, x9, lsl #2]
	lsl	x13, x12, x13
	orr	x10, x13, x10
	add	x9, x9, #1
	cmp	x9, x8
	b.lo	LBB70_26
LBB70_32:
	mov	w20, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #56                         ; =0x38
	bl	_calloc
	ldur	x28, [x29, #-112]
	cbz	x0, LBB70_130
; %bb.33:
	str	x28, [x0]
	ldr	w8, [x28, #24]
	stp	w20, w8, [x0, #16]
	str	w21, [x0, #24]
	str	x23, [x0, #40]
	mov	x8, x0
	mov	x0, x21
	mov	w1, #136                        ; =0x88
	mov	x20, x8
	bl	_calloc
	mov	x25, x0
	stur	x20, [x29, #-120]               ; 8-byte Folded Spill
	str	x0, [x20, #8]
	mov	w0, #1                          ; =0x1
	mov	w1, #41624                      ; =0xa298
	movk	w1, #1, lsl #16
	bl	_calloc
	mov	x21, x0
	mov	x0, x24
	bl	_malloc
	mov	x20, x0
	mov	w26, #4                         ; =0x4
	cbz	x25, LBB70_143
; %bb.34:
	cbz	x21, LBB70_143
; %bb.35:
	cbz	x20, LBB70_143
; %bb.36:
	ldr	x1, [x28]
	mov	x0, x20
	mov	x2, x24
	bl	_memcpy
	mov	w24, #1                         ; =0x1
	str	w24, [x20]
	str	x28, [x21]
	ldr	w8, [x28, #24]
	cbz	w8, LBB70_124
; %bb.37:
	mov	x10, #0                         ; =0x0
	add	x8, x21, #26, lsl #12           ; =106496
	add	x27, x8, #152
	add	x8, x21, #23, lsl #12           ; =94208
	add	x9, x8, #2192
	mov	w8, #47232                      ; =0xb880
	add	x8, x21, x8
	stp	x8, x20, [sp, #128]             ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x0, x8, #152
	add	x11, x20, #1816
	add	x8, x20, #1560
	stp	x8, x11, [sp, #40]              ; 16-byte Folded Spill
	mov	w8, #14464                      ; =0x3880
	add	x8, x21, x8
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	add	x8, x21, #19, lsl #12           ; =77824
	add	x8, x8, #2192
	stp	x8, x9, [sp, #80]               ; 16-byte Folded Spill
	mov	w8, #14496                      ; =0x38a0
	add	x8, x21, x8
	stp	x0, x8, [sp, #56]               ; 16-byte Folded Spill
	add	x8, x21, #16
	stp	x8, x28, [sp, #16]              ; 16-byte Folded Spill
	add	x8, x28, #2608
	mov	w23, #600                       ; =0x258
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB70_38:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB70_41 Depth 2
                                        ;       Child Loop BB70_44 Depth 3
                                        ;         Child Loop BB70_49 Depth 4
                                        ;         Child Loop BB70_69 Depth 4
                                        ;     Child Loop BB70_74 Depth 2
                                        ;       Child Loop BB70_77 Depth 3
                                        ;     Child Loop BB70_84 Depth 2
                                        ;     Child Loop BB70_92 Depth 2
                                        ;       Child Loop BB70_116 Depth 3
	str	x10, [sp, #32]                  ; 8-byte Folded Spill
	ldr	w10, [x8, x10, lsl #2]
	str	xzr, [x9]
	ldur	x8, [x29, #-120]                ; 8-byte Folded Reload
	ldr	x20, [x8]
	stur	x10, [x29, #-128]               ; 8-byte Folded Spill
	add	x8, x10, w10, uxtw #3
	lsl	x8, x8, #2
	add	x26, x20, x8
	ldrh	w28, [x26, #56]
	mov	w1, #8192                       ; =0x2000
	bl	_bzero
	ldr	x6, [sp, #56]                   ; 8-byte Folded Reload
	mov	w7, #136                        ; =0x88
	cbz	x28, LBB70_81
; %bb.39:                               ;   in Loop: Header=BB70_38 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20, #16]
	ldur	x8, [x29, #-128]                ; 8-byte Folded Reload
	add	x8, x20, x8, lsl #2
	ldr	w8, [x8, #2352]
	add	x11, x10, #86
	add	x12, x10, #72
	b	LBB70_41
LBB70_40:                               ;   in Loop: Header=BB70_41 Depth=2
	add	x9, x9, #1
	cmp	x9, x28
	b.eq	LBB70_71
LBB70_41:                               ;   Parent Loop BB70_38 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB70_44 Depth 3
                                        ;         Child Loop BB70_49 Depth 4
                                        ;         Child Loop BB70_69 Depth 4
	strh	w9, [x27]
	mov	w17, #1                         ; =0x1
	lsl	x14, x17, x9
	lsr	w15, w9, #6
	add	x13, x6, x9, lsl #5
	ldr	x16, [x13, x15, lsl #3]
	orr	x14, x16, x14
	str	x14, [x13, x15, lsl #3]
                                        ; kill: def $w17 killed $w17 killed $x17 def $x17
	b	LBB70_44
LBB70_42:                               ;   in Loop: Header=BB70_44 Depth=3
	mov	x17, x16
LBB70_43:                               ;   in Loop: Header=BB70_44 Depth=3
	tst	w17, #0xffff
	b.eq	LBB70_40
LBB70_44:                               ;   Parent Loop BB70_38 Depth=1
                                        ;     Parent Loop BB70_41 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB70_49 Depth 4
                                        ;         Child Loop BB70_69 Depth 4
	sub	w16, w17, #1
	and	x14, x16, #0xffff
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	ldrh	w14, [x27, x14, lsl #1]
	add	w14, w8, w14
	umaddl	x15, w14, w23, x10
	ldrb	w15, [x15, #76]
	cbz	w15, LBB70_42
; %bb.45:                               ;   in Loop: Header=BB70_44 Depth=3
	cmp	w15, #8
	b.hs	LBB70_47
; %bb.46:                               ;   in Loop: Header=BB70_44 Depth=3
	mov	x0, #0                          ; =0x0
	b	LBB70_66
LBB70_47:                               ;   in Loop: Header=BB70_44 Depth=3
	mov	x17, #0                         ; =0x0
	and	x0, x15, #0xf8
	neg	x0, x0
	umaddl	x1, w14, w23, x11
	b	LBB70_49
LBB70_48:                               ;   in Loop: Header=BB70_49 Depth=4
	add	x1, x1, #16
	sub	x17, x17, #8
	cmp	x0, x17
	b.eq	LBB70_65
LBB70_49:                               ;   Parent Loop BB70_38 Depth=1
                                        ;     Parent Loop BB70_41 Depth=2
                                        ;       Parent Loop BB70_44 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldurh	w2, [x1, #-14]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_51
; %bb.50:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	and	x3, x16, #0xffff
	add	w16, w16, #1
	strh	w2, [x27, x3, lsl #1]
                                        ; kill: def $w16 killed $w16 def $x16
LBB70_51:                               ;   in Loop: Header=BB70_49 Depth=4
	ldurh	w2, [x1, #-12]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_53
; %bb.52:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
LBB70_53:                               ;   in Loop: Header=BB70_49 Depth=4
	ldurh	w2, [x1, #-10]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_55
; %bb.54:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
LBB70_55:                               ;   in Loop: Header=BB70_49 Depth=4
	ldurh	w2, [x1, #-8]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_57
; %bb.56:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
LBB70_57:                               ;   in Loop: Header=BB70_49 Depth=4
	ldurh	w2, [x1, #-6]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_59
; %bb.58:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
LBB70_59:                               ;   in Loop: Header=BB70_49 Depth=4
	ldurh	w2, [x1, #-4]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_61
; %bb.60:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
LBB70_61:                               ;   in Loop: Header=BB70_49 Depth=4
	ldurh	w2, [x1, #-2]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_63
; %bb.62:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
LBB70_63:                               ;   in Loop: Header=BB70_49 Depth=4
	ldrh	w2, [x1]
	lsl	x3, x24, x2
	lsr	x4, x2, #3
	and	x4, x4, #0x1ff8
	ldr	x5, [x13, x4]
	tst	x3, x5
	b.ne	LBB70_48
; %bb.64:                               ;   in Loop: Header=BB70_49 Depth=4
	orr	x3, x3, x5
	str	x3, [x13, x4]
	add	w3, w16, #1
                                        ; kill: def $w16 killed $w16 killed $x16 def $x16
	and	x16, x16, #0xffff
	strh	w2, [x27, x16, lsl #1]
	mov	x16, x3
	b	LBB70_48
LBB70_65:                               ;   in Loop: Header=BB70_44 Depth=3
	neg	x0, x17
LBB70_66:                               ;   in Loop: Header=BB70_44 Depth=3
	mov	x17, x16
	and	x15, x15, #0x7
	cbz	x15, LBB70_43
; %bb.67:                               ;   in Loop: Header=BB70_44 Depth=3
	lsl	x17, x0, #1
	umaddl	x14, w14, w23, x17
	add	x14, x12, x14
	mov	x17, x16
	b	LBB70_69
LBB70_68:                               ;   in Loop: Header=BB70_69 Depth=4
	subs	x15, x15, #1
	b.eq	LBB70_43
LBB70_69:                               ;   Parent Loop BB70_38 Depth=1
                                        ;     Parent Loop BB70_41 Depth=2
                                        ;       Parent Loop BB70_44 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldrh	w16, [x14], #2
	lsl	x0, x24, x16
	lsr	x1, x16, #3
	and	x1, x1, #0x1ff8
	ldr	x2, [x13, x1]
	tst	x0, x2
	b.ne	LBB70_68
; %bb.70:                               ;   in Loop: Header=BB70_69 Depth=4
	orr	x0, x0, x2
	str	x0, [x13, x1]
	and	x0, x17, #0xffff
	add	w17, w17, #1
	strh	w16, [x27, x0, lsl #1]
                                        ; kill: def $w17 killed $w17 def $x17
	b	LBB70_68
LBB70_71:                               ;   in Loop: Header=BB70_38 Depth=1
	mov	x9, #0                          ; =0x0
	ldur	x10, [x29, #-120]               ; 8-byte Folded Reload
	ldr	x10, [x10, #8]
	b	LBB70_74
LBB70_72:                               ;   in Loop: Header=BB70_74 Depth=2
	mov	x12, x9
	mov	x11, x9
LBB70_73:                               ;   in Loop: Header=BB70_74 Depth=2
	add	w12, w12, w8
	umaddl	x12, w12, w7, x10
	strh	w11, [x12, #2]
	add	x9, x9, #1
	cmp	x9, x28
	b.eq	LBB70_81
LBB70_74:                               ;   Parent Loop BB70_38 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB70_77 Depth 3
	cbz	x9, LBB70_80
; %bb.75:                               ;   in Loop: Header=BB70_74 Depth=2
	mov	x11, #0                         ; =0x0
	lsr	x12, x9, #6
	add	x12, x6, x12, lsl #3
	lsl	x13, x24, x9
	b	LBB70_77
LBB70_76:                               ;   in Loop: Header=BB70_77 Depth=3
	add	x11, x11, #1
	add	x12, x12, #32
	cmp	x9, x11
	b.eq	LBB70_72
LBB70_77:                               ;   Parent Loop BB70_38 Depth=1
                                        ;     Parent Loop BB70_74 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	w14, w11, #6
	add	x15, x6, x9, lsl #5
	ldr	x14, [x15, x14, lsl #3]
	lsr	x14, x14, x11
	tbz	w14, #0, LBB70_76
; %bb.78:                               ;   in Loop: Header=BB70_77 Depth=3
	ldr	x14, [x12]
	tst	x14, x13
	b.eq	LBB70_76
; %bb.79:                               ;   in Loop: Header=BB70_74 Depth=2
	mov	x12, x9
	b	LBB70_73
LBB70_80:                               ;   in Loop: Header=BB70_74 Depth=2
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	b	LBB70_73
LBB70_81:                               ;   in Loop: Header=BB70_38 Depth=1
	ldr	x20, [sp, #128]                 ; 8-byte Folded Reload
	mov	x0, x20
	mov	w1, #32784                      ; =0x8010
	bl	_bzero
	ldrh	w8, [x26, #62]
	strh	w8, [x20]
	ldr	x20, [sp, #136]                 ; 8-byte Folded Reload
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	mov	w28, #2192                      ; =0x890
	movk	w28, #1, lsl #16
	mov	w1, #47264                      ; =0xb8a0
	mov	w2, #47265                      ; =0xb8a1
	cbz	w8, LBB70_87
; %bb.82:                               ;   in Loop: Header=BB70_38 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldur	x10, [x29, #-128]               ; 8-byte Folded Reload
	ldr	w9, [x9, x10, lsl #2]
	mov	x10, x21
	mov	w11, #1                         ; =0x1
	b	LBB70_84
LBB70_83:                               ;   in Loop: Header=BB70_84 Depth=2
	add	x8, x8, #1
	ldurh	w12, [x26, #62]
	add	x10, x10, #40
	cmp	x8, x12
	b.hs	LBB70_87
LBB70_84:                               ;   Parent Loop BB70_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x10, x1
	add	w12, w9, w8
	add	x12, x0, w12, uxtw #4
	ldr	q0, [x12]
	ldp	x12, x14, [x12]
	ldurh	w15, [x26, #60]
	tst	x12, #0xff00
	cset	w16, eq
	lsr	x17, x14, #32
	sub	x17, x17, #1
	cmp	x17, #2
	cset	w17, lo
	ands	w16, w16, w17
	add	x16, x11, x16
	csel	x17, x11, xzr, ne
	cmp	x8, x15
	csel	x11, x11, x16, hs
	csel	x16, xzr, x17, hs
	lsr	x14, x14, #33
	cmp	x14, #1
	cset	w14, eq
	str	q0, [x10, #47248]
	add	x17, x10, x2
	str	wzr, [x17]
	stur	wzr, [x17, #3]
	str	x16, [x13, #8]
	stp	w14, wzr, [x13, #16]
	cmp	x8, x15
	cset	w14, lo
	strb	w14, [x13]
	b.hs	LBB70_83
; %bb.85:                               ;   in Loop: Header=BB70_84 Depth=2
	ubfx	w12, w12, #8, #8
	cbz	w12, LBB70_83
; %bb.86:                               ;   in Loop: Header=BB70_84 Depth=2
	strb	w24, [x10, x28]
	add	x13, x8, #257
	add	x14, x10, x28
	strb	w24, [x14, #1]
	cmp	w12, #1
	cset	w12, eq
	strh	w8, [x14, #2]
	str	wzr, [x14, #4]
	stp	x13, x13, [x14, #8]
	str	xzr, [x14, #24]
	strb	w12, [x14, #32]
	stur	wzr, [x14, #33]
	str	wzr, [x14, #36]
	b	LBB70_83
LBB70_87:                               ;   in Loop: Header=BB70_38 Depth=1
	add	x0, x21, #96
	mov	w1, #14368                      ; =0x3820
	bl	_bzero
	str	x20, [x21, #80]
	str	x24, [x21, #104]
	strb	w24, [x21, #120]
	mov	w8, #1025                       ; =0x401
	str	x8, [x20, #8]
	ldur	x25, [x29, #-128]               ; 8-byte Folded Reload
	stp	w25, wzr, [x21, #88]
	mov	w8, #47248                      ; =0xb890
	add	x1, x21, x8
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	mov	w2, #10240                      ; =0x2800
	bl	_memcpy
	mov	w8, #24704                      ; =0x6080
	add	x0, x21, x8
	mov	w8, #57488                      ; =0xe090
	add	x1, x21, x8
	mov	w2, #10240                      ; =0x2800
	bl	_memcpy
	mov	w8, #34944                      ; =0x8880
	add	x0, x21, x8
	add	x1, x21, x28
	mov	w2, #10240                      ; =0x2800
	bl	_memcpy
	mov	w8, #45184                      ; =0xb080
	add	x0, x21, x8
	mov	w8, #12432                      ; =0x3090
	movk	w8, #1, lsl #16
	add	x1, x21, x8
	mov	w2, #2048                       ; =0x800
	bl	_memcpy
	mov	x0, x21
	bl	_file_cyclic_canonicalize
	cbnz	w0, LBB70_146
; %bb.88:                               ;   in Loop: Header=BB70_38 Depth=1
	sub	x4, x29, #89
	ldur	x0, [x29, #-120]                ; 8-byte Folded Reload
	mov	x1, x21
	mov	x2, x25
	mov	w3, #0                          ; =0x0
	bl	_file_cyclic_intern
	cbnz	w0, LBB70_146
; %bb.89:                               ;   in Loop: Header=BB70_38 Depth=1
	str	x21, [sp, #152]                 ; 8-byte Folded Spill
	ldr	x11, [sp, #88]                  ; 8-byte Folded Reload
	ldp	w8, w9, [x11]
	cmp	x8, x9
	mov	w12, #136                       ; =0x88
	b.hs	LBB70_149
; %bb.90:                               ;   in Loop: Header=BB70_38 Depth=1
	mov	w13, #0                         ; =0x0
	ldur	x25, [x29, #-120]               ; 8-byte Folded Reload
	b	LBB70_92
LBB70_91:                               ;   in Loop: Header=BB70_92 Depth=2
	ldr	w8, [sp, #108]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ldr	w9, [sp, #100]                  ; 4-byte Folded Reload
	orr	w9, w9, w8
	and	w13, w9, #0x1
	strb	w24, [x14, #160]
	ldr	x11, [sp, #88]                  ; 8-byte Folded Reload
	ldp	w8, w10, [x11]
	cmp	x8, x10
	ldr	x20, [sp, #136]                 ; 8-byte Folded Reload
	b.hs	LBB70_122
LBB70_92:                               ;   Parent Loop BB70_38 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB70_116 Depth 3
	add	w9, w8, #1
	str	w9, [x11]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #2
	ldrh	w11, [x8]
	ldp	x14, x9, [x25]
	add	x15, x14, #2352
	ldur	x10, [x29, #-128]               ; 8-byte Folded Reload
	ldr	w10, [x15, x10, lsl #2]
	ldrb	w8, [x8, #2]
	add	w10, w10, w11
	umaddl	x9, w10, w12, x9
	add	x8, x9, x8, lsl #3
	ldr	x9, [x8, #8]
	ldrb	w8, [x9, #160]
	tbnz	w8, #0, LBB70_140
; %bb.93:                               ;   in Loop: Header=BB70_92 Depth=2
	str	x15, [sp, #112]                 ; 8-byte Folded Spill
	str	x14, [sp, #144]                 ; 8-byte Folded Spill
	stur	w11, [x29, #-144]               ; 4-byte Folded Spill
	stur	x9, [x29, #-136]                ; 8-byte Folded Spill
	str	w13, [sp, #108]                 ; 4-byte Folded Spill
	ldr	w8, [x25, #32]
	cmp	w8, #16, lsl #12                ; =65536
	b.eq	LBB70_140
; %bb.94:                               ;   in Loop: Header=BB70_92 Depth=2
	add	w8, w8, #1
	str	w8, [x25, #32]
	ldr	x26, [sp, #128]                 ; 8-byte Folded Reload
	mov	x0, x26
	mov	w1, #32784                      ; =0x8010
	bl	_bzero
	ldur	x28, [x29, #-136]               ; 8-byte Folded Reload
	ldr	x8, [x28]
	ldrh	w9, [x28, #8]
	strh	w9, [x26, #8]
	str	x8, [x26]
	ldr	x1, [x28, #16]
	ldrh	w8, [x28]
	add	x8, x8, x8, lsl #2
	lsl	x2, x8, #3
	ldr	x25, [sp, #152]                 ; 8-byte Folded Reload
	mov	w8, #47248                      ; =0xb890
	add	x0, x25, x8
	mov	w3, #59912                      ; =0xea08
	bl	___memcpy_chk
	ldr	x1, [x28, #24]
	ldrh	w8, [x28, #2]
	add	x8, x8, x8, lsl #2
	lsl	x2, x8, #3
	mov	w8, #57488                      ; =0xe090
	add	x0, x25, x8
	mov	w3, #49672                      ; =0xc208
	bl	___memcpy_chk
	ldr	x1, [x28, #32]
	ldrh	w8, [x28, #48]
	add	x8, x8, x8, lsl #2
	lsl	x2, x8, #3
	mov	w8, #2192                       ; =0x890
	movk	w8, #1, lsl #16
	add	x0, x25, x8
	mov	w3, #39432                      ; =0x9a08
	bl	___memcpy_chk
	ldr	x1, [x28, #40]
	ldrh	w8, [x28, #4]
	lsl	x2, x8, #3
	mov	w8, #12432                      ; =0x3090
	movk	w8, #1, lsl #16
	add	x0, x25, x8
	mov	w3, #29192                      ; =0x7208
	bl	___memcpy_chk
	add	x0, x25, #96
	mov	w1, #14368                      ; =0x3820
	bl	_bzero
	str	x20, [x25, #80]
	ldur	x21, [x29, #-128]               ; 8-byte Folded Reload
	str	w21, [x25, #88]
	str	x24, [x25, #104]
	strb	w24, [x25, #120]
	mov	w8, #1025                       ; =0x401
	str	x8, [x20, #8]
	ldrh	w20, [x26, #2]
	strh	w20, [x25, #92]
	ldrh	w8, [x26, #4]
	strh	w8, [x25, #94]
	mov	w8, #47248                      ; =0xb890
	add	x1, x25, x8
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	mov	w2, #10240                      ; =0x2800
	bl	_memcpy
	mov	w8, #24704                      ; =0x6080
	add	x0, x25, x8
	mov	w8, #57488                      ; =0xe090
	add	x1, x25, x8
	mov	w2, #10240                      ; =0x2800
	bl	_memcpy
	mov	w8, #34944                      ; =0x8880
	add	x0, x25, x8
	mov	w8, #2192                       ; =0x890
	movk	w8, #1, lsl #16
	add	x1, x25, x8
	mov	w2, #10240                      ; =0x2800
	bl	_memcpy
	mov	w8, #45184                      ; =0xb080
	add	x0, x25, x8
	mov	w8, #12432                      ; =0x3090
	movk	w8, #1, lsl #16
	add	x1, x25, x8
	mov	w2, #2048                       ; =0x800
	bl	_memcpy
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	ldr	w8, [x8, x21, lsl #2]
	ldur	w10, [x29, #-144]               ; 4-byte Folded Reload
	add	w8, w8, w10
	str	x9, [sp, #144]                  ; 8-byte Folded Spill
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	umaddl	x9, w8, w23, x9
	strb	w24, [x28, #76]!
	strh	w20, [x28, #4]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x28, #8]
	mov	w8, #128                        ; =0x80
	str	w8, [x28, #20]
	stur	x9, [x29, #-144]                ; 8-byte Folded Spill
	cbz	x19, LBB70_96
; %bb.95:                               ;   in Loop: Header=BB70_92 Depth=2
	ldp	x0, x8, [x19, #16]
	add	x2, x25, #80
	mov	x1, x25
	mov	x3, x9
	mov	x4, x28
	blr	x8
	b	LBB70_97
LBB70_96:                               ;   in Loop: Header=BB70_92 Depth=2
	add	x1, x25, #80
	mov	x0, x25
	mov	x2, x9
	mov	x3, x28
	bl	_file_body_transfer
LBB70_97:                               ;   in Loop: Header=BB70_92 Depth=2
	mov	x26, x0
	mov	x21, x25
	ldr	x20, [sp, #136]                 ; 8-byte Folded Reload
	ldur	x25, [x29, #-136]               ; 8-byte Folded Reload
	cbnz	w0, LBB70_143
; %bb.98:                               ;   in Loop: Header=BB70_92 Depth=2
	ldrh	w8, [x21, #92]
	strh	w8, [x25, #82]
	ldrb	w28, [x25, #77]
	mov	x0, x21
	bl	_file_cyclic_canonicalize
	cbnz	w0, LBB70_146
; %bb.99:                               ;   in Loop: Header=BB70_92 Depth=2
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x8, [x9]
	ldrh	w9, [x9, #8]
	strh	w9, [x25, #74]
	stur	x8, [x25, #66]
	ldur	x13, [x29, #-144]               ; 8-byte Folded Reload
	ldrb	w8, [x13, #8]
	cmp	w8, #146
	mov	w12, #136                       ; =0x88
	mov	x14, x25
	str	w28, [sp, #100]                 ; 4-byte Folded Spill
	b.ne	LBB70_103
; %bb.100:                              ;   in Loop: Header=BB70_92 Depth=2
	ldrh	w8, [x13, #16]
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	mov	w10, #40                        ; =0x28
	umaddl	x9, w8, w10, x9
	ldrb	w10, [x9, #16]
	tbz	w10, #0, LBB70_148
; %bb.101:                              ;   in Loop: Header=BB70_92 Depth=2
	ldr	x10, [x9, #8]
	ldrb	w11, [x9, #1]
	lsl	x11, x11, #8
	lsr	x10, x10, #33
	cmp	x10, #1
	ccmp	x11, #0, #0, eq
	b.ne	LBB70_147
; %bb.102:                              ;   in Loop: Header=BB70_92 Depth=2
	ldr	w21, [x9, #32]
	strb	w24, [x14, #78]
	add	x8, x8, x8, lsl #2
	lsl	x8, x8, #3
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	b	LBB70_104
LBB70_103:                              ;   in Loop: Header=BB70_92 Depth=2
	str	xzr, [sp, #112]                 ; 8-byte Folded Spill
	mov	w21, #0                         ; =0x0
LBB70_104:                              ;   in Loop: Header=BB70_92 Depth=2
	ldur	x25, [x29, #-120]               ; 8-byte Folded Reload
	ldrb	w8, [x13, #76]
	cbz	w8, LBB70_91
; %bb.105:                              ;   in Loop: Header=BB70_92 Depth=2
	ldrb	w9, [x14, #78]
	cmp	w9, #1
	b.ne	LBB70_108
; %bb.106:                              ;   in Loop: Header=BB70_92 Depth=2
	sub	w9, w21, #1
	cmp	w9, #1
	b.hi	LBB70_112
; %bb.107:                              ;   in Loop: Header=BB70_92 Depth=2
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #2                          ; =0x2
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	str	w9, [x8, x10]
LBB70_108:                              ;   in Loop: Header=BB70_92 Depth=2
	ldr	w8, [x25, #36]
	cmp	w8, #32, lsl #12                ; =131072
	b.eq	LBB70_137
; %bb.109:                              ;   in Loop: Header=BB70_92 Depth=2
	add	w8, w8, #1
	str	w8, [x25, #36]
	ldr	x28, [sp, #152]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x20, x25
	bl	_file_cyclic_canonicalize
	cbnz	w0, LBB70_150
; %bb.110:                              ;   in Loop: Header=BB70_92 Depth=2
	ldur	x25, [x29, #-144]               ; 8-byte Folded Reload
	ldrh	w3, [x25, #72]
	sub	x4, x29, #89
	mov	x0, x20
	mov	x1, x28
	ldur	x2, [x29, #-128]                ; 8-byte Folded Reload
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_file_cyclic_intern
	cbnz	w0, LBB70_138
; %bb.111:                              ;   in Loop: Header=BB70_92 Depth=2
	ldurb	w8, [x29, #-89]
	ldur	x14, [x29, #-136]               ; 8-byte Folded Reload
	strb	w8, [x14, #157]
	ldrb	w8, [x14, #156]
	orr	w8, w8, #0x1
	strb	w8, [x14, #156]
	ldrb	w8, [x25, #76]
	ldur	x25, [x29, #-120]               ; 8-byte Folded Reload
	mov	w12, #136                       ; =0x88
LBB70_112:                              ;   in Loop: Header=BB70_92 Depth=2
	cmp	w8, #2
	b.lo	LBB70_91
; %bb.113:                              ;   in Loop: Header=BB70_92 Depth=2
	and	w9, w21, #0xfffffffd
	str	w9, [sp, #104]                  ; 4-byte Folded Spill
	add	x11, x14, #158
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	umaddl	x9, w10, w23, x9
	add	x28, x9, #74
	mov	w20, #1                         ; =0x1
	b	LBB70_116
LBB70_114:                              ;   in Loop: Header=BB70_116 Depth=3
	ldurb	w8, [x29, #-89]
	ldr	x11, [sp, #144]                 ; 8-byte Folded Reload
	strb	w8, [x11]
	lsl	w8, w24, w20
	ldur	x14, [x29, #-136]               ; 8-byte Folded Reload
	ldrb	w9, [x14, #156]
	orr	w8, w9, w8
	strb	w8, [x14, #156]
	ldur	x8, [x29, #-144]                ; 8-byte Folded Reload
	ldrb	w8, [x8, #76]
	ldur	x25, [x29, #-120]               ; 8-byte Folded Reload
	mov	w12, #136                       ; =0x88
LBB70_115:                              ;   in Loop: Header=BB70_116 Depth=3
	add	x20, x20, #1
	add	x11, x11, #1
	add	x28, x28, #2
	cmp	x20, w8, uxtw
	b.hs	LBB70_91
LBB70_116:                              ;   Parent Loop BB70_38 Depth=1
                                        ;     Parent Loop BB70_92 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w9, [x14, #78]
	cmp	w9, #1
	b.ne	LBB70_119
; %bb.117:                              ;   in Loop: Header=BB70_116 Depth=3
	ldr	w9, [sp, #104]                  ; 4-byte Folded Reload
	cmp	w9, #1
	b.ne	LBB70_115
; %bb.118:                              ;   in Loop: Header=BB70_116 Depth=3
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #3                          ; =0x3
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	str	w9, [x8, x10]
LBB70_119:                              ;   in Loop: Header=BB70_116 Depth=3
	str	x11, [sp, #144]                 ; 8-byte Folded Spill
	ldr	w8, [x25, #36]
	cmp	w8, #32, lsl #12                ; =131072
	b.eq	LBB70_137
; %bb.120:                              ;   in Loop: Header=BB70_116 Depth=3
	add	w8, w8, #1
	str	w8, [x25, #36]
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
	mov	x0, x21
	bl	_file_cyclic_canonicalize
	cbnz	w0, LBB70_141
; %bb.121:                              ;   in Loop: Header=BB70_116 Depth=3
	ldrh	w3, [x28]
	sub	x4, x29, #89
	mov	x0, x25
	mov	x1, x21
	ldur	x2, [x29, #-128]                ; 8-byte Folded Reload
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_file_cyclic_intern
	cbz	w0, LBB70_114
	b	LBB70_138
LBB70_122:                              ;   in Loop: Header=BB70_38 Depth=1
	tst	w9, #0xff
	b.eq	LBB70_147
; %bb.123:                              ;   in Loop: Header=BB70_38 Depth=1
	ldp	x8, x28, [sp, #16]              ; 16-byte Folded Reload
	ldur	x9, [x29, #-128]                ; 8-byte Folded Reload
	strb	w24, [x8, x9]
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	add	x10, x10, #1
	ldr	w8, [x28, #24]
	cmp	x10, x8
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x20, [sp, #136]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	b.lo	LBB70_38
LBB70_124:
	ldur	x0, [x29, #-120]                ; 8-byte Folded Reload
	bl	_file_cyclic_complete
	eor	w26, w0, #0x1
	b	LBB70_143
LBB70_125:
	cbz	x20, LBB70_135
; %bb.126:
	ldr	x19, [x20]
	cbz	x19, LBB70_129
; %bb.127:
	ldr	w8, [x19]
	subs	w8, w8, #1
	str	w8, [x19]
	b.ne	LBB70_129
; %bb.128:
	ldr	x0, [x19, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x19
	bl	_free
LBB70_129:
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #8]
	bl	_free
	mov	x0, x20
	bl	_free
	mov	w26, #2                         ; =0x2
	b	LBB70_21
LBB70_130:
	cbz	x28, LBB70_136
; %bb.131:
	ldr	x19, [x28]
	cbz	x19, LBB70_134
; %bb.132:
	ldr	w8, [x19]
	subs	w8, w8, #1
	str	w8, [x19]
	b.ne	LBB70_134
; %bb.133:
	ldr	x0, [x19, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x19
	bl	_free
LBB70_134:
	ldr	x0, [x28, #16]
	bl	_free
	ldr	x0, [x28, #8]
	bl	_free
	mov	x0, x28
	bl	_free
	mov	w26, #4                         ; =0x4
	b	LBB70_21
LBB70_135:
	mov	w26, #2                         ; =0x2
	b	LBB70_21
LBB70_136:
	mov	w26, #4                         ; =0x4
	b	LBB70_21
LBB70_137:
	mov	w26, #3                         ; =0x3
	b	LBB70_139
LBB70_138:
	mov	x26, x0
LBB70_139:
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
	b	LBB70_142
LBB70_140:
	mov	w26, #3                         ; =0x3
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
	b	LBB70_143
LBB70_141:
	mov	x26, x0
LBB70_142:
	ldr	x20, [sp, #136]                 ; 8-byte Folded Reload
LBB70_143:
	mov	x0, x20
	bl	_free
	mov	x0, x21
	bl	_free
	cbz	w26, LBB70_145
; %bb.144:
	ldur	x0, [x29, #-120]                ; 8-byte Folded Reload
	bl	_nvm_file_cyclic_free
	b	LBB70_21
LBB70_145:
	ldur	x8, [x29, #-120]                ; 8-byte Folded Reload
	str	x8, [x22]
	b	LBB70_21
LBB70_146:
	mov	x26, x0
	b	LBB70_143
LBB70_147:
	mov	w26, #1                         ; =0x1
	b	LBB70_139
LBB70_148:
	mov	w26, #1                         ; =0x1
	b	LBB70_143
LBB70_149:
	mov	w26, #1                         ; =0x1
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
	b	LBB70_143
LBB70_150:
	mov	x26, x0
	mov	x21, x28
	b	LBB70_142
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_summary ; -- Begin function nvm_file_cyclic_summary
	.globl	_nvm_file_cyclic_summary
	.p2align	2
_nvm_file_cyclic_summary:               ; @nvm_file_cyclic_summary
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB71_2
; %bb.1:
	ldp	q0, q1, [x8, #16]
	ldr	x8, [x8, #48]
	str	x8, [x1, #32]
	stp	q0, q1, [x1]
LBB71_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_function ; -- Begin function nvm_file_cyclic_function
	.globl	_nvm_file_cyclic_function
	.p2align	2
_nvm_file_cyclic_function:              ; @nvm_file_cyclic_function
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB72_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB72_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB72_5
; %bb.3:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB72_6
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8, #48]
	ldr	w8, [x8, #80]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB72_5:
	ret
LBB72_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_local  ; -- Begin function nvm_file_cyclic_local
	.globl	_nvm_file_cyclic_local
	.p2align	2
_nvm_file_cyclic_local:                 ; @nvm_file_cyclic_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB73_8
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB73_7
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB73_8
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB73_8
; %bb.4:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB73_7
; %bb.5:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB73_7
; %bb.6:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB73_7:
	mov	w0, #0                          ; =0x0
LBB73_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_instruction ; -- Begin function nvm_file_cyclic_instruction
	.globl	_nvm_file_cyclic_instruction
	.p2align	2
_nvm_file_cyclic_instruction:           ; @nvm_file_cyclic_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB74_6
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB74_6
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB74_6
; %bb.3:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB74_7
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB74_7
; %bb.5:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, w1
	ldr	x10, [x8, #16]
	add	x8, x8, x9, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x0, x3
	mov	w2, #600                        ; =0x258
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB74_6:
	ret
LBB74_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_component ; -- Begin function nvm_file_cyclic_component
	.globl	_nvm_file_cyclic_component
	.p2align	2
_nvm_file_cyclic_component:             ; @nvm_file_cyclic_component
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB75_6
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB75_7
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB75_7
; %bb.3:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB75_6
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB75_6
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrh	w8, [x8, #2]
	strh	w8, [x3]
	mov	w0, #1                          ; =0x1
LBB75_6:
	ret
LBB75_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_variant_count ; -- Begin function nvm_file_cyclic_variant_count
	.globl	_nvm_file_cyclic_variant_count
	.p2align	2
_nvm_file_cyclic_variant_count:         ; @nvm_file_cyclic_variant_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB76_6
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB76_7
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB76_7
; %bb.3:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB76_6
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB76_6
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
LBB76_6:
	ret
LBB76_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_variant ; -- Begin function nvm_file_cyclic_variant
	.globl	_nvm_file_cyclic_variant
	.p2align	2
_nvm_file_cyclic_variant:               ; @nvm_file_cyclic_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB77_8
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB77_9
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB77_9
; %bb.3:
	ldr	x9, [x0, #8]
	cbz	x9, LBB77_9
; %bb.4:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB77_9
; %bb.5:
	mov	w0, #0                          ; =0x0
	cbz	x4, LBB77_8
; %bb.6:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB77_8
; %bb.7:
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	stp	q1, q2, [x4, #16]
	str	q0, [x4]
	ldur	q0, [x8, #104]
	ldur	q1, [x8, #120]
	ldur	q2, [x8, #136]
	ldr	x8, [x8, #152]
	str	x8, [x4, #96]
	stp	q1, q2, [x4, #64]
	str	q0, [x4, #48]
	mov	w0, #1                          ; =0x1
LBB77_8:
	ret
LBB77_9:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_input_local ; -- Begin function nvm_file_cyclic_input_local
	.globl	_nvm_file_cyclic_input_local
	.p2align	2
_nvm_file_cyclic_input_local:           ; @nvm_file_cyclic_input_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB78_9
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB78_10
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB78_10
; %bb.3:
	ldr	x9, [x0, #8]
	cbz	x9, LBB78_10
; %bb.4:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB78_10
; %bb.5:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB78_9
; %bb.6:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB78_9
; %bb.7:
	ldrh	w9, [x8]
	cmp	w4, w9
	b.hs	LBB78_10
; %bb.8:
	ldr	x8, [x8, #16]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
LBB78_9:
	ret
LBB78_10:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_input_stack ; -- Begin function nvm_file_cyclic_input_stack
	.globl	_nvm_file_cyclic_input_stack
	.p2align	2
_nvm_file_cyclic_input_stack:           ; @nvm_file_cyclic_input_stack
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB79_9
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB79_10
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB79_10
; %bb.3:
	ldr	x9, [x0, #8]
	cbz	x9, LBB79_10
; %bb.4:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB79_10
; %bb.5:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB79_9
; %bb.6:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB79_9
; %bb.7:
	ldrh	w9, [x8, #2]
	cmp	w4, w9
	b.hs	LBB79_10
; %bb.8:
	ldr	x8, [x8, #24]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
LBB79_9:
	ret
LBB79_10:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_input_reference ; -- Begin function nvm_file_cyclic_input_reference
	.globl	_nvm_file_cyclic_input_reference
	.p2align	2
_nvm_file_cyclic_input_reference:       ; @nvm_file_cyclic_input_reference
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB80_13
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB80_10
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB80_10
; %bb.3:
	ldr	x9, [x0, #8]
	cbz	x9, LBB80_10
; %bb.4:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB80_10
; %bb.5:
	mov	w0, #0                          ; =0x0
	cmp	w4, #255
	b.hi	LBB80_13
; %bb.6:
	cbz	x5, LBB80_13
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB80_13
; %bb.8:
	ldrh	w9, [x8, #48]
	cmp	w4, w9
	b.hs	LBB80_11
; %bb.9:
	ldr	x8, [x8, #32]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	str	q1, [x5, #16]
	b	LBB80_12
LBB80_10:
	mov	w0, #0                          ; =0x0
	ret
LBB80_11:
	str	xzr, [x5, #32]
	movi.2d	v0, #0000000000000000
	str	q0, [x5, #16]
LBB80_12:
	str	q0, [x5]
	mov	w0, #1                          ; =0x1
LBB80_13:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_input_region ; -- Begin function nvm_file_cyclic_input_region
	.globl	_nvm_file_cyclic_input_region
	.p2align	2
_nvm_file_cyclic_input_region:          ; @nvm_file_cyclic_input_region
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB81_9
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB81_10
; %bb.2:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB81_10
; %bb.3:
	ldr	x9, [x0, #8]
	cbz	x9, LBB81_10
; %bb.4:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB81_10
; %bb.5:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB81_9
; %bb.6:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB81_9
; %bb.7:
	ldrh	w9, [x8, #4]
	cmp	w4, w9
	b.hs	LBB81_10
; %bb.8:
	ldr	x8, [x8, #40]
	ldr	x8, [x8, w4, uxtw #3]
	str	x8, [x5]
	mov	w0, #1                          ; =0x1
LBB81_9:
	ret
LBB81_10:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_type   ; -- Begin function nvm_file_cyclic_type
	.globl	_nvm_file_cyclic_type
	.p2align	2
_nvm_file_cyclic_type:                  ; @nvm_file_cyclic_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB82_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_type
LBB82_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_import ; -- Begin function nvm_file_cyclic_import
	.globl	_nvm_file_cyclic_import
	.p2align	2
_nvm_file_cyclic_import:                ; @nvm_file_cyclic_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB83_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_import
LBB83_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_free ; -- Begin function nvm_file_cyclic_hosted_free
	.globl	_nvm_file_cyclic_hosted_free
	.p2align	2
_nvm_file_cyclic_hosted_free:           ; @nvm_file_cyclic_hosted_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB84_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_file_cyclic_free
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB84_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_prepare ; -- Begin function nvm_file_cyclic_hosted_prepare
	.globl	_nvm_file_cyclic_hosted_prepare
	.p2align	2
_nvm_file_cyclic_hosted_prepare:        ; @nvm_file_cyclic_hosted_prepare
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB85_4
; %bb.1:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #336]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #352]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x1
	mov	x22, x2
	sub	x2, x29, #112
	sub	x3, x29, #120
	mov	x21, x0
	bl	_file_hosted_preflight
	cbnz	w0, LBB85_14
; %bb.2:
	ldur	x23, [x29, #-120]
	lsr	x8, x23, #24
	cbnz	x8, LBB85_5
; %bb.3:
	mov	w0, #1                          ; =0x1
	b	LBB85_14
LBB85_4:
	mov	w0, #1                          ; =0x1
	ret
LBB85_5:
	mov	x8, #-59793                     ; =0xffffffffffff166f
	movk	x8, #64512, lsl #16
	mov	x9, #-59793                     ; =0xffffffffffff166f
	movk	x9, #64768, lsl #16
	add	x8, x23, x8
	cmp	x8, x9
	b.hs	LBB85_7
; %bb.6:
	mov	w0, #3                          ; =0x3
	b	LBB85_14
LBB85_7:
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB85_13
; %bb.8:
	mov	x19, x0
	add	x24, sp, #16
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	str	xzr, [sp, #256]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #208]
	stp	q0, q0, [x24, #176]
	stp	q0, q0, [x24, #144]
	str	q0, [x24, #128]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #8]
	add	x2, sp, #16
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_v2_module_deserialize
	cbnz	w0, LBB85_10
; %bb.9:
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_to_nvm_module
	cbz	w0, LBB85_15
LBB85_10:
	mov	x0, #0                          ; =0x0
LBB85_11:
	mov	w23, #2                         ; =0x2
LBB85_12:
	bl	_nvm_file_cyclic_hosted_free
	ldr	x0, [sp, #8]
	bl	_nvm_module_free
	add	x0, sp, #16
	bl	_nvm_v2_module_free
	mov	x0, x19
	bl	_free
	mov	x0, x23
	b	LBB85_14
LBB85_13:
	mov	w0, #4                          ; =0x4
LBB85_14:
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #368]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #352]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
LBB85_15:
	ldr	x21, [sp, #8]
	cbz	x21, LBB85_10
; %bb.16:
	ldr	w2, [x21, #288]
	ldr	x8, [sp, #192]
	cmp	x8, x2
	b.ne	LBB85_10
; %bb.17:
	ldr	x0, [x21, #280]
	cbz	x0, LBB85_11
; %bb.18:
	ldr	x1, [sp, #184]
	bl	_memcmp
	cbnz	w0, LBB85_10
; %bb.19:
	mov	w24, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #5744                       ; =0x1670
	bl	_calloc
	cbz	x0, LBB85_22
; %bb.20:
	mov	w8, #5744                       ; =0x1670
	add	x23, x23, x8
	str	w24, [x0, #16]
	ldur	w8, [x29, #-104]
	str	w8, [x0, #32]
	stp	x20, x23, [x0, #72]
	mov	x1, x0
	mov	x0, x21
	mov	x21, x1
	mov	x2, #0                          ; =0x0
	bl	_file_cyclic_analyze_extended
	cbz	w0, LBB85_23
LBB85_21:
	mov	x23, x0
	mov	x0, x21
	b	LBB85_12
LBB85_22:
	mov	w23, #4                         ; =0x4
	b	LBB85_12
LBB85_23:
	ldr	x9, [x21]
	ldr	w10, [x9, #16]
	cmp	w10, #1
	b.ne	LBB85_27
; %bb.24:
	ldrb	w10, [x9, #48]
	tbnz	w10, #0, LBB85_26
; %bb.25:
	ldr	x9, [x9, #40]
	mov	w10, #16777216                  ; =0x1000000
	cmp	x9, x10
	b.ls	LBB85_28
LBB85_26:
	mov	w23, #1                         ; =0x1
	mov	x0, x21
	b	LBB85_12
LBB85_27:
	mov	x0, x21
	mov	w23, #1                         ; =0x1
	b	LBB85_12
LBB85_28:
	mov	x8, x23
	str	x9, [x21, #88]
	mov	w10, #59792                     ; =0xe990
	movk	w10, #1023, lsl #16
	mov	w23, #3                         ; =0x3
	cmp	x20, x10
	b.hi	LBB85_31
; %bb.29:
	sub	x10, x10, x20
	cmp	x9, x10
	b.hi	LBB85_31
; %bb.30:
	mov	w10, #5744                      ; =0x1670
	add	x9, x20, x9
	add	x9, x9, x10
	cmp	x9, x8
	b.ls	LBB85_32
LBB85_31:
	mov	x0, x21
	b	LBB85_12
LBB85_32:
	mov	x0, x21
	str	x9, [x21, #96]
	ldr	x2, [sp, #8]
	add	x1, sp, #16
	bl	_file_ch_start
	cbnz	w0, LBB85_21
; %bb.33:
	add	x1, sp, #16
	mov	x0, x21
	bl	_file_ch_bounds
	mov	x23, x0
	cbnz	w0, LBB85_31
; %bb.34:
	str	x19, [x21, #8]
	str	x21, [x22]
	mov	x19, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	b	LBB85_12
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_start
_file_ch_start:                         ; @file_ch_start
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x8, [x0]
	ldr	x9, [x8]
	ldr	w21, [x9, #24]
	ldr	w8, [x1, #80]
	cmp	w21, w8
	b.ne	LBB86_3
; %bb.1:
	ldr	w8, [x2, #272]
	cmp	w21, w8
	b.ne	LBB86_3
; %bb.2:
	ldrb	w8, [x2, #8]
	tbnz	w8, #0, LBB86_5
LBB86_3:
	mov	w0, #1                          ; =0x1
LBB86_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB86_5:
	mov	x8, x0
	ldr	w10, [x2, #12]
	ldr	w11, [x1, #4]
	mov	w0, #1                          ; =0x1
	cmp	w10, w11
	b.ne	LBB86_4
; %bb.6:
	cmp	w11, w21
	b.hs	LBB86_4
; %bb.7:
	mov	w11, #-1                        ; =0xffffffff
	stp	w10, w11, [x8, #20]
	str	w21, [x8, #28]
	mov	w11, #36                        ; =0x24
	umaddl	x10, w10, w11, x9
	ldrh	w11, [x10, #60]
	cbnz	w11, LBB86_11
; %bb.8:
	ldurb	w11, [x10, #64]
	cmp	w11, #1
	b.ne	LBB86_11
; %bb.9:
	ldurb	w11, [x10, #69]
	cbnz	w11, LBB86_11
; %bb.10:
	ldur	w11, [x10, #72]
	cmn	w11, #1
	b.eq	LBB86_12
LBB86_11:
	mov	w0, #2                          ; =0x2
	b	LBB86_4
LBB86_12:
	ldurb	w10, [x10, #68]
	cmp	w10, #4
	ccmp	w10, #1, #4, ne
	b.ne	LBB86_11
; %bb.13:
	mov	x22, #0                         ; =0x0
	ldr	x23, [x2, #256]
	ldr	w24, [x2, #248]
	add	x25, x9, #72
	mov	w28, #-1                        ; =0xffffffff
Lloh38:
	adrp	x19, l_.str.3@PAGE
Lloh39:
	add	x19, x19, l_.str.3@PAGEOFF
	b	LBB86_16
LBB86_14:                               ;   in Loop: Header=BB86_16 Depth=1
	mov	w28, #-1                        ; =0xffffffff
LBB86_15:                               ;   in Loop: Header=BB86_16 Depth=1
	mov	w0, #0                          ; =0x0
	add	x22, x22, #1
	add	x25, x25, #36
	cmp	x21, x22
	mov	x2, x27
	mov	x8, x26
	b.eq	LBB86_4
LBB86_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x23], #24
	cmp	w9, w24
	b.hs	LBB86_3
; %bb.17:                               ;   in Loop: Header=BB86_16 Depth=1
	ldr	x10, [x2, #232]
	ldr	x20, [x10, x9, lsl #3]
	cbz	x20, LBB86_3
; %bb.18:                               ;   in Loop: Header=BB86_16 Depth=1
	mov	x26, x8
	mov	x27, x2
	ldr	x8, [x2, #240]
	ldr	w2, [x8, x9, lsl #2]
	mov	x0, x20
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB86_3
; %bb.19:                               ;   in Loop: Header=BB86_16 Depth=1
	cmn	w28, #1
	b.ne	LBB86_15
; %bb.20:                               ;   in Loop: Header=BB86_16 Depth=1
	mov	x0, x20
	mov	x1, x19
	bl	_strcmp
	cbnz	w0, LBB86_14
; %bb.21:                               ;   in Loop: Header=BB86_16 Depth=1
	ldurh	w8, [x25, #-12]
	cbnz	w8, LBB86_11
; %bb.22:                               ;   in Loop: Header=BB86_16 Depth=1
	ldurb	w9, [x25, #-8]
	cbnz	w9, LBB86_11
; %bb.23:                               ;   in Loop: Header=BB86_16 Depth=1
	ldurb	w9, [x25, #-4]
	cbnz	w9, LBB86_11
; %bb.24:                               ;   in Loop: Header=BB86_16 Depth=1
	ldurb	w9, [x25, #-3]
	cbnz	w9, LBB86_11
; %bb.25:                               ;   in Loop: Header=BB86_16 Depth=1
	ldr	w9, [x25]
	cmn	w9, #1
	b.ne	LBB86_11
; %bb.26:                               ;   in Loop: Header=BB86_16 Depth=1
	str	w22, [x26, #24]
	mov	x28, x22
	b	LBB86_15
	.loh AdrpAdd	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_bounds
_file_ch_bounds:                        ; @file_ch_bounds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x28, x27, [sp, #144]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	mov	x19, x0
Lloh40:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh41:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh42:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	ldr	x0, [x0]
	ldr	x21, [x0]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	bl	_file_cyclic_complete
	cbz	w0, LBB87_102
; %bb.1:
	ldr	w8, [x21, #24]
	cbz	w8, LBB87_80
; %bb.2:
	mov	x5, #0                          ; =0x0
	add	x6, x21, #2608
	add	x7, x19, #112
	add	x22, x21, #48
	add	x27, x21, #2352
	add	x25, sp, #64
	mov	w9, #88                         ; =0x58
	mov	w10, #36                        ; =0x24
	mov	w11, #65537                     ; =0x10001
	mov	w12, #136                       ; =0x88
LBB87_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB87_13 Depth 2
                                        ;       Child Loop BB87_21 Depth 3
                                        ;     Child Loop BB87_60 Depth 2
                                        ;       Child Loop BB87_63 Depth 3
	ldr	w28, [x6, x5, lsl #2]
	cmp	x28, x8
	b.hs	LBB87_102
; %bb.4:                                ;   in Loop: Header=BB87_3 Depth=1
	ldrb	w8, [x25, x28]
	tbnz	w8, #0, LBB87_102
; %bb.5:                                ;   in Loop: Header=BB87_3 Depth=1
	umaddl	x26, w28, w9, x7
	umaddl	x8, w28, w10, x22
	ldp	q0, q1, [x8]
	ldr	w8, [x8, #32]
	str	w8, [x26, #32]
	stp	q0, q1, [x26]
	ldr	x8, [x20, #72]
	add	x8, x8, x28, lsl #5
	ldrh	w8, [x8, #28]
	strh	w8, [x26, #36]
	ldrh	w24, [x26, #14]
	strh	w24, [x26, #40]
	stur	w11, [x26, #42]
	strb	wzr, [x26, #80]
	ldr	x9, [x19]
	cbz	x9, LBB87_102
; %bb.6:                                ;   in Loop: Header=BB87_3 Depth=1
	ldr	x10, [x9]
	ldr	w11, [x10, #24]
	cmp	x28, x11
	b.hs	LBB87_102
; %bb.7:                                ;   in Loop: Header=BB87_3 Depth=1
	add	x11, x28, x28, lsl #3
	lsl	x11, x11, #2
	str	x11, [sp, #56]                  ; 8-byte Folded Spill
	add	x11, x10, x11
	ldrh	w11, [x11, #56]
	cbz	w11, LBB87_102
; %bb.8:                                ;   in Loop: Header=BB87_3 Depth=1
	ldr	x9, [x9, #8]
	cbz	x9, LBB87_102
; %bb.9:                                ;   in Loop: Header=BB87_3 Depth=1
	add	x10, x10, x28, lsl #2
	ldr	w10, [x10, #2352]
	umaddl	x9, w10, w12, x9
	ldrb	w10, [x9]
	cbz	w10, LBB87_102
; %bb.10:                               ;   in Loop: Header=BB87_3 Depth=1
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #2]
	cbnz	w9, LBB87_102
; %bb.11:                               ;   in Loop: Header=BB87_3 Depth=1
	ldrh	w23, [x26, #8]
	cbz	w23, LBB87_55
; %bb.12:                               ;   in Loop: Header=BB87_3 Depth=1
	stp	x22, x7, [sp]                   ; 16-byte Folded Spill
	stp	x6, x5, [sp, #16]               ; 16-byte Folded Spill
	stp	x20, x27, [sp, #32]             ; 16-byte Folded Spill
	mov	w25, #0                         ; =0x0
	str	x21, [sp, #48]                  ; 8-byte Folded Spill
LBB87_13:                               ;   Parent Loop BB87_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB87_21 Depth 3
	ldr	x9, [x19]
	cbz	x9, LBB87_106
; %bb.14:                               ;   in Loop: Header=BB87_13 Depth=2
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	x28, x10
	b.hs	LBB87_106
; %bb.15:                               ;   in Loop: Header=BB87_13 Depth=2
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	add	x10, x8, x10
	ldrh	w10, [x10, #56]
	cmp	w25, w10
	b.hs	LBB87_106
; %bb.16:                               ;   in Loop: Header=BB87_13 Depth=2
	ldr	x22, [x9, #8]
	cbz	x22, LBB87_106
; %bb.17:                               ;   in Loop: Header=BB87_13 Depth=2
	ldr	w9, [x27, x28, lsl #2]
	ldr	x10, [x21, #16]
	add	w9, w9, w25
	mov	w11, #600                       ; =0x258
	umaddl	x21, w9, w11, x10
	add	x8, x8, x28, lsl #2
	ldr	w27, [x8, #2352]
	ldrb	w0, [x21, #8]
	mov	w1, #0                          ; =0x0
	bl	_file_code_supported_mode
	cbz	w0, LBB87_106
; %bb.18:                               ;   in Loop: Header=BB87_13 Depth=2
	add	w8, w27, w25
	mov	w9, #136                        ; =0x88
	umaddl	x20, w8, w9, x22
	ldrb	w8, [x20]
	cbz	w8, LBB87_53
; %bb.19:                               ;   in Loop: Header=BB87_13 Depth=2
	mov	x23, #0                         ; =0x0
	add	w8, w27, w25
	umaddl	x8, w8, w9, x22
	add	x27, x8, #8
	b	LBB87_21
LBB87_20:                               ;   in Loop: Header=BB87_21 Depth=3
	add	x23, x23, #1
	ldrb	w8, [x20]
	cmp	x23, x8
	b.hs	LBB87_52
LBB87_21:                               ;   Parent Loop BB87_3 Depth=1
                                        ;     Parent Loop BB87_13 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x22, [x27, x23, lsl #3]
	ldr	x0, [x19]
	add	x2, x22, #56
	mov	x1, x21
	bl	_file_ch_fact
	cbz	w0, LBB87_102
; %bb.22:                               ;   in Loop: Header=BB87_21 Depth=3
	ldr	x8, [x22, #56]
	lsr	x10, x8, #48
	ldrh	w24, [x26, #40]
	and	w9, w8, #0xffff
	mov	w0, #1                          ; =0x1
	cmp	x10, #256
	ccmp	w24, w9, #0, ls
	b.ne	LBB87_103
; %bb.23:                               ;   in Loop: Header=BB87_21 Depth=3
	lsr	w9, w8, #16
	cmp	w9, #256
	b.hi	LBB87_103
; %bb.24:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w11, [x22, #64]
	cmp	w11, #256
	b.hi	LBB87_103
; %bb.25:                               ;   in Loop: Header=BB87_21 Depth=3
	ubfx	x12, x8, #32, #16
	cmp	w12, #256
	b.hi	LBB87_103
; %bb.26:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w8, [x26, #38]
	cmp	w9, w8
	b.ls	LBB87_28
; %bb.27:                               ;   in Loop: Header=BB87_21 Depth=3
	strh	w9, [x26, #38]
	mov	x8, x9
LBB87_28:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w9, [x26, #46]
	cmp	x10, x9
	b.ls	LBB87_30
; %bb.29:                               ;   in Loop: Header=BB87_21 Depth=3
	strh	w10, [x26, #46]
	mov	x9, x10
LBB87_30:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w10, [x26, #48]
	cmp	w11, w10
	b.ls	LBB87_32
; %bb.31:                               ;   in Loop: Header=BB87_21 Depth=3
	strh	w11, [x26, #48]
	mov	x10, x11
LBB87_32:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w11, [x26, #50]
	cmp	w12, w11
	b.ls	LBB87_34
; %bb.33:                               ;   in Loop: Header=BB87_21 Depth=3
	strh	w12, [x26, #50]
	mov	x11, x12
LBB87_34:                               ;   in Loop: Header=BB87_21 Depth=3
	ldur	x12, [x22, #66]
	lsr	x13, x12, #48
	cmp	x13, #256
	b.hi	LBB87_103
; %bb.35:                               ;   in Loop: Header=BB87_21 Depth=3
	and	w14, w12, #0xffff
	cmp	w24, w14
	b.ne	LBB87_103
; %bb.36:                               ;   in Loop: Header=BB87_21 Depth=3
	lsr	w16, w12, #16
	cmp	w16, #256
	b.hi	LBB87_103
; %bb.37:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w14, [x22, #74]
	cmp	w14, #256
	b.hi	LBB87_103
; %bb.38:                               ;   in Loop: Header=BB87_21 Depth=3
	ubfx	x15, x12, #32, #16
	cmp	w15, #256
	b.hi	LBB87_103
; %bb.39:                               ;   in Loop: Header=BB87_21 Depth=3
	cmp	w16, w8
	b.ls	LBB87_43
; %bb.40:                               ;   in Loop: Header=BB87_21 Depth=3
	lsr	x8, x12, #16
	strh	w8, [x26, #38]
	cmp	x13, x9
	b.hi	LBB87_44
LBB87_41:                               ;   in Loop: Header=BB87_21 Depth=3
	cmp	w14, w10
	b.ls	LBB87_45
LBB87_42:                               ;   in Loop: Header=BB87_21 Depth=3
	strh	w14, [x26, #48]
	cmp	w15, w11
	b.hi	LBB87_46
	b	LBB87_47
LBB87_43:                               ;   in Loop: Header=BB87_21 Depth=3
	cmp	x13, x9
	b.ls	LBB87_41
LBB87_44:                               ;   in Loop: Header=BB87_21 Depth=3
	strh	w13, [x26, #46]
	cmp	w14, w10
	b.hi	LBB87_42
LBB87_45:                               ;   in Loop: Header=BB87_21 Depth=3
	cmp	w15, w11
	b.ls	LBB87_47
LBB87_46:                               ;   in Loop: Header=BB87_21 Depth=3
	lsr	x8, x12, #32
	strh	w8, [x26, #50]
LBB87_47:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrb	w8, [x22, #79]
	cmp	w8, #1
	b.ne	LBB87_20
; %bb.48:                               ;   in Loop: Header=BB87_21 Depth=3
	ldr	w8, [x22, #100]
	cmp	w8, #1
	b.ne	LBB87_20
; %bb.49:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w8, [x22, #124]
	cmp	w8, #256
	b.hi	LBB87_103
; %bb.50:                               ;   in Loop: Header=BB87_21 Depth=3
	ldrh	w9, [x26, #42]
	cmp	w8, w9
	b.lo	LBB87_20
; %bb.51:                               ;   in Loop: Header=BB87_21 Depth=3
	add	w8, w8, #1
	strh	w8, [x26, #42]
	b	LBB87_20
LBB87_52:                               ;   in Loop: Header=BB87_13 Depth=2
	ldrh	w23, [x26, #8]
LBB87_53:                               ;   in Loop: Header=BB87_13 Depth=2
	add	w25, w25, #1
	cmp	w25, w23
	ldp	x27, x21, [sp, #40]             ; 16-byte Folded Reload
	b.lo	LBB87_13
; %bb.54:                               ;   in Loop: Header=BB87_3 Depth=1
	ldrh	w8, [x26, #36]
	ldp	x5, x20, [sp, #24]              ; 16-byte Folded Reload
	ldp	x7, x6, [sp, #8]                ; 16-byte Folded Reload
	ldr	x22, [sp]                       ; 8-byte Folded Reload
	add	x25, sp, #64
LBB87_55:                               ;   in Loop: Header=BB87_3 Depth=1
	ldrh	w9, [x26, #38]
	cbz	w8, LBB87_57
; %bb.56:                               ;   in Loop: Header=BB87_3 Depth=1
	cmp	w8, w9
	b.lo	LBB87_102
LBB87_57:                               ;   in Loop: Header=BB87_3 Depth=1
	mov	w11, w24
	ldrh	w12, [x26, #42]
	add	x8, x11, x12
	add	x8, x9, x8
	stp	x8, x8, [x26, #64]
	cbz	w23, LBB87_75
; %bb.58:                               ;   in Loop: Header=BB87_3 Depth=1
	mov	w10, #0                         ; =0x0
	ldr	x9, [x19]
	add	x11, x12, x11
	ldp	x12, x13, [x9]
	add	x9, x12, x28, lsl #2
	ldr	w14, [x9, #2352]
	add	x15, x13, #8
	mov	x16, x14
	mov	x9, x8
	mov	x12, x8
	mov	w24, #88                        ; =0x58
	b	LBB87_60
LBB87_59:                               ;   in Loop: Header=BB87_60 Depth=2
	add	w10, w10, #1
	add	w16, w16, #1
	cmp	w10, w23
	b.eq	LBB87_76
LBB87_60:                               ;   Parent Loop BB87_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB87_63 Depth 3
	add	w17, w14, w10
	mov	w0, #136                        ; =0x88
	umull	x17, w17, w0
	ldrb	w17, [x13, x17]
	cbz	x17, LBB87_59
; %bb.61:                               ;   in Loop: Header=BB87_60 Depth=2
	umaddl	x0, w16, w0, x15
	b	LBB87_63
LBB87_62:                               ;   in Loop: Header=BB87_63 Depth=3
	subs	x17, x17, #1
	b.eq	LBB87_59
LBB87_63:                               ;   Parent Loop BB87_3 Depth=1
                                        ;     Parent Loop BB87_60 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x1, [x0], #8
	ldrb	w2, [x1, #79]
	cmp	w2, #1
	b.ne	LBB87_62
; %bb.64:                               ;   in Loop: Header=BB87_63 Depth=3
	ldr	w2, [x1, #100]
	cmp	w2, #1
	b.ne	LBB87_62
; %bb.65:                               ;   in Loop: Header=BB87_63 Depth=3
	ldr	w2, [x1, #108]
	ldr	w3, [x21, #24]
	cmp	w2, w3
	b.hs	LBB87_102
; %bb.66:                               ;   in Loop: Header=BB87_63 Depth=3
	ldrb	w3, [x25, x2]
	cmp	w3, #1
	b.ne	LBB87_102
; %bb.67:                               ;   in Loop: Header=BB87_63 Depth=3
	ldrh	w3, [x1, #128]
	ldrh	w4, [x1, #124]
	subs	w3, w4, w3
	b.lo	LBB87_102
; %bb.68:                               ;   in Loop: Header=BB87_63 Depth=3
	ldrh	w4, [x1, #80]
	cmp	w3, w4
	b.hi	LBB87_102
; %bb.69:                               ;   in Loop: Header=BB87_63 Depth=3
	umaddl	x1, w2, w24, x7
	ldr	x2, [x1, #64]
	sub	x3, x11, w3, uxtw
	add	x3, x3, x4
	add	x2, x3, x2
	cmp	x2, x12
	b.ls	LBB87_71
; %bb.70:                               ;   in Loop: Header=BB87_63 Depth=3
	str	x2, [x26, #64]
	mov	x12, x2
LBB87_71:                               ;   in Loop: Header=BB87_63 Depth=3
	ldr	x2, [x1, #72]
	add	x2, x2, x8
	cmp	x2, x9
	b.ls	LBB87_73
; %bb.72:                               ;   in Loop: Header=BB87_63 Depth=3
	str	x2, [x26, #72]
	mov	x9, x2
LBB87_73:                               ;   in Loop: Header=BB87_63 Depth=3
	ldrh	w1, [x1, #44]
	ldrh	w2, [x26, #44]
	cmp	w1, w2
	b.lo	LBB87_62
; %bb.74:                               ;   in Loop: Header=BB87_63 Depth=3
	add	w1, w1, #1
	strh	w1, [x26, #44]
	b	LBB87_62
LBB87_75:                               ;   in Loop: Header=BB87_3 Depth=1
	mov	x9, x8
	mov	x12, x8
LBB87_76:                               ;   in Loop: Header=BB87_3 Depth=1
	ldrh	w8, [x26, #44]
	lsl	w10, w8, #8
	stp	w10, w10, [x26, #52]
	mov	w0, #3                          ; =0x3
	cmp	w8, #64
	b.hi	LBB87_103
; %bb.77:                               ;   in Loop: Header=BB87_3 Depth=1
	mov	w8, #49216                      ; =0xc040
	cmp	x12, x8
	b.hi	LBB87_103
; %bb.78:                               ;   in Loop: Header=BB87_3 Depth=1
	cmp	x9, x8
	b.hi	LBB87_103
; %bb.79:                               ;   in Loop: Header=BB87_3 Depth=1
	add	x25, sp, #64
	mov	w8, #1                          ; =0x1
	strb	w8, [x25, x28]
	add	x5, x5, #1
	ldr	w8, [x21, #24]
	cmp	x5, x8
	mov	w9, #88                         ; =0x58
	mov	w10, #36                        ; =0x24
	mov	w11, #65537                     ; =0x10001
	mov	w12, #136                       ; =0x88
	b.lo	LBB87_3
LBB87_80:
	ldp	w10, w8, [x19, #20]
	add	x9, x19, #112
	cmn	w10, #1
	b.eq	LBB87_91
; %bb.81:
	mov	w11, #88                        ; =0x58
	umaddl	x10, w10, w11, x9
	ldr	x11, [x10, #64]
	ldr	x12, [x19, #40]
	cmp	x11, x12
	b.ls	LBB87_83
; %bb.82:
	str	x11, [x19, #40]
LBB87_83:
	ldr	x11, [x10, #72]
	ldr	x12, [x19, #48]
	cmp	x11, x12
	b.ls	LBB87_85
; %bb.84:
	str	x11, [x19, #48]
LBB87_85:
	ldrh	w11, [x10, #44]
	ldrh	w12, [x19, #56]
	cmp	w11, w12
	b.ls	LBB87_87
; %bb.86:
	strh	w11, [x19, #56]
LBB87_87:
	ldr	w11, [x10, #52]
	ldr	w12, [x19, #60]
	cmp	w11, w12
	b.ls	LBB87_89
; %bb.88:
	str	w11, [x19, #60]
LBB87_89:
	ldr	w10, [x10, #56]
	ldr	w11, [x19, #64]
	cmp	w10, w11
	b.ls	LBB87_91
; %bb.90:
	str	w10, [x19, #64]
LBB87_91:
	cmn	w8, #1
	b.eq	LBB87_105
; %bb.92:
	mov	w10, #88                        ; =0x58
	umaddl	x8, w8, w10, x9
	ldr	x9, [x8, #64]
	ldr	x10, [x19, #40]
	cmp	x9, x10
	b.ls	LBB87_94
; %bb.93:
	str	x9, [x19, #40]
LBB87_94:
	ldr	x9, [x8, #72]
	ldr	x10, [x19, #48]
	cmp	x9, x10
	b.ls	LBB87_96
; %bb.95:
	str	x9, [x19, #48]
LBB87_96:
	ldrh	w9, [x8, #44]
	ldrh	w10, [x19, #56]
	cmp	w9, w10
	b.ls	LBB87_98
; %bb.97:
	strh	w9, [x19, #56]
LBB87_98:
	ldr	w9, [x8, #52]
	ldr	w10, [x19, #60]
	cmp	w9, w10
	b.ls	LBB87_100
; %bb.99:
	str	w9, [x19, #60]
LBB87_100:
	ldr	w8, [x8, #56]
	ldr	w9, [x19, #64]
	cmp	w8, w9
	b.ls	LBB87_105
; %bb.101:
	mov	w0, #0                          ; =0x0
	str	w8, [x19, #64]
	b	LBB87_103
LBB87_102:
	mov	w0, #1                          ; =0x1
LBB87_103:
	ldur	x8, [x29, #-88]
Lloh43:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh44:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh45:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB87_107
; %bb.104:
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
LBB87_105:
	mov	w0, #0                          ; =0x0
	b	LBB87_103
LBB87_106:
	mov	w0, #2                          ; =0x2
	b	LBB87_103
LBB87_107:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh40, Lloh41, Lloh42
	.loh AdrpLdrGotLdr	Lloh43, Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_query_summary ; -- Begin function nvm_file_cyclic_hosted_query_summary
	.globl	_nvm_file_cyclic_hosted_query_summary
	.p2align	2
_nvm_file_cyclic_hosted_query_summary:  ; @nvm_file_cyclic_hosted_query_summary
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB88_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB88_4
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB88_4
; %bb.3:
	ldp	q0, q1, [x8, #16]
	ldr	x8, [x8, #48]
	str	x8, [x1, #32]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB88_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_startup ; -- Begin function nvm_file_cyclic_hosted_startup
	.globl	_nvm_file_cyclic_hosted_startup
	.p2align	2
_nvm_file_cyclic_hosted_startup:        ; @nvm_file_cyclic_hosted_startup
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB89_2
; %bb.1:
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [x1]
	ldp	q0, q1, [x8, #48]
	ldp	q2, q3, [x8, #80]
	stp	q2, q3, [x1, #64]
	stp	q0, q1, [x1, #32]
LBB89_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_function ; -- Begin function nvm_file_cyclic_hosted_function
	.globl	_nvm_file_cyclic_hosted_function
	.p2align	2
_nvm_file_cyclic_hosted_function:       ; @nvm_file_cyclic_hosted_function
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB90_4
; %bb.1:
	cbz	x2, LBB90_4
; %bb.2:
	ldr	w9, [x8, #28]
	cmp	w1, w9
	b.hs	LBB90_5
; %bb.3:
	mov	w9, #88                         ; =0x58
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8, #112]
	stp	q0, q1, [x2]
	ldp	q0, q1, [x8, #144]
	ldr	q2, [x8, #176]
	ldr	x8, [x8, #192]
	str	x8, [x2, #80]
	stp	q1, q2, [x2, #48]
	str	q0, [x2, #32]
	mov	w0, #1                          ; =0x1
LBB90_4:
	ret
LBB90_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_function_order ; -- Begin function nvm_file_cyclic_hosted_function_order
	.globl	_nvm_file_cyclic_hosted_function_order
	.p2align	2
_nvm_file_cyclic_hosted_function_order: ; @nvm_file_cyclic_hosted_function_order
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB91_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB91_5
; %bb.2:
	ldr	x8, [x8]
	ldr	x8, [x8]
	cbz	x8, LBB91_5
; %bb.3:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB91_6
; %bb.4:
	add	x8, x8, w1, uxtw #2
	ldr	w8, [x8, #2608]
	str	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB91_5:
	ret
LBB91_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_local ; -- Begin function nvm_file_cyclic_hosted_local
	.globl	_nvm_file_cyclic_hosted_local
	.p2align	2
_nvm_file_cyclic_hosted_local:          ; @nvm_file_cyclic_hosted_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB92_9
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB92_8
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB92_8
; %bb.3:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB92_9
; %bb.4:
	ldr	x8, [x8]
	cbz	x8, LBB92_9
; %bb.5:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB92_8
; %bb.6:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB92_8
; %bb.7:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB92_8:
	mov	w0, #0                          ; =0x0
LBB92_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_instruction ; -- Begin function nvm_file_cyclic_hosted_instruction
	.globl	_nvm_file_cyclic_hosted_instruction
	.p2align	2
_nvm_file_cyclic_hosted_instruction:    ; @nvm_file_cyclic_hosted_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB93_7
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB93_8
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB93_7
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB93_7
; %bb.4:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB93_8
; %bb.5:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB93_8
; %bb.6:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, w1
	ldr	x10, [x8, #16]
	add	x8, x8, x9, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x0, x3
	mov	w2, #600                        ; =0x258
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB93_7:
	ret
LBB93_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_component ; -- Begin function nvm_file_cyclic_hosted_component
	.globl	_nvm_file_cyclic_hosted_component
	.p2align	2
_nvm_file_cyclic_hosted_component:      ; @nvm_file_cyclic_hosted_component
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB94_8
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB94_7
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB94_7
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB94_7
; %bb.4:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB94_8
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB94_8
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrh	w8, [x8, #2]
	strh	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB94_7:
	mov	w0, #0                          ; =0x0
LBB94_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_variant_count ; -- Begin function nvm_file_cyclic_hosted_variant_count
	.globl	_nvm_file_cyclic_hosted_variant_count
	.p2align	2
_nvm_file_cyclic_hosted_variant_count:  ; @nvm_file_cyclic_hosted_variant_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB95_8
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB95_7
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB95_7
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB95_7
; %bb.4:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB95_8
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB95_8
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB95_7:
	mov	w0, #0                          ; =0x0
LBB95_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_variant ; -- Begin function nvm_file_cyclic_hosted_variant
	.globl	_nvm_file_cyclic_hosted_variant
	.p2align	2
_nvm_file_cyclic_hosted_variant:        ; @nvm_file_cyclic_hosted_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB96_10
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB96_9
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB96_9
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB96_9
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB96_9
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB96_9
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x4, LBB96_10
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB96_10
; %bb.8:
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	stp	q1, q2, [x4, #16]
	str	q0, [x4]
	ldur	q0, [x8, #104]
	ldur	q1, [x8, #120]
	ldur	q2, [x8, #136]
	ldr	x8, [x8, #152]
	str	x8, [x4, #96]
	stp	q1, q2, [x4, #64]
	str	q0, [x4, #48]
	mov	w0, #1                          ; =0x1
	ret
LBB96_9:
	mov	w0, #0                          ; =0x0
LBB96_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_input_local ; -- Begin function nvm_file_cyclic_hosted_input_local
	.globl	_nvm_file_cyclic_hosted_input_local
	.p2align	2
_nvm_file_cyclic_hosted_input_local:    ; @nvm_file_cyclic_hosted_input_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB97_11
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB97_10
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB97_10
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB97_10
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB97_10
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB97_10
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB97_11
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB97_11
; %bb.8:
	ldrh	w9, [x8]
	cmp	w4, w9
	b.hs	LBB97_10
; %bb.9:
	ldr	x8, [x8, #16]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB97_10:
	mov	w0, #0                          ; =0x0
LBB97_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_input_stack ; -- Begin function nvm_file_cyclic_hosted_input_stack
	.globl	_nvm_file_cyclic_hosted_input_stack
	.p2align	2
_nvm_file_cyclic_hosted_input_stack:    ; @nvm_file_cyclic_hosted_input_stack
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB98_11
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB98_10
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB98_10
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB98_10
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB98_10
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB98_10
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB98_11
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB98_11
; %bb.8:
	ldrh	w9, [x8, #2]
	cmp	w4, w9
	b.hs	LBB98_10
; %bb.9:
	ldr	x8, [x8, #24]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB98_10:
	mov	w0, #0                          ; =0x0
LBB98_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_input_reference ; -- Begin function nvm_file_cyclic_hosted_input_reference
	.globl	_nvm_file_cyclic_hosted_input_reference
	.p2align	2
_nvm_file_cyclic_hosted_input_reference: ; @nvm_file_cyclic_hosted_input_reference
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB99_12
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB99_11
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB99_11
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB99_11
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB99_11
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB99_11
; %bb.6:
	mov	w0, #0                          ; =0x0
	cmp	w4, #255
	b.hi	LBB99_12
; %bb.7:
	cbz	x5, LBB99_12
; %bb.8:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB99_12
; %bb.9:
	ldrh	w9, [x8, #48]
	cmp	w4, w9
	b.hs	LBB99_13
; %bb.10:
	ldr	x8, [x8, #32]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	str	q1, [x5, #16]
	b	LBB99_14
LBB99_11:
	mov	w0, #0                          ; =0x0
LBB99_12:
	ret
LBB99_13:
	str	xzr, [x5, #32]
	movi.2d	v0, #0000000000000000
	str	q0, [x5, #16]
LBB99_14:
	str	q0, [x5]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_input_region ; -- Begin function nvm_file_cyclic_hosted_input_region
	.globl	_nvm_file_cyclic_hosted_input_region
	.p2align	2
_nvm_file_cyclic_hosted_input_region:   ; @nvm_file_cyclic_hosted_input_region
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB100_11
; %bb.1:
	ldr	x9, [x0]
	cbz	x9, LBB100_10
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB100_10
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB100_10
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB100_10
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB100_10
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB100_11
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB100_11
; %bb.8:
	ldrh	w9, [x8, #4]
	cmp	w4, w9
	b.hs	LBB100_10
; %bb.9:
	ldr	x8, [x8, #40]
	ldr	x8, [x8, w4, uxtw #3]
	str	x8, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB100_10:
	mov	w0, #0                          ; =0x0
LBB100_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_type ; -- Begin function nvm_file_cyclic_hosted_type
	.globl	_nvm_file_cyclic_hosted_type
	.p2align	2
_nvm_file_cyclic_hosted_type:           ; @nvm_file_cyclic_hosted_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB101_3
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB101_3
; %bb.2:
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_type
LBB101_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_import ; -- Begin function nvm_file_cyclic_hosted_import
	.globl	_nvm_file_cyclic_hosted_import
	.p2align	2
_nvm_file_cyclic_hosted_import:         ; @nvm_file_cyclic_hosted_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB102_3
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB102_3
; %bb.2:
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_import
LBB102_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_cyclic_hosted_bytes ; -- Begin function nvm_file_cyclic_hosted_bytes
	.globl	_nvm_file_cyclic_hosted_bytes
	.p2align	2
_nvm_file_cyclic_hosted_bytes:          ; @nvm_file_cyclic_hosted_bytes
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB103_3
; %bb.1:
	cbnz	x2, LBB103_4
; %bb.2:
	cbz	x3, LBB103_4
LBB103_3:
	mov	w0, #0                          ; =0x0
	ret
LBB103_4:
	ldr	x8, [x0, #72]
	subs	x8, x8, x1
	ccmp	x3, x8, #2, hs
	cset	w9, hi
	eor	w8, w9, #0x1
	cbz	x3, LBB103_7
; %bb.5:
	tbnz	w9, #0, LBB103_7
; %bb.6:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	add	x1, x8, x1
	mov	x0, x2
	mov	x2, x3
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB103_7:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_file_indirect_targets
lCPI104_0:
	.long	3                               ; 0x3
	.long	4294967295                      ; 0xffffffff
	.long	4294967295                      ; 0xffffffff
	.long	0                               ; 0x0
lCPI104_1:
	.long	1                               ; 0x1
	.long	4294967295                      ; 0xffffffff
	.long	4294967295                      ; 0xffffffff
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_file_indirect_targets
	.globl	_nvm_file_indirect_targets
	.p2align	2
_nvm_file_indirect_targets:             ; @nvm_file_indirect_targets
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
	str	wzr, [sp, #24]
	str	xzr, [sp, #16]
	cbz	x1, LBB104_6
; %bb.1:
	mov	x25, x1
	add	x1, sp, #24
	add	x2, sp, #16
	mov	x20, x0
	bl	_file_code_preflight
	cmp	w0, #1
	b.gt	LBB104_7
; %bb.2:
	cbnz	w0, LBB104_9
; %bb.3:
	mov	w9, #64472                      ; =0xfbd8
	movk	w9, #253, lsl #16
	ldr	x8, [sp, #16]
	cmp	x8, x9
	b.hi	LBB104_5
; %bb.4:
	ldr	w21, [sp, #24]
	add	x10, x21, w21, uxtw #1
	lsl	x10, x10, #4
	sub	x9, x9, x8
	cmp	x10, x9
	mov	w9, #1064                       ; =0x428
	movk	w9, #2, lsl #16
	add	x8, x8, x9
	add	x26, x8, x10
	mov	w8, #30448                      ; =0x76f0
	movk	w8, #191, lsl #16
	ccmp	x26, x8, #2, ls
	b.ls	LBB104_14
LBB104_5:
Lloh46:
	adrp	x8, lCPI104_0@PAGE
Lloh47:
	ldr	q0, [x8, lCPI104_0@PAGEOFF]
	str	q0, [x19]
Lloh48:
	adrp	x8, l_.str.7@PAGE
Lloh49:
	add	x8, x8, l_.str.7@PAGEOFF
	b	LBB104_13
LBB104_6:
Lloh50:
	adrp	x8, lCPI104_1@PAGE
Lloh51:
	ldr	q0, [x8, lCPI104_1@PAGEOFF]
Lloh52:
	adrp	x8, l_.str.4@PAGE
Lloh53:
	add	x8, x8, l_.str.4@PAGEOFF
	str	q0, [x19]
	b	LBB104_13
LBB104_7:
	cmp	w0, #3
	b.ne	LBB104_10
; %bb.8:
Lloh54:
	adrp	x8, l_.str.7@PAGE
Lloh55:
	add	x8, x8, l_.str.7@PAGEOFF
	b	LBB104_11
LBB104_9:
Lloh56:
	adrp	x8, l_.str.4@PAGE
Lloh57:
	add	x8, x8, l_.str.4@PAGEOFF
	b	LBB104_11
LBB104_10:
Lloh58:
	adrp	x8, l_.str.6@PAGE
Lloh59:
	add	x8, x8, l_.str.6@PAGEOFF
LBB104_11:
	str	w0, [x19]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #4]
LBB104_12:
	str	wzr, [x19, #12]
LBB104_13:
	str	x8, [x19, #16]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB104_14:
	str	xzr, [sp, #8]
	mov	w22, #1                         ; =0x1
	add	x1, sp, #8
	mov	x0, x20
	mov	w2, #0                          ; =0x0
	mov	w3, #1                          ; =0x1
	bl	_file_code_prepare_profile
Lloh60:
	adrp	x8, l_.str.4@PAGE
Lloh61:
	add	x8, x8, l_.str.4@PAGEOFF
	mov	w23, #-1                        ; =0xffffffff
	cmp	w0, #2
	b.gt	LBB104_18
; %bb.15:
	cbz	w0, LBB104_21
; %bb.16:
	mov	w9, #-1                         ; =0xffffffff
	cmp	w0, #2
	b.ne	LBB104_41
; %bb.17:
	mov	w23, #-1                        ; =0xffffffff
	mov	x22, x0
Lloh62:
	adrp	x8, l_.str.6@PAGE
Lloh63:
	add	x8, x8, l_.str.6@PAGEOFF
	b	LBB104_41
LBB104_18:
	cmp	w0, #3
	b.eq	LBB104_36
; %bb.19:
	mov	w9, #-1                         ; =0xffffffff
	cmp	w0, #4
	b.ne	LBB104_41
; %bb.20:
	mov	w23, #-1                        ; =0xffffffff
	mov	x22, x0
	b	LBB104_40
LBB104_21:
	mov	w0, #1                          ; =0x1
	mov	w1, #1064                       ; =0x428
	movk	w1, #2, lsl #16
	bl	_calloc
	ldr	x24, [sp, #8]
	cbz	x0, LBB104_37
; %bb.22:
	mov	x20, x0
	mov	w8, #35088                      ; =0x8910
	movk	w8, #64, lsl #16
	add	x8, x26, x8
	str	x24, [x0]
	ldr	w26, [x24, #24]
	stp	w26, w21, [x0, #8]
	str	x8, [x0, #24]
	mov	x0, x21
	mov	w1, #48                         ; =0x30
	bl	_calloc
	mov	x22, x0
	str	x0, [x20, #32]
	mov	w0, #1                          ; =0x1
	mov	w1, #35088                      ; =0x8910
	movk	w1, #64, lsl #16
	bl	_calloc
	mov	x21, x0
	cbz	x22, LBB104_38
; %bb.23:
	cbz	x21, LBB104_38
; %bb.24:
	add	x22, x20, #40
	mov	w8, #11056                      ; =0x2b30
	add	x1, x24, x8
	mov	x0, x22
	mov	w2, #512                        ; =0x200
	bl	_memcpy
	mov	w27, #-1                        ; =0xffffffff
LBB104_25:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB104_27 Depth 2
	strb	wzr, [sp, #7]
	cbz	w26, LBB104_30
; %bb.26:                               ;   in Loop: Header=BB104_25 Depth=1
	mov	w23, #0                         ; =0x0
LBB104_27:                              ;   Parent Loop BB104_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w27, [sp, #28]
	add	x3, sp, #28
	add	x5, sp, #7
	mov	x0, x20
	mov	x1, x23
	mov	x2, x21
	mov	w4, #0                          ; =0x0
	bl	_fi_function
	cbnz	w0, LBB104_42
; %bb.28:                               ;   in Loop: Header=BB104_27 Depth=2
	add	w23, w23, #1
	ldr	w26, [x24, #24]
	cmp	w23, w26
	b.lo	LBB104_27
; %bb.29:                               ;   in Loop: Header=BB104_25 Depth=1
	ldrb	w8, [sp, #7]
	tbnz	w8, #0, LBB104_25
LBB104_30:
	cbz	w26, LBB104_75
; %bb.31:
	mov	w23, #0                         ; =0x0
	mov	w26, #-1                        ; =0xffffffff
LBB104_32:                              ; =>This Inner Loop Header: Depth=1
	str	w26, [sp, #28]
	add	x3, sp, #28
	add	x5, sp, #7
	mov	x0, x20
	mov	x1, x23
	mov	x2, x21
	mov	w4, #1                          ; =0x1
	bl	_fi_function
	cbnz	w0, LBB104_42
; %bb.33:                               ;   in Loop: Header=BB104_32 Depth=1
	add	w23, w23, #1
	ldr	w8, [x24, #24]
	cmp	w23, w8
	b.lo	LBB104_32
; %bb.34:
	ldrb	w9, [sp, #7]
	tbz	w9, #0, LBB104_43
; %bb.35:
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_nvm_file_indirect_targets_free
Lloh64:
	adrp	x8, l_.str.4@PAGE
Lloh65:
	add	x8, x8, l_.str.4@PAGEOFF
	mov	w22, #1                         ; =0x1
	ldr	w9, [sp, #28]
	b	LBB104_41
LBB104_36:
	mov	w23, #-1                        ; =0xffffffff
	mov	x22, x0
	mov	w9, #-1                         ; =0xffffffff
Lloh66:
	adrp	x8, l_.str.7@PAGE
Lloh67:
	add	x8, x8, l_.str.7@PAGEOFF
	b	LBB104_41
LBB104_37:
	mov	x0, x24
	bl	_nvm_file_code_free
	b	LBB104_39
LBB104_38:
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_nvm_file_indirect_targets_free
LBB104_39:
	mov	w23, #-1                        ; =0xffffffff
	mov	w22, #4                         ; =0x4
	mov	w9, #-1                         ; =0xffffffff
LBB104_40:
Lloh68:
	adrp	x8, l_.str.8@PAGE
Lloh69:
	add	x8, x8, l_.str.8@PAGEOFF
LBB104_41:
	stp	w22, w23, [x19]
	str	w9, [x19, #8]
	b	LBB104_12
LBB104_42:
	mov	x22, x0
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_nvm_file_indirect_targets_free
Lloh70:
	adrp	x8, l_.str.4@PAGE
Lloh71:
	add	x8, x8, l_.str.4@PAGEOFF
	mov	w10, #1                         ; =0x1
	ldr	w9, [sp, #28]
Lloh72:
	adrp	x11, l_.str.7@PAGE
Lloh73:
	add	x11, x11, l_.str.7@PAGEOFF
Lloh74:
	adrp	x12, l_.str.6@PAGE
Lloh75:
	add	x12, x12, l_.str.6@PAGEOFF
	cmp	w22, #2
	csel	w10, w10, w22, ne
	csel	x8, x8, x12, ne
	cmp	w22, #3
	csel	w22, w22, w10, eq
	csel	x8, x11, x8, eq
	b	LBB104_41
LBB104_43:
	cbz	w8, LBB104_75
; %bb.44:
	mov	x9, #0                          ; =0x0
	and	x10, x8, #0x7
	and	x11, x8, #0xfffffff8
	neg	x11, x11
	add	x12, x20, #48
	add	x13, x20, #40
	mov	w14, #1                         ; =0x1
	b	LBB104_46
LBB104_45:                              ;   in Loop: Header=BB104_46 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB104_72
LBB104_46:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB104_50 Depth 2
                                        ;     Child Loop BB104_70 Depth 2
	lsl	x15, x14, x9
	cmp	w8, #8
	b.hs	LBB104_48
; %bb.47:                               ;   in Loop: Header=BB104_46 Depth=1
	mov	x16, #0                         ; =0x0
	b	LBB104_67
LBB104_48:                              ;   in Loop: Header=BB104_46 Depth=1
	mov	x16, #0                         ; =0x0
	mov	x17, x12
	b	LBB104_50
LBB104_49:                              ;   in Loop: Header=BB104_50 Depth=2
	sub	x16, x16, #8
	add	x17, x17, #64
	cmp	x11, x16
	b.eq	LBB104_66
LBB104_50:                              ;   Parent Loop BB104_46 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x0, [x17, #-8]
	tst	x0, x15
	b.eq	LBB104_52
; %bb.51:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	stur	x0, [x17, #-8]
LBB104_52:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17]
	tst	x0, x15
	b.eq	LBB104_54
; %bb.53:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17]
LBB104_54:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17, #8]
	tst	x0, x15
	b.eq	LBB104_56
; %bb.55:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17, #8]
LBB104_56:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17, #16]
	tst	x0, x15
	b.eq	LBB104_58
; %bb.57:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17, #16]
LBB104_58:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17, #24]
	tst	x0, x15
	b.eq	LBB104_60
; %bb.59:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17, #24]
LBB104_60:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17, #32]
	tst	x0, x15
	b.eq	LBB104_62
; %bb.61:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17, #32]
LBB104_62:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17, #40]
	tst	x0, x15
	b.eq	LBB104_64
; %bb.63:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17, #40]
LBB104_64:                              ;   in Loop: Header=BB104_50 Depth=2
	ldr	x0, [x17, #48]
	tst	x0, x15
	b.eq	LBB104_49
; %bb.65:                               ;   in Loop: Header=BB104_50 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x17, #48]
	b	LBB104_49
LBB104_66:                              ;   in Loop: Header=BB104_46 Depth=1
	neg	x16, x16
LBB104_67:                              ;   in Loop: Header=BB104_46 Depth=1
	cbz	x10, LBB104_45
; %bb.68:                               ;   in Loop: Header=BB104_46 Depth=1
	add	x16, x13, x16, lsl #3
	mov	x17, x10
	b	LBB104_70
LBB104_69:                              ;   in Loop: Header=BB104_70 Depth=2
	add	x16, x16, #8
	subs	x17, x17, #1
	b.eq	LBB104_45
LBB104_70:                              ;   Parent Loop BB104_46 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x0, [x16]
	tst	x0, x15
	b.eq	LBB104_69
; %bb.71:                               ;   in Loop: Header=BB104_70 Depth=2
	ldr	x1, [x22, x9, lsl #3]
	orr	x0, x1, x0
	str	x0, [x16]
	b	LBB104_69
LBB104_72:
	mov	x23, #0                         ; =0x0
LBB104_73:                              ; =>This Inner Loop Header: Depth=1
	add	x9, x20, x23, lsl #3
	ldr	x9, [x9, #40]
	lsr	x9, x9, x23
	tbnz	w9, #0, LBB104_76
; %bb.74:                               ;   in Loop: Header=BB104_73 Depth=1
	add	x23, x23, #1
	cmp	w8, w23
	b.ne	LBB104_73
LBB104_75:
	mov	x0, x21
	bl	_free
	mov	w22, #0                         ; =0x0
	str	x20, [x25]
	mov	w23, #-1                        ; =0xffffffff
	mov	w9, #-1                         ; =0xffffffff
Lloh76:
	adrp	x8, l_.str.5@PAGE
Lloh77:
	add	x8, x8, l_.str.5@PAGEOFF
	b	LBB104_41
LBB104_76:
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_nvm_file_indirect_targets_free
Lloh78:
	adrp	x8, l_.str.6@PAGE
Lloh79:
	add	x8, x8, l_.str.6@PAGEOFF
	mov	w9, #-1                         ; =0xffffffff
	mov	w22, #2                         ; =0x2
	b	LBB104_41
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_preflight
_file_code_preflight:                   ; @file_code_preflight
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB105_35
; %bb.1:
	ldr	x8, [x0, #256]
	cbz	x8, LBB105_35
; %bb.2:
	ldr	w9, [x0, #272]
	cbz	w9, LBB105_35
; %bb.3:
	ldr	x8, [x0, #280]
	cbz	x8, LBB105_35
; %bb.4:
	ldr	w10, [x0, #288]
	cbz	w10, LBB105_35
; %bb.5:
	mov	w8, #3                          ; =0x3
	cmp	w9, #64
	b.hi	LBB105_36
; %bb.6:
	cmp	w10, #16, lsl #12               ; =65536
	b.hi	LBB105_36
; %bb.7:
	ldr	w8, [x0, #12]
	cmp	w8, w9
	b.hs	LBB105_35
; %bb.8:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w23, #24                        ; =0x18
	mov	w16, #600                       ; =0x258
LBB105_9:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB105_18 Depth 2
                                        ;     Child Loop BB105_21 Depth 2
	ldr	x11, [x0, #256]
	mov	w8, w22
	umaddl	x28, w8, w23, x11
	ldr	w8, [x28, #12]
	cbz	w8, LBB105_37
; %bb.10:                               ;   in Loop: Header=BB105_9 Depth=1
	ldr	w9, [x28, #8]
	ldr	w10, [x0, #288]
	subs	w10, w10, w9
	ccmp	w8, w10, #2, hs
	b.hi	LBB105_37
; %bb.11:                               ;   in Loop: Header=BB105_9 Depth=1
	ldrh	w12, [x28, #4]
	ldrh	w10, [x28, #16]
	cmp	w12, w10
	b.hi	LBB105_37
; %bb.12:                               ;   in Loop: Header=BB105_9 Depth=1
	ldr	w12, [x28]
	ldr	w13, [x0, #248]
	cmp	w12, w13
	b.hs	LBB105_37
; %bb.13:                               ;   in Loop: Header=BB105_9 Depth=1
	ldrb	w12, [x28, #20]
	cmp	w12, #15
	b.hi	LBB105_37
; %bb.14:                               ;   in Loop: Header=BB105_9 Depth=1
	ldrb	w13, [x28, #21]
	cmp	w13, #0
	cset	w13, eq
	cmp	w12, #0
	cset	w12, ne
	cmp	w12, w13
	b.eq	LBB105_37
; %bb.15:                               ;   in Loop: Header=BB105_9 Depth=1
	cmp	w10, #256
	b.hi	LBB105_34
; %bb.16:                               ;   in Loop: Header=BB105_9 Depth=1
	cbz	w22, LBB105_20
; %bb.17:                               ;   in Loop: Header=BB105_9 Depth=1
	add	w12, w9, w8
	add	x11, x11, #12
	mov	x13, x22
LBB105_18:                              ;   Parent Loop BB105_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	w14, w15, [x11, #-4]
	add	w15, w15, w14
	cmp	w14, w12
	ccmp	w9, w15, #2, lo
	b.lo	LBB105_37
; %bb.19:                               ;   in Loop: Header=BB105_18 Depth=2
	add	x11, x11, #24
	subs	x13, x13, #1
	b.ne	LBB105_18
LBB105_20:                              ;   in Loop: Header=BB105_9 Depth=1
	stp	x1, x2, [sp]                    ; 16-byte Folded Spill
	mov	w25, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	add	x20, x20, x10
	add	w21, w8, w21
	mul	w27, w19, w16
LBB105_21:                              ;   Parent Loop BB105_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	mov	x24, x0
	ldr	x8, [x0, #280]
	ldp	w9, w10, [x28, #8]
	add	x8, x8, x9
	add	x0, x8, w26, uxtw
	sub	w1, w10, w26
	add	x2, sp, #16
	bl	_isa_decode
	cbz	w0, LBB105_37
; %bb.22:                               ;   in Loop: Header=BB105_21 Depth=2
	mov	w8, #3                          ; =0x3
	cmp	w25, #255
	b.hi	LBB105_38
; %bb.23:                               ;   in Loop: Header=BB105_21 Depth=2
	add	w9, w19, w25
	cmp	w9, #1, lsl #12                 ; =4096
	b.hs	LBB105_38
; %bb.24:                               ;   in Loop: Header=BB105_21 Depth=2
	add	w25, w25, #1
	ldr	w8, [x28, #12]
	add	w27, w27, #600
	add	w26, w0, w26
	cmp	w26, w8
	mov	x0, x24
	b.lo	LBB105_21
; %bb.25:                               ;   in Loop: Header=BB105_9 Depth=1
	ldr	w8, [x0, #272]
	add	x22, x22, #1
	add	w19, w19, w25
	cmp	w22, w8
	ldp	x1, x2, [sp]                    ; 16-byte Folded Reload
	mov	w16, #600                       ; =0x258
	b.lo	LBB105_9
; %bb.26:
	ldr	w8, [x0, #288]
	cmp	w21, w8
	b.ne	LBB105_39
; %bb.27:
	str	xzr, [sp, #16]
	add	x1, sp, #16
	mov	w0, #65536                      ; =0x10000
	bl	_nvm_file_nominal_storage_bound
	mov	w8, #3                          ; =0x3
	cbz	w0, LBB105_38
; %bb.28:
	mov	w9, #65422                      ; =0xff8e
	movk	w9, #15, lsl #16
	cmp	x20, x9
	b.hi	LBB105_38
; %bb.29:
	mov	w8, #63720                      ; =0xf8e8
	movk	w8, #255, lsl #16
	lsl	x9, x20, #4
	ldr	x11, [sp, #16]
	sub	x10, x8, x9
	cmp	x11, x10
	b.hi	LBB105_34
; %bb.30:
	mov	w10, #53968                     ; =0xd2d0
	movk	w10, #255, lsl #16
	add	x9, x9, x11
	add	x9, x9, #1816
	cmp	x9, x10
	b.hi	LBB105_34
; %bb.31:
	ldr	w11, [x24, #288]
	sub	x10, x10, x9
	cmp	x10, x11
	b.lo	LBB105_34
; %bb.32:
	mov	w10, #53968                     ; =0xd2d0
	movk	w10, #255, lsl #16
	add	x9, x9, x11
	sub	x10, x10, x9
	cmp	x10, x27
	b.lo	LBB105_34
; %bb.33:
	mov	w10, #11568                     ; =0x2d30
	add	x9, x9, x10
	add	x9, x9, x27
	add	x8, x8, #984
	cmp	x9, x8
	b.ls	LBB105_40
LBB105_34:
	mov	w8, #3                          ; =0x3
	b	LBB105_38
LBB105_35:
	mov	w8, #1                          ; =0x1
LBB105_36:
	mov	x0, x8
	ret
LBB105_37:
	mov	w8, #1                          ; =0x1
LBB105_38:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	mov	x0, x8
	ret
LBB105_39:
	mov	w8, #2                          ; =0x2
	b	LBB105_38
LBB105_40:
	mov	w8, #0                          ; =0x0
	add	x10, x9, #832
	ldp	x11, x9, [sp]                   ; 16-byte Folded Reload
	str	w19, [x11]
	str	x10, [x9]
	b	LBB105_38
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_prepare_profile
_file_code_prepare_profile:             ; @file_code_prepare_profile
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x1, LBB106_7
; %bb.1:
	mov	x20, x3
	mov	x21, x0
	mov	x27, x2
	mov	x26, x1
	sub	x1, x29, #112
	sub	x2, x29, #120
	bl	_file_code_preflight
	mov	x24, x0
	cbnz	w0, LBB106_8
; %bb.2:
	str	xzr, [sp, #128]
	add	x1, sp, #128
	mov	x0, x21
	mov	x2, x20
	bl	_file_flow_declarations_mode
	mov	x24, x0
	cbnz	w0, LBB106_8
; %bb.3:
	ldr	x22, [sp, #128]
	add	x28, x22, #24
	ldr	w10, [x21, #12]
	mov	w8, #24                         ; =0x18
	umaddl	x8, w10, w8, x28
	ldrb	w9, [x8, #8]
	mov	w11, #250                       ; =0xfa
	and	w11, w9, w11
	cmp	w9, #5
	ccmp	w11, #0, #0, ne
	b.ne	LBB106_5
; %bb.4:
	ldr	w9, [x8, #12]
	cmn	w9, #1
	b.eq	LBB106_10
LBB106_5:
	ldr	w8, [x22]
	subs	w8, w8, #1
	str	w8, [x22]
	b.eq	LBB106_9
; %bb.6:
	mov	w24, #2                         ; =0x2
	b	LBB106_8
LBB106_7:
	mov	w24, #1                         ; =0x1
LBB106_8:
	mov	x0, x24
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB106_9:
	ldr	x0, [x22, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x22
	bl	_free
	mov	w24, #2                         ; =0x2
	b	LBB106_8
LBB106_10:
	ldrh	w8, [x8]
	cbz	x8, LBB106_15
; %bb.11:
	add	x9, x22, #1816
	add	x10, x22, x10, lsl #2
	ldr	w10, [x10, #1560]
	mov	w11, #250                       ; =0xfa
LBB106_12:                              ; =>This Inner Loop Header: Depth=1
	add	x12, x9, w10, uxtw #4
	ldrb	w13, [x12, #1]
	cbnz	w13, LBB106_127
; %bb.13:                               ;   in Loop: Header=BB106_12 Depth=1
	ldr	w13, [x12, #4]
	ldrb	w12, [x12]
	and	w12, w12, w11
	cmp	w12, #0
	ccmn	w13, #1, #0, eq
	b.ne	LBB106_127
; %bb.14:                               ;   in Loop: Header=BB106_12 Depth=1
	add	w10, w10, #1
	subs	x8, x8, #1
	b.ne	LBB106_12
LBB106_15:
	mov	w0, #1                          ; =0x1
	mov	w1, #11568                      ; =0x2d30
	bl	_calloc
	cbz	x0, LBB106_128
; %bb.16:
	str	x22, [x0]
	ldr	w8, [x21, #272]
	ldr	w22, [x21, #288]
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	stp	w8, w22, [x0, #24]
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
	ldur	w23, [x29, #-112]
	mov	x8, x0
	str	w23, [x8, #32]
	ldur	x8, [x29, #-120]
	mov	x9, x0
	str	x8, [x9, #40]
	mov	x0, x22
	bl	_malloc
	mov	x24, x0
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	str	x0, [x8, #8]
	mov	x0, x23
	ldr	x23, [sp, #120]                 ; 8-byte Folded Reload
	mov	w1, #600                        ; =0x258
	bl	_calloc
	mov	x8, x0
	mov	x0, x24
	str	x8, [x23, #16]
	mov	w24, #4                         ; =0x4
	cbz	x0, LBB106_131
; %bb.17:
	cbz	x8, LBB106_131
; %bb.18:
	ldr	x1, [x21, #280]
	mov	x2, x22
	bl	_memcpy
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cbz	w8, LBB106_126
; %bb.19:
	mov	x22, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	add	x9, x23, #48
	add	x10, x23, #2352
	mov	w8, #11056                      ; =0x2b30
	add	x8, x23, x8
	stp	x8, x10, [sp, #16]              ; 16-byte Folded Spill
	add	x8, x23, #62
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	mov	w8, #36                         ; =0x24
	mov	x2, x27
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
LBB106_20:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB106_25 Depth 2
                                        ;       Child Loop BB106_75 Depth 3
                                        ;       Child Loop BB106_57 Depth 3
	madd	x24, x22, x8, x9
	ldr	x8, [x21, #256]
	add	x9, x22, x22, lsl #1
	lsl	x9, x9, #3
	add	x8, x8, x9
	ldr	w17, [x8, #12]
	ldr	d0, [x8, #8]
	str	d0, [x24]
	add	x8, x28, x9
	ldr	q0, [x8]
	ldr	x8, [x8, #16]
	stur	x8, [x24, #28]
	stur	q0, [x24, #12]
	str	w19, [x10, x22, lsl #2]
	cbz	w17, LBB106_117
; %bb.21:                               ;   in Loop: Header=BB106_20 Depth=1
	mov	w25, #0                         ; =0x0
	add	x8, x22, x22, lsl #3
	lsl	x8, x8, #2
	stp	x8, x24, [sp, #56]              ; 16-byte Folded Spill
	ldp	x8, x10, [x23, #8]
	ldr	w9, [x24]
	add	x8, x8, x9
	stp	x8, x10, [sp, #80]              ; 16-byte Folded Spill
	add	x8, x10, #78
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	str	x22, [sp, #40]                  ; 8-byte Folded Spill
	str	w17, [sp, #100]                 ; 4-byte Folded Spill
	b	LBB106_25
LBB106_22:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrb	w8, [x23, #16]
LBB106_23:                              ;   in Loop: Header=BB106_25 Depth=2
	cmp	w8, #1
	b.hi	LBB106_129
LBB106_24:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	w19, [sp, #112]                 ; 4-byte Folded Reload
	add	w19, w19, #1
	ldr	x24, [sp, #64]                  ; 8-byte Folded Reload
	ldrh	w8, [x24, #8]
	add	w8, w8, #1
	strh	w8, [x24, #8]
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	add	w25, w8, w25
	cmp	w25, w17
	b.hs	LBB106_117
LBB106_25:                              ;   Parent Loop BB106_20 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB106_75 Depth 3
                                        ;       Child Loop BB106_57 Depth 3
	mov	w8, #600                        ; =0x258
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	umaddl	x23, w19, w8, x9
	str	w25, [x23]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x23, #592]
	str	w8, [x23, #72]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	x0, x8, w25, uxtw
	sub	w1, w17, w25
	add	x2, x23, #8
	bl	_isa_decode
	cbz	w0, LBB106_129
; %bb.26:                               ;   in Loop: Header=BB106_25 Depth=2
	str	w0, [sp, #116]                  ; 4-byte Folded Spill
	ldurb	w24, [x23, #8]
	mov	x0, x24
	cbz	w20, LBB106_28
; %bb.27:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	w1, #1                          ; =0x1
	bl	_file_code_supported_mode
	tbnz	w0, #0, LBB106_29
	b	LBB106_132
LBB106_28:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	w1, #0                          ; =0x0
	bl	_file_code_supported_mode
	cbz	w0, LBB106_132
LBB106_29:                              ;   in Loop: Header=BB106_25 Depth=2
	sub	w8, w24, #3
	cmp	w8, #149
	str	w19, [sp, #112]                 ; 4-byte Folded Spill
	b.hi	LBB106_40
; %bb.30:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	w9, #600                        ; =0x258
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	umaddl	x19, w19, w9, x10
Lloh80:
	adrp	x11, lJTI106_0@PAGE
Lloh81:
	add	x11, x11, lJTI106_0@PAGEOFF
	adr	x9, LBB106_22
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	mov	x2, x27
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	br	x9
LBB106_31:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #16]
	ldp	x9, x10, [sp, #48]              ; 16-byte Folded Reload
	ldrh	w9, [x9, x10]
	cmp	w8, w9
	b.hs	LBB106_129
; %bb.32:                               ;   in Loop: Header=BB106_25 Depth=2
	cmp	w24, #147
	b.ne	LBB106_24
; %bb.33:                               ;   in Loop: Header=BB106_25 Depth=2
	ldrb	w8, [x23, #24]
	b	LBB106_23
LBB106_34:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	w0, [x23, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cmp	w0, w8
	b.hs	LBB106_129
; %bb.35:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x22, [x8]
	cbz	x22, LBB106_129
; %bb.36:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	w8, [x22, #4]
	cmp	w0, w8
	b.hs	LBB106_129
; %bb.37:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	w8, #24                         ; =0x18
	umaddl	x8, w0, w8, x22
	ldrh	w1, [x8, #24]
	cmp	w24, #151
	b.ne	LBB106_48
; %bb.38:                               ;   in Loop: Header=BB106_25 Depth=2
	stp	x1, x0, [sp]                    ; 16-byte Folded Spill
	ldr	w1, [x23, #24]
	mov	x0, x21
	bl	_nvm_get_string
	cbz	x0, LBB106_129
; %bb.39:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	x24, x0
	ldr	w1, [x23, #24]
	mov	x0, x21
	bl	_nvm_get_string_len
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	cmp	w0, w1, lsl #1
	mov	x2, x27
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	b.eq	LBB106_49
	b	LBB106_129
LBB106_40:                              ;   in Loop: Header=BB106_25 Depth=2
	cmp	w24, #250
	mov	x2, x27
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	b.eq	LBB106_92
; %bb.41:                               ;   in Loop: Header=BB106_25 Depth=2
	cmp	w24, #251
	b.ne	LBB106_24
LBB106_42:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	x8, x23
	ldrh	w22, [x8, #24]!
	sub	x9, x8, #8
	ldrh	w19, [x8, #8]
	cmp	w24, #251
	b.ne	LBB106_85
; %bb.43:                               ;   in Loop: Header=BB106_25 Depth=2
	ldrb	w9, [x9]
	cmp	w9, #2
	b.hi	LBB106_129
; %bb.44:                               ;   in Loop: Header=BB106_25 Depth=2
	b.eq	LBB106_132
; %bb.45:                               ;   in Loop: Header=BB106_25 Depth=2
	cmp	w9, #0
	mov	w9, #2                          ; =0x2
	csel	w1, wzr, w9, eq
	mov	x22, x19
	ldrh	w19, [x23, #40]
	mov	x9, x8
	b	LBB106_86
LBB106_46:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #16]
	cmp	w8, #255
	b.hi	LBB106_129
; %bb.47:                               ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #24]
	ldp	x9, x10, [sp, #48]              ; 16-byte Folded Reload
	ldrh	w9, [x9, x10]
	cmp	w8, w9
	b.lo	LBB106_24
	b	LBB106_129
LBB106_48:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	x24, #0                         ; =0x0
LBB106_49:                              ;   in Loop: Header=BB106_25 Depth=2
	cbz	w1, LBB106_80
; %bb.50:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	w8, [x22, #4]
	cmp	w0, w8
	b.hs	LBB106_129
; %bb.51:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	x9, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	add	x10, x0, x0, lsl #1
	lsl	x10, x10, #3
	add	x11, x22, #26
	add	x12, x22, #1560
	add	x13, x22, #1817
	add	x14, x24, #1
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	b	LBB106_57
LBB106_52:                              ;   in Loop: Header=BB106_57 Depth=3
	cbz	w16, LBB106_61
; %bb.53:                               ;   in Loop: Header=BB106_57 Depth=3
	ldurb	w15, [x23, #8]
	cmp	w15, #15
	b.ne	LBB106_129
; %bb.54:                               ;   in Loop: Header=BB106_57 Depth=3
	ldrh	w15, [x23, #24]
LBB106_55:                              ;   in Loop: Header=BB106_57 Depth=3
	cmp	w15, #255
	b.hi	LBB106_129
LBB106_56:                              ;   in Loop: Header=BB106_57 Depth=3
	strh	w15, [x19, x9, lsl #1]
	add	x9, x9, #1
	add	x14, x14, #2
	cmp	x1, x9
	b.eq	LBB106_81
LBB106_57:                              ;   Parent Loop BB106_20 Depth=1
                                        ;     Parent Loop BB106_25 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w15, [x11, x10]
	cmp	x9, x15
	b.hs	LBB106_129
; %bb.58:                               ;   in Loop: Header=BB106_57 Depth=3
	ldr	w15, [x12, x0, lsl #2]
	add	w15, w9, w15
	ubfiz	x15, x15, #4, #32
	ldrb	w16, [x13, x15]
	cmp	w16, #0
	cinc	w8, w8, ne
	cbz	x24, LBB106_52
; %bb.59:                               ;   in Loop: Header=BB106_57 Depth=3
	ldurh	w15, [x14, #-1]
	cbnz	w16, LBB106_55
; %bb.60:                               ;   in Loop: Header=BB106_57 Depth=3
	mov	w16, #65535                     ; =0xffff
	cmp	w15, w16
	mov	w15, #65535                     ; =0xffff
	b.eq	LBB106_56
	b	LBB106_129
LBB106_61:                              ;   in Loop: Header=BB106_57 Depth=3
	mov	w15, #65535                     ; =0xffff
	b	LBB106_56
LBB106_62:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #16]
	cmp	w8, #255
	b.ls	LBB106_24
	b	LBB106_129
LBB106_63:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x19, [x8]
	ldr	x0, [x19, #16]
	sub	x2, x29, #108
	mov	w1, #0                          ; =0x0
	bl	_nvm_file_nominal_import
	tbz	w0, #0, LBB106_96
; %bb.64:                               ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-108]
	ldr	w9, [x23, #16]
	cmp	w8, w9
	b.ne	LBB106_96
; %bb.65:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	x24, #0                         ; =0x0
	b	LBB106_112
LBB106_66:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	w1, [x23, #16]
	ldr	w8, [x21, #248]
	cmp	w1, w8
	b.hs	LBB106_129
; %bb.67:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	x0, x21
	bl	_nvm_get_string
	cbz	x0, LBB106_129
; %bb.68:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	w1, [x23, #16]
	mov	x0, x21
	bl	_nvm_get_string_len
	cmp	w0, #256, lsl #12               ; =1048576
	mov	x2, x27
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	b.ls	LBB106_24
	b	LBB106_135
LBB106_69:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w22, [x23, #16]
	cmp	w22, #256
	b.hi	LBB106_129
; %bb.70:                               ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #24]
	cmp	w8, #1
	b.hi	LBB106_129
; %bb.71:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	w24, [x23, #32]
	mov	x0, x21
	mov	x1, x24
	bl	_nvm_get_string
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	cbz	x0, LBB106_129
; %bb.72:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	x0, x21
	mov	x1, x24
	bl	_nvm_get_string_len
	mov	w24, #1                         ; =0x1
	ldr	x23, [sp, #120]                 ; 8-byte Folded Reload
	cbz	w22, LBB106_131
; %bb.73:                               ;   in Loop: Header=BB106_25 Depth=2
	lsl	w8, w22, #1
	cmp	w0, w8
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	b.ne	LBB106_131
; %bb.74:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	w8, #0                          ; =0x0
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x9, x9, #1
	mov	x2, x27
	mov	w12, #65535                     ; =0xffff
LBB106_75:                              ;   Parent Loop BB106_20 Depth=1
                                        ;     Parent Loop BB106_25 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w10, [x9, #-1]
	ldrb	w11, [x9], #2
	orr	w10, w10, w11, lsl #8
	cmp	w11, #0
	ccmp	w10, w12, #4, ne
	b.ne	LBB106_133
; %bb.76:                               ;   in Loop: Header=BB106_75 Depth=3
	cmp	w10, w12
	cset	w11, ne
	orr	w8, w8, w11
	strh	w10, [x19], #2
	subs	x22, x22, #1
	b.ne	LBB106_75
; %bb.77:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	tbnz	w8, #0, LBB106_24
	b	LBB106_129
LBB106_78:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #16]
	cmp	w8, #256
	b.hi	LBB106_129
; %bb.79:                               ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #24]
	b	LBB106_23
LBB106_80:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	w8, #0                          ; =0x0
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
LBB106_81:                              ;   in Loop: Header=BB106_25 Depth=2
	ldurb	w9, [x23, #8]
	cmp	w9, #151
	b.eq	LBB106_102
; %bb.82:                               ;   in Loop: Header=BB106_25 Depth=2
	cmp	w9, #15
	b.ne	LBB106_103
; %bb.83:                               ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w9, [x23, #24]
	cmp	w9, #255
	b.hi	LBB106_129
; %bb.84:                               ;   in Loop: Header=BB106_25 Depth=2
	cmp	w8, #1
	b.eq	LBB106_104
	b	LBB106_132
LBB106_85:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	w1, #2                          ; =0x2
LBB106_86:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	w2, [x9]
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	sub	x3, x29, #108
	bl	_nvm_file_nominal_source
	cbz	w0, LBB106_129
; %bb.87:                               ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-92]
	sub	w8, w8, #5
	cmn	w8, #2
	b.lo	LBB106_132
; %bb.88:                               ;   in Loop: Header=BB106_25 Depth=2
	ldur	w0, [x29, #-104]
	bl	_nl_file_catalog_type
	cbz	x0, LBB106_129
; %bb.89:                               ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-92]
	cmp	w8, #4
	mov	x2, x27
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	b.ne	LBB106_93
; %bb.90:                               ;   in Loop: Header=BB106_25 Depth=2
	cbnz	w22, LBB106_129
; %bb.91:                               ;   in Loop: Header=BB106_25 Depth=2
	ldr	x24, [x0, #32]
	b	LBB106_94
LBB106_92:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	w8, [x23, #16]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	cmp	w8, w9
	b.lo	LBB106_24
	b	LBB106_129
LBB106_93:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	x8, [x0, #32]
	mov	w24, #1                         ; =0x1
	cmp	x8, w22, uxtw
	b.ls	LBB106_130
LBB106_94:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	cmp	x24, w19, uxtw
	b.ne	LBB106_129
; %bb.95:                               ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-104]
	str	w8, [x23, #592]
	b	LBB106_24
LBB106_96:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	x0, [x19, #16]
	sub	x2, x29, #108
	mov	w1, #1                          ; =0x1
	bl	_nvm_file_nominal_import
	cbz	w0, LBB106_99
; %bb.97:                               ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-108]
	ldr	w9, [x23, #16]
	cmp	w8, w9
	b.ne	LBB106_99
; %bb.98:                               ;   in Loop: Header=BB106_25 Depth=2
	mov	w24, #1                         ; =0x1
	b	LBB106_112
LBB106_99:                              ;   in Loop: Header=BB106_25 Depth=2
	ldr	x0, [x19, #16]
	sub	x2, x29, #108
	mov	w1, #2                          ; =0x2
	bl	_nvm_file_nominal_import
	cbz	w0, LBB106_105
; %bb.100:                              ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-108]
	ldr	w9, [x23, #16]
	cmp	w8, w9
	b.ne	LBB106_105
; %bb.101:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	w24, #2                         ; =0x2
	b	LBB106_112
LBB106_102:                             ;   in Loop: Header=BB106_25 Depth=2
	cbnz	w8, LBB106_104
	b	LBB106_129
LBB106_103:                             ;   in Loop: Header=BB106_25 Depth=2
	cbnz	w8, LBB106_129
LBB106_104:                             ;   in Loop: Header=BB106_25 Depth=2
	mov	w8, #1                          ; =0x1
	lsl	x8, x8, x0
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [x10, x22, lsl #3]
	orr	x8, x9, x8
	str	x8, [x10, x22, lsl #3]
	b	LBB106_24
LBB106_105:                             ;   in Loop: Header=BB106_25 Depth=2
	ldr	x0, [x19, #16]
	sub	x2, x29, #108
	mov	w1, #3                          ; =0x3
	bl	_nvm_file_nominal_import
	cbz	w0, LBB106_108
; %bb.106:                              ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-108]
	ldr	w9, [x23, #16]
	cmp	w8, w9
	b.ne	LBB106_108
; %bb.107:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	w24, #3                         ; =0x3
	b	LBB106_112
LBB106_108:                             ;   in Loop: Header=BB106_25 Depth=2
	ldr	x0, [x19, #16]
	sub	x2, x29, #108
	mov	w1, #4                          ; =0x4
	bl	_nvm_file_nominal_import
	cbz	w0, LBB106_111
; %bb.109:                              ;   in Loop: Header=BB106_25 Depth=2
	ldur	w8, [x29, #-108]
	ldr	w9, [x23, #16]
	cmp	w8, w9
	b.ne	LBB106_111
; %bb.110:                              ;   in Loop: Header=BB106_25 Depth=2
	mov	w24, #4                         ; =0x4
	b	LBB106_112
LBB106_111:                             ;   in Loop: Header=BB106_25 Depth=2
	mov	w24, #5                         ; =0x5
LBB106_112:                             ;   in Loop: Header=BB106_25 Depth=2
	mov	x0, x24
	bl	_nl_file_catalog_method
	cbz	x0, LBB106_129
; %bb.113:                              ;   in Loop: Header=BB106_25 Depth=2
	ldrh	w8, [x23, #24]
	ldr	w9, [x0, #44]
	cmp	w9, #1
	mov	x2, x27
	ldr	w17, [sp, #100]                 ; 4-byte Folded Reload
	b.ne	LBB106_115
; %bb.114:                              ;   in Loop: Header=BB106_25 Depth=2
	cmp	w8, #255
	b.ls	LBB106_116
	b	LBB106_129
LBB106_115:                             ;   in Loop: Header=BB106_25 Depth=2
	mov	w9, #65535                      ; =0xffff
	cmp	w8, w9
	b.ne	LBB106_129
LBB106_116:                             ;   in Loop: Header=BB106_25 Depth=2
	str	w24, [x23, #592]
	b	LBB106_24
LBB106_117:                             ;   in Loop: Header=BB106_20 Depth=1
	ldr	x23, [sp, #120]                 ; 8-byte Folded Reload
	mov	x0, x23
	mov	x1, x22
	bl	_file_code_cfg
	cbnz	w0, LBB106_134
; %bb.118:                              ;   in Loop: Header=BB106_20 Depth=1
	add	x22, x22, #1
	ldr	w8, [x23, #24]
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	cmp	x22, x8
	mov	x2, x27
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	mov	w8, #36                         ; =0x24
	b.lo	LBB106_20
; %bb.119:
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cbz	w8, LBB106_126
; %bb.120:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x23, #2608
	mov	w11, #1                         ; =0x1
LBB106_121:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB106_123 Depth 2
	mov	x12, #0                         ; =0x0
	mvn	x13, x9
	b	LBB106_123
LBB106_122:                             ;   in Loop: Header=BB106_123 Depth=2
	add	x12, x12, #1
	mov	w24, #2                         ; =0x2
	ldr	x14, [sp, #104]                 ; 8-byte Folded Reload
	cmp	x14, x12
	b.eq	LBB106_131
LBB106_123:                             ;   Parent Loop BB106_121 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x14, x9, x12
	tbnz	w14, #0, LBB106_122
; %bb.124:                              ;   in Loop: Header=BB106_123 Depth=2
	ldr	x14, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x14, [x14, x12, lsl #3]
	tst	x14, x13
	b.ne	LBB106_122
; %bb.125:                              ;   in Loop: Header=BB106_121 Depth=1
	str	w12, [x10, x8, lsl #2]
	lsl	x12, x11, x12
	orr	x9, x12, x9
	add	x8, x8, #1
	ldr	x12, [sp, #104]                 ; 8-byte Folded Reload
	cmp	x8, x12
	b.lo	LBB106_121
LBB106_126:
	mov	w24, #0                         ; =0x0
	str	x23, [x26]
	b	LBB106_8
LBB106_127:
	mov	x0, x22
	bl	_nvm_file_flow_declarations_free
	mov	w24, #2                         ; =0x2
	b	LBB106_8
LBB106_128:
	mov	x0, x22
	bl	_nvm_file_flow_declarations_free
	mov	w24, #4                         ; =0x4
	b	LBB106_8
LBB106_129:
	mov	w24, #1                         ; =0x1
LBB106_130:
	ldr	x23, [sp, #120]                 ; 8-byte Folded Reload
LBB106_131:
	mov	x0, x23
	bl	_nvm_file_code_free
	b	LBB106_8
LBB106_132:
	mov	w24, #2                         ; =0x2
	b	LBB106_130
LBB106_133:
	mov	w24, #1                         ; =0x1
	b	LBB106_131
LBB106_134:
	mov	x24, x0
	b	LBB106_131
LBB106_135:
	mov	w24, #3                         ; =0x3
	b	LBB106_130
	.loh AdrpAdd	Lloh80, Lloh81
	.cfi_endproc
	.section	__TEXT,__const
lJTI106_0:
	.byte	(LBB106_22-LBB106_22)>>2
	.byte	(LBB106_66-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_34-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_46-LBB106_22)>>2
	.byte	(LBB106_46-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_34-LBB106_22)>>2
	.byte	(LBB106_78-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_42-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_63-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_31-LBB106_22)>>2
	.byte	(LBB106_24-LBB106_22)>>2
	.byte	(LBB106_62-LBB106_22)>>2
	.byte	(LBB106_34-LBB106_22)>>2
	.byte	(LBB106_69-LBB106_22)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function fi_function
lCPI107_0:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI107_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI107_2:
	.quad	-4294967285                     ; 0xffffffff0000000b
	.quad	4294967295                      ; 0xffffffff
lCPI107_3:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
lCPI107_4:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_fi_function:                           ; @fi_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #272]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #288]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #304]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x5, [sp, #24]                   ; 8-byte Folded Spill
	str	w4, [sp, #92]                   ; 4-byte Folded Spill
	str	x3, [sp, #144]                  ; 8-byte Folded Spill
	mov	x20, x2
	mov	x22, x0
	add	x8, x2, #1032, lsl #12          ; =4227072
	add	x21, x8, #2064
	add	x8, x2, #1030, lsl #12          ; =4218880
	add	x8, x8, #2089
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	add	x8, x2, #1028, lsl #12          ; =4210688
	add	x8, x8, #2056
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	ldr	x23, [x0]
	add	x9, x23, #48
	mov	w24, w1
	mov	w8, #36                         ; =0x24
	str	w1, [sp, #108]                  ; 4-byte Folded Spill
	str	x9, [sp, #96]                   ; 8-byte Folded Spill
	umaddl	x19, w1, w8, x9
	mov	x0, x2
	mov	w1, #35088                      ; =0x8910
	movk	w1, #64, lsl #16
	bl	_bzero
	mov	w8, #1                          ; =0x1
	strb	w8, [x20]
	strb	w8, [x21]
	ldrh	w9, [x19, #14]
	cbz	w9, LBB107_6
; %bb.1:
	mov	x9, #0                          ; =0x0
	add	x10, x22, x24, lsl #11
	add	x10, x10, #552
	add	x11, x20, #34
	mov	w12, #3                         ; =0x3
	b	LBB107_3
LBB107_2:                               ;   in Loop: Header=BB107_3 Depth=1
	add	x14, x14, #1816
	ldr	q0, [x14]
	stur	q0, [x11, #-26]
	stur	x13, [x11, #-10]
	sturb	w16, [x11, #-2]
	sturb	w15, [x11, #-1]
	str	wzr, [x11]
	strh	wzr, [x11, #4]
	add	x9, x9, #1
	ldrh	w13, [x19, #14]
	add	x11, x11, #32
	cmp	x9, x13
	b.hs	LBB107_6
LBB107_3:                               ; =>This Inner Loop Header: Depth=1
	mov	x13, #0                         ; =0x0
	ldr	x14, [x23]
	add	x15, x14, x24, lsl #2
	ldr	w15, [x15, #1560]
	add	w15, w9, w15
	add	x14, x14, w15, uxtw #4
	ldrh	w16, [x19, #12]
	ldr	x15, [x14, #1824]
	lsr	x15, x15, #33
	cmp	x15, #1
	csel	w15, w12, wzr, eq
	cmp	x9, x16
	cinc	w16, w8, lo
	b.hs	LBB107_2
; %bb.4:                                ;   in Loop: Header=BB107_3 Depth=1
	ldrb	w17, [x14, #1816]
	cmp	x17, #11
	b.ne	LBB107_2
; %bb.5:                                ;   in Loop: Header=BB107_3 Depth=1
	ldr	x13, [x10, x9, lsl #3]
	b	LBB107_2
LBB107_6:
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	add	x8, x23, #2352
	stp	x8, x22, [sp, #152]             ; 16-byte Folded Spill
	add	x8, x20, #1026, lsl #12         ; =4202496
	add	x8, x8, #2056
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	add	x9, x22, #40
	add	x8, x24, x24, lsl #3
	lsl	x10, x8, #2
	add	x8, x22, #32, lsl #12           ; =131072
	add	x8, x8, #552
	stp	x8, x10, [sp, #8]               ; 16-byte Folded Spill
	add	x8, x20, #1024, lsl #12         ; =4194304
	add	x10, x8, #2056
	add	x8, x20, #1028, lsl #12         ; =4210688
	add	x8, x8, #2089
	stp	x9, x8, [sp, #112]              ; 16-byte Folded Spill
	add	x8, x20, #1032, lsl #12         ; =4227072
	add	x9, x8, #2065
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	add	x8, x8, #33
	stp	x8, x9, [sp, #72]               ; 16-byte Folded Spill
	add	x8, x20, #33
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	mov	w8, #8225                       ; =0x2021
	add	x8, x20, x8
	stp	x10, x8, [sp, #40]              ; 16-byte Folded Spill
	mov	x8, #-65532                     ; =0xffffffffffff0004
	movk	x8, #0, lsl #16
	add	x8, x8, #7
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
LBB107_7:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB107_38 Depth 2
                                        ;     Child Loop BB107_11 Depth 2
                                        ;     Child Loop BB107_139 Depth 2
                                        ;     Child Loop BB107_234 Depth 2
                                        ;     Child Loop BB107_180 Depth 2
                                        ;       Child Loop BB107_187 Depth 3
                                        ;       Child Loop BB107_197 Depth 3
	ldrh	w8, [x19, #8]
	ands	w10, w8, #0xffff
	cset	w9, eq
	cbz	w10, LBB107_13
; %bb.8:                                ;   in Loop: Header=BB107_7 Depth=1
	and	w10, w8, #0xffff
	cmp	w10, #4
	b.hs	LBB107_37
; %bb.9:                                ;   in Loop: Header=BB107_7 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x14, [sp, #160]                 ; 8-byte Folded Reload
LBB107_10:                              ;   in Loop: Header=BB107_7 Depth=1
	and	x11, x8, #0x3
	cbz	x11, LBB107_253
LBB107_11:                              ;   Parent Loop BB107_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w12, [x21, x10]
	tbnz	w12, #0, LBB107_14
; %bb.12:                               ;   in Loop: Header=BB107_11 Depth=2
	add	x10, x10, #1
	subs	x11, x11, #1
	b.ne	LBB107_11
	b	LBB107_253
LBB107_13:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x14, [sp, #160]                 ; 8-byte Folded Reload
LBB107_14:                              ;   in Loop: Header=BB107_7 Depth=1
	and	w11, w10, #0xffff
	cmp	w11, w8, uxth
	b.eq	LBB107_254
; %bb.15:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x23, #16]
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w9, [x9, x24, lsl #2]
	add	w9, w9, w10, uxth
	mov	w11, #600                       ; =0x258
	umaddl	x27, w9, w11, x8
	ldr	w8, [x27]
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	str	w8, [x9]
	ldr	w8, [x14, #20]
	cmp	w8, #64, lsl #12                ; =262144
	b.eq	LBB107_267
; %bb.16:                               ;   in Loop: Header=BB107_7 Depth=1
	add	w8, w8, #1
	str	w8, [x14, #20]
                                        ; kill: def $w10 killed $w10 killed $x10 def $x10
	and	x8, x10, #0xffff
	strb	wzr, [x21, x8]
	mov	w9, #16392                      ; =0x4008
	umaddl	x1, w8, w9, x20
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x0, x20, x8
	mov	w2, #16392                      ; =0x4008
	bl	_memcpy
	ldrb	w8, [x27, #8]
	ldr	w9, [sp, #92]                   ; 4-byte Folded Reload
	tbnz	w9, #0, LBB107_24
; %bb.17:                               ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #152
	b.eq	LBB107_19
; %bb.18:                               ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #60
	b.ne	LBB107_24
LBB107_19:                              ;   in Loop: Header=BB107_7 Depth=1
	add	x9, x20, #1024, lsl #12         ; =4194304
	ldrh	w9, [x9, #2050]
	cbz	x9, LBB107_24
; %bb.20:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w9, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_24
; %bb.21:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9]
	ldr	x11, [sp, #32]                  ; 8-byte Folded Reload
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB107_24
; %bb.22:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x9, #8]
	and	x10, x10, x26
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB107_24
; %bb.23:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x9, #16]
	cbz	x9, LBB107_7
LBB107_24:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	w0, #2                          ; =0x2
	cmp	w8, #254
	b.hi	LBB107_264
; %bb.25:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x28, [x9]
	mov	x9, x27
	ldrh	w22, [x9, #16]!
	str	x9, [sp, #128]                  ; 8-byte Folded Spill
Lloh82:
	adrp	x11, lJTI107_0@PAGE
Lloh83:
	add	x11, x11, lJTI107_0@PAGEOFF
	adr	x9, LBB107_26
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	mov	w14, #2050                      ; =0x802
	movk	w14, #64, lsl #16
	mov	x15, #-256                      ; =0xffffffffffffff00
	movk	x15, #0, lsl #16
	br	x9
LBB107_26:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #2
	b.lo	LBB107_265
; %bb.27:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x10, x9, lsl #5
	ldrb	w9, [x10, #24]
	cmp	w9, #2
	b.ne	LBB107_265
; %bb.28:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x10]
	eor	x9, x9, #0xffffffff00000001
	mov	w0, #1                          ; =0x1
	tst	x9, #0xff
	b.ne	LBB107_264
; %bb.29:                               ;   in Loop: Header=BB107_7 Depth=1
	tst	x9, x15
	b.ne	LBB107_264
; %bb.30:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x10, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x9, x11
	b.ne	LBB107_264
; %bb.31:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	stp	q0, q0, [x10]
	and	w10, w9, #0xffff
	sub	w10, w10, #1
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x11, x10, lsl #5
	ldrb	w11, [x10, #24]
	cmp	w11, #2
	b.ne	LBB107_264
; %bb.32:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x10]
	eor	x11, x11, #0xffffffff00000001
	tst	x11, #0xff
	b.ne	LBB107_264
; %bb.33:                               ;   in Loop: Header=BB107_7 Depth=1
	tst	x11, x15
	b.ne	LBB107_264
; %bb.34:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x10, #8]
	mov	w12, #-1                        ; =0xffffffff
	cmp	x11, x12
	b.ne	LBB107_264
; %bb.35:                               ;   in Loop: Header=BB107_7 Depth=1
	stp	q0, q0, [x10]
	sub	w8, w8, #2
	and	w10, w8, #0xffff
	strh	w8, [x20, x14]
	cmp	w10, #256
	b.eq	LBB107_267
; %bb.36:                               ;   in Loop: Header=BB107_7 Depth=1
	strh	w9, [x20, x14]
	and	x8, x8, #0xffff
	b	LBB107_174
LBB107_37:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x10, #0                         ; =0x0
	and	x11, x8, #0xffff
	and	x11, x11, #0xfffc
	ldr	x14, [sp, #160]                 ; 8-byte Folded Reload
	ldr	x15, [sp, #80]                  ; 8-byte Folded Reload
LBB107_38:                              ;   Parent Loop BB107_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x15, x10
	ldurb	w12, [x12, #-1]
	tbnz	w12, #0, LBB107_14
; %bb.39:                               ;   in Loop: Header=BB107_38 Depth=2
	ldrb	w12, [x15, x10]
	tbnz	w12, #0, LBB107_53
; %bb.40:                               ;   in Loop: Header=BB107_38 Depth=2
	add	x12, x15, x10
	ldrb	w13, [x12, #1]
	tbnz	w13, #0, LBB107_54
; %bb.41:                               ;   in Loop: Header=BB107_38 Depth=2
	ldrb	w12, [x12, #2]
	tbnz	w12, #0, LBB107_55
; %bb.42:                               ;   in Loop: Header=BB107_38 Depth=2
	add	x10, x10, #4
	cmp	x11, x10
	b.ne	LBB107_38
	b	LBB107_10
LBB107_43:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #2
	b.lo	LBB107_265
; %bb.44:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x10, x9, lsl #5
	ldrb	w9, [x10, #24]
	cmp	w9, #2
	b.ne	LBB107_265
; %bb.45:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x10]
	eor	x9, x9, #0xffffffff00000001
	mov	w0, #1                          ; =0x1
	tst	x9, #0xff
	b.ne	LBB107_264
; %bb.46:                               ;   in Loop: Header=BB107_7 Depth=1
	tst	x9, x15
	b.ne	LBB107_264
; %bb.47:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x10, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x9, x11
	b.ne	LBB107_264
; %bb.48:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	stp	q0, q0, [x10]
	and	w10, w9, #0xffff
	sub	w10, w10, #1
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x11, x10, lsl #5
	ldrb	w11, [x10, #24]
	cmp	w11, #2
	b.ne	LBB107_264
; %bb.49:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x10]
	eor	x11, x11, #0xffffffff00000001
	tst	x11, #0xff
	b.ne	LBB107_264
LBB107_50:                              ;   in Loop: Header=BB107_7 Depth=1
	tst	x11, x15
	b.ne	LBB107_264
; %bb.51:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x10, #8]
	mov	w12, #-1                        ; =0xffffffff
	cmp	x11, x12
	b.ne	LBB107_264
; %bb.52:                               ;   in Loop: Header=BB107_7 Depth=1
	stp	q0, q0, [x10]
	b	LBB107_160
LBB107_53:                              ;   in Loop: Header=BB107_7 Depth=1
	add	x10, x10, #1
	b	LBB107_14
LBB107_54:                              ;   in Loop: Header=BB107_7 Depth=1
	add	x10, x10, #2
	b	LBB107_14
LBB107_55:                              ;   in Loop: Header=BB107_7 Depth=1
	add	x10, x10, #3
	b	LBB107_14
LBB107_56:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cbz	x8, LBB107_265
; %bb.57:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w8, w8, #1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #5
	ldrb	w9, [x8, #24]
	mov	w0, #1                          ; =0x1
	cmp	w9, #2
	b.ne	LBB107_264
; %bb.58:                               ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB107_264
; %bb.59:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x8, #8]
	lsr	x25, x9, #32
	sub	x10, x25, #1
	cmp	x10, #2
	b.lo	LBB107_264
; %bb.60:                               ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w26, [x8, #25]
	mov	w0, w9
	bl	_nl_file_catalog_type
	cbz	x0, LBB107_265
; %bb.61:                               ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w8, [x27, #8]
	cmp	w25, #3
	b.eq	LBB107_125
; %bb.62:                               ;   in Loop: Header=BB107_7 Depth=1
	cmp	w25, #4
	b.ne	LBB107_263
; %bb.63:                               ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #252
	b.ne	LBB107_263
; %bb.64:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x0, #32]
	cmp	x8, x22
	b.ls	LBB107_265
; %bb.65:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x0, #24]
	add	x8, x8, x22, lsl #5
	ldr	x1, [x8, #16]
	sub	x2, x29, #128
	mov	x0, x28
	bl	_fi_member
	mov	w9, #2050                       ; =0x802
	movk	w9, #64, lsl #16
	tbnz	w0, #0, LBB107_246
	b	LBB107_265
LBB107_66:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cbz	x8, LBB107_265
; %bb.67:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_265
; %bb.68:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9]
	mov	x11, #-65532                    ; =0xffffffffffff0004
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	mov	w0, #1                          ; =0x1
	tst	x10, #0xff
	b.ne	LBB107_264
; %bb.69:                               ;   in Loop: Header=BB107_7 Depth=1
	tst	x10, x15
	b.ne	LBB107_264
; %bb.70:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB107_264
; %bb.71:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
LBB107_72:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w8, w8, #1
	b	LBB107_99
LBB107_73:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w3, [x8]
	mov	w8, #1                          ; =0x1
	lsl	x2, x8, x3
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x1, x20, x8
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
                                        ; kill: def $w3 killed $w3 killed $x3
	ldr	x4, [sp, #24]                   ; 8-byte Folded Reload
	bl	_fi_call
	b	LBB107_217
LBB107_74:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x1, x20, x8
	sub	x3, x29, #112
	sub	x4, x29, #132
	mov	x0, x28
	mov	x2, x27
	bl	_fi_candidates
	mov	w12, #2050                      ; =0x802
	movk	w12, #64, lsl #16
	cbnz	w0, LBB107_217
; %bb.75:                               ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x12]
	cbz	x8, LBB107_247
; %bb.76:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_247
; %bb.77:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9]
	mov	x11, #-65532                    ; =0xffffffffffff0004
	movk	x11, #0, lsl #16
	add	x11, x11, #7
	eor	x10, x10, x11
	mov	w0, #1                          ; =0x1
	tst	x10, #0xff
	b.ne	LBB107_217
; %bb.78:                               ;   in Loop: Header=BB107_7 Depth=1
	tst	x10, x26
	b.ne	LBB107_217
; %bb.79:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB107_217
; %bb.80:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	sub	w8, w8, #1
	strh	w8, [x20, x12]
	ldur	x2, [x29, #-112]
	ldr	x11, [sp, #112]                 ; 8-byte Folded Reload
	ldr	x8, [x11, x24, lsl #3]
	orr	x9, x8, x2
	cmp	x9, x8
	cset	w8, ne
	ldr	x4, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w10, [x4]
	orr	w8, w10, w8
	strb	w8, [x4]
	str	x9, [x11, x24, lsl #3]
	ldur	w3, [x29, #-132]
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x1, x20, x8
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
	bl	_fi_call
	b	LBB107_217
LBB107_81:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #2
	b.lo	LBB107_265
; %bb.82:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x10, x9, lsl #5
	ldrb	w9, [x10]
	cmp	w9, #4
	ccmp	w9, #1, #4, ne
	b.ne	LBB107_264
; %bb.83:                               ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w11, [x10, #24]
	cmp	w11, #2
	b.ne	LBB107_265
; %bb.84:                               ;   in Loop: Header=BB107_7 Depth=1
	orr	x11, x9, #0xffffffff00000000
	ldr	x9, [x10]
	eor	x9, x9, x11
	tst	x9, #0xff
	b.ne	LBB107_265
; %bb.85:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x12, [x10, #8]
	and	x9, x9, x15
	cmp	x9, #0
	mov	w9, #-1                         ; =0xffffffff
	ccmp	x12, x9, #0, eq
	b.ne	LBB107_265
; %bb.86:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	stp	q0, q0, [x10]
	and	w10, w9, #0xffff
	sub	w10, w10, #1
	ldr	x12, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x12, x10, lsl #5
	ldrb	w12, [x10, #24]
	cmp	w12, #2
	b.ne	LBB107_265
; %bb.87:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x12, [x10]
	eor	x11, x12, x11
	mov	w0, #1                          ; =0x1
	tst	x11, #0xff
	b.eq	LBB107_50
	b	LBB107_264
LBB107_88:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #2
	b.lo	LBB107_265
; %bb.89:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x11, x10, x9, lsl #5
	ldrb	w9, [x11, #24]
	cmp	w9, #2
	b.ne	LBB107_265
; %bb.90:                               ;   in Loop: Header=BB107_7 Depth=1
	mov	x10, #-65532                    ; =0xffffffffffff0004
	movk	x10, #0, lsl #16
	ldr	x9, [x11]
	eor	x9, x9, x10
	mov	w0, #1                          ; =0x1
	tst	x9, #0xff
	b.ne	LBB107_264
; %bb.91:                               ;   in Loop: Header=BB107_7 Depth=1
	tst	x9, x15
	b.ne	LBB107_264
; %bb.92:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x11, #8]
	mov	w12, #-1                        ; =0xffffffff
	cmp	x9, x12
	b.ne	LBB107_264
; %bb.93:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	stp	q0, q0, [x11]
	and	w11, w9, #0xffff
	sub	w11, w11, #1
	ldr	x12, [sp, #136]                 ; 8-byte Folded Reload
	add	x11, x12, x11, lsl #5
	ldrb	w12, [x11, #24]
	cmp	w12, #2
	b.ne	LBB107_264
; %bb.94:                               ;   in Loop: Header=BB107_7 Depth=1
	ldr	x12, [x11]
	b	LBB107_156
LBB107_95:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w9, [x20, x14]
	cbz	x9, LBB107_265
; %bb.96:                               ;   in Loop: Header=BB107_7 Depth=1
	sub	w10, w9, #1
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x11, x10, lsl #5
	ldr	w11, [x10, #12]
	ldrb	w12, [x10, #1]
	sub	x11, x11, #1
	cmp	w12, #0
	ccmp	x11, #2, #2, eq
	cset	w11, lo
	cmp	w8, #149
	cset	w8, ne
	cmp	w8, w11
	b.eq	LBB107_265
; %bb.97:                               ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w8, [x10, #24]
	cmp	w8, #2
	b.ne	LBB107_265
; %bb.98:                               ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10]
	sub	w8, w9, #1
LBB107_99:                              ;   in Loop: Header=BB107_7 Depth=1
	strh	w8, [x20, x14]
	b	LBB107_177
LBB107_100:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x9, x9, x22, lsl #5
	ldr	x10, [x9]
	ldrb	w11, [x9, #24]
	and	x12, x10, #0xff00
	cmp	w11, #2
	ccmp	x12, #0, #0, eq
	b.ne	LBB107_265
; %bb.101:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x9, #8]
	lsr	x12, x11, #32
	sub	x12, x12, #1
	cmp	x12, #2
	cset	w12, lo
	cmp	w8, #11
	cset	w8, ne
	cmp	w8, w12
	b.eq	LBB107_265
; %bb.102:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #256
	b.eq	LBB107_267
; %bb.103:                              ;   in Loop: Header=BB107_7 Depth=1
	ldur	q0, [x9, #8]
	ldrb	w12, [x9, #25]
	add	w13, w8, #1
	strh	w13, [x20, x14]
	ldr	x13, [sp, #136]                 ; 8-byte Folded Reload
	add	x8, x13, x8, lsl #5
	str	x10, [x8]
	stur	q0, [x8, #8]
	mov	w13, #2                         ; =0x2
	strb	w13, [x8, #24]
	strb	w12, [x8, #25]
	ldurh	w12, [x9, #30]
	ldur	w13, [x9, #26]
	stur	w13, [x8, #26]
	strh	w12, [x8, #30]
	ldrb	w8, [x27, #8]
	cmp	w8, #11
	b.ne	LBB107_177
; %bb.104:                              ;   in Loop: Header=BB107_7 Depth=1
	lsr	x8, x11, #33
	cmp	x8, #1
	mov	w8, #3                          ; =0x3
	stp	x10, x11, [x9]
	csel	w8, w8, wzr, eq
	str	xzr, [x9, #16]
	mov	w10, #1                         ; =0x1
	strb	w10, [x9, #24]
	strb	w8, [x9, #25]
	stur	wzr, [x9, #26]
	sturh	wzr, [x9, #30]
	b	LBB107_177
LBB107_105:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w9, [x20, x14]
	cbz	x9, LBB107_265
; %bb.106:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w9, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x10, x9, lsl #5
	ldp	x1, x2, [x10]
	ldur	q0, [x10, #8]
	ldrb	w12, [x10, #24]
	ldrb	w11, [x10, #25]
	and	x9, x1, #0xff
	cmp	w8, #17
	ccmp	w12, #2, #0, eq
	ccmp	x9, #0, #0, eq
	and	x9, x1, x15
	mov	x13, #-4294967296               ; =0xffffffff00000000
	ccmp	x9, x13, #0, eq
	mov	w9, #-1                         ; =0xffffffff
	ccmp	x2, x9, #0, eq
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x9, x9, x22, lsl #5
	b.eq	LBB107_248
LBB107_107:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	w0, #1                          ; =0x1
	cmp	w12, #2
	b.ne	LBB107_264
; %bb.108:                              ;   in Loop: Header=BB107_7 Depth=1
	and	x12, x1, #0xff00
	cbnz	x12, LBB107_264
; %bb.109:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x12, [x9]
	eor	x12, x12, x1
	tst	x12, #0xff
	b.ne	LBB107_264
; %bb.110:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x13, [x9, #8]
	and	x12, x12, x15
	cmp	x12, #0
	ccmp	x2, x13, #0, eq
	b.ne	LBB107_264
; %bb.111:                              ;   in Loop: Header=BB107_7 Depth=1
	lsr	x12, x2, #32
	sub	x12, x12, #1
	cmp	x12, #2
	cset	w12, lo
	cmp	w8, #12
	cset	w13, eq
	eor	w12, w13, w12
	tbnz	w12, #0, LBB107_264
; %bb.112:                              ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #12
	b.ne	LBB107_114
; %bb.113:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w8, [x9, #24]
	cmp	w8, #1
	b.ne	LBB107_264
LBB107_114:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	str	x1, [x9]
	stur	q0, [x9, #8]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #24]
	strb	w11, [x9, #25]
	ldurh	w8, [x10, #30]
	ldur	w10, [x10, #26]
	stur	w10, [x9, #26]
	strh	w8, [x9, #30]
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x0, x20, x8
	bl	_fi_take
	b	LBB107_217
LBB107_115:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	ldrh	w8, [x27, #24]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #5
	ldr	x9, [x8, #8]
	ldrb	w8, [x8, #24]
	cmp	w8, #2
	lsr	x8, x9, #32
	ccmp	x8, #1, #0, eq
	b	LBB107_216
LBB107_116:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	w0, [x27, #592]
	bl	_nl_file_catalog_type
	cbz	x0, LBB107_265
; %bb.117:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, x0
	ldr	w1, [x27, #592]
	ldr	x8, [x28]
	ldr	x0, [x8, #16]
	sub	x2, x29, #112
	bl	_nvm_file_nominal_type
	tbz	w0, #0, LBB107_265
; %bb.118:                              ;   in Loop: Header=BB107_7 Depth=1
	ldurb	w8, [x29, #-100]
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	cmp	w8, #0
	csel	w8, w10, w9, eq
	ldur	w22, [x29, #-96]
	sturb	w8, [x29, #-128]
	sturb	wzr, [x29, #-127]
	sturh	wzr, [x29, #-126]
	ldur	d0, [x29, #-112]
	stur	d0, [x29, #-124]
	stur	w22, [x29, #-116]
	ldrb	w8, [x27, #8]
	cmp	w8, #251
	mov	w8, #16                         ; =0x10
	csel	x8, x8, x10, eq
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldrh	w8, [x9, x8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	cmp	w22, #4
	b.ne	LBB107_232
; %bb.119:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x26, #32]
	mov	w13, #2050                      ; =0x802
	movk	w13, #64, lsl #16
	cbnz	x8, LBB107_233
; %bb.120:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x13]
	b	LBB107_240
LBB107_121:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cbz	x8, LBB107_265
; %bb.122:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_265
; %bb.123:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9]
	eor	x10, x10, #0xffffffff00000001
	tst	x10, #0xff
	b.ne	LBB107_265
; %bb.124:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x11, [x9, #8]
	and	x10, x10, x15
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.eq	LBB107_133
	b	LBB107_265
LBB107_125:                             ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #254
	mov	w9, #2050                       ; =0x802
	movk	w9, #64, lsl #16
	b.eq	LBB107_127
; %bb.126:                              ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #105
	b.ne	LBB107_243
LBB107_127:                             ;   in Loop: Header=BB107_7 Depth=1
Lloh84:
	adrp	x8, lCPI107_0@PAGE
Lloh85:
	ldr	q0, [x8, lCPI107_0@PAGEOFF]
	stur	q0, [x29, #-128]
	b	LBB107_246
LBB107_128:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cbz	x8, LBB107_265
; %bb.129:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_265
; %bb.130:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9]
	mov	x11, #-65532                    ; =0xffffffffffff0004
	movk	x11, #0, lsl #16
	orr	x11, x11, #0x1
	eor	x10, x10, x11
	mov	w0, #1                          ; =0x1
	tst	x10, #0xff
	b.ne	LBB107_264
; %bb.131:                              ;   in Loop: Header=BB107_7 Depth=1
	tst	x10, x15
	b.ne	LBB107_264
; %bb.132:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB107_264
LBB107_133:                             ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	cmp	w9, #256
	b.eq	LBB107_267
; %bb.134:                              ;   in Loop: Header=BB107_7 Depth=1
	strh	w8, [x20, x14]
	and	x8, x9, #0xffff
	b	LBB107_174
LBB107_135:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	w0, [x27, #592]
	bl	_nl_file_catalog_method
	cbz	x0, LBB107_265
; %bb.136:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, x0
	ldr	x8, [x0, #56]
	cbz	x8, LBB107_265
; %bb.137:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	w9, [x26, #44]
	cmp	w9, #1
	cset	w9, eq
	sub	x25, x8, #1
	str	x9, [sp]                        ; 8-byte Folded Spill
	cmp	x25, x9
	b.ls	LBB107_146
; %bb.138:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	w9, #48                         ; =0x30
	mov	x10, #-80                       ; =0xffffffffffffffb0
	madd	x22, x8, x9, x10
LBB107_139:                             ;   Parent Loop BB107_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x26, #48]
	ldr	x1, [x8, x22]
	sub	x2, x29, #128
	mov	x0, x28
	bl	_fi_member
	cbz	w0, LBB107_265
; %bb.140:                              ;   in Loop: Header=BB107_139 Depth=2
	mov	w13, #2050                      ; =0x802
	movk	w13, #64, lsl #16
	ldrh	w8, [x20, x13]
	cbz	x8, LBB107_265
; %bb.141:                              ;   in Loop: Header=BB107_139 Depth=2
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_265
; %bb.142:                              ;   in Loop: Header=BB107_139 Depth=2
	ldur	x10, [x29, #-128]
	ldr	x11, [x9]
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB107_265
; %bb.143:                              ;   in Loop: Header=BB107_139 Depth=2
	ldur	x11, [x29, #-120]
	ldr	x12, [x9, #8]
	mov	x14, #-256                      ; =0xffffffffffffff00
	movk	x14, #0, lsl #16
	and	x10, x10, x14
	cmp	x10, #0
	ccmp	x12, x11, #0, eq
	b.ne	LBB107_265
; %bb.144:                              ;   in Loop: Header=BB107_139 Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	sub	w8, w8, #1
	strh	w8, [x20, x13]
	sub	x25, x25, #1
	sub	x22, x22, #48
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	cmp	x25, x8
	b.hi	LBB107_139
; %bb.145:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x26, #56]
LBB107_146:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x26, #48]
	mov	w10, #48                        ; =0x30
	madd	x8, x8, x10, x9
	ldur	x1, [x8, #-32]
	sub	x2, x29, #128
	mov	x0, x28
	bl	_fi_member
	cbz	w0, LBB107_265
; %bb.147:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	w10, #2050                      ; =0x802
	movk	w10, #64, lsl #16
	ldrh	w8, [x20, x10]
	mov	w0, #3                          ; =0x3
	cmp	x8, #256
	b.eq	LBB107_264
; %bb.148:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x10]
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #5
	ldur	x9, [x29, #-120]
	ldur	q0, [x29, #-128]
	lsr	x9, x9, #33
	str	q0, [x8]
	cmp	x9, #1
	csel	w9, w0, wzr, eq
	str	xzr, [x8, #16]
	mov	w10, #2                         ; =0x2
	strb	w10, [x8, #24]
	b	LBB107_242
LBB107_149:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #2
	b.lo	LBB107_265
; %bb.150:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x11, x10, x9, lsl #5
	ldrb	w9, [x11, #24]
	cmp	w9, #2
	b.ne	LBB107_265
; %bb.151:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x10, #-65532                    ; =0xffffffffffff0004
	movk	x10, #0, lsl #16
	ldr	x9, [x11]
	orr	x12, x10, #0x1
	eor	x9, x9, x12
	mov	w0, #1                          ; =0x1
	tst	x9, #0xff
	b.ne	LBB107_264
; %bb.152:                              ;   in Loop: Header=BB107_7 Depth=1
	tst	x9, x15
	b.ne	LBB107_264
; %bb.153:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x11, #8]
	mov	w12, #-1                        ; =0xffffffff
	cmp	x9, x12
	b.ne	LBB107_264
; %bb.154:                              ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	stp	q0, q0, [x11]
	and	w11, w9, #0xffff
	sub	w11, w11, #1
	ldr	x12, [sp, #136]                 ; 8-byte Folded Reload
	add	x11, x12, x11, lsl #5
	ldrb	w12, [x11, #24]
	cmp	w12, #2
	b.ne	LBB107_264
; %bb.155:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x12, [x11]
	add	x10, x10, #1
LBB107_156:                             ;   in Loop: Header=BB107_7 Depth=1
	eor	x10, x12, x10
	tst	x10, #0xff
	b.ne	LBB107_264
; %bb.157:                              ;   in Loop: Header=BB107_7 Depth=1
	tst	x10, x15
	b.ne	LBB107_264
; %bb.158:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x11, #8]
	mov	w12, #-1                        ; =0xffffffff
	cmp	x10, x12
	b.ne	LBB107_264
; %bb.159:                              ;   in Loop: Header=BB107_7 Depth=1
	stp	q0, q0, [x11]
LBB107_160:                             ;   in Loop: Header=BB107_7 Depth=1
	sub	w8, w8, #2
	and	w10, w8, #0xffff
	strh	w8, [x20, x14]
	cmp	w10, #256
	b.eq	LBB107_267
; %bb.161:                              ;   in Loop: Header=BB107_7 Depth=1
	strh	w9, [x20, x14]
	and	x8, x8, #0xffff
LBB107_162:                             ;   in Loop: Header=BB107_7 Depth=1
Lloh86:
	adrp	x9, lCPI107_1@PAGE
Lloh87:
	ldr	q0, [x9, lCPI107_1@PAGEOFF]
	b	LBB107_175
LBB107_163:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x22, lsl #5
	ldrb	w9, [x8, #24]
	cmp	w9, #2
	b.ne	LBB107_265
; %bb.164:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [x8, #8]
	lsr	x10, x9, #32
	sub	x10, x10, #1
	mov	w0, #1                          ; =0x1
	ldrb	w11, [x8, #1]
	cmp	w11, #0
	ccmp	x10, #1, #2, eq
	b.hi	LBB107_264
; %bb.165:                              ;   in Loop: Header=BB107_7 Depth=1
	lsr	x9, x9, #33
	cmp	x9, #1
	str	xzr, [x8, #16]
	mov	w9, #3                          ; =0x3
	strb	w0, [x8, #24]
	csel	w9, w9, wzr, eq
	strb	w9, [x8, #25]
	stur	wzr, [x8, #26]
	sturh	wzr, [x8, #30]
	b	LBB107_177
LBB107_166:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #256
	b.eq	LBB107_267
; %bb.167:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x14]
Lloh88:
	adrp	x9, lCPI107_4@PAGE
Lloh89:
	ldr	q0, [x9, lCPI107_4@PAGEOFF]
	b	LBB107_175
LBB107_168:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #256
	b.eq	LBB107_267
; %bb.169:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x14]
Lloh90:
	adrp	x9, lCPI107_3@PAGE
Lloh91:
	ldr	q0, [x9, lCPI107_3@PAGEOFF]
	b	LBB107_175
LBB107_170:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #256
	b.eq	LBB107_267
; %bb.171:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w9, [x9]
	mov	w10, #1                         ; =0x1
	add	w11, w8, #1
	strh	w11, [x20, x14]
Lloh92:
	adrp	x11, lCPI107_2@PAGE
Lloh93:
	ldr	q0, [x11, lCPI107_2@PAGEOFF]
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	add	x8, x11, x8, lsl #5
	str	q0, [x8]
	lsl	x9, x10, x9
	str	x9, [x8, #16]
	b	LBB107_176
LBB107_172:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #256
	b.eq	LBB107_267
; %bb.173:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x14]
LBB107_174:                             ;   in Loop: Header=BB107_7 Depth=1
Lloh94:
	adrp	x9, lCPI107_0@PAGE
Lloh95:
	ldr	q0, [x9, lCPI107_0@PAGEOFF]
LBB107_175:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #5
	str	q0, [x8]
	str	xzr, [x8, #16]
LBB107_176:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	w9, #2                          ; =0x2
	strb	w9, [x8, #24]
	stur	wzr, [x8, #25]
	str	wzr, [x8, #28]
LBB107_177:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
LBB107_178:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w8, [x27, #76]
	cbz	w8, LBB107_7
; %bb.179:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	x28, #0                         ; =0x0
	add	x25, x27, #72
LBB107_180:                             ;   Parent Loop BB107_7 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB107_187 Depth 3
                                        ;       Child Loop BB107_197 Depth 3
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x1, x20, x8
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	w2, #16392                      ; =0x4008
	bl	_memcpy
	ldrb	w8, [x27, #8]
	cmp	w8, #146
	b.ne	LBB107_182
; %bb.181:                              ;   in Loop: Header=BB107_180 Depth=2
	ldp	x11, x8, [sp, #120]             ; 16-byte Folded Reload
	ldrh	w8, [x8]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w28
	lsl	x8, x8, #5
	ldrb	w10, [x11, x8]
	ands	w9, w9, w10
	strb	w9, [x11, x8]
	b.eq	LBB107_194
LBB107_182:                             ;   in Loop: Header=BB107_180 Depth=2
	ldrh	w22, [x25, x28, lsl #1]
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldrb	w8, [x8]
	cmp	w8, #1
	b.ne	LBB107_191
; %bb.183:                              ;   in Loop: Header=BB107_180 Depth=2
	mov	w8, #16392                      ; =0x4008
	umaddl	x0, w22, w8, x20
	ldrb	w8, [x0]
	tbz	w8, #0, LBB107_192
; %bb.184:                              ;   in Loop: Header=BB107_180 Depth=2
	ldrh	w8, [x0, #2]
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldrh	w9, [x9, #2]
	cmp	w8, w9
	b.ne	LBB107_265
; %bb.185:                              ;   in Loop: Header=BB107_180 Depth=2
	ldrh	w10, [x19, #14]
	cbz	w10, LBB107_195
; %bb.186:                              ;   in Loop: Header=BB107_180 Depth=2
	mov	w9, #0                          ; =0x0
	mov	w11, #16392                     ; =0x4008
	ldp	x13, x12, [sp, #64]             ; 16-byte Folded Reload
	umaddl	x11, w22, w11, x13
	mov	x3, #-256                       ; =0xffffffffffffff00
	movk	x3, #0, lsl #16
LBB107_187:                             ;   Parent Loop BB107_7 Depth=1
                                        ;     Parent Loop BB107_180 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	x13, [x11, #-25]
	ldur	x14, [x12, #-25]
	eor	x13, x14, x13
	tst	x13, #0xff
	b.ne	LBB107_263
; %bb.188:                              ;   in Loop: Header=BB107_187 Depth=3
	ldur	x14, [x12, #-17]
	ldur	x15, [x11, #-17]
	and	x13, x13, x3
	cmp	x13, #0
	ccmp	x15, x14, #0, eq
	b.ne	LBB107_263
; %bb.189:                              ;   in Loop: Header=BB107_187 Depth=3
	ldur	x13, [x11, #-9]
	ldur	x14, [x12, #-9]
	orr	x14, x14, x13
	ldurb	w15, [x11, #-1]
	and	w16, w15, #0xff
	ldurb	w17, [x12, #-1]
	orr	w15, w17, w15
	and	w17, w15, #0xff
	ldrb	w0, [x11]
	and	w1, w0, #0xff
	ldrb	w2, [x12], #32
	orr	w0, w2, w0
	and	w2, w0, #0xff
	cmp	x14, x13
	ccmp	w17, w16, #0, eq
	ccmp	w2, w1, #0, eq
	cset	w13, ne
	orr	w9, w9, w13
	stur	x14, [x11, #-9]
	sturb	w15, [x11, #-1]
	strb	w0, [x11], #32
	subs	x10, x10, #1
	b.ne	LBB107_187
; %bb.190:                              ;   in Loop: Header=BB107_180 Depth=2
	cbnz	w8, LBB107_196
	b	LBB107_193
LBB107_191:                             ;   in Loop: Header=BB107_180 Depth=2
	mov	w9, #0                          ; =0x0
	b	LBB107_193
LBB107_192:                             ;   in Loop: Header=BB107_180 Depth=2
	ldr	x1, [sp, #168]                  ; 8-byte Folded Reload
	mov	w2, #16392                      ; =0x4008
	bl	_memcpy
	mov	w9, #1                          ; =0x1
LBB107_193:                             ;   in Loop: Header=BB107_180 Depth=2
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	ldrb	w8, [x21, x22]
	orr	w8, w8, w9
	strb	w8, [x21, x22]
LBB107_194:                             ;   in Loop: Header=BB107_180 Depth=2
	add	x28, x28, #1
	ldrb	w8, [x27, #76]
	cmp	x28, x8
	b.lo	LBB107_180
	b	LBB107_7
LBB107_195:                             ;   in Loop: Header=BB107_180 Depth=2
	mov	w9, #0                          ; =0x0
	mov	x3, #-256                       ; =0xffffffffffffff00
	movk	x3, #0, lsl #16
	cbz	w8, LBB107_193
LBB107_196:                             ;   in Loop: Header=BB107_180 Depth=2
	mov	w10, #16392                     ; =0x4008
	ldr	x11, [sp, #48]                  ; 8-byte Folded Reload
	umaddl	x10, w22, w10, x11
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
LBB107_197:                             ;   Parent Loop BB107_7 Depth=1
                                        ;     Parent Loop BB107_180 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	x12, [x10, #-25]
	ldur	x13, [x11, #-25]
	eor	x12, x13, x12
	tst	x12, #0xff
	b.ne	LBB107_263
; %bb.198:                              ;   in Loop: Header=BB107_197 Depth=3
	ldur	x13, [x11, #-17]
	ldur	x14, [x10, #-17]
	and	x12, x12, x3
	cmp	x12, #0
	ccmp	x14, x13, #0, eq
	b.ne	LBB107_263
; %bb.199:                              ;   in Loop: Header=BB107_197 Depth=3
	ldur	x12, [x10, #-9]
	ldur	x13, [x11, #-9]
	orr	x13, x13, x12
	ldurb	w14, [x10, #-1]
	and	w15, w14, #0xff
	ldurb	w16, [x11, #-1]
	orr	w14, w16, w14
	and	w16, w14, #0xff
	ldrb	w17, [x10]
	and	w0, w17, #0xff
	ldrb	w1, [x11], #32
	orr	w17, w1, w17
	and	w1, w17, #0xff
	cmp	x13, x12
	ccmp	w16, w15, #0, eq
	ccmp	w1, w0, #0, eq
	cset	w12, ne
	orr	w9, w9, w12
	stur	x13, [x10, #-9]
	sturb	w14, [x10, #-1]
	strb	w17, [x10], #32
	subs	x8, x8, #1
	b.ne	LBB107_197
	b	LBB107_193
LBB107_200:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cmp	x8, #256
	b.eq	LBB107_267
; %bb.201:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x14]
	b	LBB107_162
LBB107_202:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cbz	x8, LBB107_265
; %bb.203:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldr	w10, [x9, #12]
	sub	x10, x10, #1
	ldrb	w9, [x9, #1]
	cmp	w9, #0
	ccmp	x10, #2, #2, eq
	b.lo	LBB107_265
; %bb.204:                              ;   in Loop: Header=BB107_7 Depth=1
	cmp	w8, #256
	b.eq	LBB107_267
; %bb.205:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x14]
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #5
	ldp	q0, q1, [x8, #-32]
	stp	q0, q1, [x8]
	b	LBB107_177
LBB107_206:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x9, x28, x8
	ldrh	w8, [x20, x14]
	ldrb	w10, [x9, #64]
	cmp	w8, w10
	b.ne	LBB107_265
; %bb.207:                              ;   in Loop: Header=BB107_7 Depth=1
	cbz	w10, LBB107_177
; %bb.208:                              ;   in Loop: Header=BB107_7 Depth=1
	ldurb	w10, [x9, #68]
	cmp	w10, #11
	b.ne	LBB107_210
; %bb.209:                              ;   in Loop: Header=BB107_7 Depth=1
	add	x10, x20, #1024, lsl #12        ; =4194304
	ldr	x10, [x10, #10264]
	ldr	x16, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x11, [x16, x24, lsl #3]
	orr	x10, x11, x10
	cmp	x10, x11
	cset	w11, ne
	ldr	x13, [sp, #24]                  ; 8-byte Folded Reload
	ldrb	w12, [x13]
	orr	w11, w12, w11
	strb	w11, [x13]
	str	x10, [x16, x24, lsl #3]
LBB107_210:                             ;   in Loop: Header=BB107_7 Depth=1
	sub	w10, w8, #1
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	add	x10, x11, x10, lsl #5
	ldrb	w11, [x10, #24]
	cmp	w11, #2
	b.ne	LBB107_265
; %bb.211:                              ;   in Loop: Header=BB107_7 Depth=1
	ldur	x11, [x9, #68]
	ldr	x12, [x10]
	eor	x11, x12, x11
	mov	w0, #1                          ; =0x1
	tst	x11, #0xff
	b.ne	LBB107_264
; %bb.212:                              ;   in Loop: Header=BB107_7 Depth=1
	tst	x11, x15
	b.ne	LBB107_264
; %bb.213:                              ;   in Loop: Header=BB107_7 Depth=1
	ldur	x9, [x9, #76]
	ldr	x11, [x10, #8]
	cmp	x11, x9
	b.ne	LBB107_264
; %bb.214:                              ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10]
	b	LBB107_72
LBB107_215:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x22, lsl #5
	ldrb	w9, [x8, #24]
	ldrb	w8, [x8, #25]
	tst	w8, #0xff
	ccmp	w9, #2, #0, ne
LBB107_216:                             ;   in Loop: Header=BB107_7 Depth=1
	cset	w0, ne
LBB107_217:                             ;   in Loop: Header=BB107_7 Depth=1
	cbz	w0, LBB107_178
	b	LBB107_264
LBB107_218:                             ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x22, x8, x22, lsl #5
	ldrb	w8, [x22, #24]
	cmp	w8, #2
	b.ne	LBB107_264
; %bb.219:                              ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w8, [x22, #25]
	ldrb	w9, [x27, #24]
	mov	w10, #1                         ; =0x1
	lsl	w9, w10, w9
	cmp	w8, w9, uxtb
	b.ne	LBB107_264
; %bb.220:                              ;   in Loop: Header=BB107_7 Depth=1
	ldp	x26, x25, [x22]
	mov	w0, w25
	bl	_nl_file_catalog_type
	cbz	x0, LBB107_265
; %bb.221:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x0, #32]
	cmp	x8, #2
	b.ne	LBB107_265
; %bb.222:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x0, #24]
	ldrb	w9, [x27, #24]
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	sub	x2, x29, #128
	mov	x0, x28
	bl	_fi_member
	cbz	w0, LBB107_265
; %bb.223:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	w10, #2050                      ; =0x802
	movk	w10, #64, lsl #16
	ldrh	w8, [x20, x10]
	mov	w0, #3                          ; =0x3
	cmp	x8, #256
	b.eq	LBB107_264
; %bb.224:                              ;   in Loop: Header=BB107_7 Depth=1
	add	w9, w8, #1
	strh	w9, [x20, x10]
	ldur	x9, [x29, #-120]
	ldur	q0, [x29, #-128]
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x8, x10, x8, lsl #5
	str	q0, [x8]
	lsr	x9, x9, #33
	cmp	x9, #1
	csel	w9, w0, wzr, eq
	str	xzr, [x8, #16]
	mov	w10, #2                         ; =0x2
	strb	w10, [x8, #24]
	strb	w9, [x8, #25]
	stur	wzr, [x8, #26]
	strh	wzr, [x8, #30]
	lsr	x8, x25, #33
	cmp	x8, #1
	csel	w8, w0, wzr, eq
	stp	x26, x25, [x22]
	str	xzr, [x22, #16]
	mov	w9, #1                          ; =0x1
	strb	w9, [x22, #24]
	strb	w8, [x22, #25]
	stur	wzr, [x22, #26]
	sturh	wzr, [x22, #30]
	b	LBB107_177
LBB107_225:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x14]
	cbz	x8, LBB107_265
; %bb.226:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_265
; %bb.227:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9]
	mov	x11, #-65532                    ; =0xffffffffffff0004
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	mov	w0, #1                          ; =0x1
	tst	x10, #0xff
	b.ne	LBB107_264
; %bb.228:                              ;   in Loop: Header=BB107_7 Depth=1
	tst	x10, x15
	b.ne	LBB107_264
; %bb.229:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x10, [x9, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB107_264
; %bb.230:                              ;   in Loop: Header=BB107_7 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	sub	w9, w8, #1
	strh	w9, [x20, x14]
	cmp	w9, #256
	b.eq	LBB107_267
; %bb.231:                              ;   in Loop: Header=BB107_7 Depth=1
	strh	w8, [x20, x14]
	and	x8, x9, #0xffff
	b	LBB107_162
LBB107_232:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	w8, #1                          ; =0x1
LBB107_233:                             ;   in Loop: Header=BB107_7 Depth=1
	sub	x25, x8, #1
LBB107_234:                             ;   Parent Loop BB107_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x26, #24]
	cmp	w22, #4
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	csel	x9, x25, x9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	sub	x2, x29, #112
	mov	x0, x28
	bl	_fi_member
	cbz	w0, LBB107_265
; %bb.235:                              ;   in Loop: Header=BB107_234 Depth=2
	mov	w13, #2050                      ; =0x802
	movk	w13, #64, lsl #16
	ldrh	w8, [x20, x13]
	cbz	x8, LBB107_265
; %bb.236:                              ;   in Loop: Header=BB107_234 Depth=2
	sub	w9, w8, #1
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #5
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB107_265
; %bb.237:                              ;   in Loop: Header=BB107_234 Depth=2
	ldur	x10, [x29, #-112]
	ldr	x11, [x9]
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB107_265
; %bb.238:                              ;   in Loop: Header=BB107_234 Depth=2
	ldur	x11, [x29, #-104]
	ldr	x12, [x9, #8]
	mov	x14, #-256                      ; =0xffffffffffffff00
	movk	x14, #0, lsl #16
	and	x10, x10, x14
	cmp	x10, #0
	ccmp	x12, x11, #0, eq
	b.ne	LBB107_265
; %bb.239:                              ;   in Loop: Header=BB107_234 Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	sub	w8, w8, #1
	strh	w8, [x20, x13]
	sub	x25, x25, #1
	cmn	x25, #1
	b.ne	LBB107_234
LBB107_240:                             ;   in Loop: Header=BB107_7 Depth=1
	and	w9, w8, #0xffff
	mov	w0, #3                          ; =0x3
	cmp	w9, #256
	b.eq	LBB107_264
; %bb.241:                              ;   in Loop: Header=BB107_7 Depth=1
	mov	w9, #1                          ; =0x1
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	lsl	w9, w9, w10
	add	w10, w8, #1
	strh	w10, [x20, x13]
	and	x8, x8, #0xffff
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	add	x8, x10, x8, lsl #5
	ldur	x10, [x29, #-120]
	ldur	q0, [x29, #-128]
	lsr	x10, x10, #33
	cmp	x10, #1
	str	q0, [x8]
	str	xzr, [x8, #16]
	csel	w10, w0, wzr, eq
	mov	w11, #2                         ; =0x2
	strb	w11, [x8, #24]
	cmp	w22, #4
	csel	w9, w10, w9, eq
LBB107_242:                             ;   in Loop: Header=BB107_7 Depth=1
	strb	w9, [x8, #25]
	stur	wzr, [x8, #26]
	strh	wzr, [x8, #30]
	b	LBB107_177
LBB107_243:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	x8, x0
	mov	w0, #2                          ; =0x2
	cbnz	w22, LBB107_264
; %bb.244:                              ;   in Loop: Header=BB107_7 Depth=1
	sub	w9, w26, #3
	cmn	w9, #2
	b.lo	LBB107_264
; %bb.245:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	x8, [x8, #24]
	cmp	w26, #2
	cset	w9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	sub	x2, x29, #128
	mov	x0, x28
	bl	_fi_member
	mov	w9, #2050                       ; =0x802
	movk	w9, #64, lsl #16
	cbz	w0, LBB107_265
LBB107_246:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrh	w8, [x20, x9]
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #5
	ldur	x9, [x29, #-120]
	ldur	q0, [x29, #-128]
	lsr	x9, x9, #33
	cmp	x9, #1
	stur	q0, [x8, #-32]
	mov	w9, #3                          ; =0x3
	csel	w9, w9, wzr, eq
	stur	xzr, [x8, #-16]
	mov	w10, #2                         ; =0x2
	sturb	w10, [x8, #-8]
	sturb	w9, [x8, #-7]
	stur	wzr, [x8, #-6]
	sturh	wzr, [x8, #-2]
	b	LBB107_177
LBB107_247:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	w0, #1                          ; =0x1
	b	LBB107_217
LBB107_248:                             ;   in Loop: Header=BB107_7 Depth=1
	ldrb	w13, [x9]
	cbz	w13, LBB107_107
; %bb.249:                              ;   in Loop: Header=BB107_7 Depth=1
	ldr	q0, [x9]
	stur	q0, [x29, #-128]
	ldurb	w8, [x29, #-127]
	cbnz	w8, LBB107_265
; %bb.250:                              ;   in Loop: Header=BB107_7 Depth=1
	ldp	x8, x10, [x29, #-128]
	mov	w0, #1                          ; =0x1
	and	x11, x8, #0xff00
	cbnz	x11, LBB107_252
; %bb.251:                              ;   in Loop: Header=BB107_7 Depth=1
	lsr	x11, x10, #32
	sub	x11, x11, #1
	cmp	x11, #2
	b.lo	LBB107_264
LBB107_252:                             ;   in Loop: Header=BB107_7 Depth=1
	mov	x26, #-256                      ; =0xffffffffffffff00
	movk	x26, #0, lsl #16
	lsr	x11, x10, #33
	cmp	x11, #1
	mov	w11, #3                         ; =0x3
	stp	x8, x10, [x9]
	csel	w8, w11, wzr, eq
	str	xzr, [x9, #16]
	strb	w0, [x9, #24]
	strb	w8, [x9, #25]
	stur	wzr, [x9, #26]
	strh	wzr, [x9, #30]
	mov	w8, #2048                       ; =0x800
	movk	w8, #64, lsl #16
	add	x0, x20, x8
	mov	x1, #-4294967296                ; =0xffffffff00000000
	mov	w2, #-1                         ; =0xffffffff
	bl	_fi_take
	b	LBB107_217
LBB107_253:
	mov	w9, #0                          ; =0x0
LBB107_254:
	mov	w0, #0                          ; =0x0
	tbnz	w9, #0, LBB107_264
; %bb.255:
	ldr	w9, [sp, #92]                   ; 4-byte Folded Reload
	cbz	w9, LBB107_264
; %bb.256:
	mov	x21, #0                         ; =0x0
	mov	w22, #600                       ; =0x258
	mov	w25, #36                        ; =0x24
	mov	w26, #48                        ; =0x30
	mov	w27, #16392                     ; =0x4008
	b	LBB107_258
LBB107_257:                             ;   in Loop: Header=BB107_258 Depth=1
	add	x21, x21, #1
	add	x20, x20, x27
	cmp	x21, w8, uxth
	b.hs	LBB107_266
LBB107_258:                             ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x23, #16]
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	w10, [x10, x24, lsl #2]
	add	w10, w21, w10
	umaddl	x2, w10, w22, x9
	ldrb	w9, [x2, #8]
	cmp	w9, #152
	b.eq	LBB107_260
; %bb.259:                              ;   in Loop: Header=BB107_258 Depth=1
	cmp	w9, #60
	b.ne	LBB107_257
LBB107_260:                             ;   in Loop: Header=BB107_258 Depth=1
	ldr	w28, [x2]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	w28, [x8]
	ldrb	w8, [x20]
	cmp	w8, #1
	b.ne	LBB107_263
; %bb.261:                              ;   in Loop: Header=BB107_258 Depth=1
	sub	x3, x29, #112
	sub	x4, x29, #128
	mov	x0, x23
	mov	x1, x20
	bl	_fi_candidates
	cbnz	w0, LBB107_264
; %bb.262:                              ;   in Loop: Header=BB107_258 Depth=1
	ldur	w8, [x29, #-128]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	umaddl	x8, w8, w25, x9
	ldr	x12, [sp, #160]                 ; 8-byte Folded Reload
	ldr	x9, [x12, #32]
	ldr	w10, [x12, #16]
	add	w11, w10, #1
	str	w11, [x12, #16]
	umaddl	x9, w10, w26, x9
	ldrh	w10, [x8, #12]
	ldur	x11, [x29, #-112]
	ldrb	w12, [x8, #16]
	ldur	q0, [x8, #20]
	stur	q0, [x29, #-160]
	ldr	w8, [sp, #108]                  ; 4-byte Folded Reload
	stp	w8, w28, [x9]
	strh	w21, [x9, #8]
	strh	w10, [x9, #10]
	str	wzr, [x9, #12]
	str	x11, [x9, #16]
	strb	w12, [x9, #24]
	strb	wzr, [x9, #27]
	sturh	wzr, [x9, #25]
	ldur	q0, [x29, #-160]
	stur	q0, [x9, #28]
	str	wzr, [x9, #44]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x8, [x9, x24, lsl #3]
	orr	x8, x8, x11
	str	x8, [x9, x24, lsl #3]
	ldrh	w8, [x19, #8]
	b	LBB107_257
LBB107_263:
	mov	w0, #2                          ; =0x2
LBB107_264:
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #320]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #304]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #288]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
LBB107_265:
	mov	w0, #1                          ; =0x1
	b	LBB107_264
LBB107_266:
	mov	w0, #0                          ; =0x0
	b	LBB107_264
LBB107_267:
	mov	w0, #3                          ; =0x3
	b	LBB107_264
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh94, Lloh95
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI107_0:
	.short	(LBB107_177-LBB107_26)>>2
	.short	(LBB107_172-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_200-LBB107_26)>>2
	.short	(LBB107_166-LBB107_26)>>2
	.short	(LBB107_168-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_202-LBB107_26)>>2
	.short	(LBB107_95-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_100-LBB107_26)>>2
	.short	(LBB107_105-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_73-LBB107_26)>>2
	.short	(LBB107_100-LBB107_26)>>2
	.short	(LBB107_105-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_177-LBB107_26)>>2
	.short	(LBB107_177-LBB107_26)>>2
	.short	(LBB107_115-LBB107_26)>>2
	.short	(LBB107_115-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_121-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_81-LBB107_26)>>2
	.short	(LBB107_81-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_88-LBB107_26)>>2
	.short	(LBB107_88-LBB107_26)>>2
	.short	(LBB107_225-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_177-LBB107_26)>>2
	.short	(LBB107_66-LBB107_26)>>2
	.short	(LBB107_66-LBB107_26)>>2
	.short	(LBB107_73-LBB107_26)>>2
	.short	(LBB107_74-LBB107_26)>>2
	.short	(LBB107_206-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_128-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_149-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_116-LBB107_26)>>2
	.short	(LBB107_56-LBB107_26)>>2
	.short	(LBB107_56-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_135-LBB107_26)>>2
	.short	(LBB107_215-LBB107_26)>>2
	.short	(LBB107_218-LBB107_26)>>2
	.short	(LBB107_163-LBB107_26)>>2
	.short	(LBB107_95-LBB107_26)>>2
	.short	(LBB107_177-LBB107_26)>>2
	.short	(LBB107_73-LBB107_26)>>2
	.short	(LBB107_74-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_66-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_26-LBB107_26)>>2
	.short	(LBB107_121-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_43-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_170-LBB107_26)>>2
	.short	(LBB107_116-LBB107_26)>>2
	.short	(LBB107_56-LBB107_26)>>2
	.short	(LBB107_264-LBB107_26)>>2
	.short	(LBB107_56-LBB107_26)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_file_indirect_targets_free ; -- Begin function nvm_file_indirect_targets_free
	.globl	_nvm_file_indirect_targets_free
	.p2align	2
_nvm_file_indirect_targets_free:        ; @nvm_file_indirect_targets_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB108_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB108_6
; %bb.2:
	ldr	x21, [x20]
	cbz	x21, LBB108_5
; %bb.3:
	ldr	w8, [x21]
	subs	w8, w8, #1
	str	w8, [x21]
	b.ne	LBB108_5
; %bb.4:
	ldr	x0, [x21, #16]
	bl	_nvm_file_nominal_plan_free
	mov	x0, x21
	bl	_free
LBB108_5:
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #8]
	bl	_free
	mov	x0, x20
	bl	_free
LBB108_6:
	ldr	x0, [x19, #32]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB108_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_targets_summary ; -- Begin function nvm_file_indirect_targets_summary
	.globl	_nvm_file_indirect_targets_summary
	.p2align	2
_nvm_file_indirect_targets_summary:     ; @nvm_file_indirect_targets_summary
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB109_2
; %bb.1:
	ldur	q0, [x8, #8]
	ldr	x8, [x8, #24]
	str	x8, [x1, #16]
	str	q0, [x1]
LBB109_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_targets_call ; -- Begin function nvm_file_indirect_targets_call
	.globl	_nvm_file_indirect_targets_call
	.p2align	2
_nvm_file_indirect_targets_call:        ; @nvm_file_indirect_targets_call
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB110_5
; %bb.1:
	cbz	x2, LBB110_5
; %bb.2:
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB110_4
; %bb.3:
	ldr	x8, [x8, #32]
	mov	w9, #48                         ; =0x30
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8]
	ldr	q2, [x8, #32]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB110_4:
	mov	w0, #0                          ; =0x0
LBB110_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_targets_parameter ; -- Begin function nvm_file_indirect_targets_parameter
	.globl	_nvm_file_indirect_targets_parameter
	.p2align	2
_nvm_file_indirect_targets_parameter:   ; @nvm_file_indirect_targets_parameter
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB111_15
; %bb.1:
	cbz	x3, LBB111_15
; %bb.2:
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB111_14
; %bb.3:
	ldr	x11, [x8, #32]
	mov	w9, #48                         ; =0x30
	umaddl	x9, w1, w9, x11
	ldrh	w9, [x9, #10]
	cmp	w2, w9
	b.hs	LBB111_14
; %bb.4:
	ldr	x9, [x8]
	ldr	w10, [x9, #24]
	cbz	w10, LBB111_10
; %bb.5:
	mov	x8, #0                          ; =0x0
	mov	w12, w1
	mov	w13, #48                        ; =0x30
	umaddl	x11, w12, w13, x11
	ldr	x11, [x11, #16]
LBB111_6:                               ; =>This Inner Loop Header: Depth=1
	lsr	x12, x11, x8
	tbnz	w12, #0, LBB111_9
; %bb.7:                                ;   in Loop: Header=BB111_6 Depth=1
	add	x8, x8, #1
	cmp	x10, x8
	b.ne	LBB111_6
; %bb.8:
	mov	x8, x10
LBB111_9:
	ldr	x9, [x9]
	cbnz	x9, LBB111_11
	b	LBB111_14
LBB111_10:
	mov	w8, #0                          ; =0x0
	ldr	x9, [x9]
	cbz	x9, LBB111_14
LBB111_11:
	ldr	w10, [x9, #4]
	cmp	w8, w10
	b.hs	LBB111_14
; %bb.12:
	mov	w10, #24                        ; =0x18
	umaddl	x10, w8, w10, x9
	ldrh	w10, [x10, #26]
	cmp	w2, w10
	b.hs	LBB111_14
; %bb.13:
	mov	w8, w8
	add	x8, x9, x8, lsl #2
	ldr	w8, [x8, #1560]
	add	w8, w8, w2
	add	x8, x9, w8, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB111_14:
	mov	w0, #0                          ; =0x0
LBB111_15:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_analyze ; -- Begin function nvm_file_indirect_flow_analyze
	.globl	_nvm_file_indirect_flow_analyze
	.p2align	2
_nvm_file_indirect_flow_analyze:        ; @nvm_file_indirect_flow_analyze
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB112_7
; %bb.1:
	sub	sp, sp, #160
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
	mov	x23, x1
	str	xzr, [sp, #72]
	add	x8, sp, #48
	add	x1, sp, #72
	bl	_nvm_file_indirect_targets
	ldr	w0, [sp, #48]
	sub	w8, w0, #2
	cmp	w8, #3
	b.lo	LBB112_23
; %bb.2:
	cbnz	w0, LBB112_8
; %bb.3:
	add	x1, sp, #44
	add	x2, sp, #48
	mov	x0, x19
	bl	_file_code_preflight
	cbnz	w0, LBB112_21
; %bb.4:
	ldr	w8, [x19, #272]
	cbz	w8, LBB112_9
; %bb.5:
	ldr	x9, [x19, #256]
	cmp	w8, #4
	b.hs	LBB112_10
; %bb.6:
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	b	LBB112_13
LBB112_7:
	mov	w0, #1                          ; =0x1
	ret
LBB112_8:
	mov	w0, #1                          ; =0x1
	b	LBB112_23
LBB112_9:
	mov	w8, #1816                       ; =0x718
	b	LBB112_16
LBB112_10:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x8, #0xfffffffc
	add	x15, x9, #64
	mov	x16, x10
LBB112_11:                              ; =>This Inner Loop Header: Depth=1
	ldurh	w17, [x15, #-48]
	ldurh	w0, [x15, #-24]
	ldrh	w1, [x15]
	add	x11, x11, x17
	add	x12, x12, x0
	ldrh	w17, [x15, #24]
	add	x13, x13, x1
	add	x14, x14, x17
	add	x15, x15, #96
	subs	x16, x16, #4
	b.ne	LBB112_11
; %bb.12:
	add	x11, x12, x11
	add	x12, x14, x13
	add	x11, x12, x11
	cmp	x10, x8
	b.eq	LBB112_15
LBB112_13:
	sub	x8, x8, x10
	mov	w12, #24                        ; =0x18
	umaddl	x9, w10, w12, x9
	add	x9, x9, #16
LBB112_14:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x9], #24
	add	x11, x11, x10
	subs	x8, x8, #1
	b.ne	LBB112_14
LBB112_15:
	lsl	x8, x11, #4
	add	x8, x8, #1816
LBB112_16:
	mov	w10, #65480                     ; =0xffc8
	movk	w10, #255, lsl #16
	ldr	x9, [sp, #48]
	cmp	x9, x10
	b.hi	LBB112_20
; %bb.17:
	ldr	w24, [sp, #44]
	add	x11, x24, x24, lsl #4
	lsl	x11, x11, #3
	sub	x10, x10, x9
	cmp	x11, x10
	b.hi	LBB112_20
; %bb.18:
	add	x9, x9, x11
	add	x9, x9, #56
	mov	w10, #23912                     ; =0x5d68
	movk	w10, #254, lsl #16
	sub	x11, x10, x9
	cmp	x9, x10
	ccmp	x8, x11, #2, ls
	b.hi	LBB112_20
; %bb.19:
	add	x8, x9, x8
	add	x8, x8, #26, lsl #12            ; =106496
	add	x8, x8, #664
	mov	w9, #60545                      ; =0xec81
	movk	w9, #251, lsl #16
	cmp	x8, x9
	b.lo	LBB112_24
LBB112_20:
	mov	w0, #3                          ; =0x3
LBB112_21:
	ldr	x8, [sp, #72]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_file_indirect_targets_free
LBB112_22:
	mov	x0, x19
LBB112_23:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB112_24:
	ldr	x22, [sp, #72]
	ldr	x9, [x22, #24]
	mov	w10, #60544                     ; =0xec80
	movk	w10, #507, lsl #16
	sub	x8, x10, x8
	cmp	x9, x8
	b.ls	LBB112_26
; %bb.25:
	mov	x0, x22
	bl	_nvm_file_indirect_targets_free
	mov	w0, #3                          ; =0x3
	b	LBB112_23
LBB112_26:
	mov	w25, #4888                      ; =0x1318
	movk	w25, #4, lsl #16
	mov	w0, #1                          ; =0x1
	mov	w1, #104                        ; =0x68
	bl	_calloc
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #4888                       ; =0x1318
	movk	w1, #4, lsl #16
	bl	_calloc
	mov	x21, x0
	cbz	x20, LBB112_37
; %bb.27:
	cbz	x21, LBB112_37
; %bb.28:
	str	x22, [x20]
	str	x22, [x21]
	ldr	w8, [x22, #16]
	cbz	w8, LBB112_34
; %bb.29:
	ldr	x12, [x22, #32]
	ldr	x9, [x22]
	add	x10, x9, #2352
	add	x11, x21, #8
	add	x12, x12, #8
	mov	w13, #600                       ; =0x258
LBB112_30:                              ; =>This Inner Loop Header: Depth=1
	ldur	w14, [x12, #-8]
	ldrh	w15, [x12]
	ldr	w14, [x10, x14, lsl #2]
	add	w14, w14, w15
	cmp	w14, w24
	b.hs	LBB112_38
; %bb.31:                               ;   in Loop: Header=BB112_30 Depth=1
	ldur	w15, [x12, #-4]
	ldr	x16, [x9, #16]
	umull	x17, w14, w13
	ldr	w16, [x16, x17]
	cmp	w16, w15
	b.ne	LBB112_38
; %bb.32:                               ;   in Loop: Header=BB112_30 Depth=1
	ldr	x15, [x11, w14, uxtw #3]
	cbnz	x15, LBB112_38
; %bb.33:                               ;   in Loop: Header=BB112_30 Depth=1
	ldr	x15, [x12, #8]
	add	x12, x12, #48
	str	x15, [x11, w14, uxtw #3]
	subs	x8, x8, #1
	b.ne	LBB112_30
LBB112_34:
	add	x8, x25, #104
	add	x9, x22, #40
	stp	x8, x9, [sp, #8]
Lloh96:
	adrp	x8, _fif_transfer@PAGE
Lloh97:
	add	x8, x8, _fif_transfer@PAGEOFF
	stp	x21, x8, [sp, #24]
	add	x1, x20, #8
	add	x2, sp, #8
	mov	x0, x19
	bl	_file_cyclic_analyze_extended
	cbnz	w0, LBB112_39
; %bb.35:
	ldur	q0, [x22, #8]
	ldr	x8, [x22, #24]
	str	x8, [x20, #32]
	str	q0, [x20, #16]
	ldr	x8, [x20, #8]
	ldr	x9, [x8, #48]
	ldp	q1, q0, [x8, #16]
	stur	q1, [x20, #40]
	stur	q0, [x20, #56]
	str	x9, [x20, #72]
	mov	w9, #32776                      ; =0x8008
	ldr	w9, [x21, x9]
	str	w9, [x20, #80]
	ldr	x9, [x22, #24]
	ldr	x8, [x8, #40]
	mov	w10, #33554432                  ; =0x2000000
	add	x8, x8, x9
	cmp	x8, x10
	str	x8, [x20, #88]
	b.ls	LBB112_40
; %bb.36:
	mov	w0, #3                          ; =0x3
	b	LBB112_39
LBB112_37:
	mov	x0, x20
	bl	_free
	mov	x0, x21
	bl	_free
	mov	x0, x22
	bl	_nvm_file_indirect_targets_free
	mov	w0, #4                          ; =0x4
	b	LBB112_23
LBB112_38:
	mov	w0, #1                          ; =0x1
LBB112_39:
	mov	x19, x0
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_nvm_file_indirect_flow_free
	b	LBB112_22
LBB112_40:
	mov	x0, x21
	bl	_free
	mov	w0, #0                          ; =0x0
	str	x20, [x23]
	b	LBB112_23
	.loh AdrpAdd	Lloh96, Lloh97
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function fif_transfer
lCPI113_0:
	.long	5                               ; 0x5
	.long	64                              ; 0x40
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI113_1:
	.quad	-4294967285                     ; 0xffffffff0000000b
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_fif_transfer:                          ; @fif_transfer
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #720
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh98:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh99:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh100:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	ldrb	w8, [x3, #8]
	cmp	w8, #60
	b.eq	LBB113_6
; %bb.1:
	cmp	w8, #152
	b.eq	LBB113_6
; %bb.2:
	cmp	w8, #250
	b.ne	LBB113_14
; %bb.3:
	ldr	w8, [x3, #16]
	ldr	x9, [x1]
	ldr	w9, [x9, #24]
	cmp	w8, w9
	b.hs	LBB113_11
; %bb.4:
	ldrh	w8, [x2, #12]
	cmp	x8, #256
	b.ne	LBB113_16
LBB113_5:
	mov	w0, #3                          ; =0x3
	b	LBB113_12
LBB113_6:
	ldrh	w10, [x2, #12]
	cbz	x10, LBB113_11
; %bb.7:
	mov	w9, #24624                      ; =0x6030
	add	x9, x2, x9
	mov	w11, #40                        ; =0x28
	umaddl	x11, w10, w11, x9
	ldurb	w12, [x11, #-24]
	tbz	w12, #0, LBB113_11
; %bb.8:
	ldr	x12, [x11, #-40]!
	mov	x13, #-65525                    ; =0xffffffffffff000b
	movk	x13, #0, lsl #16
	eor	x13, x12, x13
	tst	x13, #0xff
	b.ne	LBB113_11
; %bb.9:
	ldr	x12, [x11, #8]
	and	x13, x13, #0xffffffffffffff00
	and	x13, x13, #0xffffffff0000ffff
	mov	w14, w12
	cmp	x13, #0
	mov	w13, #-1                        ; =0xffffffff
	ccmp	x14, x13, #0, eq
	b.ne	LBB113_11
; %bb.10:
	ldr	w13, [x11, #32]
	ldr	x11, [x11, #24]
	lsr	x12, x12, #32
	cmp	x12, #0
	ccmp	x11, #0, #0, eq
	ccmp	w13, #0, #0, eq
	b.eq	LBB113_17
LBB113_11:
	mov	w0, #1                          ; =0x1
LBB113_12:
	ldur	x8, [x29, #-96]
Lloh101:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh102:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh103:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB113_55
; %bb.13:
	add	sp, sp, #720
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB113_14:
	ldur	x8, [x29, #-96]
Lloh104:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh105:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh106:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB113_55
; %bb.15:
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	mov	x3, x4
	add	sp, sp, #720
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_file_body_transfer
LBB113_16:
	mov	w0, #0                          ; =0x0
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x2
	add	w8, w8, #1
	strh	w8, [x2, #12]
Lloh107:
	adrp	x8, lCPI113_1@PAGE
Lloh108:
	ldr	q0, [x8, lCPI113_1@PAGEOFF]
	mov	w8, #24624                      ; =0x6030
	add	x8, x9, x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x8, #16]
	str	q0, [x9, #24624]
	str	xzr, [x9, #24656]
	stur	xzr, [x8, #25]
	stur	xzr, [x8, #17]
	b	LBB113_12
LBB113_17:
	ldr	x12, [x1]
	ldr	x11, [x12, #16]
	sub	x11, x3, x11
	asr	x13, x11, #3
	mov	x14, #51555                     ; =0xc963
	movk	x14, #38447, lsl #16
	movk	x14, #25340, lsl #32
	movk	x14, #12233, lsl #48
	mul	x15, x13, x14
	ldr	w17, [x12, #32]
	cmp	x15, x17
	b.hs	LBB113_57
; %bb.18:
	add	x13, x0, x15, lsl #3
	ldr	x14, [x13, #8]
	cbz	x14, LBB113_57
; %bb.19:
	ldr	x13, [x0]
	ldr	x13, [x13]
	ldr	w16, [x2, #8]
	ldr	w5, [x13, #24]
	cmp	w16, w5
	b.hs	LBB113_11
; %bb.20:
	ldr	w5, [x12, #24]
	cmp	w16, w5
	b.hs	LBB113_11
; %bb.21:
	ldr	w5, [x13, #32]
	cmp	w5, w17
	b.ne	LBB113_11
; %bb.22:
	lsl	x5, x16, #2
	add	x17, x13, x5
	ldr	w17, [x17, #2352]
	add	x5, x12, x5
	ldr	w5, [x5, #2352]
	cmp	w17, w5
	b.ne	LBB113_11
; %bb.23:
	subs	x15, x15, x17
	b.lo	LBB113_11
; %bb.24:
	add	x16, x16, x16, lsl #3
	lsl	x16, x16, #2
	add	x17, x13, x16
	ldrh	w17, [x17, #56]
	cmp	x15, x17
	b.hs	LBB113_11
; %bb.25:
	stp	x14, x2, [sp, #40]              ; 16-byte Folded Spill
	stp	x1, x0, [sp, #56]               ; 16-byte Folded Spill
	str	x4, [sp, #32]                   ; 8-byte Folded Spill
	add	x12, x12, x16
	ldrh	w12, [x12, #56]
	cmp	w17, w12
	b.ne	LBB113_11
; %bb.26:
	mov	x20, x3
	ldr	x12, [x13, #16]
	add	x11, x12, x11
	ldr	w12, [x11]
	ldr	w13, [x3]
	cmp	w12, w13
	b.ne	LBB113_11
; %bb.27:
	ldrb	w11, [x11, #8]
	cmp	w11, w8
	b.ne	LBB113_11
; %bb.28:
	sub	w8, w10, #1
	ldr	x19, [sp, #48]                  ; 8-byte Folded Reload
	strh	w8, [x19, #12]
	and	x8, x8, #0xffff
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	xzr, [x8, #32]
	mov	w9, #32784                      ; =0x8010
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x0, x8, x9
	mov	x1, x19
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x8, [x19]
	ldr	x24, [x8, #8]
	str	xzr, [sp, #176]
	str	wzr, [sp, #184]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #128]
	str	xzr, [sp, #160]
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	w8, [x8, #24]
	cbz	w8, LBB113_57
; %bb.29:
	mov	x21, #0                         ; =0x0
	str	wzr, [sp, #28]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x8, x8, #39, lsl #12            ; =159744
	add	x25, x8, #224
	mov	w26, #32776                     ; =0x8008
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x27, x8, #16
	mov	w28, #28880                     ; =0x70d0
	movk	w28, #2, lsl #16
	add	x8, x20, #78
	stp	x24, x8, [sp, #8]               ; 16-byte Folded Spill
	add	x23, x25, #28
	mov	w22, #1                         ; =0x1
	b	LBB113_32
LBB113_30:                              ;   in Loop: Header=BB113_32 Depth=1
	ldr	x22, [sp, #64]                  ; 8-byte Folded Reload
	mov	w8, #14400                      ; =0x3840
	movk	w8, #1, lsl #16
	add	x0, x22, x8
	add	x1, x22, x28
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	mov	w8, #61552                      ; =0xf070
	movk	w8, #1, lsl #16
	add	x0, x22, x8
	mov	w8, #10496                      ; =0x2900
	movk	w8, #3, lsl #16
	add	x1, x22, x8
	mov	w2, #32784                      ; =0x8010
	bl	_memcpy
	mov	w22, #0                         ; =0x0
	ldr	x8, [x19]
	str	x8, [sp, #176]
	ldp	w8, w9, [x19, #8]
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	str	w8, [sp, #184]
	ldp	q0, q1, [x19, #16]
	stp	q0, q1, [sp, #128]
	ldr	x8, [x19, #48]
	str	x8, [sp, #160]
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB113_31:                              ;   in Loop: Header=BB113_32 Depth=1
	add	x21, x21, #1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	w8, [x8, #24]
	cmp	x21, x8
	b.hs	LBB113_56
LBB113_32:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB113_39 Depth 2
                                        ;     Child Loop BB113_45 Depth 2
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	lsr	x8, x8, x21
	tbz	w8, #0, LBB113_31
; %bb.33:                               ;   in Loop: Header=BB113_32 Depth=1
	ldrb	w8, [x27, x21]
	cmp	w8, #1
	b.ne	LBB113_57
; %bb.34:                               ;   in Loop: Header=BB113_32 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, x26]
	cmp	w8, #64, lsl #12                ; =262144
	b.eq	LBB113_5
; %bb.35:                               ;   in Loop: Header=BB113_32 Depth=1
	add	w8, w8, #1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	str	w8, [x9, x26]
	add	x0, x9, x28
	mov	w8, #32784                      ; =0x8010
	add	x1, x9, x8
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	ldp	x10, x8, [sp, #48]              ; 16-byte Folded Reload
	ldr	x9, [x10]
	str	x24, [x9, #8]
	ldr	x8, [x8]
	mov	w10, #36                        ; =0x24
	madd	x8, x21, x10, x8
	ldrh	w4, [x8, #60]
	cbz	x4, LBB113_42
; %bb.36:                               ;   in Loop: Header=BB113_32 Depth=1
	add	x8, x9, x21, lsl #2
	ldr	w8, [x8, #1560]
	add	x9, x9, #1817
	add	x10, sp, #192
	mov	x11, x4
	ldr	x12, [sp, #16]                  ; 8-byte Folded Reload
	b	LBB113_39
LBB113_37:                              ;   in Loop: Header=BB113_39 Depth=2
	mov	w13, #65535                     ; =0xffff
LBB113_38:                              ;   in Loop: Header=BB113_39 Depth=2
	strh	w13, [x10], #2
	add	w8, w8, #1
	add	x12, x12, #2
	subs	x11, x11, #1
	b.eq	LBB113_42
LBB113_39:                              ;   Parent Loop BB113_32 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ubfiz	x13, x8, #4, #32
	ldrb	w13, [x9, x13]
	cbz	w13, LBB113_37
; %bb.40:                               ;   in Loop: Header=BB113_39 Depth=2
	ldrb	w13, [x20, #8]
	cmp	w13, #152
	b.ne	LBB113_57
; %bb.41:                               ;   in Loop: Header=BB113_39 Depth=2
	ldrh	w13, [x12]
	b	LBB113_38
LBB113_42:                              ;   in Loop: Header=BB113_32 Depth=1
	ldr	w1, [x20]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x0, x8, x28
	add	x3, sp, #192
	mov	x2, x21
                                        ; kill: def $w4 killed $w4 killed $x4
	bl	_nvm_file_flow_call
	cbnz	w0, LBB113_12
; %bb.43:                               ;   in Loop: Header=BB113_32 Depth=1
	ldrh	w8, [x25]
	cbz	x8, LBB113_11
; %bb.44:                               ;   in Loop: Header=BB113_32 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	w10, [x20]
	mov	x11, x23
LBB113_45:                              ;   Parent Loop BB113_32 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w12, [x11, #4]
	cmp	w12, w10
	csel	x9, x11, x9, eq
	add	x11, x11, #56
	subs	x8, x8, #1
	b.ne	LBB113_45
; %bb.46:                               ;   in Loop: Header=BB113_32 Depth=1
	cbz	x9, LBB113_11
; %bb.47:                               ;   in Loop: Header=BB113_32 Depth=1
	mov	x19, x9
	ldr	w8, [x9]
	cmp	w8, #1
	b.ne	LBB113_11
; %bb.48:                               ;   in Loop: Header=BB113_32 Depth=1
	ldr	w8, [x19, #8]
	cmp	x21, x8
	b.ne	LBB113_11
; %bb.49:                               ;   in Loop: Header=BB113_32 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x19, #8]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #28800                      ; =0x7080
	movk	w9, #2, lsl #16
	add	x0, x8, x9
	bl	_file_cyclic_canonicalize
	cbnz	w0, LBB113_12
; %bb.50:                               ;   in Loop: Header=BB113_32 Depth=1
	tbnz	w22, #0, LBB113_30
; %bb.51:                               ;   in Loop: Header=BB113_32 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #61552                      ; =0xf070
	movk	w9, #1, lsl #16
	add	x0, x8, x9
	mov	w9, #10496                      ; =0x2900
	movk	w9, #3, lsl #16
	add	x1, x8, x9
	bl	_file_cyclic_equal
	cbz	w0, LBB113_57
; %bb.52:                               ;   in Loop: Header=BB113_32 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #14400                      ; =0x3840
	movk	w9, #1, lsl #16
	add	x0, x8, x9
	add	x1, x8, x28
	bl	_fif_state_metadata_equal
	tbz	w0, #0, LBB113_57
; %bb.53:                               ;   in Loop: Header=BB113_32 Depth=1
	ldr	x8, [sp, #176]
	str	x8, [sp, #72]
	ldr	w9, [sp, #184]
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	stp	w9, w8, [sp, #80]
	ldp	q0, q1, [sp, #128]
	add	x9, sp, #72
	stp	q0, q1, [x9, #16]
	ldr	x8, [sp, #160]
	stur	x8, [x9, #48]
	add	x0, sp, #72
	mov	x1, x19
	bl	_obligation_same
	cbz	w0, LBB113_57
; %bb.54:                               ;   in Loop: Header=BB113_32 Depth=1
	mov	w22, #0                         ; =0x0
	b	LBB113_31
LBB113_55:
	bl	___stack_chk_fail
LBB113_56:
	tbz	w22, #0, LBB113_58
LBB113_57:
	mov	w0, #2                          ; =0x2
	b	LBB113_12
LBB113_58:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #14400                      ; =0x3840
	movk	w9, #1, lsl #16
	add	x1, x8, x9
	ldr	x19, [sp, #48]                  ; 8-byte Folded Reload
	mov	x0, x19
	mov	w2, #47152                      ; =0xb830
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldr	x8, [x19]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	x9, [x8, #8]
	ldp	q0, q1, [sp, #128]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	q0, [x8, #40]
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #3]
	ldr	x9, [sp, #176]
	str	x9, [x8, #24]
	ldr	w9, [sp, #184]
	ldr	w10, [sp, #28]                  ; 4-byte Folded Reload
	stp	w9, w10, [x8, #32]
	stur	q1, [x8, #56]
	ldr	x9, [sp, #160]
	str	x9, [x8, #72]
Lloh109:
	adrp	x9, lCPI113_0@PAGE
Lloh110:
	ldr	d0, [x9, lCPI113_0@PAGEOFF]
	stur	d0, [x8, #12]
	and	w9, w10, #0xffffffbf
	ldr	w10, [x8, #20]
	orr	w9, w10, w9
	str	w9, [x8, #20]
	b	LBB113_12
	.loh AdrpLdrGotLdr	Lloh98, Lloh99, Lloh100
	.loh AdrpLdrGotLdr	Lloh101, Lloh102, Lloh103
	.loh AdrpLdrGotLdr	Lloh104, Lloh105, Lloh106
	.loh AdrpLdr	Lloh107, Lloh108
	.loh AdrpLdr	Lloh109, Lloh110
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_free ; -- Begin function nvm_file_indirect_flow_free
	.globl	_nvm_file_indirect_flow_free
	.p2align	2
_nvm_file_indirect_flow_free:           ; @nvm_file_indirect_flow_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB114_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #8]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_file_cyclic_free
	ldr	x0, [x19]
	bl	_nvm_file_indirect_targets_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB114_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_summary ; -- Begin function nvm_file_indirect_flow_summary
	.globl	_nvm_file_indirect_flow_summary
	.p2align	2
_nvm_file_indirect_flow_summary:        ; @nvm_file_indirect_flow_summary
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB115_2
; %bb.1:
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [x1]
	ldp	q0, q1, [x8, #48]
	ldr	q2, [x8, #80]
	ldr	x8, [x8, #96]
	str	x8, [x1, #80]
	stp	q1, q2, [x1, #48]
	str	q0, [x1, #32]
LBB115_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_function ; -- Begin function nvm_file_indirect_flow_function
	.globl	_nvm_file_indirect_flow_function
	.p2align	2
_nvm_file_indirect_flow_function:       ; @nvm_file_indirect_flow_function
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB116_7
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB116_6
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB116_7
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB116_7
; %bb.4:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB116_6
; %bb.5:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8, #48]
	ldr	w8, [x8, #80]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB116_6:
	mov	w0, #0                          ; =0x0
LBB116_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_local ; -- Begin function nvm_file_indirect_flow_local
	.globl	_nvm_file_indirect_flow_local
	.p2align	2
_nvm_file_indirect_flow_local:          ; @nvm_file_indirect_flow_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB117_9
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB117_8
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB117_8
; %bb.3:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB117_9
; %bb.4:
	ldr	x8, [x8]
	cbz	x8, LBB117_9
; %bb.5:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB117_8
; %bb.6:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB117_8
; %bb.7:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB117_8:
	mov	w0, #0                          ; =0x0
LBB117_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_instruction ; -- Begin function nvm_file_indirect_flow_instruction
	.globl	_nvm_file_indirect_flow_instruction
	.p2align	2
_nvm_file_indirect_flow_instruction:    ; @nvm_file_indirect_flow_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB118_7
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB118_8
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB118_7
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB118_7
; %bb.4:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB118_8
; %bb.5:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB118_8
; %bb.6:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, w1
	ldr	x10, [x8, #16]
	add	x8, x8, x9, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x0, x3
	mov	w2, #600                        ; =0x258
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB118_7:
	ret
LBB118_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_variant_count ; -- Begin function nvm_file_indirect_flow_variant_count
	.globl	_nvm_file_indirect_flow_variant_count
	.p2align	2
_nvm_file_indirect_flow_variant_count:  ; @nvm_file_indirect_flow_variant_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB119_8
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB119_7
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB119_7
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB119_7
; %bb.4:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB119_8
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB119_8
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB119_7:
	mov	w0, #0                          ; =0x0
LBB119_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_variant ; -- Begin function nvm_file_indirect_flow_variant
	.globl	_nvm_file_indirect_flow_variant
	.p2align	2
_nvm_file_indirect_flow_variant:        ; @nvm_file_indirect_flow_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB120_10
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB120_9
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB120_9
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB120_9
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB120_9
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB120_9
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x4, LBB120_10
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB120_10
; %bb.8:
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	stp	q1, q2, [x4, #16]
	str	q0, [x4]
	ldur	q0, [x8, #104]
	ldur	q1, [x8, #120]
	ldur	q2, [x8, #136]
	ldr	x8, [x8, #152]
	str	x8, [x4, #96]
	stp	q1, q2, [x4, #64]
	str	q0, [x4, #48]
	mov	w0, #1                          ; =0x1
	ret
LBB120_9:
	mov	w0, #0                          ; =0x0
LBB120_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_input_local ; -- Begin function nvm_file_indirect_flow_input_local
	.globl	_nvm_file_indirect_flow_input_local
	.p2align	2
_nvm_file_indirect_flow_input_local:    ; @nvm_file_indirect_flow_input_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB121_11
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB121_10
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB121_10
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB121_10
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB121_10
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB121_10
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB121_11
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB121_11
; %bb.8:
	ldrh	w9, [x8]
	cmp	w4, w9
	b.hs	LBB121_10
; %bb.9:
	ldr	x8, [x8, #16]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB121_10:
	mov	w0, #0                          ; =0x0
LBB121_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_input_stack ; -- Begin function nvm_file_indirect_flow_input_stack
	.globl	_nvm_file_indirect_flow_input_stack
	.p2align	2
_nvm_file_indirect_flow_input_stack:    ; @nvm_file_indirect_flow_input_stack
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB122_11
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB122_10
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB122_10
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB122_10
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB122_10
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB122_10
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB122_11
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB122_11
; %bb.8:
	ldrh	w9, [x8, #2]
	cmp	w4, w9
	b.hs	LBB122_10
; %bb.9:
	ldr	x8, [x8, #24]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB122_10:
	mov	w0, #0                          ; =0x0
LBB122_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_input_reference ; -- Begin function nvm_file_indirect_flow_input_reference
	.globl	_nvm_file_indirect_flow_input_reference
	.p2align	2
_nvm_file_indirect_flow_input_reference: ; @nvm_file_indirect_flow_input_reference
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB123_12
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB123_11
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB123_11
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB123_11
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB123_11
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB123_11
; %bb.6:
	mov	w0, #0                          ; =0x0
	cmp	w4, #255
	b.hi	LBB123_12
; %bb.7:
	cbz	x5, LBB123_12
; %bb.8:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB123_12
; %bb.9:
	ldrh	w9, [x8, #48]
	cmp	w4, w9
	b.hs	LBB123_13
; %bb.10:
	ldr	x8, [x8, #32]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	str	q1, [x5, #16]
	b	LBB123_14
LBB123_11:
	mov	w0, #0                          ; =0x0
LBB123_12:
	ret
LBB123_13:
	str	xzr, [x5, #32]
	movi.2d	v0, #0000000000000000
	str	q0, [x5, #16]
LBB123_14:
	str	q0, [x5]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_input_region ; -- Begin function nvm_file_indirect_flow_input_region
	.globl	_nvm_file_indirect_flow_input_region
	.p2align	2
_nvm_file_indirect_flow_input_region:   ; @nvm_file_indirect_flow_input_region
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB124_11
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB124_10
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB124_10
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB124_10
; %bb.4:
	ldr	x9, [x9, #8]
	cbz	x9, LBB124_10
; %bb.5:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB124_10
; %bb.6:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB124_11
; %bb.7:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB124_11
; %bb.8:
	ldrh	w9, [x8, #4]
	cmp	w4, w9
	b.hs	LBB124_10
; %bb.9:
	ldr	x8, [x8, #40]
	ldr	x8, [x8, w4, uxtw #3]
	str	x8, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB124_10:
	mov	w0, #0                          ; =0x0
LBB124_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_call ; -- Begin function nvm_file_indirect_flow_call
	.globl	_nvm_file_indirect_flow_call
	.p2align	2
_nvm_file_indirect_flow_call:           ; @nvm_file_indirect_flow_call
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB125_16
; %bb.1:
	cbz	x4, LBB125_16
; %bb.2:
	ldr	x8, [x0, #8]
	cbz	x8, LBB125_16
; %bb.3:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	ldr	x9, [x8]
	cbz	x9, LBB125_14
; %bb.4:
	ldr	w10, [x9, #24]
	cmp	w1, w10
	b.hs	LBB125_14
; %bb.5:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x9
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB125_14
; %bb.6:
	mov	w10, w1
	ldr	x11, [x9, #16]
	add	x9, x9, x10, lsl #2
	ldr	w9, [x9, #2352]
	add	w10, w9, w2
	mov	w9, #600                        ; =0x258
	umaddl	x11, w10, w9, x11
	ldr	w9, [x11]
	ldrb	w11, [x11, #8]
	cmp	w11, #152
	b.eq	LBB125_8
; %bb.7:
	cmp	w11, #60
	b.ne	LBB125_14
LBB125_8:
	ldr	x8, [x8, #8]
	cbz	x8, LBB125_15
; %bb.9:
	mov	w11, #136                       ; =0x88
	umaddl	x8, w10, w11, x8
	ldrb	w10, [x8]
	cmp	w3, w10
	b.hs	LBB125_14
; %bb.10:
	add	x8, x8, w3, uxtw #3
	ldr	x10, [x8, #8]
	cbz	x10, LBB125_14
; %bb.11:
	ldrb	w8, [x10, #79]
	tbz	w8, #0, LBB125_14
; %bb.12:
	ldr	x8, [x0]
	ldr	w11, [x8, #16]
	cbz	w11, LBB125_14
; %bb.13:
	ldr	x8, [x8, #32]
	add	x12, x8, #8
	b	LBB125_18
LBB125_14:
	mov	w8, #0                          ; =0x0
LBB125_15:
	add	sp, sp, #64
LBB125_16:
	mov	x0, x8
	ret
LBB125_17:                              ;   in Loop: Header=BB125_18 Depth=1
	mov	w8, #0                          ; =0x0
	add	x12, x12, #48
	subs	x11, x11, #1
	b.eq	LBB125_15
LBB125_18:                              ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x12, #-8]
	cmp	w8, w1
	b.ne	LBB125_17
; %bb.19:                               ;   in Loop: Header=BB125_18 Depth=1
	ldrh	w8, [x12]
	cmp	w8, w2
	b.ne	LBB125_17
; %bb.20:                               ;   in Loop: Header=BB125_18 Depth=1
	ldur	w8, [x12, #-4]
	cmp	w8, w9
	b.ne	LBB125_17
; %bb.21:
	ldr	x8, [x12, #8]
	ldur	q0, [x10, #100]
	ldur	q1, [x10, #116]
	stp	q0, q1, [sp]
	ldur	q2, [x10, #132]
	str	q2, [sp, #32]
	ldur	x10, [x10, #148]
	str	x10, [sp, #48]
	stp	w1, w9, [x4]
	stp	x8, x8, [x4, #8]
	stur	q0, [x4, #24]
	stur	q1, [x4, #40]
	stur	q2, [x4, #56]
	mov	w8, #1                          ; =0x1
	str	x10, [x4, #72]
	b	LBB125_15
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_component ; -- Begin function nvm_file_indirect_flow_component
	.globl	_nvm_file_indirect_flow_component
	.p2align	2
_nvm_file_indirect_flow_component:      ; @nvm_file_indirect_flow_component
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB126_8
; %bb.1:
	ldr	x9, [x0, #8]
	cbz	x9, LBB126_7
; %bb.2:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB126_7
; %bb.3:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB126_7
; %bb.4:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB126_8
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB126_8
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrh	w8, [x8, #2]
	strh	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB126_7:
	mov	w0, #0                          ; =0x0
LBB126_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_type ; -- Begin function nvm_file_indirect_flow_type
	.globl	_nvm_file_indirect_flow_type
	.p2align	2
_nvm_file_indirect_flow_type:           ; @nvm_file_indirect_flow_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB127_3
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB127_3
; %bb.2:
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_type
LBB127_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_flow_import ; -- Begin function nvm_file_indirect_flow_import
	.globl	_nvm_file_indirect_flow_import
	.p2align	2
_nvm_file_indirect_flow_import:         ; @nvm_file_indirect_flow_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB128_3
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB128_3
; %bb.2:
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_import
LBB128_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_free ; -- Begin function nvm_file_indirect_hosted_free
	.globl	_nvm_file_indirect_hosted_free
	.p2align	2
_nvm_file_indirect_hosted_free:         ; @nvm_file_indirect_hosted_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB129_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB129_3
; %bb.2:
	ldr	x0, [x20, #8]
	bl	_nvm_file_cyclic_free
	ldr	x0, [x20]
	bl	_nvm_file_indirect_targets_free
	mov	x0, x20
	bl	_free
LBB129_3:
	mov	w8, #32776                      ; =0x8008
	ldr	x0, [x19, x8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB129_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_prepare ; -- Begin function nvm_file_indirect_hosted_prepare
	.globl	_nvm_file_indirect_hosted_prepare
	.p2align	2
_nvm_file_indirect_hosted_prepare:      ; @nvm_file_indirect_hosted_prepare
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB130_4
; %bb.1:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #336]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #352]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x1
	mov	x22, x2
	sub	x2, x29, #112
	sub	x3, x29, #120
	mov	x21, x0
	bl	_file_hosted_preflight
	cbnz	w0, LBB130_14
; %bb.2:
	ldur	x23, [x29, #-120]
	lsr	x8, x23, #24
	cbnz	x8, LBB130_5
; %bb.3:
	mov	w0, #1                          ; =0x1
	b	LBB130_14
LBB130_4:
	mov	w0, #1                          ; =0x1
	ret
LBB130_5:
	mov	x8, #-27025                     ; =0xffffffffffff966f
	movk	x8, #64768, lsl #16
	mov	x9, #-27025                     ; =0xffffffffffff966f
	movk	x9, #65024, lsl #16
	add	x8, x23, x8
	cmp	x8, x9
	b.hs	LBB130_7
; %bb.6:
	mov	w0, #3                          ; =0x3
	b	LBB130_14
LBB130_7:
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB130_13
; %bb.8:
	mov	x19, x0
	add	x24, sp, #16
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	str	xzr, [sp, #256]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #208]
	stp	q0, q0, [x24, #176]
	stp	q0, q0, [x24, #144]
	str	q0, [x24, #128]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #8]
	add	x2, sp, #16
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_v2_module_deserialize
	cbnz	w0, LBB130_10
; %bb.9:
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_to_nvm_module
	cbz	w0, LBB130_15
LBB130_10:
	mov	x0, #0                          ; =0x0
LBB130_11:
	mov	w23, #2                         ; =0x2
LBB130_12:
	bl	_nvm_file_indirect_hosted_free
	ldr	x0, [sp, #8]
	bl	_nvm_module_free
	add	x0, sp, #16
	bl	_nvm_v2_module_free
	mov	x0, x19
	bl	_free
	mov	x0, x23
	b	LBB130_14
LBB130_13:
	mov	w0, #4                          ; =0x4
LBB130_14:
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #368]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #352]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
LBB130_15:
	ldr	x21, [sp, #8]
	cbz	x21, LBB130_10
; %bb.16:
	ldr	w2, [x21, #288]
	ldr	x8, [sp, #192]
	cmp	x8, x2
	b.ne	LBB130_10
; %bb.17:
	ldr	x0, [x21, #280]
	cbz	x0, LBB130_11
; %bb.18:
	ldr	x1, [sp, #184]
	bl	_memcmp
	cbnz	w0, LBB130_10
; %bb.19:
	mov	w24, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #38512                      ; =0x9670
	bl	_calloc
	cbz	x0, LBB130_22
; %bb.20:
	mov	w8, #38512                      ; =0x9670
	movk	w8, #256, lsl #16
	add	x23, x23, x8
	add	x8, x0, #8, lsl #12             ; =32768
	str	w24, [x8, #16]
	mov	x24, x8
	ldur	w8, [x29, #-104]
	str	w8, [x24, #32]
	stp	x20, x23, [x24, #72]
	mov	x1, x0
	mov	x0, x21
	mov	x21, x1
	bl	_nvm_file_indirect_flow_analyze
	cbz	w0, LBB130_23
LBB130_21:
	mov	x23, x0
	mov	x0, x21
	b	LBB130_12
LBB130_22:
	mov	w23, #4                         ; =0x4
	b	LBB130_12
LBB130_23:
	str	x24, [sp]                       ; 8-byte Folded Spill
	ldr	x9, [x21]
	ldr	w10, [x9, #40]
	cmp	w10, #1
	b.ne	LBB130_28
; %bb.24:
	ldrb	w10, [x9, #96]
	tbnz	w10, #0, LBB130_27
; %bb.25:
	ldrb	w10, [x9, #72]
	tbnz	w10, #0, LBB130_27
; %bb.26:
	ldr	x9, [x9, #88]
	mov	w10, #33554432                  ; =0x2000000
	cmp	x9, x10
	b.ls	LBB130_29
LBB130_27:
	mov	w23, #1                         ; =0x1
	mov	x0, x21
	b	LBB130_12
LBB130_28:
	mov	x0, x21
	mov	w23, #1                         ; =0x1
	b	LBB130_12
LBB130_29:
	mov	x8, x23
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	str	x9, [x10, #88]
	mov	w10, #27024                     ; =0x6990
	movk	w10, #1023, lsl #16
	mov	w23, #3                         ; =0x3
	cmp	x20, x10
	b.hi	LBB130_32
; %bb.30:
	sub	x10, x10, x20
	cmp	x9, x10
	b.hi	LBB130_32
; %bb.31:
	mov	w10, #38512                     ; =0x9670
	add	x9, x20, x9
	add	x9, x9, x10
	cmp	x9, x8
	b.ls	LBB130_33
LBB130_32:
	mov	x0, x21
	b	LBB130_12
LBB130_33:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x9, [x8, #96]
	mov	x0, x21
	bl	_file_ih_target_map
	cbz	w0, LBB130_27
; %bb.34:
	ldr	x2, [sp, #8]
	add	x1, sp, #16
	mov	x0, x21
	bl	_file_ih_start
	cbnz	w0, LBB130_21
; %bb.35:
	add	x1, sp, #16
	mov	x0, x21
	bl	_file_ih_bounds
	mov	x23, x0
	cbnz	w0, LBB130_32
; %bb.36:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x19, [x8, #8]
	str	x21, [x22]
	mov	x19, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	b	LBB130_12
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_target_map
_file_ih_target_map:                    ; @file_ih_target_map
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0]
	ldp	x14, x8, [x8]
	ldr	x8, [x8]
	ldr	w9, [x14, #8]
	ldr	w10, [x8, #24]
	cmp	w9, w10
	b.ne	LBB131_19
; %bb.1:
	ldr	w10, [x14, #12]
	ldr	w11, [x8, #32]
	cmp	w10, w11
	b.ne	LBB131_19
; %bb.2:
	ldr	w11, [x14, #16]
	cbz	w11, LBB131_14
; %bb.3:
	add	x12, x8, #56
	add	x13, x8, #2352
	ldr	x15, [x14, #32]
	add	x14, x0, #8
	add	x15, x15, #8
	mov	w16, #36                        ; =0x24
	mov	w17, #600                       ; =0x258
LBB131_4:                               ; =>This Inner Loop Header: Depth=1
	ldur	w3, [x15, #-8]
	cmp	w3, w9
	b.hs	LBB131_19
; %bb.5:                                ;   in Loop: Header=BB131_4 Depth=1
	ldr	x1, [x15, #8]
	ldrh	w4, [x15]
	umull	x2, w3, w16
	ldrh	w2, [x12, x2]
	cmp	w4, w2
	ccmp	x1, #0, #4, lo
	b.eq	LBB131_19
; %bb.6:                                ;   in Loop: Header=BB131_4 Depth=1
	ldur	w2, [x15, #-4]
	cmp	w9, #63
	b.hi	LBB131_8
; %bb.7:                                ;   in Loop: Header=BB131_4 Depth=1
	lsr	x5, x1, x9
	cbnz	x5, LBB131_19
LBB131_8:                               ;   in Loop: Header=BB131_4 Depth=1
	ldr	w3, [x13, x3, lsl #2]
	add	w3, w3, w4
	cmp	w3, #4095
	b.hi	LBB131_19
; %bb.9:                                ;   in Loop: Header=BB131_4 Depth=1
	ldr	x4, [x14, w3, uxtw #3]
	cbnz	x4, LBB131_19
; %bb.10:                               ;   in Loop: Header=BB131_4 Depth=1
	ldr	x4, [x8, #16]
	umaddl	x5, w3, w17, x4
	ldrb	w5, [x5, #8]
	cmp	w5, #152
	b.eq	LBB131_12
; %bb.11:                               ;   in Loop: Header=BB131_4 Depth=1
	cmp	w5, #60
	b.ne	LBB131_19
LBB131_12:                              ;   in Loop: Header=BB131_4 Depth=1
	umull	x5, w3, w17
	ldr	w4, [x4, x5]
	cmp	w4, w2
	b.ne	LBB131_19
; %bb.13:                               ;   in Loop: Header=BB131_4 Depth=1
	add	x15, x15, #48
	str	x1, [x14, x3, lsl #3]
	subs	x11, x11, #1
	b.ne	LBB131_4
LBB131_14:
	cbz	w10, LBB131_20
; %bb.15:
	ldr	x11, [x8, #16]
	add	x8, x0, #8
	sub	x9, x10, #1
	add	x10, x11, #8
	mov	w11, #152                       ; =0x98
LBB131_16:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x10]
	cmp	w12, #60
	ccmp	w12, w11, #4, ne
	cset	w12, eq
	ldr	x13, [x8], #8
	cmp	x13, #0
	cset	w13, eq
	eor	w0, w12, w13
	subs	x9, x9, #1
	cset	w12, hs
	cmp	w0, #1
	b.ne	LBB131_18
; %bb.17:                               ;   in Loop: Header=BB131_16 Depth=1
	add	x10, x10, #600
	tbnz	w12, #0, LBB131_16
LBB131_18:
	ret
LBB131_19:
	mov	w0, #0                          ; =0x0
	ret
LBB131_20:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_start
_file_ih_start:                         ; @file_ih_start
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x8, [x0]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	w21, [x8, #24]
	ldr	w9, [x1, #80]
	cmp	w21, w9
	b.ne	LBB132_3
; %bb.1:
	ldr	w9, [x2, #272]
	cmp	w21, w9
	b.ne	LBB132_3
; %bb.2:
	ldrb	w9, [x2, #8]
	tbnz	w9, #0, LBB132_5
LBB132_3:
	mov	w0, #1                          ; =0x1
LBB132_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB132_5:
	mov	x10, x0
	ldr	w9, [x2, #12]
	ldr	w11, [x1, #4]
	mov	w0, #1                          ; =0x1
	cmp	w9, w11
	b.ne	LBB132_4
; %bb.6:
	cmp	w11, w21
	b.hs	LBB132_4
; %bb.7:
	add	x22, x10, #8, lsl #12           ; =32768
	mov	w10, #-1                        ; =0xffffffff
	stp	w9, w10, [x22, #20]
	str	w21, [x22, #28]
	mov	w10, #36                        ; =0x24
	umaddl	x9, w9, w10, x8
	ldrh	w10, [x9, #60]
	cbnz	w10, LBB132_11
; %bb.8:
	ldurb	w10, [x9, #64]
	cmp	w10, #1
	b.ne	LBB132_11
; %bb.9:
	ldurb	w10, [x9, #69]
	cbnz	w10, LBB132_11
; %bb.10:
	ldur	w10, [x9, #72]
	cmn	w10, #1
	b.eq	LBB132_12
LBB132_11:
	mov	w0, #2                          ; =0x2
	b	LBB132_4
LBB132_12:
	ldurb	w9, [x9, #68]
	cmp	w9, #4
	ccmp	w9, #1, #4, ne
	b.ne	LBB132_11
; %bb.13:
	mov	x23, #0                         ; =0x0
	ldr	x24, [x2, #256]
	ldr	w25, [x2, #248]
	add	x26, x8, #72
	mov	w28, #-1                        ; =0xffffffff
Lloh111:
	adrp	x19, l_.str.3@PAGE
Lloh112:
	add	x19, x19, l_.str.3@PAGEOFF
	b	LBB132_16
LBB132_14:                              ;   in Loop: Header=BB132_16 Depth=1
	mov	w28, #-1                        ; =0xffffffff
LBB132_15:                              ;   in Loop: Header=BB132_16 Depth=1
	mov	w0, #0                          ; =0x0
	add	x23, x23, #1
	add	x26, x26, #36
	cmp	x21, x23
	mov	x2, x27
	b.eq	LBB132_4
LBB132_16:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24], #24
	cmp	w8, w25
	b.hs	LBB132_3
; %bb.17:                               ;   in Loop: Header=BB132_16 Depth=1
	ldr	x9, [x2, #232]
	ldr	x20, [x9, x8, lsl #3]
	cbz	x20, LBB132_3
; %bb.18:                               ;   in Loop: Header=BB132_16 Depth=1
	mov	x27, x2
	ldr	x9, [x2, #240]
	ldr	w2, [x9, x8, lsl #2]
	mov	x0, x20
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB132_3
; %bb.19:                               ;   in Loop: Header=BB132_16 Depth=1
	cmn	w28, #1
	b.ne	LBB132_15
; %bb.20:                               ;   in Loop: Header=BB132_16 Depth=1
	mov	x0, x20
	mov	x1, x19
	bl	_strcmp
	cbnz	w0, LBB132_14
; %bb.21:                               ;   in Loop: Header=BB132_16 Depth=1
	ldurh	w8, [x26, #-12]
	cbnz	w8, LBB132_11
; %bb.22:                               ;   in Loop: Header=BB132_16 Depth=1
	ldurb	w8, [x26, #-8]
	cbnz	w8, LBB132_11
; %bb.23:                               ;   in Loop: Header=BB132_16 Depth=1
	ldurb	w8, [x26, #-4]
	cbnz	w8, LBB132_11
; %bb.24:                               ;   in Loop: Header=BB132_16 Depth=1
	ldurb	w8, [x26, #-3]
	cbnz	w8, LBB132_11
; %bb.25:                               ;   in Loop: Header=BB132_16 Depth=1
	ldr	w8, [x26]
	cmn	w8, #1
	b.ne	LBB132_11
; %bb.26:                               ;   in Loop: Header=BB132_16 Depth=1
	str	w23, [x22, #24]
	mov	x28, x23
	b	LBB132_15
	.loh AdrpAdd	Lloh111, Lloh112
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function file_ih_bounds
lCPI133_0:
	.long	4294967295                      ; 0xffffffff
	.long	448                             ; 0x1c0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_file_ih_bounds:                        ; @file_ih_bounds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	d9, d8, [sp, #288]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #320]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #336]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #352]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x20, x1
Lloh113:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh114:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh115:
	ldr	x8, [x8]
	stur	x8, [x29, #-112]
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	ldr	x8, [x0]
	ldr	x0, [x8, #8]
	ldr	x25, [x0]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x29, #-144]
	stp	q0, q0, [x29, #-176]
	bl	_file_cyclic_complete
	cbz	w0, LBB133_145
; %bb.1:
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	add	x7, x8, #8, lsl #12             ; =32768
	ldr	w8, [x25, #24]
	cbz	w8, LBB133_123
; %bb.2:
	mov	x12, #0                         ; =0x0
	add	x13, x25, #2608
	mov	w9, #32880                      ; =0x8070
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	add	x14, x10, x9
	add	x15, x25, #48
	add	x24, x25, #2352
	add	x9, x10, #8
	str	x9, [sp, #128]                  ; 8-byte Folded Spill
	add	x21, x7, #184
	sub	x23, x29, #176
	mov	w10, #88                        ; =0x58
	mov	w11, #36                        ; =0x24
	mov	w16, #65537                     ; =0x10001
	mov	w30, #136                       ; =0x88
Lloh116:
	adrp	x9, lCPI133_0@PAGE
Lloh117:
	ldr	d8, [x9, lCPI133_0@PAGEOFF]
LBB133_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB133_13 Depth 2
                                        ;       Child Loop BB133_20 Depth 3
                                        ;         Child Loop BB133_41 Depth 4
                                        ;           Child Loop BB133_47 Depth 5
                                        ;     Child Loop BB133_95 Depth 2
                                        ;       Child Loop BB133_98 Depth 3
                                        ;         Child Loop BB133_112 Depth 4
	ldr	w26, [x13, x12, lsl #2]
	cmp	x26, x8
	b.hs	LBB133_145
; %bb.4:                                ;   in Loop: Header=BB133_3 Depth=1
	ldrb	w8, [x23, x26]
	tbnz	w8, #0, LBB133_145
; %bb.5:                                ;   in Loop: Header=BB133_3 Depth=1
	umaddl	x27, w26, w10, x14
	umaddl	x8, w26, w11, x15
	ldp	q0, q1, [x8]
	ldr	w8, [x8, #32]
	str	w8, [x27, #32]
	stp	q0, q1, [x27]
	ldr	x8, [x20, #72]
	add	x8, x8, x26, lsl #5
	ldrh	w8, [x8, #28]
	strh	w8, [x27, #36]
	ldrh	w4, [x27, #14]
	strh	w4, [x27, #40]
	stur	w16, [x27, #42]
	strb	wzr, [x27, #80]
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x9, [x9]
	ldr	x9, [x9, #8]
	cbz	x9, LBB133_145
; %bb.6:                                ;   in Loop: Header=BB133_3 Depth=1
	ldr	x10, [x9]
	ldr	w11, [x10, #24]
	cmp	x26, x11
	b.hs	LBB133_145
; %bb.7:                                ;   in Loop: Header=BB133_3 Depth=1
	add	x11, x26, x26, lsl #3
	lsl	x16, x11, #2
	add	x11, x10, x16
	ldrh	w11, [x11, #56]
	cbz	w11, LBB133_145
; %bb.8:                                ;   in Loop: Header=BB133_3 Depth=1
	ldr	x9, [x9, #8]
	cbz	x9, LBB133_145
; %bb.9:                                ;   in Loop: Header=BB133_3 Depth=1
	add	x10, x10, x26, lsl #2
	ldr	w10, [x10, #2352]
	umaddl	x9, w10, w30, x9
	ldrb	w10, [x9]
	cbz	w10, LBB133_145
; %bb.10:                               ;   in Loop: Header=BB133_3 Depth=1
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #2]
	cbnz	w9, LBB133_145
; %bb.11:                               ;   in Loop: Header=BB133_3 Depth=1
	stp	x15, x14, [sp, #80]             ; 16-byte Folded Spill
	stp	x13, x12, [sp, #96]             ; 16-byte Folded Spill
	ldrh	w28, [x27, #8]
	cbz	w28, LBB133_90
; %bb.12:                               ;   in Loop: Header=BB133_3 Depth=1
	stp	x20, x7, [sp, #40]              ; 16-byte Folded Spill
	str	wzr, [sp, #140]                 ; 4-byte Folded Spill
	str	x24, [sp, #112]                 ; 8-byte Folded Spill
	stp	x16, x21, [sp, #64]             ; 16-byte Folded Spill
LBB133_13:                              ;   Parent Loop BB133_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB133_20 Depth 3
                                        ;         Child Loop BB133_41 Depth 4
                                        ;           Child Loop BB133_47 Depth 5
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x9, [x8, #8]
	cbz	x9, LBB133_149
; %bb.14:                               ;   in Loop: Header=BB133_13 Depth=2
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	x26, x10
	b.hs	LBB133_149
; %bb.15:                               ;   in Loop: Header=BB133_13 Depth=2
	add	x10, x8, x16
	ldrh	w10, [x10, #56]
	ldr	w11, [sp, #140]                 ; 4-byte Folded Reload
	cmp	w11, w10
	b.hs	LBB133_149
; %bb.16:                               ;   in Loop: Header=BB133_13 Depth=2
	ldr	x23, [x9, #8]
	cbz	x23, LBB133_149
; %bb.17:                               ;   in Loop: Header=BB133_13 Depth=2
	mov	x20, x28
	mov	x28, x4
	ldr	w22, [x24, x26, lsl #2]
	ldr	x21, [x25, #16]
	ldr	w9, [sp, #140]                  ; 4-byte Folded Reload
	add	w9, w22, w9
	mov	w10, #600                       ; =0x258
	umaddl	x9, w9, w10, x21
	add	x8, x8, x26, lsl #2
	ldr	w24, [x8, #2352]
	str	x9, [sp, #120]                  ; 8-byte Folded Spill
	ldrb	w0, [x9, #8]
	mov	w1, #1                          ; =0x1
	bl	_file_code_supported_mode
	cbz	w0, LBB133_149
; %bb.18:                               ;   in Loop: Header=BB133_13 Depth=2
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	add	w8, w24, w8
	mov	w30, #136                       ; =0x88
	umaddl	x5, w8, w30, x23
	ldrb	w8, [x5]
	cbz	w8, LBB133_86
; %bb.19:                               ;   in Loop: Header=BB133_13 Depth=2
	mov	x6, #0                          ; =0x0
	add	x7, x5, #8
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	add	w8, w22, w8
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x21
	add	x21, x8, #78
	ldp	x24, x1, [sp, #112]             ; 16-byte Folded Reload
	mov	x4, x28
	str	x25, [sp, #56]                  ; 8-byte Folded Spill
LBB133_20:                              ;   Parent Loop BB133_3 Depth=1
                                        ;     Parent Loop BB133_13 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB133_41 Depth 4
                                        ;           Child Loop BB133_47 Depth 5
	ldr	x28, [x7, x6, lsl #3]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldrb	w23, [x1, #8]
	cmp	w23, #152
	b.eq	LBB133_22
; %bb.21:                               ;   in Loop: Header=BB133_20 Depth=3
	cmp	w23, #60
	b.ne	LBB133_36
LBB133_22:                              ;   in Loop: Header=BB133_20 Depth=3
	ldr	x19, [x0]
	add	x8, x19, x26, lsl #2
	ldr	w8, [x8, #2352]
	ldr	w9, [sp, #140]                  ; 4-byte Folded Reload
	add	w8, w8, w9
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x20, [x9, w8, uxtw #3]
	cbz	x20, LBB133_145
; %bb.23:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrb	w8, [x28, #76]
	cmp	w8, #1
	b.ne	LBB133_145
; %bb.24:                               ;   in Loop: Header=BB133_20 Depth=3
	ldr	w8, [x28, #88]
	cmp	w8, #5
	b.ne	LBB133_145
; %bb.25:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrsh	w8, [x28, #84]
	cmn	w8, #1
	b.ne	LBB133_145
; %bb.26:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrb	w8, [x28, #78]
	tbnz	w8, #0, LBB133_145
; %bb.27:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrb	w8, [x28, #77]
	tbnz	w8, #0, LBB133_145
; %bb.28:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrb	w8, [x28, #79]
	cmp	w8, #1
	b.ne	LBB133_145
; %bb.29:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w8, [x28, #80]
	ldrh	w9, [x28, #58]
	mov	w22, #1                         ; =0x1
	cmp	w8, w9
	b.ne	LBB133_146
; %bb.30:                               ;   in Loop: Header=BB133_20 Depth=3
	cbz	w8, LBB133_146
; %bb.31:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w8, [x28, #82]
	ldrh	w9, [x28, #68]
	cmp	w8, w9
	b.ne	LBB133_146
; %bb.32:                               ;   in Loop: Header=BB133_20 Depth=3
	ldr	w8, [x28, #92]
	cmp	w8, #64
	b.ne	LBB133_145
; %bb.33:                               ;   in Loop: Header=BB133_20 Depth=3
	ldr	w8, [x28, #96]
	cmp	w8, #384
	b.ne	LBB133_145
; %bb.34:                               ;   in Loop: Header=BB133_20 Depth=3
	ldr	w25, [x19, #24]
	cbz	w25, LBB133_53
; %bb.35:                               ;   in Loop: Header=BB133_20 Depth=3
	mov	x24, #0                         ; =0x0
	add	x9, x19, #60
	stp	x9, x25, [sp]                   ; 16-byte Folded Spill
	stp	x21, x26, [sp, #24]             ; 16-byte Folded Spill
	str	x20, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB133_41
LBB133_36:                              ;   in Loop: Header=BB133_20 Depth=3
	mov	x20, x24
	mov	x24, x7
	mov	x23, x6
	mov	x22, x5
	add	x2, x28, #56
	mov	x19, x1
	bl	_file_ch_fact
	cbz	w0, LBB133_145
; %bb.37:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w4, [x27, #40]
	mov	w30, #136                       ; =0x88
	mov	x5, x22
	mov	x6, x23
	mov	x7, x24
	mov	x24, x20
	mov	x1, x19
	b	LBB133_54
LBB133_38:                              ;   in Loop: Header=BB133_41 Depth=4
	mov	w13, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
LBB133_39:                              ;   in Loop: Header=BB133_41 Depth=4
	mov	w22, #1                         ; =0x1
	stp	w22, w11, [sp, #152]
	str	d8, [sp, #160]
	str	xzr, [sp, #168]
	strh	w10, [sp, #176]
	strh	w13, [sp, #178]
	strh	w12, [sp, #180]
	strb	w9, [sp, #182]
	strb	wzr, [sp, #183]
	ldur	q0, [x8, #8]
	add	x8, sp, #152
	stur	q0, [x8, #32]
	str	xzr, [sp, #200]
	add	x0, x28, #100
	add	x1, sp, #152
	mov	x20, x4
	mov	x25, x5
	mov	x26, x19
	mov	x19, x6
	mov	x21, x7
	bl	_obligation_same
	mov	x7, x21
	mov	x6, x19
	mov	x19, x26
	ldp	x21, x26, [sp, #24]             ; 16-byte Folded Reload
	mov	x5, x25
	mov	x4, x20
	ldp	x25, x20, [sp, #8]              ; 16-byte Folded Reload
	ldr	x1, [sp, #120]                  ; 8-byte Folded Reload
	mov	w30, #136                       ; =0x88
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	cbz	w0, LBB133_146
LBB133_40:                              ;   in Loop: Header=BB133_41 Depth=4
	add	x24, x24, #1
	cmp	x24, x25
	b.eq	LBB133_85
LBB133_41:                              ;   Parent Loop BB133_3 Depth=1
                                        ;     Parent Loop BB133_13 Depth=2
                                        ;       Parent Loop BB133_20 Depth=3
                                        ; =>      This Loop Header: Depth=4
                                        ;           Child Loop BB133_47 Depth 5
	lsr	x8, x20, x24
	tbz	w8, #0, LBB133_40
; %bb.42:                               ;   in Loop: Header=BB133_41 Depth=4
	mov	w8, #36                         ; =0x24
	madd	x8, x24, x8, x9
	ldr	w11, [x1]
	ldrh	w10, [x8]
	ldrb	w9, [x8, #4]
	cbz	x10, LBB133_38
; %bb.43:                               ;   in Loop: Header=BB133_41 Depth=4
	ldr	x16, [x19]
	cbz	x16, LBB133_145
; %bb.44:                               ;   in Loop: Header=BB133_41 Depth=4
	ldr	w12, [x16, #4]
	cmp	x24, x12
	b.hs	LBB133_145
; %bb.45:                               ;   in Loop: Header=BB133_41 Depth=4
	mov	x14, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	add	x15, x24, x24, lsl #1
	lsl	x17, x15, #3
	add	x0, x16, #26
	add	x15, x16, #1816
	add	x16, x16, #1560
	ldrh	w17, [x0, x17]
	b	LBB133_47
LBB133_46:                              ;   in Loop: Header=BB133_47 Depth=5
	cmp	w2, #0
	cinc	w12, w12, ne
	lsr	x1, x1, #32
	sub	x1, x1, #1
	tst	x0, #0xff00
	ccmp	x1, #2, #2, eq
	cinc	w13, w13, lo
	add	x14, x14, #1
	cmp	x10, x14
	b.eq	LBB133_39
LBB133_47:                              ;   Parent Loop BB133_3 Depth=1
                                        ;     Parent Loop BB133_13 Depth=2
                                        ;       Parent Loop BB133_20 Depth=3
                                        ;         Parent Loop BB133_41 Depth=4
                                        ; =>        This Inner Loop Header: Depth=5
	cmp	x17, x14
	b.eq	LBB133_145
; %bb.48:                               ;   in Loop: Header=BB133_47 Depth=5
	ldr	w0, [x16, x24, lsl #2]
	add	w0, w14, w0
	add	x1, x15, w0, uxtw #4
	ldp	x0, x1, [x1]
	cmp	w23, #152
	ubfx	w2, w0, #8, #8
	cbz	w2, LBB133_51
; %bb.49:                               ;   in Loop: Header=BB133_47 Depth=5
	b.ne	LBB133_145
; %bb.50:                               ;   in Loop: Header=BB133_47 Depth=5
	ldrh	w3, [x21, x14, lsl #1]
	cmp	w3, #255
	b.ls	LBB133_46
	b	LBB133_145
LBB133_51:                              ;   in Loop: Header=BB133_47 Depth=5
	b.ne	LBB133_46
; %bb.52:                               ;   in Loop: Header=BB133_47 Depth=5
	ldrsh	w3, [x21, x14, lsl #1]
	cmn	w3, #1
	b.eq	LBB133_46
	b	LBB133_145
LBB133_53:                              ;   in Loop: Header=BB133_20 Depth=3
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
LBB133_54:                              ;   in Loop: Header=BB133_20 Depth=3
	ldr	x8, [x28, #56]
	lsr	x10, x8, #48
	and	w9, w8, #0xffff
	mov	w22, #1                         ; =0x1
	cmp	x10, #256
	ccmp	w4, w9, #0, ls
	b.ne	LBB133_146
; %bb.55:                               ;   in Loop: Header=BB133_20 Depth=3
	lsr	w9, w8, #16
	cmp	w9, #256
	b.hi	LBB133_146
; %bb.56:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w11, [x28, #64]
	cmp	w11, #256
	b.hi	LBB133_146
; %bb.57:                               ;   in Loop: Header=BB133_20 Depth=3
	ubfx	x12, x8, #32, #16
	cmp	w12, #256
	b.hi	LBB133_146
; %bb.58:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w8, [x27, #38]
	cmp	w9, w8
	b.ls	LBB133_60
; %bb.59:                               ;   in Loop: Header=BB133_20 Depth=3
	strh	w9, [x27, #38]
	mov	x8, x9
LBB133_60:                              ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w9, [x27, #46]
	cmp	x10, x9
	b.ls	LBB133_62
; %bb.61:                               ;   in Loop: Header=BB133_20 Depth=3
	strh	w10, [x27, #46]
	mov	x9, x10
LBB133_62:                              ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w10, [x27, #48]
	cmp	w11, w10
	b.ls	LBB133_64
; %bb.63:                               ;   in Loop: Header=BB133_20 Depth=3
	strh	w11, [x27, #48]
	mov	x10, x11
LBB133_64:                              ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w11, [x27, #50]
	cmp	w12, w11
	b.ls	LBB133_66
; %bb.65:                               ;   in Loop: Header=BB133_20 Depth=3
	strh	w12, [x27, #50]
	mov	x11, x12
LBB133_66:                              ;   in Loop: Header=BB133_20 Depth=3
	ldur	x12, [x28, #66]
	lsr	x13, x12, #48
	mov	w22, #1                         ; =0x1
	cmp	x13, #256
	b.hi	LBB133_146
; %bb.67:                               ;   in Loop: Header=BB133_20 Depth=3
	and	w14, w12, #0xffff
	cmp	w4, w14
	b.ne	LBB133_146
; %bb.68:                               ;   in Loop: Header=BB133_20 Depth=3
	lsr	w16, w12, #16
	cmp	w16, #256
	b.hi	LBB133_146
; %bb.69:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w14, [x28, #74]
	cmp	w14, #256
	b.hi	LBB133_146
; %bb.70:                               ;   in Loop: Header=BB133_20 Depth=3
	ubfx	x15, x12, #32, #16
	cmp	w15, #256
	b.hi	LBB133_146
; %bb.71:                               ;   in Loop: Header=BB133_20 Depth=3
	cmp	w16, w8
	b.ls	LBB133_75
; %bb.72:                               ;   in Loop: Header=BB133_20 Depth=3
	lsr	x8, x12, #16
	strh	w8, [x27, #38]
	cmp	x13, x9
	b.hi	LBB133_76
LBB133_73:                              ;   in Loop: Header=BB133_20 Depth=3
	cmp	w14, w10
	b.ls	LBB133_77
LBB133_74:                              ;   in Loop: Header=BB133_20 Depth=3
	strh	w14, [x27, #48]
	cmp	w15, w11
	b.hi	LBB133_78
	b	LBB133_79
LBB133_75:                              ;   in Loop: Header=BB133_20 Depth=3
	cmp	x13, x9
	b.ls	LBB133_73
LBB133_76:                              ;   in Loop: Header=BB133_20 Depth=3
	strh	w13, [x27, #46]
	cmp	w14, w10
	b.hi	LBB133_74
LBB133_77:                              ;   in Loop: Header=BB133_20 Depth=3
	cmp	w15, w11
	b.ls	LBB133_79
LBB133_78:                              ;   in Loop: Header=BB133_20 Depth=3
	lsr	x8, x12, #32
	strh	w8, [x27, #50]
LBB133_79:                              ;   in Loop: Header=BB133_20 Depth=3
	ldrb	w8, [x28, #79]
	cmp	w8, #1
	b.ne	LBB133_84
; %bb.80:                               ;   in Loop: Header=BB133_20 Depth=3
	ldr	w8, [x28, #100]
	cmp	w8, #1
	b.ne	LBB133_84
; %bb.81:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w8, [x28, #124]
	ldrb	w9, [x1, #8]
	cmp	w9, #60
	mov	w10, #152                       ; =0x98
	ccmp	w9, w10, #4, ne
	cinc	w8, w8, eq
	add	w8, w8, #1
	cmp	w8, #258
	b.hi	LBB133_145
; %bb.82:                               ;   in Loop: Header=BB133_20 Depth=3
	ldrh	w9, [x27, #42]
	cmp	w8, w9
	b.ls	LBB133_84
; %bb.83:                               ;   in Loop: Header=BB133_20 Depth=3
	strh	w8, [x27, #42]
LBB133_84:                              ;   in Loop: Header=BB133_20 Depth=3
	add	x6, x6, #1
	ldrb	w8, [x5]
	cmp	x6, x8
	b.lo	LBB133_20
	b	LBB133_88
LBB133_85:                              ;   in Loop: Header=BB133_20 Depth=3
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB133_54
LBB133_86:                              ;   in Loop: Header=BB133_13 Depth=2
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	mov	x4, x28
	mov	x28, x20
LBB133_87:                              ;   in Loop: Header=BB133_13 Depth=2
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	add	w8, w8, #1
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	cmp	w8, w28
	ldp	x16, x21, [sp, #64]             ; 16-byte Folded Reload
	sub	x23, x29, #176
	b.lo	LBB133_13
	b	LBB133_89
LBB133_88:                              ;   in Loop: Header=BB133_13 Depth=2
	ldrh	w28, [x27, #8]
	b	LBB133_87
LBB133_89:                              ;   in Loop: Header=BB133_3 Depth=1
	ldrh	w8, [x27, #36]
	ldp	x20, x7, [sp, #40]              ; 16-byte Folded Reload
LBB133_90:                              ;   in Loop: Header=BB133_3 Depth=1
	ldrh	w9, [x27, #38]
	cbz	w8, LBB133_92
; %bb.91:                               ;   in Loop: Header=BB133_3 Depth=1
	cmp	w8, w9
	b.lo	LBB133_145
LBB133_92:                              ;   in Loop: Header=BB133_3 Depth=1
	mov	w10, w4
	ldrh	w11, [x27, #42]
	add	x8, x10, x11
	add	x8, x9, x8
	stp	x8, x8, [x27, #64]
	cbz	w28, LBB133_120
; %bb.93:                               ;   in Loop: Header=BB133_3 Depth=1
	mov	w9, #0                          ; =0x0
	ldr	x12, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x12, [x12]
	ldr	x12, [x12, #8]
	add	x11, x11, x10
	ldp	x10, x13, [x12]
	add	x10, x10, x26, lsl #2
	ldr	w14, [x10, #2352]
	mov	x10, x8
	mov	x12, x8
	b	LBB133_95
LBB133_94:                              ;   in Loop: Header=BB133_95 Depth=2
	add	w9, w9, #1
	cmp	w9, w28
	b.eq	LBB133_121
LBB133_95:                              ;   Parent Loop BB133_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB133_98 Depth 3
                                        ;         Child Loop BB133_112 Depth 4
	add	w15, w14, w9
	umaddl	x17, w15, w30, x13
	ldrb	w15, [x17], #8
	cbz	x15, LBB133_94
; %bb.96:                               ;   in Loop: Header=BB133_95 Depth=2
	mov	x16, #0                         ; =0x0
	b	LBB133_98
LBB133_97:                              ;   in Loop: Header=BB133_98 Depth=3
	add	x16, x16, #1
	cmp	x16, x15
	b.eq	LBB133_94
LBB133_98:                              ;   Parent Loop BB133_3 Depth=1
                                        ;     Parent Loop BB133_95 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB133_112 Depth 4
	ldr	x1, [x17, x16, lsl #3]
	ldrb	w0, [x1, #79]
	cmp	w0, #1
	b.ne	LBB133_97
; %bb.99:                               ;   in Loop: Header=BB133_98 Depth=3
	ldr	w0, [x1, #100]
	cmp	w0, #1
	b.ne	LBB133_97
; %bb.100:                              ;   in Loop: Header=BB133_98 Depth=3
	ldr	x2, [x25, #16]
	ldr	w0, [x24, x26, lsl #2]
	add	w0, w0, w9
	mov	w3, #600                        ; =0x258
	umaddl	x2, w0, w3, x2
	ldrb	w3, [x2, #8]
	cmp	w3, #60
	cset	w2, eq
	cmp	w3, #152
	csinc	w2, w2, wzr, ne
	cmp	w3, #60
	b.eq	LBB133_102
; %bb.101:                              ;   in Loop: Header=BB133_98 Depth=3
	cmp	w3, #152
	b.ne	LBB133_105
LBB133_102:                             ;   in Loop: Header=BB133_98 Depth=3
	ldr	x3, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x0, [x3, w0, uxtw #3]
	cbz	x0, LBB133_145
; %bb.103:                              ;   in Loop: Header=BB133_98 Depth=3
	ldrh	w3, [x1, #128]
	ldrh	w4, [x1, #124]
	cmp	w3, w4
	b.hi	LBB133_145
; %bb.104:                              ;   in Loop: Header=BB133_98 Depth=3
	ldr	w5, [x1, #108]
	cmn	w5, #1
	b.eq	LBB133_108
	b	LBB133_145
LBB133_105:                             ;   in Loop: Header=BB133_98 Depth=3
	ldr	w0, [x1, #108]
	ldr	w3, [x25, #24]
	mov	w22, #1                         ; =0x1
	cmp	w0, w3
	b.hs	LBB133_146
; %bb.106:                              ;   in Loop: Header=BB133_98 Depth=3
	ldrh	w3, [x1, #128]
	ldrh	w4, [x1, #124]
	cmp	w3, w4
	b.hi	LBB133_146
; %bb.107:                              ;   in Loop: Header=BB133_98 Depth=3
	lsl	x0, x22, x0
LBB133_108:                             ;   in Loop: Header=BB133_98 Depth=3
	sub	w3, w4, w3
	add	w3, w3, w2
	ldrh	w4, [x1, #80]
	cmp	w3, w4
	b.hi	LBB133_145
; %bb.109:                              ;   in Loop: Header=BB133_98 Depth=3
	ldr	w1, [x25, #24]
	cbz	w1, LBB133_97
; %bb.110:                              ;   in Loop: Header=BB133_98 Depth=3
	mov	x2, #0                          ; =0x0
	add	x4, x11, x4
	sub	x3, x4, w3, uxtw
	mov	x4, x21
	b	LBB133_112
LBB133_111:                             ;   in Loop: Header=BB133_112 Depth=4
	add	x2, x2, #1
	add	x4, x4, #88
	cmp	x1, x2
	b.eq	LBB133_97
LBB133_112:                             ;   Parent Loop BB133_3 Depth=1
                                        ;     Parent Loop BB133_95 Depth=2
                                        ;       Parent Loop BB133_98 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	lsr	x5, x0, x2
	tbz	w5, #0, LBB133_111
; %bb.113:                              ;   in Loop: Header=BB133_112 Depth=4
	ldrb	w5, [x23, x2]
	cmp	w5, #1
	b.ne	LBB133_145
; %bb.114:                              ;   in Loop: Header=BB133_112 Depth=4
	ldp	x6, x5, [x4, #-8]
	add	x6, x3, x6
	cmp	x6, x12
	b.ls	LBB133_116
; %bb.115:                              ;   in Loop: Header=BB133_112 Depth=4
	str	x6, [x27, #64]
	mov	x12, x6
LBB133_116:                             ;   in Loop: Header=BB133_112 Depth=4
	add	x5, x5, x8
	cmp	x5, x10
	b.ls	LBB133_118
; %bb.117:                              ;   in Loop: Header=BB133_112 Depth=4
	str	x5, [x27, #72]
	mov	x10, x5
LBB133_118:                             ;   in Loop: Header=BB133_112 Depth=4
	ldurh	w5, [x4, #-28]
	ldrh	w6, [x27, #44]
	cmp	w5, w6
	b.lo	LBB133_111
; %bb.119:                              ;   in Loop: Header=BB133_112 Depth=4
	add	w5, w5, #1
	strh	w5, [x27, #44]
	b	LBB133_111
LBB133_120:                             ;   in Loop: Header=BB133_3 Depth=1
	mov	x10, x8
	mov	x12, x8
LBB133_121:                             ;   in Loop: Header=BB133_3 Depth=1
	ldrh	w8, [x27, #44]
	lsl	w9, w8, #8
	stp	w9, w9, [x27, #52]
	cmp	w8, #64
	mov	w8, #49280                      ; =0xc080
	ccmp	x12, x8, #2, ls
	ccmp	x10, x8, #2, ls
	b.hi	LBB133_150
; %bb.122:                              ;   in Loop: Header=BB133_3 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, x26]
	ldp	x13, x12, [sp, #96]             ; 16-byte Folded Reload
	add	x12, x12, #1
	ldr	w8, [x25, #24]
	cmp	x12, x8
	ldp	x15, x14, [sp, #80]             ; 16-byte Folded Reload
	mov	w10, #88                        ; =0x58
	mov	w11, #36                        ; =0x24
	mov	w16, #65537                     ; =0x10001
	b.lo	LBB133_3
LBB133_123:
	ldp	w10, w8, [x7, #20]
	mov	w9, #32880                      ; =0x8070
	ldr	x11, [sp, #144]                 ; 8-byte Folded Reload
	add	x9, x11, x9
	cmn	w10, #1
	b.eq	LBB133_134
; %bb.124:
	mov	w11, #88                        ; =0x58
	umaddl	x10, w10, w11, x9
	ldr	x11, [x10, #64]
	ldr	x12, [x7, #40]
	cmp	x11, x12
	b.ls	LBB133_126
; %bb.125:
	str	x11, [x7, #40]
LBB133_126:
	ldr	x11, [x10, #72]
	ldr	x12, [x7, #48]
	cmp	x11, x12
	b.ls	LBB133_128
; %bb.127:
	str	x11, [x7, #48]
LBB133_128:
	ldrh	w11, [x10, #44]
	ldrh	w12, [x7, #56]
	cmp	w11, w12
	b.ls	LBB133_130
; %bb.129:
	strh	w11, [x7, #56]
LBB133_130:
	ldr	w11, [x10, #52]
	ldr	w12, [x7, #60]
	cmp	w11, w12
	b.ls	LBB133_132
; %bb.131:
	str	w11, [x7, #60]
LBB133_132:
	ldr	w10, [x10, #56]
	ldr	w11, [x7, #64]
	cmp	w10, w11
	b.ls	LBB133_134
; %bb.133:
	str	w10, [x7, #64]
LBB133_134:
	cmn	w8, #1
	b.eq	LBB133_148
; %bb.135:
	mov	w10, #88                        ; =0x58
	umaddl	x8, w8, w10, x9
	ldr	x9, [x8, #64]
	ldr	x10, [x7, #40]
	cmp	x9, x10
	b.ls	LBB133_137
; %bb.136:
	str	x9, [x7, #40]
LBB133_137:
	ldr	x9, [x8, #72]
	ldr	x10, [x7, #48]
	cmp	x9, x10
	b.ls	LBB133_139
; %bb.138:
	str	x9, [x7, #48]
LBB133_139:
	ldrh	w9, [x8, #44]
	ldrh	w10, [x7, #56]
	cmp	w9, w10
	b.ls	LBB133_141
; %bb.140:
	strh	w9, [x7, #56]
LBB133_141:
	ldr	w9, [x8, #52]
	ldr	w10, [x7, #60]
	cmp	w9, w10
	b.ls	LBB133_143
; %bb.142:
	str	w9, [x7, #60]
LBB133_143:
	ldr	w8, [x8, #56]
	ldr	w9, [x7, #64]
	cmp	w8, w9
	b.ls	LBB133_148
; %bb.144:
	mov	w22, #0                         ; =0x0
	str	w8, [x7, #64]
	b	LBB133_146
LBB133_145:
	mov	w22, #1                         ; =0x1
LBB133_146:
	ldur	x8, [x29, #-112]
Lloh118:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh119:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh120:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB133_151
; %bb.147:
	mov	x0, x22
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #368]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #352]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #336]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #288]              ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
LBB133_148:
	mov	w22, #0                         ; =0x0
	b	LBB133_146
LBB133_149:
	mov	w22, #2                         ; =0x2
	b	LBB133_146
LBB133_150:
	mov	w22, #3                         ; =0x3
	b	LBB133_146
LBB133_151:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh113, Lloh114, Lloh115
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdrGotLdr	Lloh118, Lloh119, Lloh120
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_query_summary ; -- Begin function nvm_file_indirect_hosted_query_summary
	.globl	_nvm_file_indirect_hosted_query_summary
	.p2align	2
_nvm_file_indirect_hosted_query_summary: ; @nvm_file_indirect_hosted_query_summary
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB134_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB134_4
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB134_4
; %bb.3:
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [x1]
	ldp	q0, q1, [x8, #48]
	ldr	q2, [x8, #80]
	ldr	x8, [x8, #96]
	str	x8, [x1, #80]
	stp	q1, q2, [x1, #48]
	str	q0, [x1, #32]
	mov	w0, #1                          ; =0x1
LBB134_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_startup ; -- Begin function nvm_file_indirect_hosted_startup
	.globl	_nvm_file_indirect_hosted_startup
	.p2align	2
_nvm_file_indirect_hosted_startup:      ; @nvm_file_indirect_hosted_startup
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB135_2
; %bb.1:
	ldr	q0, [x8, #32784]
	ldr	q1, [x8, #32800]
	stp	q0, q1, [x1]
	ldr	q0, [x8, #32816]
	ldr	q1, [x8, #32832]
	ldr	q2, [x8, #32848]
	ldr	q3, [x8, #32864]
	stp	q2, q3, [x1, #64]
	stp	q0, q1, [x1, #32]
LBB135_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_function ; -- Begin function nvm_file_indirect_hosted_function
	.globl	_nvm_file_indirect_hosted_function
	.p2align	2
_nvm_file_indirect_hosted_function:     ; @nvm_file_indirect_hosted_function
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB136_4
; %bb.1:
	cbz	x2, LBB136_4
; %bb.2:
	mov	w8, #32796                      ; =0x801c
	ldr	w8, [x0, x8]
	cmp	w1, w8
	b.hs	LBB136_5
; %bb.3:
	mov	w8, #88                         ; =0x58
	umaddl	x8, w1, w8, x0
	mov	w9, #32880                      ; =0x8070
	add	x9, x8, x9
	ldr	q0, [x8, #32880]
	ldr	q1, [x8, #32896]
	stp	q0, q1, [x2]
	ldr	q0, [x8, #32912]
	ldr	q1, [x8, #32928]
	ldr	q2, [x8, #32944]
	ldr	x8, [x9, #80]
	str	x8, [x2, #80]
	stp	q1, q2, [x2, #48]
	str	q0, [x2, #32]
	mov	w8, #1                          ; =0x1
LBB136_4:
	mov	x0, x8
	ret
LBB136_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_function_order ; -- Begin function nvm_file_indirect_hosted_function_order
	.globl	_nvm_file_indirect_hosted_function_order
	.p2align	2
_nvm_file_indirect_hosted_function_order: ; @nvm_file_indirect_hosted_function_order
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB137_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB137_5
; %bb.2:
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	cbz	x8, LBB137_5
; %bb.3:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB137_6
; %bb.4:
	add	x8, x8, w1, uxtw #2
	ldr	w8, [x8, #2608]
	str	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB137_5:
	ret
LBB137_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_local ; -- Begin function nvm_file_indirect_hosted_local
	.globl	_nvm_file_indirect_hosted_local
	.p2align	2
_nvm_file_indirect_hosted_local:        ; @nvm_file_indirect_hosted_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB138_10
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB138_9
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB138_9
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB138_9
; %bb.4:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB138_10
; %bb.5:
	ldr	x8, [x8]
	cbz	x8, LBB138_10
; %bb.6:
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB138_9
; %bb.7:
	mov	w9, #24                         ; =0x18
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #26]
	cmp	w2, w9
	b.hs	LBB138_9
; %bb.8:
	mov	w9, w1
	add	x9, x8, x9, lsl #2
	ldr	w9, [x9, #1560]
	add	w9, w9, w2
	add	x8, x8, w9, uxtw #4
	add	x8, x8, #1816
	ldr	q0, [x8]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB138_9:
	mov	w0, #0                          ; =0x0
LBB138_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_instruction ; -- Begin function nvm_file_indirect_hosted_instruction
	.globl	_nvm_file_indirect_hosted_instruction
	.p2align	2
_nvm_file_indirect_hosted_instruction:  ; @nvm_file_indirect_hosted_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB139_8
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB139_9
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB139_9
; %bb.3:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB139_8
; %bb.4:
	ldr	x8, [x8]
	cbz	x8, LBB139_8
; %bb.5:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB139_9
; %bb.6:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #56]
	cmp	w2, w9
	b.hs	LBB139_9
; %bb.7:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, w1
	ldr	x10, [x8, #16]
	add	x8, x8, x9, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x0, x3
	mov	w2, #600                        ; =0x258
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB139_8:
	ret
LBB139_9:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_component ; -- Begin function nvm_file_indirect_hosted_component
	.globl	_nvm_file_indirect_hosted_component
	.p2align	2
_nvm_file_indirect_hosted_component:    ; @nvm_file_indirect_hosted_component
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB140_9
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB140_8
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB140_8
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB140_8
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB140_8
; %bb.5:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB140_9
; %bb.6:
	ldr	x9, [x9, #8]
	cbz	x9, LBB140_9
; %bb.7:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrh	w8, [x8, #2]
	strh	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB140_8:
	mov	w0, #0                          ; =0x0
LBB140_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_variant_count ; -- Begin function nvm_file_indirect_hosted_variant_count
	.globl	_nvm_file_indirect_hosted_variant_count
	.p2align	2
_nvm_file_indirect_hosted_variant_count: ; @nvm_file_indirect_hosted_variant_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB141_9
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB141_8
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB141_8
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB141_8
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB141_8
; %bb.5:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB141_9
; %bb.6:
	ldr	x9, [x9, #8]
	cbz	x9, LBB141_9
; %bb.7:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB141_8:
	mov	w0, #0                          ; =0x0
LBB141_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_variant ; -- Begin function nvm_file_indirect_hosted_variant
	.globl	_nvm_file_indirect_hosted_variant
	.p2align	2
_nvm_file_indirect_hosted_variant:      ; @nvm_file_indirect_hosted_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB142_11
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB142_10
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB142_10
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB142_10
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB142_10
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB142_10
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB142_10
; %bb.7:
	mov	w0, #0                          ; =0x0
	cbz	x4, LBB142_11
; %bb.8:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB142_11
; %bb.9:
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	stp	q1, q2, [x4, #16]
	str	q0, [x4]
	ldur	q0, [x8, #104]
	ldur	q1, [x8, #120]
	ldur	q2, [x8, #136]
	ldr	x8, [x8, #152]
	str	x8, [x4, #96]
	stp	q1, q2, [x4, #64]
	str	q0, [x4, #48]
	mov	w0, #1                          ; =0x1
	ret
LBB142_10:
	mov	w0, #0                          ; =0x0
LBB142_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_input_local ; -- Begin function nvm_file_indirect_hosted_input_local
	.globl	_nvm_file_indirect_hosted_input_local
	.p2align	2
_nvm_file_indirect_hosted_input_local:  ; @nvm_file_indirect_hosted_input_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB143_12
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB143_11
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB143_11
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB143_11
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB143_11
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB143_11
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB143_11
; %bb.7:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB143_12
; %bb.8:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB143_12
; %bb.9:
	ldrh	w9, [x8]
	cmp	w4, w9
	b.hs	LBB143_11
; %bb.10:
	ldr	x8, [x8, #16]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB143_11:
	mov	w0, #0                          ; =0x0
LBB143_12:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_input_stack ; -- Begin function nvm_file_indirect_hosted_input_stack
	.globl	_nvm_file_indirect_hosted_input_stack
	.p2align	2
_nvm_file_indirect_hosted_input_stack:  ; @nvm_file_indirect_hosted_input_stack
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB144_12
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB144_11
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB144_11
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB144_11
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB144_11
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB144_11
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB144_11
; %bb.7:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB144_12
; %bb.8:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB144_12
; %bb.9:
	ldrh	w9, [x8, #2]
	cmp	w4, w9
	b.hs	LBB144_11
; %bb.10:
	ldr	x8, [x8, #24]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	stp	q0, q1, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB144_11:
	mov	w0, #0                          ; =0x0
LBB144_12:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_input_reference ; -- Begin function nvm_file_indirect_hosted_input_reference
	.globl	_nvm_file_indirect_hosted_input_reference
	.p2align	2
_nvm_file_indirect_hosted_input_reference: ; @nvm_file_indirect_hosted_input_reference
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB145_13
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB145_12
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB145_12
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB145_12
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB145_12
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB145_12
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB145_12
; %bb.7:
	mov	w0, #0                          ; =0x0
	cmp	w4, #255
	b.hi	LBB145_13
; %bb.8:
	cbz	x5, LBB145_13
; %bb.9:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB145_13
; %bb.10:
	ldrh	w9, [x8, #48]
	cmp	w4, w9
	b.hs	LBB145_14
; %bb.11:
	ldr	x8, [x8, #32]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w4, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x5, #32]
	str	q1, [x5, #16]
	b	LBB145_15
LBB145_12:
	mov	w0, #0                          ; =0x0
LBB145_13:
	ret
LBB145_14:
	str	xzr, [x5, #32]
	movi.2d	v0, #0000000000000000
	str	q0, [x5, #16]
LBB145_15:
	str	q0, [x5]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_input_region ; -- Begin function nvm_file_indirect_hosted_input_region
	.globl	_nvm_file_indirect_hosted_input_region
	.p2align	2
_nvm_file_indirect_hosted_input_region: ; @nvm_file_indirect_hosted_input_region
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB146_12
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB146_11
; %bb.2:
	ldr	x9, [x8, #8]
	cbz	x9, LBB146_11
; %bb.3:
	ldr	x8, [x9]
	ldr	w10, [x8, #24]
	cmp	w1, w10
	b.hs	LBB146_11
; %bb.4:
	mov	w10, #36                        ; =0x24
	umaddl	x10, w1, w10, x8
	ldrh	w10, [x10, #56]
	cmp	w2, w10
	b.hs	LBB146_11
; %bb.5:
	ldr	x9, [x9, #8]
	cbz	x9, LBB146_11
; %bb.6:
	mov	w10, w1
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #2352]
	add	w8, w8, w2
	mov	w10, #136                       ; =0x88
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w3, w9
	b.hs	LBB146_11
; %bb.7:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB146_12
; %bb.8:
	add	x8, x8, w3, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB146_12
; %bb.9:
	ldrh	w9, [x8, #4]
	cmp	w4, w9
	b.hs	LBB146_11
; %bb.10:
	ldr	x8, [x8, #40]
	ldr	x8, [x8, w4, uxtw #3]
	str	x8, [x5]
	mov	w0, #1                          ; =0x1
	ret
LBB146_11:
	mov	w0, #0                          ; =0x0
LBB146_12:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_type ; -- Begin function nvm_file_indirect_hosted_type
	.globl	_nvm_file_indirect_hosted_type
	.p2align	2
_nvm_file_indirect_hosted_type:         ; @nvm_file_indirect_hosted_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB147_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB147_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB147_4
; %bb.3:
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_type
LBB147_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_import ; -- Begin function nvm_file_indirect_hosted_import
	.globl	_nvm_file_indirect_hosted_import
	.p2align	2
_nvm_file_indirect_hosted_import:       ; @nvm_file_indirect_hosted_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB148_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB148_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB148_4
; %bb.3:
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	b	_nvm_file_nominal_import
LBB148_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_bytes ; -- Begin function nvm_file_indirect_hosted_bytes
	.globl	_nvm_file_indirect_hosted_bytes
	.p2align	2
_nvm_file_indirect_hosted_bytes:        ; @nvm_file_indirect_hosted_bytes
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB149_7
; %bb.1:
	cbnz	x2, LBB149_4
; %bb.2:
	cbz	x3, LBB149_4
; %bb.3:
	mov	w0, #0                          ; =0x0
	ret
LBB149_4:
	add	x8, x0, #8, lsl #12             ; =32768
	ldr	x9, [x8, #72]
	subs	x9, x9, x1
	ccmp	x3, x9, #2, hs
	cset	w9, hi
	eor	w0, w9, #0x1
	cbz	x3, LBB149_7
; %bb.5:
	tbnz	w9, #0, LBB149_7
; %bb.6:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x8, #8]
	add	x1, x8, x1
	mov	x0, x2
	mov	x2, x3
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB149_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_call ; -- Begin function nvm_file_indirect_hosted_call
	.globl	_nvm_file_indirect_hosted_call
	.p2align	2
_nvm_file_indirect_hosted_call:         ; @nvm_file_indirect_hosted_call
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB150_11
; %bb.1:
	cbz	x4, LBB150_11
; %bb.2:
	mov	w8, #32796                      ; =0x801c
	ldr	w8, [x0, x8]
	cmp	w1, w8
	b.hs	LBB150_12
; %bb.3:
	mov	w8, #88                         ; =0x58
	umaddl	x8, w1, w8, x0
	mov	w9, #32888                      ; =0x8078
	ldrh	w8, [x8, x9]
	cmp	w2, w8
	b.hs	LBB150_12
; %bb.4:
	mov	w12, w1
	ldr	x8, [x0]
	ldr	x11, [x8, #8]
	ldr	x10, [x11]
	add	x8, x10, x12, lsl #2
	ldr	w8, [x8, #2352]
	add	w9, w8, w2
	add	x8, x0, w9, uxtw #3
	ldr	x8, [x8, #8]
	cbz	x8, LBB150_11
; %bb.5:
	ldr	w13, [x10, #24]
	cmp	w1, w13
	b.hs	LBB150_12
; %bb.6:
	mov	w13, #36                        ; =0x24
	umaddl	x12, w12, w13, x10
	ldrh	w12, [x12, #56]
	cmp	w2, w12
	b.hs	LBB150_12
; %bb.7:
	ldr	x11, [x11, #8]
	cbz	x11, LBB150_12
; %bb.8:
	mov	w12, #136                       ; =0x88
	umaddl	x11, w9, w12, x11
	ldrb	w12, [x11]
	cmp	w3, w12
	b.hs	LBB150_12
; %bb.9:
	add	x11, x11, w3, uxtw #3
	ldr	x11, [x11, #8]
	cbz	x11, LBB150_12
; %bb.10:
	ldr	x10, [x10, #16]
	mov	w12, #600                       ; =0x258
	umull	x9, w9, w12
	ldr	w9, [x10, x9]
	ldur	q0, [x11, #100]
	ldur	q1, [x11, #116]
	stp	q0, q1, [sp, #-64]!
	.cfi_def_cfa_offset 64
	ldur	q2, [x11, #132]
	str	q2, [sp, #32]
	ldur	x10, [x11, #148]
	str	x10, [sp, #48]
	stp	w1, w9, [x4]
	stp	x8, x8, [x4, #8]
	stur	q0, [x4, #24]
	stur	q1, [x4, #40]
	stur	q2, [x4, #56]
	str	x10, [x4, #72]
	mov	w8, #1                          ; =0x1
	add	sp, sp, #64
LBB150_11:
	mov	x0, x8
	ret
LBB150_12:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_indirect_hosted_string ; -- Begin function nvm_file_indirect_hosted_string
	.globl	_nvm_file_indirect_hosted_string
	.p2align	2
_nvm_file_indirect_hosted_string:       ; @nvm_file_indirect_hosted_string
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB151_18
; %bb.1:
	cbz	x2, LBB151_18
; %bb.2:
	cbz	x3, LBB151_18
; %bb.3:
	sub	sp, sp, #192
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x21, x2
	mov	x20, x3
	add	x23, x8, #8, lsl #12            ; =32768
	ldr	x0, [x23, #8]
	ldr	x1, [x23, #72]
	add	x2, sp, #80
	bl	_nvm_v2_read_header
	cbz	w0, LBB151_5
; %bb.4:
	mov	w0, #0                          ; =0x0
	b	LBB151_17
LBB151_5:
	ldr	w8, [sp, #108]
	cbz	w8, LBB151_10
; %bb.6:
	mov	w19, #0                         ; =0x0
LBB151_7:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x23, #8]
	ldr	x1, [x23, #72]
	add	x2, sp, #80
	add	x4, sp, #56
	mov	x3, x19
	bl	_nvm_v2_read_section
	cbnz	w0, LBB151_14
; %bb.8:                                ;   in Loop: Header=BB151_7 Depth=1
	ldr	w8, [sp, #56]
	cmp	w8, #2
	b.eq	LBB151_11
; %bb.9:                                ;   in Loop: Header=BB151_7 Depth=1
	add	w19, w19, #1
	ldr	w8, [sp, #108]
	cmp	w19, w8
	b.lo	LBB151_7
LBB151_10:
	mov	w9, #0                          ; =0x0
                                        ; implicit-def: $w8
	b	LBB151_16
LBB151_11:
	ldr	x8, [x23, #8]
	ldp	x9, x2, [sp, #64]
	add	x0, sp, #32
	add	x1, x8, x9
	bl	_nvm_v2_cursor_init
	add	x0, sp, #32
	add	x1, sp, #28
	bl	_nvm_v2_u32
	mov	w8, #0                          ; =0x0
	cbnz	w0, LBB151_15
; %bb.12:
	ldr	w9, [sp, #28]
	cmp	w22, w9
	b.hs	LBB151_15
; %bb.13:
	add	x0, sp, #32
	add	x1, sp, #27
	bl	_nvm_v2_u8
	cbz	w0, LBB151_19
LBB151_14:
	mov	w8, #0                          ; =0x0
LBB151_15:
	mov	w9, #1                          ; =0x1
LBB151_16:
	and	w0, w9, w8
LBB151_17:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #192
LBB151_18:
	ret
LBB151_19:
	add	w19, w22, #1
LBB151_20:                              ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #32
	add	x1, sp, #26
	bl	_nvm_v2_u8
	cbnz	w0, LBB151_14
; %bb.21:                               ;   in Loop: Header=BB151_20 Depth=1
	add	x0, sp, #32
	add	x1, sp, #24
	bl	_nvm_v2_u16
	cbnz	w0, LBB151_14
; %bb.22:                               ;   in Loop: Header=BB151_20 Depth=1
	add	x0, sp, #32
	add	x1, sp, #20
	bl	_nvm_v2_u32
	mov	w8, #0                          ; =0x0
	cbnz	w0, LBB151_15
; %bb.23:                               ;   in Loop: Header=BB151_20 Depth=1
	ldrb	w9, [sp, #27]
	cmp	w9, #5
	b.ne	LBB151_15
; %bb.24:                               ;   in Loop: Header=BB151_20 Depth=1
	ldrb	w9, [sp, #26]
	cbnz	w9, LBB151_15
; %bb.25:                               ;   in Loop: Header=BB151_20 Depth=1
	ldrh	w9, [sp, #24]
	cbnz	w9, LBB151_15
; %bb.26:                               ;   in Loop: Header=BB151_20 Depth=1
	ldr	w1, [sp, #20]
	add	x0, sp, #32
	add	x2, sp, #8
	bl	_nvm_v2_take
	cbnz	w0, LBB151_14
; %bb.27:                               ;   in Loop: Header=BB151_20 Depth=1
	add	x0, sp, #32
	bl	_nvm_v2_align4
	cbnz	w0, LBB151_14
; %bb.28:                               ;   in Loop: Header=BB151_20 Depth=1
	subs	w19, w19, #1
	b.eq	LBB151_30
; %bb.29:                               ;   in Loop: Header=BB151_20 Depth=1
	add	x0, sp, #32
	add	x1, sp, #27
	bl	_nvm_v2_u8
	cbz	w0, LBB151_20
	b	LBB151_14
LBB151_30:
	ldr	x8, [sp, #8]
	str	x8, [x21]
	ldr	w8, [sp, #20]
	str	x8, [x20]
	mov	w8, #1                          ; =0x1
	b	LBB151_15
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_declaration
_read_declaration:                      ; @read_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x3
	mov	x19, x2
	mov	x22, x1
	mov	x20, x0
	add	x1, sp, #31
	bl	_nvm_v2_u8
	cbnz	w0, LBB152_3
; %bb.1:
	add	x1, sp, #30
	mov	x0, x20
	bl	_nvm_v2_u8
	cbnz	w0, LBB152_3
; %bb.2:
	add	x1, sp, #28
	mov	x0, x20
	bl	_nvm_v2_u16
	cbz	w0, LBB152_5
LBB152_3:
	mov	w0, #1                          ; =0x1
LBB152_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB152_5:
	add	x1, sp, #24
	mov	x0, x20
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB152_4
; %bb.6:
	ldrh	w8, [sp, #28]
	cbnz	w8, LBB152_4
; %bb.7:
	ldrb	w23, [sp, #31]
	ldrb	w24, [sp, #30]
	ldr	w20, [sp, #24]
	cmn	w20, #1
	b.eq	LBB152_15
; %bb.8:
	add	x2, sp, #4
	mov	x0, x22
	mov	x1, x20
	bl	_nvm_file_nominal_layout
	cbz	w0, LBB152_3
; %bb.9:
	ldr	w8, [sp, #20]
	cbz	w8, LBB152_18
; %bb.10:
	ldr	w9, [sp, #8]
	ldrb	w10, [sp, #30]
	cbz	w10, LBB152_13
; %bb.11:
	mov	w0, #1                          ; =0x1
	cmp	w8, #1
	b.ne	LBB152_4
; %bb.12:
	sub	w10, w10, #3
	cmn	w10, #3
	b.ls	LBB152_4
LBB152_13:
	ldrb	w10, [sp, #31]
	ldrb	w11, [sp, #16]
	mov	w12, #10                        ; =0xa
	mov	w13, #8                         ; =0x8
	cmp	w11, #0
	csel	w11, w13, w12, eq
	cmp	w11, w10
	b.ne	LBB152_3
; %bb.14:
	orr	x8, x9, x8, lsl #32
	b	LBB152_19
LBB152_15:
	cbnz	w24, LBB152_18
; %bb.16:
	mov	w10, #250                       ; =0xfa
	cmp	w23, #11
	csel	w9, wzr, w21, ne
	mov	w8, #-1                         ; =0xffffffff
	and	w10, w23, w10
	cbz	w10, LBB152_19
; %bb.17:
	tbnz	w9, #0, LBB152_19
LBB152_18:
	mov	w0, #2                          ; =0x2
	b	LBB152_4
LBB152_19:
	mov	w0, #0                          ; =0x0
	orr	x9, x23, x24, lsl #8
	orr	x9, x9, x20, lsl #32
	stp	x9, x8, [x19]
	b	LBB152_4
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function file_body_transfer
lCPI153_0:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI153_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI153_2:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
lCPI153_3:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_file_body_transfer:                    ; @file_body_transfer
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
Lloh121:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh122:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh123:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	mov	x10, x2
	ldrh	w8, [x10, #16]!
	ldurb	w11, [x10, #-8]
	cmp	w11, #255
	b.eq	LBB153_130
; %bb.1:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
Lloh124:
	adrp	x12, lJTI153_0@PAGE
Lloh125:
	add	x12, x12, lJTI153_0@PAGEOFF
	adr	x13, LBB153_2
	ldrh	w14, [x12, x11, lsl #1]
	add	x13, x13, x14, lsl #2
	br	x13
LBB153_2:
	ldrh	w10, [x1, #12]
	subs	w8, w10, #2
	b.lo	LBB153_13
; %bb.3:
	mov	w9, #24624                      ; =0x6030
	add	x9, x1, x9
	and	x11, x8, #0xffff
	mov	w8, #40                         ; =0x28
	umaddl	x8, w11, w8, x9
	ldrb	w12, [x8, #16]
	mov	w0, #1                          ; =0x1
	tbz	w12, #0, LBB153_131
; %bb.4:
	ldr	x12, [x8, #24]
	cbnz	x12, LBB153_131
; %bb.5:
	ldr	x12, [x8]
	mov	x13, #-4294967296               ; =0xffffffff00000000
	bfxil	x13, x12, #0, #8
	eor	x13, x13, x12
	tst	x13, #0xff
	b.ne	LBB153_131
; %bb.6:
	and	x14, x12, #0xff
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	ldr	x15, [x8, #8]
	and	x13, x13, x12
	cmp	x14, #1
	ccmp	x13, #0, #0, eq
	mov	w13, #-1                        ; =0xffffffff
	ccmp	x15, x13, #0, eq
	b.ne	LBB153_131
; %bb.7:
	mov	w13, #40                        ; =0x28
	umaddl	x11, w11, w13, x9
	ldrb	w13, [x11, #56]
	tbz	w13, #0, LBB153_131
; %bb.8:
	ldr	x13, [x11, #64]
	cbnz	x13, LBB153_131
; %bb.9:
	ldur	x13, [x11, #40]
	mov	x14, #-4294967296               ; =0xffffffff00000000
	bfxil	x14, x13, #0, #8
	eor	x14, x14, x13
	tst	x14, #0xff
	b.ne	LBB153_131
; %bb.10:
	and	x13, x13, #0xff
	ldur	x11, [x11, #48]
	and	x12, x14, x12
	cmp	x13, #1
	ccmp	x12, #0, #0, eq
	mov	w12, #-1                        ; =0xffffffff
	ccmp	x11, x12, #0, eq
	b.ne	LBB153_131
; %bb.11:
	sub	w10, w10, #1
	and	x11, x10, #0xffff
	mov	w12, #40                        ; =0x28
	umaddl	x9, w11, w12, x9
	str	xzr, [x9, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	strh	w10, [x1, #12]
	b	LBB153_54
LBB153_12:
	ldrh	w10, [x1, #12]
	subs	w8, w10, #2
	b.hs	LBB153_14
LBB153_13:
	mov	w0, #1                          ; =0x1
	b	LBB153_131
LBB153_14:
	mov	w9, #24624                      ; =0x6030
	add	x9, x1, x9
	and	x11, x8, #0xffff
	mov	w8, #40                         ; =0x28
	umaddl	x8, w11, w8, x9
	ldrb	w12, [x8, #16]
	mov	w0, #1                          ; =0x1
	tbz	w12, #0, LBB153_131
; %bb.15:
	ldr	x12, [x8, #24]
	cbnz	x12, LBB153_131
; %bb.16:
	ldr	x12, [x8]
	mov	x13, #-4294967296               ; =0xffffffff00000000
	bfxil	x13, x12, #0, #8
	eor	x13, x13, x12
	tst	x13, #0xff
	b.ne	LBB153_131
; %bb.17:
	and	x14, x12, #0xff
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	ldr	x15, [x8, #8]
	and	x13, x13, x12
	cmp	x14, #1
	ccmp	x13, #0, #0, eq
	mov	w13, #-1                        ; =0xffffffff
	ccmp	x15, x13, #0, eq
	b.ne	LBB153_131
; %bb.18:
	mov	w13, #40                        ; =0x28
	umaddl	x11, w11, w13, x9
	ldrb	w13, [x11, #56]
	tbz	w13, #0, LBB153_131
; %bb.19:
	ldr	x13, [x11, #64]
	cbnz	x13, LBB153_131
; %bb.20:
	ldur	x13, [x11, #40]
	mov	x14, #-4294967296               ; =0xffffffff00000000
	bfxil	x14, x13, #0, #8
	eor	x14, x14, x13
	tst	x14, #0xff
	b.ne	LBB153_131
; %bb.21:
	and	x13, x13, #0xff
	ldur	x11, [x11, #48]
	and	x12, x14, x12
	cmp	x13, #1
LBB153_22:
	ccmp	x12, #0, #0, eq
	mov	w12, #-1                        ; =0xffffffff
	ccmp	x11, x12, #0, eq
	b.ne	LBB153_131
; %bb.23:
	sub	w10, w10, #1
	and	x11, x10, #0xffff
	mov	w12, #40                        ; =0x28
	umaddl	x9, w11, w12, x9
	str	xzr, [x9, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	strh	w10, [x1, #12]
Lloh126:
	adrp	x9, lCPI153_1@PAGE
Lloh127:
	ldr	q0, [x9, lCPI153_1@PAGEOFF]
	b	LBB153_55
LBB153_24:
	ldr	w8, [x10]
	ldr	x10, [x9]
	ldr	w11, [x10, #24]
	cmp	w8, w11
	b.hs	LBB153_130
; %bb.25:
	add	x9, x9, x8
	ldrb	w9, [x9, #16]
	cmp	w9, #1
	b.ne	LBB153_130
; %bb.26:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w8, w9, x10
	ldrh	w4, [x9, #60]
	cbz	x4, LBB153_145
; %bb.27:
	ldr	x9, [x1]
	add	x10, x9, x8, lsl #2
	ldr	w11, [x10, #1560]
	add	x9, x9, #1817
	and	x10, x4, #0x7
	cmp	w4, #8
	b.hs	LBB153_152
; %bb.28:
	mov	x12, #0                         ; =0x0
LBB153_29:
	cbz	x10, LBB153_145
; %bb.30:
	lsl	x14, x12, #1
	add	x13, sp, #8
	add	x13, x13, x14
	add	x14, x14, x2
	add	x14, x14, #78
	add	w11, w11, w12
	b	LBB153_33
LBB153_31:                              ;   in Loop: Header=BB153_33 Depth=1
	ldrh	w12, [x14]
LBB153_32:                              ;   in Loop: Header=BB153_33 Depth=1
	strh	w12, [x13], #2
	add	x14, x14, #2
	add	w11, w11, #1
	subs	x10, x10, #1
	b.eq	LBB153_145
LBB153_33:                              ; =>This Inner Loop Header: Depth=1
	ubfiz	x12, x11, #4, #32
	ldrb	w12, [x9, x12]
	cbnz	w12, LBB153_31
; %bb.34:                               ;   in Loop: Header=BB153_33 Depth=1
	mov	w12, #65535                     ; =0xffff
	b	LBB153_32
LBB153_35:
	ldrh	w10, [x1, #12]
	subs	w8, w10, #2
	b.lo	LBB153_13
; %bb.36:
	mov	w9, #24624                      ; =0x6030
	add	x9, x1, x9
	and	x12, x8, #0xffff
	mov	w8, #40                         ; =0x28
	umaddl	x8, w12, w8, x9
	ldrb	w11, [x8, #16]
	mov	w0, #1                          ; =0x1
	tbz	w11, #0, LBB153_131
; %bb.37:
	ldr	x11, [x8, #24]
	cbnz	x11, LBB153_131
; %bb.38:
	ldr	x13, [x8]
	and	w11, w13, #0xff
	orr	x14, x11, #0xffffffff00000000
	eor	x14, x14, x13
	tst	x14, #0xff
	b.ne	LBB153_131
; %bb.39:
	mov	x13, #-256                      ; =0xffffffffffffff00
	movk	x13, #0, lsl #16
	ldr	x15, [x8, #8]
	and	x14, x14, x13
	cmp	x14, #0
	mov	w14, #-1                        ; =0xffffffff
	ccmp	x15, x14, #0, eq
	b.ne	LBB153_131
; %bb.40:
	cmp	w11, #4
	ccmp	w11, #1, #4, ne
	b.ne	LBB153_130
; %bb.41:
	mov	w14, #40                        ; =0x28
	umaddl	x14, w12, w14, x9
	ldrb	w12, [x14, #56]
	tbz	w12, #0, LBB153_131
; %bb.42:
	ldr	x12, [x14, #64]
	cbnz	x12, LBB153_131
; %bb.43:
	ldur	x15, [x14, #40]
	and	w12, w15, #0xff
	orr	x16, x12, #0xffffffff00000000
	eor	x15, x16, x15
	tst	x15, #0xff
	b.ne	LBB153_131
; %bb.44:
	ldur	x14, [x14, #48]
	and	x13, x15, x13
	cmp	x13, #0
	mov	w13, #-1                        ; =0xffffffff
	ccmp	x14, x13, #0, eq
	b.ne	LBB153_131
; %bb.45:
	cmp	w12, #4
	b.eq	LBB153_47
; %bb.46:
	cmp	w12, #1
	b.ne	LBB153_130
LBB153_47:
	cmp	w11, w12
	b.ne	LBB153_130
; %bb.48:
	mov	w0, #0                          ; =0x0
	sub	w10, w10, #1
	and	x11, x10, #0xffff
	mov	w12, #40                        ; =0x28
	umaddl	x9, w11, w12, x9
	str	xzr, [x9, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	strh	w10, [x1, #12]
Lloh128:
	adrp	x9, lCPI153_1@PAGE
Lloh129:
	ldr	q0, [x9, lCPI153_1@PAGEOFF]
	b	LBB153_76
LBB153_49:
	ldrh	w8, [x1, #12]
	cbz	w8, LBB153_13
; %bb.50:
	sub	w8, w8, #1
	and	x8, x8, #0xffff
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x1
	mov	w8, #24624                      ; =0x6030
	add	x8, x9, x8
	ldrb	w10, [x8, #16]
	mov	w0, #1                          ; =0x1
	tbz	w10, #0, LBB153_131
; %bb.51:
	ldr	x9, [x9, #24648]
	cbnz	x9, LBB153_131
; %bb.52:
	ldr	x9, [x8]
	mov	x10, #-4294967296               ; =0xffffffff00000000
	bfxil	x10, x9, #0, #8
	eor	x10, x10, x9
	tst	x10, #0xff
	b.ne	LBB153_131
; %bb.53:
	and	x9, x9, #0xff
	ldr	x11, [x8, #8]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x9, #1
	ccmp	x10, #0, #0, eq
	mov	w9, #-1                         ; =0xffffffff
	ccmp	x11, x9, #0, eq
	b.ne	LBB153_131
LBB153_54:
Lloh130:
	adrp	x9, lCPI153_0@PAGE
Lloh131:
	ldr	q0, [x9, lCPI153_0@PAGEOFF]
LBB153_55:
	str	q0, [x8]
	strb	w0, [x8, #16]
	stur	xzr, [x8, #25]
	stur	xzr, [x8, #17]
	str	xzr, [x8, #32]
	mov	w0, #0                          ; =0x0
	b	LBB153_131
LBB153_56:
	ldrh	w10, [x1, #12]
	subs	w8, w10, #2
	b.lo	LBB153_13
; %bb.57:
	mov	w9, #24624                      ; =0x6030
	add	x9, x1, x9
	and	x11, x8, #0xffff
	mov	w8, #40                         ; =0x28
	umaddl	x8, w11, w8, x9
	ldrb	w12, [x8, #16]
	mov	w0, #1                          ; =0x1
	tbz	w12, #0, LBB153_131
; %bb.58:
	ldr	x12, [x8, #24]
	cbnz	x12, LBB153_131
; %bb.59:
	ldr	x12, [x8]
	mov	x13, #-4294967296               ; =0xffffffff00000000
	bfxil	x13, x12, #0, #8
	eor	x13, x13, x12
	tst	x13, #0xff
	b.ne	LBB153_131
; %bb.60:
	and	x14, x12, #0xff
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	ldr	x15, [x8, #8]
	and	x13, x13, x12
	cmp	x14, #4
	ccmp	x13, #0, #0, eq
	mov	w13, #-1                        ; =0xffffffff
	ccmp	x15, x13, #0, eq
	b.ne	LBB153_131
; %bb.61:
	mov	w13, #40                        ; =0x28
	umaddl	x11, w11, w13, x9
	ldrb	w13, [x11, #56]
	tbz	w13, #0, LBB153_131
; %bb.62:
	ldr	x13, [x11, #64]
	cbnz	x13, LBB153_131
; %bb.63:
	ldur	x13, [x11, #40]
	mov	x14, #-4294967296               ; =0xffffffff00000000
	bfxil	x14, x13, #0, #8
	eor	x14, x14, x13
	tst	x14, #0xff
	b.ne	LBB153_131
; %bb.64:
	and	x13, x13, #0xff
	ldur	x11, [x11, #48]
	and	x12, x14, x12
	cmp	x13, #4
	b	LBB153_22
LBB153_65:
	ldrh	w8, [x1, #12]
	cbz	w8, LBB153_13
; %bb.66:
	sub	w8, w8, #1
	and	x9, x8, #0xffff
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x1
	mov	w9, #24624                      ; =0x6030
	add	x9, x10, x9
	ldrb	w11, [x9, #16]
	mov	w0, #1                          ; =0x1
	tbz	w11, #0, LBB153_131
; %bb.67:
	ldr	x10, [x10, #24648]
	cbnz	x10, LBB153_131
; %bb.68:
	ldr	x10, [x9]
	mov	x11, #-4294967296               ; =0xffffffff00000000
	bfxil	x11, x10, #0, #8
	eor	x11, x11, x10
	tst	x11, #0xff
	b.ne	LBB153_131
; %bb.69:
	and	x10, x10, #0xff
	ldr	x12, [x9, #8]
	and	x11, x11, #0xffffffffffffff00
	and	x11, x11, #0xffffffff0000ffff
	cmp	x10, #4
	ccmp	x11, #0, #0, eq
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x12, x10, #0, eq
	b.ne	LBB153_131
; %bb.70:
	mov	w0, #0                          ; =0x0
	str	xzr, [x9, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	strh	w8, [x1, #12]
	b	LBB153_131
LBB153_71:
	ldrh	w8, [x1, #12]
	cbz	x8, LBB153_13
; %bb.72:
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x1
	mov	w8, #24584                      ; =0x6008
	add	x8, x9, x8
	ldrb	w10, [x8, #16]
	mov	w0, #1                          ; =0x1
	tbz	w10, #0, LBB153_131
; %bb.73:
	ldrb	w10, [x8, #1]
	ldr	x9, [x9, #24608]
	cmp	x9, #0
	ccmp	w10, #0, #0, eq
	b.ne	LBB153_131
; %bb.74:
	ldr	w9, [x8, #12]
	cmp	w9, #3
	b.ne	LBB153_130
; %bb.75:
	mov	w0, #0                          ; =0x0
Lloh132:
	adrp	x9, lCPI153_0@PAGE
Lloh133:
	ldr	q0, [x9, lCPI153_0@PAGEOFF]
LBB153_76:
	str	q0, [x8]
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #16]
	stur	xzr, [x8, #25]
	stur	xzr, [x8, #17]
	str	xzr, [x8, #32]
	b	LBB153_131
LBB153_77:
	ldr	w8, [x2, #592]
	cmp	w11, #251
	mov	w9, #8                          ; =0x8
	mov	w11, #16                        ; =0x10
	csel	x9, x11, x9, eq
	ldrh	w2, [x10, x9]
	ldur	x9, [x29, #-40]
Lloh134:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh135:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh136:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.78:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_construct
LBB153_79:
	cmp	w11, #252
	cset	w3, eq
	ldur	x9, [x29, #-40]
Lloh137:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh138:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh139:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.80:
	mov	x0, x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_file_body_projection
LBB153_81:
	ldur	x8, [x29, #-40]
Lloh140:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh141:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh142:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.82:
	mov	x0, x1
	mov	w1, #5                          ; =0x5
	mov	w2, #1                          ; =0x1
	b	LBB153_135
LBB153_83:
	mov	x0, x1
	mov	x19, x3
	bl	_nvm_file_flow_can_exit
	cmp	w0, #0
	cset	w8, eq
	strb	w8, [x19, #1]
	mov	w8, #4                          ; =0x4
	str	w8, [x19, #12]
	b	LBB153_131
LBB153_84:
	ldrh	w9, [x2, #24]
	ldur	x10, [x29, #-40]
Lloh143:
	adrp	x11, ___stack_chk_guard@GOTPAGE
Lloh144:
	ldr	x11, [x11, ___stack_chk_guard@GOTPAGEOFF]
Lloh145:
	ldr	x11, [x11]
	cmp	x11, x10
	b.ne	LBB153_181
; %bb.85:
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
	mov	w3, #1                          ; =0x1
	b	LBB153_90
LBB153_86:
	ldur	x9, [x29, #-40]
Lloh146:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh147:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh148:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.87:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_put
LBB153_88:
	ldrh	w9, [x2, #24]
	ldur	x10, [x29, #-40]
Lloh149:
	adrp	x11, ___stack_chk_guard@GOTPAGE
Lloh150:
	ldr	x11, [x11, ___stack_chk_guard@GOTPAGEOFF]
Lloh151:
	ldr	x11, [x11]
	cmp	x11, x10
	b.ne	LBB153_181
; %bb.89:
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
	mov	w3, #0                          ; =0x0
LBB153_90:
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_file_flow_borrow_mode
LBB153_91:
	cbz	x1, LBB153_13
; %bb.92:
	ldrb	w8, [x1, #40]
	cmp	w8, #1
	b.ne	LBB153_130
; %bb.93:
	ldrh	w8, [x1, #12]
	cmp	x8, #256
	b.eq	LBB153_114
; %bb.94:
	mov	w0, #0                          ; =0x0
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x1
	add	w8, w8, #1
	strh	w8, [x1, #12]
Lloh152:
	adrp	x8, lCPI153_3@PAGE
Lloh153:
	ldr	q0, [x8, lCPI153_3@PAGEOFF]
	b	LBB153_180
LBB153_95:
	ldur	x8, [x29, #-40]
Lloh154:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh155:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh156:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.96:
	mov	x0, x1
	mov	w1, #4                          ; =0x4
	mov	w2, #4                          ; =0x4
	b	LBB153_135
LBB153_97:
	cbz	x1, LBB153_13
; %bb.98:
	ldrb	w8, [x1, #40]
	cmp	w8, #1
	b.ne	LBB153_130
; %bb.99:
	ldrh	w8, [x1, #12]
	cmp	x8, #256
	b.eq	LBB153_114
; %bb.100:
	mov	w0, #0                          ; =0x0
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x1
	add	w8, w8, #1
	strh	w8, [x1, #12]
Lloh157:
	adrp	x8, lCPI153_2@PAGE
Lloh158:
	ldr	q0, [x8, lCPI153_2@PAGEOFF]
	b	LBB153_180
LBB153_101:
	ldur	x8, [x29, #-40]
Lloh159:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh160:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh161:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.102:
	mov	x0, x1
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_dup
LBB153_103:
	ldur	x9, [x29, #-40]
Lloh162:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh163:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh164:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.104:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_load
LBB153_105:
	cbz	x1, LBB153_13
; %bb.106:
	ldrb	w8, [x1, #40]
	cmp	w8, #1
	b.ne	LBB153_130
; %bb.107:
	ldrh	w8, [x1, #12]
	cmp	x8, #256
	b.eq	LBB153_114
; %bb.108:
	mov	w0, #0                          ; =0x0
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x1
	add	w8, w8, #1
	strh	w8, [x1, #12]
Lloh165:
	adrp	x8, lCPI153_0@PAGE
Lloh166:
	ldr	q0, [x8, lCPI153_0@PAGEOFF]
	b	LBB153_180
LBB153_109:
	ldur	x9, [x29, #-40]
Lloh167:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh168:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh169:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.110:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_store
LBB153_111:
	cbz	x1, LBB153_13
; %bb.112:
	ldrb	w8, [x1, #40]
	cmp	w8, #1
	b.ne	LBB153_130
; %bb.113:
	ldrh	w8, [x1, #12]
	cmp	x8, #256
	b.ne	LBB153_179
LBB153_114:
	mov	w0, #3                          ; =0x3
	b	LBB153_131
LBB153_115:
	ldur	x9, [x29, #-40]
Lloh170:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh171:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh172:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.116:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_take
LBB153_117:
	ldur	x8, [x29, #-40]
Lloh173:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh174:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh175:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.118:
	mov	x0, x1
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_pop
LBB153_119:
	ldur	x8, [x29, #-40]
Lloh176:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh177:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh178:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.120:
	mov	x0, x1
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_region_end
LBB153_121:
	ldur	x8, [x29, #-40]
Lloh179:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh180:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh181:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.122:
	mov	x0, x1
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_region_begin
LBB153_123:
	mov	w8, #6                          ; =0x6
	mov	x19, x3
	str	w8, [x3, #12]
	ldr	w8, [x2]
	ldr	w9, [x2, #16]
	mov	x20, x2
	ldrh	w3, [x2, #24]
	mov	x21, x1
	mov	x0, x1
	mov	x1, x8
	mov	x2, x9
	bl	_nvm_file_flow_service
	b	LBB153_147
LBB153_124:
	cbz	x1, LBB153_13
; %bb.125:
	ldrb	w9, [x1, #40]
	cmp	w9, #1
	b.ne	LBB153_130
; %bb.126:
	cmp	w8, #255
	b.hi	LBB153_13
; %bb.127:
	mov	w9, #40                         ; =0x28
	umaddl	x8, w8, w9, x1
	mov	w9, #34864                      ; =0x8830
	add	x8, x8, x9
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB153_13
; %bb.128:
	ldrb	w9, [x8, #1]
	tbnz	w9, #0, LBB153_13
; %bb.129:
	mov	w0, #0                          ; =0x0
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	b	LBB153_131
LBB153_130:
	mov	w0, #2                          ; =0x2
LBB153_131:
	ldur	x8, [x29, #-40]
Lloh182:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh183:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh184:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.132:
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB153_133:
	mov	w8, #3                          ; =0x3
	str	w8, [x3, #12]
	ldur	x8, [x29, #-40]
Lloh185:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh186:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh187:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.134:
	mov	x0, x1
	mov	w1, #4                          ; =0x4
	mov	w2, #16                         ; =0x10
LBB153_135:
	mov	w3, #1                          ; =0x1
	b	LBB153_140
LBB153_136:
	mov	w9, #1                          ; =0x1
	str	w9, [x3, #12]
	strh	w8, [x3, #8]
	ldur	x9, [x29, #-40]
Lloh188:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh189:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh190:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.137:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_drop_local
LBB153_138:
	ldur	x8, [x29, #-40]
Lloh191:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh192:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh193:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.139:
	mov	x0, x1
	mov	w1, #5                          ; =0x5
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
LBB153_140:
	mov	w4, #0                          ; =0x0
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_file_body_scalar
LBB153_141:
	mov	w8, #2                          ; =0x2
	str	w8, [x3, #12]
	ldur	x8, [x29, #-40]
Lloh194:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh195:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh196:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB153_181
; %bb.142:
	mov	x0, x1
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_drop_stack
LBB153_143:
	ldrb	w9, [x2, #24]
	cmp	w9, #0
	mov	w9, #2                          ; =0x2
	cinc	w2, w9, ne
	ldur	x9, [x29, #-40]
Lloh197:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh198:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh199:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB153_181
; %bb.144:
	mov	x0, x1
	mov	x1, x8
	add	sp, sp, #528
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_nvm_file_flow_take_result
LBB153_145:
	mov	w9, #5                          ; =0x5
	mov	x19, x3
	str	w9, [x3, #12]
	mov	x20, x2
	ldr	w9, [x2]
	add	x3, sp, #8
	mov	x21, x1
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
                                        ; kill: def $w4 killed $w4 killed $x4
	bl	_nvm_file_flow_call
	cbnz	w0, LBB153_147
; %bb.146:
	mov	w8, #64                         ; =0x40
	str	w8, [x19, #16]
LBB153_147:
	cbnz	w0, LBB153_131
; %bb.148:
	ldrh	w10, [x21, #16]
	cbz	x10, LBB153_13
; %bb.149:
	mov	x8, x19
	ldr	w11, [x20]
	add	x9, x21, #48
	mov	w0, #1                          ; =0x1
LBB153_150:                             ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x9]
	cmp	w12, w11
	b.eq	LBB153_178
; %bb.151:                              ;   in Loop: Header=BB153_150 Depth=1
	add	x9, x9, #56
	subs	x10, x10, #1
	b.ne	LBB153_150
	b	LBB153_131
LBB153_152:
	mov	x12, #0                         ; =0x0
	and	x13, x4, #0xfff8
	add	x14, x2, #92
	add	x15, sp, #8
	add	x15, x15, #8
	b	LBB153_155
LBB153_153:                             ;   in Loop: Header=BB153_155 Depth=1
	ldrh	w16, [x14]
LBB153_154:                             ;   in Loop: Header=BB153_155 Depth=1
	strh	w16, [x15, #6]
	add	x12, x12, #8
	add	x14, x14, #16
	add	x15, x15, #16
	cmp	x13, x12
	b.eq	LBB153_29
LBB153_155:                             ; =>This Inner Loop Header: Depth=1
	add	w16, w11, w12
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_157
; %bb.156:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-14]
	b	LBB153_158
LBB153_157:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_158:                             ;   in Loop: Header=BB153_155 Depth=1
	sturh	w16, [x15, #-8]
	add	w16, w11, w12
	add	w16, w16, #1
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_160
; %bb.159:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-12]
	b	LBB153_161
LBB153_160:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_161:                             ;   in Loop: Header=BB153_155 Depth=1
	sturh	w16, [x15, #-6]
	add	w16, w11, w12
	add	w16, w16, #2
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_163
; %bb.162:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-10]
	b	LBB153_164
LBB153_163:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_164:                             ;   in Loop: Header=BB153_155 Depth=1
	sturh	w16, [x15, #-4]
	add	w16, w11, w12
	add	w16, w16, #3
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_166
; %bb.165:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-8]
	b	LBB153_167
LBB153_166:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_167:                             ;   in Loop: Header=BB153_155 Depth=1
	sturh	w16, [x15, #-2]
	add	w16, w11, w12
	add	w16, w16, #4
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_169
; %bb.168:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-6]
	b	LBB153_170
LBB153_169:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_170:                             ;   in Loop: Header=BB153_155 Depth=1
	strh	w16, [x15]
	add	w16, w11, w12
	add	w16, w16, #5
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_172
; %bb.171:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-4]
	b	LBB153_173
LBB153_172:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_173:                             ;   in Loop: Header=BB153_155 Depth=1
	strh	w16, [x15, #2]
	add	w16, w11, w12
	add	w16, w16, #6
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbz	w16, LBB153_175
; %bb.174:                              ;   in Loop: Header=BB153_155 Depth=1
	ldurh	w16, [x14, #-2]
	b	LBB153_176
LBB153_175:                             ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
LBB153_176:                             ;   in Loop: Header=BB153_155 Depth=1
	strh	w16, [x15, #4]
	add	w16, w11, w12
	add	w16, w16, #7
	ubfiz	x16, x16, #4, #32
	ldrb	w16, [x9, x16]
	cbnz	w16, LBB153_153
; %bb.177:                              ;   in Loop: Header=BB153_155 Depth=1
	mov	w16, #65535                     ; =0xffff
	b	LBB153_154
LBB153_178:
	mov	w0, #0                          ; =0x0
	mov	w10, #1                         ; =0x1
	strb	w10, [x8, #3]
	ldur	q0, [x9, #12]
	ldur	q1, [x9, #28]
	ldur	x10, [x9, #44]
	ldur	q2, [x9, #-4]
	stur	q2, [x8, #24]
	str	x10, [x8, #72]
	ldr	w9, [x8, #36]
	ldp	w10, w11, [x8, #16]
	bic	w9, w9, w10
	orr	w9, w11, w9
	stur	q1, [x8, #56]
	stur	q0, [x8, #40]
	str	w9, [x8, #20]
	b	LBB153_131
LBB153_179:
	mov	w0, #0                          ; =0x0
	mov	w9, #40                         ; =0x28
	umaddl	x9, w8, w9, x1
	add	w8, w8, #1
	strh	w8, [x1, #12]
Lloh200:
	adrp	x8, lCPI153_1@PAGE
Lloh201:
	ldr	q0, [x8, lCPI153_1@PAGEOFF]
LBB153_180:
	mov	w8, #24624                      ; =0x6030
	add	x8, x9, x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x8, #16]
	str	q0, [x9, #24624]
	str	xzr, [x9, #24656]
	stur	xzr, [x8, #25]
	stur	xzr, [x8, #17]
	b	LBB153_131
LBB153_181:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh121, Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdrGotLdr	Lloh134, Lloh135, Lloh136
	.loh AdrpLdrGotLdr	Lloh137, Lloh138, Lloh139
	.loh AdrpLdrGotLdr	Lloh140, Lloh141, Lloh142
	.loh AdrpLdrGotLdr	Lloh143, Lloh144, Lloh145
	.loh AdrpLdrGotLdr	Lloh146, Lloh147, Lloh148
	.loh AdrpLdrGotLdr	Lloh149, Lloh150, Lloh151
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpLdrGotLdr	Lloh154, Lloh155, Lloh156
	.loh AdrpLdr	Lloh157, Lloh158
	.loh AdrpLdrGotLdr	Lloh159, Lloh160, Lloh161
	.loh AdrpLdrGotLdr	Lloh162, Lloh163, Lloh164
	.loh AdrpLdr	Lloh165, Lloh166
	.loh AdrpLdrGotLdr	Lloh167, Lloh168, Lloh169
	.loh AdrpLdrGotLdr	Lloh170, Lloh171, Lloh172
	.loh AdrpLdrGotLdr	Lloh173, Lloh174, Lloh175
	.loh AdrpLdrGotLdr	Lloh176, Lloh177, Lloh178
	.loh AdrpLdrGotLdr	Lloh179, Lloh180, Lloh181
	.loh AdrpLdrGotLdr	Lloh182, Lloh183, Lloh184
	.loh AdrpLdrGotLdr	Lloh185, Lloh186, Lloh187
	.loh AdrpLdrGotLdr	Lloh188, Lloh189, Lloh190
	.loh AdrpLdrGotLdr	Lloh191, Lloh192, Lloh193
	.loh AdrpLdrGotLdr	Lloh194, Lloh195, Lloh196
	.loh AdrpLdrGotLdr	Lloh197, Lloh198, Lloh199
	.loh AdrpLdr	Lloh200, Lloh201
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI153_0:
	.short	(LBB153_131-LBB153_2)>>2
	.short	(LBB153_105-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_111-LBB153_2)>>2
	.short	(LBB153_91-LBB153_2)>>2
	.short	(LBB153_97-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_101-LBB153_2)>>2
	.short	(LBB153_117-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_115-LBB153_2)>>2
	.short	(LBB153_86-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_24-LBB153_2)>>2
	.short	(LBB153_103-LBB153_2)>>2
	.short	(LBB153_109-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_121-LBB153_2)>>2
	.short	(LBB153_119-LBB153_2)>>2
	.short	(LBB153_84-LBB153_2)>>2
	.short	(LBB153_88-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_49-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_35-LBB153_2)>>2
	.short	(LBB153_35-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_56-LBB153_2)>>2
	.short	(LBB153_56-LBB153_2)>>2
	.short	(LBB153_95-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_131-LBB153_2)>>2
	.short	(LBB153_65-LBB153_2)>>2
	.short	(LBB153_65-LBB153_2)>>2
	.short	(LBB153_24-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_83-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_81-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_138-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_77-LBB153_2)>>2
	.short	(LBB153_71-LBB153_2)>>2
	.short	(LBB153_79-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_123-LBB153_2)>>2
	.short	(LBB153_131-LBB153_2)>>2
	.short	(LBB153_143-LBB153_2)>>2
	.short	(LBB153_136-LBB153_2)>>2
	.short	(LBB153_141-LBB153_2)>>2
	.short	(LBB153_124-LBB153_2)>>2
	.short	(LBB153_24-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_133-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_2-LBB153_2)>>2
	.short	(LBB153_49-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_12-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_77-LBB153_2)>>2
	.short	(LBB153_79-LBB153_2)>>2
	.short	(LBB153_130-LBB153_2)>>2
	.short	(LBB153_71-LBB153_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function file_body_scalar
_file_body_scalar:                      ; @file_body_scalar
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w2 killed $w2 def $x2
	ldrh	w9, [x0, #12]
	subs	w8, w9, w3
	b.lo	LBB154_5
; %bb.1:
	mov	w10, #24624                     ; =0x6030
	add	x10, x0, x10
	and	x12, x8, #0xffff
	mov	w8, #40                         ; =0x28
	umaddl	x11, w12, w8, x10
	ldrb	w13, [x11, #16]
	mov	w8, #1                          ; =0x1
	tbz	w13, #0, LBB154_6
; %bb.2:
	ldr	x13, [x11, #24]
	cbnz	x13, LBB154_6
; %bb.3:
	ldr	x13, [x11]
	and	w8, w13, #0xff
	orr	x14, x8, #0xffffffff00000000
	eor	x14, x14, x13
	tst	x14, #0xff
	b.ne	LBB154_5
; %bb.4:
	mov	x13, #-256                      ; =0xffffffffffffff00
	movk	x13, #0, lsl #16
	ldr	x15, [x11, #8]
	and	x14, x14, x13
	cmp	x14, #0
	mov	w14, #-1                        ; =0xffffffff
	ccmp	x15, x14, #0, eq
	b.eq	LBB154_7
LBB154_5:
	mov	w8, #1                          ; =0x1
LBB154_6:
	mov	x0, x8
	ret
LBB154_7:
	cbz	w4, LBB154_10
; %bb.8:
	cmp	w8, #1
	ccmp	w8, #4, #4, ne
	b.eq	LBB154_11
LBB154_9:
	mov	w0, #2                          ; =0x2
	ret
LBB154_10:
	cmp	w1, w8
	b.ne	LBB154_5
LBB154_11:
	cmp	w3, #1
	b.ne	LBB154_16
LBB154_12:
	sub	w8, w9, #1
	and	x11, x8, #0xffff
	mov	w12, #40                        ; =0x28
	umaddl	x11, w11, w12, x10
	str	xzr, [x11, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x11]
	cmp	w3, #2
	b.lo	LBB154_14
; %bb.13:
	sub	w12, w9, #2
	and	x9, x12, #0xffff
	mov	w11, #40                        ; =0x28
	umaddl	x11, w9, w11, x10
	str	xzr, [x11, #32]
	stp	q0, q0, [x11]
	mov	x9, x8
	mov	x8, x12
LBB154_14:
	strh	w8, [x0, #12]
	cmp	w2, #16
	b.ne	LBB154_24
; %bb.15:
	mov	w0, #0                          ; =0x0
	ret
LBB154_16:
	mov	w8, #40                         ; =0x28
	umaddl	x12, w12, w8, x10
	ldrb	w14, [x12, #56]
	mov	w8, #1                          ; =0x1
	tbz	w14, #0, LBB154_6
; %bb.17:
	ldr	x14, [x12, #64]
	cbnz	x14, LBB154_6
; %bb.18:
	ldur	x14, [x12, #40]
	and	w8, w14, #0xff
	orr	x15, x8, #0xffffffff00000000
	eor	x14, x15, x14
	tst	x14, #0xff
	b.ne	LBB154_5
; %bb.19:
	ldur	x12, [x12, #48]
	and	x13, x14, x13
	cmp	x13, #0
	mov	w13, #-1                        ; =0xffffffff
	ccmp	x12, x13, #0, eq
	b.ne	LBB154_5
; %bb.20:
	tbz	w4, #0, LBB154_25
; %bb.21:
	cmp	w8, #4
	b.eq	LBB154_23
; %bb.22:
	cmp	w8, #1
	b.ne	LBB154_9
LBB154_23:
	ldrb	w11, [x11]
	cmp	w11, w8
	b.ne	LBB154_9
	b	LBB154_12
LBB154_24:
	strh	w9, [x0, #12]
	orr	x9, x2, #0xffffffff00000000
	mov	w10, #-1                        ; =0xffffffff
	stp	x9, x10, [x11]
	mov	w9, #1                          ; =0x1
	strb	w9, [x11, #16]
	stur	xzr, [x11, #25]
	stur	xzr, [x11, #17]
	str	xzr, [x11, #32]
	mov	w0, #0                          ; =0x0
	ret
LBB154_25:
	cmp	w1, w8
	b.ne	LBB154_5
	b	LBB154_12
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function file_body_projection
lCPI155_0:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_file_body_projection:                  ; @file_body_projection
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldrh	w9, [x0, #12]
	cbz	x9, LBB155_12
; %bb.1:
	mov	x19, x0
	mov	w10, #24624                     ; =0x6030
	add	x20, x0, x10
	sub	x9, x9, #1
	mov	w10, #40                        ; =0x28
	smaddl	x10, w9, w10, x20
	ldrb	w11, [x10, #16]
	mov	w0, #1                          ; =0x1
	tbz	w11, #0, LBB155_13
; %bb.2:
	ldrb	w11, [x10, #1]
	ldr	x12, [x10, #24]
	cmp	x12, #0
	ccmp	w11, #0, #0, eq
	b.ne	LBB155_13
; %bb.3:
	ldp	w0, w11, [x10, #8]
	ldr	w21, [x10, #32]
	cbz	w3, LBB155_7
; %bb.4:
	cbnz	w2, LBB155_7
; %bb.5:
	cmp	w11, #4
	b.ne	LBB155_7
; %bb.6:
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	b	_nvm_file_flow_field
LBB155_7:
	cmp	w11, #3
	b.ne	LBB155_15
; %bb.8:
Lloh202:
	adrp	x10, lCPI155_0@PAGE
Lloh203:
	ldr	q0, [x10, lCPI155_0@PAGEOFF]
	str	q0, [sp]
	tbz	w2, #0, LBB155_11
; %bb.9:
	mov	x8, #-4294967295                ; =0xffffffff00000001
	mov	w10, #-1                        ; =0xffffffff
LBB155_10:
	mov	w0, #0                          ; =0x0
	mov	w11, #40                        ; =0x28
	smaddl	x9, w9, w11, x20
	lsr	x11, x10, #33
	stp	x8, x10, [x9]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #16]
	cmp	x11, #1
	cset	w8, eq
	stur	xzr, [x9, #17]
	str	xzr, [x9, #24]
	stp	w8, wzr, [x9, #32]
	b	LBB155_13
LBB155_11:
	cbz	w1, LBB155_14
LBB155_12:
	mov	w0, #1                          ; =0x1
LBB155_13:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB155_14:
	sub	w9, w21, #4
	cmn	w9, #2
	b.hs	LBB155_16
LBB155_15:
	mov	w0, #2                          ; =0x2
	b	LBB155_13
LBB155_16:
	bl	_nl_file_catalog_type
	cbz	x0, LBB155_12
; %bb.17:
	ldr	x8, [x0, #32]
	cmp	x8, #2
	b.ne	LBB155_12
; %bb.18:
	ldr	x8, [x0, #24]
	cmp	w21, #3
	cset	w9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	mov	x2, sp
	mov	x0, x19
	bl	_member_type
	cbz	w0, LBB155_12
; %bb.19:
	ldp	x8, x10, [sp]
	and	x9, x8, #0xff00
	cbnz	x9, LBB155_21
; %bb.20:
	lsr	x9, x10, #32
	sub	x9, x9, #1
	cmp	x9, #2
	b.lo	LBB155_12
LBB155_21:
	ldrh	w9, [x19, #12]
	sub	x9, x9, #1
	b	LBB155_10
	.loh AdrpLdr	Lloh202, Lloh203
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_section
_file_hosted_section:                   ; @file_hosted_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x8, [x1, #16]
	ldr	w9, [x1]
	add	x10, x2, x9, lsl #3
	str	x8, [x10, #64]
	cmp	w9, #12
	b.gt	LBB156_4
; %bb.1:
	cmp	w9, #6
	b.eq	LBB156_9
; %bb.2:
	cmp	w9, #12
	b.ne	LBB156_7
LBB156_3:
	mov	w0, #2                          ; =0x2
	b	LBB156_11
LBB156_4:
	cmp	w9, #13
	b.eq	LBB156_10
; %bb.5:
	cmp	w9, #14
	b.ne	LBB156_7
; %bb.6:
	ldr	x9, [x1, #8]
	add	x0, x0, x9
	add	x2, sp, #32
	mov	x1, x8
	bl	_nvm_file_nominal_decode
	cmp	w0, #0
	cset	w0, ne
	b	LBB156_11
LBB156_7:
	mov	x19, x2
	mov	x20, x1
	ldr	x9, [x1, #8]
	mov	x10, x0
	add	x0, sp, #32
	add	x1, x10, x9
	mov	x2, x8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #32
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbz	w0, LBB156_12
LBB156_8:
	mov	w0, #1                          ; =0x1
	b	LBB156_11
LBB156_9:
	cmp	x8, #16, lsl #12                ; =65536
	mov	w9, #3                          ; =0x3
	csel	w10, wzr, w9, ls
	cmp	x8, #0
	csel	w0, w9, w10, eq
	b	LBB156_11
LBB156_10:
	cmp	x8, #0
	cset	w0, eq
LBB156_11:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB156_12:
	ldr	w8, [sp, #28]
	ldr	w9, [x20]
	str	w8, [x19, x9, lsl #2]
	ldr	w9, [x20]
	mov	w0, #1                          ; =0x1
	sub	w9, w9, #1
	cmp	w9, #10
	b.hi	LBB156_11
; %bb.13:
	mov	w20, #8                         ; =0x8
Lloh204:
	adrp	x10, lJTI156_0@PAGE
Lloh205:
	add	x10, x10, lJTI156_0@PAGEOFF
	adr	x11, LBB156_11
	ldrb	w12, [x10, x9]
	add	x11, x11, x12, lsl #2
	br	x11
LBB156_14:
	cbnz	w8, LBB156_3
; %bb.15:
	mov	x20, #0                         ; =0x0
	b	LBB156_73
LBB156_16:
	ldp	x9, x10, [sp, #40]
	sub	x9, x9, x10
	cmp	x8, x9, lsr #2
	b.hi	LBB156_11
; %bb.17:
	cbz	w8, LBB156_71
; %bb.18:
	mov	w21, #0                         ; =0x0
	mov	w20, #24                        ; =0x18
	b	LBB156_20
LBB156_19:                              ;   in Loop: Header=BB156_20 Depth=1
	add	w21, w21, #1
	ldr	w8, [sp, #28]
	cmp	w21, w8
	b.hs	LBB156_73
LBB156_20:                              ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #32
	add	x1, sp, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB156_8
; %bb.21:                               ;   in Loop: Header=BB156_20 Depth=1
	add	x0, sp, #32
	add	x1, sp, #12
	bl	_nvm_v2_u16
	cbnz	w0, LBB156_8
; %bb.22:                               ;   in Loop: Header=BB156_20 Depth=1
	ldrh	w1, [sp, #20]
	add	x0, sp, #32
	sub	x2, x29, #56
	bl	_nvm_v2_take
	cbnz	w0, LBB156_8
; %bb.23:                               ;   in Loop: Header=BB156_20 Depth=1
	add	x0, sp, #32
	bl	_nvm_v2_align4
	cbnz	w0, LBB156_8
; %bb.24:                               ;   in Loop: Header=BB156_20 Depth=1
	ldrh	w1, [sp, #12]
	add	x0, sp, #32
	sub	x2, x29, #56
	bl	_nvm_v2_take
	cbnz	w0, LBB156_8
; %bb.25:                               ;   in Loop: Header=BB156_20 Depth=1
	add	x0, sp, #32
	bl	_nvm_v2_align4
	cbnz	w0, LBB156_8
; %bb.26:                               ;   in Loop: Header=BB156_20 Depth=1
	ldrh	w8, [sp, #20]
	ldrh	w10, [x19, #208]
	cmp	w8, w10
	b.ls	LBB156_19
; %bb.27:                               ;   in Loop: Header=BB156_20 Depth=1
	strh	w8, [x19, #208]
	b	LBB156_19
LBB156_28:
	ldp	x9, x10, [sp, #40]
	sub	x9, x9, x10
	cmp	x8, x9, lsr #3
	b.hi	LBB156_11
; %bb.29:
	cbz	w8, LBB156_72
; %bb.30:
	mov	w21, #0                         ; =0x0
	mov	w22, #67108864                  ; =0x4000000
	mov	w20, #16                        ; =0x10
LBB156_31:                              ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #32
	add	x1, sp, #16
	bl	_nvm_v2_u8
	cbnz	w0, LBB156_8
; %bb.32:                               ;   in Loop: Header=BB156_31 Depth=1
	add	x0, sp, #32
	add	x1, sp, #27
	bl	_nvm_v2_u8
	cbnz	w0, LBB156_8
; %bb.33:                               ;   in Loop: Header=BB156_31 Depth=1
	add	x0, sp, #32
	add	x1, sp, #12
	bl	_nvm_v2_u16
	cbnz	w0, LBB156_8
; %bb.34:                               ;   in Loop: Header=BB156_31 Depth=1
	add	x0, sp, #32
	add	x1, sp, #20
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB156_11
; %bb.35:                               ;   in Loop: Header=BB156_31 Depth=1
	ldrb	w8, [sp, #27]
	cbnz	w8, LBB156_11
; %bb.36:                               ;   in Loop: Header=BB156_31 Depth=1
	ldrh	w8, [sp, #12]
	cbnz	w8, LBB156_11
; %bb.37:                               ;   in Loop: Header=BB156_31 Depth=1
	ldrb	w8, [sp, #16]
	cmp	w8, #5
	b.ne	LBB156_11
; %bb.38:                               ;   in Loop: Header=BB156_31 Depth=1
	ldr	w1, [sp, #20]
	add	x0, sp, #32
	sub	x2, x29, #56
	bl	_nvm_v2_take
	cbnz	w0, LBB156_8
; %bb.39:                               ;   in Loop: Header=BB156_31 Depth=1
	add	x0, sp, #32
	bl	_nvm_v2_align4
	cbnz	w0, LBB156_8
; %bb.40:                               ;   in Loop: Header=BB156_31 Depth=1
	ldr	x9, [x19, #200]
	mov	w0, #3                          ; =0x3
	cmp	x9, x22
	b.hi	LBB156_11
; %bb.41:                               ;   in Loop: Header=BB156_31 Depth=1
	ldr	w10, [sp, #20]
	sub	x11, x22, x9
	cmp	x11, x10
	b.ls	LBB156_11
; %bb.42:                               ;   in Loop: Header=BB156_31 Depth=1
	add	x9, x10, x9
	add	x9, x9, #1
	str	x9, [x19, #200]
	add	w21, w21, #1
	ldr	w8, [sp, #28]
	cmp	w21, w8
	b.lo	LBB156_31
	b	LBB156_73
LBB156_43:
	cmp	w8, #5
	b.ne	LBB156_11
LBB156_44:
	mov	w20, #16                        ; =0x10
	b	LBB156_69
LBB156_45:
	mov	w9, #-65537                     ; =0xfffeffff
	mov	w10, #-65529                    ; =0xffff0007
	add	w9, w8, w9
	cmp	w9, w10
	b.lo	LBB156_67
; %bb.46:
	ldp	x9, x10, [sp, #40]
	sub	x9, x9, x10
	cmp	x8, x9, lsr #3
	b.hi	LBB156_11
; %bb.47:
	mov	w21, #0                         ; =0x0
	mov	x22, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x22, #43691
	mov	w23, #67108864                  ; =0x4000000
	mov	w20, #16                        ; =0x10
LBB156_48:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB156_60 Depth 2
	add	x0, sp, #32
	add	x1, sp, #27
	bl	_nvm_v2_u8
	cbnz	w0, LBB156_8
; %bb.49:                               ;   in Loop: Header=BB156_48 Depth=1
	add	x0, sp, #32
	add	x1, sp, #19
	bl	_nvm_v2_u8
	cbnz	w0, LBB156_8
; %bb.50:                               ;   in Loop: Header=BB156_48 Depth=1
	add	x0, sp, #32
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB156_8
; %bb.51:                               ;   in Loop: Header=BB156_48 Depth=1
	add	x0, sp, #32
	add	x1, sp, #20
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB156_11
; %bb.52:                               ;   in Loop: Header=BB156_48 Depth=1
	ldrb	w9, [sp, #19]
	cbnz	w9, LBB156_11
; %bb.53:                               ;   in Loop: Header=BB156_48 Depth=1
	ldrb	w9, [sp, #27]
	cmp	w9, #3
	b.hi	LBB156_11
; %bb.54:                               ;   in Loop: Header=BB156_48 Depth=1
	ldrh	w9, [sp, #16]
	ldp	x10, x11, [sp, #40]
	sub	x10, x10, x11
	umulh	x10, x10, x22
	cmp	x9, x10, lsr #3
	b.hi	LBB156_11
; %bb.55:                               ;   in Loop: Header=BB156_48 Depth=1
	mov	x8, x19
	ldr	x10, [x19, #192]
	mov	w0, #3                          ; =0x3
	cmp	x10, x23
	b.hi	LBB156_11
; %bb.56:                               ;   in Loop: Header=BB156_48 Depth=1
	add	x11, x9, x9, lsl #1
	lsl	x11, x11, #2
	sub	x12, x23, x10
	cmp	x11, x12
	b.hi	LBB156_11
; %bb.57:                               ;   in Loop: Header=BB156_48 Depth=1
	add	x10, x10, x11
	str	x10, [x8, #192]
	cbz	w9, LBB156_65
; %bb.58:                               ;   in Loop: Header=BB156_48 Depth=1
	mov	w24, #0                         ; =0x0
	b	LBB156_60
LBB156_59:                              ;   in Loop: Header=BB156_60 Depth=2
	add	w24, w24, #1
	ldrh	w8, [sp, #16]
	cmp	w24, w8
	b.hs	LBB156_65
LBB156_60:                              ;   Parent Loop BB156_48 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #32
	sub	x2, x29, #56
	mov	w1, #4                          ; =0x4
	bl	_nvm_v2_take
	cbnz	w0, LBB156_8
; %bb.61:                               ;   in Loop: Header=BB156_60 Depth=2
	add	x0, sp, #32
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB156_8
; %bb.62:                               ;   in Loop: Header=BB156_60 Depth=2
	add	x0, sp, #32
	sub	x2, x29, #56
	mov	w1, #4                          ; =0x4
	bl	_nvm_v2_take
	cbnz	w0, LBB156_8
; %bb.63:                               ;   in Loop: Header=BB156_60 Depth=2
	ldr	w8, [sp, #12]
	cmn	w8, #1
	b.eq	LBB156_59
; %bb.64:                               ;   in Loop: Header=BB156_60 Depth=2
	cmp	w8, w21
	b.lo	LBB156_59
	b	LBB156_8
LBB156_65:                              ;   in Loop: Header=BB156_48 Depth=1
	add	w21, w21, #1
	ldr	w8, [sp, #28]
	cmp	w21, w8
	b.lo	LBB156_48
	b	LBB156_73
LBB156_66:
	sub	w9, w8, #65
	cmn	w9, #64
	b.hs	LBB156_68
LBB156_67:
	mov	w0, #3                          ; =0x3
	b	LBB156_11
LBB156_68:
	mov	w20, #32                        ; =0x20
LBB156_69:
	ldp	x9, x10, [sp, #40]
	sub	x9, x9, x10
	rbit	x10, x20
	clz	x10, x10
	lsr	x9, x9, x10
	cmp	x9, x8
	b.lo	LBB156_11
; %bb.70:
	umull	x1, w20, w8
	add	x0, sp, #32
	sub	x2, x29, #56
	bl	_nvm_v2_take
	cbnz	w0, LBB156_8
	b	LBB156_73
LBB156_71:
	mov	w20, #24                        ; =0x18
	b	LBB156_73
LBB156_72:
	mov	w20, #16                        ; =0x10
LBB156_73:
	add	x0, sp, #32
	bl	_nvm_v2_cursor_exhausted
	cbz	w0, LBB156_8
; %bb.74:
	ldr	x8, [x19, #184]
	mov	w9, #67108864                   ; =0x4000000
	mov	w0, #3                          ; =0x3
	cmp	x8, x9
	b.hi	LBB156_11
; %bb.75:
	ldr	w10, [sp, #28]
	umull	x10, w20, w10
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB156_11
; %bb.76:
	mov	w0, #0                          ; =0x0
	add	x8, x10, x8
	str	x8, [x19, #184]
	b	LBB156_11
	.loh AdrpAdd	Lloh204, Lloh205
	.cfi_endproc
	.section	__TEXT,__const
lJTI156_0:
	.byte	(LBB156_69-LBB156_11)>>2
	.byte	(LBB156_28-LBB156_11)>>2
	.byte	(LBB156_16-LBB156_11)>>2
	.byte	(LBB156_45-LBB156_11)>>2
	.byte	(LBB156_66-LBB156_11)>>2
	.byte	(LBB156_11-LBB156_11)>>2
	.byte	(LBB156_14-LBB156_11)>>2
	.byte	(LBB156_43-LBB156_11)>>2
	.byte	(LBB156_14-LBB156_11)>>2
	.byte	(LBB156_44-LBB156_11)>>2
	.byte	(LBB156_14-LBB156_11)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function file_hosted_array
_file_hosted_array:                     ; @file_hosted_array
	.cfi_startproc
; %bb.0:
	cmp	x2, x1
	b.hs	LBB157_3
LBB157_1:                               ; =>This Inner Loop Header: Depth=1
	tbnz	x2, #63, LBB157_6
; %bb.2:                                ;   in Loop: Header=BB157_1 Depth=1
	lsl	x2, x2, #1
	cmp	x2, x1
	b.lo	LBB157_1
LBB157_3:
	umulh	x8, x2, x3
	cmp	xzr, x8
	b.ne	LBB157_6
; %bb.4:
	mul	x8, x2, x3
	ldr	x9, [x0]
	mov	w10, #67108864                  ; =0x4000000
	sub	x11, x10, x9
	cmp	x9, x10
	ccmp	x8, x11, #2, ls
	b.hi	LBB157_6
; %bb.5:
	mov	w10, #67108864                  ; =0x4000000
	add	x9, x9, x8
	sub	x10, x10, x9
	str	x9, [x0]
	cmp	x8, x10
	b.ls	LBB157_7
LBB157_6:
	mov	w0, #0                          ; =0x0
	ret
LBB157_7:
	add	x8, x9, x8
	str	x8, [x0]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_complete
_file_cyclic_complete:                  ; @file_cyclic_complete
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	ldr	x9, [x0]
	ldr	w10, [x9, #24]
	cbz	w10, LBB158_26
; %bb.1:
	mov	x11, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	add	x12, x9, #56
	add	x13, x9, #2352
	mov	w14, #36                        ; =0x24
	mov	w15, #600                       ; =0x258
	mov	w16, #136                       ; =0x88
LBB158_2:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB158_4 Depth 2
                                        ;       Child Loop BB158_10 Depth 3
	mul	x17, x11, x14
	ldrh	w17, [x12, x17]
	cbz	w17, LBB158_25
; %bb.3:                                ;   in Loop: Header=BB158_2 Depth=1
	mov	w1, #0                          ; =0x0
	ldr	x2, [x9, #16]
	ldr	w3, [x13, x11, lsl #2]
	ldr	x4, [x0, #8]
LBB158_4:                               ;   Parent Loop BB158_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB158_10 Depth 3
	add	w7, w3, w1
	umaddl	x19, w7, w16, x4
	ldrb	w5, [x19]
	cmp	w5, #16
	b.hi	LBB158_29
; %bb.5:                                ;   in Loop: Header=BB158_4 Depth=2
	ldrh	w6, [x19, #2]
	cmp	w6, w17
	b.hs	LBB158_29
; %bb.6:                                ;   in Loop: Header=BB158_4 Depth=2
	cbz	w5, LBB158_24
; %bb.7:                                ;   in Loop: Header=BB158_4 Depth=2
	mov	w6, #0                          ; =0x0
	umaddl	x7, w7, w15, x2
	add	x19, x19, #8
	sub	w20, w5, #1
	add	w8, w8, w20, uxtb
	add	w8, w8, #1
	b	LBB158_10
LBB158_8:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrb	w20, [x20, #158]
	cmp	w20, #255
	b.ne	LBB158_29
LBB158_9:                               ;   in Loop: Header=BB158_10 Depth=3
	add	w6, w6, #1
	cmp	w5, w6, uxtb
	b.ls	LBB158_24
LBB158_10:                              ;   Parent Loop BB158_2 Depth=1
                                        ;     Parent Loop BB158_4 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x20, x6, #0xff
	ldr	x20, [x19, x20, lsl #3]
	cbz	x20, LBB158_29
; %bb.11:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrb	w21, [x20, #160]
	cmp	w21, #1
	b.ne	LBB158_29
; %bb.12:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrh	w21, [x20, #80]
	ldrh	w22, [x20, #58]
	cmp	w21, w22
	b.ne	LBB158_29
; %bb.13:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrh	w21, [x20, #82]
	ldrh	w22, [x20, #68]
	cmp	w21, w22
	b.ne	LBB158_29
; %bb.14:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrb	w22, [x20, #156]
	ldrb	w21, [x7, #76]
	lsr	w23, w22, w21
	cbnz	w23, LBB158_29
; %bb.15:                               ;   in Loop: Header=BB158_10 Depth=3
	tbnz	w22, #0, LBB158_17
; %bb.16:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrb	w23, [x20, #157]
	cmp	w23, #255
	b.eq	LBB158_20
	b	LBB158_29
LBB158_17:                              ;   in Loop: Header=BB158_10 Depth=3
	cbz	w21, LBB158_29
; %bb.18:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrh	w23, [x7, #72]
	cmp	w23, w17
	b.hs	LBB158_29
; %bb.19:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrb	w24, [x20, #157]
	add	w23, w3, w23
	umull	x23, w23, w16
	ldrb	w23, [x4, x23]
	cmp	w24, w23
	b.hs	LBB158_29
LBB158_20:                              ;   in Loop: Header=BB158_10 Depth=3
	tbz	w22, #1, LBB158_8
; %bb.21:                               ;   in Loop: Header=BB158_10 Depth=3
	cmp	w21, #2
	b.lo	LBB158_29
; %bb.22:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrh	w21, [x7, #74]
	cmp	w21, w17
	b.hs	LBB158_29
; %bb.23:                               ;   in Loop: Header=BB158_10 Depth=3
	ldrb	w20, [x20, #158]
	add	w21, w3, w21
	umull	x21, w21, w16
	ldrb	w21, [x4, x21]
	cmp	w20, w21
	b.lo	LBB158_9
	b	LBB158_29
LBB158_24:                              ;   in Loop: Header=BB158_4 Depth=2
	add	w1, w1, #1
	cmp	w1, w17
	b.lo	LBB158_4
LBB158_25:                              ;   in Loop: Header=BB158_2 Depth=1
	add	x11, x11, #1
	cmp	x11, x10
	b.ne	LBB158_2
	b	LBB158_27
LBB158_26:
	mov	w8, #0                          ; =0x0
LBB158_27:
	ldr	w9, [x0, #28]
	cmp	w8, w9
	b.ne	LBB158_29
; %bb.28:
	ldr	w9, [x0, #32]
	cmp	w8, w9
	cset	w0, eq
	b	LBB158_30
LBB158_29:
	mov	w0, #0                          ; =0x0
LBB158_30:
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function file_cyclic_canonicalize
lCPI159_0:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI159_1:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI159_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI159_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_file_cyclic_canonicalize:              ; @file_cyclic_canonicalize
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0, #120]
	cmp	w8, #1
	b.ne	LBB159_5
; %bb.1:
	sub	sp, sp, #208
	stp	d13, d12, [sp, #64]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #80]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #96]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	ldrh	w22, [x0, #92]
	cmp	w22, #256
	b.hi	LBB159_3
; %bb.2:
	ldrh	w20, [x0, #94]
	cmp	x20, #256
	b.ls	LBB159_6
LBB159_3:
	mov	w0, #1                          ; =0x1
LBB159_4:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #96]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #80]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB159_5:
	mov	w0, #1                          ; =0x1
	ret
LBB159_6:
	add	x8, x0, #23, lsl #12            ; =94208
	add	x19, x8, #2200
	mov	w8, #45184                      ; =0xb080
	add	x21, x0, x8
	mov	w8, #47232                      ; =0xb880
	mov	x23, x0
	add	x0, x0, x8
	mov	w1, #32784                      ; =0x8010
	bl	_bzero
	mov	x0, x19
	mov	w1, #2048                       ; =0x800
	bl	_bzero
	mov	x0, x23
	ldr	x17, [x23, #80]
	ldr	w1, [x23, #88]
	add	x8, x1, x1, lsl #1
	lsl	x9, x8, #3
	add	x10, x17, #26
	ldrh	w8, [x10, x9]
	strh	w8, [x21, #2048]
	strh	w22, [x21, #2050]
	strh	w20, [x21, #2052]
	cbz	w8, LBB159_27
; %bb.7:
	mov	w3, #0                          ; =0x0
	mov	w11, #14464                     ; =0x3880
	add	x11, x0, x11
	add	x12, x17, #1816
	add	x13, x17, #1560
	mov	w14, #47248                     ; =0xb890
	add	x14, x0, x14
	mov	w15, #40                        ; =0x28
	mov	x16, #-256                      ; =0xffffffffffffff00
	movk	x16, #0, lsl #16
	mov	x2, #4294967296                 ; =0x100000000
	b	LBB159_11
LBB159_8:                               ;   in Loop: Header=BB159_11 Depth=1
	str	x23, [x19, x24, lsl #3]
	add	x23, x24, #1
	add	w24, w24, #1
	strh	w24, [x21, #2054]
LBB159_9:                               ;   in Loop: Header=BB159_11 Depth=1
	mov	w24, #1                         ; =0x1
LBB159_10:                              ;   in Loop: Header=BB159_11 Depth=1
	mov	w3, w3
	umaddl	x25, w3, w15, x14
	stp	x4, x5, [x25]
	strb	w24, [x25, #16]
	ldr	w4, [sp, #56]
	stur	w4, [x25, #17]
	ldur	w4, [sp, #59]
	str	w4, [x25, #20]
	str	x23, [x25, #24]
	stp	w7, w6, [x25, #32]
	add	w3, w3, #1
	cmp	w3, w8
	b.hs	LBB159_27
LBB159_11:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB159_25 Depth 2
	umaddl	x6, w3, w15, x11
	ldr	w4, [x13, x1, lsl #2]
	add	w4, w4, w3
	add	x7, x12, w4, uxtw #4
	ldr	x4, [x6]
	ldr	x5, [x7]
	eor	x23, x5, x4
	tst	x23, #0xff
	b.ne	LBB159_3
; %bb.12:                               ;   in Loop: Header=BB159_11 Depth=1
	ldr	x5, [x6, #8]
	ldr	x7, [x7, #8]
	and	x23, x23, x16
	cmp	x23, #0
	ccmp	x5, x7, #0, eq
	b.ne	LBB159_3
; %bb.13:                               ;   in Loop: Header=BB159_11 Depth=1
	ubfx	w24, w4, #8, #8
	ldrb	w25, [x6, #16]
	ldur	w7, [x6, #17]
	str	w7, [sp, #56]
	ldr	w7, [x6, #20]
	stur	w7, [sp, #59]
	ldr	x23, [x6, #24]
	ldp	w7, w6, [x6, #32]
	cbz	w24, LBB159_15
; %bb.14:                               ;   in Loop: Header=BB159_11 Depth=1
	and	x26, x5, #0xffffffff00000000
	cmp	w24, #2
	ccmp	x26, x2, #0, ls
	b.ne	LBB159_3
LBB159_15:                              ;   in Loop: Header=BB159_11 Depth=1
	tbz	w25, #0, LBB159_19
; %bb.16:                               ;   in Loop: Header=BB159_11 Depth=1
	lsr	x24, x5, #32
	sub	x24, x24, #1
	tst	x4, #0xff00
	ccmp	x24, #2, #2, eq
	cset	w24, lo
	cmp	x23, #0
	cset	w25, eq
	cmp	w24, w25
	b.eq	LBB159_3
; %bb.17:                               ;   in Loop: Header=BB159_11 Depth=1
	lsr	x24, x5, #33
	cmp	x24, #1
	b.ne	LBB159_21
; %bb.18:                               ;   in Loop: Header=BB159_11 Depth=1
	sub	w24, w7, #1
	cmp	w24, #3
	b.lo	LBB159_22
	b	LBB159_3
LBB159_19:                              ;   in Loop: Header=BB159_11 Depth=1
	cmp	w24, #0
	ccmp	x23, #0, #0, eq
	b.ne	LBB159_3
; %bb.20:                               ;   in Loop: Header=BB159_11 Depth=1
	mov	w6, #0                          ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	lsr	x7, x5, #33
	cmp	x7, #1
	cset	w7, eq
	stur	wzr, [sp, #59]
	str	wzr, [sp, #56]
	b	LBB159_10
LBB159_21:                              ;   in Loop: Header=BB159_11 Depth=1
	cbnz	w7, LBB159_3
LBB159_22:                              ;   in Loop: Header=BB159_11 Depth=1
	cbz	x23, LBB159_9
; %bb.23:                               ;   in Loop: Header=BB159_11 Depth=1
	ldrh	w24, [x21, #2054]
	cbz	w24, LBB159_8
; %bb.24:                               ;   in Loop: Header=BB159_11 Depth=1
	mov	x25, x19
	mov	x26, x24
	cmp	w24, #256
	b.eq	LBB159_112
LBB159_25:                              ;   Parent Loop BB159_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x27, [x25], #8
	cmp	x27, x23
	b.eq	LBB159_3
; %bb.26:                               ;   in Loop: Header=BB159_25 Depth=2
	subs	x26, x26, #1
	b.ne	LBB159_25
	b	LBB159_8
LBB159_27:
	cbz	w22, LBB159_42
; %bb.28:
	mov	w15, #0                         ; =0x0
	mov	w11, #24704                     ; =0x6080
	add	x11, x0, x11
	mov	w12, #57488                     ; =0xe090
	add	x12, x0, x12
	mov	w13, #40                        ; =0x28
	mov	w14, #1                         ; =0x1
LBB159_29:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB159_38 Depth 2
	umaddl	x4, w15, w13, x11
	ldrb	w16, [x4, #16]
	cmp	w16, #1
	b.ne	LBB159_3
; %bb.30:                               ;   in Loop: Header=BB159_29 Depth=1
	ldp	x16, x2, [x4]
	ldur	w3, [x4, #17]
	str	w3, [sp, #48]
	ldr	w3, [x4, #20]
	stur	w3, [sp, #51]
	tst	x16, #0xff00
	b.ne	LBB159_3
; %bb.31:                               ;   in Loop: Header=BB159_29 Depth=1
	ldr	x3, [x4, #24]
	lsr	x5, x2, #32
	sub	x5, x5, #1
	cmp	x5, #2
	cset	w5, lo
	cmp	x3, #0
	cset	w6, eq
	cmp	w6, w5
	b.eq	LBB159_3
; %bb.32:                               ;   in Loop: Header=BB159_29 Depth=1
	ldr	d0, [x4, #32]
	ldr	w4, [x4, #32]
	lsr	x5, x2, #33
	cmp	x5, #1
	b.ne	LBB159_34
; %bb.33:                               ;   in Loop: Header=BB159_29 Depth=1
	sub	w4, w4, #1
	cmp	w4, #3
	b.lo	LBB159_35
	b	LBB159_3
LBB159_34:                              ;   in Loop: Header=BB159_29 Depth=1
	cbnz	w4, LBB159_3
LBB159_35:                              ;   in Loop: Header=BB159_29 Depth=1
	cbz	x3, LBB159_41
; %bb.36:                               ;   in Loop: Header=BB159_29 Depth=1
	ldrh	w4, [x21, #2054]
	cbz	w4, LBB159_40
; %bb.37:                               ;   in Loop: Header=BB159_29 Depth=1
	mov	x5, x19
	mov	x6, x4
	cmp	w4, #256
	b.eq	LBB159_112
LBB159_38:                              ;   Parent Loop BB159_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x7, [x5], #8
	cmp	x7, x3
	b.eq	LBB159_3
; %bb.39:                               ;   in Loop: Header=BB159_38 Depth=2
	subs	x6, x6, #1
	b.ne	LBB159_38
LBB159_40:                              ;   in Loop: Header=BB159_29 Depth=1
	str	x3, [x19, x4, lsl #3]
	add	x3, x4, #1
	add	w4, w4, #1
	strh	w4, [x21, #2054]
LBB159_41:                              ;   in Loop: Header=BB159_29 Depth=1
	mov	w15, w15
	umaddl	x4, w15, w13, x12
	stp	x16, x2, [x4]
	strb	w14, [x4, #16]
	ldr	w16, [sp, #48]
	stur	w16, [x4, #17]
	ldur	w16, [sp, #51]
	str	w16, [x4, #20]
	str	x3, [x4, #24]
	str	d0, [x4, #32]
	add	w15, w15, #1
	cmp	w15, w22
	b.lo	LBB159_29
LBB159_42:
	cbz	w20, LBB159_49
; %bb.43:
	mov	x11, #0                         ; =0x0
	add	x12, x0, #19, lsl #12           ; =77824
	add	x12, x12, #144
	b	LBB159_45
LBB159_44:                              ;   in Loop: Header=BB159_45 Depth=1
	add	x14, x13, #513
	str	x14, [x12, x13, lsl #3]
	add	x11, x11, #1
	cmp	w20, w11, uxth
	b.ls	LBB159_49
LBB159_45:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB159_47 Depth 2
	and	x13, x11, #0xffff
	ldr	x14, [x21, x13, lsl #3]
	cbz	x14, LBB159_3
; %bb.46:                               ;   in Loop: Header=BB159_45 Depth=1
	mov	x15, x11
	mov	x16, x21
	cbz	w13, LBB159_44
LBB159_47:                              ;   Parent Loop BB159_45 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x2, [x16], #8
	cmp	x14, x2
	b.eq	LBB159_3
; %bb.48:                               ;   in Loop: Header=BB159_47 Depth=2
	subs	x15, x15, #1
	b.ne	LBB159_47
	b	LBB159_44
LBB159_49:
	mov	x12, #0                         ; =0x0
	add	x11, x0, #16, lsl #12           ; =65536
	add	x11, x11, #2193
	mov	w13, #34976                     ; =0x88a0
	add	x13, x0, x13
	mov	w14, #34944                     ; =0x8880
	add	x14, x0, x14
Lloh206:
	adrp	x15, lCPI159_3@PAGE
Lloh207:
	ldr	q0, [x15, lCPI159_3@PAGEOFF]
	mov	w15, #14464                     ; =0x3880
	add	x15, x0, x15
	mov	w16, #45184                     ; =0xb080
	add	x16, x0, x16
	mov	w2, #24                         ; =0x18
	umaddl	x17, w1, w2, x17
	add	x1, x0, #16, lsl #12            ; =65536
	add	x1, x1, #2192
	and	x2, x20, #0x1e0
	and	x5, x20, #0x1c
	and	x4, x20, #0x1fc
	mov	w3, #45312                      ; =0xb100
	add	x3, x0, x3
	stp	x5, x3, [sp, #16]               ; 16-byte Folded Spill
	mov	w3, #2                          ; =0x2
	dup.2d	v1, x3
	movi.2s	v2, #1
	movi	d3, #0x00ffff0000ffff
	neg	x3, x4
	str	x3, [sp, #32]                   ; 8-byte Folded Spill
Lloh208:
	adrp	x3, lCPI159_0@PAGE
Lloh209:
	ldr	q4, [x3, lCPI159_0@PAGEOFF]
Lloh210:
	adrp	x3, lCPI159_1@PAGE
Lloh211:
	ldr	q5, [x3, lCPI159_1@PAGEOFF]
Lloh212:
	adrp	x3, lCPI159_2@PAGE
Lloh213:
	ldr	q6, [x3, lCPI159_2@PAGEOFF]
	add	x3, x19, #64
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	add	x0, x0, #23, lsl #12            ; =94208
	movi.8h	v7, #1
	movi.8h	v16, #9
	add	x0, x0, #2200
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	w0, #16                         ; =0x10
	dup.2d	v17, x0
	mov	w22, #40                        ; =0x28
	b	LBB159_53
LBB159_50:                              ;   in Loop: Header=BB159_53 Depth=1
	mov	x3, #0                          ; =0x0
	mov	x0, x30
LBB159_51:                              ;   in Loop: Header=BB159_53 Depth=1
	madd	x5, x12, x22, x1
	strb	w24, [x5]
	strb	w28, [x5, #1]
	strh	w25, [x5, #2]
	str	w27, [x5, #4]
	stp	x0, x30, [x5, #8]
	str	x3, [x5, #24]
	strb	w26, [x5, #32]
	ldur	w0, [x23, #33]
	stur	w0, [x5, #33]
	ldur	w0, [x23, #36]
	str	w0, [x5, #36]
	ldrh	w0, [x21, #2056]
	add	w0, w0, #1
	strh	w0, [x21, #2056]
LBB159_52:                              ;   in Loop: Header=BB159_53 Depth=1
	add	x12, x12, #1
	cmp	x12, #256
	b.eq	LBB159_113
LBB159_53:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB159_67 Depth 2
                                        ;     Child Loop BB159_71 Depth 2
                                        ;     Child Loop BB159_74 Depth 2
                                        ;     Child Loop BB159_80 Depth 2
                                        ;     Child Loop BB159_97 Depth 2
                                        ;     Child Loop BB159_101 Depth 2
                                        ;     Child Loop BB159_104 Depth 2
                                        ;     Child Loop BB159_107 Depth 2
	madd	x23, x12, x22, x14
	ldrb	w24, [x23]
	tbz	w24, #0, LBB159_52
; %bb.54:                               ;   in Loop: Header=BB159_53 Depth=1
	ldp	x30, x7, [x23, #8]
	cmp	x30, #0
	ccmp	x7, #0, #4, ne
	b.eq	LBB159_3
; %bb.55:                               ;   in Loop: Header=BB159_53 Depth=1
	ldrh	w25, [x23, #2]
	ldrh	w0, [x10, x9]
	cmp	w25, w0
	b.hs	LBB159_3
; %bb.56:                               ;   in Loop: Header=BB159_53 Depth=1
	umaddl	x5, w25, w22, x15
	ldrb	w3, [x5, #16]
	mov	w0, #1                          ; =0x1
	tbz	w3, #0, LBB159_4
; %bb.57:                               ;   in Loop: Header=BB159_53 Depth=1
	ldr	w3, [x5, #12]
	cmp	w3, #1
	b.ne	LBB159_4
; %bb.58:                               ;   in Loop: Header=BB159_53 Depth=1
	ldrb	w28, [x23, #1]
	ldr	w27, [x23, #4]
	ldr	x3, [x23, #24]
	ldrb	w26, [x23, #32]
	ldrb	w6, [x5, #1]
	ldr	x5, [x5, #24]
	tbz	w28, #0, LBB159_61
; %bb.59:                               ;   in Loop: Header=BB159_53 Depth=1
	cmp	x12, x25
	b.ne	LBB159_4
; %bb.60:                               ;   in Loop: Header=BB159_53 Depth=1
	tst	w26, #0x1
	cinc	w19, w0, eq
	cmp	w19, w6
	ccmp	x5, #0, #0, eq
	b.eq	LBB159_76
	b	LBB159_4
LBB159_61:                              ;   in Loop: Header=BB159_53 Depth=1
	cmp	w6, #0
	ccmp	x5, x30, #0, eq
	ccmp	w20, #0, #4, eq
	b.eq	LBB159_4
; %bb.62:                               ;   in Loop: Header=BB159_53 Depth=1
	cmp	w20, #4
	b.hs	LBB159_64
; %bb.63:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	x6, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	b	LBB159_73
LBB159_64:                              ;   in Loop: Header=BB159_53 Depth=1
	dup.2d	v18, x3
	cmp	w20, #32
	b.hs	LBB159_66
; %bb.65:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	x5, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	b	LBB159_70
LBB159_66:                              ;   in Loop: Header=BB159_53 Depth=1
	movi.2d	v19, #0000000000000000
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	x5, x2
	movi.2d	v20, #0000000000000000
LBB159_67:                              ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q22, q21, [x0, #-32]
	ldp	q24, q23, [x0, #-64]
	ldp	q26, q25, [x0, #-96]
	ldp	q27, q28, [x0, #-128]
	ldp	q30, q29, [x0, #96]
	ldp	q8, q31, [x0, #64]
	ldp	q10, q9, [x0, #32]
	ldp	q11, q12, [x0], #256
	cmeq.2d	v28, v28, v18
	cmeq.2d	v27, v27, v18
	uzp1.4s	v27, v27, v28
	cmeq.2d	v26, v26, v18
	cmeq.2d	v25, v25, v18
	uzp1.4s	v25, v26, v25
	uzp1.8h	v25, v27, v25
	cmeq.2d	v24, v24, v18
	cmeq.2d	v23, v23, v18
	uzp1.4s	v23, v24, v23
	cmeq.2d	v22, v22, v18
	cmeq.2d	v21, v21, v18
	uzp1.4s	v21, v22, v21
	uzp1.8h	v21, v23, v21
	uzp1.16b	v21, v25, v21
	cmeq.2d	v22, v12, v18
	cmeq.2d	v23, v11, v18
	uzp1.4s	v22, v23, v22
	cmeq.2d	v23, v10, v18
	cmeq.2d	v24, v9, v18
	uzp1.4s	v23, v23, v24
	uzp1.8h	v22, v22, v23
	cmeq.2d	v23, v8, v18
	cmeq.2d	v24, v31, v18
	uzp1.4s	v23, v23, v24
	cmeq.2d	v24, v30, v18
	cmeq.2d	v25, v29, v18
	uzp1.4s	v24, v24, v25
	uzp1.8h	v23, v23, v24
	uzp1.16b	v22, v22, v23
	orr.16b	v19, v19, v21
	orr.16b	v20, v20, v22
	subs	x5, x5, #32
	b.ne	LBB159_67
; %bb.68:                               ;   in Loop: Header=BB159_53 Depth=1
	orr.16b	v19, v20, v19
	shl.16b	v19, v19, #7
	cmlt.16b	v19, v19, #0
	umaxv.16b	b19, v19
	fmov	w0, s19
	and	w0, w0, #0x1
	cmp	x2, x20
	b.eq	LBB159_75
; %bb.69:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	x5, x2
	mov	x6, x2
	ldr	x19, [sp, #16]                  ; 8-byte Folded Reload
	cbz	x19, LBB159_73
LBB159_70:                              ;   in Loop: Header=BB159_53 Depth=1
	movi.2d	v19, #0000000000000000
	mov.h	v19[0], w0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	add	x0, x0, x5
	add	x5, x16, x5, lsl #3
LBB159_71:                              ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q20, q21, [x5], #32
	cmeq.2d	v21, v21, v18
	cmeq.2d	v20, v20, v18
	uzp1.4s	v20, v20, v21
	xtn.4h	v20, v20
	orr.8b	v19, v19, v20
	adds	x0, x0, #4
	b.ne	LBB159_71
; %bb.72:                               ;   in Loop: Header=BB159_53 Depth=1
	shl.4h	v18, v19, #15
	cmlt.4h	v18, v18, #0
	umaxv.4h	h18, v18
	fmov	w0, s18
	and	w0, w0, #0x1
	mov	x6, x4
	cmp	x4, x20
	b.eq	LBB159_75
LBB159_73:                              ;   in Loop: Header=BB159_53 Depth=1
	sub	x5, x20, x6
	add	x6, x16, x6, lsl #3
LBB159_74:                              ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x19, [x6], #8
	cmp	x19, x3
	cset	w19, eq
	orr	w0, w0, w19
	subs	x5, x5, #1
	b.ne	LBB159_74
LBB159_75:                              ;   in Loop: Header=BB159_53 Depth=1
	tbz	w0, #0, LBB159_3
LBB159_76:                              ;   in Loop: Header=BB159_53 Depth=1
	cbz	x12, LBB159_84
; %bb.77:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	x0, x12
	mov	x5, x13
	b	LBB159_80
LBB159_78:                              ;   in Loop: Header=BB159_80 Depth=2
	ldur	x6, [x5, #-16]
	cmp	x6, x7
	b.eq	LBB159_3
LBB159_79:                              ;   in Loop: Header=BB159_80 Depth=2
	add	x5, x5, #40
	subs	x0, x0, #1
	b.eq	LBB159_84
LBB159_80:                              ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w6, [x5, #-32]
	cmp	w6, #1
	b.ne	LBB159_79
; %bb.81:                               ;   in Loop: Header=BB159_80 Depth=2
	ldur	x6, [x5, #-24]
	cmp	x6, x30
	b.ne	LBB159_78
; %bb.82:                               ;   in Loop: Header=BB159_80 Depth=2
	tbz	w26, #0, LBB159_3
; %bb.83:                               ;   in Loop: Header=BB159_80 Depth=2
	ldrb	w6, [x5]
	cmp	w6, #1
	b.eq	LBB159_78
	b	LBB159_3
LBB159_84:                              ;   in Loop: Header=BB159_53 Depth=1
	tbz	w28, #0, LBB159_90
; %bb.85:                               ;   in Loop: Header=BB159_53 Depth=1
	ldurh	w0, [x17, #24]
	cmp	x12, x0
	b.hs	LBB159_3
; %bb.86:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	w0, #1                          ; =0x1
	cmp	x12, x25
	b.ne	LBB159_4
; %bb.87:                               ;   in Loop: Header=BB159_53 Depth=1
	cbnz	x3, LBB159_4
; %bb.88:                               ;   in Loop: Header=BB159_53 Depth=1
	add	x3, x12, #257
	cmp	x30, x3
	b.ne	LBB159_4
; %bb.89:                               ;   in Loop: Header=BB159_53 Depth=1
	cmp	x7, x30
	b.eq	LBB159_50
	b	LBB159_4
LBB159_90:                              ;   in Loop: Header=BB159_53 Depth=1
	ldrh	w0, [x21, #2054]
	cbz	w0, LBB159_93
; %bb.91:                               ;   in Loop: Header=BB159_53 Depth=1
	cmp	w0, #1
	b.ne	LBB159_94
; %bb.92:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	x6, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB159_103
LBB159_93:                              ;   in Loop: Header=BB159_53 Depth=1
	mov	w5, #0                          ; =0x0
	b	LBB159_105
LBB159_94:                              ;   in Loop: Header=BB159_53 Depth=1
	dup.2d	v18, x30
	cmp	w0, #16
	b.hs	LBB159_96
; %bb.95:                               ;   in Loop: Header=BB159_53 Depth=1
	mov	x6, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB159_100
LBB159_96:                              ;   in Loop: Header=BB159_53 Depth=1
	and	x6, x0, #0xfff0
	movi.2d	v19, #0000000000000000
	ldr	x5, [sp, #8]                    ; 8-byte Folded Reload
	mov	x7, x6
	mov.16b	v20, v0
	mov.16b	v21, v6
	mov.16b	v22, v5
	mov.16b	v23, v4
	movi.2d	v24, #0000000000000000
LBB159_97:                              ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q26, q25, [x5, #-32]
	ldp	q27, q28, [x5, #-64]
	ldp	q30, q29, [x5, #32]
	ldp	q31, q8, [x5], #128
	cmeq.2d	v28, v28, v18
	cmeq.2d	v27, v27, v18
	uzp1.4s	v27, v27, v28
	cmeq.2d	v26, v26, v18
	cmeq.2d	v25, v25, v18
	uzp1.4s	v25, v26, v25
	uzp1.8h	v25, v27, v25
	cmeq.2d	v26, v8, v18
	cmeq.2d	v27, v31, v18
	uzp1.4s	v26, v27, v26
	cmeq.2d	v27, v30, v18
	cmeq.2d	v28, v29, v18
	uzp1.4s	v27, v27, v28
	uzp1.8h	v26, v26, v27
	uzp1.4s	v27, v20, v21
	uzp1.4s	v28, v22, v23
	uzp1.8h	v27, v27, v28
	add.8h	v28, v27, v7
	add.8h	v27, v27, v16
	bit.16b	v19, v28, v25
	bit.16b	v24, v27, v26
	add.2d	v22, v22, v17
	add.2d	v21, v21, v17
	add.2d	v20, v20, v17
	add.2d	v23, v23, v17
	subs	x7, x7, #16
	b.ne	LBB159_97
; %bb.98:                               ;   in Loop: Header=BB159_53 Depth=1
	umax.8h	v19, v19, v24
	umaxv.8h	h19, v19
	fmov	w5, s19
	cmp	x6, x0
	b.eq	LBB159_105
; %bb.99:                               ;   in Loop: Header=BB159_53 Depth=1
	tst	x0, #0xe
	b.eq	LBB159_103
LBB159_100:                             ;   in Loop: Header=BB159_53 Depth=1
	mov	x7, x6
	dup.2s	v19, w5
	and	x6, x0, #0xfffe
	dup.2d	v20, x7
	orr.16b	v20, v20, v0
	sub	x5, x7, x6
	ldr	x19, [sp, #40]                  ; 8-byte Folded Reload
	add	x7, x19, x7, lsl #3
LBB159_101:                             ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q21, [x7], #16
	cmeq.2d	v21, v21, v18
	xtn.2s	v21, v21
	xtn.2s	v22, v20
	add.2s	v22, v22, v2
	bit.8b	v19, v22, v21
	add.2d	v20, v20, v1
	adds	x5, x5, #2
	b.ne	LBB159_101
; %bb.102:                              ;   in Loop: Header=BB159_53 Depth=1
	and.8b	v18, v19, v3
	umaxp.2s	v18, v18, v18
	fmov	w5, s18
	cmp	x6, x0
	b.eq	LBB159_105
LBB159_103:                             ;   in Loop: Header=BB159_53 Depth=1
	ldr	x7, [sp, #40]                   ; 8-byte Folded Reload
	add	x7, x7, x6, lsl #3
	sub	x0, x0, x6
	add	x6, x6, #1
LBB159_104:                             ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x19, [x7], #8
	cmp	x19, x30
	csel	w5, w6, w5, eq
	add	x6, x6, #1
	subs	x0, x0, #1
	b.ne	LBB159_104
LBB159_105:                             ;   in Loop: Header=BB159_53 Depth=1
	cbz	w20, LBB159_108
; %bb.106:                              ;   in Loop: Header=BB159_53 Depth=1
	mov	x0, #0                          ; =0x0
	mov	x6, x20
LBB159_107:                             ;   Parent Loop BB159_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x7, [x16, x0, lsl #3]
	cmp	x7, x3
	csel	w6, w0, w6, eq
	add	x0, x0, #1
	cmp	x20, x0
	b.ne	LBB159_107
	b	LBB159_109
LBB159_108:                             ;   in Loop: Header=BB159_53 Depth=1
	mov	w6, #0                          ; =0x0
LBB159_109:                             ;   in Loop: Header=BB159_53 Depth=1
	mov	w0, #1                          ; =0x1
	tst	w5, #0xffff
	b.eq	LBB159_4
; %bb.110:                              ;   in Loop: Header=BB159_53 Depth=1
	cmp	w20, w6, uxth
	b.eq	LBB159_4
; %bb.111:                              ;   in Loop: Header=BB159_53 Depth=1
	and	x0, x5, #0xffff
	add	x30, x12, #769
	and	x3, x6, #0xffff
	add	x3, x3, #513
	b	LBB159_51
LBB159_112:
	mov	w0, #3                          ; =0x3
	b	LBB159_4
LBB159_113:
	cbz	w8, LBB159_119
; %bb.114:
	mov	x9, #-20480                     ; =0xffffffffffffb000
	b	LBB159_116
LBB159_115:                             ;   in Loop: Header=BB159_116 Depth=1
	mov	w0, #0                          ; =0x0
	add	x11, x11, #40
	subs	x8, x8, #1
	b.eq	LBB159_4
LBB159_116:                             ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x11, x9]
	cbz	w10, LBB159_115
; %bb.117:                              ;   in Loop: Header=BB159_116 Depth=1
	ldurb	w10, [x11, #-1]
	cmp	w10, #1
	b.ne	LBB159_3
; %bb.118:                              ;   in Loop: Header=BB159_116 Depth=1
	ldrb	w10, [x11]
	cmp	w10, #1
	b.eq	LBB159_115
	b	LBB159_3
LBB159_119:
	mov	w0, #0                          ; =0x0
	b	LBB159_4
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdrp	Lloh210, Lloh212
	.loh AdrpLdr	Lloh210, Lloh211
	.loh AdrpAdrp	Lloh208, Lloh210
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpLdr	Lloh206, Lloh207
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_intern
_file_cyclic_intern:                    ; @file_cyclic_intern
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x4, [sp, #64]                   ; 8-byte Folded Spill
	mov	w8, #47232                      ; =0xb880
	add	x27, x1, x8
	ldp	x9, x8, [x0]
	add	x9, x9, w2, uxtw #2
	ldr	w9, [x9, #2352]
	add	w9, w9, w3
	mov	w10, #136                       ; =0x88
	umaddl	x28, w9, w10, x8
	ldrb	w26, [x28]
	cbz	x26, LBB160_30
; %bb.1:
	mov	x8, #0                          ; =0x0
	add	x9, x1, #19, lsl #12            ; =77824
	add	x11, x9, #144
	mov	w10, #57520                     ; =0xe0b0
	add	x9, x1, x10
	stp	x11, x9, [sp, #48]              ; 16-byte Folded Spill
	add	x11, x28, #8
	mov	x12, x27
	ldrh	w13, [x12], #48
	add	x14, x1, #16, lsl #12           ; =65536
	add	x14, x14, #2192
	add	x15, x1, #16, lsl #12           ; =65536
	add	x9, x15, #2208
	str	x9, [sp, #72]                   ; 8-byte Folded Spill
	add	x16, x1, #16, lsl #12           ; =65536
	add	x16, x16, #2194
	mov	x17, #-256                      ; =0xffffffffffffff00
	movk	x17, #0, lsl #16
	b	LBB160_3
LBB160_2:                               ;   in Loop: Header=BB160_3 Depth=1
	add	x8, x8, #1
	cmp	x8, x26
	b.eq	LBB160_30
LBB160_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB160_10 Depth 2
                                        ;     Child Loop BB160_15 Depth 2
                                        ;     Child Loop BB160_20 Depth 2
                                        ;     Child Loop BB160_24 Depth 2
	ldr	x2, [x11, x8, lsl #3]
	ldrh	w5, [x2]
	cmp	w5, w13
	b.ne	LBB160_2
; %bb.4:                                ;   in Loop: Header=BB160_3 Depth=1
	ldrh	w6, [x2, #2]
	ldrh	w5, [x27, #2]
	cmp	w6, w5
	b.ne	LBB160_2
; %bb.5:                                ;   in Loop: Header=BB160_3 Depth=1
	ldrh	w5, [x2, #4]
	ldrh	w7, [x27, #4]
	cmp	w5, w7
	b.ne	LBB160_2
; %bb.6:                                ;   in Loop: Header=BB160_3 Depth=1
	ldrh	w7, [x2, #6]
	ldrh	w19, [x27, #6]
	cmp	w7, w19
	b.ne	LBB160_2
; %bb.7:                                ;   in Loop: Header=BB160_3 Depth=1
	ldrh	w7, [x2, #8]
	ldrh	w19, [x27, #8]
	cmp	w7, w19
	b.ne	LBB160_2
; %bb.8:                                ;   in Loop: Header=BB160_3 Depth=1
	cbz	w13, LBB160_13
; %bb.9:                                ;   in Loop: Header=BB160_3 Depth=1
	ldr	x7, [x2, #16]
	add	x7, x7, #16
	mov	x19, x12
	mov	x20, x13
LBB160_10:                              ;   Parent Loop BB160_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x21, [x7, #-16]
	ldur	x22, [x19, #-32]
	eor	x21, x22, x21
	tst	x21, #0xff
	b.ne	LBB160_2
; %bb.11:                               ;   in Loop: Header=BB160_10 Depth=2
	ldr	w22, [x19]
	ldr	w23, [x7, #16]
	ldur	x24, [x19, #-8]
	ldurb	w25, [x19, #-16]
	ldur	x30, [x19, #-24]
	ldr	x9, [x7, #8]
	ldrb	w10, [x7]
	ldur	x15, [x7, #-8]
	and	x21, x21, x17
	cmp	x21, #0
	ccmp	x15, x30, #0, eq
	ccmp	w10, w25, #0, eq
	ccmp	x9, x24, #0, eq
	ccmp	w23, w22, #0, eq
	b.ne	LBB160_2
; %bb.12:                               ;   in Loop: Header=BB160_10 Depth=2
	add	x7, x7, #40
	add	x19, x19, #40
	subs	x20, x20, #1
	b.ne	LBB160_10
LBB160_13:                              ;   in Loop: Header=BB160_3 Depth=1
	cbz	w6, LBB160_18
; %bb.14:                               ;   in Loop: Header=BB160_3 Depth=1
	ldr	x7, [x2, #24]
	add	x7, x7, #16
	ldr	x19, [sp, #56]                  ; 8-byte Folded Reload
LBB160_15:                              ;   Parent Loop BB160_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x9, [x7, #-16]
	ldur	x10, [x19, #-32]
	eor	x20, x10, x9
	tst	x20, #0xff
	b.ne	LBB160_2
; %bb.16:                               ;   in Loop: Header=BB160_15 Depth=2
	ldr	w9, [x19]
	ldr	w10, [x7, #16]
	ldur	x15, [x19, #-8]
	ldurb	w21, [x19, #-16]
	ldur	x22, [x19, #-24]
	ldr	x23, [x7, #8]
	ldrb	w24, [x7]
	ldur	x25, [x7, #-8]
	and	x20, x20, x17
	cmp	x20, #0
	ccmp	x25, x22, #0, eq
	ccmp	w24, w21, #0, eq
	ccmp	x23, x15, #0, eq
	ccmp	w10, w9, #0, eq
	b.ne	LBB160_2
; %bb.17:                               ;   in Loop: Header=BB160_15 Depth=2
	add	x7, x7, #40
	add	x19, x19, #40
	subs	x6, x6, #1
	b.ne	LBB160_15
LBB160_18:                              ;   in Loop: Header=BB160_3 Depth=1
	cbz	w5, LBB160_22
; %bb.19:                               ;   in Loop: Header=BB160_3 Depth=1
	ldr	x6, [x2, #40]
	ldr	x7, [sp, #48]                   ; 8-byte Folded Reload
LBB160_20:                              ;   Parent Loop BB160_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [x6], #8
	ldr	x10, [x7], #8
	cmp	x9, x10
	b.ne	LBB160_2
; %bb.21:                               ;   in Loop: Header=BB160_20 Depth=2
	subs	x5, x5, #1
	b.ne	LBB160_20
LBB160_22:                              ;   in Loop: Header=BB160_3 Depth=1
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	ldrh	w7, [x2, #48]
	b	LBB160_24
LBB160_23:                              ;   in Loop: Header=BB160_24 Depth=2
	add	x6, x6, #1
	add	x5, x5, #40
	cmp	x6, #256
	b.eq	LBB160_41
LBB160_24:                              ;   Parent Loop BB160_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x6, x7
	b.hs	LBB160_26
; %bb.25:                               ;   in Loop: Header=BB160_24 Depth=2
	ldr	x9, [x2, #32]
	add	x9, x9, x5
	ldrb	w25, [x9]
	ldrb	w24, [x9, #1]
	ldrh	w23, [x9, #2]
	ldp	x22, x21, [x9, #8]
	ldr	x20, [x9, #24]
	ldrb	w19, [x9, #32]
	b	LBB160_27
LBB160_26:                              ;   in Loop: Header=BB160_24 Depth=2
	mov	w19, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
LBB160_27:                              ;   in Loop: Header=BB160_24 Depth=2
	add	x30, x14, x5
	ldrb	w9, [x30]
	cmp	w25, w9
	b.ne	LBB160_2
; %bb.28:                               ;   in Loop: Header=BB160_24 Depth=2
	tbz	w25, #0, LBB160_23
; %bb.29:                               ;   in Loop: Header=BB160_24 Depth=2
	ldrh	w9, [x16, x5]
	ldrb	w10, [x30, #1]
	ldr	x15, [sp, #72]                  ; 8-byte Folded Reload
	add	x15, x15, x5
	ldp	x25, x4, [x15, #-8]
	ldr	x15, [x15, #8]
	ldrb	w30, [x30, #32]
	cmp	w24, w10
	ccmp	w23, w9, #0, eq
	ccmp	x22, x25, #0, eq
	ccmp	x21, x4, #0, eq
	ccmp	x20, x15, #0, eq
	ccmp	w19, w30, #0, eq
	b.eq	LBB160_23
	b	LBB160_2
LBB160_30:
	mov	w22, #0                         ; =0x0
	mov	w20, #30868                     ; =0x7894
	movk	w20, #1, lsl #16
	add	x8, x1, #16, lsl #12            ; =65536
	add	x19, x8, #2192
	mov	w8, #1                          ; =0x1
	mov	x9, x19
LBB160_31:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #40
	cmp	w10, #0
	csel	w22, w8, w22, ne
	add	x8, x8, #1
	cmp	x8, #257
	b.ne	LBB160_31
; %bb.32:
	cmp	w26, #16
	b.eq	LBB160_35
; %bb.33:
	ldr	w25, [x1, x20]
	cmp	w25, #1, lsl #12                ; =4096
	b.eq	LBB160_35
; %bb.34:
	ldr	w21, [x0, #28]
	cmp	w21, #16, lsl #12               ; =65536
	b.ne	LBB160_37
LBB160_35:
	mov	w8, #3                          ; =0x3
LBB160_36:
	mov	x0, x8
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB160_37:
	ldr	x10, [x0, #40]
	mov	w11, #16777216                  ; =0x1000000
	mov	w8, #3                          ; =0x3
	cmp	x10, x11
	b.hi	LBB160_36
; %bb.38:
	ldrh	w24, [x27]
	ldrh	w23, [x27, #2]
	add	x9, x23, x24
	and	x15, x22, #0xffff
	add	x12, x15, w22, uxth #2
	lsl	x14, x12, #3
	ldrh	w12, [x27, #4]
	lsl	x13, x12, #3
	mov	w12, #40                        ; =0x28
	umaddl	x9, w9, w12, x14
	add	x9, x9, x13
	add	x9, x9, #168
	sub	x11, x11, x10
	cmp	x9, x11
	b.hi	LBB160_36
; %bb.39:
	stp	x15, x14, [sp, #24]             ; 16-byte Folded Spill
	stp	x13, x1, [sp, #40]              ; 16-byte Folded Spill
	str	w3, [sp, #72]                   ; 4-byte Folded Spill
	add	x8, x10, x9
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	str	x8, [x0, #40]
	mov	w0, #1                          ; =0x1
	mov	x1, x9
	bl	_calloc
	cbz	x0, LBB160_43
; %bb.40:
	ldr	x8, [x27]
	str	x8, [x0]
	ldrh	w8, [x27, #8]
	strh	w8, [x0, #8]
	strh	w22, [x0, #48]
	add	x8, x0, #168
	add	x9, x24, x24, lsl #2
	lsl	x2, x9, #3
	add	x9, x23, x23, lsl #2
	lsl	x9, x9, #3
	add	x23, x8, x2
	add	x11, x23, x9
	stp	x11, x9, [sp, #8]               ; 16-byte Folded Spill
	stp	x8, x23, [x0, #16]
	mov	w9, #40                         ; =0x28
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	umaddl	x9, w10, w9, x11
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	stp	x11, x9, [x0, #32]
	mov	w9, #47248                      ; =0xb890
	ldr	x22, [sp, #48]                  ; 8-byte Folded Reload
	add	x1, x22, x9
	mov	x24, x0
	mov	x0, x8
	bl	_memcpy
	mov	w8, #57488                      ; =0xe090
	add	x1, x22, x8
	mov	x0, x23
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x1, x19
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	bl	_memcpy
	add	x8, x22, #19, lsl #12           ; =77824
	add	x1, x8, #144
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	bl	_memcpy
	ldr	x8, [x27]
	str	x8, [x24, #56]
	ldrh	w8, [x27, #8]
	strh	w8, [x24, #64]
	mov	w8, #65535                      ; =0xffff
	sturh	w8, [x24, #157]
	add	x8, x28, x26, lsl #3
	str	x24, [x8, #8]
	add	w8, w26, #1
	strb	w8, [x28]
	add	w9, w21, #1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	w9, [x8, #28]
	add	w8, w25, #1
	str	w8, [x22, x20]
	add	x8, x22, x25, lsl #2
	add	x8, x8, #19, lsl #12            ; =77824
	add	x9, x8, #2192
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	strh	w8, [x9]
	strb	w26, [x9, #2]
	strb	wzr, [x9, #3]
	b	LBB160_42
LBB160_41:
	mov	x26, x8
LBB160_42:
	mov	w8, #0                          ; =0x0
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	strb	w26, [x9]
	b	LBB160_36
LBB160_43:
	mov	w8, #4                          ; =0x4
	b	LBB160_36
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_fact
_file_ch_fact:                          ; @file_ch_fact
	.cfi_startproc
; %bb.0:
	mov	w9, #0                          ; =0x0
	ldrb	w8, [x1, #8]
	cmp	w8, #147
	b.gt	LBB161_4
; %bb.1:
	cmp	w8, #60
	b.gt	LBB161_8
; %bb.2:
	cmp	w8, #15
	b.eq	LBB161_14
; %bb.3:
	cmp	w8, #59
	b.eq	LBB161_14
	b	LBB161_15
LBB161_4:
	cmp	w8, #150
	b.gt	LBB161_11
; %bb.5:
	cmp	w8, #148
	b.eq	LBB161_17
; %bb.6:
	cmp	w8, #149
	b.ne	LBB161_15
; %bb.7:
	mov	w10, #65535                     ; =0xffff
	mov	w9, #2                          ; =0x2
	b	LBB161_19
LBB161_8:
	cmp	w8, #61
	b.eq	LBB161_18
; %bb.9:
	cmp	w8, #145
	b.ne	LBB161_15
; %bb.10:
	mov	w10, #65535                     ; =0xffff
	mov	w9, #6                          ; =0x6
	b	LBB161_19
LBB161_11:
	cmp	w8, #151
	b.eq	LBB161_14
; %bb.12:
	cmp	w8, #161
	b.ne	LBB161_15
; %bb.13:
	mov	w10, #65535                     ; =0xffff
	mov	w9, #3                          ; =0x3
	b	LBB161_19
LBB161_14:
	mov	w9, #5                          ; =0x5
LBB161_15:
	mov	w10, #65535                     ; =0xffff
	cmp	w8, #59
	b.ne	LBB161_19
; %bb.16:
	mov	w11, #1                         ; =0x1
	b	LBB161_20
LBB161_17:
	ldrh	w10, [x1, #16]
	mov	w9, #1                          ; =0x1
	b	LBB161_19
LBB161_18:
	mov	w10, #65535                     ; =0xffff
	mov	w9, #4                          ; =0x4
LBB161_19:
	cmp	w8, #15
	mov	w11, #151                       ; =0x97
	ccmp	w8, w11, #4, ne
	cset	w11, eq
LBB161_20:
	ldrb	w12, [x2, #20]
	cmp	w12, #1
	b.ne	LBB161_38
; %bb.21:
	ldr	w12, [x2, #32]
	cmp	w12, w9
	b.ne	LBB161_38
; %bb.22:
	ldrh	w9, [x2, #28]
	cmp	w10, w9
	b.ne	LBB161_38
; %bb.23:
	ldrb	w9, [x2, #22]
	cmp	w8, #146
	cset	w10, eq
	cmp	w9, w10
	b.ne	LBB161_38
; %bb.24:
	ldrb	w9, [x2, #21]
	cmp	w8, #61
	cset	w10, eq
	cmp	w9, w10
	b.ne	LBB161_38
; %bb.25:
	ldrh	w9, [x2, #24]
	ldrh	w10, [x2, #2]
	cmp	w9, w10
	b.ne	LBB161_38
; %bb.26:
	ldrh	w9, [x2, #26]
	ldrh	w10, [x2, #12]
	cmp	w9, w10
	b.ne	LBB161_38
; %bb.27:
	cmp	w8, #145
	ldrb	w9, [x2, #23]
	csinc	w10, w11, wzr, ne
	cmp	w9, w10
	b.ne	LBB161_38
; %bb.28:
	sub	sp, sp, #176
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	str	xzr, [sp, #80]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	str	q0, [sp, #32]
	cbz	w11, LBB161_39
; %bb.29:
	ldr	w8, [x1, #16]
	ldr	x13, [x0]
	ldr	w9, [x13, #24]
	cmp	w8, w9
	b.hs	LBB161_60
; %bb.30:
	mov	w9, #36                         ; =0x24
	umaddl	x10, w8, w9, x13
	mov	w9, #1                          ; =0x1
	ldr	w11, [x1]
	stp	w9, w11, [sp, #32]
	str	w8, [sp, #40]
	ldrh	w9, [x10, #60]
	strh	w9, [sp, #56]
	ldrb	w11, [x10, #64]
	strb	w11, [sp, #62]
	ldur	q0, [x10, #68]
	str	q0, [sp, #64]
	cbz	w9, LBB161_37
; %bb.31:
	mov	w11, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	ldr	x13, [x13]
	add	x14, x8, x8, lsl #1
	lsl	x14, x14, #3
	add	x15, x13, #26
	add	x16, x13, #1816
	add	x17, x13, #1560
LBB161_32:                              ; =>This Inner Loop Header: Depth=1
	cbz	x13, LBB161_60
; %bb.33:                               ;   in Loop: Header=BB161_32 Depth=1
	ldr	w0, [x13, #4]
	cmp	w8, w0
	b.hs	LBB161_60
; %bb.34:                               ;   in Loop: Header=BB161_32 Depth=1
	ldrh	w0, [x15, x14]
	cmp	w11, w0
	b.hs	LBB161_60
; %bb.35:                               ;   in Loop: Header=BB161_32 Depth=1
	ldr	w0, [x17, x8, lsl #2]
	add	w0, w11, w0
	add	x0, x16, w0, uxtw #4
	ldrb	w1, [x0, #1]
	lsl	x1, x1, #8
	ldr	w0, [x0, #12]
	sub	x0, x0, #1
	cmp	x1, #0
	cset	w1, eq
	cinc	w10, w10, ne
	cmp	x0, #2
	csel	w0, wzr, w1, hs
	add	w12, w12, w0
	add	w11, w11, #1
	cmp	w9, w11
	b.ne	LBB161_32
; %bb.36:
	strh	w12, [sp, #58]
	strh	w10, [sp, #60]
LBB161_37:
	mov	w22, #448                       ; =0x1c0
	str	w22, [sp, #44]
	mov	w8, #64                         ; =0x40
	b	LBB161_50
LBB161_38:
	mov	w0, #0                          ; =0x0
	ret
LBB161_39:
	cmp	w8, #145
	b.ne	LBB161_49
; %bb.40:
	mov	x21, x2
	mov	x22, x1
	ldr	w8, [x1, #592]
	mov	x19, x0
	mov	x0, x8
	bl	_nl_file_catalog_method
	cbz	x0, LBB161_60
; %bb.41:
	mov	x8, x19
	cbz	x19, LBB161_60
; %bb.42:
	mov	x20, x0
	ldr	x9, [x0, #56]
	cbz	x9, LBB161_60
; %bb.43:
	ldr	w1, [x22, #592]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	add	x2, sp, #28
	bl	_nvm_file_nominal_import
	cbz	w0, LBB161_60
; %bb.44:
	ldr	w8, [sp, #28]
	ldr	w9, [x22, #16]
	cmp	w8, w9
	b.ne	LBB161_60
; %bb.45:
	ldp	x8, x9, [x20, #48]
	mov	w10, #48                        ; =0x30
	madd	x8, x9, x10, x8
	ldur	x1, [x8, #-32]
	add	x8, sp, #32
	add	x2, x8, #32
	mov	x0, x19
	bl	_file_ch_member
	cbz	w0, LBB161_60
; %bb.46:
	ldr	w8, [x22]
	stp	wzr, w8, [sp, #32]
	ldr	w8, [sp, #28]
	str	w8, [sp, #40]
	ldr	x8, [x20, #56]
	sub	w9, w8, #1
	strh	w9, [sp, #56]
	ldr	w9, [x20, #64]
	cmp	w9, #2
	csel	w10, w9, wzr, eq
	cmp	w9, #1
	csinc	w10, w10, wzr, ne
	ldr	w9, [x20, #80]
	cmp	w9, #2
	csel	w11, w9, wzr, eq
	cmp	w9, #1
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #62]
	ldur	d0, [x20, #36]
	str	d0, [sp, #48]
	csinc	w11, w11, wzr, ne
	stp	w10, w11, [sp, #80]
	ldr	w10, [x20, #44]
	cmp	w10, #2
	b.eq	LBB161_53
; %bb.47:
	cmp	w10, #1
	b.ne	LBB161_54
; %bb.48:
	strh	w9, [sp, #60]
	mov	w22, #415                       ; =0x19f
	b	LBB161_55
LBB161_49:
	mov	w8, #0                          ; =0x0
	mov	w22, #128                       ; =0x80
LBB161_50:
	ldr	w9, [x2, #36]
	cmp	w9, w8
	b.ne	LBB161_60
; %bb.51:
	ldr	w9, [x2, #40]
	bic	w8, w22, w8
	cmp	w9, w8
	b.ne	LBB161_60
; %bb.52:
	add	x0, x2, #44
	add	x1, sp, #32
	bl	_obligation_same
	b	LBB161_61
LBB161_53:
	strh	w9, [sp, #58]
LBB161_54:
	mov	w22, #399                       ; =0x18f
LBB161_55:
	cmp	x8, #2
	b.lo	LBB161_59
; %bb.56:
	mov	x23, #0                         ; =0x0
	mov	w24, #1                         ; =0x1
	mov	x0, x19
LBB161_57:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #48]
	add	x8, x8, x23
	ldr	w25, [x8, #40]
	ldr	x1, [x8, #16]
	add	x2, sp, #12
	bl	_file_ch_member
	cbz	w0, LBB161_60
; %bb.58:                               ;   in Loop: Header=BB161_57 Depth=1
	orr	w8, w22, #0x20
	cmp	w25, #1
	csel	w22, w8, w22, eq
	add	x24, x24, #1
	ldr	x8, [x20, #56]
	add	x23, x23, #48
	cmp	x24, x8
	mov	x0, x19
	b.lo	LBB161_57
LBB161_59:
	mov	w8, #0                          ; =0x0
	str	w22, [sp, #44]
	mov	x2, x21
	b	LBB161_50
LBB161_60:
	mov	w0, #0                          ; =0x0
LBB161_61:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_supported_mode
_file_code_supported_mode:              ; @file_code_supported_mode
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cbz	w1, LBB162_8
; %bb.1:
	mov	w0, #1                          ; =0x1
	cmp	w8, #151
	b.gt	LBB162_5
; %bb.2:
	sub	w9, w8, #60
	cmp	w9, #8
	b.hi	LBB162_7
; %bb.3:
	mov	w10, #1                         ; =0x1
	lsl	w9, w10, w9
	mov	w10, #273                       ; =0x111
	tst	w9, w10
	b.eq	LBB162_7
LBB162_4:
	ret
LBB162_5:
	cmp	w8, #152
	b.eq	LBB162_4
; %bb.6:
	cmp	w8, #250
	b.eq	LBB162_4
	b	LBB162_8
LBB162_7:
	cmp	w8, #4
	b.eq	LBB162_4
LBB162_8:
	cmp	w8, #254
	b.hi	LBB162_10
; %bb.9:
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh214:
	adrp	x9, lJTI162_0@PAGE
Lloh215:
	add	x9, x9, lJTI162_0@PAGEOFF
	adr	x10, LBB162_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB162_10:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh214, Lloh215
	.cfi_endproc
	.section	__TEXT,__const
lJTI162_0:
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
	.byte	(LBB162_10-LBB162_4)>>2
	.byte	(LBB162_4-LBB162_4)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function file_ch_member
lCPI163_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
lCPI163_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI163_2:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI163_3:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_file_ch_member:                        ; @file_ch_member
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x1, LBB163_11
; %bb.1:
	mov	x20, x1
	mov	x21, x0
Lloh216:
	adrp	x1, l_.str@PAGE
Lloh217:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB163_12
; %bb.2:
Lloh218:
	adrp	x1, l_.str.1@PAGE
Lloh219:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB163_13
; %bb.3:
Lloh220:
	adrp	x1, l_.str.2@PAGE
Lloh221:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB163_15
; %bb.4:
	mov	x22, #0                         ; =0x0
	b	LBB163_6
LBB163_5:                               ;   in Loop: Header=BB163_6 Depth=1
	add	x22, x22, #1
	cmp	x22, #8
	b.eq	LBB163_14
LBB163_6:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x22
	bl	_nl_file_catalog_type
	cbz	x0, LBB163_5
; %bb.7:                                ;   in Loop: Header=BB163_6 Depth=1
	ldr	x0, [x0]
	mov	x1, x20
	bl	_strcmp
	cbz	x21, LBB163_5
; %bb.8:                                ;   in Loop: Header=BB163_6 Depth=1
	cbnz	w0, LBB163_5
; %bb.9:                                ;   in Loop: Header=BB163_6 Depth=1
	ldr	x8, [x21]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	add	x2, sp, #8
	mov	x1, x22
	bl	_nvm_file_nominal_type
	cbz	w0, LBB163_5
; %bb.10:
	ldrb	w8, [sp, #20]
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	cmp	w8, #0
	csel	w8, w10, w9, eq
	ldr	w9, [sp, #24]
	strb	w8, [x19]
	strb	wzr, [x19, #1]
	strh	wzr, [x19, #2]
	ldr	d0, [sp, #8]
	stur	d0, [x19, #4]
	str	w9, [x19, #12]
	b	LBB163_17
LBB163_11:
Lloh222:
	adrp	x8, lCPI163_3@PAGE
Lloh223:
	ldr	q0, [x8, lCPI163_3@PAGEOFF]
	b	LBB163_16
LBB163_12:
Lloh224:
	adrp	x8, lCPI163_2@PAGE
Lloh225:
	ldr	q0, [x8, lCPI163_2@PAGEOFF]
	b	LBB163_16
LBB163_13:
Lloh226:
	adrp	x8, lCPI163_1@PAGE
Lloh227:
	ldr	q0, [x8, lCPI163_1@PAGEOFF]
	b	LBB163_16
LBB163_14:
	mov	w0, #0                          ; =0x0
	b	LBB163_18
LBB163_15:
Lloh228:
	adrp	x8, lCPI163_0@PAGE
Lloh229:
	ldr	q0, [x8, lCPI163_0@PAGEOFF]
LBB163_16:
	str	q0, [x19]
LBB163_17:
	mov	w0, #1                          ; =0x1
LBB163_18:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpLdr	Lloh222, Lloh223
	.loh AdrpLdr	Lloh224, Lloh225
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpLdr	Lloh228, Lloh229
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_cfg
_file_code_cfg:                         ; @file_code_cfg
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #784
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh230:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh231:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh232:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #736]
	mov	w9, w1
	stp	q0, q0, [sp, #704]
	stp	q0, q0, [sp, #672]
	stp	q0, q0, [sp, #640]
	stp	q0, q0, [sp, #608]
	stp	q0, q0, [sp, #576]
	stp	q0, q0, [sp, #544]
	stp	q0, q0, [sp, #512]
	stp	q0, q0, [sp, #480]
	stp	q0, q0, [sp, #448]
	stp	q0, q0, [sp, #416]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #320]
	stp	q0, q0, [sp, #288]
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	add	x8, x9, w1, uxtw #3
	lsl	x10, x8, #2
	add	x11, x0, #56
	stp	q0, q0, [sp]
	ldrh	w5, [x11, x10]
	cbz	w5, LBB164_28
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x13, [x0, #16]
	add	x12, x0, #2352
	ldr	w14, [x12, x9, lsl #2]
	mov	w15, #36                        ; =0x24
	umaddl	x15, w9, w15, x0
	add	x16, x13, #74
	mov	w17, #600                       ; =0x258
	add	x1, sp, #256
	mov	x3, x14
	b	LBB164_3
LBB164_2:                               ;   in Loop: Header=BB164_3 Depth=1
	add	x8, x8, #1
	ldrh	w5, [x11, x10]
	add	w3, w3, #1
	cmp	x8, x5
	b.hs	LBB164_31
LBB164_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB164_9 Depth 2
                                        ;     Child Loop BB164_17 Depth 2
                                        ;     Child Loop BB164_24 Depth 2
	add	w4, w14, w8
	umaddl	x4, w4, w17, x13
	ldrb	w6, [x4, #8]
	subs	w19, w6, #56
	b.eq	LBB164_6
; %bb.4:                                ;   in Loop: Header=BB164_3 Depth=1
	cmp	w6, #61
	b.ne	LBB164_7
; %bb.5:                                ;   in Loop: Header=BB164_3 Depth=1
	ldrb	w5, [x4, #76]
	b	LBB164_20
LBB164_6:                               ;   in Loop: Header=BB164_3 Depth=1
	ldr	w7, [x4]
	ldrb	w5, [x4, #76]
	b	LBB164_13
LBB164_7:                               ;   in Loop: Header=BB164_3 Depth=1
	ldr	w7, [x4]
	ldr	w20, [x4, #64]
	ldur	w21, [x15, #52]
	add	x20, x20, x7
	cmp	x20, x21
	and	w21, w5, #0xffff
	ccmp	w21, #0, #4, lo
	b.eq	LBB164_27
; %bb.8:                                ;   in Loop: Header=BB164_3 Depth=1
	mov	x23, #0                         ; =0x0
	add	x22, x4, #72
	ldrb	w21, [x4, #76]
	sub	x5, x23, w5, uxth
	mov	x24, x14
LBB164_9:                               ;   Parent Loop BB164_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umull	x25, w24, w17
	ldr	w25, [x13, x25]
	cmp	w25, w20
	b.eq	LBB164_11
; %bb.10:                               ;   in Loop: Header=BB164_9 Depth=2
	sub	x23, x23, #1
	add	w24, w24, #1
	cmp	x5, x23
	b.ne	LBB164_9
	b	LBB164_27
LBB164_11:                              ;   in Loop: Header=BB164_3 Depth=1
	neg	w5, w23
	strh	w5, [x22, x21, lsl #1]
	add	w5, w21, #1
	strb	w5, [x4, #76]
	cmp	w19, #3
	b.lo	LBB164_13
; %bb.12:                               ;   in Loop: Header=BB164_3 Depth=1
	cmp	w6, #146
	b.ne	LBB164_20
LBB164_13:                              ;   in Loop: Header=BB164_3 Depth=1
	cmp	w6, #146
	cset	w6, eq
	add	x6, x4, w6, uxtw #3
	ldrsw	x6, [x6, #16]
	adds	x6, x7, x6
	b.mi	LBB164_27
; %bb.14:                               ;   in Loop: Header=BB164_3 Depth=1
	ldur	w7, [x15, #52]
	cmp	x6, x7
	b.hs	LBB164_27
; %bb.15:                               ;   in Loop: Header=BB164_3 Depth=1
	ldurh	w20, [x15, #56]
	cbz	x20, LBB164_27
; %bb.16:                               ;   in Loop: Header=BB164_3 Depth=1
	mov	x19, #0                         ; =0x0
	add	x7, x4, #72
                                        ; kill: def $w5 killed $w5 killed $x5 def $x5
	and	x5, x5, #0xff
	neg	x20, x20
	mov	x21, x14
LBB164_17:                              ;   Parent Loop BB164_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umull	x22, w21, w17
	ldr	w22, [x13, x22]
	cmp	w22, w6
	b.eq	LBB164_19
; %bb.18:                               ;   in Loop: Header=BB164_17 Depth=2
	sub	x19, x19, #1
	add	w21, w21, #1
	cmp	x20, x19
	b.ne	LBB164_17
	b	LBB164_27
LBB164_19:                              ;   in Loop: Header=BB164_3 Depth=1
	neg	w6, w19
	strh	w6, [x7, x5, lsl #1]
	add	w5, w5, #1
	strb	w5, [x4, #76]
LBB164_20:                              ;   in Loop: Header=BB164_3 Depth=1
	tst	w5, #0xff
	b.eq	LBB164_2
; %bb.21:                               ;   in Loop: Header=BB164_3 Depth=1
	and	x6, x5, #0xff
	and	w5, w5, #0xff
	cmp	w5, #1
	b.ne	LBB164_23
; %bb.22:                               ;   in Loop: Header=BB164_3 Depth=1
	mov	x5, #0                          ; =0x0
	b	LBB164_25
LBB164_23:                              ;   in Loop: Header=BB164_3 Depth=1
	mov	x5, #0                          ; =0x0
	umaddl	x7, w3, w17, x16
	and	x19, x6, #0xfe
LBB164_24:                              ;   Parent Loop BB164_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w20, [x7, #-2]
	ldrh	w21, [x1, x20, lsl #1]
	add	w21, w21, #1
	strh	w21, [x1, x20, lsl #1]
	ldrh	w20, [x7], #4
	ldrh	w21, [x1, x20, lsl #1]
	add	w21, w21, #1
	strh	w21, [x1, x20, lsl #1]
	add	x5, x5, #2
	cmp	x19, x5
	b.ne	LBB164_24
LBB164_25:                              ;   in Loop: Header=BB164_3 Depth=1
	tbz	w6, #0, LBB164_2
; %bb.26:                               ;   in Loop: Header=BB164_3 Depth=1
	add	x4, x4, #72
	ldrh	w4, [x4, x5, lsl #1]
	ldrh	w5, [x1, x4, lsl #1]
	add	w5, w5, #1
	strh	w5, [x1, x4, lsl #1]
	b	LBB164_2
LBB164_27:
	mov	w8, #1                          ; =0x1
	b	LBB164_29
LBB164_28:
	mov	w8, #0                          ; =0x0
LBB164_29:
	ldur	x9, [x29, #-72]
Lloh233:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh234:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh235:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB164_46
; %bb.30:
	mov	x0, x8
	add	sp, sp, #784
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB164_31:
	mov	w8, #0                          ; =0x0
	cbz	w5, LBB164_29
; %bb.32:
	cbz	w2, LBB164_29
; %bb.33:
	mov	w13, #0                         ; =0x0
	add	x14, x0, #2864
	mov	x15, sp
	add	x16, sp, #256
	mov	w17, #1                         ; =0x1
	mov	w1, #600                        ; =0x258
LBB164_34:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB164_36 Depth 2
                                        ;     Child Loop BB164_42 Depth 2
	mov	w2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	and	w8, w5, #0xffff
	tst	w5, #0xfffe
	csinc	w4, w8, wzr, ne
	b	LBB164_36
LBB164_35:                              ;   in Loop: Header=BB164_36 Depth=2
	add	x3, x3, #1
	add	w2, w2, #1
	mov	w8, #2                          ; =0x2
	cmp	x4, x3
	b.eq	LBB164_29
LBB164_36:                              ;   Parent Loop BB164_34 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [x15, x3]
	tbnz	w8, #0, LBB164_35
; %bb.37:                               ;   in Loop: Header=BB164_36 Depth=2
	ldrh	w8, [x16, x3, lsl #1]
	cbnz	w8, LBB164_35
; %bb.38:                               ;   in Loop: Header=BB164_34 Depth=1
	strb	w17, [x15, x3]
	ldr	w6, [x12, x9, lsl #2]
	add	w8, w6, w13
	strh	w3, [x14, w8, uxtw #1]
	ldr	x7, [x0, #16]
	add	w8, w6, w3
	umaddl	x8, w8, w1, x7
	ldrb	w3, [x8, #76]
	cbz	w3, LBB164_45
; %bb.39:                               ;   in Loop: Header=BB164_34 Depth=1
	cmp	w3, #1
	b.ne	LBB164_41
; %bb.40:                               ;   in Loop: Header=BB164_34 Depth=1
	mov	x4, #0                          ; =0x0
	b	LBB164_43
LBB164_41:                              ;   in Loop: Header=BB164_34 Depth=1
	mov	x4, #0                          ; =0x0
	and	x5, x3, #0xfe
	add	w2, w6, w2
	umaddl	x2, w2, w1, x7
	add	x2, x2, #74
LBB164_42:                              ;   Parent Loop BB164_34 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w6, [x2, #-2]
	ldrh	w7, [x16, x6, lsl #1]
	sub	w7, w7, #1
	strh	w7, [x16, x6, lsl #1]
	ldrh	w6, [x2], #4
	ldrh	w7, [x16, x6, lsl #1]
	sub	w7, w7, #1
	strh	w7, [x16, x6, lsl #1]
	add	x4, x4, #2
	cmp	x5, x4
	b.ne	LBB164_42
LBB164_43:                              ;   in Loop: Header=BB164_34 Depth=1
	tbz	w3, #0, LBB164_45
; %bb.44:                               ;   in Loop: Header=BB164_34 Depth=1
	add	x8, x8, #72
	ldrh	w8, [x8, x4, lsl #1]
	ldrh	w2, [x16, x8, lsl #1]
	sub	w2, w2, #1
	strh	w2, [x16, x8, lsl #1]
LBB164_45:                              ;   in Loop: Header=BB164_34 Depth=1
	mov	w8, #0                          ; =0x0
	add	w13, w13, #1
	ldrh	w5, [x11, x10]
	cmp	w13, w5
	b.lo	LBB164_34
	b	LBB164_29
LBB164_46:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh230, Lloh231, Lloh232
	.loh AdrpLdrGotLdr	Lloh233, Lloh234, Lloh235
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_candidates
_fi_candidates:                         ; @fi_candidates
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x1, #2]
	cbz	x8, LBB165_7
; %bb.1:
	sub	w8, w8, #1
	add	x8, x1, x8, lsl #5
	mov	w9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldrb	w9, [x8, #24]
	cmp	w9, #2
	b.ne	LBB165_8
; %bb.2:
	ldr	x9, [x8]
	mov	x10, #-65525                    ; =0xffffffffffff000b
	movk	x10, #0, lsl #16
	eor	x10, x9, x10
	tst	x10, #0xff
	b.ne	LBB165_8
; %bb.3:
	mov	x9, #-256                       ; =0xffffffffffffff00
	movk	x9, #0, lsl #16
	ldr	x11, [x8, #8]
	and	x10, x10, x9
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB165_8
; %bb.4:
	ldr	x8, [x8, #16]
	cbz	x8, LBB165_8
; %bb.5:
	ldr	w10, [x0, #24]
	cmp	w10, #63
	b.hi	LBB165_9
; %bb.6:
	lsr	x11, x8, x10
	cbz	x11, LBB165_9
LBB165_7:
	mov	w0, #1                          ; =0x1
	ret
LBB165_8:
	mov	w0, #2                          ; =0x2
	ret
LBB165_9:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	cbz	x10, LBB165_34
; %bb.10:
	mov	x11, #0                         ; =0x0
	add	x12, x0, #60
	add	x13, x2, #78
	add	x14, x0, #48
	mov	w15, #36                        ; =0x24
	mov	w16, #65535                     ; =0xffff
	mov	x17, x10
LBB165_11:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB165_18 Depth 2
                                        ;     Child Loop BB165_29 Depth 2
	lsr	x1, x8, x11
	tbz	w1, #0, LBB165_32
; %bb.12:                               ;   in Loop: Header=BB165_11 Depth=1
	add	x1, x11, x11, lsl #3
	lsl	x5, x1, #2
	add	x6, x12, x5
	ldrh	w1, [x6]
	ldrh	w7, [x2, #16]
	cmp	w1, w7
	b.ne	LBB165_37
; %bb.13:                               ;   in Loop: Header=BB165_11 Depth=1
	ldrb	w6, [x6, #4]
	ldrh	w7, [x2, #24]
	cmp	w7, w6
	b.ne	LBB165_37
; %bb.14:                               ;   in Loop: Header=BB165_11 Depth=1
	cbz	w1, LBB165_22
; %bb.15:                               ;   in Loop: Header=BB165_11 Depth=1
	ldr	x19, [x0]
	add	x7, x19, x11, lsl #2
	ldr	w7, [x7, #1560]
	add	x19, x19, #1817
	ldrb	w20, [x2, #8]
	mov	x21, x1
	mov	x22, x13
	b	LBB165_18
LBB165_16:                              ;   in Loop: Header=BB165_18 Depth=2
	cbnz	w23, LBB165_36
LBB165_17:                              ;   in Loop: Header=BB165_18 Depth=2
	add	w7, w7, #1
	add	x22, x22, #2
	subs	x21, x21, #1
	b.eq	LBB165_22
LBB165_18:                              ;   Parent Loop BB165_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ubfiz	x23, x7, #4, #32
	ldrb	w23, [x19, x23]
	cmp	w20, #152
	b.ne	LBB165_16
; %bb.19:                               ;   in Loop: Header=BB165_18 Depth=2
	ldrh	w24, [x22]
	cbz	w23, LBB165_21
; %bb.20:                               ;   in Loop: Header=BB165_18 Depth=2
	cmp	w24, #255
	b.ls	LBB165_17
	b	LBB165_37
LBB165_21:                              ;   in Loop: Header=BB165_18 Depth=2
	cmp	w24, w16
	b.eq	LBB165_17
	b	LBB165_37
LBB165_22:                              ;   in Loop: Header=BB165_11 Depth=1
	mov	x7, x11
	cmp	x17, x10
	b.eq	LBB165_33
; %bb.23:                               ;   in Loop: Header=BB165_11 Depth=1
	madd	x7, x17, x15, x14
	ldrh	w19, [x7, #12]
	cmp	w19, w1
	b.ne	LBB165_36
; %bb.24:                               ;   in Loop: Header=BB165_11 Depth=1
	ldrb	w19, [x7, #16]
	cmp	w19, w6
	b.ne	LBB165_36
; %bb.25:                               ;   in Loop: Header=BB165_11 Depth=1
	add	x5, x14, x5
	ldur	x6, [x7, #20]
	ldur	x19, [x5, #20]
	eor	x6, x19, x6
	tst	x6, #0xff
	b.ne	LBB165_36
; %bb.26:                               ;   in Loop: Header=BB165_11 Depth=1
	ldur	x5, [x5, #28]
	ldur	x7, [x7, #28]
	and	x6, x6, x9
	cmp	x6, #0
	ccmp	x7, x5, #0, eq
	b.ne	LBB165_36
; %bb.27:                               ;   in Loop: Header=BB165_11 Depth=1
	cbz	w1, LBB165_32
; %bb.28:                               ;   in Loop: Header=BB165_11 Depth=1
	ldr	x6, [x0]
	add	x5, x6, #1816
	add	x7, x6, #1560
	ldr	w6, [x7, x17, lsl #2]
	ldr	w7, [x7, x11, lsl #2]
LBB165_29:                              ;   Parent Loop BB165_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x19, x5, w6, uxtw #4
	add	x20, x5, w7, uxtw #4
	ldr	x21, [x19]
	ldr	x22, [x20]
	eor	x21, x22, x21
	tst	x21, #0xff
	b.ne	LBB165_36
; %bb.30:                               ;   in Loop: Header=BB165_29 Depth=2
	ldr	x20, [x20, #8]
	ldr	x19, [x19, #8]
	and	x21, x21, x9
	cmp	x21, #0
	ccmp	x19, x20, #0, eq
	b.ne	LBB165_36
; %bb.31:                               ;   in Loop: Header=BB165_29 Depth=2
	add	w7, w7, #1
	add	w6, w6, #1
	subs	x1, x1, #1
	b.ne	LBB165_29
LBB165_32:                              ;   in Loop: Header=BB165_11 Depth=1
	mov	x7, x17
LBB165_33:                              ;   in Loop: Header=BB165_11 Depth=1
	add	x11, x11, #1
	mov	x17, x7
	cmp	x11, x10
	b.ne	LBB165_11
	b	LBB165_35
LBB165_34:
	mov	x7, #0                          ; =0x0
LBB165_35:
	mov	w0, #0                          ; =0x0
	str	x8, [x3]
	str	w7, [x4]
	b	LBB165_38
LBB165_36:
	mov	w0, #2                          ; =0x2
	b	LBB165_38
LBB165_37:
	mov	w0, #1                          ; =0x1
LBB165_38:
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_take
_fi_take:                               ; @fi_take
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x0, #2]
	cbz	x8, LBB166_4
; %bb.1:
	sub	w9, w8, #1
	add	x9, x0, x9, lsl #5
	mov	w10, #8200                      ; =0x2008
	add	x9, x9, x10
	ldrb	w10, [x9, #24]
	cmp	w10, #2
	b.ne	LBB166_4
; %bb.2:
	ldr	x10, [x9]
	eor	x10, x10, x1
	tst	x10, #0xff
	b.ne	LBB166_4
; %bb.3:
	ldr	x11, [x9, #8]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	ccmp	x11, x2, #0, eq
	b.eq	LBB166_5
LBB166_4:
	mov	w0, #1                          ; =0x1
	ret
LBB166_5:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	sub	w8, w8, #1
	strh	w8, [x0, #2]
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function fi_member
lCPI167_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
lCPI167_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI167_2:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI167_3:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_fi_member:                             ; @fi_member
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x1, LBB167_21
; %bb.1:
	mov	x21, x1
	mov	x20, x0
Lloh236:
	adrp	x1, l_.str@PAGE
Lloh237:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB167_22
; %bb.2:
Lloh238:
	adrp	x1, l_.str.1@PAGE
Lloh239:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB167_23
; %bb.3:
Lloh240:
	adrp	x1, l_.str.2@PAGE
Lloh241:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB167_24
; %bb.4:
	mov	x0, #0                          ; =0x0
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_6
; %bb.5:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_27
LBB167_6:
	mov	w0, #1                          ; =0x1
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_8
; %bb.7:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_28
LBB167_8:
	mov	w0, #2                          ; =0x2
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_10
; %bb.9:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_29
LBB167_10:
	mov	w0, #3                          ; =0x3
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_12
; %bb.11:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_30
LBB167_12:
	mov	w0, #4                          ; =0x4
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_14
; %bb.13:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_31
LBB167_14:
	mov	w0, #5                          ; =0x5
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_16
; %bb.15:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_32
LBB167_16:
	mov	w0, #6                          ; =0x6
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_18
; %bb.17:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_33
LBB167_18:
	mov	w0, #7                          ; =0x7
	bl	_nl_file_catalog_type
	cbz	x0, LBB167_20
; %bb.19:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB167_34
LBB167_20:
	mov	w8, #0                          ; =0x0
                                        ; implicit-def: $w0
	b	LBB167_38
LBB167_21:
Lloh242:
	adrp	x8, lCPI167_3@PAGE
Lloh243:
	ldr	q0, [x8, lCPI167_3@PAGEOFF]
	b	LBB167_25
LBB167_22:
Lloh244:
	adrp	x8, lCPI167_2@PAGE
Lloh245:
	ldr	q0, [x8, lCPI167_2@PAGEOFF]
	b	LBB167_25
LBB167_23:
Lloh246:
	adrp	x8, lCPI167_1@PAGE
Lloh247:
	ldr	q0, [x8, lCPI167_1@PAGEOFF]
	b	LBB167_25
LBB167_24:
Lloh248:
	adrp	x8, lCPI167_0@PAGE
Lloh249:
	ldr	q0, [x8, lCPI167_0@PAGEOFF]
LBB167_25:
	str	q0, [x19]
	mov	w0, #1                          ; =0x1
LBB167_26:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB167_27:
	mov	w1, #0                          ; =0x0
	b	LBB167_35
LBB167_28:
	mov	w1, #1                          ; =0x1
	b	LBB167_35
LBB167_29:
	mov	w1, #2                          ; =0x2
	b	LBB167_35
LBB167_30:
	mov	w1, #3                          ; =0x3
	b	LBB167_35
LBB167_31:
	mov	w1, #4                          ; =0x4
	b	LBB167_35
LBB167_32:
	mov	w1, #5                          ; =0x5
	b	LBB167_35
LBB167_33:
	mov	w1, #6                          ; =0x6
	b	LBB167_35
LBB167_34:
	mov	w1, #7                          ; =0x7
LBB167_35:
	ldr	x8, [x20]
	ldr	x0, [x8, #16]
	add	x2, sp, #8
	bl	_nvm_file_nominal_type
	cbz	w0, LBB167_37
; %bb.36:
	ldrb	w8, [sp, #20]
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	cmp	w8, #0
	csel	w8, w10, w9, eq
	ldr	w9, [sp, #24]
	strb	w8, [x19]
	strb	wzr, [x19, #1]
	strh	wzr, [x19, #2]
	ldr	d0, [sp, #8]
	stur	d0, [x19, #4]
	str	w9, [x19, #12]
LBB167_37:
	mov	w8, #1                          ; =0x1
LBB167_38:
	and	w0, w8, w0
	b	LBB167_26
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpLdr	Lloh248, Lloh249
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_call
_fi_call:                               ; @fi_call
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	ldr	x8, [x0]
	mov	w9, #36                         ; =0x24
	umaddl	x9, w3, w9, x8
	ldrh	w10, [x9, #60]!
	cbz	w10, LBB168_14
; %bb.1:
	mov	w11, #8184                      ; =0x1ff8
	add	x11, x1, x11
	mov	w12, #8200                      ; =0x2008
	add	x12, x1, x12
	add	x13, x0, #552
	sub	w14, w10, #1
	mov	x15, #-256                      ; =0xffffffffffffff00
	movk	x15, #0, lsl #16
	movi.2d	v0, #0000000000000000
	mov	w16, w3
	b	LBB168_3
LBB168_2:                               ;   in Loop: Header=BB168_3 Depth=1
	sub	w14, w14, #1
	and	w17, w10, #0xffff
	cbz	w17, LBB168_14
LBB168_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB168_12 Depth 2
	ldr	x17, [x8]
	add	x3, x17, x16, lsl #2
	ldr	w3, [x3, #1560]
	sub	w10, w10, #1
	add	w3, w10, w3
	add	x17, x17, w3, uxtw #4
	ldr	x3, [x17, #1816]
	tst	x3, #0xff00
	b.ne	LBB168_2
; %bb.4:                                ;   in Loop: Header=BB168_3 Depth=1
	ldrh	w5, [x1, #2]
	cbz	x5, LBB168_21
; %bb.5:                                ;   in Loop: Header=BB168_3 Depth=1
	sub	w6, w5, #1
	add	x6, x12, x6, lsl #5
	ldrb	w7, [x6, #24]
	cmp	w7, #2
	b.ne	LBB168_21
; %bb.6:                                ;   in Loop: Header=BB168_3 Depth=1
	ldr	x7, [x6]
	eor	x7, x7, x3
	tst	x7, #0xff
	b.ne	LBB168_21
; %bb.7:                                ;   in Loop: Header=BB168_3 Depth=1
	ldr	x17, [x17, #1824]
	ldr	x19, [x6, #8]
	and	x7, x7, x15
	cmp	x7, #0
	ccmp	x19, x17, #0, eq
	b.ne	LBB168_21
; %bb.8:                                ;   in Loop: Header=BB168_3 Depth=1
	lsl	x17, x5, #5
	ldr	x17, [x11, x17]
	stp	q0, q0, [x6]
	sub	w5, w5, #1
	strh	w5, [x1, #2]
	and	x3, x3, #0xff
	cmp	x3, #11
	b.ne	LBB168_2
; %bb.9:                                ;   in Loop: Header=BB168_3 Depth=1
	ldr	w3, [x8, #24]
	cbz	w3, LBB168_2
; %bb.10:                               ;   in Loop: Header=BB168_3 Depth=1
	mov	x5, #0                          ; =0x0
	add	x6, x13, w14, uxtw #3
	b	LBB168_12
LBB168_11:                              ;   in Loop: Header=BB168_12 Depth=2
	add	x5, x5, #1
	add	x6, x6, #2048
	cmp	x3, x5
	b.eq	LBB168_2
LBB168_12:                              ;   Parent Loop BB168_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x7, x2, x5
	tbz	w7, #0, LBB168_11
; %bb.13:                               ;   in Loop: Header=BB168_12 Depth=2
	ldr	x7, [x6]
	orr	x19, x7, x17
	cmp	x19, x7
	cset	w7, ne
	ldrb	w20, [x4]
	orr	w7, w20, w7
	strb	w7, [x4]
	str	x19, [x6]
	b	LBB168_11
LBB168_14:
	ldrb	w10, [x9, #4]
	cbz	w10, LBB168_25
; %bb.15:
	ldp	x11, x9, [x9, #8]
	lsr	x10, x9, #33
	cmp	x10, #1
	mov	w10, #3                         ; =0x3
	csel	w10, w10, wzr, eq
	and	x12, x11, #0xff
	cmp	x12, #11
	b.ne	LBB168_22
; %bb.16:
	ldr	w12, [x8, #24]
	cbz	w12, LBB168_22
; %bb.17:
	mov	x13, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	add	x14, x0, #32, lsl #12           ; =131072
	add	x14, x14, #552
	b	LBB168_19
LBB168_18:                              ;   in Loop: Header=BB168_19 Depth=1
	add	x13, x13, #1
	cmp	x12, x13
	b.eq	LBB168_23
LBB168_19:                              ; =>This Inner Loop Header: Depth=1
	lsr	x15, x2, x13
	tbz	w15, #0, LBB168_18
; %bb.20:                               ;   in Loop: Header=BB168_19 Depth=1
	ldr	x15, [x14, x13, lsl #3]
	orr	x8, x15, x8
	b	LBB168_18
LBB168_21:
	mov	w0, #1                          ; =0x1
	ldp	x20, x19, [sp], #16             ; 16-byte Folded Reload
	ret
LBB168_22:
	mov	x8, #0                          ; =0x0
LBB168_23:
	ldrh	w12, [x1, #2]
	cmp	x12, #256
	b.ne	LBB168_26
; %bb.24:
	mov	w0, #3                          ; =0x3
	ldp	x20, x19, [sp], #16             ; 16-byte Folded Reload
	ret
LBB168_25:
	mov	w0, #0                          ; =0x0
	ldp	x20, x19, [sp], #16             ; 16-byte Folded Reload
	ret
LBB168_26:
	mov	w0, #0                          ; =0x0
	add	w13, w12, #1
	strh	w13, [x1, #2]
	add	x12, x1, x12, lsl #5
	str	x11, [x12, #8200]
	mov	w11, #8200                      ; =0x2008
	str	x9, [x12, #8208]
	add	x9, x12, x11
	str	x8, [x12, #8216]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #24]
	strb	w10, [x9, #25]
	stur	wzr, [x9, #26]
	strh	wzr, [x9, #30]
	ldp	x20, x19, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_equal
_file_cyclic_equal:                     ; @file_cyclic_equal
	.cfi_startproc
; %bb.0:
	ldrh	w10, [x0]
	ldrh	w8, [x1]
	cmp	w10, w8
	b.ne	LBB169_29
; %bb.1:
	ldrh	w9, [x0, #2]
	ldrh	w8, [x1, #2]
	cmp	w9, w8
	b.ne	LBB169_29
; %bb.2:
	ldrh	w8, [x0, #4]
	ldrh	w11, [x1, #4]
	cmp	w8, w11
	b.ne	LBB169_29
; %bb.3:
	ldrh	w11, [x0, #6]
	ldrh	w12, [x1, #6]
	cmp	w11, w12
	b.ne	LBB169_29
; %bb.4:
	ldrh	w11, [x0, #8]
	ldrh	w12, [x1, #8]
	cmp	w11, w12
	b.ne	LBB169_29
; %bb.5:
	cbz	w10, LBB169_10
; %bb.6:
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	add	x12, x0, #48
	add	x13, x1, #24
LBB169_7:                               ; =>This Inner Loop Header: Depth=1
	ldur	x14, [x12, #-32]
	ldur	x15, [x13, #-8]
	eor	x14, x15, x14
	tst	x14, #0xff
	b.ne	LBB169_29
; %bb.8:                                ;   in Loop: Header=BB169_7 Depth=1
	ldr	w15, [x13, #24]
	ldr	w16, [x12]
	ldr	x17, [x13, #16]
	ldrb	w2, [x13, #8]
	ldr	x3, [x13], #40
	ldur	x4, [x12, #-8]
	ldurb	w5, [x12, #-16]
	ldur	x6, [x12, #-24]
	and	x14, x14, x11
	cmp	x14, #0
	ccmp	x6, x3, #0, eq
	ccmp	w5, w2, #0, eq
	ccmp	x4, x17, #0, eq
	ccmp	w16, w15, #0, eq
	b.ne	LBB169_29
; %bb.9:                                ;   in Loop: Header=BB169_7 Depth=1
	add	x12, x12, #40
	subs	x10, x10, #1
	b.ne	LBB169_7
LBB169_10:
	cbz	w9, LBB169_15
; %bb.11:
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	mov	w12, #10288                     ; =0x2830
	add	x11, x0, x12
	add	x12, x1, x12
LBB169_12:                              ; =>This Inner Loop Header: Depth=1
	ldur	x13, [x11, #-32]
	ldur	x14, [x12, #-32]
	eor	x13, x14, x13
	tst	x13, #0xff
	b.ne	LBB169_29
; %bb.13:                               ;   in Loop: Header=BB169_12 Depth=1
	ldr	w14, [x12]
	ldr	w15, [x11]
	ldur	x16, [x12, #-8]
	ldurb	w17, [x12, #-16]
	ldur	x2, [x12, #-24]
	ldur	x3, [x11, #-8]
	ldurb	w4, [x11, #-16]
	ldur	x5, [x11, #-24]
	and	x13, x13, x10
	cmp	x13, #0
	ccmp	x5, x2, #0, eq
	ccmp	w4, w17, #0, eq
	ccmp	x3, x16, #0, eq
	ccmp	w15, w14, #0, eq
	b.ne	LBB169_29
; %bb.14:                               ;   in Loop: Header=BB169_12 Depth=1
	add	x11, x11, #40
	add	x12, x12, #40
	subs	x9, x9, #1
	b.ne	LBB169_12
LBB169_15:
	cbz	w8, LBB169_19
; %bb.16:
	mov	w10, #30736                     ; =0x7810
	add	x9, x0, x10
	add	x10, x1, x10
LBB169_17:                              ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x9], #8
	ldr	x12, [x10], #8
	cmp	x11, x12
	b.ne	LBB169_29
; %bb.18:                               ;   in Loop: Header=BB169_17 Depth=1
	subs	x8, x8, #1
	b.ne	LBB169_17
LBB169_19:
	mov	x9, #0                          ; =0x0
	mov	w8, #20496                      ; =0x5010
	add	x10, x0, x8
	mov	w8, #20498                      ; =0x5012
	add	x11, x0, x8
	add	x12, x1, x8
	mov	w8, #20528                      ; =0x5030
	add	x13, x1, x8
	mov	w14, #256                       ; =0x100
	b	LBB169_21
LBB169_20:                              ;   in Loop: Header=BB169_21 Depth=1
	add	x9, x9, #40
	mov	w8, #1                          ; =0x1
	subs	x14, x14, #1
	b.eq	LBB169_30
LBB169_21:                              ; =>This Inner Loop Header: Depth=1
	add	x15, x10, x9
	add	x16, x13, x9
	ldrb	w8, [x15]
	ldurb	w17, [x16, #-32]
	cmp	w8, w17
	b.ne	LBB169_29
; %bb.22:                               ;   in Loop: Header=BB169_21 Depth=1
	tbz	w8, #0, LBB169_20
; %bb.23:                               ;   in Loop: Header=BB169_21 Depth=1
	mov	w8, #0                          ; =0x0
	ldrb	w17, [x15, #1]
	ldurb	w2, [x16, #-31]
	cmp	w17, w2
	b.ne	LBB169_30
; %bb.24:                               ;   in Loop: Header=BB169_21 Depth=1
	ldrh	w17, [x11, x9]
	ldrh	w2, [x12, x9]
	cmp	w17, w2
	b.ne	LBB169_30
; %bb.25:                               ;   in Loop: Header=BB169_21 Depth=1
	add	x17, x0, x9
	ldr	x3, [x17, #20504]
	add	x2, x1, x9
	ldr	x4, [x2, #20504]
	cmp	x3, x4
	b.ne	LBB169_30
; %bb.26:                               ;   in Loop: Header=BB169_21 Depth=1
	ldr	x3, [x17, #20512]
	ldr	x4, [x2, #20512]
	cmp	x3, x4
	b.ne	LBB169_30
; %bb.27:                               ;   in Loop: Header=BB169_21 Depth=1
	ldr	x17, [x17, #20520]
	ldr	x2, [x2, #20520]
	cmp	x17, x2
	b.ne	LBB169_30
; %bb.28:                               ;   in Loop: Header=BB169_21 Depth=1
	ldrb	w15, [x15, #32]
	ldrb	w16, [x16]
	cmp	w15, w16
	b.eq	LBB169_20
	b	LBB169_30
LBB169_29:
	mov	w8, #0                          ; =0x0
LBB169_30:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fif_state_metadata_equal
_fif_state_metadata_equal:              ; @fif_state_metadata_equal
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0, #24]
	ldr	x9, [x1, #24]
	cmp	x8, x9
	b.ne	LBB170_20
; %bb.1:
	ldrb	w8, [x0, #40]
	ldrb	w9, [x1, #40]
	cmp	w8, w9
	b.ne	LBB170_20
; %bb.2:
	ldr	x8, [x0, #32]
	ldr	x9, [x1, #32]
	cmp	x8, x9
	b.ne	LBB170_20
; %bb.3:
	ldrh	w8, [x0, #16]
	ldrh	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB170_20
; %bb.4:
	cbz	w8, LBB170_21
; %bb.5:
	mov	x9, #0                          ; =0x0
	lsl	x10, x8, #6
	sub	x10, x10, x8, lsl #3
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
LBB170_6:                               ; =>This Inner Loop Header: Depth=1
	mov	w8, #0                          ; =0x0
	add	x12, x0, x9
	add	x13, x1, x9
	ldp	w14, w15, [x12, #60]
	ldrh	w16, [x12, #68]
	and	w16, w16, #0xffff
	ldrh	w17, [x12, #70]
	and	w17, w17, #0xffff
	ldrh	w2, [x12, #72]
	and	w2, w2, #0xffff
	ldp	w3, w4, [x13, #60]
	ldrh	w5, [x13, #68]
	ldrh	w6, [x13, #70]
	cmp	w14, w3
	ldrh	w3, [x13, #72]
	ldur	q0, [x12, #44]
	ldur	q1, [x13, #44]
	cset	w14, eq
	cmp	w15, w4
	cset	w15, eq
	cmp	w16, w5, uxth
	cset	w16, eq
	cmp	w17, w6, uxth
	cset	w17, eq
	cmp	w2, w3, uxth
	cset	w2, eq
	cmeq.4s	v0, v0, v1
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w3, s0
	tbz	w3, #0, LBB170_19
; %bb.7:                                ;   in Loop: Header=BB170_6 Depth=1
	cbz	w14, LBB170_19
; %bb.8:                                ;   in Loop: Header=BB170_6 Depth=1
	cbz	w15, LBB170_19
; %bb.9:                                ;   in Loop: Header=BB170_6 Depth=1
	cbz	w16, LBB170_19
; %bb.10:                               ;   in Loop: Header=BB170_6 Depth=1
	cbz	w17, LBB170_19
; %bb.11:                               ;   in Loop: Header=BB170_6 Depth=1
	cbz	w2, LBB170_19
; %bb.12:                               ;   in Loop: Header=BB170_6 Depth=1
	ldrb	w14, [x12, #74]
	ldrb	w15, [x13, #74]
	cmp	w14, w15
	b.ne	LBB170_19
; %bb.13:                               ;   in Loop: Header=BB170_6 Depth=1
	add	x8, x1, x9
	ldur	x8, [x8, #76]
	add	x14, x0, x9
	ldur	x14, [x14, #76]
	eor	x14, x14, x8
	tst	x14, #0xff
	b.ne	LBB170_20
; %bb.14:                               ;   in Loop: Header=BB170_6 Depth=1
	mov	w8, #0                          ; =0x0
	tst	x14, x11
	b.ne	LBB170_19
; %bb.15:                               ;   in Loop: Header=BB170_6 Depth=1
	ldur	x14, [x12, #84]
	ldur	x15, [x13, #84]
	cmp	x14, x15
	b.ne	LBB170_19
; %bb.16:                               ;   in Loop: Header=BB170_6 Depth=1
	ldr	w14, [x12, #92]
	ldr	w15, [x13, #92]
	cmp	w14, w15
	b.ne	LBB170_19
; %bb.17:                               ;   in Loop: Header=BB170_6 Depth=1
	ldr	w12, [x12, #96]
	ldr	w13, [x13, #96]
	cmp	w12, w13
	b.ne	LBB170_19
; %bb.18:                               ;   in Loop: Header=BB170_6 Depth=1
	add	x9, x9, #56
	mov	w8, #1                          ; =0x1
	cmp	x10, x9
	b.ne	LBB170_6
LBB170_19:
	mov	x0, x8
	ret
LBB170_20:
	mov	w0, #0                          ; =0x0
	ret
LBB170_21:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

l_.str.3:                               ; @.str.3
	.asciz	"__init__"

l_.str.4:                               ; @.str.4
	.asciz	"I found invalid callable target facts."

l_.str.5:                               ; @.str.5
	.asciz	"I describe exact targets without File execution authority."

l_.str.6:                               ; @.str.6
	.asciz	"I cannot resolve this complete callable target contract."

l_.str.7:                               ; @.str.7
	.asciz	"I reached my bounded target-query limit."

l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate the target-query staging."

.subsections_via_symbols
