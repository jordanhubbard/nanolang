from pathlib import Path
import json,os,signal,subprocess,sys,time
base=Path.cwd();old=Path('/home/jkh/Src/nanolang-callable-ownership');src=base/'.test_output/cycle-allocation-policy-candidate';previous=base/'.test_output/cycle-allocation-policy-generation';out=base/'.test_output/cycle-policy-configured-generation';out.mkdir(exist_ok=False);sys.path.insert(0,str(old));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(old,1800,30);b.load();b.check_artifacts(['nanoc_stage1.nvm']);proof=json.loads((previous/'manifest.json').read_text());vm=previous/'nano_vm';assert digest(vm)==proof['candidate_vm_sha256'] and all(digest(src/n)==v for n,v in proof['sources'].items());cache=str(old/'obj/module_cache');b.env['NANO_BUILD_CACHE']=cache;record=dict(previous_observation=str(previous),actual_vm=str(vm),vm_sha256=digest(vm),sources=proof['sources'],cache=cache,context_source='I restore the original Make export NANO_BUILD_CACHE=$(abspath MODULE_BUILD_CACHE), selected as obj/module_cache in the retained Stage1 host paths. My preceding standalone diagnostic did not explicitly preserve this configured context.',steps=[],limits=['I reuse the same actual private VM and original raw Stage1 compiler; I change only the missing configured cache context. I preserve1800/30 budgets, exact raw/host equality and the native-code guard. I never alias or rewrite compiler generations.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(args,label,env):
 args=list(map(str,args));entry=dict(label=label,argv=args);record['steps'].append(entry);save();start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as c:
  p=subprocess.Popen(args,cwd=old,env=env,stdout=a,stderr=c,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=1800)
  except BaseException as e:
   entry['error']=repr(e)
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
   entry['returncode']=p.wait();raise
  finally:entry['elapsed_seconds']=time.monotonic()-start;save()
 if entry['returncode']:raise RuntimeError(entry)
env=b.guarded_environment();env['NANOLANG_BOOTSTRAP_NO_CC']='1';source=out/'cache-context.nano';source.write_text('module "'+str(old/'modules/compiler_support/compiler_support.nano')+'" as support\nfn main() -> int { assert (== (support.module_artifact "") "") return 0 }\nshadow main { assert (== (main) 0) }\n')
try:
 run([vm,old/'bin/nanoc_stage1.nvm','--',source,'--emit-nvm','-o',out/'cache-context.nvm'],'configured-context-probe',env)
 hosts=b.imports(out/'cache-context.nvm');record['probe_hosts']=hosts;save();assert hosts and all(b.manifest['hosts'].get(k)==v for k,v in hosts.items())
 env.update(NANO_COMPILER_PHASE_RECORDER=str(old/'.test_output/bootstrap-join-phase-recorder.py'),NANO_BOOTSTRAP_PHASE_FILE=str(out/'phases.jsonl'))
 run([vm,old/'bin/nanoc_stage1.nvm','--','src_nano/nanoc_v06.nano','--emit-nvm','-o',out/'derived-stage2.nvm'],'actual-complete-generation',env)
 run([old/'bin/nano_vm','--verify-only',out/'derived-stage2.nvm'],'verify-complete-generation',env)
 record['raw_stage1_stage2_equal']=(out/'derived-stage2.nvm').read_bytes()==(old/'bin/nanoc_stage1.nvm').read_bytes();record['host_closure_equal']=b.imports(out/'derived-stage2.nvm')==b.manifest['hosts'];record['derived_module_sha256']=digest(out/'derived-stage2.nvm');save();assert record['raw_stage1_stage2_equal'] and record['host_closure_equal']
finally:
 b.check_inputs();b.check_artifacts(['nanoc_stage1.nvm']);record['unchanged_original_inputs']=True;record['unchanged_private_sources']=all(digest(src/n)==v for n,v in proof['sources'].items());save();assert record['unchanged_private_sources']
print('I completed actual raw self-generation with the original configured cache context, verification, byte equality and exact host closure under unchanged budgets.')
