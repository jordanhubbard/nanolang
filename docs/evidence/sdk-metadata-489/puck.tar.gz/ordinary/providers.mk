include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(MODULE_GENERATION_PROBE_OBJECTS) $(OBJ_DIR)/test_module_generation_probe
	@printf '%s\n' '$(MODULE_GENERATION_PROBE_OBJECTS) $(OBJ_DIR)/test_module_generation_probe' > /Users/jkh/nanolang-qualification/sdk-metadata-489-puck/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /Users/jkh/nanolang-qualification/sdk-metadata-489-puck/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /Users/jkh/nanolang-qualification/sdk-metadata-489-puck/ordinary/ldflags.txt
