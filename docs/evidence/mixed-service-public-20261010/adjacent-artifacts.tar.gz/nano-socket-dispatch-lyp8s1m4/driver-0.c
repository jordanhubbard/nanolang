#include <nanolang/socket/nanoisa/socket_indirect_native_public.h>
#include <nanolang/socket/nanoisa/socket_host_grant_internal.h>
#include <stdlib.h>
static void public_native_busy(void);
#define SOCKET_DISPATCH_ON_OPEN() public_native_busy()
#include "tests/nanoisa/socket_dispatch_host.h"
extern NvmSocketIndirectExecutionReport nvm_socket_indirect_program_test(NvmSocketHostGrant *,const NvmSocketIndirectOptions *,NvmSocketScalar *);
static void public_native_busy(void){
 NvmSocketIndirectExecutionReport r=nvm_socket_indirect_program_test((void *)1,(void *)1,(void *)1);
 if(r.runtime.status!=NVM_SOCKET_RUNTIME_BUSY || r.instruction_limit || r.runtime.acquired)abort();
 if(nvm_socket_host_grant_revoke((void *)1)!=NVM_SOCKET_HOST_BUSY)abort();
}
int main(int argc,char **argv){
 if(argc!=3 && argc!=4)return 2;
 NvmSocketHostGrant *grant=NULL;
 if(nvm_socket_host_grant_create_tcp_connections(&grant)!=NVM_SOCKET_HOST_OK)return 3;
 int mode=argc==4?atoi(argv[3]):0;
 if(mode==2 && nvm_socket_host_grant_revoke(grant)!=NVM_SOCKET_HOST_OK)return 4;
 if(mode==3 && nvm_socket_host_enter_query()!=NVM_SOCKET_HOST_OK)return 5;
 NvmSocketIndirectOptions options={1,strtoull(argv[1],NULL,10)};
 dispatch_close_fault=atoi(argv[2])!=0;
 NvmSocketScalar scalar={TAG_INT,12345};
 NvmSocketRuntimeView out={.fields=99,.values={12345}};
 NvmSocketIndirectExecutionReport r=nvm_socket_indirect_program_test(mode==1?NULL:grant,&options,&scalar);
 if(r.runtime.status==NVM_SOCKET_RUNTIME_OK){out.fields=1;out.values[0]=scalar.value;}
 else if(scalar.tag!=TAG_INT || scalar.value!=12345)abort();
 if(mode==3)nvm_socket_host_leave();
 if(nvm_socket_host_grant_destroy(&grant)!=NVM_SOCKET_HOST_OK || grant)return 6;
 dispatch_report(r,out);return 0;}
