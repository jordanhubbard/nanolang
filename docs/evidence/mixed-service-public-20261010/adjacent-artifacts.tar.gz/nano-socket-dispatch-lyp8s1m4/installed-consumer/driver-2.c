#include <nanolang/socket/nanoisa/socket_indirect_public.h>
extern NvmSocketIndirectExecutionReport nvm_socket_indirect_program_test(NvmSocketHostGrant *,const NvmSocketIndirectOptions *,NvmSocketScalar *);
int main(void){NvmSocketHostGrant *grant=0;NvmSocketIndirectOptions options={1,100000};NvmSocketScalar out={0};
 if(nvm_socket_host_grant_create_tcp_connections(&grant)!=NVM_SOCKET_HOST_OK)return 1;
 NvmSocketIndirectExecutionReport r=nvm_socket_indirect_program_test(grant,&options,&out);
 if(nvm_socket_host_grant_destroy(&grant)!=NVM_SOCKET_HOST_OK || grant)return 2;
 return !(r.runtime.status==NVM_SOCKET_RUNTIME_OK && !r.runtime.cleanup.cleanup_failures && out.tag==TAG_INT && out.value==4);}
