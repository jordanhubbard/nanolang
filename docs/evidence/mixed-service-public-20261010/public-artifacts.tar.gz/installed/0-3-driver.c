#include "host.h"
extern NvmServicesIndirectExecutionReport nvm_services_indirect_program_test(NvmServicesHostGrant *,const NvmServicesIndirectOptions *,NvmServicesScalar *);
int main(int argc,char **argv){if(argc!=3)return 2;return public_run(nvm_services_indirect_program_test,(unsigned)strtoul(argv[1],NULL,10),strtoull(argv[2],NULL,10));}
