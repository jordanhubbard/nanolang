from pathlib import Path
import os,sys,subprocess,json,shlex,time
root=Path(sys.argv[1]);products=Path(sys.argv[2]);out=Path(sys.argv[3]);out.mkdir(exist_ok=False)
record=dict(limits=['I instrument the actual test projection and actual shared reverse converter. Other linked providers retain their ordinary instrumentation. I compare every C report, including C outcomes for the explicitly deferred pure profiles. I do not claim whole-provider or Darwin leak instrumentation.'],sanitizer_environment={k:os.environ.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']})
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
text=subprocess.check_output(['make','-Bn','CC=/usr/bin/cc','obj/nvm2c_module_reference'],cwd=root,text=True)
(out/'make-dry-run').write_text(text)
commands=[shlex.split(line) for line in text.replace('\\\n',' ').splitlines() if line.startswith('/usr/bin/cc ') and 'tests/nvm2c_module_reference.c' in shlex.split(line)]
assert len(commands)==1,len(commands)
args=[arg for arg in commands[0] if arg!='obj/nanoisa/nvm_v2_convert.o'];exe=out/'reference-sanitized';args[args.index('-o')+1]=str(exe)
args+=['src/nanoisa/nvm_v2_convert.c','-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'];record['build_argv']=args;save()
start=time.monotonic();r=subprocess.run(args,cwd=root,capture_output=True,timeout=600);(out/'build.stdout').write_bytes(r.stdout);(out/'build.stderr').write_bytes(r.stderr);record.update(build_returncode=r.returncode,build_seconds=time.monotonic()-start);save();assert r.returncode==0
rows=[];paths=sorted((products/'inputs').glob('*.nvm'),key=lambda p:int(p.stem));start=time.monotonic();record['batches']=[]
for offset in range(0,len(paths),64):
 r=subprocess.run([exe,'--conversion',*paths[offset:offset+64]],cwd=root,capture_output=True,timeout=120)
 (out/f'{offset:05d}.stdout').write_bytes(r.stdout);(out/f'{offset:05d}.stderr').write_bytes(r.stderr);record['batches'].append(dict(start=offset,returncode=r.returncode));save();assert r.returncode==0
 rows+=r.stdout.decode().splitlines()
assert rows==(products/'reference.txt').read_text().splitlines()
originals=sorted(products.glob('original-*.nvm'));r=subprocess.run([exe,'--conversion',*originals],cwd=root,capture_output=True,timeout=120);(out/'originals.stdout').write_bytes(r.stdout);(out/'originals.stderr').write_bytes(r.stderr);assert r.returncode==0
# Product output ordering follows producer then source-path order, whereas the
# filesystem order differs. I compare exact complete report multisets here.
assert sorted(r.stdout.decode().splitlines())==sorted((products/'original-reference.txt').read_text().splitlines())
record.update(status='passed',reports=len(rows),original_products=len(originals),seconds=time.monotonic()-start);save();print(json.dumps({k:v for k,v in record.items() if k not in ['build_argv','batches']}))
