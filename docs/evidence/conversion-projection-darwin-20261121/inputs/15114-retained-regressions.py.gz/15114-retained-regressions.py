from pathlib import Path
import os,sys,json,tempfile,time,unittest,importlib.util
root=Path.cwd();out=Path(sys.argv[1]);out.mkdir(exist_ok=False);sys.path.insert(0,str(root));products=out/'products';products.mkdir()
class Retained(tempfile.TemporaryDirectory):
 def __init__(self,*args,**kwargs):
  kwargs['dir']=products
  super().__init__(*args,**kwargs)
 def cleanup(self):self._finalizer.detach()
tempfile.TemporaryDirectory=Retained
names=['tests.test_nanolang_translator_module','tests.test_nanolang_translator_ownership_module','tests.test_nanolang_translator_passive_module','tests.test_nanolang_translator_service_modules']
origins={name:importlib.util.find_spec(name).origin for name in names+['tests.nanolang_translator_routes']}
for name,origin in origins.items():assert Path(origin).resolve()==root/Path(*name.split('.')).with_suffix('.py'),(name,origin)
record=dict(test_modules=names,imported_sources=origins,pid=os.getpid(),status='running');path=out/'manifest.json';path.write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names));record.update(status='passed' if result.wasSuccessful() else 'failed',tests=result.testsRun,seconds=time.monotonic()-start,failures=len(result.failures),errors=len(result.errors));path.write_text(json.dumps(record,indent=2)+'\n');sys.exit(0 if result.wasSuccessful() else 1)
