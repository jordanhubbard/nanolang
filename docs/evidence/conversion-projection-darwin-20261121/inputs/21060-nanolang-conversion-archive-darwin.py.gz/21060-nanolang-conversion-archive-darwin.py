from pathlib import Path
import os,sys,json,subprocess,hashlib,gzip,stat
root=Path('/Users/jkh/.worktrees/nanolang/conversion-projection-20261121');control=root.with_name(root.name+'-control');out=root.with_name(root.name+'-archive');(out/'inputs').mkdir(parents=True,exist_ok=False)
resume=root.with_name(root.name+'-resume')
sha=lambda data:hashlib.sha256(data).hexdigest();original_bytes=(control/'manifest.json').read_bytes();state=json.loads(original_bytes);completion=json.loads((resume/'manifest.json').read_text())
assert state['status']=='failed' and state['primary_preserved'] and state['provider_guards_unchanged']
assert completion['status']=='passed' and completion['primary_preserved'] and completion['provider_guards_unchanged'] and completion['failed_manifest_bytes_preserved']
assert completion['prior_manifest_sha256']==sha(original_bytes)
assert all(step['returncode']==0 for step in completion['steps'])
assert all(step['returncode']==(1 if step['name']=='module-regressions' else 0) for step in state['steps'])
conversion=json.loads((control/'conversion-products/manifest.json').read_text());prior_regressions=json.loads((control/'regressions/manifest.json').read_text());regressions=json.loads((resume/'regressions/manifest.json').read_text());san=json.loads((resume/'reference-sanitizers/manifest.json').read_text())
assert prior_regressions['status']=='failed' and prior_regressions['tests']==5 and prior_regressions['errors']==2 and prior_regressions['failures']==0
assert regressions['status']==san['status']=='passed' and regressions['tests']==2
expected=state['source_hashes'];assert all(sha((root/name).read_bytes())==value for name,value in expected.items());assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
paths={Path(__file__).resolve()};paths.update(path for path in control.rglob('*') if path.is_file());paths.update(path for path in resume.rglob('*') if path.is_file());paths.update(root/name for name in expected)
# My fresh standalone clone contains only this observer's generated test work.
paths.update(path for path in (root/'.test_output').rglob('*') if path.is_file() and 'conversion-module-cache' not in path.relative_to(root/'.test_output').parts)
for name in ['docs/ROADMAP.md','docs/NANOLANG_NANOISA_C_TRANSLATOR.md',*state['tools'],'obj/fixture_identifier_lexer','obj/nvm2c_service_nominal_reference']:
 p=root/name
 if p.is_file():paths.add(p)
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(name) for name in b.manifest['hosts'])
record=dict(implementation=state['pin'],issue=1142,source_hashes=expected,conversion=conversion,regressions=dict(original=prior_regressions,resumed=regressions,completed_original_methods=completion['completed_original_methods']),product_controller_status=state['status'],completion_status=completion['status'],qualified_provider=state['provider'],limits=['I qualify complete conversion projections and the unchanged original core/ownership/passive/service module suite through five product routes. Successful conversion grants no executable, affine/private-profile, pure-emitter or final-source-bootstrap authority. I retain every original module test product, including service source products. The first observer passes three original methods and errors on two missing prerequisites. I preserve its failed manifest, supply only the output parent and declared service oracle, then pass only the two missing methods in a separate observer; I do not repeat completed passing gates. The standalone cold-output Make bug remains separately tracked by #1175. I use the frozen raw-equal bdffa4ccc Stage1 only as a development source producer. Build caches are omitted. Targeted actual reverse-converter and emitted-product ASan/UBSan do not instrument every provider; I claim no Darwin LeakSanitizer coverage. Every frozen provider/source/tool/primary-work/stash guard is preserved.'])
files=[];seen={}
for i,path in enumerate(sorted(paths)):
 raw=path.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{path.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(path),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(path.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=files;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==e['compressed_sha256'] and len(raw)==e['bytes'] and sha(raw)==e['sha256']
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/name).read_bytes())==value for name,value in expected.items());assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
print(json.dumps(dict(files=len(files),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/name).stat().st_size for name in seen.values()),unique_artifacts=len(seen),source_files=len(expected))))
