from pathlib import Path
import sys,json,gzip,hashlib,stat,subprocess,os,shutil
host=sys.argv[1];sha=lambda raw:hashlib.sha256(raw).hexdigest()
if host=='linux':
 root=Path.cwd();work=root/'.test_output/record-set-rvalue-20261122';control=work/'linux-typed';old=None;out=root/'docs/evidence/record-set-rvalue-linux-20261122';frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121')
else:
 root=Path('/Users/jkh/.worktrees/nanolang/record-set-typed-20261122');control=root.with_name(root.name+'-control');work=control;old=Path('/Users/jkh/.worktrees/nanolang/record-set-rvalue-20261122');out=root.with_name(root.name+'-archive');frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121')
state=json.loads((control/'manifest.json').read_text());assert state['status']=='passed'
expected=state['source_hashes'];assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items())
result=json.loads((control/'commands/result.json').read_text());assert result['successful'] and result['ran']==20 and not(result['failures'] or result['errors'] or result['skipped'])
sanitizer=json.loads((control/'direct-sanitized/manifest.json').read_text());assert sanitizer['passed']
pin=state.get('pin');assert pin==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
paths={p for p in work.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(work).parts and not p.is_symlink()};paths.update(root/n for n in expected);paths.update(root/n for n in state['tools'])
if host=='darwin':
 oldcontrol=old.with_name(old.name+'-control');paths.update(p for p in oldcontrol.rglob('*') if p.is_file() and not p.is_symlink() and 'module-cache' not in p.relative_to(oldcontrol).parts)
 paths.update(old/n for n in ['src/transpiler_iterative_v3_twopass.c','tests/test_cseed_record_array_literals.py','docs/ROADMAP.md','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nano','bin/nvm2c','bin/nano_aot_runtime.o'])
 for name in ['/tmp/nanolang-record-set-typed-20261122.log','/tmp/nanolang-record-set-rvalue-20261122.log','/tmp/nanolang-record-set-darwin-health.py','/tmp/nanolang-record-set-darwin-health.json']:
  paths.add(Path(name))
paths.update(frozen/'bin'/n for n in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']);paths.update(Path(n) for n in b.manifest['hosts'])
(out/'inputs').mkdir(parents=True,exist_ok=False);files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(p.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record=dict(implementation=pin,source_hashes=expected,qualification=state,verification=result,sanitizers=sanitizer,files=files,issue=1177,limits=['I qualify only the typed ordinary-record C-seed array_set repair and the complete20-method original/new neighboring suite. I preserve the original failed rvalue source/results and the first auto-type-only nominal hole separately. Source-level VM/frontend nominal checking remains open under1179. No capture/private admission or new raw bootstrap runs. All original assertions and per-child/shadow limits remain unchanged. Direct sanitizer instrumentation does not include every prebuilt provider and does not establish Darwin LeakSanitizer coverage. Build caches and Git internals are omitted.'])
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items());print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/n).stat().st_size for n in seen.values()),source_files=len(expected))))
