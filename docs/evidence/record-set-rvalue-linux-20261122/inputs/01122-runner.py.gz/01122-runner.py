import tempfile,unittest
original=tempfile.TemporaryDirectory
def retained(*args,**kwargs):
 kwargs["delete"]=False
 return original(*args,**kwargs)
tempfile.TemporaryDirectory=retained
unittest.main(module=None,argv=["unittest","-v","tests.test_cseed_record_array_literals.RecordArrayLiterals.test_record_set_materializes_values_and_orders_all_three_operands"])
