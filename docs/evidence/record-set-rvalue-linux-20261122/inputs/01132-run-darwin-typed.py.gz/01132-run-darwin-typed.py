from pathlib import Path
import sys,os,subprocess,json,hashlib,time,signal,traceback,shutil,platform,re
pin=sys.argv[1];expected_path=Path(sys.argv[2]);primary=Path('/Users/jkh/Src/nanolang')
root=Path('/Users/jkh/.worktrees/nanolang/record-set-typed-20261122')
out=root.with_name(root.name+'-control');assert not root.exists() and not out.exists()
out.mkdir(parents=True);shutil.copy2(__file__,out/'observer.py');shutil.copy2(expected_path,out/'expected-sources.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
record=dict(pin=pin,root=str(root),controller_pid=os.getpid(),python=sys.version,platform=platform.platform(),steps=[],status='running',limits=['I qualify only the C-seed ordinary record setter repair at exact06ec80f84 through the new regression plus original record-array and call-order controls. I preserve all source/tool/frozen-provider/primary-audit/stash guards, ordinary10s shadows,600s native/guest budgets and1800/30 bootstrap limits. No raw bootstrap, bytecode/private/runtime admission or historical performance claim follows.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def git(*args,cwd=primary):return subprocess.check_output(['git',*args],cwd=cwd)
def primary_guard():
 paths=git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0');files={}
 for raw in paths:
  if not raw:continue
  name=os.fsdecode(raw);p=primary/name
  if p.is_symlink():files[name]={'symlink':os.readlink(p)}
  elif p.is_file():files[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode}
  else:files[name]={'absent':True}
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('rev-parse','--abbrev-ref','HEAD').decode().strip(),status=sha(git('status','--porcelain=v1','-z','--untracked-files=all')),diff=sha(git('diff','--binary','--full-index','HEAD')),cached=sha(git('diff','--cached','--binary','--full-index','HEAD')),stashes=git('stash','list','--format=%H').decode().splitlines(),files=files)

original=primary_guard();record['primary_before']=original;save()
health=json.loads(Path(sys.argv[3]).read_text());assert health['admitted'];shutil.copy2(Path(sys.argv[3]),out/'health.json')
base_env=dict(os.environ,PATH='/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',MAKEFLAGS='-j1')
def step(name,args,cwd,env=base_env,timeout=3600):
 item=dict(name=name,argv=list(map(str,args)),cwd=str(cwd));record['steps'].append(item);save();started=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=cwd,env=env,stdout=a,stderr=b,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['elapsed_seconds']=time.monotonic()-started;save();print(json.dumps(item),flush=True)
 if item['returncode']:raise RuntimeError(f'{name} failed with {item["returncode"]}')
 return item
expected=json.loads(expected_path.read_text())
def sources():
 actual={name:sha((root/name).read_bytes()) for name in expected};assert actual==expected,[name for name in expected if actual[name]!=expected[name]]
 return actual
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');b=None;tools={}
def guards():
 assert sources()==expected
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 if tools:assert {name:sha((root/name).read_bytes()) for name in tools}==tools
 assert primary_guard()==original
try:
 root.mkdir(parents=True)
 for name,args in [('init',['git','init',root]),('origin',['git','remote','add','origin','git@github.com:jordanhubbard/nanolang.git']),('promisor',['git','config','remote.origin.promisor','true']),('filter',['git','config','remote.origin.partialclonefilter','blob:none']),('fetch',['git','fetch','--filter=blob:none','--no-tags','origin',pin]),('sparse-init',['git','sparse-checkout','init','--no-cone'])]:
  step(name,args,root,timeout=600)
 patterns=Path(git('rev-parse','--git-path','info/sparse-checkout',cwd=root).decode().strip())
 if not patterns.is_absolute():patterns=root/patterns
 patterns.write_text('/*\n!/docs/evidence/\n')
 step('checkout',['git','checkout','--detach',pin],root,timeout=600)
 assert git('rev-parse','HEAD',cwd=root).decode().strip()==pin
 record['source_hashes']=sources();record['source_map_sha256']=sha(expected_path.read_bytes());save()
 sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
 b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 compiler=frozen/'bin/nanoc_stage1';record['provider']=dict(pin=git('rev-parse','HEAD',cwd=frozen).decode().strip(),compiler=str(compiler),compiler_sha256=sha(compiler.read_bytes()),receipt=str(frozen/'bin/nanoc_bootstrap.json'),receipt_sha256=sha((frozen/'bin/nanoc_bootstrap.json').read_bytes()),hosts=b.manifest['hosts'])
 tools_dir=out/'tools';tools_dir.mkdir();(tools_dir/'python3').symlink_to('/opt/homebrew/bin/python3.13')
 selector=out/'make-shell'
 selector.write_text('#!/opt/homebrew/bin/python3.13\nimport os,sys\nargs=sys.argv[1:]\nassert args[-2]=="-c"\nargs[-1]='+repr('export PATH='+str(tools_dir)+':"$PATH"\n')+'+args[-1]\nos.execve("/bin/bash",["/bin/bash",*args],os.environ)\n');selector.chmod(0o755)
 env=dict(base_env,PYTHONPATH=str(root),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_SELFHOST_COMPILER=str(compiler))
 for name in ['NANOLANG_TRANSLATOR_SOURCE_MODULE','NANO_CC','NANOLANG_BOOTSTRAP_NO_CC','NANO_AS_CAPTURE_HELPER']:env.pop(name,None)
 record['gate_environment']={name:env.get(name) for name in ['PATH','CC','MAKEFLAGS','NANOLANG_ROOT','NANO_MODULE_PATH','NANO_BUILD_CACHE','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_TRANSLATOR_SOURCE_COMPILER','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']};save();guards()
 step('python-preflight',[selector,'-c',"python3 -c 'import sys,yaml;print(sys.version);print(yaml.__version__)'"],root,env,timeout=60)
 (root/'.test_output').mkdir(exist_ok=True)
 step('build-tools',['make','CC=/usr/bin/cc','SHELL='+str(selector),'bin/nano','bin/nanoc_c','nano_virt','nano_vm','bin/nanoisa','nvm2c','nvm2c-runtime'],root,env,timeout=1800);guards()
 tools={name:sha((root/name).read_bytes()) for name in ['bin/nano','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o']};record['tools']=tools;save();guards()
 env['TMPDIR']=str(out/'tmp');(out/'tmp').mkdir()
 shutil.copy2(Path(sys.argv[4]),out/'run-suite.py')
 step('suite',['/opt/homebrew/bin/python3.13',out/'run-suite.py',out/'commands'],root,env,timeout=3600);guards()
 shutil.copy2(Path(sys.argv[5]),out/'run-direct-sanitized.py')
 step('direct-sanitized',['/opt/homebrew/bin/python3.13',out/'run-direct-sanitized.py',out],root,env,timeout=600);guards()
 step('identifiers',['make','CC=/usr/bin/cc','SHELL='+str(selector),'test-embedded-nano-identifiers'],root,env,timeout=600);guards()
 record.update(status='passed',primary_after=primary_guard(),source_and_tool_guards_unchanged=True);assert record['primary_after']==original
except BaseException as error:
 record['status']='failed';record['error']=repr(error);(out/'exception').write_text(traceback.format_exc())
finally:
 try:
  assert primary_guard()==original;record['primary_preserved']=True
  if b is not None:b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
  if root.exists():record['final_status']=git('status','--porcelain=v1','--untracked-files=all',cwd=root).decode();assert record['final_status']==''
 except BaseException as error:
  record['status']='failed';record['guard_error']=repr(error)
 save()
print(json.dumps({'status':record['status'],'root':str(root),'manifest':str(out/'manifest.json')}),flush=True)
sys.exit(0 if record['status']=='passed' else 1)
