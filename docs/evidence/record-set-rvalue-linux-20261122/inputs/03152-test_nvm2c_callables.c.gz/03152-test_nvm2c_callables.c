#include "assembler.h"
#include "isa.h"
#include "nvm2c.h"
#include <stdlib.h>
#include "nvm2c_callables.h"
#include <stdio.h>
#include <string.h>

static int passed, failed;
#define CHECK(value) do { if (value) ++passed; else { ++failed; \
    fprintf(stderr, "I failed %s at line %d\n", #value, __LINE__); } } while (0)

static NvmModule *assemble(const char *text, int verify) {
    AsmResult result = {0};
    NvmModule *module = verify ? asm_assemble(text, &result) : asm_assemble_unverified(text, &result);
    if (!module) fprintf(stderr, "I could not assemble line %u: %s\n", result.line, result.message);
    CHECK(module != NULL);
    return module;
}
static void targets(NvmModule *module, NvmCallableAnalysis *a, uint32_t function,
                    size_t ordinal, const uint32_t *expected, size_t count) {
    const NvmFunctionEntry *fn = &module->functions[function];
    for (uint32_t pc = 0; pc < fn->code_length;) {
        DecodedInstruction in;
        uint32_t size = isa_decode(module->code + fn->code_offset + pc, fn->code_length - pc, &in);
        CHECK(size != 0);
        if (!size) return;
        if (in.opcode == OP_CALL_INDIRECT && ordinal-- == 0) {
            NvmShapeId shape = nvm_callable_at(a, function, pc);
            if (!count) { CHECK(!shape); return; }
            CHECK(shape != 0);
            if (!shape) return;
            CHECK(nvm_shape_function_count(&a->shapes, shape) == count);
            for (size_t i = 0; i < count; ++i) {
                uint32_t target = UINT32_MAX;
                CHECK(nvm_shape_function_target(&a->shapes, shape, i, &target));
                CHECK(target == expected[i]);
            }
            return;
        }
        pc += size;
    }
    CHECK(0);
}
static int analyze(NvmModule *m, NvmCallableAnalysis *a) {
    int ok = nvm_callable_analyze(m, a);
    if (!ok) fprintf(stderr, "I could not analyze: %s\n", a->error);
    CHECK(ok);
    return ok;
}
#define LEAVES ".function first 1 1 0 int 1\nLOAD_LOCAL 0\nRET\n.end\n" \
               ".function second 1 1 0 int 1\nLOAD_LOCAL 0\nRET\n.end\n"

static void direct_results_and_joins(void) {
    NvmModule *m = assemble(
        ".function main 0 1 0 void 0\nPUSH_BOOL 1\nCALL choose\nSTORE_LOCAL 0\n"
        "PUSH_I64 7\nLOAD_LOCAL 0\nCALL_INDIRECT 1 1\nPOP\nRET\n.end\n"
        ".function choose 1 1 0 function 1\nLOAD_LOCAL 0\nJMP_FALSE other\n"
        "FUNCREF first\nJMP joined\nother:\nFUNCREF second\njoined:\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) { const uint32_t want[] = {2, 3}; targets(m, &a, 0, 0, want, 2); }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void indirect_arguments_and_results(void) {
    NvmModule *m = assemble(
        ".function main 0 1 0 void 0\nFUNCREF first\nFUNCREF relay\nCALL_INDIRECT 1 1\n"
        "STORE_LOCAL 0\nPUSH_I64 7\nLOAD_LOCAL 0\nCALL_INDIRECT 1 1\nPOP\n"
        "FUNCREF first\nPUSH_I64 8\nFUNCREF apply\nCALL_INDIRECT 2 1\nPOP\nRET\n.end\n"
        ".function relay 1 1 0 function 1\nLOAD_LOCAL 0\nRET\n.end\n"
        ".function apply 2 2 0 int 1\nLOAD_LOCAL 1\nLOAD_LOCAL 0\nCALL_INDIRECT 1 1\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        const uint32_t relay[] = {1}, leaf[] = {3}, apply[] = {2};
        targets(m, &a, 0, 0, relay, 1); targets(m, &a, 0, 1, leaf, 1);
        targets(m, &a, 0, 2, apply, 1); targets(m, &a, 2, 0, leaf, 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void globals_loops_and_separate_producers(void) {
    NvmModule *m = assemble(
        ".function main 0 1 0 void 0\nFUNCREF first\nSTORE_GLOBAL 0\n"
        "again:\nPUSH_BOOL 0\nJMP_FALSE done\nFUNCREF second\nSTORE_GLOBAL 0\nJMP again\n"
        "done:\nPUSH_I64 1\nLOAD_GLOBAL 0\nCALL_INDIRECT 1 1\nPOP\n"
        "PUSH_I64 2\nFUNCREF first\nCALL_INDIRECT 1 1\nPOP\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        const uint32_t both[] = {1, 2}, first[] = {1};
        targets(m, &a, 0, 0, both, 2); targets(m, &a, 0, 1, first, 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void aggregate_and_array_aliases(void) {
    NvmModule *m = assemble(
        ".function main 0 2 0 void 0\nFUNCREF first\nARR_LITERAL 11 1\n"
        "AGG_PACK 0 0 0 1\nSTORE_LOCAL 0\nLOAD_LOCAL 0\nCALL relay\nSTORE_LOCAL 1\n"
        "LOAD_LOCAL 1\nAGG_GET 0\nPUSH_I64 0\nFUNCREF second\nARR_SET\nPOP\n"
        "PUSH_I64 5\nLOAD_LOCAL 0\nAGG_GET 0\nPUSH_I64 0\nARR_GET\nCALL_INDIRECT 1 1\nPOP\nRET\n.end\n"
        ".function relay 1 1 0 struct 1\nLOAD_LOCAL 0\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) { const uint32_t both[] = {2, 3}; targets(m, &a, 0, 0, both, 2); }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void unresolved_and_refused(void) {
    const char *cases[] = {
        ".function main 0 0 0 void 0\nPUSH_I64 9\nCALL_INDIRECT 0 0\nRET\n.end\n",
        ".function main 0 0 0 void 0\nFUNCREF leaf\nCALL_INDIRECT 0 0\nRET\n.end\n"
        ".function leaf 1 1 0 void 0\nRET\n.end\n",
        ".function main 0 0 0 void 0\nFUNCREF 99\nPOP\nRET\n.end\n",
        ".function main 0 0 0 void 0\nPOP\nRET\n.end\n",
        ".function main 0 0 0 void 0\nFUNCREF leaf\nCALL_INDIRECT 0 0\nRET\n.end\n"
        ".function leaf 0 0 0 int 1\nPUSH_I64 1\nRET\n.end\n"
    };
    for (size_t i = 0; i < sizeof cases / sizeof *cases; ++i) {
        NvmModule *m = assemble(cases[i], 0);
        if (!m) continue;
        NvmCallableAnalysis a;
        if (i == 0) {
            CHECK(nvm_callable_analyze(m, &a)); targets(m, &a, 0, 0, NULL, 0);
        } else { CHECK(!nvm_callable_analyze(m, &a)); CHECK(a.error[0]); }
        CHECK(!nvm_callable_at(&a, UINT32_MAX, 0));
        if (i == 1 || i == 4) {
            char error[256];
            char *native = nvm2c_emit(m, error, sizeof error);
            CHECK(native == NULL);
            CHECK(strstr(error, "matching callable argument and result counts") != NULL);
            free(native);
        }
        nvm_callable_destroy(&a); nvm_module_free(m);
    }
}
static void stack_loop_and_zero_target(void) {
    NvmModule *m = assemble(
        ".function main 0 0 0 void 0\nFUNCREF first\nagain:\nPUSH_BOOL 0\nJMP_FALSE done\n"
        "POP\nFUNCREF second\nJMP again\ndone:\nPUSH_I64 3\nSWAP\nCALL_INDIRECT 1 1\nPOP\n"
        "FUNCREF main\nCALL_INDIRECT 0 0\nRET\n.end\n" LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        const uint32_t both[] = {1, 2}, entry[] = {0};
        targets(m, &a, 0, 0, both, 2); targets(m, &a, 0, 1, entry, 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void map_aliases(void) {
    NvmModule *m = assemble(
        ".string key \"key\"\n"
        ".function main 0 2 0 void 0\nHM_NEW 5 11\nPUSH_STR key\nFUNCREF first\nHM_SET\n"
        "STORE_LOCAL 0\nLOAD_LOCAL 0\nSTORE_LOCAL 1\n"
        "LOAD_LOCAL 1\nPUSH_STR key\nFUNCREF second\nHM_SET\nPOP\n"
        "PUSH_I64 5\nLOAD_LOCAL 0\nPUSH_STR key\nHM_GET\nCALL_INDIRECT 1 1\nPOP\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) { const uint32_t both[] = {1, 2}; targets(m, &a, 0, 0, both, 2); }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

/* I follow captures through returned closures and retain late writes without
 * adding a destination's other targets to an independent FUNCREF producer. */
static void captured_targets(void) {
    NvmModule *m = assemble(
        ".function main 0 1 0 void 0\nFUNCREF first\nCLOSURE_NEW middle 1\n"
        "CALL_INDIRECT 0 1\nSTORE_LOCAL 0\nPUSH_I64 7\nLOAD_LOCAL 0\nCALL_INDIRECT 1 1\nPOP\n"
        "PUSH_I64 8\nFUNCREF first\nCALL_INDIRECT 1 1\nPOP\nRET\n.end\n"
        ".function middle 0 0 1 closure 1\nLOAD_UPVALUE 0 0\nCLOSURE_NEW inner 1\nRET\n.end\n"
        ".function inner 1 1 1 int 1\nFUNCREF second\nSTORE_UPVALUE 0 0\n"
        "LOAD_LOCAL 0\nLOAD_UPVALUE 0 0\nCALL_INDIRECT 1 1\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        const uint32_t middle[] = {1}, inner[] = {2}, first[] = {3}, both[] = {3, 4};
        targets(m, &a, 0, 0, middle, 1); targets(m, &a, 0, 1, inner, 1);
        targets(m, &a, 0, 2, first, 1); targets(m, &a, 2, 0, both, 2);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void captured_array_aliases_and_instances(void) {
    NvmModule *m = assemble(
        ".function main 0 3 0 void 0\nFUNCREF first\nARR_LITERAL 11 1\nSTORE_LOCAL 0\n"
        "LOAD_LOCAL 0\nCLOSURE_NEW apply 1\nSTORE_LOCAL 1\n"
        "LOAD_LOCAL 0\nPUSH_I64 0\nFUNCREF second\nARR_SET\nPOP\n"
        "PUSH_I64 5\nLOAD_LOCAL 1\nCALL_INDIRECT 1 1\nPOP\n"
        "FUNCREF first\nCLOSURE_NEW relay 1\nCALL_INDIRECT 0 1\nPOP\n"
        "FUNCREF second\nCLOSURE_NEW relay 1\nCALL_INDIRECT 0 1\nSTORE_LOCAL 2\n"
        "PUSH_I64 6\nLOAD_LOCAL 2\nCALL_INDIRECT 1 1\nPOP\nRET\n.end\n"
        ".function apply 1 1 1 int 1\nLOAD_LOCAL 0\nLOAD_UPVALUE 0 0\nPUSH_I64 0\n"
        "ARR_GET\nCALL_INDIRECT 1 1\nRET\n.end\n"
        ".function relay 0 0 1 function 1\nLOAD_UPVALUE 0 0\nRET\n.end\n"
        LEAVES, 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        const uint32_t apply[] = {1}, relay[] = {2}, both[] = {3, 4};
        targets(m, &a, 0, 0, apply, 1); targets(m, &a, 1, 0, both, 2);
        targets(m, &a, 0, 1, relay, 1); targets(m, &a, 0, 2, relay, 1);
        targets(m, &a, 0, 3, both, 2);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

/* I refine the surviving aggregate only when its exact tag comparison is
 * entered at DUP. An alternate entry at the branch keeps both targets. */
static void variant_guard_targets(void) {
    for (int bypass = 0; bypass < 2; ++bypass) {
        char source[4096];
        snprintf(source, sizeof source,
            ".function main 0 1 0 void 0\nPUSH_BOOL 0\nCALL choose\n%s"
            "DUP\nAGG_TAG\nPUSH_I64 0\nEQ\ncondition:\nJMP_FALSE other\n"
            "STORE_LOCAL 0\nPUSH_I64 7\nLOAD_LOCAL 0\nAGG_GET 0\n"
            "CALL_INDIRECT 1 1\nPOP\nRET\nother:\nPOP\nRET\n%s.end\n"
            ".function choose 1 1 0 union 1\nLOAD_LOCAL 0\nJMP_FALSE second_arm\n"
            "FUNCREF first\nAGG_PACK 1 0 0 1\nRET\nsecond_arm:\n"
            "FUNCREF second\nAGG_PACK 1 0 1 1\nRET\n.end\n" LEAVES,
            bypass ? "PUSH_BOOL 1\nJMP_TRUE bypass\n" : "",
            bypass ? "bypass:\nPUSH_BOOL 1\nJMP condition\n" : "");
        NvmModule *m = assemble(source, 1);
        if (!m) continue;
        NvmCallableAnalysis a;
        if (analyze(m, &a)) {
            const uint32_t want[] = {2, 3};
            targets(m, &a, 0, 0, want, bypass ? 2 : 1);
        }
        nvm_callable_destroy(&a); nvm_module_free(m);
    }
}

static void variant_scalar_producers(void) {
    for (int bypass = 0; bypass < 2; ++bypass) {
        char source[4096];
        snprintf(source, sizeof source,
            ".string text \"kept\"\n.function main 0 1 0 void 0\nPUSH_BOOL 0\nCALL choose\n%s"
            "DUP\nAGG_TAG\nPUSH_I64 0\nEQ\ncondition:\nJMP_FALSE other\n"
            "STORE_LOCAL 0\nLOAD_LOCAL 0\nAGG_GET 0\nPOP\nRET\nother:\nPOP\nRET\n%s.end\n"
            ".function choose 1 1 0 union 1\nLOAD_LOCAL 0\nJMP_FALSE second_arm\n"
            "PUSH_BOOL 1\nAGG_PACK 1 0 0 1\nRET\nsecond_arm:\n"
            "PUSH_STR text\nAGG_PACK 1 0 1 1\nRET\n.end\n",
            bypass ? "PUSH_BOOL 1\nJMP_TRUE bypass\n" : "",
            bypass ? "bypass:\nPUSH_BOOL 1\nJMP condition\n" : "");
        NvmModule *m = assemble(source, 1);
        if (!m) continue;
        NvmCallableAnalysis a;
        if (analyze(m, &a)) {
            const NvmFunctionEntry *fn = &m->functions[0];
            unsigned projections = 0;
            for (uint32_t pc = 0; pc < fn->code_length;) {
                DecodedInstruction in;
                uint32_t size = isa_decode(m->code + fn->code_offset + pc, fn->code_length - pc, &in);
                CHECK(size != 0);
                if (!size) break;
                if (in.opcode == OP_AGG_GET) {
                    uint16_t expected = (1u << TAG_BOOL) | (bypass ? 1u << TAG_STRING : 0);
                    CHECK(nvm_callable_projection_tags(&a, 0, pc) == expected);
                    ++projections;
                }
                pc += size;
            }
            CHECK(projections == 1);
        }
        nvm_callable_destroy(&a); nvm_module_free(m);
    }
    for (int wrong = 0; wrong < 2; ++wrong) {
        char source[2048];
        snprintf(source, sizeof source,
            ".string text \"unused\"\n.function main 0 0 0 int 1\n"
            "PUSH_BOOL 1\nAGG_PACK 1 0 0 1\nCALL read\nPOP\n"
            "PUSH_STR text\nAGG_PACK 1 0 %d 1\nCALL read\nASSERT\nPUSH_I64 0\nRET\n.end\n"
            ".function read 1 1 0 bool 1\nLOAD_LOCAL 0\nDUP\nAGG_TAG\nPUSH_I64 1\nEQ\n"
            "JMP_FALSE fallback\nAGG_GET 0\nRET\nfallback:\nPOP\nPUSH_BOOL 1\nRET\n.end\n", wrong);
        NvmModule *m = assemble(source, 1);
        if (!m) continue;
        char error[512] = {0};
        char *c = nvm2c_emit(m, error, sizeof error);
        if (!wrong && !c) fprintf(stderr, "I could not translate the fallback: %s\n", error);
        CHECK(wrong ? c == NULL : c != NULL);
        if (wrong) CHECK(strstr(error, "incompatible variant scalar payload") != NULL);
        free(c); nvm_module_free(m);
    }
}

static void malformed_captures(void) {
    const char *cases[] = {
        ".function main 0 0 0 void 0\nCLOSURE_NEW 99 0\nPOP\nRET\n.end\n",
        ".function main 0 0 0 void 0\nCLOSURE_NEW child 0\nPOP\nRET\n.end\n"
        ".function child 0 0 1 void 0\nRET\n.end\n",
        ".function main 0 0 0 void 0\nCLOSURE_NEW child 1\nPOP\nRET\n.end\n"
        ".function child 0 0 1 void 0\nRET\n.end\n",
        ".function main 0 0 1 void 0\nLOAD_UPVALUE 1 0\nPOP\nRET\n.end\n",
        ".function main 0 0 1 void 0\nLOAD_UPVALUE 0 1\nPOP\nRET\n.end\n",
        ".function main 0 0 1 void 0\nPUSH_I64 0\nSTORE_UPVALUE 0 1\nRET\n.end\n"
    };
    for (size_t i = 0; i < sizeof cases / sizeof *cases; ++i) {
        NvmModule *m = assemble(cases[i], 0);
        if (!m) continue;
        NvmCallableAnalysis a;
        CHECK(!nvm_callable_analyze(m, &a)); CHECK(a.error[0]);
        nvm_callable_destroy(&a); nvm_module_free(m);
    }
}

static void source_fixture(const char *path) {
    AsmResult result = {0};
    NvmModule *m = asm_assemble_file(path, &result);
    CHECK(m != NULL);
    if (!m) { fprintf(stderr, "%s\n", result.message); return; }
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        const uint32_t both[] = {4, 5}, first[] = {4};
        for (size_t i = 0; i < 3; ++i) targets(m, &a, 0, i, both, 2);
        targets(m, &a, 0, 3, first, 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}


static void split_elements_keep_string_provenance(void) {
    NvmModule *m = assemble(
        ".string text \"hi,there\"\n.string delimiter \",\"\n"
        ".function main 0 0 0 void 0\nPUSH_STR text\nPUSH_STR delimiter\nSTR_SPLIT\n"
        "PUSH_I64 0\nARR_GET\nAGG_PACK 0 0 0 1\nAGG_GET 0\nPOP\nRET\n.end\n", 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        unsigned projections = 0;
        for (uint32_t pc = 0; pc < m->functions[0].code_length;) {
            DecodedInstruction in;
            uint32_t size = isa_decode(m->code + m->functions[0].code_offset + pc,
                m->functions[0].code_length - pc, &in);
            CHECK(size != 0);
            if (!size) break;
            if (in.opcode == OP_AGG_GET) {
                CHECK(nvm_callable_projection_tags(&a, 0, pc) == (1u << TAG_STRING));
                CHECK(nvm_callable_at(&a, 0, pc) == 0);
                ++projections;
            }
            pc += size;
        }
        CHECK(projections == 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void sorted_elements_keep_string_provenance(void) {
    NvmModule *m = assemble(
        ".string text \"hi\"\n.import \"\" \"vm_array_sort\" array array\n"
        ".function main 0 0 0 void 0\nPUSH_STR text\nARR_LITERAL 5 1\nCALL_EXTERN 0\n"
        "PUSH_I64 0\nARR_GET\nAGG_PACK 0 0 0 1\nAGG_GET 0\nPOP\nRET\n.end\n", 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        unsigned projections = 0;
        for (uint32_t pc = 0; pc < m->functions[0].code_length;) {
            DecodedInstruction in;
            uint32_t size = isa_decode(m->code + m->functions[0].code_offset + pc,
                m->functions[0].code_length - pc, &in);
            CHECK(size != 0);
            if (!size) break;
            if (in.opcode == OP_AGG_GET) {
                CHECK(nvm_callable_projection_tags(&a, 0, pc) == (1u << TAG_STRING));
                CHECK(nvm_callable_at(&a, 0, pc) == 0);
                ++projections;
            }
            pc += size;
        }
        CHECK(projections == 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

static void encoded_elements_keep_byte_provenance(void) {
    NvmModule *m = assemble(
        ".string text \"hi\"\n.import \"\" \"vm_bytes_from_string\" array string\n"
        ".function main 0 0 0 void 0\nPUSH_STR text\nCALL_EXTERN 0\n"
        "PUSH_I64 0\nARR_GET\nAGG_PACK 0 0 0 1\nAGG_GET 0\nPOP\nRET\n.end\n", 1);
    if (!m) return;
    NvmCallableAnalysis a;
    if (analyze(m, &a)) {
        unsigned projections = 0;
        for (uint32_t pc = 0; pc < m->functions[0].code_length;) {
            DecodedInstruction in;
            uint32_t size = isa_decode(m->code + m->functions[0].code_offset + pc,
                m->functions[0].code_length - pc, &in);
            CHECK(size != 0);
            if (!size) break;
            if (in.opcode == OP_AGG_GET) {
                CHECK(nvm_callable_projection_tags(&a, 0, pc) == (1u << TAG_U8));
                CHECK(nvm_callable_at(&a, 0, pc) == 0);
                ++projections;
            }
            pc += size;
        }
        CHECK(projections == 1);
    }
    nvm_callable_destroy(&a); nvm_module_free(m);
}

int main(int argc, char **argv) {
    direct_results_and_joins(); indirect_arguments_and_results();
    globals_loops_and_separate_producers(); aggregate_and_array_aliases();
    unresolved_and_refused(); stack_loop_and_zero_target(); map_aliases();
    captured_targets(); captured_array_aliases_and_instances(); malformed_captures();
    variant_guard_targets();
    variant_scalar_producers();
    split_elements_keep_string_provenance();
    sorted_elements_keep_string_provenance();
    encoded_elements_keep_byte_provenance();
    if (argc > 1) source_fixture(argv[1]);
    printf("Callable constraints: %d passed, %d failed\n", passed, failed);
    return failed != 0;
}
