from pathlib import Path
import os,sys,json,time,subprocess,hashlib,signal,traceback,shutil
root=Path.cwd();work=root/'.test_output/record-set-rvalue-20261122';out=work/'linux-completion';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert pin=='8b29b1858eb71a09bb26c1f3ff62dab2bc9224b1'
names=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],text=True).splitlines();expected={n:sha(root/n) for n in sorted(set(names)) if (root/n).is_file()}
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
record=dict(pin=pin,status='running',source_hashes=expected,steps=[],provider=dict(compiler=str(frozen/'bin/nanoc_stage1'),compiler_sha256=sha(frozen/'bin/nanoc_stage1'),receipt_sha256=sha(frozen/'bin/nanoc_bootstrap.json')),limits=['I qualify only the C-seed ordinary record setter repair and original native/VM record and operand-order neighbors. No raw bootstrap or private/capture admission runs. Ordinary shadows10s and all original test subprocess deadlines remain unchanged.']);tools={}
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def guards():
 assert {n:sha(root/n) for n in expected}==expected
 assert all(sha(root/n)==v for n,v in tools.items())
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_SELFHOST_COMPILER=str(frozen/'bin/nanoc_stage1'),NANO_BUILD_CACHE=str(out/'module-cache'),PYTHONPATH=str(root));env.pop('NANO_AS_CAPTURE_HELPER',None)
(out/'tmp').mkdir();env['TMPDIR']=str(out/'tmp')
def step(name,args,timeout):
 item=dict(name=name,argv=list(map(str,args)));record['steps'].append(item);save();t=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as c:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=c,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['seconds']=time.monotonic()-t;save();print(json.dumps(item),flush=True);assert item['returncode']==0,item
try:
 record['environment']={n:env.get(n) for n in ['PATH','CC','NANO_SHADOW_TIMEOUT_SECONDS','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS','NANOLANG_SELFHOST_COMPILER']};save();guards()
 step('tools',['make','CC=/usr/bin/cc','bin/nano','bin/nanoc_c','nano_virt','nano_vm','bin/nanoisa','nvm2c','nvm2c-runtime'],1800)
 tools={n:sha(root/n) for n in ['bin/nano','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so']};record['tools']=tools;save();guards()
 step('suite',['/usr/bin/python3',work/'run-suite.py',out/'commands'],3600);guards()
 step('identifiers',['make','CC=/usr/bin/cc','test-embedded-nano-identifiers'],600);guards()
 record.update(status='passed',final_guards_unchanged=True)
except BaseException as error:record.update(status='failed',error=repr(error));(out/'exception').write_text(traceback.format_exc())
finally:
 try:guards();record['final_guards_unchanged']=True
 except BaseException as error:record.update(status='failed',guard_error=repr(error))
 save()
print(record['status'],flush=True);sys.exit(0 if record['status']=='passed' else 1)
