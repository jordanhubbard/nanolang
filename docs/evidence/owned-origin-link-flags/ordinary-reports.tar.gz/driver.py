import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();config=sys.argv[3];report.mkdir(exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('sha','write','inventory','run')];assert len(nodes)==4
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));exec(compile(module,str(base),'exec'));(report/'effective-supervisor.py').write_text(ast.unparse(module));shutil.copyfile(__file__,report/'driver.py')
files=(root/'.qualification-tracked').read_text().splitlines()
def source():return {p:sha(root/p) for p in files}
paths={n:shutil.which(n) for n in ('make','cc','gcc','ar','ld','nm','ps','python3')};paths.update(driver=__file__,supervisor=str(base),driver_python=sys.executable)
for n in ('cc1','collect2','libasan.so','libubsan.so'):
 p=subprocess.check_output(['gcc',('-print-prog-name=' if n in ('cc1','collect2') else '-print-file-name=')+n],text=True).strip()
 if Path(p).is_file():paths[n]=p
def tools():return {n:{'path':str(Path(p).resolve()),'sha256':sha(p)} for n,p in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['UBSAN_OPTIONS']='halt_on_error=1';os.environ['LSAN_OPTIONS']=''
flags='-Wall -Wextra -Werror -std=c99 -g -Isrc -D_GNU_SOURCE';link='-lm -lcrypto'
if config=='sanitizer':flags+=' -fsanitize=address,undefined -fno-omit-frame-pointer';link+=' -fsanitize=address,undefined'
os.environ['OWNED_ARRAY_ORIGIN_ARTIFACTS']=str(report/'fixture-products')
write('attribution.json',{'source':'1c50a0c85','config':config,'inner_subprocess_seconds':30,'phase_bound':1800,'instrumentation':config,'LSan':False})
run('owning-gate',['make','-j2','test-owned-array-origins','CC=gcc','CFLAGS='+flags,'LDFLAGS='+link]);write('final.json',{'status':'PASS','results':results})
