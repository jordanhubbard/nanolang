; ModuleID = 'src/nanoisa/managed_module.c'
source_filename = "src/nanoisa/managed_module.c"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-unknown"

%struct.NmsRuntime = type { ptr, i32, i32, ptr, ptr, ptr, i32, i32, i64, i64, i32, i32, i32, i32, i32 }
%struct.NmsSlot = type { ptr, i64, i32, i32, i32, i32, i32, i32, i32 }
%struct.NmsView = type { ptr, i32 }
%struct.NmsValue = type { i64, i32 }
%struct.NmsRecordDescriptor = type { i32, i32 }
%struct.NbpBig = type { [128 x i32], i32 }

@.str = private unnamed_addr constant [5 x i8] c"true\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"false\00", align 1
@nms_module_error = internal unnamed_addr global i32 0, align 4
@nms_module_ready = internal unnamed_addr global i1 false, align 4
@nms_module_instance = internal global %struct.NmsRuntime zeroinitializer, align 8
@free_blocks = internal unnamed_addr global ptr null, align 4
@pool_initialized = internal unnamed_addr global i1 false, align 4
@__heap_base = external global i8, align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define hidden void @nms_init(ptr noundef writeonly captures(none) initializes((0, 68)) %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #0 {
  store ptr null, ptr %0, align 8, !tbaa !5
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 8
  store i32 0, ptr %4, align 8, !tbaa !9
  %5 = getelementptr inbounds nuw i8, ptr %0, i32 4
  store i32 0, ptr %5, align 4, !tbaa !10
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 12
  store ptr %1, ptr %6, align 4, !tbaa !11
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 48
  store i32 %2, ptr %7, align 8, !tbaa !12
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 16
  store ptr null, ptr %8, align 8, !tbaa !13
  %9 = getelementptr inbounds nuw i8, ptr %0, i32 20
  store ptr null, ptr %9, align 4, !tbaa !14
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 28
  store i32 0, ptr %10, align 4, !tbaa !15
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 24
  store i32 0, ptr %11, align 8, !tbaa !16
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 56
  store i32 0, ptr %12, align 8, !tbaa !17
  %13 = getelementptr inbounds nuw i8, ptr %0, i32 52
  store i32 0, ptr %13, align 4, !tbaa !18
  %14 = getelementptr inbounds nuw i8, ptr %0, i32 40
  store i64 0, ptr %14, align 8, !tbaa !19
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 32
  store i64 0, ptr %15, align 8, !tbaa !20
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 64
  store i32 0, ptr %16, align 8, !tbaa !21
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 60
  store i32 0, ptr %17, align 4, !tbaa !22
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_view(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp ne ptr %0, null
  %5 = icmp ne ptr %2, null
  %6 = and i1 %4, %5
  br i1 %6, label %7, label %61

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %9 = load i32, ptr %8, align 8, !tbaa !21
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %61

11:                                               ; preds = %7
  %12 = icmp sgt i64 %1, -1
  br i1 %12, label %38, label %13

13:                                               ; preds = %11
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %61, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %18 = load i32, ptr %17, align 4, !tbaa !18
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  br i1 %20, label %61, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %23 = load ptr, ptr %22, align 8, !tbaa !13
  %24 = icmp eq ptr %23, null
  br i1 %24, label %61, label %25

25:                                               ; preds = %21
  %26 = trunc i64 %1 to i32
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i32 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i32 8
  %29 = load i64, ptr %28, align 8, !tbaa !23
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %61, label %31

31:                                               ; preds = %25
  %32 = getelementptr inbounds nuw i8, ptr %27, i32 28
  %33 = load i32, ptr %32, align 4, !tbaa !26
  %34 = icmp eq i32 %33, 1
  br i1 %34, label %35, label %61

35:                                               ; preds = %31
  %36 = load ptr, ptr %27, align 8, !tbaa !27
  store ptr %36, ptr %2, align 4, !tbaa !28
  %37 = getelementptr inbounds nuw i8, ptr %27, i32 16
  br label %57

38:                                               ; preds = %11
  %39 = icmp eq i64 %1, 0
  br i1 %39, label %61, label %40

40:                                               ; preds = %38
  %41 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %42 = load i32, ptr %41, align 8, !tbaa !12
  %43 = zext i32 %42 to i64
  %44 = icmp samesign ugt i64 %1, %43
  br i1 %44, label %61, label %45

45:                                               ; preds = %40
  %46 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %47 = load ptr, ptr %46, align 4, !tbaa !11
  %48 = icmp eq ptr %47, null
  br i1 %48, label %61, label %49

49:                                               ; preds = %45
  %50 = trunc nuw i64 %1 to i32
  %51 = getelementptr %struct.NmsView, ptr %47, i32 %50
  %52 = getelementptr i8, ptr %51, i32 -8
  %53 = load ptr, ptr %52, align 4, !tbaa !28
  %54 = icmp eq ptr %53, null
  br i1 %54, label %61, label %55

55:                                               ; preds = %49
  store ptr %53, ptr %2, align 4, !tbaa !28
  %56 = getelementptr i8, ptr %51, i32 -4
  br label %57

57:                                               ; preds = %55, %35
  %58 = phi ptr [ %37, %35 ], [ %56, %55 ]
  %59 = load i32, ptr %58, align 4, !tbaa !1
  %60 = getelementptr inbounds nuw i8, ptr %2, i32 4
  store i32 %59, ptr %60, align 4, !tbaa !30
  br label %61

61:                                               ; preds = %57, %21, %25, %16, %13, %31, %49, %38, %40, %45, %7, %3
  %62 = phi i32 [ 6, %3 ], [ 6, %49 ], [ 6, %25 ], [ 5, %7 ], [ 6, %38 ], [ 6, %45 ], [ 6, %40 ], [ 6, %21 ], [ 1, %31 ], [ 6, %13 ], [ 6, %16 ], [ 0, %57 ]
  ret i32 %62
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_prepare_collection(ptr noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %29, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %5 = load i32, ptr %4, align 8, !tbaa !21
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %29

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 28
  %9 = load i32, ptr %8, align 4, !tbaa !15
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %29

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %13 = load i32, ptr %12, align 4, !tbaa !18
  %14 = zext i32 %13 to i64
  %15 = add nuw nsw i64 %14, 1
  %16 = mul nuw nsw i64 %15, 9
  %17 = add nuw nsw i64 %16, 3
  %18 = and i64 %17, 274877906940
  %19 = shl nuw nsw i64 %15, 2
  %20 = add nuw nsw i64 %18, %19
  %21 = icmp samesign ugt i64 %20, 4294967295
  br i1 %21, label %29, label %22

22:                                               ; preds = %11
  %23 = tail call fastcc ptr @allocate(i64 noundef %20) #27
  %24 = icmp eq ptr %23, null
  br i1 %24, label %29, label %25

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 20
  store ptr %23, ptr %26, align 4, !tbaa !14
  %27 = load i32, ptr %12, align 4, !tbaa !18
  %28 = getelementptr inbounds nuw i8, ptr %0, i32 24
  store i32 %27, ptr %28, align 8, !tbaa !16
  store i32 1, ptr %8, align 4, !tbaa !15
  br label %29

29:                                               ; preds = %11, %25, %22, %7, %3, %1
  %30 = phi i32 [ 6, %1 ], [ 5, %3 ], [ 0, %7 ], [ 0, %25 ], [ 3, %22 ], [ 3, %11 ]
  ret i32 %30
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_string_array_create(ptr noundef captures(address_is_null) %0, ptr noundef writeonly captures(address_is_null) %1) local_unnamed_addr #3 {
  %3 = icmp ne ptr %0, null
  %4 = icmp ne ptr %1, null
  %5 = and i1 %3, %4
  br i1 %5, label %6, label %12

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %8 = load i32, ptr %7, align 8, !tbaa !21
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 2, i64 noundef 0, ptr noundef %1) #27
  br label %12

12:                                               ; preds = %6, %2, %10
  %13 = phi i32 [ 6, %2 ], [ %11, %10 ], [ 5, %6 ]
  ret i32 %13
}

; Function Attrs: nofree norecurse nosync nounwind
define internal fastcc range(i32 0, 4) i32 @publish_slot(ptr noundef nonnull captures(none) %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef range(i32 1, 6) %4, i64 noundef range(i64 0, 4294967296) %5, ptr noundef nonnull writeonly captures(none) %6) unnamed_addr #3 {
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %9 = load i64, ptr %8, align 8, !tbaa !20
  %10 = xor i64 %9, -1
  %11 = icmp ugt i64 %5, %10
  br i1 %11, label %262, label %12

12:                                               ; preds = %7
  %13 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %14 = load i32, ptr %13, align 4, !tbaa !18
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 56
  %16 = load i32, ptr %15, align 8, !tbaa !17
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %21, label %18

18:                                               ; preds = %12
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %20 = load ptr, ptr %19, align 8, !tbaa !13
  br label %242

21:                                               ; preds = %12
  %22 = icmp ugt i32 %14, -3
  br i1 %22, label %262, label %23

23:                                               ; preds = %21
  %24 = icmp eq i32 %14, 0
  %25 = tail call i32 @llvm.smax.i32(i32 %14, i32 -1)
  %26 = shl i32 %25, 1
  %27 = select i1 %24, i32 8, i32 %26
  %28 = icmp ugt i32 %27, 89478484
  br i1 %28, label %262, label %29

29:                                               ; preds = %23
  %30 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %31 = load ptr, ptr %30, align 8, !tbaa !13
  %32 = icmp eq i32 %27, %14
  br i1 %32, label %242, label %33

33:                                               ; preds = %29
  %34 = zext nneg i32 %27 to i64
  %35 = mul nuw nsw i64 %34, 48
  %36 = add nuw nsw i64 %35, 48
  %37 = tail call fastcc ptr @allocate(i64 noundef %36) #27
  %38 = icmp eq ptr %37, null
  br i1 %38, label %262, label %39

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %0, i32 28
  %41 = load i32, ptr %40, align 4, !tbaa !15
  %42 = icmp eq i32 %41, 0
  br i1 %42, label %93, label %43

43:                                               ; preds = %39
  %44 = or disjoint i64 %34, 1
  %45 = mul nuw nsw i64 %44, 9
  %46 = add nuw nsw i64 %45, 3
  %47 = and i64 %46, 4294967292
  %48 = shl nuw nsw i64 %44, 2
  %49 = add nuw nsw i64 %47, %48
  %50 = tail call fastcc ptr @allocate(i64 noundef %49) #27
  %51 = icmp eq ptr %50, null
  br i1 %51, label %52, label %93

52:                                               ; preds = %43
  %53 = getelementptr inbounds i8, ptr %37, i32 -16
  br label %54

54:                                               ; preds = %54, %52
  %55 = phi ptr [ null, %52 ], [ %57, %54 ]
  %56 = phi ptr [ @free_blocks, %52 ], [ %61, %54 ]
  %57 = load ptr, ptr %56, align 4, !tbaa !31
  %58 = icmp ne ptr %57, null
  %59 = icmp ult ptr %57, %53
  %60 = and i1 %58, %59
  %61 = getelementptr inbounds nuw i8, ptr %57, i32 8
  br i1 %60, label %54, label %62, !llvm.loop !33

62:                                               ; preds = %54
  %63 = ptrtoint ptr %53 to i32
  %64 = getelementptr inbounds i8, ptr %37, i32 -8
  store ptr %57, ptr %64, align 8, !tbaa !35
  br i1 %58, label %65, label %76

65:                                               ; preds = %62
  %66 = ptrtoint ptr %57 to i32
  %67 = zext i32 %63 to i64
  %68 = load i64, ptr %53, align 8, !tbaa !37
  %69 = add i64 %68, %67
  %70 = zext i32 %66 to i64
  %71 = icmp eq i64 %69, %70
  br i1 %71, label %72, label %76

72:                                               ; preds = %65
  %73 = load i64, ptr %57, align 8, !tbaa !37
  %74 = add i64 %73, %68
  store i64 %74, ptr %53, align 8, !tbaa !37
  %75 = load ptr, ptr %61, align 8, !tbaa !35
  store ptr %75, ptr %64, align 8, !tbaa !35
  br label %76

76:                                               ; preds = %72, %65, %62
  %77 = phi ptr [ %75, %72 ], [ %57, %65 ], [ null, %62 ]
  %78 = icmp eq ptr %55, null
  br i1 %78, label %92, label %79

79:                                               ; preds = %76
  %80 = ptrtoint ptr %55 to i32
  %81 = zext i32 %80 to i64
  %82 = load i64, ptr %55, align 8, !tbaa !37
  %83 = add i64 %82, %81
  %84 = zext i32 %63 to i64
  %85 = icmp eq i64 %83, %84
  br i1 %85, label %86, label %90

86:                                               ; preds = %79
  %87 = load i64, ptr %53, align 8, !tbaa !37
  %88 = add i64 %87, %82
  store i64 %88, ptr %55, align 8, !tbaa !37
  %89 = getelementptr inbounds nuw i8, ptr %55, i32 8
  store ptr %77, ptr %89, align 8, !tbaa !35
  br label %262

90:                                               ; preds = %79
  %91 = getelementptr inbounds nuw i8, ptr %55, i32 8
  store ptr %53, ptr %91, align 8, !tbaa !35
  br label %262

92:                                               ; preds = %76
  store ptr %53, ptr @free_blocks, align 4, !tbaa !31
  br label %262

93:                                               ; preds = %43, %39
  %94 = phi ptr [ %50, %43 ], [ null, %39 ]
  %95 = load ptr, ptr %30, align 8, !tbaa !13
  %96 = icmp eq ptr %95, null
  br label %100

97:                                               ; preds = %149
  %98 = load i32, ptr %40, align 4, !tbaa !15
  %99 = icmp eq i32 %98, 0
  br i1 %99, label %198, label %152

100:                                              ; preds = %93, %149
  %101 = phi i64 [ 0, %93 ], [ %150, %149 ]
  br i1 %96, label %135, label %102

102:                                              ; preds = %100
  %103 = load i32, ptr %13, align 4, !tbaa !18
  %104 = zext i32 %103 to i64
  %105 = icmp samesign ugt i64 %101, %104
  br i1 %105, label %135, label %106

106:                                              ; preds = %102
  %107 = trunc nuw i64 %101 to i32
  %108 = getelementptr inbounds nuw %struct.NmsSlot, ptr %95, i32 %107
  %109 = load ptr, ptr %108, align 8, !tbaa !27
  %110 = getelementptr inbounds nuw %struct.NmsSlot, ptr %37, i32 %107
  store ptr %109, ptr %110, align 8, !tbaa !27
  %111 = getelementptr inbounds nuw i8, ptr %108, i32 8
  %112 = load i64, ptr %111, align 8, !tbaa !23
  %113 = getelementptr inbounds nuw i8, ptr %110, i32 8
  store i64 %112, ptr %113, align 8, !tbaa !23
  %114 = getelementptr inbounds nuw i8, ptr %108, i32 16
  %115 = load i32, ptr %114, align 8, !tbaa !38
  %116 = getelementptr inbounds nuw i8, ptr %110, i32 16
  store i32 %115, ptr %116, align 8, !tbaa !38
  %117 = getelementptr inbounds nuw i8, ptr %108, i32 20
  %118 = load i32, ptr %117, align 4, !tbaa !39
  %119 = getelementptr inbounds nuw i8, ptr %110, i32 20
  store i32 %118, ptr %119, align 4, !tbaa !39
  %120 = getelementptr inbounds nuw i8, ptr %108, i32 32
  %121 = load i32, ptr %120, align 8, !tbaa !40
  %122 = getelementptr inbounds nuw i8, ptr %110, i32 32
  store i32 %121, ptr %122, align 8, !tbaa !40
  %123 = getelementptr inbounds nuw i8, ptr %108, i32 36
  %124 = load i32, ptr %123, align 4, !tbaa !41
  %125 = getelementptr inbounds nuw i8, ptr %110, i32 36
  store i32 %124, ptr %125, align 4, !tbaa !41
  %126 = getelementptr inbounds nuw i8, ptr %108, i32 40
  %127 = load i32, ptr %126, align 8, !tbaa !42
  %128 = getelementptr inbounds nuw i8, ptr %110, i32 40
  store i32 %127, ptr %128, align 8, !tbaa !42
  %129 = getelementptr inbounds nuw i8, ptr %108, i32 28
  %130 = load i32, ptr %129, align 4, !tbaa !26
  %131 = getelementptr inbounds nuw i8, ptr %110, i32 28
  store i32 %130, ptr %131, align 4, !tbaa !26
  %132 = getelementptr inbounds nuw i8, ptr %108, i32 24
  %133 = load i32, ptr %132, align 8, !tbaa !43
  %134 = getelementptr inbounds nuw i8, ptr %110, i32 24
  store i32 %133, ptr %134, align 8, !tbaa !43
  br label %149

135:                                              ; preds = %102, %100
  %136 = trunc nuw i64 %101 to i32
  %137 = getelementptr inbounds nuw %struct.NmsSlot, ptr %37, i32 %136
  store ptr null, ptr %137, align 8, !tbaa !27
  %138 = getelementptr inbounds nuw i8, ptr %137, i32 8
  store i64 0, ptr %138, align 8, !tbaa !23
  %139 = getelementptr inbounds nuw i8, ptr %137, i32 16
  store i32 0, ptr %139, align 8, !tbaa !38
  %140 = getelementptr inbounds nuw i8, ptr %137, i32 28
  store i32 0, ptr %140, align 4, !tbaa !26
  %141 = getelementptr inbounds nuw i8, ptr %137, i32 24
  store i32 0, ptr %141, align 8, !tbaa !43
  %142 = getelementptr inbounds nuw i8, ptr %137, i32 32
  store i32 0, ptr %142, align 8, !tbaa !40
  %143 = getelementptr inbounds nuw i8, ptr %137, i32 36
  store i32 0, ptr %143, align 4, !tbaa !41
  %144 = getelementptr inbounds nuw i8, ptr %137, i32 40
  store i32 0, ptr %144, align 8, !tbaa !42
  %145 = icmp samesign ult i64 %101, %34
  %146 = add i32 %136, 1
  %147 = select i1 %145, i32 %146, i32 0
  %148 = getelementptr inbounds nuw i8, ptr %137, i32 20
  store i32 %147, ptr %148, align 4, !tbaa !39
  br label %149

149:                                              ; preds = %106, %135
  %150 = add nuw nsw i64 %101, 1
  %151 = icmp eq i64 %101, %34
  br i1 %151, label %97, label %100, !llvm.loop !44

152:                                              ; preds = %97
  %153 = getelementptr inbounds nuw i8, ptr %0, i32 20
  %154 = load ptr, ptr %153, align 4, !tbaa !14
  store ptr %94, ptr %153, align 4, !tbaa !14
  %155 = getelementptr inbounds nuw i8, ptr %0, i32 24
  store i32 %27, ptr %155, align 8, !tbaa !16
  %156 = icmp eq ptr %154, null
  br i1 %156, label %198, label %157

157:                                              ; preds = %152
  %158 = getelementptr inbounds i8, ptr %154, i32 -16
  br label %159

159:                                              ; preds = %159, %157
  %160 = phi ptr [ null, %157 ], [ %162, %159 ]
  %161 = phi ptr [ @free_blocks, %157 ], [ %166, %159 ]
  %162 = load ptr, ptr %161, align 4, !tbaa !31
  %163 = icmp ne ptr %162, null
  %164 = icmp ult ptr %162, %158
  %165 = and i1 %163, %164
  %166 = getelementptr inbounds nuw i8, ptr %162, i32 8
  br i1 %165, label %159, label %167, !llvm.loop !33

167:                                              ; preds = %159
  %168 = ptrtoint ptr %158 to i32
  %169 = getelementptr inbounds i8, ptr %154, i32 -8
  store ptr %162, ptr %169, align 8, !tbaa !35
  br i1 %163, label %170, label %181

170:                                              ; preds = %167
  %171 = ptrtoint ptr %162 to i32
  %172 = zext i32 %168 to i64
  %173 = load i64, ptr %158, align 8, !tbaa !37
  %174 = add i64 %173, %172
  %175 = zext i32 %171 to i64
  %176 = icmp eq i64 %174, %175
  br i1 %176, label %177, label %181

177:                                              ; preds = %170
  %178 = load i64, ptr %162, align 8, !tbaa !37
  %179 = add i64 %178, %173
  store i64 %179, ptr %158, align 8, !tbaa !37
  %180 = load ptr, ptr %166, align 8, !tbaa !35
  store ptr %180, ptr %169, align 8, !tbaa !35
  br label %181

181:                                              ; preds = %177, %170, %167
  %182 = phi ptr [ %180, %177 ], [ %162, %170 ], [ null, %167 ]
  %183 = icmp eq ptr %160, null
  br i1 %183, label %197, label %184

184:                                              ; preds = %181
  %185 = ptrtoint ptr %160 to i32
  %186 = zext i32 %185 to i64
  %187 = load i64, ptr %160, align 8, !tbaa !37
  %188 = add i64 %187, %186
  %189 = zext i32 %168 to i64
  %190 = icmp eq i64 %188, %189
  br i1 %190, label %191, label %195

191:                                              ; preds = %184
  %192 = load i64, ptr %158, align 8, !tbaa !37
  %193 = add i64 %192, %187
  store i64 %193, ptr %160, align 8, !tbaa !37
  %194 = getelementptr inbounds nuw i8, ptr %160, i32 8
  store ptr %182, ptr %194, align 8, !tbaa !35
  br label %198

195:                                              ; preds = %184
  %196 = getelementptr inbounds nuw i8, ptr %160, i32 8
  store ptr %158, ptr %196, align 8, !tbaa !35
  br label %198

197:                                              ; preds = %181
  store ptr %158, ptr @free_blocks, align 4, !tbaa !31
  br label %198

198:                                              ; preds = %197, %195, %191, %152, %97
  store ptr %37, ptr %30, align 8, !tbaa !13
  %199 = load i32, ptr %13, align 4, !tbaa !18
  %200 = add i32 %199, 1
  store i32 %27, ptr %13, align 4, !tbaa !18
  br i1 %96, label %242, label %201

201:                                              ; preds = %198
  %202 = getelementptr inbounds i8, ptr %95, i32 -16
  br label %203

203:                                              ; preds = %203, %201
  %204 = phi ptr [ null, %201 ], [ %206, %203 ]
  %205 = phi ptr [ @free_blocks, %201 ], [ %210, %203 ]
  %206 = load ptr, ptr %205, align 4, !tbaa !31
  %207 = icmp ne ptr %206, null
  %208 = icmp ult ptr %206, %202
  %209 = and i1 %207, %208
  %210 = getelementptr inbounds nuw i8, ptr %206, i32 8
  br i1 %209, label %203, label %211, !llvm.loop !33

211:                                              ; preds = %203
  %212 = ptrtoint ptr %202 to i32
  %213 = getelementptr inbounds i8, ptr %95, i32 -8
  store ptr %206, ptr %213, align 8, !tbaa !35
  br i1 %207, label %214, label %225

214:                                              ; preds = %211
  %215 = ptrtoint ptr %206 to i32
  %216 = zext i32 %212 to i64
  %217 = load i64, ptr %202, align 8, !tbaa !37
  %218 = add i64 %217, %216
  %219 = zext i32 %215 to i64
  %220 = icmp eq i64 %218, %219
  br i1 %220, label %221, label %225

221:                                              ; preds = %214
  %222 = load i64, ptr %206, align 8, !tbaa !37
  %223 = add i64 %222, %217
  store i64 %223, ptr %202, align 8, !tbaa !37
  %224 = load ptr, ptr %210, align 8, !tbaa !35
  store ptr %224, ptr %213, align 8, !tbaa !35
  br label %225

225:                                              ; preds = %221, %214, %211
  %226 = phi ptr [ %224, %221 ], [ %206, %214 ], [ null, %211 ]
  %227 = icmp eq ptr %204, null
  br i1 %227, label %241, label %228

228:                                              ; preds = %225
  %229 = ptrtoint ptr %204 to i32
  %230 = zext i32 %229 to i64
  %231 = load i64, ptr %204, align 8, !tbaa !37
  %232 = add i64 %231, %230
  %233 = zext i32 %212 to i64
  %234 = icmp eq i64 %232, %233
  br i1 %234, label %235, label %239

235:                                              ; preds = %228
  %236 = load i64, ptr %202, align 8, !tbaa !37
  %237 = add i64 %236, %231
  store i64 %237, ptr %204, align 8, !tbaa !37
  %238 = getelementptr inbounds nuw i8, ptr %204, i32 8
  store ptr %226, ptr %238, align 8, !tbaa !35
  br label %242

239:                                              ; preds = %228
  %240 = getelementptr inbounds nuw i8, ptr %204, i32 8
  store ptr %202, ptr %240, align 8, !tbaa !35
  br label %242

241:                                              ; preds = %225
  store ptr %202, ptr @free_blocks, align 4, !tbaa !31
  br label %242

242:                                              ; preds = %241, %239, %235, %198, %18, %29
  %243 = phi i32 [ %16, %18 ], [ 0, %29 ], [ %200, %198 ], [ %200, %235 ], [ %200, %239 ], [ %200, %241 ]
  %244 = phi ptr [ %20, %18 ], [ %31, %29 ], [ %37, %198 ], [ %37, %235 ], [ %37, %239 ], [ %37, %241 ]
  %245 = getelementptr inbounds nuw %struct.NmsSlot, ptr %244, i32 %243
  %246 = getelementptr inbounds nuw i8, ptr %245, i32 20
  %247 = load i32, ptr %246, align 4, !tbaa !39
  store i32 %247, ptr %15, align 8, !tbaa !17
  store ptr %1, ptr %245, align 8, !tbaa !27
  %248 = getelementptr inbounds nuw i8, ptr %245, i32 16
  store i32 %2, ptr %248, align 8, !tbaa !38
  %249 = getelementptr inbounds nuw i8, ptr %245, i32 32
  store i32 0, ptr %249, align 8, !tbaa !40
  %250 = getelementptr inbounds nuw i8, ptr %245, i32 36
  store i32 0, ptr %250, align 4, !tbaa !41
  %251 = getelementptr inbounds nuw i8, ptr %245, i32 40
  store i32 0, ptr %251, align 8, !tbaa !42
  %252 = getelementptr inbounds nuw i8, ptr %245, i32 28
  store i32 %4, ptr %252, align 4, !tbaa !26
  %253 = getelementptr inbounds nuw i8, ptr %245, i32 24
  store i32 %3, ptr %253, align 8, !tbaa !43
  %254 = getelementptr inbounds nuw i8, ptr %245, i32 8
  store i64 1, ptr %254, align 8, !tbaa !23
  store i32 0, ptr %246, align 4, !tbaa !39
  %255 = load i64, ptr %8, align 8, !tbaa !20
  %256 = add i64 %255, %5
  store i64 %256, ptr %8, align 8, !tbaa !20
  %257 = getelementptr inbounds nuw i8, ptr %0, i32 40
  %258 = load i64, ptr %257, align 8, !tbaa !19
  %259 = add i64 %258, 1
  store i64 %259, ptr %257, align 8, !tbaa !19
  %260 = zext i32 %243 to i64
  %261 = or disjoint i64 %260, -9223372036854775808
  store i64 %261, ptr %6, align 8, !tbaa !45
  br label %262

262:                                              ; preds = %92, %90, %86, %21, %23, %33, %242, %7
  %263 = phi i32 [ 3, %7 ], [ 3, %23 ], [ 3, %21 ], [ 0, %242 ], [ 3, %33 ], [ 3, %86 ], [ 3, %90 ], [ 3, %92 ]
  ret i32 %263
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_string_array_append(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2) local_unnamed_addr #4 {
  %4 = icmp sgt i64 %1, -1
  %5 = icmp eq ptr %0, null
  br i1 %4, label %6, label %29

6:                                                ; preds = %3
  br i1 %5, label %210, label %7

7:                                                ; preds = %6
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %9 = load i32, ptr %8, align 8, !tbaa !21
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %210

11:                                               ; preds = %7
  %12 = icmp eq i64 %1, 0
  br i1 %12, label %210, label %13

13:                                               ; preds = %11
  %14 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %15 = load i32, ptr %14, align 8, !tbaa !12
  %16 = zext i32 %15 to i64
  %17 = icmp samesign ugt i64 %1, %16
  br i1 %17, label %210, label %18

18:                                               ; preds = %13
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %20 = load ptr, ptr %19, align 4, !tbaa !11
  %21 = icmp eq ptr %20, null
  br i1 %21, label %210, label %22

22:                                               ; preds = %18
  %23 = trunc nuw i64 %1 to i32
  %24 = getelementptr %struct.NmsView, ptr %20, i32 %23
  %25 = getelementptr i8, ptr %24, i32 -8
  %26 = load ptr, ptr %25, align 4, !tbaa !28
  %27 = icmp eq ptr %26, null
  %28 = select i1 %27, i32 6, i32 1
  br label %210

29:                                               ; preds = %3
  br i1 %5, label %210, label %30

30:                                               ; preds = %29
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %32 = load i32, ptr %31, align 8, !tbaa !21
  %33 = icmp eq i32 %32, 0
  br i1 %33, label %34, label %210

34:                                               ; preds = %30
  %35 = and i64 %1, 9223372036854775807
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %210, label %37

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %39 = load i32, ptr %38, align 4, !tbaa !18
  %40 = freeze i32 %39
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %35, %41
  br i1 %42, label %210, label %43

43:                                               ; preds = %37
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %45 = load ptr, ptr %44, align 8, !tbaa !13
  %46 = icmp eq ptr %45, null
  br i1 %46, label %210, label %47

47:                                               ; preds = %43
  %48 = trunc i64 %1 to i32
  %49 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i32 %48
  %50 = getelementptr inbounds nuw i8, ptr %49, i32 8
  %51 = load i64, ptr %50, align 8, !tbaa !23
  %52 = icmp eq i64 %51, 0
  br i1 %52, label %210, label %53

53:                                               ; preds = %47
  %54 = getelementptr inbounds nuw i8, ptr %49, i32 28
  %55 = load i32, ptr %54, align 4, !tbaa !26
  %56 = icmp eq i32 %55, 2
  br i1 %56, label %57, label %210

57:                                               ; preds = %53
  %58 = icmp sgt i64 %2, -1
  br i1 %58, label %73, label %59

59:                                               ; preds = %57
  %60 = and i64 %2, 9223372036854775807
  %61 = add nsw i64 %60, -1
  %62 = icmp ult i64 %61, %41
  br i1 %62, label %63, label %210

63:                                               ; preds = %59
  %64 = trunc i64 %2 to i32
  %65 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i32 %64
  %66 = getelementptr inbounds nuw i8, ptr %65, i32 8
  %67 = load i64, ptr %66, align 8, !tbaa !23
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %210, label %69

69:                                               ; preds = %63
  %70 = getelementptr inbounds nuw i8, ptr %65, i32 28
  %71 = load i32, ptr %70, align 4, !tbaa !26
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %90, label %210

73:                                               ; preds = %57
  %74 = icmp eq i64 %2, 0
  br i1 %74, label %210, label %75

75:                                               ; preds = %73
  %76 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %77 = load i32, ptr %76, align 8, !tbaa !12
  %78 = zext i32 %77 to i64
  %79 = icmp samesign ugt i64 %2, %78
  br i1 %79, label %210, label %80

80:                                               ; preds = %75
  %81 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %82 = load ptr, ptr %81, align 4, !tbaa !11
  %83 = icmp eq ptr %82, null
  br i1 %83, label %210, label %84

84:                                               ; preds = %80
  %85 = trunc nuw i64 %2 to i32
  %86 = getelementptr %struct.NmsView, ptr %82, i32 %85
  %87 = getelementptr i8, ptr %86, i32 -8
  %88 = load ptr, ptr %87, align 4, !tbaa !28
  %89 = icmp eq ptr %88, null
  br i1 %89, label %210, label %90

90:                                               ; preds = %84, %69
  %91 = getelementptr inbounds nuw i8, ptr %49, i32 16
  %92 = load i32, ptr %91, align 8, !tbaa !38
  %93 = icmp eq i32 %92, -1
  br i1 %93, label %210, label %94

94:                                               ; preds = %90
  %95 = getelementptr inbounds nuw i8, ptr %49, i32 24
  %96 = load i32, ptr %95, align 8, !tbaa !43
  %97 = load ptr, ptr %49, align 8, !tbaa !27
  %98 = icmp eq i32 %92, %96
  br i1 %98, label %99, label %148

99:                                               ; preds = %94
  %100 = icmp eq i32 %92, 0
  %101 = shl i32 %92, 1
  %102 = icmp sgt i32 %92, -1
  %103 = select i1 %102, i32 %101, i32 -1
  %104 = select i1 %100, i32 4, i32 %103
  %105 = zext i32 %104 to i64
  %106 = shl nuw nsw i64 %105, 3
  %107 = icmp ugt i32 %104, 536870911
  br i1 %107, label %210, label %108

108:                                              ; preds = %99
  %109 = sub i32 %104, %92
  %110 = zext i32 %109 to i64
  %111 = shl nuw nsw i64 %110, 3
  %112 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %113 = load i64, ptr %112, align 8, !tbaa !20
  %114 = xor i64 %113, -1
  %115 = icmp ugt i64 %111, %114
  br i1 %115, label %210, label %116

116:                                              ; preds = %108
  %117 = tail call fastcc ptr @allocate(i64 noundef %106) #27
  %118 = icmp eq ptr %117, null
  br i1 %118, label %210, label %119

119:                                              ; preds = %116
  %120 = load ptr, ptr %49, align 8, !tbaa !27
  %121 = load i32, ptr %91, align 8, !tbaa !38
  %122 = zext i32 %121 to i64
  %123 = shl nuw nsw i64 %122, 3
  %124 = icmp eq i32 %121, 0
  br i1 %124, label %148, label %125

125:                                              ; preds = %119, %125
  %126 = phi i64 [ %146, %125 ], [ 0, %119 ]
  %127 = trunc i64 %126 to i32
  %128 = getelementptr inbounds nuw i8, ptr %120, i32 %127
  %129 = load volatile i8, ptr %128, align 1, !tbaa !46
  %130 = getelementptr inbounds nuw i8, ptr %117, i32 %127
  store volatile i8 %129, ptr %130, align 1, !tbaa !46
  %131 = trunc i64 %126 to i32
  %132 = or disjoint i32 %131, 1
  %133 = getelementptr inbounds nuw i8, ptr %120, i32 %132
  %134 = load volatile i8, ptr %133, align 1, !tbaa !46
  %135 = getelementptr inbounds nuw i8, ptr %117, i32 %132
  store volatile i8 %134, ptr %135, align 1, !tbaa !46
  %136 = trunc i64 %126 to i32
  %137 = or disjoint i32 %136, 2
  %138 = getelementptr inbounds nuw i8, ptr %120, i32 %137
  %139 = load volatile i8, ptr %138, align 1, !tbaa !46
  %140 = getelementptr inbounds nuw i8, ptr %117, i32 %137
  store volatile i8 %139, ptr %140, align 1, !tbaa !46
  %141 = trunc i64 %126 to i32
  %142 = or disjoint i32 %141, 3
  %143 = getelementptr inbounds nuw i8, ptr %120, i32 %142
  %144 = load volatile i8, ptr %143, align 1, !tbaa !46
  %145 = getelementptr inbounds nuw i8, ptr %117, i32 %142
  store volatile i8 %144, ptr %145, align 1, !tbaa !46
  %146 = add nuw nsw i64 %126, 4
  %147 = icmp eq i64 %146, %123
  br i1 %147, label %148, label %125, !llvm.loop !47

148:                                              ; preds = %125, %119, %94
  %149 = phi i32 [ %96, %94 ], [ %104, %119 ], [ %104, %125 ]
  %150 = phi ptr [ %97, %94 ], [ %117, %119 ], [ %117, %125 ]
  %151 = load i32, ptr %31, align 8, !tbaa !21
  %152 = icmp eq i32 %151, 0
  br i1 %58, label %153, label %171

153:                                              ; preds = %148
  br i1 %152, label %154, label %190

154:                                              ; preds = %153
  %155 = icmp eq i64 %2, 0
  br i1 %155, label %190, label %156

156:                                              ; preds = %154
  %157 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %158 = load i32, ptr %157, align 8, !tbaa !12
  %159 = zext i32 %158 to i64
  %160 = icmp samesign ugt i64 %2, %159
  br i1 %160, label %190, label %161

161:                                              ; preds = %156
  %162 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %163 = load ptr, ptr %162, align 4, !tbaa !11
  %164 = icmp eq ptr %163, null
  br i1 %164, label %190, label %165

165:                                              ; preds = %161
  %166 = trunc nuw i64 %2 to i32
  %167 = getelementptr %struct.NmsView, ptr %163, i32 %166
  %168 = getelementptr i8, ptr %167, i32 -8
  %169 = load ptr, ptr %168, align 4, !tbaa !28
  %170 = icmp eq ptr %169, null
  br i1 %170, label %190, label %195

171:                                              ; preds = %148
  br i1 %152, label %172, label %190

172:                                              ; preds = %171
  %173 = and i64 %2, 9223372036854775807
  %174 = icmp eq i64 %173, 0
  br i1 %174, label %190, label %175

175:                                              ; preds = %172
  %176 = load i32, ptr %38, align 4, !tbaa !18
  %177 = zext i32 %176 to i64
  %178 = icmp samesign ugt i64 %173, %177
  br i1 %178, label %190, label %179

179:                                              ; preds = %175
  %180 = load ptr, ptr %44, align 8, !tbaa !13
  %181 = icmp eq ptr %180, null
  br i1 %181, label %190, label %182

182:                                              ; preds = %179
  %183 = trunc i64 %2 to i32
  %184 = getelementptr inbounds nuw %struct.NmsSlot, ptr %180, i32 %183
  %185 = getelementptr inbounds nuw i8, ptr %184, i32 8
  %186 = load i64, ptr %185, align 8, !tbaa !23
  switch i64 %186, label %187 [
    i64 0, label %190
    i64 -1, label %189
  ]

187:                                              ; preds = %182
  %188 = add nuw i64 %186, 1
  store i64 %188, ptr %185, align 8, !tbaa !23
  br label %195

189:                                              ; preds = %182
  br label %190

190:                                              ; preds = %165, %156, %189, %182, %153, %154, %161, %171, %172, %175, %179
  %191 = phi i32 [ 6, %156 ], [ 6, %179 ], [ 6, %175 ], [ 6, %172 ], [ 5, %171 ], [ 6, %161 ], [ 6, %154 ], [ 5, %153 ], [ 6, %182 ], [ 3, %189 ], [ 6, %165 ]
  %192 = load ptr, ptr %49, align 8, !tbaa !27
  %193 = icmp eq ptr %150, %192
  br i1 %193, label %210, label %194

194:                                              ; preds = %190
  tail call fastcc void @deallocate(ptr noundef %150) #27
  br label %210

195:                                              ; preds = %187, %165
  %196 = load ptr, ptr %49, align 8, !tbaa !27
  %197 = icmp eq ptr %150, %196
  br i1 %197, label %206, label %198

198:                                              ; preds = %195
  %199 = load i32, ptr %95, align 8, !tbaa !43
  %200 = sub i32 %149, %199
  %201 = zext i32 %200 to i64
  %202 = shl nuw nsw i64 %201, 3
  %203 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %204 = load i64, ptr %203, align 8, !tbaa !20
  %205 = add i64 %202, %204
  store i64 %205, ptr %203, align 8, !tbaa !20
  tail call fastcc void @deallocate(ptr noundef %196) #27
  store ptr %150, ptr %49, align 8, !tbaa !27
  store i32 %149, ptr %95, align 8, !tbaa !43
  br label %206

206:                                              ; preds = %198, %195
  %207 = load i32, ptr %91, align 8, !tbaa !38
  %208 = add i32 %207, 1
  store i32 %208, ptr %91, align 8, !tbaa !38
  %209 = getelementptr inbounds nuw i64, ptr %150, i32 %207
  store i64 %2, ptr %209, align 8, !tbaa !45
  br label %210

210:                                              ; preds = %59, %69, %75, %80, %73, %63, %84, %18, %11, %7, %13, %22, %6, %30, %47, %43, %37, %34, %29, %206, %194, %190, %116, %108, %99, %90, %53
  %211 = phi i32 [ 3, %99 ], [ 1, %53 ], [ 6, %29 ], [ 3, %90 ], [ %191, %190 ], [ 0, %206 ], [ %191, %194 ], [ 3, %116 ], [ 3, %108 ], [ 6, %18 ], [ 6, %11 ], [ 5, %7 ], [ 6, %13 ], [ %28, %22 ], [ 6, %6 ], [ 5, %30 ], [ 6, %47 ], [ 6, %43 ], [ 6, %37 ], [ 6, %34 ], [ 6, %59 ], [ 1, %69 ], [ 6, %84 ], [ 6, %75 ], [ 6, %80 ], [ 6, %73 ], [ 6, %63 ]
  ret i32 %211
}

; Function Attrs: nofree norecurse nosync nounwind
define internal fastcc ptr @allocate(i64 noundef %0) unnamed_addr #3 {
  %2 = icmp ugt i64 %0, 4294967264
  br i1 %2, label %133, label %3

3:                                                ; preds = %1
  %4 = add nuw nsw i64 %0, 31
  %5 = and i64 %4, 8589934576
  %6 = load i1, ptr @pool_initialized, align 4
  br i1 %6, label %22, label %7

7:                                                ; preds = %3
  store i1 true, ptr @pool_initialized, align 4
  %8 = zext i32 ptrtoint (ptr @__heap_base to i32) to i64
  %9 = add nuw nsw i64 %8, 15
  %10 = and i64 %9, 8589934576
  %11 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %12 = zext i32 %11 to i64
  %13 = shl nuw nsw i64 %12, 16
  %14 = icmp samesign ult i64 %10, %13
  br i1 %14, label %15, label %22

15:                                               ; preds = %7
  %16 = sub nuw nsw i64 %13, %10
  %17 = icmp samesign ugt i64 %16, 31
  br i1 %17, label %18, label %22

18:                                               ; preds = %15
  %19 = trunc i64 %10 to i32
  %20 = inttoptr i32 %19 to ptr
  store i64 %16, ptr %20, align 16, !tbaa !37
  %21 = getelementptr inbounds nuw i8, ptr %20, i32 8
  store ptr null, ptr %21, align 8, !tbaa !35
  store ptr %20, ptr @free_blocks, align 4, !tbaa !31
  br label %22

22:                                               ; preds = %18, %15, %7, %3
  br label %23

23:                                               ; preds = %132, %22
  %24 = phi i1 [ true, %22 ], [ false, %132 ]
  %25 = load ptr, ptr @free_blocks, align 4, !tbaa !31
  %26 = icmp eq ptr %25, null
  br i1 %26, label %59, label %27

27:                                               ; preds = %23
  %28 = load i64, ptr %25, align 8, !tbaa !37
  %29 = icmp ult i64 %28, %5
  br i1 %29, label %50, label %35

30:                                               ; preds = %50
  %31 = load i64, ptr %53, align 8, !tbaa !37
  %32 = icmp ult i64 %31, %5
  br i1 %32, label %50, label %33, !llvm.loop !48

33:                                               ; preds = %30
  %34 = getelementptr inbounds nuw i8, ptr %51, i32 8
  br label %35

35:                                               ; preds = %27, %33
  %36 = phi ptr [ %53, %33 ], [ %25, %27 ]
  %37 = phi ptr [ %34, %33 ], [ @free_blocks, %27 ]
  %38 = phi i64 [ %31, %33 ], [ %28, %27 ]
  %39 = sub nuw i64 %38, %5
  %40 = icmp ugt i64 %39, 31
  br i1 %40, label %41, label %47

41:                                               ; preds = %35
  %42 = trunc nuw i64 %5 to i32
  %43 = getelementptr inbounds nuw i8, ptr %36, i32 %42
  store i64 %39, ptr %43, align 8, !tbaa !37
  %44 = getelementptr inbounds nuw i8, ptr %36, i32 8
  %45 = load ptr, ptr %44, align 8, !tbaa !35
  %46 = getelementptr inbounds nuw i8, ptr %43, i32 8
  store ptr %45, ptr %46, align 8, !tbaa !35
  store i64 %5, ptr %36, align 8, !tbaa !37
  br label %55

47:                                               ; preds = %35
  %48 = getelementptr inbounds nuw i8, ptr %36, i32 8
  %49 = load ptr, ptr %48, align 8, !tbaa !35
  br label %55

50:                                               ; preds = %27, %30
  %51 = phi ptr [ %53, %30 ], [ %25, %27 ]
  %52 = getelementptr inbounds nuw i8, ptr %51, i32 8
  %53 = load ptr, ptr %52, align 4, !tbaa !31
  %54 = icmp eq ptr %53, null
  br i1 %54, label %59, label %30, !llvm.loop !48

55:                                               ; preds = %47, %41
  %56 = phi ptr [ %43, %41 ], [ %49, %47 ]
  store ptr %56, ptr %37, align 4, !tbaa !31
  %57 = getelementptr inbounds nuw i8, ptr %36, i32 8
  store ptr null, ptr %57, align 8, !tbaa !35
  %58 = getelementptr inbounds nuw i8, ptr %36, i32 16
  br label %133

59:                                               ; preds = %50, %23
  br i1 %24, label %60, label %133

60:                                               ; preds = %59
  %61 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %62 = zext i32 %61 to i64
  br label %63

63:                                               ; preds = %66, %60
  %64 = phi ptr [ %25, %60 ], [ %68, %66 ]
  %65 = icmp eq ptr %64, null
  br i1 %65, label %79, label %66

66:                                               ; preds = %63
  %67 = getelementptr inbounds nuw i8, ptr %64, i32 8
  %68 = load ptr, ptr %67, align 8, !tbaa !35
  %69 = icmp eq ptr %68, null
  br i1 %69, label %70, label %63, !llvm.loop !49

70:                                               ; preds = %66
  %71 = ptrtoint ptr %64 to i32
  %72 = zext i32 %71 to i64
  %73 = load i64, ptr %64, align 8, !tbaa !37
  %74 = add i64 %73, %72
  %75 = shl nuw nsw i64 %62, 16
  %76 = icmp eq i64 %74, %75
  %77 = select i1 %76, i64 %73, i64 0
  %78 = sub i64 %5, %77
  br label %79

79:                                               ; preds = %63, %70
  %80 = phi i64 [ %78, %70 ], [ %5, %63 ]
  %81 = add i64 %80, 65535
  %82 = lshr i64 %81, 16
  %83 = icmp ugt i32 %61, 65536
  %84 = sub nuw nsw i64 65536, %62
  %85 = icmp samesign ugt i64 %82, %84
  %86 = select i1 %83, i1 true, i1 %85
  br i1 %86, label %133, label %87

87:                                               ; preds = %79
  %88 = trunc nuw nsw i64 %82 to i32
  %89 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %88)
  %90 = icmp eq i32 %89, -1
  br i1 %90, label %133, label %91

91:                                               ; preds = %87
  %92 = shl i32 %89, 16
  %93 = inttoptr i32 %92 to ptr
  %94 = and i64 %81, -65536
  store i64 %94, ptr %93, align 65536, !tbaa !37
  %95 = getelementptr inbounds nuw i8, ptr %93, i32 8
  store ptr null, ptr %95, align 8, !tbaa !35
  br label %96

96:                                               ; preds = %96, %91
  %97 = phi ptr [ null, %91 ], [ %99, %96 ]
  %98 = phi ptr [ @free_blocks, %91 ], [ %103, %96 ]
  %99 = load ptr, ptr %98, align 4, !tbaa !31
  %100 = icmp ne ptr %99, null
  %101 = icmp ult ptr %99, %93
  %102 = and i1 %100, %101
  %103 = getelementptr inbounds nuw i8, ptr %99, i32 8
  br i1 %102, label %96, label %104, !llvm.loop !33

104:                                              ; preds = %96
  store ptr %99, ptr %95, align 8, !tbaa !35
  br i1 %100, label %105, label %115

105:                                              ; preds = %104
  %106 = ptrtoint ptr %99 to i32
  %107 = zext i32 %92 to i64
  %108 = add i64 %94, %107
  %109 = zext i32 %106 to i64
  %110 = icmp eq i64 %108, %109
  br i1 %110, label %111, label %115

111:                                              ; preds = %105
  %112 = load i64, ptr %99, align 8, !tbaa !37
  %113 = add i64 %112, %94
  store i64 %113, ptr %93, align 65536, !tbaa !37
  %114 = load ptr, ptr %103, align 8, !tbaa !35
  store ptr %114, ptr %95, align 8, !tbaa !35
  br label %115

115:                                              ; preds = %111, %105, %104
  %116 = phi i64 [ %113, %111 ], [ %94, %105 ], [ %94, %104 ]
  %117 = phi ptr [ %114, %111 ], [ %99, %105 ], [ null, %104 ]
  %118 = icmp eq ptr %97, null
  br i1 %118, label %131, label %119

119:                                              ; preds = %115
  %120 = ptrtoint ptr %97 to i32
  %121 = zext i32 %120 to i64
  %122 = load i64, ptr %97, align 8, !tbaa !37
  %123 = add i64 %122, %121
  %124 = zext i32 %92 to i64
  %125 = icmp eq i64 %123, %124
  br i1 %125, label %126, label %129

126:                                              ; preds = %119
  %127 = add i64 %122, %116
  store i64 %127, ptr %97, align 8, !tbaa !37
  %128 = getelementptr inbounds nuw i8, ptr %97, i32 8
  store ptr %117, ptr %128, align 8, !tbaa !35
  br label %132

129:                                              ; preds = %119
  %130 = getelementptr inbounds nuw i8, ptr %97, i32 8
  store ptr %93, ptr %130, align 8, !tbaa !35
  br label %132

131:                                              ; preds = %115
  store ptr %93, ptr @free_blocks, align 4, !tbaa !31
  br label %132

132:                                              ; preds = %131, %129, %126
  br label %23, !llvm.loop !50

133:                                              ; preds = %59, %79, %87, %1, %55
  %134 = phi ptr [ null, %1 ], [ %58, %55 ], [ null, %87 ], [ null, %79 ], [ null, %59 ]
  ret ptr %134
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_retain(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1) local_unnamed_addr #5 {
  %3 = icmp sgt i64 %1, -1
  %4 = icmp eq ptr %0, null
  br i1 %3, label %5, label %28

5:                                                ; preds = %2
  br i1 %4, label %53, label %6

6:                                                ; preds = %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %8 = load i32, ptr %7, align 8, !tbaa !21
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %53

10:                                               ; preds = %6
  %11 = icmp eq i64 %1, 0
  br i1 %11, label %53, label %12

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %14 = load i32, ptr %13, align 8, !tbaa !12
  %15 = zext i32 %14 to i64
  %16 = icmp samesign ugt i64 %1, %15
  br i1 %16, label %53, label %17

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %19 = load ptr, ptr %18, align 4, !tbaa !11
  %20 = icmp eq ptr %19, null
  br i1 %20, label %53, label %21

21:                                               ; preds = %17
  %22 = trunc nuw i64 %1 to i32
  %23 = getelementptr %struct.NmsView, ptr %19, i32 %22
  %24 = getelementptr i8, ptr %23, i32 -8
  %25 = load ptr, ptr %24, align 4, !tbaa !28
  %26 = icmp eq ptr %25, null
  %27 = select i1 %26, i32 6, i32 0
  br label %53

28:                                               ; preds = %2
  br i1 %4, label %53, label %29

29:                                               ; preds = %28
  %30 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %31 = load i32, ptr %30, align 8, !tbaa !21
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %33, label %53

33:                                               ; preds = %29
  %34 = and i64 %1, 9223372036854775807
  %35 = icmp eq i64 %34, 0
  br i1 %35, label %53, label %36

36:                                               ; preds = %33
  %37 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %38 = load i32, ptr %37, align 4, !tbaa !18
  %39 = zext i32 %38 to i64
  %40 = icmp samesign ugt i64 %34, %39
  br i1 %40, label %53, label %41

41:                                               ; preds = %36
  %42 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %43 = load ptr, ptr %42, align 8, !tbaa !13
  %44 = icmp eq ptr %43, null
  br i1 %44, label %53, label %45

45:                                               ; preds = %41
  %46 = trunc i64 %1 to i32
  %47 = getelementptr inbounds nuw %struct.NmsSlot, ptr %43, i32 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i32 8
  %49 = load i64, ptr %48, align 8, !tbaa !23
  switch i64 %49, label %50 [
    i64 0, label %53
    i64 -1, label %52
  ]

50:                                               ; preds = %45
  %51 = add nuw i64 %49, 1
  store i64 %51, ptr %48, align 8, !tbaa !23
  br label %53

52:                                               ; preds = %45
  br label %53

53:                                               ; preds = %45, %52, %21, %33, %36, %41, %29, %28, %50, %17, %12, %10, %6, %5
  %54 = phi i32 [ 6, %12 ], [ 6, %5 ], [ %27, %21 ], [ 6, %28 ], [ 5, %6 ], [ 6, %10 ], [ 6, %17 ], [ 0, %50 ], [ 5, %29 ], [ 6, %33 ], [ 6, %36 ], [ 6, %41 ], [ 6, %45 ], [ 3, %52 ]
  ret i32 %54
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc void @deallocate(ptr noundef %0) unnamed_addr #6 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %44, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds i8, ptr %0, i32 -16
  br label %5

5:                                                ; preds = %5, %3
  %6 = phi ptr [ null, %3 ], [ %8, %5 ]
  %7 = phi ptr [ @free_blocks, %3 ], [ %12, %5 ]
  %8 = load ptr, ptr %7, align 4, !tbaa !31
  %9 = icmp ne ptr %8, null
  %10 = icmp ult ptr %8, %4
  %11 = and i1 %9, %10
  %12 = getelementptr inbounds nuw i8, ptr %8, i32 8
  br i1 %11, label %5, label %13, !llvm.loop !33

13:                                               ; preds = %5
  %14 = ptrtoint ptr %4 to i32
  %15 = getelementptr inbounds i8, ptr %0, i32 -8
  store ptr %8, ptr %15, align 8, !tbaa !35
  br i1 %9, label %16, label %27

16:                                               ; preds = %13
  %17 = ptrtoint ptr %8 to i32
  %18 = zext i32 %14 to i64
  %19 = load i64, ptr %4, align 8, !tbaa !37
  %20 = add i64 %19, %18
  %21 = zext i32 %17 to i64
  %22 = icmp eq i64 %20, %21
  br i1 %22, label %23, label %27

23:                                               ; preds = %16
  %24 = load i64, ptr %8, align 8, !tbaa !37
  %25 = add i64 %24, %19
  store i64 %25, ptr %4, align 8, !tbaa !37
  %26 = load ptr, ptr %12, align 8, !tbaa !35
  store ptr %26, ptr %15, align 8, !tbaa !35
  br label %27

27:                                               ; preds = %23, %16, %13
  %28 = phi ptr [ %26, %23 ], [ %8, %16 ], [ null, %13 ]
  %29 = icmp eq ptr %6, null
  br i1 %29, label %43, label %30

30:                                               ; preds = %27
  %31 = ptrtoint ptr %6 to i32
  %32 = zext i32 %31 to i64
  %33 = load i64, ptr %6, align 8, !tbaa !37
  %34 = add i64 %33, %32
  %35 = zext i32 %14 to i64
  %36 = icmp eq i64 %34, %35
  br i1 %36, label %37, label %41

37:                                               ; preds = %30
  %38 = load i64, ptr %4, align 8, !tbaa !37
  %39 = add i64 %38, %33
  store i64 %39, ptr %6, align 8, !tbaa !37
  %40 = getelementptr inbounds nuw i8, ptr %6, i32 8
  store ptr %28, ptr %40, align 8, !tbaa !35
  br label %44

41:                                               ; preds = %30
  %42 = getelementptr inbounds nuw i8, ptr %6, i32 8
  store ptr %4, ptr %42, align 8, !tbaa !35
  br label %44

43:                                               ; preds = %27
  store ptr %4, ptr @free_blocks, align 4, !tbaa !31
  br label %44

44:                                               ; preds = %43, %41, %37, %1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_string_array_get(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #5 {
  %5 = icmp eq ptr %3, null
  br i1 %5, label %102, label %6

6:                                                ; preds = %4
  %7 = icmp sgt i64 %1, -1
  %8 = icmp eq ptr %0, null
  br i1 %7, label %9, label %32

9:                                                ; preds = %6
  br i1 %8, label %102, label %10

10:                                               ; preds = %9
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %12 = load i32, ptr %11, align 8, !tbaa !21
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %102

14:                                               ; preds = %10
  %15 = icmp eq i64 %1, 0
  br i1 %15, label %102, label %16

16:                                               ; preds = %14
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %18 = load i32, ptr %17, align 8, !tbaa !12
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %1, %19
  br i1 %20, label %102, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %23 = load ptr, ptr %22, align 4, !tbaa !11
  %24 = icmp eq ptr %23, null
  br i1 %24, label %102, label %25

25:                                               ; preds = %21
  %26 = trunc nuw i64 %1 to i32
  %27 = getelementptr %struct.NmsView, ptr %23, i32 %26
  %28 = getelementptr i8, ptr %27, i32 -8
  %29 = load ptr, ptr %28, align 4, !tbaa !28
  %30 = icmp eq ptr %29, null
  %31 = select i1 %30, i32 6, i32 1
  br label %102

32:                                               ; preds = %6
  br i1 %8, label %102, label %33

33:                                               ; preds = %32
  %34 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %35 = load i32, ptr %34, align 8, !tbaa !21
  %36 = icmp eq i32 %35, 0
  br i1 %36, label %37, label %102

37:                                               ; preds = %33
  %38 = and i64 %1, 9223372036854775807
  %39 = icmp eq i64 %38, 0
  br i1 %39, label %102, label %40

40:                                               ; preds = %37
  %41 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %42 = load i32, ptr %41, align 4, !tbaa !18
  %43 = freeze i32 %42
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %38, %44
  br i1 %45, label %102, label %46

46:                                               ; preds = %40
  %47 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %48 = load ptr, ptr %47, align 8, !tbaa !13
  %49 = icmp eq ptr %48, null
  br i1 %49, label %102, label %50

50:                                               ; preds = %46
  %51 = trunc i64 %1 to i32
  %52 = getelementptr inbounds nuw %struct.NmsSlot, ptr %48, i32 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i32 8
  %54 = load i64, ptr %53, align 8, !tbaa !23
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %102, label %56

56:                                               ; preds = %50
  %57 = getelementptr inbounds nuw i8, ptr %52, i32 28
  %58 = load i32, ptr %57, align 4, !tbaa !26
  %59 = icmp eq i32 %58, 2
  br i1 %59, label %60, label %102

60:                                               ; preds = %56
  %61 = getelementptr inbounds nuw i8, ptr %52, i32 16
  %62 = load i32, ptr %61, align 8, !tbaa !38
  %63 = zext i32 %62 to i64
  %64 = icmp ult i64 %2, %63
  br i1 %64, label %66, label %65

65:                                               ; preds = %60
  store i64 0, ptr %3, align 8, !tbaa !45
  br label %102

66:                                               ; preds = %60
  %67 = load ptr, ptr %52, align 8, !tbaa !27
  %68 = trunc nuw i64 %2 to i32
  %69 = getelementptr inbounds nuw i64, ptr %67, i32 %68
  %70 = load i64, ptr %69, align 8, !tbaa !45
  %71 = icmp sgt i64 %70, -1
  br i1 %71, label %72, label %89

72:                                               ; preds = %66
  %73 = icmp eq i64 %70, 0
  br i1 %73, label %102, label %74

74:                                               ; preds = %72
  %75 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %76 = load i32, ptr %75, align 8, !tbaa !12
  %77 = zext i32 %76 to i64
  %78 = icmp samesign ugt i64 %70, %77
  br i1 %78, label %102, label %79

79:                                               ; preds = %74
  %80 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %81 = load ptr, ptr %80, align 4, !tbaa !11
  %82 = icmp eq ptr %81, null
  br i1 %82, label %102, label %83

83:                                               ; preds = %79
  %84 = trunc nuw i64 %70 to i32
  %85 = getelementptr %struct.NmsView, ptr %81, i32 %84
  %86 = getelementptr i8, ptr %85, i32 -8
  %87 = load ptr, ptr %86, align 4, !tbaa !28
  %88 = icmp eq ptr %87, null
  br i1 %88, label %102, label %101

89:                                               ; preds = %66
  %90 = and i64 %70, 9223372036854775807
  %91 = add nsw i64 %90, -1
  %92 = icmp ult i64 %91, %44
  br i1 %92, label %93, label %102

93:                                               ; preds = %89
  %94 = trunc i64 %70 to i32
  %95 = getelementptr inbounds nuw %struct.NmsSlot, ptr %48, i32 %94
  %96 = getelementptr inbounds nuw i8, ptr %95, i32 8
  %97 = load i64, ptr %96, align 8, !tbaa !23
  switch i64 %97, label %98 [
    i64 0, label %102
    i64 -1, label %100
  ]

98:                                               ; preds = %93
  %99 = add nuw i64 %97, 1
  store i64 %99, ptr %96, align 8, !tbaa !23
  br label %101

100:                                              ; preds = %93
  br label %102

101:                                              ; preds = %98, %83
  store i64 %70, ptr %3, align 8, !tbaa !45
  br label %102

102:                                              ; preds = %83, %89, %79, %72, %93, %100, %74, %21, %14, %10, %16, %25, %9, %33, %50, %46, %40, %37, %32, %56, %101, %65, %4
  %103 = phi i32 [ 6, %4 ], [ 1, %56 ], [ 0, %65 ], [ 0, %101 ], [ 6, %32 ], [ 6, %21 ], [ 6, %14 ], [ 5, %10 ], [ 6, %16 ], [ %31, %25 ], [ 6, %9 ], [ 5, %33 ], [ 6, %50 ], [ 6, %46 ], [ 6, %40 ], [ 6, %37 ], [ 6, %74 ], [ 6, %93 ], [ 6, %89 ], [ 3, %100 ], [ 6, %79 ], [ 6, %72 ], [ 6, %83 ]
  ret i32 %103
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_string_array_length(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %61, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %31

8:                                                ; preds = %5
  br i1 %7, label %61, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %11 = load i32, ptr %10, align 8, !tbaa !21
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %61

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %61, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %17 = load i32, ptr %16, align 8, !tbaa !12
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %61, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %22 = load ptr, ptr %21, align 4, !tbaa !11
  %23 = icmp eq ptr %22, null
  br i1 %23, label %61, label %24

24:                                               ; preds = %20
  %25 = trunc nuw i64 %1 to i32
  %26 = getelementptr %struct.NmsView, ptr %22, i32 %25
  %27 = getelementptr i8, ptr %26, i32 -8
  %28 = load ptr, ptr %27, align 4, !tbaa !28
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %61

31:                                               ; preds = %5
  br i1 %7, label %61, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %34 = load i32, ptr %33, align 8, !tbaa !21
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %61

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %61, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %41 = load i32, ptr %40, align 4, !tbaa !18
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %37, %42
  br i1 %43, label %61, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %46 = load ptr, ptr %45, align 8, !tbaa !13
  %47 = icmp eq ptr %46, null
  br i1 %47, label %61, label %48

48:                                               ; preds = %44
  %49 = trunc i64 %1 to i32
  %50 = getelementptr inbounds nuw %struct.NmsSlot, ptr %46, i32 %49
  %51 = getelementptr inbounds nuw i8, ptr %50, i32 8
  %52 = load i64, ptr %51, align 8, !tbaa !23
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %61, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw i8, ptr %50, i32 28
  %56 = load i32, ptr %55, align 4, !tbaa !26
  %57 = icmp eq i32 %56, 2
  br i1 %57, label %58, label %61

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw i8, ptr %50, i32 16
  %60 = load i32, ptr %59, align 8, !tbaa !38
  store i32 %60, ptr %2, align 4, !tbaa !1
  br label %61

61:                                               ; preds = %20, %13, %9, %15, %24, %8, %32, %48, %44, %39, %36, %31, %54, %58, %3
  %62 = phi i32 [ 6, %3 ], [ 1, %54 ], [ 0, %58 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %30, %24 ], [ 6, %8 ], [ 5, %32 ], [ 6, %48 ], [ 6, %44 ], [ 6, %39 ], [ 6, %36 ], [ 6, %31 ]
  ret i32 %62
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_create(ptr noundef captures(address_is_null) %0, ptr noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = tail call fastcc i32 @create_parts(ptr noundef %0, ptr noundef %1, i64 noundef %2, ptr noundef null, i64 noundef 0, ptr noundef %3) #27
  ret i32 %5
}

; Function Attrs: nofree norecurse nounwind
define internal fastcc range(i32 0, 7) i32 @create_parts(ptr noundef captures(address_is_null) %0, ptr noundef %1, i64 noundef %2, ptr noundef %3, i64 noundef range(i64 0, 4294967296) %4, ptr noundef writeonly captures(address_is_null) %5) unnamed_addr #4 {
  %7 = icmp ne ptr %0, null
  %8 = icmp ne ptr %5, null
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %138

10:                                               ; preds = %6
  %11 = icmp eq ptr %1, null
  %12 = icmp ne i64 %2, 0
  %13 = and i1 %11, %12
  br i1 %13, label %138, label %14

14:                                               ; preds = %10
  %15 = icmp eq ptr %3, null
  %16 = icmp ne i64 %4, 0
  %17 = and i1 %15, %16
  br i1 %17, label %138, label %18

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %20 = load i32, ptr %19, align 8, !tbaa !21
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %138

22:                                               ; preds = %18
  %23 = icmp ugt i64 %2, 4294967295
  br i1 %23, label %138, label %24

24:                                               ; preds = %22
  %25 = add nuw nsw i64 %4, %2
  %26 = icmp samesign ugt i64 %25, 4294967294
  br i1 %26, label %138, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %29 = load i64, ptr %28, align 8, !tbaa !20
  %30 = xor i64 %29, -1
  %31 = icmp ugt i64 %25, %30
  br i1 %31, label %138, label %32

32:                                               ; preds = %27
  %33 = add nuw nsw i64 %25, 1
  %34 = tail call fastcc ptr @allocate(i64 noundef %33) #27
  %35 = icmp eq ptr %34, null
  br i1 %35, label %138, label %36

36:                                               ; preds = %32
  %37 = icmp eq i64 %2, 0
  br i1 %37, label %83, label %38

38:                                               ; preds = %36
  %39 = and i64 %2, 3
  %40 = icmp ult i64 %2, 4
  br i1 %40, label %70, label %41

41:                                               ; preds = %38
  %42 = and i64 %2, 4294967292
  br label %43

43:                                               ; preds = %43, %41
  %44 = phi i64 [ 0, %41 ], [ %65, %43 ]
  %45 = phi i64 [ 0, %41 ], [ %66, %43 ]
  %46 = trunc i64 %44 to i32
  %47 = getelementptr inbounds nuw i8, ptr %1, i32 %46
  %48 = load volatile i8, ptr %47, align 1, !tbaa !46
  %49 = getelementptr inbounds nuw i8, ptr %34, i32 %46
  store volatile i8 %48, ptr %49, align 1, !tbaa !46
  %50 = trunc i64 %44 to i32
  %51 = or disjoint i32 %50, 1
  %52 = getelementptr inbounds nuw i8, ptr %1, i32 %51
  %53 = load volatile i8, ptr %52, align 1, !tbaa !46
  %54 = getelementptr inbounds nuw i8, ptr %34, i32 %51
  store volatile i8 %53, ptr %54, align 1, !tbaa !46
  %55 = trunc i64 %44 to i32
  %56 = or disjoint i32 %55, 2
  %57 = getelementptr inbounds nuw i8, ptr %1, i32 %56
  %58 = load volatile i8, ptr %57, align 1, !tbaa !46
  %59 = getelementptr inbounds nuw i8, ptr %34, i32 %56
  store volatile i8 %58, ptr %59, align 1, !tbaa !46
  %60 = trunc i64 %44 to i32
  %61 = or disjoint i32 %60, 3
  %62 = getelementptr inbounds nuw i8, ptr %1, i32 %61
  %63 = load volatile i8, ptr %62, align 1, !tbaa !46
  %64 = getelementptr inbounds nuw i8, ptr %34, i32 %61
  store volatile i8 %63, ptr %64, align 1, !tbaa !46
  %65 = add nuw nsw i64 %44, 4
  %66 = add i64 %45, 4
  %67 = icmp eq i64 %66, %42
  br i1 %67, label %68, label %43, !llvm.loop !47

68:                                               ; preds = %43
  %69 = icmp eq i64 %39, 0
  br i1 %69, label %83, label %70

70:                                               ; preds = %68, %38
  %71 = phi i64 [ 0, %38 ], [ %65, %68 ]
  %72 = icmp ne i64 %39, 0
  tail call void @llvm.assume(i1 %72)
  br label %73

73:                                               ; preds = %73, %70
  %74 = phi i64 [ %80, %73 ], [ %71, %70 ]
  %75 = phi i64 [ %81, %73 ], [ 0, %70 ]
  %76 = trunc i64 %74 to i32
  %77 = getelementptr inbounds nuw i8, ptr %1, i32 %76
  %78 = load volatile i8, ptr %77, align 1, !tbaa !46
  %79 = getelementptr inbounds nuw i8, ptr %34, i32 %76
  store volatile i8 %78, ptr %79, align 1, !tbaa !46
  %80 = add nuw nsw i64 %74, 1
  %81 = add i64 %75, 1
  %82 = icmp eq i64 %81, %39
  br i1 %82, label %83, label %73, !llvm.loop !51

83:                                               ; preds = %68, %73, %36
  %84 = trunc nuw i64 %2 to i32
  %85 = getelementptr inbounds nuw i8, ptr %34, i32 %84
  %86 = icmp eq i64 %4, 0
  br i1 %86, label %132, label %87

87:                                               ; preds = %83
  %88 = and i64 %4, 3
  %89 = icmp samesign ult i64 %4, 4
  br i1 %89, label %119, label %90

90:                                               ; preds = %87
  %91 = and i64 %4, 4294967292
  br label %92

92:                                               ; preds = %92, %90
  %93 = phi i64 [ 0, %90 ], [ %114, %92 ]
  %94 = phi i64 [ 0, %90 ], [ %115, %92 ]
  %95 = trunc i64 %93 to i32
  %96 = getelementptr inbounds nuw i8, ptr %3, i32 %95
  %97 = load volatile i8, ptr %96, align 1, !tbaa !46
  %98 = getelementptr inbounds nuw i8, ptr %85, i32 %95
  store volatile i8 %97, ptr %98, align 1, !tbaa !46
  %99 = trunc i64 %93 to i32
  %100 = or disjoint i32 %99, 1
  %101 = getelementptr inbounds nuw i8, ptr %3, i32 %100
  %102 = load volatile i8, ptr %101, align 1, !tbaa !46
  %103 = getelementptr inbounds nuw i8, ptr %85, i32 %100
  store volatile i8 %102, ptr %103, align 1, !tbaa !46
  %104 = trunc i64 %93 to i32
  %105 = or disjoint i32 %104, 2
  %106 = getelementptr inbounds nuw i8, ptr %3, i32 %105
  %107 = load volatile i8, ptr %106, align 1, !tbaa !46
  %108 = getelementptr inbounds nuw i8, ptr %85, i32 %105
  store volatile i8 %107, ptr %108, align 1, !tbaa !46
  %109 = trunc i64 %93 to i32
  %110 = or disjoint i32 %109, 3
  %111 = getelementptr inbounds nuw i8, ptr %3, i32 %110
  %112 = load volatile i8, ptr %111, align 1, !tbaa !46
  %113 = getelementptr inbounds nuw i8, ptr %85, i32 %110
  store volatile i8 %112, ptr %113, align 1, !tbaa !46
  %114 = add nuw nsw i64 %93, 4
  %115 = add i64 %94, 4
  %116 = icmp eq i64 %115, %91
  br i1 %116, label %117, label %92, !llvm.loop !47

117:                                              ; preds = %92
  %118 = icmp eq i64 %88, 0
  br i1 %118, label %132, label %119

119:                                              ; preds = %117, %87
  %120 = phi i64 [ 0, %87 ], [ %114, %117 ]
  %121 = icmp ne i64 %88, 0
  tail call void @llvm.assume(i1 %121)
  br label %122

122:                                              ; preds = %122, %119
  %123 = phi i64 [ %129, %122 ], [ %120, %119 ]
  %124 = phi i64 [ %130, %122 ], [ 0, %119 ]
  %125 = trunc i64 %123 to i32
  %126 = getelementptr inbounds nuw i8, ptr %3, i32 %125
  %127 = load volatile i8, ptr %126, align 1, !tbaa !46
  %128 = getelementptr inbounds nuw i8, ptr %85, i32 %125
  store volatile i8 %127, ptr %128, align 1, !tbaa !46
  %129 = add nuw nsw i64 %123, 1
  %130 = add i64 %124, 1
  %131 = icmp eq i64 %130, %88
  br i1 %131, label %132, label %122, !llvm.loop !53

132:                                              ; preds = %117, %122, %83
  %133 = trunc nuw i64 %25 to i32
  %134 = getelementptr inbounds nuw i8, ptr %34, i32 %133
  store i8 0, ptr %134, align 1, !tbaa !46
  %135 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %34, i32 noundef %133, i32 noundef 0, i32 noundef 1, i64 noundef %25, ptr noundef %5) #27
  %136 = icmp eq i32 %135, 0
  br i1 %136, label %138, label %137

137:                                              ; preds = %132
  tail call fastcc void @deallocate(ptr noundef nonnull %34) #27
  br label %138

138:                                              ; preds = %27, %24, %132, %137, %32, %22, %18, %6, %10, %14
  %139 = phi i32 [ 3, %22 ], [ 6, %6 ], [ 5, %18 ], [ 6, %14 ], [ 6, %10 ], [ 3, %24 ], [ 3, %27 ], [ 3, %32 ], [ %135, %137 ], [ 0, %132 ]
  ret i32 %139
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_value_retain(ptr noundef readonly captures(address_is_null) %0, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %1) local_unnamed_addr #5 {
  %3 = tail call fastcc i32 @value_valid(ptr noundef %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %1) #27
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %60

5:                                                ; preds = %2
  %6 = getelementptr inbounds nuw i8, ptr %1, i32 8
  %7 = load i32, ptr %6, align 8, !tbaa !54
  switch i32 %7, label %60 [
    i32 8, label %8
    i32 7, label %8
    i32 5, label %8
  ]

8:                                                ; preds = %5, %5, %5
  %9 = load i64, ptr %1, align 8, !tbaa !56
  %10 = icmp sgt i64 %9, -1
  %11 = icmp eq ptr %0, null
  br i1 %10, label %12, label %35

12:                                               ; preds = %8
  br i1 %11, label %60, label %13

13:                                               ; preds = %12
  %14 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %15 = load i32, ptr %14, align 8, !tbaa !21
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %60

17:                                               ; preds = %13
  %18 = icmp eq i64 %9, 0
  br i1 %18, label %60, label %19

19:                                               ; preds = %17
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %21 = load i32, ptr %20, align 8, !tbaa !12
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %9, %22
  br i1 %23, label %60, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %26 = load ptr, ptr %25, align 4, !tbaa !11
  %27 = icmp eq ptr %26, null
  br i1 %27, label %60, label %28

28:                                               ; preds = %24
  %29 = trunc nuw i64 %9 to i32
  %30 = getelementptr %struct.NmsView, ptr %26, i32 %29
  %31 = getelementptr i8, ptr %30, i32 -8
  %32 = load ptr, ptr %31, align 4, !tbaa !28
  %33 = icmp eq ptr %32, null
  %34 = select i1 %33, i32 6, i32 0
  br label %60

35:                                               ; preds = %8
  br i1 %11, label %60, label %36

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %38 = load i32, ptr %37, align 8, !tbaa !21
  %39 = icmp eq i32 %38, 0
  br i1 %39, label %40, label %60

40:                                               ; preds = %36
  %41 = and i64 %9, 9223372036854775807
  %42 = icmp eq i64 %41, 0
  br i1 %42, label %60, label %43

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %45 = load i32, ptr %44, align 4, !tbaa !18
  %46 = zext i32 %45 to i64
  %47 = icmp samesign ugt i64 %41, %46
  br i1 %47, label %60, label %48

48:                                               ; preds = %43
  %49 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %50 = load ptr, ptr %49, align 8, !tbaa !13
  %51 = icmp eq ptr %50, null
  br i1 %51, label %60, label %52

52:                                               ; preds = %48
  %53 = trunc i64 %9 to i32
  %54 = getelementptr inbounds nuw %struct.NmsSlot, ptr %50, i32 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i32 8
  %56 = load i64, ptr %55, align 8, !tbaa !23
  switch i64 %56, label %57 [
    i64 0, label %60
    i64 -1, label %59
  ]

57:                                               ; preds = %52
  %58 = add nuw i64 %56, 1
  store i64 %58, ptr %55, align 8, !tbaa !23
  br label %60

59:                                               ; preds = %52
  br label %60

60:                                               ; preds = %5, %59, %57, %52, %48, %43, %40, %36, %35, %28, %24, %19, %17, %13, %12, %2
  %61 = phi i32 [ %3, %2 ], [ 0, %5 ], [ 6, %19 ], [ 6, %12 ], [ %34, %28 ], [ 6, %35 ], [ 5, %13 ], [ 6, %17 ], [ 6, %24 ], [ 0, %57 ], [ 5, %36 ], [ 6, %40 ], [ 6, %43 ], [ 6, %48 ], [ 6, %52 ], [ 3, %59 ]
  ret i32 %61
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc range(i32 0, 7) i32 @value_valid(ptr noundef readonly captures(address_is_null) %0, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %1) unnamed_addr #7 {
  %3 = icmp eq ptr %0, null
  br i1 %3, label %160, label %4

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %6 = load i32, ptr %5, align 8, !tbaa !21
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %160

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %1, i32 8
  %10 = load i32, ptr %9, align 8, !tbaa !54
  switch i32 %10, label %155 [
    i32 5, label %11
    i32 7, label %55
    i32 8, label %100
  ]

11:                                               ; preds = %8
  %12 = load i64, ptr %1, align 8, !tbaa !56
  %13 = icmp sgt i64 %12, -1
  br i1 %13, label %37, label %14

14:                                               ; preds = %11
  %15 = and i64 %12, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %160, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %160, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %24 = load ptr, ptr %23, align 8, !tbaa !13
  %25 = icmp eq ptr %24, null
  br i1 %25, label %160, label %26

26:                                               ; preds = %22
  %27 = trunc i64 %12 to i32
  %28 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i32 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i32 8
  %30 = load i64, ptr %29, align 8, !tbaa !23
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %160, label %32

32:                                               ; preds = %26
  %33 = getelementptr inbounds nuw i8, ptr %28, i32 28
  %34 = load i32, ptr %33, align 4, !tbaa !26
  %35 = icmp ne i32 %34, 1
  %36 = zext i1 %35 to i32
  br label %160

37:                                               ; preds = %11
  %38 = icmp eq i64 %12, 0
  br i1 %38, label %160, label %39

39:                                               ; preds = %37
  %40 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %41 = load i32, ptr %40, align 8, !tbaa !12
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %12, %42
  br i1 %43, label %160, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %46 = load ptr, ptr %45, align 4, !tbaa !11
  %47 = icmp eq ptr %46, null
  br i1 %47, label %160, label %48

48:                                               ; preds = %44
  %49 = trunc nuw i64 %12 to i32
  %50 = getelementptr %struct.NmsView, ptr %46, i32 %49
  %51 = getelementptr i8, ptr %50, i32 -8
  %52 = load ptr, ptr %51, align 4, !tbaa !28
  %53 = icmp eq ptr %52, null
  %54 = select i1 %53, i32 6, i32 0
  br label %160

55:                                               ; preds = %8
  %56 = load i64, ptr %1, align 8, !tbaa !56
  %57 = icmp sgt i64 %56, -1
  br i1 %57, label %58, label %76

58:                                               ; preds = %55
  %59 = icmp eq i64 %56, 0
  br i1 %59, label %160, label %60

60:                                               ; preds = %58
  %61 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %62 = load i32, ptr %61, align 8, !tbaa !12
  %63 = zext i32 %62 to i64
  %64 = icmp samesign ugt i64 %56, %63
  br i1 %64, label %160, label %65

65:                                               ; preds = %60
  %66 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %67 = load ptr, ptr %66, align 4, !tbaa !11
  %68 = icmp eq ptr %67, null
  br i1 %68, label %160, label %69

69:                                               ; preds = %65
  %70 = trunc nuw i64 %56 to i32
  %71 = getelementptr %struct.NmsView, ptr %67, i32 %70
  %72 = getelementptr i8, ptr %71, i32 -8
  %73 = load ptr, ptr %72, align 4, !tbaa !28
  %74 = icmp eq ptr %73, null
  %75 = select i1 %74, i32 6, i32 1
  br label %160

76:                                               ; preds = %55
  %77 = and i64 %56, 9223372036854775807
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %160, label %79

79:                                               ; preds = %76
  %80 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %81 = load i32, ptr %80, align 4, !tbaa !18
  %82 = zext i32 %81 to i64
  %83 = icmp samesign ugt i64 %77, %82
  br i1 %83, label %160, label %84

84:                                               ; preds = %79
  %85 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %86 = load ptr, ptr %85, align 8, !tbaa !13
  %87 = icmp eq ptr %86, null
  br i1 %87, label %160, label %88

88:                                               ; preds = %84
  %89 = trunc i64 %56 to i32
  %90 = getelementptr inbounds nuw %struct.NmsSlot, ptr %86, i32 %89
  %91 = getelementptr inbounds nuw i8, ptr %90, i32 8
  %92 = load i64, ptr %91, align 8, !tbaa !23
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %160, label %94

94:                                               ; preds = %88
  %95 = getelementptr inbounds nuw i8, ptr %90, i32 28
  %96 = load i32, ptr %95, align 4, !tbaa !26
  %97 = add i32 %96, -5
  %98 = icmp ult i32 %97, -3
  %99 = zext i1 %98 to i32
  br label %160

100:                                              ; preds = %8
  %101 = load i64, ptr %1, align 8, !tbaa !56
  %102 = and i64 %101, 9223372036854775807
  %103 = icmp slt i64 %101, 0
  %104 = icmp ne i64 %102, 0
  %105 = and i1 %103, %104
  br i1 %105, label %106, label %160

106:                                              ; preds = %100
  %107 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %108 = load i32, ptr %107, align 4, !tbaa !18
  %109 = zext i32 %108 to i64
  %110 = icmp samesign ugt i64 %102, %109
  br i1 %110, label %160, label %111

111:                                              ; preds = %106
  %112 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %113 = load ptr, ptr %112, align 8, !tbaa !13
  %114 = icmp eq ptr %113, null
  br i1 %114, label %160, label %115

115:                                              ; preds = %111
  %116 = trunc i64 %101 to i32
  %117 = getelementptr inbounds nuw %struct.NmsSlot, ptr %113, i32 %116
  %118 = getelementptr inbounds nuw i8, ptr %117, i32 8
  %119 = load i64, ptr %118, align 8, !tbaa !23
  %120 = icmp eq i64 %119, 0
  br i1 %120, label %160, label %121

121:                                              ; preds = %115
  %122 = getelementptr inbounds nuw i8, ptr %117, i32 28
  %123 = load i32, ptr %122, align 4, !tbaa !26
  %124 = icmp eq i32 %123, 5
  br i1 %124, label %125, label %160

125:                                              ; preds = %121
  %126 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %127 = load i32, ptr %126, align 8, !tbaa !9
  %128 = icmp eq i32 %127, 0
  br i1 %128, label %160, label %129

129:                                              ; preds = %125
  %130 = load ptr, ptr %0, align 8, !tbaa !5
  %131 = icmp eq ptr %130, null
  br i1 %131, label %160, label %132

132:                                              ; preds = %129
  %133 = getelementptr inbounds nuw i8, ptr %117, i32 40
  %134 = load i32, ptr %133, align 8, !tbaa !42
  %135 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %136 = load i32, ptr %135, align 4, !tbaa !10
  %137 = icmp ult i32 %134, %136
  br i1 %137, label %138, label %160

138:                                              ; preds = %132
  %139 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %130, i32 %134
  %140 = getelementptr inbounds nuw i8, ptr %139, i32 4
  %141 = load i32, ptr %140, align 4, !tbaa !57
  %142 = getelementptr inbounds nuw i8, ptr %117, i32 16
  %143 = load i32, ptr %142, align 8, !tbaa !38
  %144 = icmp eq i32 %143, %141
  br i1 %144, label %145, label %160

145:                                              ; preds = %138
  %146 = getelementptr inbounds nuw i8, ptr %117, i32 24
  %147 = load i32, ptr %146, align 8, !tbaa !43
  %148 = icmp eq i32 %147, %141
  br i1 %148, label %149, label %160

149:                                              ; preds = %145
  %150 = icmp eq i32 %141, 0
  br i1 %150, label %160, label %151

151:                                              ; preds = %149
  %152 = load ptr, ptr %117, align 8, !tbaa !27
  %153 = icmp eq ptr %152, null
  %154 = select i1 %153, i32 6, i32 0
  br label %160

155:                                              ; preds = %8
  %156 = icmp ugt i32 %10, 4
  %157 = icmp ne i32 %10, 9
  %158 = and i1 %156, %157
  %159 = zext i1 %158 to i32
  br label %160

160:                                              ; preds = %48, %32, %151, %149, %145, %138, %132, %129, %125, %121, %115, %111, %106, %100, %94, %88, %84, %79, %76, %69, %65, %60, %58, %44, %39, %37, %26, %22, %17, %14, %4, %2, %155
  %161 = phi i32 [ 6, %2 ], [ 5, %4 ], [ 6, %115 ], [ %75, %69 ], [ %159, %155 ], [ 6, %14 ], [ 6, %111 ], [ 6, %26 ], [ 6, %17 ], [ 6, %37 ], [ 6, %44 ], [ 6, %39 ], [ 6, %22 ], [ %54, %48 ], [ %36, %32 ], [ 6, %58 ], [ %99, %94 ], [ 6, %76 ], [ 6, %79 ], [ 6, %84 ], [ 6, %88 ], [ 6, %60 ], [ 6, %65 ], [ %154, %151 ], [ 6, %125 ], [ 1, %121 ], [ 6, %132 ], [ 6, %129 ], [ 6, %145 ], [ 6, %138 ], [ 0, %149 ], [ 6, %100 ], [ 6, %106 ]
  ret i32 %161
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_value_release(ptr noundef captures(address_is_null) %0, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %1) local_unnamed_addr #6 {
  %3 = tail call fastcc i32 @value_valid(ptr noundef %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %1) #27
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %11

5:                                                ; preds = %2
  %6 = getelementptr inbounds nuw i8, ptr %1, i32 8
  %7 = load i32, ptr %6, align 8, !tbaa !54
  switch i32 %7, label %11 [
    i32 8, label %8
    i32 7, label %8
    i32 5, label %8
  ]

8:                                                ; preds = %5, %5, %5
  %9 = load i64, ptr %1, align 8, !tbaa !56
  %10 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %9) #27
  br label %11

11:                                               ; preds = %5, %8, %2
  %12 = phi i32 [ %3, %2 ], [ %10, %8 ], [ 0, %5 ]
  ret i32 %12
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_release(ptr noundef captures(address_is_null) %0, i64 noundef %1) local_unnamed_addr #6 {
  %3 = icmp sgt i64 %1, -1
  %4 = icmp eq ptr %0, null
  br i1 %3, label %5, label %28

5:                                                ; preds = %2
  br i1 %4, label %288, label %6

6:                                                ; preds = %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %8 = load i32, ptr %7, align 8, !tbaa !21
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %288

10:                                               ; preds = %6
  %11 = icmp eq i64 %1, 0
  br i1 %11, label %288, label %12

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %14 = load i32, ptr %13, align 8, !tbaa !12
  %15 = zext i32 %14 to i64
  %16 = icmp samesign ugt i64 %1, %15
  br i1 %16, label %288, label %17

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %19 = load ptr, ptr %18, align 4, !tbaa !11
  %20 = icmp eq ptr %19, null
  br i1 %20, label %288, label %21

21:                                               ; preds = %17
  %22 = trunc nuw i64 %1 to i32
  %23 = getelementptr %struct.NmsView, ptr %19, i32 %22
  %24 = getelementptr i8, ptr %23, i32 -8
  %25 = load ptr, ptr %24, align 4, !tbaa !28
  %26 = icmp eq ptr %25, null
  %27 = select i1 %26, i32 6, i32 0
  br label %288

28:                                               ; preds = %2
  br i1 %4, label %288, label %29

29:                                               ; preds = %28
  %30 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %31 = load i32, ptr %30, align 8, !tbaa !21
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %33, label %288

33:                                               ; preds = %29
  %34 = and i64 %1, 9223372036854775807
  %35 = icmp eq i64 %34, 0
  br i1 %35, label %288, label %36

36:                                               ; preds = %33
  %37 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %38 = load i32, ptr %37, align 4, !tbaa !18
  %39 = freeze i32 %38
  %40 = zext i32 %39 to i64
  %41 = icmp samesign ugt i64 %34, %40
  br i1 %41, label %288, label %42

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %44 = load ptr, ptr %43, align 8, !tbaa !13
  %45 = icmp eq ptr %44, null
  br i1 %45, label %288, label %46

46:                                               ; preds = %42
  %47 = trunc i64 %1 to i32
  %48 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i32 %47
  %49 = getelementptr inbounds nuw i8, ptr %48, i32 8
  %50 = load i64, ptr %49, align 8, !tbaa !23
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %288, label %52

52:                                               ; preds = %46
  %53 = add i64 %50, -1
  store i64 %53, ptr %49, align 8, !tbaa !23
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %288

55:                                               ; preds = %52
  %56 = getelementptr inbounds nuw i8, ptr %48, i32 20
  store i32 0, ptr %56, align 4, !tbaa !39
  %57 = icmp eq i32 %47, 0
  br i1 %57, label %288, label %58

58:                                               ; preds = %55
  %59 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %60 = getelementptr inbounds nuw i8, ptr %0, i32 40
  %61 = getelementptr inbounds nuw i8, ptr %0, i32 56
  %62 = load i64, ptr %59, align 8, !tbaa !20
  %63 = load i64, ptr %60, align 8, !tbaa !19
  %64 = load i32, ptr %61, align 8, !tbaa !17
  br label %65

65:                                               ; preds = %58, %281
  %66 = phi i32 [ %64, %58 ], [ %69, %281 ]
  %67 = phi i64 [ %63, %58 ], [ %237, %281 ]
  %68 = phi i64 [ %62, %58 ], [ %236, %281 ]
  %69 = phi i32 [ %47, %58 ], [ %233, %281 ]
  %70 = phi i32 [ 0, %58 ], [ %234, %281 ]
  %71 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i32 %69
  %72 = getelementptr inbounds nuw i8, ptr %71, i32 20
  %73 = load i32, ptr %72, align 4, !tbaa !39
  %74 = getelementptr inbounds nuw i8, ptr %71, i32 28
  %75 = load i32, ptr %74, align 4, !tbaa !26
  switch i32 %75, label %204 [
    i32 5, label %76
    i32 3, label %76
    i32 2, label %76
  ]

76:                                               ; preds = %65, %65, %65
  %77 = getelementptr inbounds nuw i8, ptr %71, i32 16
  %78 = load i32, ptr %77, align 8, !tbaa !38
  %79 = icmp eq i32 %78, 0
  br i1 %79, label %212, label %80

80:                                               ; preds = %76
  %81 = getelementptr inbounds nuw i8, ptr %71, i32 32
  br label %82

82:                                               ; preds = %80, %199
  %83 = phi i32 [ 0, %80 ], [ %202, %199 ]
  %84 = phi i32 [ %73, %80 ], [ %201, %199 ]
  %85 = phi i32 [ %70, %80 ], [ %200, %199 ]
  switch i32 %75, label %146 [
    i32 4, label %86
    i32 2, label %142
  ]

86:                                               ; preds = %82
  %87 = load i32, ptr %81, align 8, !tbaa !40, !noalias !59
  %88 = and i32 %87, -3
  %89 = icmp eq i32 %88, 1
  %90 = icmp eq i32 %87, 2
  %91 = icmp eq i32 %87, 4
  %92 = or i1 %90, %91
  %93 = zext i1 %92 to i32
  %94 = select i1 %89, i32 8, i32 %93
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %199, label %96

96:                                               ; preds = %86
  %97 = mul i32 %94, %83
  %98 = load ptr, ptr %71, align 8, !tbaa !27, !noalias !59
  %99 = getelementptr i8, ptr %98, i32 %97
  %100 = zext nneg i32 %94 to i64
  %101 = and i64 %100, 1
  br i1 %89, label %102, label %154

102:                                              ; preds = %96
  %103 = and i64 %100, 8
  br label %104

104:                                              ; preds = %104, %102
  %105 = phi i64 [ 0, %102 ], [ %139, %104 ]
  %106 = phi i64 [ 0, %102 ], [ %138, %104 ]
  %107 = phi i64 [ 0, %102 ], [ %140, %104 ]
  %108 = trunc nuw nsw i64 %105 to i32
  %109 = getelementptr i8, ptr %99, i32 %108
  %110 = load i8, ptr %109, align 1, !tbaa !46, !noalias !59
  %111 = zext i8 %110 to i64
  %112 = shl nuw nsw i64 %105, 3
  %113 = shl nuw i64 %111, %112
  %114 = or i64 %113, %106
  %115 = or disjoint i64 %105, 1
  %116 = trunc nuw nsw i64 %115 to i32
  %117 = getelementptr i8, ptr %99, i32 %116
  %118 = load i8, ptr %117, align 1, !tbaa !46, !noalias !59
  %119 = zext i8 %118 to i64
  %120 = shl nuw nsw i64 %115, 3
  %121 = shl nuw i64 %119, %120
  %122 = or i64 %121, %114
  %123 = or disjoint i64 %105, 2
  %124 = trunc nuw nsw i64 %123 to i32
  %125 = getelementptr i8, ptr %99, i32 %124
  %126 = load i8, ptr %125, align 1, !tbaa !46, !noalias !59
  %127 = zext i8 %126 to i64
  %128 = shl nuw nsw i64 %123, 3
  %129 = shl nuw i64 %127, %128
  %130 = or i64 %129, %122
  %131 = or disjoint i64 %105, 3
  %132 = trunc nuw nsw i64 %131 to i32
  %133 = getelementptr i8, ptr %99, i32 %132
  %134 = load i8, ptr %133, align 1, !tbaa !46, !noalias !59
  %135 = zext i8 %134 to i64
  %136 = shl nuw nsw i64 %131, 3
  %137 = shl nuw i64 %135, %136
  %138 = or i64 %137, %130
  %139 = add nuw nsw i64 %105, 4
  %140 = add i64 %107, 4
  %141 = icmp eq i64 %140, %103
  br i1 %141, label %152, label %104, !llvm.loop !64

142:                                              ; preds = %82
  %143 = load ptr, ptr %71, align 8, !tbaa !27, !noalias !65
  %144 = getelementptr inbounds nuw i64, ptr %143, i32 %83
  %145 = load i64, ptr %144, align 8, !tbaa !45, !noalias !65
  br label %172

146:                                              ; preds = %82
  %147 = load ptr, ptr %71, align 8, !tbaa !27, !noalias !65
  %148 = getelementptr inbounds nuw %struct.NmsValue, ptr %147, i32 %83
  %149 = load i64, ptr %148, align 8, !tbaa !45
  %150 = getelementptr inbounds nuw i8, ptr %148, i32 8
  %151 = load i32, ptr %150, align 8, !tbaa !1
  br label %172

152:                                              ; preds = %104
  %153 = icmp eq i64 %101, 0
  br i1 %153, label %172, label %154

154:                                              ; preds = %152, %96
  %155 = phi i64 [ 0, %96 ], [ %139, %152 ]
  %156 = phi i64 [ 0, %96 ], [ %138, %152 ]
  %157 = trunc i32 %94 to i1
  tail call void @llvm.assume(i1 %157)
  br label %158

158:                                              ; preds = %158, %154
  %159 = phi i64 [ %155, %154 ], [ %169, %158 ]
  %160 = phi i64 [ %156, %154 ], [ %168, %158 ]
  %161 = phi i64 [ 0, %154 ], [ %170, %158 ]
  %162 = trunc nuw nsw i64 %159 to i32
  %163 = getelementptr i8, ptr %99, i32 %162
  %164 = load i8, ptr %163, align 1, !tbaa !46, !noalias !59
  %165 = zext i8 %164 to i64
  %166 = shl nuw nsw i64 %159, 3
  %167 = shl nuw i64 %165, %166
  %168 = or i64 %167, %160
  %169 = add nuw nsw i64 %159, 1
  %170 = add i64 %161, 1
  %171 = icmp eq i64 %161, 0
  br i1 %171, label %172, label %158, !llvm.loop !66

172:                                              ; preds = %152, %158, %142, %146
  %173 = phi i32 [ %151, %146 ], [ 5, %142 ], [ %87, %158 ], [ %87, %152 ]
  %174 = phi i64 [ %149, %146 ], [ %145, %142 ], [ %138, %152 ], [ %168, %158 ]
  %175 = and i32 %173, -3
  %176 = icmp ne i32 %175, 5
  %177 = icmp ne i32 %173, 8
  %178 = and i1 %177, %176
  %179 = icmp sgt i64 %174, -1
  %180 = select i1 %178, i1 true, i1 %179
  br i1 %180, label %199, label %181

181:                                              ; preds = %172
  %182 = and i64 %174, 9223372036854775807
  %183 = add nsw i64 %182, -1
  %184 = icmp ult i64 %183, %40
  br i1 %184, label %185, label %191

185:                                              ; preds = %181
  %186 = trunc i64 %174 to i32
  %187 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i32 %186
  %188 = getelementptr inbounds nuw i8, ptr %187, i32 8
  %189 = load i64, ptr %188, align 8, !tbaa !23
  %190 = icmp eq i64 %189, 0
  br i1 %190, label %191, label %194

191:                                              ; preds = %185, %181
  %192 = icmp eq i32 %85, 0
  %193 = select i1 %192, i32 6, i32 %85
  br label %199

194:                                              ; preds = %185
  %195 = add i64 %189, -1
  store i64 %195, ptr %188, align 8, !tbaa !23
  %196 = icmp eq i64 %195, 0
  br i1 %196, label %197, label %199

197:                                              ; preds = %194
  %198 = getelementptr inbounds nuw i8, ptr %187, i32 20
  store i32 %84, ptr %198, align 4, !tbaa !39
  br label %199

199:                                              ; preds = %86, %191, %197, %194, %172
  %200 = phi i32 [ %85, %172 ], [ %193, %191 ], [ %85, %197 ], [ %85, %194 ], [ %85, %86 ]
  %201 = phi i32 [ %84, %172 ], [ %84, %191 ], [ %186, %197 ], [ %84, %194 ], [ %84, %86 ]
  %202 = add nuw i32 %83, 1
  %203 = icmp eq i32 %202, %78
  br i1 %203, label %204, label %82, !llvm.loop !67

204:                                              ; preds = %199, %65
  %205 = phi i32 [ %70, %65 ], [ %200, %199 ]
  %206 = phi i32 [ %73, %65 ], [ %201, %199 ]
  %207 = icmp eq i32 %75, 1
  br i1 %207, label %208, label %212

208:                                              ; preds = %204
  %209 = getelementptr inbounds nuw i8, ptr %71, i32 16
  %210 = load i32, ptr %209, align 8, !tbaa !38
  %211 = zext i32 %210 to i64
  br label %232

212:                                              ; preds = %76, %204
  %213 = phi i32 [ %206, %204 ], [ %73, %76 ]
  %214 = phi i32 [ %205, %204 ], [ %70, %76 ]
  %215 = getelementptr inbounds nuw i8, ptr %71, i32 24
  %216 = load i32, ptr %215, align 8, !tbaa !43
  switch i32 %75, label %227 [
    i32 2, label %228
    i32 4, label %217
  ]

217:                                              ; preds = %212
  %218 = getelementptr inbounds nuw i8, ptr %71, i32 32
  %219 = load i32, ptr %218, align 8, !tbaa !40
  %220 = and i32 %219, -3
  %221 = icmp eq i32 %220, 1
  %222 = icmp eq i32 %219, 2
  %223 = icmp eq i32 %219, 4
  %224 = or i1 %222, %223
  %225 = zext i1 %224 to i64
  %226 = select i1 %221, i64 8, i64 %225
  br label %228

227:                                              ; preds = %212
  br label %228

228:                                              ; preds = %212, %217, %227
  %229 = phi i64 [ 8, %212 ], [ %226, %217 ], [ 16, %227 ]
  %230 = zext i32 %216 to i64
  %231 = mul nuw nsw i64 %229, %230
  br label %232

232:                                              ; preds = %228, %208
  %233 = phi i32 [ %206, %208 ], [ %213, %228 ]
  %234 = phi i32 [ %205, %208 ], [ %214, %228 ]
  %235 = phi i64 [ %211, %208 ], [ %231, %228 ]
  %236 = sub i64 %68, %235
  store i64 %236, ptr %59, align 8, !tbaa !20
  %237 = add i64 %67, -1
  store i64 %237, ptr %60, align 8, !tbaa !19
  %238 = load ptr, ptr %71, align 8, !tbaa !27
  %239 = icmp eq ptr %238, null
  br i1 %239, label %281, label %240

240:                                              ; preds = %232
  %241 = getelementptr inbounds i8, ptr %238, i32 -16
  br label %242

242:                                              ; preds = %242, %240
  %243 = phi ptr [ null, %240 ], [ %245, %242 ]
  %244 = phi ptr [ @free_blocks, %240 ], [ %249, %242 ]
  %245 = load ptr, ptr %244, align 4, !tbaa !31
  %246 = icmp ne ptr %245, null
  %247 = icmp ult ptr %245, %241
  %248 = and i1 %246, %247
  %249 = getelementptr inbounds nuw i8, ptr %245, i32 8
  br i1 %248, label %242, label %250, !llvm.loop !33

250:                                              ; preds = %242
  %251 = ptrtoint ptr %241 to i32
  %252 = getelementptr inbounds i8, ptr %238, i32 -8
  store ptr %245, ptr %252, align 8, !tbaa !35
  br i1 %246, label %253, label %264

253:                                              ; preds = %250
  %254 = ptrtoint ptr %245 to i32
  %255 = zext i32 %251 to i64
  %256 = load i64, ptr %241, align 8, !tbaa !37
  %257 = add i64 %256, %255
  %258 = zext i32 %254 to i64
  %259 = icmp eq i64 %257, %258
  br i1 %259, label %260, label %264

260:                                              ; preds = %253
  %261 = load i64, ptr %245, align 8, !tbaa !37
  %262 = add i64 %261, %256
  store i64 %262, ptr %241, align 8, !tbaa !37
  %263 = load ptr, ptr %249, align 8, !tbaa !35
  store ptr %263, ptr %252, align 8, !tbaa !35
  br label %264

264:                                              ; preds = %260, %253, %250
  %265 = phi ptr [ %263, %260 ], [ %245, %253 ], [ null, %250 ]
  %266 = icmp eq ptr %243, null
  br i1 %266, label %280, label %267

267:                                              ; preds = %264
  %268 = ptrtoint ptr %243 to i32
  %269 = zext i32 %268 to i64
  %270 = load i64, ptr %243, align 8, !tbaa !37
  %271 = add i64 %270, %269
  %272 = zext i32 %251 to i64
  %273 = icmp eq i64 %271, %272
  br i1 %273, label %274, label %278

274:                                              ; preds = %267
  %275 = load i64, ptr %241, align 8, !tbaa !37
  %276 = add i64 %275, %270
  store i64 %276, ptr %243, align 8, !tbaa !37
  %277 = getelementptr inbounds nuw i8, ptr %243, i32 8
  store ptr %265, ptr %277, align 8, !tbaa !35
  br label %281

278:                                              ; preds = %267
  %279 = getelementptr inbounds nuw i8, ptr %243, i32 8
  store ptr %241, ptr %279, align 8, !tbaa !35
  br label %281

280:                                              ; preds = %264
  store ptr %241, ptr @free_blocks, align 4, !tbaa !31
  br label %281

281:                                              ; preds = %232, %274, %278, %280
  store ptr null, ptr %71, align 8, !tbaa !27
  %282 = getelementptr inbounds nuw i8, ptr %71, i32 16
  store i32 0, ptr %282, align 8, !tbaa !38
  %283 = getelementptr inbounds nuw i8, ptr %71, i32 24
  store i32 0, ptr %283, align 8, !tbaa !43
  store i32 0, ptr %74, align 4, !tbaa !26
  %284 = getelementptr inbounds nuw i8, ptr %71, i32 32
  store i32 0, ptr %284, align 8, !tbaa !40
  %285 = getelementptr inbounds nuw i8, ptr %71, i32 36
  store i32 0, ptr %285, align 4, !tbaa !41
  %286 = getelementptr inbounds nuw i8, ptr %71, i32 40
  store i32 0, ptr %286, align 8, !tbaa !42
  store i32 %66, ptr %72, align 4, !tbaa !39
  store i32 %69, ptr %61, align 8, !tbaa !17
  %287 = icmp eq i32 %233, 0
  br i1 %287, label %288, label %65, !llvm.loop !68

288:                                              ; preds = %281, %55, %21, %33, %36, %42, %46, %29, %28, %52, %17, %12, %10, %6, %5
  %289 = phi i32 [ 6, %12 ], [ 6, %5 ], [ %27, %21 ], [ 6, %28 ], [ 5, %6 ], [ 6, %10 ], [ 6, %17 ], [ 0, %52 ], [ 5, %29 ], [ 6, %33 ], [ 6, %36 ], [ 6, %42 ], [ 6, %46 ], [ 0, %55 ], [ %234, %281 ]
  ret i32 %289
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_vm_array_create(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = tail call fastcc i32 @vm_array_create_capacity(ptr noundef %0, i32 noundef %1, i32 noundef 8, ptr noundef %2) #27
  ret i32 %4
}

; Function Attrs: nofree norecurse nosync nounwind
define internal fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr noundef captures(address_is_null) %0, i32 noundef %1, i32 noundef %2, ptr noundef writeonly captures(address_is_null) %3) unnamed_addr #3 {
  %5 = alloca i64, align 8
  %6 = icmp ne ptr %0, null
  %7 = icmp ne ptr %3, null
  %8 = and i1 %6, %7
  br i1 %8, label %9, label %51

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %11 = load i32, ptr %10, align 8, !tbaa !21
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %51

13:                                               ; preds = %9
  switch i32 %1, label %51 [
    i32 9, label %14
    i32 7, label %14
    i32 5, label %14
    i32 4, label %14
    i32 3, label %14
    i32 2, label %14
    i32 1, label %14
    i32 0, label %14
  ]

14:                                               ; preds = %13, %13, %13, %13, %13, %13, %13, %13
  %15 = and i32 %1, -3
  %16 = icmp eq i32 %15, 1
  %17 = icmp eq i32 %1, 2
  %18 = icmp eq i32 %1, 4
  %19 = or i1 %17, %18
  %20 = zext i1 %19 to i32
  %21 = select i1 %16, i32 8, i32 %20
  %22 = icmp eq i32 %21, 0
  %23 = select i1 %22, i32 3, i32 4
  %24 = select i1 %22, i32 16, i32 %21
  %25 = tail call i32 @llvm.umax.i32(i32 %2, i32 8)
  %26 = zext i32 %25 to i64
  %27 = zext nneg i32 %24 to i64
  %28 = mul nuw nsw i64 %27, %26
  %29 = icmp samesign ugt i64 %28, 4294967295
  br i1 %29, label %51, label %30

30:                                               ; preds = %14
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %32 = load i64, ptr %31, align 8, !tbaa !20
  %33 = xor i64 %32, -1
  %34 = icmp ugt i64 %28, %33
  br i1 %34, label %51, label %35

35:                                               ; preds = %30
  %36 = tail call fastcc ptr @allocate(i64 noundef %28) #27
  %37 = icmp eq ptr %36, null
  br i1 %37, label %51, label %38

38:                                               ; preds = %35
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  store i64 0, ptr %5, align 8, !tbaa !45
  %39 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %36, i32 noundef 0, i32 noundef %25, i32 noundef %23, i64 noundef %28, ptr noundef %5) #27
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %42, label %41

41:                                               ; preds = %38
  tail call fastcc void @deallocate(ptr noundef nonnull %36) #27
  br label %50

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %44 = load ptr, ptr %43, align 8, !tbaa !13
  %45 = load i64, ptr %5, align 8, !tbaa !45
  %46 = trunc i64 %45 to i32
  %47 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i32 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i32 32
  store i32 %1, ptr %48, align 8, !tbaa !40
  %49 = getelementptr inbounds nuw i8, ptr %47, i32 36
  store i32 1, ptr %49, align 4, !tbaa !41
  store i64 %45, ptr %3, align 8, !tbaa !45
  br label %50

50:                                               ; preds = %42, %41
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  br label %51

51:                                               ; preds = %30, %14, %35, %50, %13, %9, %4
  %52 = phi i32 [ 6, %4 ], [ 1, %13 ], [ 5, %9 ], [ 3, %14 ], [ 3, %30 ], [ %39, %50 ], [ 3, %35 ]
  ret i32 %52
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_packed_array_create(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  %5 = icmp ne ptr %0, null
  %6 = icmp ne ptr %2, null
  %7 = and i1 %5, %6
  br i1 %7, label %8, label %26

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %10 = load i32, ptr %9, align 8, !tbaa !21
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %26

12:                                               ; preds = %8
  %13 = add i32 %1, -1
  %14 = icmp ult i32 %13, 4
  br i1 %14, label %15, label %26

15:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #28
  store i64 0, ptr %4, align 8, !tbaa !45
  %16 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 4, i64 noundef 0, ptr noundef %4) #27
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %25

18:                                               ; preds = %15
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %20 = load ptr, ptr %19, align 8, !tbaa !13
  %21 = load i64, ptr %4, align 8, !tbaa !45
  %22 = trunc i64 %21 to i32
  %23 = getelementptr inbounds nuw %struct.NmsSlot, ptr %20, i32 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i32 32
  store i32 %1, ptr %24, align 8, !tbaa !40
  store i64 %21, ptr %2, align 8, !tbaa !45
  br label %25

25:                                               ; preds = %15, %18
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  br label %26

26:                                               ; preds = %12, %8, %3, %25
  %27 = phi i32 [ 6, %3 ], [ %16, %25 ], [ 5, %8 ], [ 1, %12 ]
  ret i32 %27
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define hidden range(i32 0, 7) i32 @nms_bind_records(ptr noundef captures(address_is_null) %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #8 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %68, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %7 = load i32, ptr %6, align 8, !tbaa !21
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %68

9:                                                ; preds = %5
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 60
  %11 = load i32, ptr %10, align 4, !tbaa !22
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %68

13:                                               ; preds = %9
  %14 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %15 = load i32, ptr %14, align 8, !tbaa !9
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %68

17:                                               ; preds = %13
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = icmp eq i32 %19, 0
  br i1 %20, label %21, label %68

21:                                               ; preds = %17
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 40
  %23 = load i64, ptr %22, align 8, !tbaa !19
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %68

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %27 = load i64, ptr %26, align 8, !tbaa !20
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %29, label %68

29:                                               ; preds = %25
  %30 = icmp eq i32 %2, 0
  %31 = icmp ne ptr %1, null
  %32 = or i1 %31, %30
  br i1 %32, label %33, label %68

33:                                               ; preds = %29
  %34 = icmp ugt i32 %2, 256
  br i1 %34, label %68, label %35

35:                                               ; preds = %33
  br i1 %30, label %66, label %36

36:                                               ; preds = %35
  %37 = load i32, ptr %1, align 4, !tbaa !69
  %38 = icmp ugt i32 %37, 255
  br i1 %38, label %68, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %1, i32 4
  %41 = load i32, ptr %40, align 4, !tbaa !57
  %42 = icmp ugt i32 %41, 65535
  br i1 %42, label %68, label %43

43:                                               ; preds = %39
  %44 = icmp eq i32 %2, 1
  br i1 %44, label %66, label %45

45:                                               ; preds = %43, %62
  %46 = phi i32 [ %64, %62 ], [ 1, %43 ]
  %47 = phi i32 [ %63, %62 ], [ %41, %43 ]
  %48 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %1, i32 %46
  %49 = load i32, ptr %48, align 4, !tbaa !69
  %50 = icmp ugt i32 %49, 255
  br i1 %50, label %68, label %51

51:                                               ; preds = %45
  %52 = getelementptr i8, ptr %48, i32 -8
  %53 = load i32, ptr %52, align 4, !tbaa !69
  %54 = icmp ugt i32 %49, %53
  br i1 %54, label %55, label %68

55:                                               ; preds = %51
  %56 = getelementptr inbounds nuw i8, ptr %48, i32 4
  %57 = load i32, ptr %56, align 4, !tbaa !57
  %58 = icmp ugt i32 %57, 65535
  %59 = sub i32 65536, %47
  %60 = icmp ugt i32 %57, %59
  %61 = select i1 %58, i1 true, i1 %60
  br i1 %61, label %68, label %62

62:                                               ; preds = %55
  %63 = add i32 %57, %47
  %64 = add nuw i32 %46, 1
  %65 = icmp eq i32 %64, %2
  br i1 %65, label %66, label %45, !llvm.loop !70

66:                                               ; preds = %62, %43, %35
  store ptr %1, ptr %0, align 8, !tbaa !5
  %67 = getelementptr inbounds nuw i8, ptr %0, i32 4
  store i32 %2, ptr %67, align 4, !tbaa !10
  store i32 1, ptr %14, align 8, !tbaa !9
  br label %68

68:                                               ; preds = %55, %51, %45, %36, %39, %66, %33, %13, %17, %21, %25, %29, %9, %5, %3
  %69 = phi i32 [ 6, %3 ], [ 5, %5 ], [ 4, %9 ], [ 6, %13 ], [ 1, %33 ], [ 6, %29 ], [ 6, %25 ], [ 6, %21 ], [ 6, %17 ], [ 0, %66 ], [ 1, %36 ], [ 1, %39 ], [ 1, %45 ], [ 1, %51 ], [ 1, %55 ]
  ret i32 %69
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_record_create(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp ne ptr %0, null
  %8 = icmp ne ptr %4, null
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %98

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %12 = load i32, ptr %11, align 8, !tbaa !21
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %98

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %16 = load i32, ptr %15, align 8, !tbaa !9
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %98, label %18

18:                                               ; preds = %14
  %19 = load ptr, ptr %0, align 8, !tbaa !5
  %20 = icmp eq ptr %19, null
  br i1 %20, label %98, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %23 = load i32, ptr %22, align 4, !tbaa !10
  %24 = icmp ult i32 %1, %23
  br i1 %24, label %25, label %98

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %19, i32 %1
  %27 = getelementptr inbounds nuw i8, ptr %26, i32 4
  %28 = load i32, ptr %27, align 4, !tbaa !57
  %29 = icmp eq i32 %3, %28
  br i1 %29, label %30, label %98

30:                                               ; preds = %25
  %31 = icmp eq i32 %3, 0
  %32 = icmp ne ptr %2, null
  %33 = or i1 %32, %31
  br i1 %33, label %34, label %98

34:                                               ; preds = %30
  %35 = zext i32 %3 to i64
  %36 = shl nuw nsw i64 %35, 4
  %37 = icmp ugt i32 %3, 268435455
  br i1 %37, label %98, label %38

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %40 = load i64, ptr %39, align 8, !tbaa !20
  %41 = xor i64 %40, -1
  %42 = icmp ugt i64 %36, %41
  br i1 %42, label %98, label %43

43:                                               ; preds = %38
  br i1 %31, label %65, label %47

44:                                               ; preds = %47
  %45 = add nuw i32 %48, 1
  %46 = icmp eq i32 %45, %3
  br i1 %46, label %52, label %47, !llvm.loop !72

47:                                               ; preds = %43, %44
  %48 = phi i32 [ %45, %44 ], [ 0, %43 ]
  %49 = getelementptr inbounds nuw %struct.NmsValue, ptr %2, i32 %48
  %50 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, ptr noundef byval(%struct.NmsValue) align 8 %49) #27
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %44, label %98

52:                                               ; preds = %44
  %53 = tail call fastcc ptr @allocate(i64 noundef %36) #27
  %54 = icmp eq ptr %53, null
  br i1 %54, label %98, label %55

55:                                               ; preds = %52, %61
  %56 = phi i32 [ %62, %61 ], [ 0, %52 ]
  %57 = getelementptr inbounds nuw %struct.NmsValue, ptr %53, i32 %56
  %58 = getelementptr inbounds nuw %struct.NmsValue, ptr %2, i32 %56
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %57, ptr noundef nonnull align 8 dereferenceable(16) %58, i32 16, i1 false), !tbaa.struct !73
  %59 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %58) #27
  %60 = icmp eq i32 %59, 0
  br i1 %60, label %61, label %64

61:                                               ; preds = %55
  %62 = add nuw i32 %56, 1
  %63 = icmp eq i32 %62, %3
  br i1 %63, label %65, label %55, !llvm.loop !74

64:                                               ; preds = %55
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  br label %69

65:                                               ; preds = %61, %43
  %66 = phi ptr [ null, %43 ], [ %53, %61 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  %67 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef %66, i32 noundef %3, i32 noundef %3, i32 noundef 5, i64 noundef %36, ptr noundef %6) #27
  %68 = icmp eq i32 %67, 0
  br i1 %68, label %89, label %69

69:                                               ; preds = %64, %65
  %70 = phi i32 [ %59, %64 ], [ %67, %65 ]
  %71 = phi i32 [ %56, %64 ], [ %3, %65 ]
  %72 = phi ptr [ %53, %64 ], [ %66, %65 ]
  %73 = icmp eq i32 %71, 0
  br i1 %73, label %88, label %74

74:                                               ; preds = %69, %86
  %75 = phi i32 [ %76, %86 ], [ %71, %69 ]
  %76 = add i32 %75, -1
  %77 = getelementptr inbounds nuw %struct.NmsValue, ptr %72, i32 %76
  %78 = load i64, ptr %77, align 8
  %79 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %77) #27
  %80 = icmp eq i32 %79, 0
  br i1 %80, label %81, label %86

81:                                               ; preds = %74
  %82 = getelementptr inbounds nuw i8, ptr %77, i32 8
  %83 = load i32, ptr %82, align 8
  switch i32 %83, label %86 [
    i32 8, label %84
    i32 7, label %84
    i32 5, label %84
  ]

84:                                               ; preds = %81, %81, %81
  %85 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %78) #27
  br label %86

86:                                               ; preds = %74, %81, %84
  %87 = icmp eq i32 %76, 0
  br i1 %87, label %88, label %74, !llvm.loop !75

88:                                               ; preds = %86, %69
  tail call fastcc void @deallocate(ptr noundef %72) #27
  br label %96

89:                                               ; preds = %65
  %90 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %91 = load ptr, ptr %90, align 8, !tbaa !13
  %92 = load i64, ptr %6, align 8, !tbaa !45
  %93 = trunc i64 %92 to i32
  %94 = getelementptr inbounds nuw %struct.NmsSlot, ptr %91, i32 %93
  %95 = getelementptr inbounds nuw i8, ptr %94, i32 40
  store i32 %1, ptr %95, align 8, !tbaa !42
  store i64 %92, ptr %4, align 8, !tbaa !45
  br label %96

96:                                               ; preds = %89, %88
  %97 = phi i32 [ 0, %89 ], [ %70, %88 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  br label %98

98:                                               ; preds = %47, %38, %34, %52, %96, %30, %25, %14, %18, %21, %10, %5
  %99 = phi i32 [ 6, %5 ], [ 5, %10 ], [ 1, %14 ], [ 6, %30 ], [ 1, %25 ], [ 1, %21 ], [ 1, %18 ], [ 3, %52 ], [ 3, %34 ], [ 3, %38 ], [ %97, %96 ], [ %50, %47 ]
  ret i32 %99
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #9

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_record_identity(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #1 {
  %5 = icmp eq ptr %2, null
  %6 = icmp eq ptr %3, null
  %7 = or i1 %5, %6
  %8 = icmp eq ptr %0, null
  %9 = or i1 %8, %7
  br i1 %9, label %69, label %10

10:                                               ; preds = %4
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %12 = load i32, ptr %11, align 8, !tbaa !21
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %69

14:                                               ; preds = %10
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp slt i64 %1, 0
  %17 = icmp ne i64 %15, 0
  %18 = and i1 %16, %17
  br i1 %18, label %19, label %69

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %21 = load i32, ptr %20, align 4, !tbaa !18
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %15, %22
  br i1 %23, label %69, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %26 = load ptr, ptr %25, align 8, !tbaa !13
  %27 = icmp eq ptr %26, null
  br i1 %27, label %69, label %28

28:                                               ; preds = %24
  %29 = trunc i64 %1 to i32
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i32 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i32 8
  %32 = load i64, ptr %31, align 8, !tbaa !23
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %69, label %34

34:                                               ; preds = %28
  %35 = getelementptr inbounds nuw i8, ptr %30, i32 28
  %36 = load i32, ptr %35, align 4, !tbaa !26
  %37 = icmp eq i32 %36, 5
  br i1 %37, label %38, label %69

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %40 = load i32, ptr %39, align 8, !tbaa !9
  %41 = icmp eq i32 %40, 0
  br i1 %41, label %69, label %42

42:                                               ; preds = %38
  %43 = load ptr, ptr %0, align 8, !tbaa !5
  %44 = icmp eq ptr %43, null
  br i1 %44, label %69, label %45

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i8, ptr %30, i32 40
  %47 = load i32, ptr %46, align 8, !tbaa !42
  %48 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %49 = load i32, ptr %48, align 4, !tbaa !10
  %50 = icmp ult i32 %47, %49
  br i1 %50, label %51, label %69

51:                                               ; preds = %45
  %52 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %43, i32 %47
  %53 = getelementptr inbounds nuw i8, ptr %52, i32 4
  %54 = load i32, ptr %53, align 4, !tbaa !57
  %55 = getelementptr inbounds nuw i8, ptr %30, i32 16
  %56 = load i32, ptr %55, align 8, !tbaa !38
  %57 = icmp eq i32 %56, %54
  br i1 %57, label %58, label %69

58:                                               ; preds = %51
  %59 = getelementptr inbounds nuw i8, ptr %30, i32 24
  %60 = load i32, ptr %59, align 8, !tbaa !43
  %61 = icmp eq i32 %60, %54
  br i1 %61, label %62, label %69

62:                                               ; preds = %58
  %63 = icmp eq i32 %54, 0
  br i1 %63, label %67, label %64

64:                                               ; preds = %62
  %65 = load ptr, ptr %30, align 8, !tbaa !27
  %66 = icmp eq ptr %65, null
  br i1 %66, label %69, label %67

67:                                               ; preds = %62, %64
  store i32 %47, ptr %2, align 4, !tbaa !1
  %68 = load i32, ptr %52, align 4, !tbaa !69
  store i32 %68, ptr %3, align 4, !tbaa !1
  br label %69

69:                                               ; preds = %64, %10, %28, %24, %19, %14, %51, %58, %42, %45, %34, %38, %67, %4
  %70 = phi i32 [ 6, %4 ], [ 0, %67 ], [ 6, %38 ], [ 6, %64 ], [ 5, %10 ], [ 6, %28 ], [ 6, %24 ], [ 6, %19 ], [ 6, %14 ], [ 6, %51 ], [ 6, %58 ], [ 6, %42 ], [ 6, %45 ], [ 1, %34 ]
  ret i32 %70
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 8) i32 @nms_record_get(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #5 {
  %5 = alloca %struct.NmsValue, align 8
  %6 = icmp eq ptr %3, null
  %7 = icmp eq ptr %0, null
  %8 = or i1 %7, %6
  br i1 %8, label %120, label %9

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %11 = load i32, ptr %10, align 8, !tbaa !21
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %120

13:                                               ; preds = %9
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp slt i64 %1, 0
  %16 = icmp ne i64 %14, 0
  %17 = and i1 %15, %16
  br i1 %17, label %18, label %120

18:                                               ; preds = %13
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %20 = load i32, ptr %19, align 4, !tbaa !18
  %21 = freeze i32 %20
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %14, %22
  br i1 %23, label %120, label %24

24:                                               ; preds = %18
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %26 = load ptr, ptr %25, align 8, !tbaa !13
  %27 = icmp eq ptr %26, null
  br i1 %27, label %120, label %28

28:                                               ; preds = %24
  %29 = trunc i64 %1 to i32
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i32 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i32 8
  %32 = load i64, ptr %31, align 8, !tbaa !23
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %120, label %34

34:                                               ; preds = %28
  %35 = getelementptr inbounds nuw i8, ptr %30, i32 28
  %36 = load i32, ptr %35, align 4, !tbaa !26
  %37 = icmp eq i32 %36, 5
  br i1 %37, label %38, label %120

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %40 = load i32, ptr %39, align 8, !tbaa !9
  %41 = icmp eq i32 %40, 0
  br i1 %41, label %120, label %42

42:                                               ; preds = %38
  %43 = load ptr, ptr %0, align 8, !tbaa !5
  %44 = icmp eq ptr %43, null
  br i1 %44, label %120, label %45

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i8, ptr %30, i32 40
  %47 = load i32, ptr %46, align 8, !tbaa !42
  %48 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %49 = load i32, ptr %48, align 4, !tbaa !10
  %50 = icmp ult i32 %47, %49
  br i1 %50, label %51, label %120

51:                                               ; preds = %45
  %52 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %43, i32 %47
  %53 = getelementptr inbounds nuw i8, ptr %52, i32 4
  %54 = load i32, ptr %53, align 4, !tbaa !57
  %55 = getelementptr inbounds nuw i8, ptr %30, i32 16
  %56 = load i32, ptr %55, align 8, !tbaa !38
  %57 = icmp eq i32 %56, %54
  br i1 %57, label %58, label %120

58:                                               ; preds = %51
  %59 = getelementptr inbounds nuw i8, ptr %30, i32 24
  %60 = load i32, ptr %59, align 8, !tbaa !43
  %61 = icmp eq i32 %60, %54
  br i1 %61, label %62, label %120

62:                                               ; preds = %58
  %63 = icmp eq i32 %54, 0
  br i1 %63, label %67, label %64

64:                                               ; preds = %62
  %65 = load ptr, ptr %30, align 8, !tbaa !27
  %66 = icmp eq ptr %65, null
  br i1 %66, label %120, label %67

67:                                               ; preds = %62, %64
  %68 = zext i32 %54 to i64
  %69 = icmp ult i64 %2, %68
  br i1 %69, label %70, label %120

70:                                               ; preds = %67
  %71 = trunc nuw i64 %2 to i32
  %72 = load ptr, ptr %30, align 8, !tbaa !27, !noalias !76
  %73 = getelementptr inbounds nuw %struct.NmsValue, ptr %72, i32 %71
  %74 = load i64, ptr %73, align 8, !tbaa !45
  %75 = getelementptr inbounds nuw i8, ptr %73, i32 8
  %76 = load i32, ptr %75, align 8, !tbaa !1
  %77 = getelementptr inbounds nuw i8, ptr %73, i32 12
  %78 = load i32, ptr %77, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %5)
  store i64 %74, ptr %5, align 8
  %79 = getelementptr inbounds nuw i8, ptr %5, i32 8
  store i32 %76, ptr %79, align 8
  %80 = getelementptr inbounds nuw i8, ptr %5, i32 12
  store i32 %78, ptr %80, align 4
  %81 = tail call fastcc i32 @value_valid(ptr noundef nonnull readonly %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %5) #27
  %82 = icmp eq i32 %81, 0
  br i1 %82, label %83, label %115

83:                                               ; preds = %70
  switch i32 %76, label %117 [
    i32 8, label %84
    i32 7, label %84
    i32 5, label %84
  ]

84:                                               ; preds = %83, %83, %83
  %85 = icmp sgt i64 %74, -1
  br i1 %85, label %86, label %103

86:                                               ; preds = %84
  %87 = icmp eq i64 %74, 0
  br i1 %87, label %115, label %88

88:                                               ; preds = %86
  %89 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %90 = load i32, ptr %89, align 8, !tbaa !12
  %91 = zext i32 %90 to i64
  %92 = icmp samesign ugt i64 %74, %91
  br i1 %92, label %115, label %93

93:                                               ; preds = %88
  %94 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %95 = load ptr, ptr %94, align 4, !tbaa !11
  %96 = icmp eq ptr %95, null
  br i1 %96, label %115, label %97

97:                                               ; preds = %93
  %98 = trunc nuw i64 %74 to i32
  %99 = getelementptr %struct.NmsView, ptr %95, i32 %98
  %100 = getelementptr i8, ptr %99, i32 -8
  %101 = load ptr, ptr %100, align 4, !tbaa !28
  %102 = icmp eq ptr %101, null
  br i1 %102, label %115, label %117

103:                                              ; preds = %84
  %104 = and i64 %74, 9223372036854775807
  %105 = add nsw i64 %104, -1
  %106 = icmp ult i64 %105, %22
  br i1 %106, label %107, label %115

107:                                              ; preds = %103
  %108 = trunc i64 %74 to i32
  %109 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i32 %108
  %110 = getelementptr inbounds nuw i8, ptr %109, i32 8
  %111 = load i64, ptr %110, align 8, !tbaa !23
  switch i64 %111, label %112 [
    i64 0, label %115
    i64 -1, label %114
  ]

112:                                              ; preds = %107
  %113 = add nuw i64 %111, 1
  store i64 %113, ptr %110, align 8, !tbaa !23
  br label %117

114:                                              ; preds = %107
  br label %115

115:                                              ; preds = %70, %88, %114, %107, %86, %93, %103, %97
  %116 = phi i32 [ %81, %70 ], [ 3, %114 ], [ 6, %103 ], [ 6, %88 ], [ 6, %93 ], [ 6, %86 ], [ 6, %97 ], [ 6, %107 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  br label %120

117:                                              ; preds = %112, %83, %97
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  store i64 %74, ptr %3, align 8, !tbaa !45
  %118 = getelementptr inbounds nuw i8, ptr %3, i32 8
  store i32 %76, ptr %118, align 8, !tbaa !1
  %119 = getelementptr inbounds nuw i8, ptr %3, i32 12
  store i32 %78, ptr %119, align 4
  br label %120

120:                                              ; preds = %64, %9, %28, %24, %18, %13, %51, %58, %42, %45, %34, %38, %67, %115, %117, %4
  %121 = phi i32 [ 6, %4 ], [ 7, %67 ], [ 0, %117 ], [ %116, %115 ], [ 6, %38 ], [ 6, %64 ], [ 5, %9 ], [ 6, %28 ], [ 6, %24 ], [ 6, %18 ], [ 6, %13 ], [ 6, %51 ], [ 6, %58 ], [ 6, %42 ], [ 6, %45 ], [ 1, %34 ]
  ret i32 %121
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none)
define internal fastcc void @slot_value(ptr dead_on_unwind noalias nonnull writable writeonly sret(%struct.NmsValue) align 8 captures(none) initializes((8, 16)) %0, ptr noundef readonly captures(none) %1, i32 noundef %2) unnamed_addr #10 {
  %4 = getelementptr inbounds nuw i8, ptr %1, i32 28
  %5 = load i32, ptr %4, align 4, !tbaa !26
  switch i32 %5, label %93 [
    i32 4, label %6
    i32 2, label %87
  ]

6:                                                ; preds = %3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !79)
  %7 = getelementptr inbounds nuw i8, ptr %1, i32 32
  %8 = load i32, ptr %7, align 8, !tbaa !40, !noalias !79
  %9 = and i32 %8, -3
  %10 = icmp eq i32 %9, 1
  %11 = icmp eq i32 %8, 2
  %12 = icmp eq i32 %8, 4
  %13 = or i1 %11, %12
  %14 = zext i1 %13 to i32
  %15 = select i1 %10, i32 8, i32 %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 8
  store i32 %8, ptr %16, align 8, !tbaa !54, !alias.scope !79
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 12
  store i32 0, ptr %17, align 4, !alias.scope !79
  %18 = icmp eq i32 %15, 0
  br i1 %18, label %85, label %19

19:                                               ; preds = %6
  %20 = mul i32 %15, %2
  %21 = load ptr, ptr %1, align 8, !tbaa !27, !noalias !79
  %22 = getelementptr i8, ptr %21, i32 %20
  %23 = zext nneg i32 %15 to i64
  %24 = and i64 %23, 1
  br i1 %10, label %25, label %67

25:                                               ; preds = %19
  %26 = and i64 %23, 8
  br label %27

27:                                               ; preds = %27, %25
  %28 = phi i64 [ 0, %25 ], [ %62, %27 ]
  %29 = phi i64 [ 0, %25 ], [ %61, %27 ]
  %30 = phi i64 [ 0, %25 ], [ %63, %27 ]
  %31 = trunc nuw nsw i64 %28 to i32
  %32 = getelementptr i8, ptr %22, i32 %31
  %33 = load i8, ptr %32, align 1, !tbaa !46, !noalias !79
  %34 = zext i8 %33 to i64
  %35 = shl nuw nsw i64 %28, 3
  %36 = shl nuw i64 %34, %35
  %37 = or i64 %36, %29
  %38 = or disjoint i64 %28, 1
  %39 = trunc nuw nsw i64 %38 to i32
  %40 = getelementptr i8, ptr %22, i32 %39
  %41 = load i8, ptr %40, align 1, !tbaa !46, !noalias !79
  %42 = zext i8 %41 to i64
  %43 = shl nuw nsw i64 %38, 3
  %44 = shl nuw i64 %42, %43
  %45 = or i64 %44, %37
  %46 = or disjoint i64 %28, 2
  %47 = trunc nuw nsw i64 %46 to i32
  %48 = getelementptr i8, ptr %22, i32 %47
  %49 = load i8, ptr %48, align 1, !tbaa !46, !noalias !79
  %50 = zext i8 %49 to i64
  %51 = shl nuw nsw i64 %46, 3
  %52 = shl nuw i64 %50, %51
  %53 = or i64 %52, %45
  %54 = or disjoint i64 %28, 3
  %55 = trunc nuw nsw i64 %54 to i32
  %56 = getelementptr i8, ptr %22, i32 %55
  %57 = load i8, ptr %56, align 1, !tbaa !46, !noalias !79
  %58 = zext i8 %57 to i64
  %59 = shl nuw nsw i64 %54, 3
  %60 = shl nuw i64 %58, %59
  %61 = or i64 %60, %53
  %62 = add nuw nsw i64 %28, 4
  %63 = add i64 %30, 4
  %64 = icmp eq i64 %63, %26
  br i1 %64, label %65, label %27, !llvm.loop !64

65:                                               ; preds = %27
  %66 = icmp eq i64 %24, 0
  br i1 %66, label %85, label %67

67:                                               ; preds = %65, %19
  %68 = phi i64 [ 0, %19 ], [ %62, %65 ]
  %69 = phi i64 [ 0, %19 ], [ %61, %65 ]
  %70 = trunc i32 %15 to i1
  tail call void @llvm.assume(i1 %70)
  br label %71

71:                                               ; preds = %71, %67
  %72 = phi i64 [ %68, %67 ], [ %82, %71 ]
  %73 = phi i64 [ %69, %67 ], [ %81, %71 ]
  %74 = phi i64 [ 0, %67 ], [ %83, %71 ]
  %75 = trunc nuw nsw i64 %72 to i32
  %76 = getelementptr i8, ptr %22, i32 %75
  %77 = load i8, ptr %76, align 1, !tbaa !46, !noalias !79
  %78 = zext i8 %77 to i64
  %79 = shl nuw nsw i64 %72, 3
  %80 = shl nuw i64 %78, %79
  %81 = or i64 %80, %73
  %82 = add nuw nsw i64 %72, 1
  %83 = add i64 %74, 1
  %84 = icmp eq i64 %74, 0
  br i1 %84, label %85, label %71, !llvm.loop !82

85:                                               ; preds = %65, %71, %6
  %86 = phi i64 [ 0, %6 ], [ %61, %65 ], [ %81, %71 ]
  store i64 %86, ptr %0, align 8, !alias.scope !79
  br label %96

87:                                               ; preds = %3
  %88 = load ptr, ptr %1, align 8, !tbaa !27
  %89 = getelementptr inbounds nuw i64, ptr %88, i32 %2
  %90 = load i64, ptr %89, align 8, !tbaa !45
  store i64 %90, ptr %0, align 8, !tbaa !56
  %91 = getelementptr inbounds nuw i8, ptr %0, i32 8
  store i32 5, ptr %91, align 8, !tbaa !54
  %92 = getelementptr inbounds nuw i8, ptr %0, i32 12
  store i32 0, ptr %92, align 4
  br label %96

93:                                               ; preds = %3
  %94 = load ptr, ptr %1, align 8, !tbaa !27
  %95 = getelementptr inbounds nuw %struct.NmsValue, ptr %94, i32 %2
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %95, i32 16, i1 false), !tbaa.struct !73
  br label %96

96:                                               ; preds = %93, %87, %85
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 8) i32 @nms_record_set(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %3) local_unnamed_addr #6 {
  %5 = alloca %struct.NmsValue, align 8
  %6 = icmp eq ptr %0, null
  br i1 %6, label %120, label %7

7:                                                ; preds = %4
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %9 = load i32, ptr %8, align 8, !tbaa !21
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %120

11:                                               ; preds = %7
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp slt i64 %1, 0
  %14 = icmp ne i64 %12, 0
  %15 = and i1 %13, %14
  br i1 %15, label %16, label %120

16:                                               ; preds = %11
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %18 = load i32, ptr %17, align 4, !tbaa !18
  %19 = freeze i32 %18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %12, %20
  br i1 %21, label %120, label %22

22:                                               ; preds = %16
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %24 = load ptr, ptr %23, align 8, !tbaa !13
  %25 = icmp eq ptr %24, null
  br i1 %25, label %120, label %26

26:                                               ; preds = %22
  %27 = trunc i64 %1 to i32
  %28 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i32 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i32 8
  %30 = load i64, ptr %29, align 8, !tbaa !23
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %120, label %32

32:                                               ; preds = %26
  %33 = getelementptr inbounds nuw i8, ptr %28, i32 28
  %34 = load i32, ptr %33, align 4, !tbaa !26
  %35 = icmp eq i32 %34, 5
  br i1 %35, label %36, label %120

36:                                               ; preds = %32
  %37 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %38 = load i32, ptr %37, align 8, !tbaa !9
  %39 = icmp eq i32 %38, 0
  br i1 %39, label %120, label %40

40:                                               ; preds = %36
  %41 = load ptr, ptr %0, align 8, !tbaa !5
  %42 = icmp eq ptr %41, null
  br i1 %42, label %120, label %43

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %28, i32 40
  %45 = load i32, ptr %44, align 8, !tbaa !42
  %46 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %47 = load i32, ptr %46, align 4, !tbaa !10
  %48 = icmp ult i32 %45, %47
  br i1 %48, label %49, label %120

49:                                               ; preds = %43
  %50 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %41, i32 %45
  %51 = getelementptr inbounds nuw i8, ptr %50, i32 4
  %52 = load i32, ptr %51, align 4, !tbaa !57
  %53 = getelementptr inbounds nuw i8, ptr %28, i32 16
  %54 = load i32, ptr %53, align 8, !tbaa !38
  %55 = icmp eq i32 %54, %52
  br i1 %55, label %56, label %120

56:                                               ; preds = %49
  %57 = getelementptr inbounds nuw i8, ptr %28, i32 24
  %58 = load i32, ptr %57, align 8, !tbaa !43
  %59 = icmp eq i32 %58, %52
  br i1 %59, label %60, label %120

60:                                               ; preds = %56
  %61 = icmp eq i32 %52, 0
  br i1 %61, label %65, label %62

62:                                               ; preds = %60
  %63 = load ptr, ptr %28, align 8, !tbaa !27
  %64 = icmp eq ptr %63, null
  br i1 %64, label %120, label %65

65:                                               ; preds = %60, %62
  %66 = zext i32 %52 to i64
  %67 = icmp ult i64 %2, %66
  br i1 %67, label %68, label %120

68:                                               ; preds = %65
  %69 = load i64, ptr %3, align 8
  %70 = tail call fastcc i32 @value_valid(ptr noundef nonnull readonly %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %3) #27
  %71 = icmp eq i32 %70, 0
  br i1 %71, label %72, label %120

72:                                               ; preds = %68
  %73 = getelementptr inbounds nuw i8, ptr %3, i32 8
  %74 = load i32, ptr %73, align 8
  switch i32 %74, label %106 [
    i32 8, label %75
    i32 7, label %75
    i32 5, label %75
  ]

75:                                               ; preds = %72, %72, %72
  %76 = icmp sgt i64 %69, -1
  br i1 %76, label %77, label %94

77:                                               ; preds = %75
  %78 = icmp eq i64 %69, 0
  br i1 %78, label %120, label %79

79:                                               ; preds = %77
  %80 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %81 = load i32, ptr %80, align 8, !tbaa !12
  %82 = zext i32 %81 to i64
  %83 = icmp samesign ugt i64 %69, %82
  br i1 %83, label %120, label %84

84:                                               ; preds = %79
  %85 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %86 = load ptr, ptr %85, align 4, !tbaa !11
  %87 = icmp eq ptr %86, null
  br i1 %87, label %120, label %88

88:                                               ; preds = %84
  %89 = trunc nuw i64 %69 to i32
  %90 = getelementptr %struct.NmsView, ptr %86, i32 %89
  %91 = getelementptr i8, ptr %90, i32 -8
  %92 = load ptr, ptr %91, align 4, !tbaa !28
  %93 = icmp eq ptr %92, null
  br i1 %93, label %120, label %106

94:                                               ; preds = %75
  %95 = and i64 %69, 9223372036854775807
  %96 = add nsw i64 %95, -1
  %97 = icmp ult i64 %96, %20
  br i1 %97, label %98, label %120

98:                                               ; preds = %94
  %99 = trunc i64 %69 to i32
  %100 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i32 %99
  %101 = getelementptr inbounds nuw i8, ptr %100, i32 8
  %102 = load i64, ptr %101, align 8, !tbaa !23
  switch i64 %102, label %103 [
    i64 0, label %120
    i64 -1, label %105
  ]

103:                                              ; preds = %98
  %104 = add nuw i64 %102, 1
  store i64 %104, ptr %101, align 8, !tbaa !23
  br label %106

105:                                              ; preds = %98
  br label %120

106:                                              ; preds = %103, %72, %88
  %107 = load ptr, ptr %28, align 8, !tbaa !27
  %108 = trunc nuw i64 %2 to i32
  %109 = getelementptr inbounds nuw %struct.NmsValue, ptr %107, i32 %108
  call void @llvm.lifetime.start.p0(ptr nonnull %5)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %5, ptr noundef nonnull align 8 dereferenceable(16) %109, i32 16, i1 false)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %109, ptr noundef nonnull align 8 dereferenceable(16) %3, i32 16, i1 false), !tbaa.struct !73
  %110 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %5) #27
  %111 = icmp eq i32 %110, 0
  br i1 %111, label %112, label %118

112:                                              ; preds = %106
  %113 = getelementptr inbounds nuw i8, ptr %5, i32 8
  %114 = load i32, ptr %113, align 8, !tbaa !54
  switch i32 %114, label %118 [
    i32 8, label %115
    i32 7, label %115
    i32 5, label %115
  ]

115:                                              ; preds = %112, %112, %112
  %116 = load i64, ptr %5, align 8, !tbaa !56
  %117 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %116) #27
  br label %118

118:                                              ; preds = %106, %112, %115
  %119 = phi i32 [ %110, %106 ], [ %117, %115 ], [ 0, %112 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  br label %120

120:                                              ; preds = %88, %94, %84, %77, %98, %105, %79, %68, %62, %4, %7, %26, %22, %16, %11, %49, %56, %40, %43, %32, %36, %118, %65
  %121 = phi i32 [ 6, %62 ], [ %119, %118 ], [ 7, %65 ], [ 6, %36 ], [ 6, %4 ], [ 5, %7 ], [ 6, %26 ], [ 6, %22 ], [ 6, %16 ], [ 6, %11 ], [ 6, %49 ], [ 6, %56 ], [ 6, %40 ], [ 6, %43 ], [ 1, %32 ], [ %70, %68 ], [ 3, %105 ], [ 6, %94 ], [ 6, %79 ], [ 6, %84 ], [ 6, %77 ], [ 6, %88 ], [ 6, %98 ]
  ret i32 %121
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_value_array_create(ptr noundef captures(address_is_null) %0, ptr noundef writeonly captures(address_is_null) %1) local_unnamed_addr #3 {
  %3 = icmp ne ptr %0, null
  %4 = icmp ne ptr %1, null
  %5 = and i1 %3, %4
  br i1 %5, label %6, label %12

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %8 = load i32, ptr %7, align 8, !tbaa !21
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 3, i64 noundef 0, ptr noundef %1) #27
  br label %12

12:                                               ; preds = %6, %2, %10
  %13 = phi i32 [ 6, %2 ], [ %11, %10 ], [ 5, %6 ]
  ret i32 %13
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_value_array_append(ptr noundef captures(address_is_null) %0, i64 noundef %1, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %2) local_unnamed_addr #4 {
  %4 = tail call fastcc i32 @value_array_write(ptr noundef %0, i64 noundef %1, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %2, i32 noundef 1) #27
  ret i32 %4
}

; Function Attrs: nofree norecurse nounwind
define internal fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %3, i32 noundef range(i32 0, 2) %4) unnamed_addr #4 {
  %6 = alloca double, align 8
  %7 = alloca i8, align 8
  %8 = alloca i8, align 1
  %9 = alloca i8, align 2
  %10 = alloca i8, align 1
  %11 = alloca i8, align 4
  %12 = alloca i8, align 1
  %13 = alloca i8, align 2
  %14 = alloca i8, align 1
  %15 = alloca %struct.NmsValue, align 8
  %16 = icmp sgt i64 %1, -1
  %17 = icmp eq ptr %0, null
  br i1 %16, label %18, label %41

18:                                               ; preds = %5
  br i1 %17, label %628, label %19

19:                                               ; preds = %18
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %21 = load i32, ptr %20, align 8, !tbaa !21
  %22 = icmp eq i32 %21, 0
  br i1 %22, label %23, label %628

23:                                               ; preds = %19
  %24 = icmp eq i64 %1, 0
  br i1 %24, label %628, label %25

25:                                               ; preds = %23
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %27 = load i32, ptr %26, align 8, !tbaa !12
  %28 = zext i32 %27 to i64
  %29 = icmp samesign ugt i64 %1, %28
  br i1 %29, label %628, label %30

30:                                               ; preds = %25
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %32 = load ptr, ptr %31, align 4, !tbaa !11
  %33 = icmp eq ptr %32, null
  br i1 %33, label %628, label %34

34:                                               ; preds = %30
  %35 = trunc nuw i64 %1 to i32
  %36 = getelementptr %struct.NmsView, ptr %32, i32 %35
  %37 = getelementptr i8, ptr %36, i32 -8
  %38 = load ptr, ptr %37, align 4, !tbaa !28
  %39 = icmp eq ptr %38, null
  %40 = select i1 %39, i32 6, i32 1
  br label %628

41:                                               ; preds = %5
  br i1 %17, label %628, label %42

42:                                               ; preds = %41
  %43 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %44 = load i32, ptr %43, align 8, !tbaa !21
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %46, label %628

46:                                               ; preds = %42
  %47 = and i64 %1, 9223372036854775807
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %628, label %49

49:                                               ; preds = %46
  %50 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %51 = load i32, ptr %50, align 4, !tbaa !18
  %52 = zext i32 %51 to i64
  %53 = icmp samesign ugt i64 %47, %52
  br i1 %53, label %628, label %54

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %56 = load ptr, ptr %55, align 8, !tbaa !13
  %57 = icmp eq ptr %56, null
  br i1 %57, label %628, label %58

58:                                               ; preds = %54
  %59 = trunc i64 %1 to i32
  %60 = getelementptr inbounds nuw %struct.NmsSlot, ptr %56, i32 %59
  %61 = getelementptr inbounds nuw i8, ptr %60, i32 8
  %62 = load i64, ptr %61, align 8, !tbaa !23
  %63 = icmp eq i64 %62, 0
  br i1 %63, label %628, label %64

64:                                               ; preds = %58
  %65 = getelementptr inbounds nuw i8, ptr %60, i32 28
  %66 = load i32, ptr %65, align 4, !tbaa !26
  %67 = add i32 %66, -2
  %68 = icmp ult i32 %67, 3
  br i1 %68, label %69, label %628

69:                                               ; preds = %64
  %70 = icmp eq i32 %66, 4
  br i1 %70, label %71, label %423

71:                                               ; preds = %69
  %72 = load i64, ptr %3, align 8
  %73 = getelementptr inbounds nuw i8, ptr %3, i32 8
  %74 = load i32, ptr %73, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %7)
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  call void @llvm.lifetime.start.p0(ptr nonnull %9)
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  call void @llvm.lifetime.start.p0(ptr nonnull %11)
  call void @llvm.lifetime.start.p0(ptr nonnull %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %13)
  call void @llvm.lifetime.start.p0(ptr nonnull %14)
  %75 = getelementptr inbounds nuw i8, ptr %60, i32 32
  %76 = load i32, ptr %75, align 8, !tbaa !40
  %77 = freeze i32 %76
  %78 = trunc i64 %72 to i8
  %79 = lshr i64 %72, 8
  %80 = trunc i64 %79 to i8
  %81 = lshr i64 %72, 16
  %82 = trunc i64 %81 to i8
  %83 = lshr i64 %72, 24
  %84 = trunc i64 %83 to i8
  %85 = lshr i64 %72, 32
  %86 = trunc i64 %85 to i8
  %87 = lshr i64 %72, 40
  %88 = trunc i64 %87 to i8
  %89 = lshr i64 %72, 48
  %90 = trunc i64 %89 to i8
  %91 = lshr i64 %72, 56
  %92 = trunc nuw i64 %91 to i8
  %93 = icmp eq i32 %74, 2
  %94 = icmp ugt i64 %72, 255
  %95 = select i1 %93, i1 %94, i1 false
  br i1 %95, label %421, label %96

96:                                               ; preds = %71
  %97 = icmp eq i32 %74, 4
  %98 = icmp ugt i64 %72, 1
  %99 = select i1 %97, i1 %98, i1 false
  br i1 %99, label %421, label %100

100:                                              ; preds = %96
  %101 = icmp eq i32 %77, %74
  %102 = add i32 %77, -1
  %103 = icmp ult i32 %102, 4
  %104 = and i1 %101, %103
  br i1 %104, label %105, label %106

105:                                              ; preds = %100
  store i8 %78, ptr %7, align 8
  store i8 %80, ptr %8, align 1
  store i8 %82, ptr %9, align 2
  store i8 %84, ptr %10, align 1
  store i8 %86, ptr %11, align 4
  store i8 %88, ptr %12, align 1
  store i8 %90, ptr %13, align 2
  store i8 %92, ptr %14, align 1
  br label %135

106:                                              ; preds = %100
  %107 = icmp eq i32 %77, 1
  %108 = and i1 %93, %107
  br i1 %108, label %109, label %110

109:                                              ; preds = %106
  store i8 %78, ptr %7, align 8
  store i8 %80, ptr %8, align 1
  store i8 %82, ptr %9, align 2
  store i8 %84, ptr %10, align 1
  store i8 %86, ptr %11, align 4
  store i8 %88, ptr %12, align 1
  store i8 %90, ptr %13, align 2
  store i8 %92, ptr %14, align 1
  br label %135

110:                                              ; preds = %106
  %111 = icmp eq i32 %77, 2
  %112 = icmp eq i32 %74, 1
  %113 = and i1 %112, %111
  br i1 %113, label %114, label %115

114:                                              ; preds = %110
  store i8 %78, ptr %7, align 8, !tbaa !45
  store i8 0, ptr %8, align 1, !tbaa !45
  store i8 0, ptr %9, align 2, !tbaa !45
  store i8 0, ptr %10, align 1, !tbaa !45
  store i8 0, ptr %11, align 4, !tbaa !45
  store i8 0, ptr %12, align 1, !tbaa !45
  store i8 0, ptr %13, align 2, !tbaa !45
  store i8 0, ptr %14, align 1, !tbaa !45
  br label %135

115:                                              ; preds = %110
  %116 = icmp eq i32 %77, 3
  %117 = and i1 %112, %116
  br i1 %117, label %118, label %421

118:                                              ; preds = %115
  call void @llvm.lifetime.start.p0(ptr nonnull %6)
  %119 = sitofp i64 %72 to double
  store double %119, ptr %6, align 8, !tbaa !83
  %120 = load volatile i8, ptr %6, align 8, !tbaa !46
  store volatile i8 %120, ptr %7, align 8, !tbaa !46
  %121 = getelementptr inbounds nuw i8, ptr %6, i32 1
  %122 = load volatile i8, ptr %121, align 1, !tbaa !46
  store volatile i8 %122, ptr %8, align 1, !tbaa !46
  %123 = getelementptr inbounds nuw i8, ptr %6, i32 2
  %124 = load volatile i8, ptr %123, align 2, !tbaa !46
  store volatile i8 %124, ptr %9, align 2, !tbaa !46
  %125 = getelementptr inbounds nuw i8, ptr %6, i32 3
  %126 = load volatile i8, ptr %125, align 1, !tbaa !46
  store volatile i8 %126, ptr %10, align 1, !tbaa !46
  %127 = getelementptr inbounds nuw i8, ptr %6, i32 4
  %128 = load volatile i8, ptr %127, align 4, !tbaa !46
  store volatile i8 %128, ptr %11, align 4, !tbaa !46
  %129 = getelementptr inbounds nuw i8, ptr %6, i32 5
  %130 = load volatile i8, ptr %129, align 1, !tbaa !46
  store volatile i8 %130, ptr %12, align 1, !tbaa !46
  %131 = getelementptr inbounds nuw i8, ptr %6, i32 6
  %132 = load volatile i8, ptr %131, align 2, !tbaa !46
  store volatile i8 %132, ptr %13, align 2, !tbaa !46
  %133 = getelementptr inbounds nuw i8, ptr %6, i32 7
  %134 = load volatile i8, ptr %133, align 1, !tbaa !46
  store volatile i8 %134, ptr %14, align 1, !tbaa !46
  call void @llvm.lifetime.end.p0(ptr nonnull %6)
  br label %135

135:                                              ; preds = %118, %114, %109, %105
  %136 = phi i8 [ %92, %105 ], [ %92, %109 ], [ 0, %114 ], [ %134, %118 ]
  %137 = phi i8 [ %90, %105 ], [ %90, %109 ], [ 0, %114 ], [ %132, %118 ]
  %138 = phi i8 [ %88, %105 ], [ %88, %109 ], [ 0, %114 ], [ %130, %118 ]
  %139 = phi i8 [ %86, %105 ], [ %86, %109 ], [ 0, %114 ], [ %128, %118 ]
  %140 = phi i8 [ %84, %105 ], [ %84, %109 ], [ 0, %114 ], [ %126, %118 ]
  %141 = phi i8 [ %82, %105 ], [ %82, %109 ], [ 0, %114 ], [ %124, %118 ]
  %142 = phi i8 [ %80, %105 ], [ %80, %109 ], [ 0, %114 ], [ %122, %118 ]
  %143 = phi i8 [ %78, %105 ], [ %78, %109 ], [ %78, %114 ], [ %120, %118 ]
  %144 = icmp eq i32 %4, 0
  %145 = getelementptr inbounds nuw i8, ptr %60, i32 16
  %146 = load i32, ptr %145, align 8, !tbaa !38
  br i1 %144, label %147, label %150

147:                                              ; preds = %135
  %148 = zext i32 %146 to i64
  %149 = icmp ult i64 %2, %148
  br i1 %149, label %152, label %421

150:                                              ; preds = %135
  %151 = icmp eq i32 %146, -1
  br i1 %151, label %421, label %152

152:                                              ; preds = %150, %147
  %153 = and i32 %77, -3
  %154 = icmp eq i32 %153, 1
  %155 = icmp eq i32 %77, 2
  %156 = icmp eq i32 %77, 4
  %157 = or i1 %155, %156
  %158 = zext i1 %157 to i32
  %159 = select i1 %154, i32 8, i32 %158
  %160 = icmp eq i32 %159, 0
  br i1 %160, label %421, label %161

161:                                              ; preds = %152
  br i1 %144, label %359, label %162

162:                                              ; preds = %161
  %163 = getelementptr inbounds nuw i8, ptr %60, i32 24
  %164 = load i32, ptr %163, align 8, !tbaa !43
  %165 = icmp eq i32 %146, %164
  br i1 %165, label %166, label %276

166:                                              ; preds = %162
  %167 = getelementptr inbounds nuw i8, ptr %60, i32 36
  %168 = load i32, ptr %167, align 4, !tbaa !41
  %169 = icmp eq i32 %146, 0
  %170 = zext i32 %146 to i64
  %171 = shl nuw nsw i64 %170, 1
  %172 = select i1 %169, i64 4, i64 %171
  %173 = icmp eq i32 %168, 0
  br i1 %173, label %181, label %174

174:                                              ; preds = %166
  %175 = icmp samesign ugt i64 %172, %170
  br i1 %175, label %176, label %421

176:                                              ; preds = %174
  %177 = tail call range(i32 0, 33) i32 @llvm.cttz.i32(i32 %159, i1 true)
  %178 = lshr i32 -1, %177
  %179 = zext i32 %178 to i64
  %180 = icmp samesign ugt i64 %172, %179
  br i1 %180, label %421, label %183

181:                                              ; preds = %166
  %182 = tail call i64 @llvm.umin.i64(i64 %172, i64 4294967295)
  br label %183

183:                                              ; preds = %181, %176
  %184 = phi i64 [ %172, %176 ], [ %182, %181 ]
  %185 = trunc nuw i64 %184 to i32
  %186 = zext nneg i32 %159 to i64
  %187 = mul nuw nsw i64 %184, %186
  %188 = sub i32 %185, %146
  %189 = zext i32 %188 to i64
  %190 = mul nuw nsw i64 %189, %186
  %191 = icmp samesign ugt i64 %187, 4294967295
  br i1 %191, label %421, label %192

192:                                              ; preds = %183
  %193 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %194 = load i64, ptr %193, align 8, !tbaa !20
  %195 = xor i64 %194, -1
  %196 = icmp ugt i64 %190, %195
  br i1 %196, label %421, label %197

197:                                              ; preds = %192
  %198 = tail call fastcc ptr @allocate(i64 noundef %187) #27
  %199 = icmp eq ptr %198, null
  br i1 %199, label %421, label %200

200:                                              ; preds = %197
  %201 = load ptr, ptr %60, align 8, !tbaa !27
  %202 = load i32, ptr %145, align 8, !tbaa !38
  %203 = freeze i32 %202
  %204 = icmp eq i32 %203, 0
  br i1 %204, label %262, label %205

205:                                              ; preds = %200
  %206 = zext i32 %203 to i64
  %207 = mul nuw nsw i64 %206, %186
  %208 = and i64 %207, 3
  %209 = icmp samesign ult i64 %207, 4
  br i1 %209, label %239, label %210

210:                                              ; preds = %205
  %211 = and i64 %207, 68719476732
  br label %212

212:                                              ; preds = %212, %210
  %213 = phi i64 [ 0, %210 ], [ %234, %212 ]
  %214 = phi i64 [ 0, %210 ], [ %235, %212 ]
  %215 = trunc i64 %213 to i32
  %216 = getelementptr inbounds nuw i8, ptr %201, i32 %215
  %217 = load volatile i8, ptr %216, align 1, !tbaa !46
  %218 = getelementptr inbounds nuw i8, ptr %198, i32 %215
  store volatile i8 %217, ptr %218, align 1, !tbaa !46
  %219 = trunc i64 %213 to i32
  %220 = or disjoint i32 %219, 1
  %221 = getelementptr inbounds nuw i8, ptr %201, i32 %220
  %222 = load volatile i8, ptr %221, align 1, !tbaa !46
  %223 = getelementptr inbounds nuw i8, ptr %198, i32 %220
  store volatile i8 %222, ptr %223, align 1, !tbaa !46
  %224 = trunc i64 %213 to i32
  %225 = or disjoint i32 %224, 2
  %226 = getelementptr inbounds nuw i8, ptr %201, i32 %225
  %227 = load volatile i8, ptr %226, align 1, !tbaa !46
  %228 = getelementptr inbounds nuw i8, ptr %198, i32 %225
  store volatile i8 %227, ptr %228, align 1, !tbaa !46
  %229 = trunc i64 %213 to i32
  %230 = or disjoint i32 %229, 3
  %231 = getelementptr inbounds nuw i8, ptr %201, i32 %230
  %232 = load volatile i8, ptr %231, align 1, !tbaa !46
  %233 = getelementptr inbounds nuw i8, ptr %198, i32 %230
  store volatile i8 %232, ptr %233, align 1, !tbaa !46
  %234 = add nuw nsw i64 %213, 4
  %235 = add i64 %214, 4
  %236 = icmp eq i64 %235, %211
  br i1 %236, label %237, label %212, !llvm.loop !47

237:                                              ; preds = %212
  %238 = icmp eq i64 %208, 0
  br i1 %238, label %252, label %239

239:                                              ; preds = %237, %205
  %240 = phi i64 [ 0, %205 ], [ %234, %237 ]
  %241 = icmp ne i64 %208, 0
  tail call void @llvm.assume(i1 %241)
  br label %242

242:                                              ; preds = %242, %239
  %243 = phi i64 [ %249, %242 ], [ %240, %239 ]
  %244 = phi i64 [ %250, %242 ], [ 0, %239 ]
  %245 = trunc i64 %243 to i32
  %246 = getelementptr inbounds nuw i8, ptr %201, i32 %245
  %247 = load volatile i8, ptr %246, align 1, !tbaa !46
  %248 = getelementptr inbounds nuw i8, ptr %198, i32 %245
  store volatile i8 %247, ptr %248, align 1, !tbaa !46
  %249 = add nuw nsw i64 %243, 1
  %250 = add i64 %244, 1
  %251 = icmp eq i64 %250, %208
  br i1 %251, label %252, label %242, !llvm.loop !85

252:                                              ; preds = %242, %237
  %253 = load ptr, ptr %60, align 8, !tbaa !27
  %254 = load i8, ptr %7, align 8, !tbaa !45
  %255 = load i8, ptr %8, align 1, !tbaa !45
  %256 = load i8, ptr %9, align 2, !tbaa !45
  %257 = load i8, ptr %10, align 1, !tbaa !45
  %258 = load i8, ptr %11, align 4, !tbaa !45
  %259 = load i8, ptr %12, align 1, !tbaa !45
  %260 = load i8, ptr %13, align 2, !tbaa !45
  %261 = load i8, ptr %14, align 1, !tbaa !45
  br label %262

262:                                              ; preds = %252, %200
  %263 = phi i8 [ %261, %252 ], [ %136, %200 ]
  %264 = phi i8 [ %260, %252 ], [ %137, %200 ]
  %265 = phi i8 [ %259, %252 ], [ %138, %200 ]
  %266 = phi i8 [ %258, %252 ], [ %139, %200 ]
  %267 = phi i8 [ %257, %252 ], [ %140, %200 ]
  %268 = phi i8 [ %256, %252 ], [ %141, %200 ]
  %269 = phi i8 [ %255, %252 ], [ %142, %200 ]
  %270 = phi i8 [ %254, %252 ], [ %143, %200 ]
  %271 = phi ptr [ %253, %252 ], [ %201, %200 ]
  store ptr %198, ptr %60, align 8, !tbaa !27
  store i32 %185, ptr %163, align 8, !tbaa !43
  %272 = load i64, ptr %193, align 8, !tbaa !20
  %273 = add i64 %272, %190
  store i64 %273, ptr %193, align 8, !tbaa !20
  tail call fastcc void @deallocate(ptr noundef %271) #27
  %274 = load i32, ptr %75, align 8, !tbaa !40
  %275 = and i32 %274, -3
  br label %276

276:                                              ; preds = %262, %162
  %277 = phi i32 [ %275, %262 ], [ %153, %162 ]
  %278 = phi i32 [ %274, %262 ], [ %77, %162 ]
  %279 = phi i8 [ %263, %262 ], [ %136, %162 ]
  %280 = phi i8 [ %264, %262 ], [ %137, %162 ]
  %281 = phi i8 [ %265, %262 ], [ %138, %162 ]
  %282 = phi i8 [ %266, %262 ], [ %139, %162 ]
  %283 = phi i8 [ %267, %262 ], [ %140, %162 ]
  %284 = phi i8 [ %268, %262 ], [ %141, %162 ]
  %285 = phi i8 [ %269, %262 ], [ %142, %162 ]
  %286 = phi i8 [ %270, %262 ], [ %143, %162 ]
  %287 = zext i8 %279 to i64
  %288 = shl nuw i64 %287, 56
  %289 = zext i8 %280 to i64
  %290 = shl nuw nsw i64 %289, 48
  %291 = zext i8 %281 to i64
  %292 = shl nuw nsw i64 %291, 40
  %293 = zext i8 %282 to i64
  %294 = shl nuw nsw i64 %293, 32
  %295 = zext i8 %283 to i64
  %296 = shl nuw nsw i64 %295, 24
  %297 = zext i8 %284 to i64
  %298 = shl nuw nsw i64 %297, 16
  %299 = zext i8 %285 to i64
  %300 = shl nuw nsw i64 %299, 8
  %301 = zext i8 %286 to i64
  %302 = or disjoint i64 %300, %301
  %303 = or disjoint i64 %302, %298
  %304 = or disjoint i64 %303, %296
  %305 = or disjoint i64 %304, %294
  %306 = or disjoint i64 %305, %292
  %307 = or disjoint i64 %290, %288
  %308 = or i64 %307, %306
  %309 = icmp ne i32 %277, 1
  %310 = icmp eq i32 %278, 2
  %311 = icmp eq i32 %278, 4
  %312 = or i1 %310, %311
  %313 = zext i1 %312 to i32
  %314 = select i1 %309, i32 %313, i32 8
  %315 = mul i32 %314, %146
  %316 = icmp eq i32 %314, 0
  br i1 %316, label %356, label %317

317:                                              ; preds = %276
  %318 = zext nneg i32 %314 to i64
  %319 = and i64 %318, 1
  %320 = select i1 %309, i1 %312, i1 false
  br i1 %320, label %346, label %321

321:                                              ; preds = %317
  %322 = and i64 %318, 8
  br label %323

323:                                              ; preds = %323, %321
  %324 = phi i64 [ 0, %321 ], [ %341, %323 ]
  %325 = phi i64 [ 0, %321 ], [ %342, %323 ]
  %326 = shl nuw nsw i64 %324, 3
  %327 = lshr i64 %308, %326
  %328 = trunc i64 %327 to i8
  %329 = load ptr, ptr %60, align 8, !tbaa !27
  %330 = getelementptr i8, ptr %329, i32 %315
  %331 = trunc nuw nsw i64 %324 to i32
  %332 = getelementptr i8, ptr %330, i32 %331
  store i8 %328, ptr %332, align 1, !tbaa !46
  %333 = or disjoint i64 %324, 1
  %334 = shl nuw nsw i64 %333, 3
  %335 = lshr i64 %308, %334
  %336 = trunc i64 %335 to i8
  %337 = load ptr, ptr %60, align 8, !tbaa !27
  %338 = getelementptr i8, ptr %337, i32 %315
  %339 = trunc nuw nsw i64 %333 to i32
  %340 = getelementptr i8, ptr %338, i32 %339
  store i8 %336, ptr %340, align 1, !tbaa !46
  %341 = add nuw nsw i64 %324, 2
  %342 = add i64 %325, 2
  %343 = icmp eq i64 %342, %322
  br i1 %343, label %344, label %323, !llvm.loop !86

344:                                              ; preds = %323
  %345 = icmp eq i64 %319, 0
  br i1 %345, label %356, label %346

346:                                              ; preds = %344, %317
  %347 = phi i64 [ 0, %317 ], [ %341, %344 ]
  %348 = trunc i32 %314 to i1
  tail call void @llvm.assume(i1 %348)
  %349 = shl nuw nsw i64 %347, 3
  %350 = lshr i64 %308, %349
  %351 = trunc i64 %350 to i8
  %352 = load ptr, ptr %60, align 8, !tbaa !27
  %353 = getelementptr i8, ptr %352, i32 %315
  %354 = trunc nuw nsw i64 %347 to i32
  %355 = getelementptr i8, ptr %353, i32 %354
  store i8 %351, ptr %355, align 1, !tbaa !46
  br label %356

356:                                              ; preds = %346, %344, %276
  %357 = load i32, ptr %145, align 8, !tbaa !38
  %358 = add i32 %357, 1
  store i32 %358, ptr %145, align 8, !tbaa !38
  br label %421

359:                                              ; preds = %161
  %360 = trunc i64 %2 to i32
  %361 = zext i8 %136 to i64
  %362 = shl nuw i64 %361, 56
  %363 = zext i8 %137 to i64
  %364 = shl nuw nsw i64 %363, 48
  %365 = zext i8 %138 to i64
  %366 = shl nuw nsw i64 %365, 40
  %367 = zext i8 %139 to i64
  %368 = shl nuw nsw i64 %367, 32
  %369 = zext i8 %140 to i64
  %370 = shl nuw nsw i64 %369, 24
  %371 = zext i8 %141 to i64
  %372 = shl nuw nsw i64 %371, 16
  %373 = zext i8 %142 to i64
  %374 = shl nuw nsw i64 %373, 8
  %375 = zext i8 %143 to i64
  %376 = or disjoint i64 %374, %375
  %377 = or disjoint i64 %376, %372
  %378 = or disjoint i64 %377, %370
  %379 = or disjoint i64 %378, %368
  %380 = or disjoint i64 %379, %366
  %381 = or disjoint i64 %364, %362
  %382 = or i64 %381, %380
  %383 = mul i32 %159, %360
  %384 = zext nneg i32 %159 to i64
  %385 = and i64 %384, 1
  switch i32 %77, label %386 [
    i32 4, label %411
    i32 2, label %411
  ]

386:                                              ; preds = %359
  %387 = and i64 %384, 8
  br label %388

388:                                              ; preds = %388, %386
  %389 = phi i64 [ 0, %386 ], [ %406, %388 ]
  %390 = phi i64 [ 0, %386 ], [ %407, %388 ]
  %391 = shl nuw nsw i64 %389, 3
  %392 = lshr i64 %382, %391
  %393 = trunc i64 %392 to i8
  %394 = load ptr, ptr %60, align 8, !tbaa !27
  %395 = getelementptr i8, ptr %394, i32 %383
  %396 = trunc nuw nsw i64 %389 to i32
  %397 = getelementptr i8, ptr %395, i32 %396
  store i8 %393, ptr %397, align 1, !tbaa !46
  %398 = or disjoint i64 %389, 1
  %399 = shl nuw nsw i64 %398, 3
  %400 = lshr i64 %382, %399
  %401 = trunc i64 %400 to i8
  %402 = load ptr, ptr %60, align 8, !tbaa !27
  %403 = getelementptr i8, ptr %402, i32 %383
  %404 = trunc nuw nsw i64 %398 to i32
  %405 = getelementptr i8, ptr %403, i32 %404
  store i8 %401, ptr %405, align 1, !tbaa !46
  %406 = add nuw nsw i64 %389, 2
  %407 = add i64 %390, 2
  %408 = icmp eq i64 %407, %387
  br i1 %408, label %409, label %388, !llvm.loop !86

409:                                              ; preds = %388
  %410 = icmp eq i64 %385, 0
  br i1 %410, label %421, label %411

411:                                              ; preds = %359, %359, %409
  %412 = phi i64 [ 0, %359 ], [ %406, %409 ], [ 0, %359 ]
  %413 = trunc i32 %159 to i1
  tail call void @llvm.assume(i1 %413)
  %414 = shl nuw nsw i64 %412, 3
  %415 = lshr i64 %382, %414
  %416 = trunc i64 %415 to i8
  %417 = load ptr, ptr %60, align 8, !tbaa !27
  %418 = getelementptr i8, ptr %417, i32 %383
  %419 = trunc nuw nsw i64 %412 to i32
  %420 = getelementptr i8, ptr %418, i32 %419
  store i8 %416, ptr %420, align 1, !tbaa !46
  br label %421

421:                                              ; preds = %411, %409, %71, %96, %115, %147, %150, %152, %174, %176, %183, %192, %197, %356
  %422 = phi i32 [ 1, %115 ], [ 6, %147 ], [ 3, %150 ], [ 6, %152 ], [ 3, %174 ], [ 1, %96 ], [ 0, %356 ], [ 1, %71 ], [ 3, %183 ], [ 3, %192 ], [ 3, %197 ], [ 3, %176 ], [ 0, %409 ], [ 0, %411 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7)
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  br label %628

423:                                              ; preds = %69
  %424 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %3) #27
  %425 = icmp eq i32 %424, 0
  br i1 %425, label %426, label %628

426:                                              ; preds = %423
  %427 = icmp eq i32 %4, 0
  %428 = getelementptr inbounds nuw i8, ptr %60, i32 16
  %429 = load i32, ptr %428, align 8, !tbaa !38
  br i1 %427, label %430, label %433

430:                                              ; preds = %426
  %431 = zext i32 %429 to i64
  %432 = icmp ult i64 %2, %431
  br i1 %432, label %435, label %628

433:                                              ; preds = %426
  %434 = icmp eq i32 %429, -1
  br i1 %434, label %628, label %439

435:                                              ; preds = %430
  %436 = trunc nuw i64 %2 to i32
  %437 = getelementptr inbounds nuw i8, ptr %60, i32 24
  %438 = load i32, ptr %437, align 8, !tbaa !43
  br label %460

439:                                              ; preds = %433
  %440 = getelementptr inbounds nuw i8, ptr %60, i32 24
  %441 = load i32, ptr %440, align 8, !tbaa !43
  %442 = icmp eq i32 %429, %441
  br i1 %442, label %443, label %460

443:                                              ; preds = %439
  %444 = getelementptr inbounds nuw i8, ptr %60, i32 36
  %445 = load i32, ptr %444, align 4, !tbaa !41
  %446 = icmp eq i32 %429, 0
  %447 = zext i32 %429 to i64
  %448 = shl nuw nsw i64 %447, 1
  %449 = select i1 %446, i64 4, i64 %448
  %450 = icmp eq i32 %445, 0
  br i1 %450, label %455, label %451

451:                                              ; preds = %443
  %452 = icmp samesign ule i64 %449, %447
  %453 = icmp samesign ugt i64 %449, 268435455
  %454 = select i1 %452, i1 true, i1 %453
  br i1 %454, label %628, label %457

455:                                              ; preds = %443
  %456 = tail call i64 @llvm.umin.i64(i64 %449, i64 4294967295)
  br label %457

457:                                              ; preds = %451, %455
  %458 = phi i64 [ %449, %451 ], [ %456, %455 ]
  %459 = trunc nuw i64 %458 to i32
  br label %460

460:                                              ; preds = %457, %435, %439
  %461 = phi i32 [ %438, %435 ], [ %429, %457 ], [ %441, %439 ]
  %462 = phi ptr [ %437, %435 ], [ %440, %457 ], [ %440, %439 ]
  %463 = phi i32 [ %436, %435 ], [ %429, %457 ], [ %429, %439 ]
  %464 = phi i32 [ %438, %435 ], [ %459, %457 ], [ %441, %439 ]
  %465 = zext i32 %464 to i64
  %466 = shl nuw nsw i64 %465, 4
  %467 = icmp ugt i32 %464, 268435455
  br i1 %467, label %628, label %468

468:                                              ; preds = %460
  %469 = zext i32 %461 to i64
  %470 = icmp eq i32 %66, 2
  %471 = select i1 %470, i64 3, i64 4
  %472 = shl nuw nsw i64 %469, %471
  %473 = sub nsw i64 %466, %472
  %474 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %475 = load i64, ptr %474, align 8, !tbaa !20
  %476 = xor i64 %475, -1
  %477 = icmp ugt i64 %473, %476
  br i1 %477, label %628, label %478

478:                                              ; preds = %468
  %479 = icmp ne i32 %464, %461
  %480 = select i1 %470, i1 true, i1 %479
  br i1 %480, label %481, label %597

481:                                              ; preds = %478
  %482 = tail call fastcc ptr @allocate(i64 noundef %466) #27
  %483 = icmp eq ptr %482, null
  br i1 %483, label %628, label %484

484:                                              ; preds = %481
  %485 = getelementptr inbounds nuw i8, ptr %60, i32 16
  %486 = load i32, ptr %485, align 8, !tbaa !38
  %487 = icmp eq i32 %486, 0
  br i1 %487, label %594, label %488

488:                                              ; preds = %484
  %489 = getelementptr inbounds nuw i8, ptr %60, i32 32
  br label %490

490:                                              ; preds = %488, %582
  %491 = phi i32 [ 0, %488 ], [ %588, %582 ]
  %492 = getelementptr inbounds nuw %struct.NmsValue, ptr %482, i32 %491
  %493 = load i32, ptr %65, align 4, !tbaa !26, !noalias !87
  switch i32 %493, label %554 [
    i32 4, label %494
    i32 2, label %550
  ]

494:                                              ; preds = %490
  %495 = load i32, ptr %489, align 8, !tbaa !40, !noalias !90
  %496 = and i32 %495, -3
  %497 = icmp eq i32 %496, 1
  %498 = icmp eq i32 %495, 2
  %499 = icmp eq i32 %495, 4
  %500 = or i1 %498, %499
  %501 = zext i1 %500 to i32
  %502 = select i1 %497, i32 8, i32 %501
  %503 = icmp eq i32 %502, 0
  br i1 %503, label %582, label %504

504:                                              ; preds = %494
  %505 = mul i32 %502, %491
  %506 = load ptr, ptr %60, align 8, !tbaa !27, !noalias !90
  %507 = getelementptr i8, ptr %506, i32 %505
  %508 = zext nneg i32 %502 to i64
  %509 = and i64 %508, 1
  br i1 %497, label %510, label %564

510:                                              ; preds = %504
  %511 = and i64 %508, 8
  br label %512

512:                                              ; preds = %512, %510
  %513 = phi i64 [ 0, %510 ], [ %547, %512 ]
  %514 = phi i64 [ 0, %510 ], [ %546, %512 ]
  %515 = phi i64 [ 0, %510 ], [ %548, %512 ]
  %516 = trunc nuw nsw i64 %513 to i32
  %517 = getelementptr i8, ptr %507, i32 %516
  %518 = load i8, ptr %517, align 1, !tbaa !46, !noalias !90
  %519 = zext i8 %518 to i64
  %520 = shl nuw nsw i64 %513, 3
  %521 = shl nuw i64 %519, %520
  %522 = or i64 %521, %514
  %523 = or disjoint i64 %513, 1
  %524 = trunc nuw nsw i64 %523 to i32
  %525 = getelementptr i8, ptr %507, i32 %524
  %526 = load i8, ptr %525, align 1, !tbaa !46, !noalias !90
  %527 = zext i8 %526 to i64
  %528 = shl nuw nsw i64 %523, 3
  %529 = shl nuw i64 %527, %528
  %530 = or i64 %529, %522
  %531 = or disjoint i64 %513, 2
  %532 = trunc nuw nsw i64 %531 to i32
  %533 = getelementptr i8, ptr %507, i32 %532
  %534 = load i8, ptr %533, align 1, !tbaa !46, !noalias !90
  %535 = zext i8 %534 to i64
  %536 = shl nuw nsw i64 %531, 3
  %537 = shl nuw i64 %535, %536
  %538 = or i64 %537, %530
  %539 = or disjoint i64 %513, 3
  %540 = trunc nuw nsw i64 %539 to i32
  %541 = getelementptr i8, ptr %507, i32 %540
  %542 = load i8, ptr %541, align 1, !tbaa !46, !noalias !90
  %543 = zext i8 %542 to i64
  %544 = shl nuw nsw i64 %539, 3
  %545 = shl nuw i64 %543, %544
  %546 = or i64 %545, %538
  %547 = add nuw nsw i64 %513, 4
  %548 = add i64 %515, 4
  %549 = icmp eq i64 %548, %511
  br i1 %549, label %562, label %512, !llvm.loop !64

550:                                              ; preds = %490
  %551 = load ptr, ptr %60, align 8, !tbaa !27, !noalias !87
  %552 = getelementptr inbounds nuw i64, ptr %551, i32 %491
  %553 = load i64, ptr %552, align 8, !tbaa !45, !noalias !87
  br label %582

554:                                              ; preds = %490
  %555 = load ptr, ptr %60, align 8, !tbaa !27, !noalias !87
  %556 = getelementptr inbounds nuw %struct.NmsValue, ptr %555, i32 %491
  %557 = load i64, ptr %556, align 8, !tbaa !45
  %558 = getelementptr inbounds nuw i8, ptr %556, i32 8
  %559 = load i32, ptr %558, align 8, !tbaa !1
  %560 = getelementptr inbounds nuw i8, ptr %556, i32 12
  %561 = load i32, ptr %560, align 4
  br label %582

562:                                              ; preds = %512
  %563 = icmp eq i64 %509, 0
  br i1 %563, label %582, label %564

564:                                              ; preds = %562, %504
  %565 = phi i64 [ 0, %504 ], [ %547, %562 ]
  %566 = phi i64 [ 0, %504 ], [ %546, %562 ]
  %567 = trunc i32 %502 to i1
  tail call void @llvm.assume(i1 %567)
  br label %568

568:                                              ; preds = %568, %564
  %569 = phi i64 [ %565, %564 ], [ %579, %568 ]
  %570 = phi i64 [ %566, %564 ], [ %578, %568 ]
  %571 = phi i64 [ 0, %564 ], [ %580, %568 ]
  %572 = trunc nuw nsw i64 %569 to i32
  %573 = getelementptr i8, ptr %507, i32 %572
  %574 = load i8, ptr %573, align 1, !tbaa !46, !noalias !90
  %575 = zext i8 %574 to i64
  %576 = shl nuw nsw i64 %569, 3
  %577 = shl nuw i64 %575, %576
  %578 = or i64 %577, %570
  %579 = add nuw nsw i64 %569, 1
  %580 = add i64 %571, 1
  %581 = icmp eq i64 %571, 0
  br i1 %581, label %582, label %568, !llvm.loop !93

582:                                              ; preds = %562, %568, %494, %550, %554
  %583 = phi i32 [ %561, %554 ], [ 0, %550 ], [ 0, %494 ], [ 0, %568 ], [ 0, %562 ]
  %584 = phi i32 [ %559, %554 ], [ 5, %550 ], [ %495, %494 ], [ %495, %568 ], [ %495, %562 ]
  %585 = phi i64 [ %557, %554 ], [ %553, %550 ], [ 0, %494 ], [ %546, %562 ], [ %578, %568 ]
  store i64 %585, ptr %492, align 8, !tbaa !45
  %586 = getelementptr inbounds nuw i8, ptr %492, i32 8
  store i32 %584, ptr %586, align 8, !tbaa !1
  %587 = getelementptr inbounds nuw i8, ptr %492, i32 12
  store i32 %583, ptr %587, align 4
  %588 = add nuw i32 %491, 1
  %589 = load i32, ptr %485, align 8, !tbaa !38
  %590 = icmp ult i32 %588, %589
  br i1 %590, label %490, label %591, !llvm.loop !94

591:                                              ; preds = %582
  %592 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %3) #27
  %593 = icmp eq i32 %592, 0
  br i1 %593, label %603, label %601

594:                                              ; preds = %484
  %595 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %3) #27
  %596 = icmp eq i32 %595, 0
  br i1 %596, label %603, label %601

597:                                              ; preds = %478
  %598 = load ptr, ptr %60, align 8, !tbaa !27
  %599 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %3) #27
  %600 = icmp eq i32 %599, 0
  br i1 %600, label %603, label %628

601:                                              ; preds = %591, %594
  %602 = phi i32 [ %595, %594 ], [ %592, %591 ]
  tail call fastcc void @deallocate(ptr noundef nonnull %482) #27
  br label %628

603:                                              ; preds = %594, %597, %591
  %604 = phi ptr [ %598, %597 ], [ %482, %591 ], [ %482, %594 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %15)
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %15, i8 0, i32 16, i1 false)
  br i1 %427, label %605, label %606

605:                                              ; preds = %603
  call fastcc void @slot_value(ptr dead_on_unwind writable sret(%struct.NmsValue) align 8 %15, ptr noundef nonnull %60, i32 noundef %463) #27
  br label %606

606:                                              ; preds = %605, %603
  br i1 %480, label %607, label %611

607:                                              ; preds = %606
  %608 = load ptr, ptr %60, align 8, !tbaa !27
  store ptr %604, ptr %60, align 8, !tbaa !27
  store i32 %464, ptr %462, align 8, !tbaa !43
  store i32 3, ptr %65, align 4, !tbaa !26
  %609 = load i64, ptr %474, align 8, !tbaa !20
  %610 = add i64 %609, %473
  store i64 %610, ptr %474, align 8, !tbaa !20
  tail call fastcc void @deallocate(ptr noundef %608) #27
  br label %611

611:                                              ; preds = %607, %606
  %612 = getelementptr inbounds nuw %struct.NmsValue, ptr %604, i32 %463
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %612, ptr noundef nonnull align 8 dereferenceable(16) %3, i32 16, i1 false), !tbaa.struct !73
  br i1 %427, label %617, label %613

613:                                              ; preds = %611
  %614 = getelementptr inbounds nuw i8, ptr %60, i32 16
  %615 = load i32, ptr %614, align 8, !tbaa !38
  %616 = add i32 %615, 1
  store i32 %616, ptr %614, align 8, !tbaa !38
  br label %626

617:                                              ; preds = %611
  %618 = load i64, ptr %15, align 8
  %619 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %15) #27
  %620 = icmp eq i32 %619, 0
  br i1 %620, label %621, label %626

621:                                              ; preds = %617
  %622 = getelementptr inbounds nuw i8, ptr %15, i32 8
  %623 = load i32, ptr %622, align 8
  switch i32 %623, label %626 [
    i32 8, label %624
    i32 7, label %624
    i32 5, label %624
  ]

624:                                              ; preds = %621, %621, %621
  %625 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %618) #27
  br label %626

626:                                              ; preds = %624, %621, %617, %613
  %627 = phi i32 [ 0, %613 ], [ %619, %617 ], [ %625, %624 ], [ 0, %621 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br label %628

628:                                              ; preds = %597, %451, %30, %23, %19, %25, %34, %18, %42, %58, %54, %49, %46, %41, %626, %481, %601, %460, %468, %421, %423, %430, %433, %64
  %629 = phi i32 [ 1, %64 ], [ %422, %421 ], [ %424, %423 ], [ 6, %430 ], [ %599, %597 ], [ 3, %433 ], [ 6, %41 ], [ 3, %460 ], [ 3, %468 ], [ 3, %481 ], [ %627, %626 ], [ %602, %601 ], [ 6, %30 ], [ 6, %23 ], [ 5, %19 ], [ 6, %25 ], [ %40, %34 ], [ 6, %18 ], [ 5, %42 ], [ 6, %58 ], [ 6, %54 ], [ 6, %49 ], [ 6, %46 ], [ 3, %451 ]
  ret i32 %629
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_value_array_set(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef readonly byval(%struct.NmsValue) align 8 captures(none) %3) local_unnamed_addr #4 {
  %5 = tail call fastcc i32 @value_array_write(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef nonnull byval(%struct.NmsValue) align 8 %3, i32 noundef 0) #27
  ret i32 %5
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_value_array_get(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #6 {
  %5 = alloca %struct.NmsValue, align 8
  %6 = icmp eq ptr %3, null
  br i1 %6, label %206, label %7

7:                                                ; preds = %4
  %8 = icmp sgt i64 %1, -1
  %9 = icmp eq ptr %0, null
  br i1 %8, label %10, label %33

10:                                               ; preds = %7
  br i1 %9, label %206, label %11

11:                                               ; preds = %10
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %13 = load i32, ptr %12, align 8, !tbaa !21
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %206

15:                                               ; preds = %11
  %16 = icmp eq i64 %1, 0
  br i1 %16, label %206, label %17

17:                                               ; preds = %15
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %19 = load i32, ptr %18, align 8, !tbaa !12
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %1, %20
  br i1 %21, label %206, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %24 = load ptr, ptr %23, align 4, !tbaa !11
  %25 = icmp eq ptr %24, null
  br i1 %25, label %206, label %26

26:                                               ; preds = %22
  %27 = trunc nuw i64 %1 to i32
  %28 = getelementptr %struct.NmsView, ptr %24, i32 %27
  %29 = getelementptr i8, ptr %28, i32 -8
  %30 = load ptr, ptr %29, align 4, !tbaa !28
  %31 = icmp eq ptr %30, null
  %32 = select i1 %31, i32 6, i32 1
  br label %206

33:                                               ; preds = %7
  br i1 %9, label %206, label %34

34:                                               ; preds = %33
  %35 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %36 = load i32, ptr %35, align 8, !tbaa !21
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %38, label %206

38:                                               ; preds = %34
  %39 = and i64 %1, 9223372036854775807
  %40 = icmp eq i64 %39, 0
  br i1 %40, label %206, label %41

41:                                               ; preds = %38
  %42 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %43 = load i32, ptr %42, align 4, !tbaa !18
  %44 = freeze i32 %43
  %45 = zext i32 %44 to i64
  %46 = icmp samesign ugt i64 %39, %45
  br i1 %46, label %206, label %47

47:                                               ; preds = %41
  %48 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %49 = load ptr, ptr %48, align 8, !tbaa !13
  %50 = icmp eq ptr %49, null
  br i1 %50, label %206, label %51

51:                                               ; preds = %47
  %52 = trunc i64 %1 to i32
  %53 = getelementptr inbounds nuw %struct.NmsSlot, ptr %49, i32 %52
  %54 = getelementptr inbounds nuw i8, ptr %53, i32 8
  %55 = load i64, ptr %54, align 8, !tbaa !23
  %56 = icmp eq i64 %55, 0
  br i1 %56, label %206, label %57

57:                                               ; preds = %51
  %58 = getelementptr inbounds nuw i8, ptr %53, i32 28
  %59 = load i32, ptr %58, align 4, !tbaa !26
  %60 = add i32 %59, -2
  %61 = icmp ult i32 %60, 3
  br i1 %61, label %62, label %206

62:                                               ; preds = %57
  %63 = getelementptr inbounds nuw i8, ptr %53, i32 16
  %64 = load i32, ptr %63, align 8, !tbaa !38
  %65 = zext i32 %64 to i64
  %66 = icmp ult i64 %2, %65
  br i1 %66, label %70, label %67

67:                                               ; preds = %62
  store i64 0, ptr %3, align 8, !tbaa !45
  %68 = getelementptr inbounds nuw i8, ptr %3, i32 8
  store i32 0, ptr %68, align 8, !tbaa !1
  %69 = getelementptr inbounds nuw i8, ptr %3, i32 12
  store i32 0, ptr %69, align 4
  br label %206

70:                                               ; preds = %62
  %71 = trunc nuw i64 %2 to i32
  switch i32 %59, label %133 [
    i32 4, label %72
    i32 2, label %129
  ]

72:                                               ; preds = %70
  %73 = getelementptr inbounds nuw i8, ptr %53, i32 32
  %74 = load i32, ptr %73, align 8, !tbaa !40, !noalias !95
  %75 = and i32 %74, -3
  %76 = icmp eq i32 %75, 1
  %77 = icmp eq i32 %74, 2
  %78 = icmp eq i32 %74, 4
  %79 = or i1 %77, %78
  %80 = zext i1 %79 to i32
  %81 = select i1 %76, i32 8, i32 %80
  %82 = icmp eq i32 %81, 0
  br i1 %82, label %161, label %83

83:                                               ; preds = %72
  %84 = mul i32 %81, %71
  %85 = load ptr, ptr %53, align 8, !tbaa !27, !noalias !95
  %86 = getelementptr i8, ptr %85, i32 %84
  %87 = zext nneg i32 %81 to i64
  %88 = and i64 %87, 1
  br i1 %76, label %89, label %143

89:                                               ; preds = %83
  %90 = and i64 %87, 8
  br label %91

91:                                               ; preds = %91, %89
  %92 = phi i64 [ 0, %89 ], [ %126, %91 ]
  %93 = phi i64 [ 0, %89 ], [ %125, %91 ]
  %94 = phi i64 [ 0, %89 ], [ %127, %91 ]
  %95 = trunc nuw nsw i64 %92 to i32
  %96 = getelementptr i8, ptr %86, i32 %95
  %97 = load i8, ptr %96, align 1, !tbaa !46, !noalias !95
  %98 = zext i8 %97 to i64
  %99 = shl nuw nsw i64 %92, 3
  %100 = shl nuw i64 %98, %99
  %101 = or i64 %100, %93
  %102 = or disjoint i64 %92, 1
  %103 = trunc nuw nsw i64 %102 to i32
  %104 = getelementptr i8, ptr %86, i32 %103
  %105 = load i8, ptr %104, align 1, !tbaa !46, !noalias !95
  %106 = zext i8 %105 to i64
  %107 = shl nuw nsw i64 %102, 3
  %108 = shl nuw i64 %106, %107
  %109 = or i64 %108, %101
  %110 = or disjoint i64 %92, 2
  %111 = trunc nuw nsw i64 %110 to i32
  %112 = getelementptr i8, ptr %86, i32 %111
  %113 = load i8, ptr %112, align 1, !tbaa !46, !noalias !95
  %114 = zext i8 %113 to i64
  %115 = shl nuw nsw i64 %110, 3
  %116 = shl nuw i64 %114, %115
  %117 = or i64 %116, %109
  %118 = or disjoint i64 %92, 3
  %119 = trunc nuw nsw i64 %118 to i32
  %120 = getelementptr i8, ptr %86, i32 %119
  %121 = load i8, ptr %120, align 1, !tbaa !46, !noalias !95
  %122 = zext i8 %121 to i64
  %123 = shl nuw nsw i64 %118, 3
  %124 = shl nuw i64 %122, %123
  %125 = or i64 %124, %117
  %126 = add nuw nsw i64 %92, 4
  %127 = add i64 %94, 4
  %128 = icmp eq i64 %127, %90
  br i1 %128, label %141, label %91, !llvm.loop !64

129:                                              ; preds = %70
  %130 = load ptr, ptr %53, align 8, !tbaa !27, !noalias !100
  %131 = getelementptr inbounds nuw i64, ptr %130, i32 %71
  %132 = load i64, ptr %131, align 8, !tbaa !45, !noalias !100
  br label %161

133:                                              ; preds = %70
  %134 = load ptr, ptr %53, align 8, !tbaa !27, !noalias !100
  %135 = getelementptr inbounds nuw %struct.NmsValue, ptr %134, i32 %71
  %136 = load i64, ptr %135, align 8, !tbaa !45
  %137 = getelementptr inbounds nuw i8, ptr %135, i32 8
  %138 = load i32, ptr %137, align 8, !tbaa !1
  %139 = getelementptr inbounds nuw i8, ptr %135, i32 12
  %140 = load i32, ptr %139, align 4
  br label %161

141:                                              ; preds = %91
  %142 = icmp eq i64 %88, 0
  br i1 %142, label %161, label %143

143:                                              ; preds = %141, %83
  %144 = phi i64 [ 0, %83 ], [ %126, %141 ]
  %145 = phi i64 [ 0, %83 ], [ %125, %141 ]
  %146 = trunc i32 %81 to i1
  tail call void @llvm.assume(i1 %146)
  br label %147

147:                                              ; preds = %147, %143
  %148 = phi i64 [ %144, %143 ], [ %158, %147 ]
  %149 = phi i64 [ %145, %143 ], [ %157, %147 ]
  %150 = phi i64 [ 0, %143 ], [ %159, %147 ]
  %151 = trunc nuw nsw i64 %148 to i32
  %152 = getelementptr i8, ptr %86, i32 %151
  %153 = load i8, ptr %152, align 1, !tbaa !46, !noalias !95
  %154 = zext i8 %153 to i64
  %155 = shl nuw nsw i64 %148, 3
  %156 = shl nuw i64 %154, %155
  %157 = or i64 %156, %149
  %158 = add nuw nsw i64 %148, 1
  %159 = add i64 %150, 1
  %160 = icmp eq i64 %150, 0
  br i1 %160, label %161, label %147, !llvm.loop !101

161:                                              ; preds = %141, %147, %72, %129, %133
  %162 = phi i32 [ %140, %133 ], [ 0, %129 ], [ 0, %72 ], [ 0, %147 ], [ 0, %141 ]
  %163 = phi i32 [ %138, %133 ], [ 5, %129 ], [ %74, %72 ], [ %74, %147 ], [ %74, %141 ]
  %164 = phi i64 [ %136, %133 ], [ %132, %129 ], [ 0, %72 ], [ %125, %141 ], [ %157, %147 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %5)
  store i64 %164, ptr %5, align 8
  %165 = getelementptr inbounds nuw i8, ptr %5, i32 8
  store i32 %163, ptr %165, align 8
  %166 = getelementptr inbounds nuw i8, ptr %5, i32 12
  store i32 %162, ptr %166, align 4
  %167 = tail call fastcc i32 @value_valid(ptr noundef nonnull readonly %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %5) #27
  %168 = icmp eq i32 %167, 0
  br i1 %168, label %169, label %201

169:                                              ; preds = %161
  switch i32 %163, label %203 [
    i32 8, label %170
    i32 7, label %170
    i32 5, label %170
  ]

170:                                              ; preds = %169, %169, %169
  %171 = icmp sgt i64 %164, -1
  br i1 %171, label %172, label %189

172:                                              ; preds = %170
  %173 = icmp eq i64 %164, 0
  br i1 %173, label %201, label %174

174:                                              ; preds = %172
  %175 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %176 = load i32, ptr %175, align 8, !tbaa !12
  %177 = zext i32 %176 to i64
  %178 = icmp samesign ugt i64 %164, %177
  br i1 %178, label %201, label %179

179:                                              ; preds = %174
  %180 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %181 = load ptr, ptr %180, align 4, !tbaa !11
  %182 = icmp eq ptr %181, null
  br i1 %182, label %201, label %183

183:                                              ; preds = %179
  %184 = trunc nuw i64 %164 to i32
  %185 = getelementptr %struct.NmsView, ptr %181, i32 %184
  %186 = getelementptr i8, ptr %185, i32 -8
  %187 = load ptr, ptr %186, align 4, !tbaa !28
  %188 = icmp eq ptr %187, null
  br i1 %188, label %201, label %203

189:                                              ; preds = %170
  %190 = and i64 %164, 9223372036854775807
  %191 = add nsw i64 %190, -1
  %192 = icmp ult i64 %191, %45
  br i1 %192, label %193, label %201

193:                                              ; preds = %189
  %194 = trunc i64 %164 to i32
  %195 = getelementptr inbounds nuw %struct.NmsSlot, ptr %49, i32 %194
  %196 = getelementptr inbounds nuw i8, ptr %195, i32 8
  %197 = load i64, ptr %196, align 8, !tbaa !23
  switch i64 %197, label %198 [
    i64 0, label %201
    i64 -1, label %200
  ]

198:                                              ; preds = %193
  %199 = add nuw i64 %197, 1
  store i64 %199, ptr %196, align 8, !tbaa !23
  br label %203

200:                                              ; preds = %193
  br label %201

201:                                              ; preds = %161, %174, %200, %193, %172, %179, %189, %183
  %202 = phi i32 [ %167, %161 ], [ 3, %200 ], [ 6, %189 ], [ 6, %174 ], [ 6, %179 ], [ 6, %172 ], [ 6, %183 ], [ 6, %193 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  br label %206

203:                                              ; preds = %198, %169, %183
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  store i64 %164, ptr %3, align 8, !tbaa !45
  %204 = getelementptr inbounds nuw i8, ptr %3, i32 8
  store i32 %163, ptr %204, align 8, !tbaa !1
  %205 = getelementptr inbounds nuw i8, ptr %3, i32 12
  store i32 %162, ptr %205, align 4
  br label %206

206:                                              ; preds = %22, %15, %11, %17, %26, %10, %34, %51, %47, %41, %38, %33, %57, %67, %201, %203, %4
  %207 = phi i32 [ 6, %4 ], [ 1, %57 ], [ 0, %67 ], [ 0, %203 ], [ %202, %201 ], [ 6, %22 ], [ 6, %15 ], [ 5, %11 ], [ 6, %17 ], [ %32, %26 ], [ 6, %10 ], [ 5, %34 ], [ 6, %51 ], [ 6, %47 ], [ 6, %41 ], [ 6, %38 ], [ 6, %33 ]
  ret i32 %207
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_value_array_pop(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #6 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %209, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %31

8:                                                ; preds = %5
  br i1 %7, label %209, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %11 = load i32, ptr %10, align 8, !tbaa !21
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %209

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %209, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %17 = load i32, ptr %16, align 8, !tbaa !12
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %209, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %22 = load ptr, ptr %21, align 4, !tbaa !11
  %23 = icmp eq ptr %22, null
  br i1 %23, label %209, label %24

24:                                               ; preds = %20
  %25 = trunc nuw i64 %1 to i32
  %26 = getelementptr %struct.NmsView, ptr %22, i32 %25
  %27 = getelementptr i8, ptr %26, i32 -8
  %28 = load ptr, ptr %27, align 4, !tbaa !28
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %209

31:                                               ; preds = %5
  br i1 %7, label %209, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %34 = load i32, ptr %33, align 8, !tbaa !21
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %209

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %209, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %41 = load i32, ptr %40, align 4, !tbaa !18
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %37, %42
  br i1 %43, label %209, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %46 = load ptr, ptr %45, align 8, !tbaa !13
  %47 = icmp eq ptr %46, null
  br i1 %47, label %209, label %48

48:                                               ; preds = %44
  %49 = trunc i64 %1 to i32
  %50 = getelementptr inbounds nuw %struct.NmsSlot, ptr %46, i32 %49
  %51 = getelementptr inbounds nuw i8, ptr %50, i32 8
  %52 = load i64, ptr %51, align 8, !tbaa !23
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %209, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw i8, ptr %50, i32 28
  %56 = load i32, ptr %55, align 4, !tbaa !26
  %57 = add i32 %56, -2
  %58 = icmp ult i32 %57, 3
  br i1 %58, label %59, label %209

59:                                               ; preds = %54
  %60 = getelementptr inbounds nuw i8, ptr %50, i32 16
  %61 = load i32, ptr %60, align 8, !tbaa !38
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %63, label %66

63:                                               ; preds = %59
  store i64 0, ptr %2, align 8, !tbaa !45
  %64 = getelementptr inbounds nuw i8, ptr %2, i32 8
  store i32 0, ptr %64, align 8, !tbaa !1
  %65 = getelementptr inbounds nuw i8, ptr %2, i32 12
  store i32 0, ptr %65, align 4
  br label %209

66:                                               ; preds = %59
  %67 = add i32 %61, -1
  switch i32 %56, label %130 [
    i32 4, label %68
    i32 2, label %126
  ]

68:                                               ; preds = %66
  %69 = getelementptr inbounds nuw i8, ptr %50, i32 32
  %70 = load i32, ptr %69, align 8, !tbaa !40, !noalias !102
  %71 = and i32 %70, -3
  %72 = icmp eq i32 %71, 1
  %73 = icmp eq i32 %70, 2
  %74 = icmp eq i32 %70, 4
  %75 = or i1 %73, %74
  %76 = zext i1 %75 to i32
  %77 = select i1 %72, i32 8, i32 %76
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %79, label %80

79:                                               ; preds = %68
  store i32 %67, ptr %60, align 8, !tbaa !38
  br label %203

80:                                               ; preds = %68
  %81 = mul i32 %77, %67
  %82 = load ptr, ptr %50, align 8, !tbaa !27, !noalias !102
  %83 = getelementptr i8, ptr %82, i32 %81
  %84 = zext nneg i32 %77 to i64
  %85 = and i64 %84, 1
  br i1 %72, label %86, label %140

86:                                               ; preds = %80
  %87 = and i64 %84, 8
  br label %88

88:                                               ; preds = %88, %86
  %89 = phi i64 [ 0, %86 ], [ %123, %88 ]
  %90 = phi i64 [ 0, %86 ], [ %122, %88 ]
  %91 = phi i64 [ 0, %86 ], [ %124, %88 ]
  %92 = trunc nuw nsw i64 %89 to i32
  %93 = getelementptr i8, ptr %83, i32 %92
  %94 = load i8, ptr %93, align 1, !tbaa !46, !noalias !102
  %95 = zext i8 %94 to i64
  %96 = shl nuw nsw i64 %89, 3
  %97 = shl nuw i64 %95, %96
  %98 = or i64 %97, %90
  %99 = or disjoint i64 %89, 1
  %100 = trunc nuw nsw i64 %99 to i32
  %101 = getelementptr i8, ptr %83, i32 %100
  %102 = load i8, ptr %101, align 1, !tbaa !46, !noalias !102
  %103 = zext i8 %102 to i64
  %104 = shl nuw nsw i64 %99, 3
  %105 = shl nuw i64 %103, %104
  %106 = or i64 %105, %98
  %107 = or disjoint i64 %89, 2
  %108 = trunc nuw nsw i64 %107 to i32
  %109 = getelementptr i8, ptr %83, i32 %108
  %110 = load i8, ptr %109, align 1, !tbaa !46, !noalias !102
  %111 = zext i8 %110 to i64
  %112 = shl nuw nsw i64 %107, 3
  %113 = shl nuw i64 %111, %112
  %114 = or i64 %113, %106
  %115 = or disjoint i64 %89, 3
  %116 = trunc nuw nsw i64 %115 to i32
  %117 = getelementptr i8, ptr %83, i32 %116
  %118 = load i8, ptr %117, align 1, !tbaa !46, !noalias !102
  %119 = zext i8 %118 to i64
  %120 = shl nuw nsw i64 %115, 3
  %121 = shl nuw i64 %119, %120
  %122 = or i64 %121, %114
  %123 = add nuw nsw i64 %89, 4
  %124 = add i64 %91, 4
  %125 = icmp eq i64 %124, %87
  br i1 %125, label %138, label %88, !llvm.loop !64

126:                                              ; preds = %66
  %127 = load ptr, ptr %50, align 8, !tbaa !27, !noalias !107
  %128 = getelementptr inbounds nuw i64, ptr %127, i32 %67
  %129 = load i64, ptr %128, align 8, !tbaa !45, !noalias !107
  store i32 %67, ptr %60, align 8, !tbaa !38
  store i64 0, ptr %128, align 8, !tbaa !45
  br label %203

130:                                              ; preds = %66
  %131 = load ptr, ptr %50, align 8, !tbaa !27, !noalias !107
  %132 = getelementptr inbounds nuw %struct.NmsValue, ptr %131, i32 %67
  %133 = load i64, ptr %132, align 8, !tbaa !45
  %134 = getelementptr inbounds nuw i8, ptr %132, i32 8
  %135 = load i32, ptr %134, align 8, !tbaa !1
  %136 = getelementptr inbounds nuw i8, ptr %132, i32 12
  %137 = load i32, ptr %136, align 4
  store i32 %67, ptr %60, align 8, !tbaa !38
  store i64 0, ptr %132, align 8, !tbaa !45
  store i32 0, ptr %134, align 8, !tbaa !1
  store i32 0, ptr %136, align 4
  br label %203

138:                                              ; preds = %88
  %139 = icmp eq i64 %85, 0
  br i1 %139, label %158, label %140

140:                                              ; preds = %138, %80
  %141 = phi i64 [ 0, %80 ], [ %123, %138 ]
  %142 = phi i64 [ 0, %80 ], [ %122, %138 ]
  %143 = trunc i32 %77 to i1
  tail call void @llvm.assume(i1 %143)
  br label %144

144:                                              ; preds = %144, %140
  %145 = phi i64 [ %141, %140 ], [ %155, %144 ]
  %146 = phi i64 [ %142, %140 ], [ %154, %144 ]
  %147 = phi i64 [ 0, %140 ], [ %156, %144 ]
  %148 = trunc nuw nsw i64 %145 to i32
  %149 = getelementptr i8, ptr %83, i32 %148
  %150 = load i8, ptr %149, align 1, !tbaa !46, !noalias !102
  %151 = zext i8 %150 to i64
  %152 = shl nuw nsw i64 %145, 3
  %153 = shl nuw i64 %151, %152
  %154 = or i64 %153, %146
  %155 = add nuw nsw i64 %145, 1
  %156 = add i64 %147, 1
  %157 = icmp eq i64 %147, 0
  br i1 %157, label %158, label %144, !llvm.loop !108

158:                                              ; preds = %144, %138
  %159 = phi i64 [ %122, %138 ], [ %154, %144 ]
  store i32 %67, ptr %60, align 8, !tbaa !38
  %160 = and i64 %84, 1
  br i1 %72, label %161, label %190

161:                                              ; preds = %158
  %162 = and i64 %84, 8
  br label %163

163:                                              ; preds = %163, %161
  %164 = phi i64 [ 0, %161 ], [ %185, %163 ]
  %165 = phi i64 [ 0, %161 ], [ %186, %163 ]
  %166 = load ptr, ptr %50, align 8, !tbaa !27
  %167 = getelementptr i8, ptr %166, i32 %81
  %168 = trunc nuw nsw i64 %164 to i32
  %169 = getelementptr i8, ptr %167, i32 %168
  store i8 0, ptr %169, align 1, !tbaa !46
  %170 = load ptr, ptr %50, align 8, !tbaa !27
  %171 = getelementptr i8, ptr %170, i32 %81
  %172 = trunc i64 %164 to i32
  %173 = getelementptr i8, ptr %171, i32 %172
  %174 = getelementptr i8, ptr %173, i32 1
  store i8 0, ptr %174, align 1, !tbaa !46
  %175 = load ptr, ptr %50, align 8, !tbaa !27
  %176 = getelementptr i8, ptr %175, i32 %81
  %177 = trunc i64 %164 to i32
  %178 = getelementptr i8, ptr %176, i32 %177
  %179 = getelementptr i8, ptr %178, i32 2
  store i8 0, ptr %179, align 1, !tbaa !46
  %180 = load ptr, ptr %50, align 8, !tbaa !27
  %181 = getelementptr i8, ptr %180, i32 %81
  %182 = trunc i64 %164 to i32
  %183 = getelementptr i8, ptr %181, i32 %182
  %184 = getelementptr i8, ptr %183, i32 3
  store i8 0, ptr %184, align 1, !tbaa !46
  %185 = add nuw nsw i64 %164, 4
  %186 = add i64 %165, 4
  %187 = icmp eq i64 %186, %162
  br i1 %187, label %188, label %163, !llvm.loop !86

188:                                              ; preds = %163
  %189 = icmp eq i64 %160, 0
  br i1 %189, label %203, label %190

190:                                              ; preds = %188, %158
  %191 = phi i64 [ 0, %158 ], [ %185, %188 ]
  %192 = trunc i32 %77 to i1
  tail call void @llvm.assume(i1 %192)
  br label %193

193:                                              ; preds = %193, %190
  %194 = phi i64 [ %191, %190 ], [ %200, %193 ]
  %195 = phi i64 [ 0, %190 ], [ %201, %193 ]
  %196 = load ptr, ptr %50, align 8, !tbaa !27
  %197 = getelementptr i8, ptr %196, i32 %81
  %198 = trunc nuw nsw i64 %194 to i32
  %199 = getelementptr i8, ptr %197, i32 %198
  store i8 0, ptr %199, align 1, !tbaa !46
  %200 = add nuw nsw i64 %194, 1
  %201 = add i64 %195, 1
  %202 = icmp eq i64 %195, 0
  br i1 %202, label %203, label %193, !llvm.loop !109

203:                                              ; preds = %188, %193, %79, %126, %130
  %204 = phi i64 [ %129, %126 ], [ %133, %130 ], [ 0, %79 ], [ %159, %193 ], [ %159, %188 ]
  %205 = phi i32 [ 5, %126 ], [ %135, %130 ], [ %70, %79 ], [ %70, %193 ], [ %70, %188 ]
  %206 = phi i32 [ 0, %126 ], [ %137, %130 ], [ 0, %79 ], [ 0, %193 ], [ 0, %188 ]
  store i64 %204, ptr %2, align 8, !tbaa !45
  %207 = getelementptr inbounds nuw i8, ptr %2, i32 8
  store i32 %205, ptr %207, align 8, !tbaa !1
  %208 = getelementptr inbounds nuw i8, ptr %2, i32 12
  store i32 %206, ptr %208, align 4
  br label %209

209:                                              ; preds = %20, %13, %9, %15, %24, %8, %32, %48, %44, %39, %36, %31, %54, %203, %63, %3
  %210 = phi i32 [ 6, %3 ], [ 1, %54 ], [ 0, %203 ], [ 0, %63 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %30, %24 ], [ 6, %8 ], [ 5, %32 ], [ 6, %48 ], [ 6, %44 ], [ 6, %39 ], [ 6, %36 ], [ 6, %31 ]
  ret i32 %210
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_value_array_length(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %62, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %31

8:                                                ; preds = %5
  br i1 %7, label %62, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %11 = load i32, ptr %10, align 8, !tbaa !21
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %62

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %62, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %17 = load i32, ptr %16, align 8, !tbaa !12
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %62, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %22 = load ptr, ptr %21, align 4, !tbaa !11
  %23 = icmp eq ptr %22, null
  br i1 %23, label %62, label %24

24:                                               ; preds = %20
  %25 = trunc nuw i64 %1 to i32
  %26 = getelementptr %struct.NmsView, ptr %22, i32 %25
  %27 = getelementptr i8, ptr %26, i32 -8
  %28 = load ptr, ptr %27, align 4, !tbaa !28
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %62

31:                                               ; preds = %5
  br i1 %7, label %62, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %34 = load i32, ptr %33, align 8, !tbaa !21
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %62

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %62, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %41 = load i32, ptr %40, align 4, !tbaa !18
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %37, %42
  br i1 %43, label %62, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %46 = load ptr, ptr %45, align 8, !tbaa !13
  %47 = icmp eq ptr %46, null
  br i1 %47, label %62, label %48

48:                                               ; preds = %44
  %49 = trunc i64 %1 to i32
  %50 = getelementptr inbounds nuw %struct.NmsSlot, ptr %46, i32 %49
  %51 = getelementptr inbounds nuw i8, ptr %50, i32 8
  %52 = load i64, ptr %51, align 8, !tbaa !23
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %62, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw i8, ptr %50, i32 28
  %56 = load i32, ptr %55, align 4, !tbaa !26
  %57 = add i32 %56, -2
  %58 = icmp ult i32 %57, 3
  br i1 %58, label %59, label %62

59:                                               ; preds = %54
  %60 = getelementptr inbounds nuw i8, ptr %50, i32 16
  %61 = load i32, ptr %60, align 8, !tbaa !38
  store i32 %61, ptr %2, align 4, !tbaa !1
  br label %62

62:                                               ; preds = %20, %13, %9, %15, %24, %8, %32, %48, %44, %39, %36, %31, %54, %59, %3
  %63 = phi i32 [ 6, %3 ], [ 1, %54 ], [ 0, %59 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %30, %24 ], [ 6, %8 ], [ 5, %32 ], [ 6, %48 ], [ 6, %44 ], [ 6, %39 ], [ 6, %36 ], [ 6, %31 ]
  ret i32 %63
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_vm_array_literal(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(address_is_null) %3, i32 noundef %4, ptr noundef writeonly captures(address_is_null) %5) local_unnamed_addr #4 {
  %7 = alloca %struct.NmsValue, align 8
  %8 = alloca double, align 8
  %9 = alloca %struct.NmsValue, align 8
  %10 = alloca i8, align 8
  %11 = alloca i8, align 1
  %12 = alloca i8, align 2
  %13 = alloca i8, align 1
  %14 = alloca i8, align 4
  %15 = alloca i8, align 1
  %16 = alloca i8, align 2
  %17 = alloca i8, align 1
  %18 = alloca i64, align 8
  %19 = icmp eq ptr %0, null
  %20 = icmp eq ptr %5, null
  %21 = or i1 %19, %20
  %22 = icmp ugt i32 %4, 65535
  %23 = or i1 %22, %21
  br i1 %23, label %124, label %24

24:                                               ; preds = %6
  %25 = icmp eq i32 %4, 0
  br i1 %25, label %30, label %26

26:                                               ; preds = %24
  %27 = icmp ne ptr %2, null
  %28 = icmp ne ptr %3, null
  %29 = and i1 %27, %28
  br i1 %29, label %30, label %124

30:                                               ; preds = %26, %24
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %32 = load i32, ptr %31, align 8, !tbaa !21
  %33 = icmp eq i32 %32, 0
  br i1 %33, label %34, label %124

34:                                               ; preds = %30
  switch i32 %1, label %124 [
    i32 9, label %35
    i32 7, label %35
    i32 5, label %35
    i32 4, label %35
    i32 3, label %35
    i32 2, label %35
    i32 1, label %35
    i32 0, label %35
  ]

35:                                               ; preds = %34, %34, %34, %34, %34, %34, %34, %34
  br i1 %25, label %100, label %36

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %9, i32 8
  %38 = getelementptr inbounds nuw i8, ptr %9, i32 12
  %39 = and i32 %1, -3
  %40 = icmp ne i32 %39, 1
  %41 = icmp eq i32 %1, 2
  %42 = icmp eq i32 %1, 4
  %43 = or i1 %41, %42
  %44 = xor i1 %43, %40
  %45 = add nsw i32 %1, -1
  %46 = icmp ult i32 %45, 4
  %47 = icmp eq i32 %1, 1
  %48 = icmp eq i32 %1, 3
  %49 = getelementptr inbounds nuw i8, ptr %8, i32 1
  %50 = getelementptr inbounds nuw i8, ptr %8, i32 2
  %51 = getelementptr inbounds nuw i8, ptr %8, i32 3
  %52 = getelementptr inbounds nuw i8, ptr %8, i32 4
  %53 = getelementptr inbounds nuw i8, ptr %8, i32 5
  %54 = getelementptr inbounds nuw i8, ptr %8, i32 6
  %55 = getelementptr inbounds nuw i8, ptr %8, i32 7
  br label %56

56:                                               ; preds = %36, %97
  %57 = phi i32 [ 0, %36 ], [ %98, %97 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #28
  %58 = getelementptr inbounds nuw i64, ptr %2, i32 %57
  %59 = load i64, ptr %58, align 8, !tbaa !45
  store i64 %59, ptr %9, align 8, !tbaa !56
  %60 = getelementptr inbounds nuw i32, ptr %3, i32 %57
  %61 = load i32, ptr %60, align 4, !tbaa !1
  store i32 %61, ptr %37, align 8, !tbaa !54
  store i32 0, ptr %38, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  call void @llvm.lifetime.start.p0(ptr nonnull %11)
  call void @llvm.lifetime.start.p0(ptr nonnull %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %13)
  call void @llvm.lifetime.start.p0(ptr nonnull %14)
  call void @llvm.lifetime.start.p0(ptr nonnull %15)
  call void @llvm.lifetime.start.p0(ptr nonnull %16)
  call void @llvm.lifetime.start.p0(ptr nonnull %17)
  br i1 %44, label %94, label %62

62:                                               ; preds = %56
  %63 = trunc i64 %59 to i8
  %64 = icmp eq i32 %61, 2
  %65 = icmp ugt i64 %59, 255
  %66 = select i1 %64, i1 %65, i1 false
  br i1 %66, label %93, label %67

67:                                               ; preds = %62
  %68 = icmp eq i32 %61, 4
  %69 = icmp ugt i64 %59, 1
  %70 = select i1 %68, i1 %69, i1 false
  br i1 %70, label %93, label %71

71:                                               ; preds = %67
  %72 = icmp eq i32 %1, %61
  %73 = and i1 %46, %72
  %74 = and i1 %47, %64
  %75 = or i1 %73, %74
  br i1 %75, label %92, label %76

76:                                               ; preds = %71
  %77 = icmp eq i32 %61, 1
  %78 = and i1 %41, %77
  br i1 %78, label %79, label %80

79:                                               ; preds = %76
  store i8 %63, ptr %10, align 8, !tbaa !45
  store i8 0, ptr %11, align 1, !tbaa !45
  store i8 0, ptr %12, align 2, !tbaa !45
  br label %92

80:                                               ; preds = %76
  %81 = and i1 %48, %77
  br i1 %81, label %82, label %93

82:                                               ; preds = %80
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  %83 = sitofp i64 %59 to double
  store double %83, ptr %8, align 8, !tbaa !83
  %84 = load volatile i8, ptr %8, align 8, !tbaa !46
  store volatile i8 %84, ptr %10, align 8, !tbaa !46
  %85 = load volatile i8, ptr %49, align 1, !tbaa !46
  store volatile i8 %85, ptr %11, align 1, !tbaa !46
  %86 = load volatile i8, ptr %50, align 2, !tbaa !46
  store volatile i8 %86, ptr %12, align 2, !tbaa !46
  %87 = load volatile i8, ptr %51, align 1, !tbaa !46
  store volatile i8 %87, ptr %13, align 1, !tbaa !46
  %88 = load volatile i8, ptr %52, align 4, !tbaa !46
  store volatile i8 %88, ptr %14, align 4, !tbaa !46
  %89 = load volatile i8, ptr %53, align 1, !tbaa !46
  store volatile i8 %89, ptr %15, align 1, !tbaa !46
  %90 = load volatile i8, ptr %54, align 2, !tbaa !46
  store volatile i8 %90, ptr %16, align 2, !tbaa !46
  %91 = load volatile i8, ptr %55, align 1, !tbaa !46
  store volatile i8 %91, ptr %17, align 1, !tbaa !46
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  br label %92

92:                                               ; preds = %71, %79, %82
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  call void @llvm.lifetime.end.p0(ptr nonnull %16)
  call void @llvm.lifetime.end.p0(ptr nonnull %17)
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #28
  br label %97

93:                                               ; preds = %62, %67, %80
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  call void @llvm.lifetime.end.p0(ptr nonnull %16)
  call void @llvm.lifetime.end.p0(ptr nonnull %17)
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #28
  br label %124

94:                                               ; preds = %56
  %95 = tail call fastcc i32 @value_valid(ptr noundef %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %9) #27
  %96 = icmp eq i32 %95, 0
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  call void @llvm.lifetime.end.p0(ptr nonnull %16)
  call void @llvm.lifetime.end.p0(ptr nonnull %17)
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #28
  br i1 %96, label %97, label %124

97:                                               ; preds = %92, %94
  %98 = add nuw i32 %57, 1
  %99 = icmp eq i32 %98, %4
  br i1 %99, label %100, label %56, !llvm.loop !110

100:                                              ; preds = %97, %35
  call void @llvm.lifetime.start.p0(ptr nonnull %18) #28
  store i64 0, ptr %18, align 8, !tbaa !45
  %101 = call fastcc i32 @vm_array_create_capacity(ptr noundef %0, i32 noundef %1, i32 noundef %4, ptr noundef nonnull %18) #27
  %102 = icmp eq i32 %101, 0
  br i1 %102, label %103, label %122

103:                                              ; preds = %100
  %104 = load i64, ptr %18, align 8, !tbaa !45
  br i1 %25, label %121, label %105

105:                                              ; preds = %103
  %106 = getelementptr inbounds nuw i8, ptr %7, i32 8
  %107 = getelementptr inbounds nuw i8, ptr %7, i32 12
  br label %111

108:                                              ; preds = %111
  %109 = add nuw i32 %112, 1
  %110 = icmp eq i32 %109, %4
  br i1 %110, label %121, label %111, !llvm.loop !111

111:                                              ; preds = %105, %108
  %112 = phi i32 [ 0, %105 ], [ %109, %108 ]
  %113 = getelementptr inbounds nuw i64, ptr %2, i32 %112
  %114 = load i64, ptr %113, align 8, !tbaa !45
  %115 = getelementptr inbounds nuw i32, ptr %3, i32 %112
  %116 = load i32, ptr %115, align 4, !tbaa !1
  call void @llvm.lifetime.start.p0(ptr nonnull %7)
  store i64 %114, ptr %7, align 8
  store i32 %116, ptr %106, align 8
  store i32 0, ptr %107, align 4
  %117 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef %0, i64 noundef %104, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %7, i32 noundef 1) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %7)
  %118 = icmp eq i32 %117, 0
  br i1 %118, label %108, label %119

119:                                              ; preds = %111
  %120 = call i32 @nms_release(ptr noundef %0, i64 noundef %104) #27
  br label %122

121:                                              ; preds = %108, %103
  store i64 %104, ptr %5, align 8, !tbaa !45
  br label %122

122:                                              ; preds = %119, %100, %121
  %123 = phi i32 [ %117, %119 ], [ 0, %121 ], [ %101, %100 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %18) #28
  br label %124

124:                                              ; preds = %94, %93, %34, %30, %6, %26, %122
  %125 = phi i32 [ 5, %30 ], [ 6, %6 ], [ %123, %122 ], [ 1, %34 ], [ 6, %26 ], [ 1, %93 ], [ %95, %94 ]
  ret i32 %125
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_vm_array_slice(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #4 {
  %6 = alloca %struct.NmsValue, align 8
  %7 = alloca i64, align 8
  %8 = icmp eq ptr %4, null
  br i1 %8, label %262, label %9

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  %11 = icmp eq ptr %0, null
  br i1 %10, label %12, label %35

12:                                               ; preds = %9
  br i1 %11, label %262, label %13

13:                                               ; preds = %12
  %14 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %15 = load i32, ptr %14, align 8, !tbaa !21
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %262

17:                                               ; preds = %13
  %18 = icmp eq i64 %1, 0
  br i1 %18, label %262, label %19

19:                                               ; preds = %17
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %21 = load i32, ptr %20, align 8, !tbaa !12
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %1, %22
  br i1 %23, label %262, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %26 = load ptr, ptr %25, align 4, !tbaa !11
  %27 = icmp eq ptr %26, null
  br i1 %27, label %262, label %28

28:                                               ; preds = %24
  %29 = trunc nuw i64 %1 to i32
  %30 = getelementptr %struct.NmsView, ptr %26, i32 %29
  %31 = getelementptr i8, ptr %30, i32 -8
  %32 = load ptr, ptr %31, align 4, !tbaa !28
  %33 = icmp eq ptr %32, null
  %34 = select i1 %33, i32 6, i32 1
  br label %262

35:                                               ; preds = %9
  br i1 %11, label %262, label %36

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %38 = load i32, ptr %37, align 8, !tbaa !21
  %39 = icmp eq i32 %38, 0
  br i1 %39, label %40, label %262

40:                                               ; preds = %36
  %41 = and i64 %1, 9223372036854775807
  %42 = icmp eq i64 %41, 0
  br i1 %42, label %262, label %43

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %45 = load i32, ptr %44, align 4, !tbaa !18
  %46 = zext i32 %45 to i64
  %47 = icmp samesign ugt i64 %41, %46
  br i1 %47, label %262, label %48

48:                                               ; preds = %43
  %49 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %50 = load ptr, ptr %49, align 8, !tbaa !13
  %51 = icmp eq ptr %50, null
  br i1 %51, label %262, label %52

52:                                               ; preds = %48
  %53 = trunc i64 %1 to i32
  %54 = getelementptr inbounds nuw %struct.NmsSlot, ptr %50, i32 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i32 8
  %56 = load i64, ptr %55, align 8, !tbaa !23
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %262, label %58

58:                                               ; preds = %52
  %59 = getelementptr inbounds nuw i8, ptr %54, i32 28
  %60 = load i32, ptr %59, align 4, !tbaa !26
  %61 = add i32 %60, -2
  %62 = icmp ult i32 %61, 3
  br i1 %62, label %63, label %262

63:                                               ; preds = %58
  %64 = getelementptr inbounds nuw i8, ptr %54, i32 16
  %65 = load i32, ptr %64, align 8, !tbaa !38
  %66 = icmp eq i32 %60, 2
  br i1 %66, label %70, label %67

67:                                               ; preds = %63
  %68 = getelementptr inbounds nuw i8, ptr %54, i32 32
  %69 = load i32, ptr %68, align 8, !tbaa !40
  br label %70

70:                                               ; preds = %63, %67
  %71 = phi i32 [ %69, %67 ], [ 5, %63 ]
  %72 = tail call i32 @llvm.umin.i32(i32 %2, i32 %65)
  %73 = tail call i32 @llvm.umin.i32(i32 %3, i32 %65)
  %74 = tail call i32 @llvm.usub.sat.i32(i32 %73, i32 %72)
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #28
  store i64 0, ptr %7, align 8, !tbaa !45
  %75 = call fastcc i32 @vm_array_create_capacity(ptr noundef nonnull %0, i32 noundef %71, i32 noundef %74, ptr noundef nonnull %7) #27
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %77, label %260

77:                                               ; preds = %70
  %78 = load ptr, ptr %49, align 8, !tbaa !13
  %79 = getelementptr inbounds nuw %struct.NmsSlot, ptr %78, i32 %53
  %80 = load i64, ptr %7, align 8, !tbaa !45
  %81 = trunc i64 %80 to i32
  %82 = getelementptr inbounds nuw %struct.NmsSlot, ptr %78, i32 %81
  %83 = getelementptr inbounds nuw i8, ptr %79, i32 28
  %84 = load i32, ptr %83, align 4, !tbaa !26
  %85 = icmp eq i32 %84, 4
  %86 = icmp ult i32 %2, %73
  br i1 %85, label %92, label %87

87:                                               ; preds = %77
  br i1 %86, label %88, label %259

88:                                               ; preds = %87
  %89 = getelementptr inbounds nuw i8, ptr %79, i32 32
  %90 = getelementptr inbounds nuw i8, ptr %6, i32 8
  %91 = getelementptr inbounds nuw i8, ptr %6, i32 12
  br label %159

92:                                               ; preds = %77
  br i1 %86, label %93, label %154

93:                                               ; preds = %92
  %94 = and i32 %71, -3
  %95 = icmp eq i32 %94, 1
  %96 = icmp eq i32 %71, 2
  %97 = icmp eq i32 %71, 4
  %98 = or i1 %96, %97
  %99 = zext i1 %98 to i32
  %100 = select i1 %95, i32 8, i32 %99
  %101 = load ptr, ptr %82, align 8, !tbaa !27
  %102 = load ptr, ptr %79, align 8, !tbaa !27
  %103 = zext nneg i32 %100 to i64
  %104 = mul i32 %100, %72
  %105 = getelementptr inbounds nuw i8, ptr %102, i32 %104
  %106 = zext i32 %74 to i64
  %107 = mul nuw nsw i64 %103, %106
  %108 = icmp eq i64 %107, 0
  br i1 %108, label %154, label %109

109:                                              ; preds = %93
  %110 = and i64 %107, 3
  %111 = icmp samesign ult i64 %107, 4
  br i1 %111, label %141, label %112

112:                                              ; preds = %109
  %113 = and i64 %107, 68719476732
  br label %114

114:                                              ; preds = %114, %112
  %115 = phi i64 [ 0, %112 ], [ %136, %114 ]
  %116 = phi i64 [ 0, %112 ], [ %137, %114 ]
  %117 = trunc i64 %115 to i32
  %118 = getelementptr inbounds nuw i8, ptr %105, i32 %117
  %119 = load volatile i8, ptr %118, align 1, !tbaa !46
  %120 = getelementptr inbounds nuw i8, ptr %101, i32 %117
  store volatile i8 %119, ptr %120, align 1, !tbaa !46
  %121 = trunc i64 %115 to i32
  %122 = or disjoint i32 %121, 1
  %123 = getelementptr inbounds nuw i8, ptr %105, i32 %122
  %124 = load volatile i8, ptr %123, align 1, !tbaa !46
  %125 = getelementptr inbounds nuw i8, ptr %101, i32 %122
  store volatile i8 %124, ptr %125, align 1, !tbaa !46
  %126 = trunc i64 %115 to i32
  %127 = or disjoint i32 %126, 2
  %128 = getelementptr inbounds nuw i8, ptr %105, i32 %127
  %129 = load volatile i8, ptr %128, align 1, !tbaa !46
  %130 = getelementptr inbounds nuw i8, ptr %101, i32 %127
  store volatile i8 %129, ptr %130, align 1, !tbaa !46
  %131 = trunc i64 %115 to i32
  %132 = or disjoint i32 %131, 3
  %133 = getelementptr inbounds nuw i8, ptr %105, i32 %132
  %134 = load volatile i8, ptr %133, align 1, !tbaa !46
  %135 = getelementptr inbounds nuw i8, ptr %101, i32 %132
  store volatile i8 %134, ptr %135, align 1, !tbaa !46
  %136 = add nuw nsw i64 %115, 4
  %137 = add i64 %116, 4
  %138 = icmp eq i64 %137, %113
  br i1 %138, label %139, label %114, !llvm.loop !47

139:                                              ; preds = %114
  %140 = icmp eq i64 %110, 0
  br i1 %140, label %154, label %141

141:                                              ; preds = %139, %109
  %142 = phi i64 [ 0, %109 ], [ %136, %139 ]
  %143 = icmp ne i64 %110, 0
  call void @llvm.assume(i1 %143)
  br label %144

144:                                              ; preds = %144, %141
  %145 = phi i64 [ %151, %144 ], [ %142, %141 ]
  %146 = phi i64 [ %152, %144 ], [ 0, %141 ]
  %147 = trunc i64 %145 to i32
  %148 = getelementptr inbounds nuw i8, ptr %105, i32 %147
  %149 = load volatile i8, ptr %148, align 1, !tbaa !46
  %150 = getelementptr inbounds nuw i8, ptr %101, i32 %147
  store volatile i8 %149, ptr %150, align 1, !tbaa !46
  %151 = add nuw nsw i64 %145, 1
  %152 = add i64 %146, 1
  %153 = icmp eq i64 %152, %110
  br i1 %153, label %154, label %144, !llvm.loop !112

154:                                              ; preds = %139, %144, %93, %92
  %155 = getelementptr inbounds nuw i8, ptr %82, i32 16
  store i32 %74, ptr %155, align 8, !tbaa !38
  br label %259

156:                                              ; preds = %251
  %157 = add nuw i32 %160, 1
  %158 = icmp ult i32 %157, %74
  br i1 %158, label %159, label %259, !llvm.loop !113

159:                                              ; preds = %88, %156
  %160 = phi i32 [ 0, %88 ], [ %157, %156 ]
  %161 = add i32 %160, %72
  %162 = load i32, ptr %83, align 4, !tbaa !26, !noalias !114
  switch i32 %162, label %223 [
    i32 4, label %163
    i32 2, label %219
  ]

163:                                              ; preds = %159
  %164 = load i32, ptr %89, align 8, !tbaa !40, !noalias !117
  %165 = and i32 %164, -3
  %166 = icmp eq i32 %165, 1
  %167 = icmp eq i32 %164, 2
  %168 = icmp eq i32 %164, 4
  %169 = or i1 %167, %168
  %170 = zext i1 %169 to i32
  %171 = select i1 %166, i32 8, i32 %170
  %172 = icmp eq i32 %171, 0
  br i1 %172, label %251, label %173

173:                                              ; preds = %163
  %174 = mul i32 %171, %161
  %175 = load ptr, ptr %79, align 8, !tbaa !27, !noalias !117
  %176 = getelementptr i8, ptr %175, i32 %174
  %177 = zext nneg i32 %171 to i64
  %178 = and i64 %177, 1
  br i1 %166, label %179, label %233

179:                                              ; preds = %173
  %180 = and i64 %177, 8
  br label %181

181:                                              ; preds = %181, %179
  %182 = phi i64 [ 0, %179 ], [ %216, %181 ]
  %183 = phi i64 [ 0, %179 ], [ %215, %181 ]
  %184 = phi i64 [ 0, %179 ], [ %217, %181 ]
  %185 = trunc nuw nsw i64 %182 to i32
  %186 = getelementptr i8, ptr %176, i32 %185
  %187 = load i8, ptr %186, align 1, !tbaa !46, !noalias !117
  %188 = zext i8 %187 to i64
  %189 = shl nuw nsw i64 %182, 3
  %190 = shl nuw i64 %188, %189
  %191 = or i64 %190, %183
  %192 = or disjoint i64 %182, 1
  %193 = trunc nuw nsw i64 %192 to i32
  %194 = getelementptr i8, ptr %176, i32 %193
  %195 = load i8, ptr %194, align 1, !tbaa !46, !noalias !117
  %196 = zext i8 %195 to i64
  %197 = shl nuw nsw i64 %192, 3
  %198 = shl nuw i64 %196, %197
  %199 = or i64 %198, %191
  %200 = or disjoint i64 %182, 2
  %201 = trunc nuw nsw i64 %200 to i32
  %202 = getelementptr i8, ptr %176, i32 %201
  %203 = load i8, ptr %202, align 1, !tbaa !46, !noalias !117
  %204 = zext i8 %203 to i64
  %205 = shl nuw nsw i64 %200, 3
  %206 = shl nuw i64 %204, %205
  %207 = or i64 %206, %199
  %208 = or disjoint i64 %182, 3
  %209 = trunc nuw nsw i64 %208 to i32
  %210 = getelementptr i8, ptr %176, i32 %209
  %211 = load i8, ptr %210, align 1, !tbaa !46, !noalias !117
  %212 = zext i8 %211 to i64
  %213 = shl nuw nsw i64 %208, 3
  %214 = shl nuw i64 %212, %213
  %215 = or i64 %214, %207
  %216 = add nuw nsw i64 %182, 4
  %217 = add i64 %184, 4
  %218 = icmp eq i64 %217, %180
  br i1 %218, label %231, label %181, !llvm.loop !64

219:                                              ; preds = %159
  %220 = load ptr, ptr %79, align 8, !tbaa !27, !noalias !114
  %221 = getelementptr inbounds nuw i64, ptr %220, i32 %161
  %222 = load i64, ptr %221, align 8, !tbaa !45, !noalias !114
  br label %251

223:                                              ; preds = %159
  %224 = load ptr, ptr %79, align 8, !tbaa !27, !noalias !114
  %225 = getelementptr inbounds nuw %struct.NmsValue, ptr %224, i32 %161
  %226 = load i64, ptr %225, align 8, !tbaa !45
  %227 = getelementptr inbounds nuw i8, ptr %225, i32 8
  %228 = load i32, ptr %227, align 8, !tbaa !1
  %229 = getelementptr inbounds nuw i8, ptr %225, i32 12
  %230 = load i32, ptr %229, align 4
  br label %251

231:                                              ; preds = %181
  %232 = icmp eq i64 %178, 0
  br i1 %232, label %251, label %233

233:                                              ; preds = %231, %173
  %234 = phi i64 [ 0, %173 ], [ %216, %231 ]
  %235 = phi i64 [ 0, %173 ], [ %215, %231 ]
  %236 = trunc i32 %171 to i1
  call void @llvm.assume(i1 %236)
  br label %237

237:                                              ; preds = %237, %233
  %238 = phi i64 [ %234, %233 ], [ %248, %237 ]
  %239 = phi i64 [ %235, %233 ], [ %247, %237 ]
  %240 = phi i64 [ 0, %233 ], [ %249, %237 ]
  %241 = trunc nuw nsw i64 %238 to i32
  %242 = getelementptr i8, ptr %176, i32 %241
  %243 = load i8, ptr %242, align 1, !tbaa !46, !noalias !117
  %244 = zext i8 %243 to i64
  %245 = shl nuw nsw i64 %238, 3
  %246 = shl nuw i64 %244, %245
  %247 = or i64 %246, %239
  %248 = add nuw nsw i64 %238, 1
  %249 = add i64 %240, 1
  %250 = icmp eq i64 %240, 0
  br i1 %250, label %251, label %237, !llvm.loop !120

251:                                              ; preds = %231, %237, %163, %219, %223
  %252 = phi i32 [ %230, %223 ], [ 0, %219 ], [ 0, %163 ], [ 0, %237 ], [ 0, %231 ]
  %253 = phi i32 [ %228, %223 ], [ 5, %219 ], [ %164, %163 ], [ %164, %237 ], [ %164, %231 ]
  %254 = phi i64 [ %226, %223 ], [ %222, %219 ], [ 0, %163 ], [ %215, %231 ], [ %247, %237 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6)
  store i64 %254, ptr %6, align 8
  store i32 %253, ptr %90, align 8
  store i32 %252, ptr %91, align 4
  %255 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %80, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %6, i32 noundef 1) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %6)
  %256 = icmp eq i32 %255, 0
  br i1 %256, label %156, label %257

257:                                              ; preds = %251
  %258 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %80) #27
  br label %260

259:                                              ; preds = %156, %87, %154
  store i64 %80, ptr %4, align 8, !tbaa !45
  br label %260

260:                                              ; preds = %257, %259, %70
  %261 = phi i32 [ %75, %70 ], [ 0, %259 ], [ %255, %257 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #28
  br label %262

262:                                              ; preds = %24, %17, %13, %19, %28, %12, %36, %52, %48, %43, %40, %35, %260, %58, %5
  %263 = phi i32 [ 6, %5 ], [ %261, %260 ], [ 1, %58 ], [ 6, %24 ], [ 6, %17 ], [ 5, %13 ], [ 6, %19 ], [ %34, %28 ], [ 6, %12 ], [ 5, %36 ], [ 6, %52 ], [ 6, %48 ], [ 6, %43 ], [ 6, %40 ], [ 6, %35 ]
  ret i32 %263
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_format_scalar(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = alloca [32 x i8], align 16
  %6 = alloca [1100 x i8], align 16
  %7 = alloca [6 x i8], align 1
  %8 = alloca [20 x i8], align 16
  %9 = getelementptr inbounds nuw i8, ptr %5, i32 1
  switch i32 %2, label %572 [
    i32 3, label %10
    i32 9, label %552
    i32 7, label %552
    i32 0, label %552
    i32 4, label %567
  ]

10:                                               ; preds = %4
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  %11 = icmp sgt i64 %1, -1
  br i1 %11, label %13, label %12

12:                                               ; preds = %10
  store i8 45, ptr %5, align 16, !tbaa !46
  br label %13

13:                                               ; preds = %12, %10
  %14 = phi ptr [ %9, %12 ], [ %5, %10 ]
  %15 = phi i32 [ 1, %12 ], [ 0, %10 ]
  %16 = lshr i64 %1, 52
  %17 = trunc nuw nsw i64 %16 to i32
  %18 = and i32 %17, 2047
  %19 = and i64 %1, 4503599627370495
  %20 = icmp eq i32 %18, 2047
  br i1 %20, label %21, label %31

21:                                               ; preds = %13
  %22 = icmp eq i64 %19, 0
  %23 = select i1 %22, i8 105, i8 110
  store i8 %23, ptr %14, align 1, !tbaa !46
  %24 = select i1 %22, i8 110, i8 97
  %25 = getelementptr inbounds nuw i8, ptr %14, i32 1
  store i8 %24, ptr %25, align 1, !tbaa !46
  %26 = select i1 %22, i8 102, i8 110
  %27 = add nuw nsw i32 %15, 3
  %28 = getelementptr inbounds nuw i8, ptr %14, i32 2
  store i8 %26, ptr %28, align 1, !tbaa !46
  %29 = zext nneg i32 %27 to i64
  %30 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef %0, ptr noundef nonnull %5, i64 noundef %29, ptr noundef null, i64 noundef 0, ptr noundef %3) #27
  br label %550

31:                                               ; preds = %13
  %32 = icmp ne i32 %18, 0
  %33 = icmp ne i64 %19, 0
  %34 = or i1 %33, %32
  br i1 %34, label %39, label %35

35:                                               ; preds = %31
  %36 = add nuw nsw i32 %15, 1
  store i8 48, ptr %14, align 1, !tbaa !46
  %37 = zext nneg i32 %36 to i64
  %38 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef %0, ptr noundef nonnull %5, i64 noundef %37, ptr noundef null, i64 noundef 0, ptr noundef %3) #27
  br label %550

39:                                               ; preds = %31
  %40 = or disjoint i64 %19, 4503599627370496
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  %41 = select i1 %32, i64 %40, i64 %19
  br label %42

42:                                               ; preds = %39, %42
  %43 = phi i32 [ %50, %42 ], [ 0, %39 ]
  %44 = phi i64 [ %46, %42 ], [ %41, %39 ]
  %45 = freeze i64 %44
  %46 = udiv i64 %45, 10
  %47 = mul i64 %46, 10
  %48 = sub i64 %45, %47
  %49 = trunc nuw nsw i64 %48 to i8
  %50 = add i32 %43, 1
  %51 = getelementptr inbounds nuw i8, ptr %6, i32 %43
  store i8 %49, ptr %51, align 1, !tbaa !46
  %52 = icmp samesign ult i64 %44, 10
  br i1 %52, label %53, label %42, !llvm.loop !121

53:                                               ; preds = %42
  %54 = add nsw i32 %18, -1075
  %55 = select i1 %32, i32 %54, i32 -1074
  %56 = icmp slt i32 %55, 0
  %57 = tail call i32 @llvm.abs.i32(i32 %55, i1 true)
  %58 = select i1 %56, i32 5, i32 2
  %59 = icmp eq i32 %55, 0
  br i1 %59, label %127, label %60

60:                                               ; preds = %53, %123
  %61 = phi i32 [ %125, %123 ], [ 0, %53 ]
  %62 = phi i32 [ %124, %123 ], [ %50, %53 ]
  %63 = icmp eq i32 %62, 0
  br i1 %63, label %123, label %64

64:                                               ; preds = %60
  %65 = and i32 %62, 1
  %66 = icmp eq i32 %62, 1
  br i1 %66, label %71, label %67

67:                                               ; preds = %64
  %68 = and i32 %62, -2
  br label %89

69:                                               ; preds = %89
  %70 = icmp eq i32 %65, 0
  br i1 %70, label %85, label %71

71:                                               ; preds = %69, %64
  %72 = phi i32 [ 0, %64 ], [ %114, %69 ]
  %73 = phi i32 [ 0, %64 ], [ %110, %69 ]
  %74 = trunc i32 %62 to i1
  tail call void @llvm.assume(i1 %74)
  %75 = getelementptr inbounds nuw i8, ptr %6, i32 %72
  %76 = load i8, ptr %75, align 1, !tbaa !46
  %77 = zext i8 %76 to i32
  %78 = mul nuw nsw i32 %58, %77
  %79 = add nuw nsw i32 %78, %73
  %80 = freeze i32 %79
  %81 = udiv i32 %80, 10
  %82 = mul i32 %81, 10
  %83 = sub i32 %80, %82
  %84 = trunc nuw nsw i32 %83 to i8
  store i8 %84, ptr %75, align 1, !tbaa !46
  br label %85

85:                                               ; preds = %69, %71
  %86 = phi i32 [ %108, %69 ], [ %79, %71 ]
  %87 = phi i32 [ %110, %69 ], [ %81, %71 ]
  %88 = icmp samesign ult i32 %86, 10
  br i1 %88, label %123, label %117

89:                                               ; preds = %89, %67
  %90 = phi i32 [ 0, %67 ], [ %114, %89 ]
  %91 = phi i32 [ 0, %67 ], [ %110, %89 ]
  %92 = phi i32 [ 0, %67 ], [ %115, %89 ]
  %93 = getelementptr inbounds nuw i8, ptr %6, i32 %90
  %94 = load i8, ptr %93, align 2, !tbaa !46
  %95 = zext i8 %94 to i32
  %96 = mul nuw nsw i32 %58, %95
  %97 = add nuw nsw i32 %96, %91
  %98 = freeze i32 %97
  %99 = udiv i32 %98, 10
  %100 = mul i32 %99, 10
  %101 = sub i32 %98, %100
  %102 = trunc nuw nsw i32 %101 to i8
  store i8 %102, ptr %93, align 2, !tbaa !46
  %103 = getelementptr inbounds nuw i8, ptr %6, i32 %90
  %104 = getelementptr inbounds nuw i8, ptr %103, i32 1
  %105 = load i8, ptr %104, align 1, !tbaa !46
  %106 = zext i8 %105 to i32
  %107 = mul nuw nsw i32 %58, %106
  %108 = add nuw nsw i32 %107, %99
  %109 = freeze i32 %108
  %110 = udiv i32 %109, 10
  %111 = mul i32 %110, 10
  %112 = sub i32 %109, %111
  %113 = trunc nuw nsw i32 %112 to i8
  store i8 %113, ptr %104, align 1, !tbaa !46
  %114 = add nuw i32 %90, 2
  %115 = add i32 %92, 2
  %116 = icmp eq i32 %115, %68
  br i1 %116, label %69, label %89, !llvm.loop !122

117:                                              ; preds = %85
  %118 = icmp eq i32 %62, 1100
  br i1 %118, label %548, label %119

119:                                              ; preds = %117
  %120 = trunc i32 %87 to i8
  %121 = add i32 %62, 1
  %122 = getelementptr inbounds nuw i8, ptr %6, i32 %62
  store i8 %120, ptr %122, align 1, !tbaa !46
  br label %123

123:                                              ; preds = %119, %85, %60
  %124 = phi i32 [ %62, %85 ], [ %121, %119 ], [ 0, %60 ]
  %125 = add nuw i32 %61, 1
  %126 = icmp eq i32 %125, %57
  br i1 %126, label %127, label %60, !llvm.loop !123

127:                                              ; preds = %123, %53
  %128 = phi i32 [ %50, %53 ], [ %124, %123 ]
  %129 = add i32 %128, -1
  %130 = icmp eq i32 %128, 0
  br i1 %130, label %137, label %131

131:                                              ; preds = %127
  %132 = getelementptr inbounds nuw i8, ptr %6, i32 %129
  %133 = load i8, ptr %132, align 1, !tbaa !46
  %134 = zext i8 %133 to i32
  %135 = mul nuw nsw i32 %134, 10
  %136 = icmp eq i32 %128, 1
  br i1 %136, label %137, label %140

137:                                              ; preds = %131, %127
  %138 = phi i32 [ %135, %131 ], [ 0, %127 ]
  %139 = mul nuw nsw i32 %138, 10
  br label %148

140:                                              ; preds = %131
  %141 = getelementptr i8, ptr %6, i32 %128
  %142 = getelementptr i8, ptr %141, i32 -2
  %143 = load i8, ptr %142, align 1, !tbaa !46
  %144 = zext i8 %143 to i32
  %145 = add nuw nsw i32 %135, %144
  %146 = mul nuw nsw i32 %145, 10
  %147 = icmp ugt i32 %128, 2
  br i1 %147, label %151, label %148

148:                                              ; preds = %140, %137
  %149 = phi i32 [ %139, %137 ], [ %146, %140 ]
  %150 = mul nuw nsw i32 %149, 10
  br label %158

151:                                              ; preds = %140
  %152 = getelementptr i8, ptr %141, i32 -3
  %153 = load i8, ptr %152, align 1, !tbaa !46
  %154 = zext i8 %153 to i32
  %155 = add nuw nsw i32 %146, %154
  %156 = mul nuw nsw i32 %155, 10
  %157 = icmp eq i32 %128, 3
  br i1 %157, label %158, label %161

158:                                              ; preds = %151, %148
  %159 = phi i32 [ %150, %148 ], [ %156, %151 ]
  %160 = mul nuw nsw i32 %159, 10
  br label %168

161:                                              ; preds = %151
  %162 = getelementptr i8, ptr %141, i32 -4
  %163 = load i8, ptr %162, align 1, !tbaa !46
  %164 = zext i8 %163 to i32
  %165 = add nuw nsw i32 %156, %164
  %166 = mul nuw nsw i32 %165, 10
  %167 = icmp ugt i32 %128, 4
  br i1 %167, label %171, label %168

168:                                              ; preds = %161, %158
  %169 = phi i32 [ %160, %158 ], [ %166, %161 ]
  %170 = mul nuw nsw i32 %169, 10
  br label %178

171:                                              ; preds = %161
  %172 = getelementptr i8, ptr %141, i32 -5
  %173 = load i8, ptr %172, align 1, !tbaa !46
  %174 = zext i8 %173 to i32
  %175 = add nuw nsw i32 %166, %174
  %176 = mul nuw nsw i32 %175, 10
  %177 = icmp eq i32 %128, 5
  br i1 %177, label %178, label %182

178:                                              ; preds = %171, %168
  %179 = phi i32 [ %170, %168 ], [ %176, %171 ]
  %180 = tail call i32 @llvm.smin.i32(i32 %55, i32 0)
  %181 = add nsw i32 %129, %180
  br label %269

182:                                              ; preds = %171
  %183 = getelementptr i8, ptr %141, i32 -6
  %184 = load i8, ptr %183, align 1, !tbaa !46
  %185 = zext i8 %184 to i32
  %186 = add nuw nsw i32 %176, %185
  %187 = tail call i32 @llvm.smin.i32(i32 %55, i32 0)
  %188 = add nsw i32 %129, %187
  %189 = icmp ugt i32 %128, 6
  br i1 %189, label %190, label %269

190:                                              ; preds = %182
  %191 = getelementptr i8, ptr %141, i32 -7
  %192 = load i8, ptr %191, align 1, !tbaa !46
  %193 = icmp eq i32 %128, 7
  br i1 %193, label %222, label %194

194:                                              ; preds = %190
  %195 = add i32 %128, -8
  %196 = add i32 %128, -7
  %197 = and i32 %196, 3
  %198 = icmp ult i32 %195, 3
  br i1 %198, label %203, label %199

199:                                              ; preds = %194
  %200 = and i32 %196, -4
  br label %225

201:                                              ; preds = %225
  %202 = icmp eq i32 %197, 0
  br i1 %202, label %219, label %203

203:                                              ; preds = %201, %194
  %204 = phi i32 [ 0, %194 ], [ %252, %201 ]
  %205 = phi i32 [ 0, %194 ], [ %251, %201 ]
  %206 = icmp ne i32 %197, 0
  tail call void @llvm.assume(i1 %206)
  br label %207

207:                                              ; preds = %207, %203
  %208 = phi i32 [ %216, %207 ], [ %204, %203 ]
  %209 = phi i32 [ %215, %207 ], [ %205, %203 ]
  %210 = phi i32 [ %217, %207 ], [ 0, %203 ]
  %211 = getelementptr inbounds nuw i8, ptr %6, i32 %208
  %212 = load i8, ptr %211, align 1, !tbaa !46
  %213 = icmp ne i8 %212, 0
  %214 = zext i1 %213 to i32
  %215 = or i32 %209, %214
  %216 = add nuw i32 %208, 1
  %217 = add i32 %210, 1
  %218 = icmp eq i32 %217, %197
  br i1 %218, label %219, label %207, !llvm.loop !124

219:                                              ; preds = %207, %201
  %220 = phi i32 [ %251, %201 ], [ %215, %207 ]
  %221 = icmp eq i32 %220, 0
  br label %222

222:                                              ; preds = %219, %190
  %223 = phi i1 [ true, %190 ], [ %221, %219 ]
  %224 = icmp ugt i8 %192, 5
  br i1 %224, label %261, label %255

225:                                              ; preds = %225, %199
  %226 = phi i32 [ 0, %199 ], [ %252, %225 ]
  %227 = phi i32 [ 0, %199 ], [ %251, %225 ]
  %228 = phi i32 [ 0, %199 ], [ %253, %225 ]
  %229 = getelementptr inbounds nuw i8, ptr %6, i32 %226
  %230 = load i8, ptr %229, align 4, !tbaa !46
  %231 = icmp ne i8 %230, 0
  %232 = zext i1 %231 to i32
  %233 = or i32 %227, %232
  %234 = getelementptr inbounds nuw i8, ptr %6, i32 %226
  %235 = getelementptr inbounds nuw i8, ptr %234, i32 1
  %236 = load i8, ptr %235, align 1, !tbaa !46
  %237 = icmp ne i8 %236, 0
  %238 = zext i1 %237 to i32
  %239 = or i32 %233, %238
  %240 = getelementptr inbounds nuw i8, ptr %6, i32 %226
  %241 = getelementptr inbounds nuw i8, ptr %240, i32 2
  %242 = load i8, ptr %241, align 2, !tbaa !46
  %243 = icmp ne i8 %242, 0
  %244 = zext i1 %243 to i32
  %245 = or i32 %239, %244
  %246 = getelementptr inbounds nuw i8, ptr %6, i32 %226
  %247 = getelementptr inbounds nuw i8, ptr %246, i32 3
  %248 = load i8, ptr %247, align 1, !tbaa !46
  %249 = icmp ne i8 %248, 0
  %250 = zext i1 %249 to i32
  %251 = or i32 %245, %250
  %252 = add nuw i32 %226, 4
  %253 = add i32 %228, 4
  %254 = icmp eq i32 %253, %200
  br i1 %254, label %201, label %225, !llvm.loop !125

255:                                              ; preds = %222
  %256 = icmp eq i8 %192, 5
  br i1 %256, label %257, label %263

257:                                              ; preds = %255
  %258 = and i32 %185, 1
  %259 = icmp eq i32 %258, 0
  %260 = select i1 %223, i1 %259, i1 false
  br i1 %260, label %263, label %261

261:                                              ; preds = %257, %222
  %262 = add nuw nsw i32 %186, 1
  br label %263

263:                                              ; preds = %261, %257, %255
  %264 = phi i32 [ %262, %261 ], [ %186, %257 ], [ %186, %255 ]
  %265 = icmp eq i32 %264, 1000000
  %266 = add i32 %128, %187
  %267 = select i1 %265, i32 %266, i32 %188
  %268 = select i1 %265, i32 100000, i32 %264
  br label %269

269:                                              ; preds = %263, %182, %178
  %270 = phi i32 [ %267, %263 ], [ %188, %182 ], [ %181, %178 ]
  %271 = phi i32 [ %268, %263 ], [ %186, %182 ], [ %179, %178 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #28
  %272 = freeze i32 %271
  %273 = udiv i32 %272, 10
  %274 = mul i32 %273, 10
  %275 = sub i32 %272, %274
  %276 = trunc nuw nsw i32 %275 to i8
  %277 = or disjoint i8 %276, 48
  %278 = getelementptr inbounds nuw i8, ptr %7, i32 5
  store i8 %277, ptr %278, align 1, !tbaa !46
  %279 = urem i32 %273, 10
  %280 = trunc nuw nsw i32 %279 to i8
  %281 = or disjoint i8 %280, 48
  %282 = getelementptr inbounds nuw i8, ptr %7, i32 4
  store i8 %281, ptr %282, align 1, !tbaa !46
  %283 = udiv i32 %271, 100
  %284 = urem i32 %283, 10
  %285 = trunc nuw nsw i32 %284 to i8
  %286 = or disjoint i8 %285, 48
  %287 = getelementptr inbounds nuw i8, ptr %7, i32 3
  store i8 %286, ptr %287, align 1, !tbaa !46
  %288 = udiv i32 %271, 1000
  %289 = trunc nuw nsw i32 %288 to i16
  %290 = urem i16 %289, 10
  %291 = trunc nuw nsw i16 %290 to i8
  %292 = or disjoint i8 %291, 48
  %293 = getelementptr inbounds nuw i8, ptr %7, i32 2
  store i8 %292, ptr %293, align 1, !tbaa !46
  %294 = udiv i32 %271, 10000
  %295 = trunc nuw nsw i32 %294 to i16
  %296 = urem i16 %295, 10
  %297 = trunc nuw nsw i16 %296 to i8
  %298 = or disjoint i8 %297, 48
  %299 = getelementptr inbounds nuw i8, ptr %7, i32 1
  store i8 %298, ptr %299, align 1, !tbaa !46
  %300 = udiv i32 %271, 100000
  %301 = trunc nuw nsw i32 %300 to i16
  %302 = urem i16 %301, 10
  %303 = trunc nuw nsw i16 %302 to i8
  %304 = or disjoint i8 %303, 48
  store i8 %304, ptr %7, align 1, !tbaa !46
  %305 = icmp eq i32 %275, 0
  br i1 %305, label %306, label %317

306:                                              ; preds = %269
  %307 = icmp eq i32 %279, 0
  br i1 %307, label %308, label %317

308:                                              ; preds = %306
  %309 = icmp eq i32 %284, 0
  br i1 %309, label %310, label %317

310:                                              ; preds = %308
  %311 = icmp eq i16 %290, 0
  br i1 %311, label %312, label %317

312:                                              ; preds = %310
  %313 = icmp eq i16 %296, 0
  br i1 %313, label %314, label %317

314:                                              ; preds = %312
  %315 = add i32 %270, -6
  %316 = icmp ult i32 %315, -10
  br i1 %316, label %325, label %373

317:                                              ; preds = %312, %310, %308, %306, %269
  %318 = phi i1 [ false, %269 ], [ false, %306 ], [ false, %308 ], [ false, %310 ], [ true, %312 ]
  %319 = phi i1 [ false, %269 ], [ false, %306 ], [ false, %308 ], [ true, %310 ], [ false, %312 ]
  %320 = phi i1 [ false, %269 ], [ false, %306 ], [ true, %308 ], [ false, %310 ], [ false, %312 ]
  %321 = phi i1 [ false, %269 ], [ true, %306 ], [ false, %308 ], [ false, %310 ], [ false, %312 ]
  %322 = phi i32 [ 6, %269 ], [ 5, %306 ], [ 4, %308 ], [ 3, %310 ], [ 2, %312 ]
  %323 = add i32 %270, -6
  %324 = icmp ult i32 %323, -10
  br i1 %324, label %326, label %373

325:                                              ; preds = %314
  store i8 %304, ptr %14, align 1, !tbaa !46
  br label %343

326:                                              ; preds = %317
  store i8 %304, ptr %14, align 1, !tbaa !46
  %327 = getelementptr inbounds nuw i8, ptr %14, i32 1
  store i8 46, ptr %327, align 1, !tbaa !46
  %328 = add nuw nsw i32 %322, %15
  %329 = getelementptr inbounds nuw i8, ptr %5, i32 %15
  %330 = getelementptr inbounds nuw i8, ptr %329, i32 2
  store i8 %298, ptr %330, align 1, !tbaa !46
  br i1 %318, label %343, label %331

331:                                              ; preds = %326
  %332 = getelementptr inbounds nuw i8, ptr %5, i32 %15
  %333 = getelementptr inbounds nuw i8, ptr %332, i32 3
  store i8 %292, ptr %333, align 1, !tbaa !46
  br i1 %319, label %343, label %334

334:                                              ; preds = %331
  %335 = getelementptr inbounds nuw i8, ptr %5, i32 %15
  %336 = getelementptr inbounds nuw i8, ptr %335, i32 4
  store i8 %286, ptr %336, align 1, !tbaa !46
  br i1 %320, label %343, label %337

337:                                              ; preds = %334
  %338 = getelementptr inbounds nuw i8, ptr %5, i32 %15
  %339 = getelementptr inbounds nuw i8, ptr %338, i32 5
  store i8 %281, ptr %339, align 1, !tbaa !46
  br i1 %321, label %343, label %340

340:                                              ; preds = %337
  %341 = getelementptr inbounds nuw i8, ptr %5, i32 %15
  %342 = getelementptr inbounds nuw i8, ptr %341, i32 6
  store i8 %277, ptr %342, align 1, !tbaa !46
  br label %343

343:                                              ; preds = %326, %331, %334, %337, %340, %325
  %344 = phi i32 [ %15, %325 ], [ %328, %340 ], [ %328, %337 ], [ %328, %334 ], [ %328, %331 ], [ %328, %326 ]
  %345 = getelementptr inbounds nuw i8, ptr %5, i32 %344
  %346 = getelementptr inbounds nuw i8, ptr %345, i32 1
  store i8 101, ptr %346, align 1, !tbaa !46
  %347 = icmp slt i32 %270, 0
  %348 = select i1 %347, i8 45, i8 43
  %349 = add nuw nsw i32 %344, 3
  %350 = getelementptr i8, ptr %345, i32 2
  store i8 %348, ptr %350, align 1, !tbaa !46
  %351 = tail call i32 @llvm.abs.i32(i32 %270, i1 true)
  %352 = icmp samesign ugt i32 %351, 99
  br i1 %352, label %353, label %359

353:                                              ; preds = %343
  %354 = udiv i32 %351, 100
  %355 = trunc i32 %354 to i8
  %356 = add i8 %355, 48
  %357 = add nuw nsw i32 %344, 4
  %358 = getelementptr inbounds nuw i8, ptr %5, i32 %349
  store i8 %356, ptr %358, align 1, !tbaa !46
  br label %359

359:                                              ; preds = %353, %343
  %360 = phi i32 [ %357, %353 ], [ %349, %343 ]
  %361 = freeze i32 %351
  %362 = udiv i32 %361, 10
  %363 = urem i32 %362, 10
  %364 = trunc nuw nsw i32 %363 to i8
  %365 = or disjoint i8 %364, 48
  %366 = getelementptr inbounds nuw i8, ptr %5, i32 %360
  store i8 %365, ptr %366, align 1, !tbaa !46
  %367 = mul i32 %362, 10
  %368 = sub i32 %361, %367
  %369 = trunc nuw nsw i32 %368 to i8
  %370 = or disjoint i8 %369, 48
  %371 = add nsw i32 %360, 2
  %372 = getelementptr i8, ptr %366, i32 1
  store i8 %370, ptr %372, align 1, !tbaa !46
  br label %544

373:                                              ; preds = %317, %314
  %374 = phi i32 [ 1, %314 ], [ %322, %317 ]
  %375 = icmp slt i32 %270, 0
  br i1 %375, label %382, label %376

376:                                              ; preds = %373
  %377 = add nuw i32 %270, 1
  %378 = and i32 %377, 3
  %379 = icmp ult i32 %270, 3
  br i1 %379, label %447, label %380

380:                                              ; preds = %376
  %381 = and i32 %377, -4
  br label %469

382:                                              ; preds = %373
  store i8 48, ptr %14, align 1, !tbaa !46
  %383 = or disjoint i32 %15, 2
  %384 = getelementptr inbounds nuw i8, ptr %14, i32 1
  store i8 46, ptr %384, align 1, !tbaa !46
  %385 = icmp eq i32 %270, -1
  br i1 %385, label %421, label %386

386:                                              ; preds = %382
  %387 = add nuw nsw i32 %15, 1
  %388 = sub i32 %387, %270
  %389 = and i32 %270, 7
  %390 = icmp eq i32 %389, 7
  br i1 %390, label %399, label %391

391:                                              ; preds = %386, %391
  %392 = phi i32 [ %394, %391 ], [ %383, %386 ]
  %393 = phi i32 [ %396, %391 ], [ 0, %386 ]
  %394 = add nuw i32 %392, 1
  %395 = getelementptr inbounds nuw i8, ptr %5, i32 %392
  store i8 48, ptr %395, align 1, !tbaa !46
  %396 = add i32 %393, 1
  %397 = xor i32 %389, %396
  %398 = icmp eq i32 %397, 7
  br i1 %398, label %399, label %391, !llvm.loop !126

399:                                              ; preds = %391, %386
  %400 = phi i32 [ %383, %386 ], [ %394, %391 ]
  %401 = icmp ugt i32 %270, -9
  br i1 %401, label %421, label %402

402:                                              ; preds = %399, %402
  %403 = phi i32 [ %417, %402 ], [ %400, %399 ]
  %404 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  store i8 48, ptr %404, align 1, !tbaa !46
  %405 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %406 = getelementptr inbounds nuw i8, ptr %405, i32 1
  store i8 48, ptr %406, align 1, !tbaa !46
  %407 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %408 = getelementptr inbounds nuw i8, ptr %407, i32 2
  store i8 48, ptr %408, align 1, !tbaa !46
  %409 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %410 = getelementptr inbounds nuw i8, ptr %409, i32 3
  store i8 48, ptr %410, align 1, !tbaa !46
  %411 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %412 = getelementptr inbounds nuw i8, ptr %411, i32 4
  store i8 48, ptr %412, align 1, !tbaa !46
  %413 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %414 = getelementptr inbounds nuw i8, ptr %413, i32 5
  store i8 48, ptr %414, align 1, !tbaa !46
  %415 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %416 = getelementptr inbounds nuw i8, ptr %415, i32 6
  store i8 48, ptr %416, align 1, !tbaa !46
  %417 = add nuw i32 %403, 8
  %418 = getelementptr inbounds nuw i8, ptr %5, i32 %403
  %419 = getelementptr inbounds nuw i8, ptr %418, i32 7
  store i8 48, ptr %419, align 1, !tbaa !46
  %420 = icmp eq i32 %417, %388
  br i1 %420, label %421, label %402, !llvm.loop !127

421:                                              ; preds = %382, %402, %399
  %422 = phi i32 [ %383, %382 ], [ %388, %402 ], [ %388, %399 ]
  %423 = add nuw i32 %422, 1
  %424 = getelementptr inbounds nuw i8, ptr %5, i32 %422
  store i8 %304, ptr %424, align 1, !tbaa !46
  %425 = icmp eq i32 %374, 1
  br i1 %425, label %544, label %426

426:                                              ; preds = %421
  %427 = add nuw i32 %422, 2
  %428 = getelementptr inbounds nuw i8, ptr %5, i32 %423
  store i8 %298, ptr %428, align 1, !tbaa !46
  %429 = icmp eq i32 %374, 2
  br i1 %429, label %544, label %430

430:                                              ; preds = %426
  %431 = add nuw i32 %422, 3
  %432 = getelementptr inbounds nuw i8, ptr %5, i32 %427
  store i8 %292, ptr %432, align 1, !tbaa !46
  %433 = icmp eq i32 %374, 3
  br i1 %433, label %544, label %434

434:                                              ; preds = %430
  %435 = add nuw i32 %422, 4
  %436 = getelementptr inbounds nuw i8, ptr %5, i32 %431
  store i8 %286, ptr %436, align 1, !tbaa !46
  %437 = icmp eq i32 %374, 4
  br i1 %437, label %544, label %438

438:                                              ; preds = %434
  %439 = add nuw i32 %422, 5
  %440 = getelementptr inbounds nuw i8, ptr %5, i32 %435
  store i8 %281, ptr %440, align 1, !tbaa !46
  %441 = icmp eq i32 %374, 5
  br i1 %441, label %544, label %442

442:                                              ; preds = %438
  %443 = add nuw i32 %422, 6
  %444 = getelementptr inbounds nuw i8, ptr %5, i32 %439
  store i8 %277, ptr %444, align 1, !tbaa !46
  br label %544

445:                                              ; preds = %469
  %446 = icmp eq i32 %378, 0
  br i1 %446, label %462, label %447

447:                                              ; preds = %445, %376
  %448 = phi i32 [ 0, %376 ], [ %492, %445 ]
  %449 = phi i32 [ %15, %376 ], [ %490, %445 ]
  %450 = icmp ne i32 %378, 0
  tail call void @llvm.assume(i1 %450)
  br label %451

451:                                              ; preds = %451, %447
  %452 = phi i32 [ %459, %451 ], [ %448, %447 ]
  %453 = phi i32 [ %457, %451 ], [ %449, %447 ]
  %454 = phi i32 [ %460, %451 ], [ 0, %447 ]
  %455 = getelementptr inbounds nuw i8, ptr %7, i32 %452
  %456 = load i8, ptr %455, align 1, !tbaa !46
  %457 = add nuw i32 %453, 1
  %458 = getelementptr inbounds nuw i8, ptr %5, i32 %453
  store i8 %456, ptr %458, align 1, !tbaa !46
  %459 = add nuw i32 %452, 1
  %460 = add i32 %454, 1
  %461 = icmp eq i32 %460, %378
  br i1 %461, label %462, label %451, !llvm.loop !128

462:                                              ; preds = %451, %445
  %463 = phi i32 [ %484, %445 ], [ %453, %451 ]
  %464 = phi i32 [ %490, %445 ], [ %457, %451 ]
  %465 = add nuw nsw i32 %270, 1
  %466 = add nuw nsw i32 %374, %15
  %467 = add nuw nsw i32 %466, 1
  %468 = icmp samesign ugt i32 %374, %465
  br i1 %468, label %495, label %544

469:                                              ; preds = %469, %380
  %470 = phi i32 [ 0, %380 ], [ %492, %469 ]
  %471 = phi i32 [ %15, %380 ], [ %490, %469 ]
  %472 = phi i32 [ 0, %380 ], [ %493, %469 ]
  %473 = getelementptr inbounds nuw i8, ptr %7, i32 %470
  %474 = load i8, ptr %473, align 1, !tbaa !46
  %475 = getelementptr inbounds nuw i8, ptr %5, i32 %471
  store i8 %474, ptr %475, align 1, !tbaa !46
  %476 = getelementptr inbounds nuw i8, ptr %7, i32 %470
  %477 = getelementptr inbounds nuw i8, ptr %476, i32 1
  %478 = load i8, ptr %477, align 1, !tbaa !46
  %479 = getelementptr inbounds nuw i8, ptr %5, i32 %471
  %480 = getelementptr inbounds nuw i8, ptr %479, i32 1
  store i8 %478, ptr %480, align 1, !tbaa !46
  %481 = getelementptr inbounds nuw i8, ptr %7, i32 %470
  %482 = getelementptr inbounds nuw i8, ptr %481, i32 2
  %483 = load i8, ptr %482, align 1, !tbaa !46
  %484 = add nuw i32 %471, 3
  %485 = getelementptr inbounds nuw i8, ptr %5, i32 %471
  %486 = getelementptr inbounds nuw i8, ptr %485, i32 2
  store i8 %483, ptr %486, align 1, !tbaa !46
  %487 = getelementptr inbounds nuw i8, ptr %7, i32 %470
  %488 = getelementptr inbounds nuw i8, ptr %487, i32 3
  %489 = load i8, ptr %488, align 1, !tbaa !46
  %490 = add nuw i32 %471, 4
  %491 = getelementptr inbounds nuw i8, ptr %5, i32 %484
  store i8 %489, ptr %491, align 1, !tbaa !46
  %492 = add nuw i32 %470, 4
  %493 = add i32 %472, 4
  %494 = icmp eq i32 %493, %381
  br i1 %494, label %445, label %469, !llvm.loop !129

495:                                              ; preds = %462
  %496 = getelementptr inbounds nuw i8, ptr %5, i32 %464
  store i8 46, ptr %496, align 1, !tbaa !46
  %497 = add i32 %463, 2
  %498 = add nsw i32 %374, %15
  %499 = xor i32 %463, -1
  %500 = add i32 %498, %499
  %501 = add nsw i32 %498, -2
  %502 = sub i32 %501, %463
  %503 = and i32 %500, 3
  %504 = icmp eq i32 %503, 0
  br i1 %504, label %516, label %505

505:                                              ; preds = %495, %505
  %506 = phi i32 [ %513, %505 ], [ %497, %495 ]
  %507 = phi i32 [ %512, %505 ], [ %465, %495 ]
  %508 = phi i32 [ %514, %505 ], [ 0, %495 ]
  %509 = getelementptr inbounds nuw i8, ptr %7, i32 %507
  %510 = load i8, ptr %509, align 1, !tbaa !46
  %511 = getelementptr inbounds nuw i8, ptr %5, i32 %506
  store i8 %510, ptr %511, align 1, !tbaa !46
  %512 = add nuw nsw i32 %507, 1
  %513 = add i32 %506, 1
  %514 = add i32 %508, 1
  %515 = icmp eq i32 %514, %503
  br i1 %515, label %516, label %505, !llvm.loop !130

516:                                              ; preds = %505, %495
  %517 = phi i32 [ %497, %495 ], [ %513, %505 ]
  %518 = phi i32 [ %465, %495 ], [ %512, %505 ]
  %519 = icmp ult i32 %502, 3
  br i1 %519, label %544, label %520

520:                                              ; preds = %516, %520
  %521 = phi i32 [ %542, %520 ], [ %517, %516 ]
  %522 = phi i32 [ %541, %520 ], [ %518, %516 ]
  %523 = getelementptr inbounds nuw i8, ptr %7, i32 %522
  %524 = load i8, ptr %523, align 1, !tbaa !46
  %525 = getelementptr inbounds nuw i8, ptr %5, i32 %521
  store i8 %524, ptr %525, align 1, !tbaa !46
  %526 = getelementptr inbounds nuw i8, ptr %7, i32 %522
  %527 = getelementptr inbounds nuw i8, ptr %526, i32 1
  %528 = load i8, ptr %527, align 1, !tbaa !46
  %529 = getelementptr i8, ptr %5, i32 %521
  %530 = getelementptr i8, ptr %529, i32 1
  store i8 %528, ptr %530, align 1, !tbaa !46
  %531 = getelementptr inbounds nuw i8, ptr %7, i32 %522
  %532 = getelementptr inbounds nuw i8, ptr %531, i32 2
  %533 = load i8, ptr %532, align 1, !tbaa !46
  %534 = getelementptr i8, ptr %5, i32 %521
  %535 = getelementptr i8, ptr %534, i32 2
  store i8 %533, ptr %535, align 1, !tbaa !46
  %536 = add i32 %521, 3
  %537 = getelementptr inbounds nuw i8, ptr %7, i32 %522
  %538 = getelementptr inbounds nuw i8, ptr %537, i32 3
  %539 = load i8, ptr %538, align 1, !tbaa !46
  %540 = getelementptr inbounds nuw i8, ptr %5, i32 %536
  store i8 %539, ptr %540, align 1, !tbaa !46
  %541 = add nuw nsw i32 %522, 4
  %542 = add i32 %521, 4
  %543 = icmp eq i32 %536, %466
  br i1 %543, label %544, label %520, !llvm.loop !131

544:                                              ; preds = %516, %520, %421, %426, %430, %434, %438, %442, %462, %359
  %545 = phi i32 [ %371, %359 ], [ %443, %442 ], [ %464, %462 ], [ %423, %421 ], [ %427, %426 ], [ %431, %430 ], [ %435, %434 ], [ %439, %438 ], [ %467, %520 ], [ %467, %516 ]
  %546 = zext i32 %545 to i64
  %547 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef %0, ptr noundef nonnull %5, i64 noundef %546, ptr noundef null, i64 noundef 0, ptr noundef %3) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #28
  br label %548

548:                                              ; preds = %117, %544
  %549 = phi i32 [ %547, %544 ], [ 6, %117 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  br label %550

550:                                              ; preds = %21, %35, %548
  %551 = phi i32 [ %30, %21 ], [ %549, %548 ], [ %38, %35 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  br label %606

552:                                              ; preds = %4, %4, %4
  %553 = icmp ne ptr %0, null
  %554 = icmp ne ptr %3, null
  %555 = and i1 %553, %554
  br i1 %555, label %556, label %606

556:                                              ; preds = %552
  %557 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %558 = load i32, ptr %557, align 8, !tbaa !21
  %559 = icmp eq i32 %558, 0
  br i1 %559, label %560, label %606

560:                                              ; preds = %556
  %561 = tail call fastcc ptr @allocate(i64 noundef 1) #27
  %562 = icmp eq ptr %561, null
  br i1 %562, label %606, label %563

563:                                              ; preds = %560
  store i8 0, ptr %561, align 1, !tbaa !46
  %564 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %561, i32 noundef 0, i32 noundef 0, i32 noundef 1, i64 noundef 0, ptr noundef %3) #27
  %565 = icmp eq i32 %564, 0
  br i1 %565, label %606, label %566

566:                                              ; preds = %563
  tail call fastcc void @deallocate(ptr noundef nonnull %561) #27
  br label %606

567:                                              ; preds = %4
  %568 = icmp eq i64 %1, 0
  %569 = select i1 %568, ptr @.str.1, ptr @.str
  %570 = select i1 %568, i64 5, i64 4
  %571 = tail call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef %0, ptr noundef nonnull %569, i64 noundef %570, ptr noundef null, i64 noundef 0, ptr noundef %3) #27
  br label %606

572:                                              ; preds = %4
  %573 = add i32 %2, -3
  %574 = icmp ult i32 %573, -2
  br i1 %574, label %606, label %575

575:                                              ; preds = %572
  %576 = icmp eq i32 %2, 1
  %577 = icmp slt i64 %1, 0
  %578 = and i1 %577, %576
  %579 = icmp eq i32 %2, 2
  %580 = and i64 %1, 255
  %581 = sub i64 0, %1
  %582 = select i1 %578, i64 %581, i64 %1
  %583 = select i1 %579, i64 %580, i64 %582
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #28
  br label %584

584:                                              ; preds = %584, %575
  %585 = phi i64 [ %583, %575 ], [ %588, %584 ]
  %586 = phi i32 [ 20, %575 ], [ %593, %584 ]
  %587 = freeze i64 %585
  %588 = udiv i64 %587, 10
  %589 = mul i64 %588, 10
  %590 = sub i64 %587, %589
  %591 = trunc nuw nsw i64 %590 to i8
  %592 = or disjoint i8 %591, 48
  %593 = add i32 %586, -1
  %594 = getelementptr inbounds nuw i8, ptr %8, i32 %593
  store i8 %592, ptr %594, align 1, !tbaa !46
  %595 = icmp ult i64 %585, 10
  br i1 %595, label %596, label %584, !llvm.loop !132

596:                                              ; preds = %584
  br i1 %578, label %597, label %600

597:                                              ; preds = %596
  %598 = add i32 %586, -2
  %599 = getelementptr inbounds nuw i8, ptr %8, i32 %598
  store i8 45, ptr %599, align 1, !tbaa !46
  br label %600

600:                                              ; preds = %597, %596
  %601 = phi i32 [ %598, %597 ], [ %593, %596 ]
  %602 = getelementptr inbounds nuw i8, ptr %8, i32 %601
  %603 = sub i32 20, %601
  %604 = zext i32 %603 to i64
  %605 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef %0, ptr noundef nonnull %602, i64 noundef %604, ptr noundef null, i64 noundef 0, ptr noundef %3) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #28
  br label %606

606:                                              ; preds = %566, %563, %560, %556, %552, %572, %600, %567, %550
  %607 = phi i32 [ %551, %550 ], [ 1, %572 ], [ %571, %567 ], [ %605, %600 ], [ 0, %563 ], [ 6, %552 ], [ 5, %556 ], [ 3, %560 ], [ %564, %566 ]
  ret i32 %607
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_parse_f64(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #6 {
  %4 = alloca %struct.NbpBig, align 4
  %5 = alloca %struct.NbpBig, align 4
  %6 = alloca i64, align 8
  %7 = icmp eq ptr %0, null
  br i1 %7, label %519, label %8

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %10 = load i32, ptr %9, align 8, !tbaa !21
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %519

12:                                               ; preds = %8
  %13 = icmp sgt i64 %1, -1
  br i1 %13, label %39, label %14

14:                                               ; preds = %12
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %519, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %519, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %24 = load ptr, ptr %23, align 8, !tbaa !13
  %25 = icmp eq ptr %24, null
  br i1 %25, label %519, label %26

26:                                               ; preds = %22
  %27 = trunc i64 %1 to i32
  %28 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i32 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i32 8
  %30 = load i64, ptr %29, align 8, !tbaa !23
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %519, label %32

32:                                               ; preds = %26
  %33 = getelementptr inbounds nuw i8, ptr %28, i32 28
  %34 = load i32, ptr %33, align 4, !tbaa !26
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %36, label %519

36:                                               ; preds = %32
  %37 = load ptr, ptr %28, align 8, !tbaa !27
  %38 = getelementptr inbounds nuw i8, ptr %28, i32 16
  br label %58

39:                                               ; preds = %12
  %40 = icmp eq i64 %1, 0
  br i1 %40, label %519, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %43 = load i32, ptr %42, align 8, !tbaa !12
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %1, %44
  br i1 %45, label %519, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %48 = load ptr, ptr %47, align 4, !tbaa !11
  %49 = icmp eq ptr %48, null
  br i1 %49, label %519, label %50

50:                                               ; preds = %46
  %51 = trunc nuw i64 %1 to i32
  %52 = getelementptr %struct.NmsView, ptr %48, i32 %51
  %53 = getelementptr i8, ptr %52, i32 -8
  %54 = load ptr, ptr %53, align 4, !tbaa !28
  %55 = icmp eq ptr %54, null
  br i1 %55, label %519, label %56

56:                                               ; preds = %50
  %57 = getelementptr i8, ptr %52, i32 -4
  br label %58

58:                                               ; preds = %56, %36
  %59 = phi ptr [ %54, %56 ], [ %37, %36 ]
  %60 = phi ptr [ %57, %56 ], [ %38, %36 ]
  %61 = load i32, ptr %60, align 4, !tbaa !1
  %62 = icmp eq ptr %2, null
  br i1 %62, label %519, label %63

63:                                               ; preds = %58
  %64 = icmp eq ptr %59, null
  %65 = icmp ne i32 %61, 0
  %66 = and i1 %64, %65
  br i1 %66, label %519, label %67

67:                                               ; preds = %63
  %68 = icmp eq i32 %61, 0
  br i1 %68, label %80, label %69

69:                                               ; preds = %67, %73
  %70 = phi i32 [ %74, %73 ], [ 0, %67 ]
  %71 = getelementptr inbounds nuw i8, ptr %59, i32 %70
  %72 = load i8, ptr %71, align 1, !tbaa !46
  switch i8 %72, label %80 [
    i8 32, label %73
    i8 9, label %73
    i8 10, label %73
    i8 13, label %73
    i8 11, label %73
    i8 12, label %73
    i8 45, label %76
    i8 43, label %76
  ]

73:                                               ; preds = %69, %69, %69, %69, %69, %69
  %74 = add nuw i32 %70, 1
  %75 = icmp eq i32 %74, %61
  br i1 %75, label %80, label %69, !llvm.loop !133

76:                                               ; preds = %69, %69
  %77 = icmp eq i8 %72, 45
  %78 = select i1 %77, i64 -9223372036854775808, i64 0
  %79 = add nuw i32 %70, 1
  br label %80

80:                                               ; preds = %73, %69, %76, %67
  %81 = phi i64 [ %78, %76 ], [ 0, %67 ], [ 0, %69 ], [ 0, %73 ]
  %82 = phi i32 [ %79, %76 ], [ 0, %67 ], [ %61, %73 ], [ %70, %69 ]
  %83 = icmp ugt i32 %82, %61
  %84 = sub i32 %61, %82
  %85 = icmp ult i32 %84, 3
  %86 = or i1 %83, %85
  br i1 %86, label %229, label %87

87:                                               ; preds = %80
  %88 = getelementptr i8, ptr %59, i32 %82
  %89 = load i8, ptr %88, align 1, !tbaa !46
  %90 = add i8 %89, -65
  %91 = icmp ult i8 %90, 26
  %92 = add nuw nsw i8 %89, 32
  %93 = select i1 %91, i8 %92, i8 %89
  switch i8 %93, label %234 [
    i8 105, label %94
    i8 110, label %112
  ]

94:                                               ; preds = %87
  %95 = getelementptr i8, ptr %88, i32 1
  %96 = load i8, ptr %95, align 1, !tbaa !46
  %97 = add i8 %96, -65
  %98 = icmp ult i8 %97, 26
  %99 = add nuw nsw i8 %96, 32
  %100 = select i1 %98, i8 %99, i8 %96
  %101 = icmp eq i8 %100, 110
  br i1 %101, label %102, label %234

102:                                              ; preds = %94
  %103 = getelementptr i8, ptr %88, i32 2
  %104 = load i8, ptr %103, align 1, !tbaa !46
  %105 = add i8 %104, -65
  %106 = icmp ult i8 %105, 26
  %107 = add nuw nsw i8 %104, 32
  %108 = select i1 %106, i8 %107, i8 %104
  %109 = icmp eq i8 %108, 102
  br i1 %109, label %110, label %234

110:                                              ; preds = %102
  %111 = or disjoint i64 %81, 9218868437227405312
  br label %517

112:                                              ; preds = %87
  %113 = getelementptr i8, ptr %88, i32 1
  %114 = load i8, ptr %113, align 1, !tbaa !46
  %115 = add i8 %114, -65
  %116 = icmp ult i8 %115, 26
  %117 = add nuw nsw i8 %114, 32
  %118 = select i1 %116, i8 %117, i8 %114
  %119 = icmp eq i8 %118, 97
  br i1 %119, label %120, label %234

120:                                              ; preds = %112
  %121 = getelementptr i8, ptr %88, i32 2
  %122 = load i8, ptr %121, align 1, !tbaa !46
  %123 = add i8 %122, -65
  %124 = icmp ult i8 %123, 26
  %125 = add nuw nsw i8 %122, 32
  %126 = select i1 %124, i8 %125, i8 %122
  %127 = icmp eq i8 %126, 110
  br i1 %127, label %128, label %234

128:                                              ; preds = %120
  %129 = add i32 %82, 3
  %130 = icmp ult i32 %129, %61
  br i1 %130, label %131, label %225

131:                                              ; preds = %128
  %132 = getelementptr inbounds nuw i8, ptr %59, i32 %129
  %133 = load i8, ptr %132, align 1, !tbaa !46
  %134 = icmp eq i8 %133, 40
  br i1 %134, label %135, label %225

135:                                              ; preds = %131
  %136 = add i32 %82, 4
  %137 = icmp ult i32 %136, %61
  br i1 %137, label %138, label %156

138:                                              ; preds = %135, %153
  %139 = phi i32 [ %154, %153 ], [ %136, %135 ]
  %140 = getelementptr inbounds nuw i8, ptr %59, i32 %139
  %141 = load i8, ptr %140, align 1, !tbaa !46
  %142 = add i8 %141, -65
  %143 = icmp ult i8 %142, 26
  %144 = add nuw nsw i8 %141, 32
  %145 = select i1 %143, i8 %144, i8 %141
  %146 = add i8 %145, -97
  %147 = icmp ult i8 %146, 26
  br i1 %147, label %153, label %148

148:                                              ; preds = %138
  %149 = add i8 %145, -48
  %150 = icmp ult i8 %149, 10
  %151 = icmp eq i8 %145, 95
  %152 = or i1 %151, %150
  br i1 %152, label %153, label %156

153:                                              ; preds = %148, %138
  %154 = add i32 %139, 1
  %155 = icmp eq i32 %154, %61
  br i1 %155, label %225, label %138

156:                                              ; preds = %148, %135
  %157 = phi i32 [ %136, %135 ], [ %139, %148 ]
  %158 = icmp eq i32 %157, %61
  br i1 %158, label %225, label %159

159:                                              ; preds = %156
  %160 = getelementptr inbounds nuw i8, ptr %59, i32 %157
  %161 = load i8, ptr %160, align 1, !tbaa !46
  %162 = icmp eq i8 %161, 41
  br i1 %162, label %163, label %225

163:                                              ; preds = %159
  %164 = sub i32 %157, %136
  %165 = icmp ugt i32 %164, 1
  br i1 %165, label %166, label %181

166:                                              ; preds = %163
  %167 = getelementptr inbounds nuw i8, ptr %59, i32 %136
  %168 = load i8, ptr %167, align 1, !tbaa !46
  %169 = icmp eq i8 %168, 48
  br i1 %169, label %170, label %181

170:                                              ; preds = %166
  %171 = getelementptr i8, ptr %132, i32 2
  %172 = load i8, ptr %171, align 1, !tbaa !46
  %173 = add i8 %172, -65
  %174 = icmp ult i8 %173, 26
  %175 = add nuw nsw i8 %172, 32
  %176 = select i1 %174, i8 %175, i8 %172
  %177 = icmp eq i8 %176, 120
  %178 = add i32 %82, 6
  %179 = select i1 %177, i32 %178, i32 %136
  %180 = select i1 %177, i32 16, i32 8
  br label %181

181:                                              ; preds = %170, %166, %163
  %182 = phi i32 [ %136, %166 ], [ %136, %163 ], [ %179, %170 ]
  %183 = phi i32 [ 10, %166 ], [ 10, %163 ], [ %180, %170 ]
  %184 = icmp ult i32 %182, %157
  br i1 %184, label %185, label %225

185:                                              ; preds = %181
  %186 = zext nneg i32 %183 to i64
  br label %187

187:                                              ; preds = %212, %185
  %188 = phi i64 [ 0, %185 ], [ %219, %212 ]
  %189 = phi i32 [ %182, %185 ], [ %220, %212 ]
  %190 = getelementptr inbounds nuw i8, ptr %59, i32 %189
  %191 = load i8, ptr %190, align 1, !tbaa !46
  %192 = add i8 %191, -48
  %193 = icmp ult i8 %192, 10
  br i1 %193, label %194, label %197

194:                                              ; preds = %187
  %195 = zext nneg i8 %191 to i32
  %196 = add nsw i32 %195, -48
  br label %207

197:                                              ; preds = %187
  %198 = add i8 %191, -65
  %199 = icmp ult i8 %198, 26
  %200 = add nuw nsw i8 %191, 32
  %201 = select i1 %199, i8 %200, i8 %191
  %202 = zext nneg i8 %201 to i32
  %203 = add i8 %201, -97
  %204 = icmp ult i8 %203, 6
  %205 = add nsw i32 %202, -87
  %206 = select i1 %204, i32 %205, i32 -1
  br label %207

207:                                              ; preds = %197, %194
  %208 = phi i32 [ %196, %194 ], [ %206, %197 ]
  %209 = icmp sgt i32 %208, -1
  %210 = icmp ult i32 %208, %183
  %211 = and i1 %209, %210
  br i1 %211, label %212, label %222

212:                                              ; preds = %207
  %213 = zext nneg i32 %208 to i64
  %214 = xor i64 %213, -1
  %215 = udiv i64 %214, %186
  %216 = icmp ugt i64 %188, %215
  %217 = mul i64 %188, %186
  %218 = add i64 %217, %213
  %219 = select i1 %216, i64 -1, i64 %218
  %220 = add i32 %189, 1
  %221 = icmp eq i32 %220, %157
  br i1 %221, label %222, label %187, !llvm.loop !134

222:                                              ; preds = %212, %207
  %223 = phi i64 [ 0, %207 ], [ %219, %212 ]
  %224 = and i64 %223, 2251799813685247
  br label %225

225:                                              ; preds = %153, %222, %181, %159, %156, %131, %128
  %226 = phi i64 [ 0, %128 ], [ 0, %131 ], [ 0, %156 ], [ 0, %159 ], [ 0, %181 ], [ %224, %222 ], [ 0, %153 ]
  %227 = or disjoint i64 %81, %226
  %228 = or disjoint i64 %227, 9221120237041090560
  br label %517

229:                                              ; preds = %80
  %230 = icmp ugt i32 %84, 2
  br i1 %230, label %231, label %274

231:                                              ; preds = %229
  %232 = getelementptr inbounds nuw i8, ptr %59, i32 %82
  %233 = load i8, ptr %232, align 1, !tbaa !46
  br label %234

234:                                              ; preds = %231, %120, %112, %102, %94, %87
  %235 = phi i8 [ %233, %231 ], [ %89, %120 ], [ %89, %112 ], [ %89, %102 ], [ %89, %94 ], [ %89, %87 ]
  %236 = getelementptr inbounds nuw i8, ptr %59, i32 %82
  %237 = icmp eq i8 %235, 48
  br i1 %237, label %238, label %274

238:                                              ; preds = %234
  %239 = getelementptr i8, ptr %236, i32 1
  %240 = load i8, ptr %239, align 1, !tbaa !46
  %241 = add i8 %240, -65
  %242 = icmp ult i8 %241, 26
  %243 = add nuw nsw i8 %240, 32
  %244 = select i1 %242, i8 %243, i8 %240
  %245 = icmp eq i8 %244, 120
  br i1 %245, label %246, label %274

246:                                              ; preds = %238
  %247 = add i32 %82, 2
  %248 = getelementptr inbounds nuw i8, ptr %59, i32 %247
  %249 = load i8, ptr %248, align 1, !tbaa !46
  %250 = add i8 %249, -48
  %251 = icmp ult i8 %250, 10
  br i1 %251, label %273, label %252

252:                                              ; preds = %246
  %253 = add i8 %249, -65
  %254 = icmp ult i8 %253, 26
  %255 = select i1 %254, i8 -65, i8 -97
  %256 = add i8 %255, %249
  %257 = icmp ult i8 %256, 6
  br i1 %257, label %273, label %258

258:                                              ; preds = %252
  %259 = icmp ne i32 %84, 3
  %260 = icmp eq i8 %249, 46
  %261 = and i1 %259, %260
  br i1 %261, label %262, label %274

262:                                              ; preds = %258
  %263 = getelementptr i8, ptr %236, i32 3
  %264 = load i8, ptr %263, align 1, !tbaa !46
  %265 = add i8 %264, -48
  %266 = icmp ult i8 %265, 10
  br i1 %266, label %273, label %267

267:                                              ; preds = %262
  %268 = add i8 %264, -65
  %269 = icmp ult i8 %268, 26
  %270 = select i1 %269, i8 -65, i8 -97
  %271 = add i8 %270, %264
  %272 = icmp ult i8 %271, 6
  br i1 %272, label %273, label %274

273:                                              ; preds = %267, %262, %252, %246
  br label %274

274:                                              ; preds = %273, %267, %258, %238, %234, %229
  %275 = phi i32 [ 32, %273 ], [ 800, %229 ], [ 800, %267 ], [ 800, %258 ], [ 800, %238 ], [ 800, %234 ]
  %276 = phi i32 [ 112, %273 ], [ 101, %229 ], [ 101, %267 ], [ 101, %258 ], [ 101, %238 ], [ 101, %234 ]
  %277 = phi i1 [ true, %273 ], [ false, %229 ], [ false, %267 ], [ false, %258 ], [ false, %238 ], [ false, %234 ]
  %278 = phi i32 [ 16, %273 ], [ 10, %229 ], [ 10, %267 ], [ 10, %258 ], [ 10, %238 ], [ 10, %234 ]
  %279 = phi i32 [ %247, %273 ], [ %82, %229 ], [ %82, %267 ], [ %82, %258 ], [ %82, %238 ], [ %82, %234 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %4, i8 0, i32 516, i1 false)
  %280 = icmp ult i32 %279, %61
  br i1 %280, label %281, label %511

281:                                              ; preds = %274
  %282 = getelementptr inbounds nuw i8, ptr %4, i32 512
  %283 = zext nneg i32 %278 to i64
  br label %284

284:                                              ; preds = %363, %281
  %285 = phi i32 [ %279, %281 ], [ %371, %363 ]
  %286 = phi i64 [ 0, %281 ], [ %370, %363 ]
  %287 = phi i64 [ 0, %281 ], [ %369, %363 ]
  %288 = phi i32 [ 0, %281 ], [ %368, %363 ]
  %289 = phi i32 [ 0, %281 ], [ %367, %363 ]
  %290 = phi i32 [ 0, %281 ], [ %366, %363 ]
  %291 = phi i32 [ 0, %281 ], [ %365, %363 ]
  %292 = phi i32 [ 0, %281 ], [ %364, %363 ]
  %293 = getelementptr inbounds nuw i8, ptr %59, i32 %285
  %294 = load i8, ptr %293, align 1, !tbaa !46
  %295 = add i8 %294, -48
  %296 = icmp ult i8 %295, 10
  br i1 %296, label %297, label %300

297:                                              ; preds = %284
  %298 = zext nneg i8 %294 to i32
  %299 = add nsw i32 %298, -48
  br label %310

300:                                              ; preds = %284
  %301 = add i8 %294, -65
  %302 = icmp ult i8 %301, 26
  %303 = add nuw nsw i8 %294, 32
  %304 = select i1 %302, i8 %303, i8 %294
  %305 = zext nneg i8 %304 to i32
  %306 = add i8 %304, -97
  %307 = icmp ult i8 %306, 6
  %308 = add nsw i32 %305, -87
  %309 = select i1 %307, i32 %308, i32 -1
  br label %310

310:                                              ; preds = %300, %297
  %311 = phi i32 [ %299, %297 ], [ %309, %300 ]
  %312 = icmp sgt i32 %311, -1
  %313 = icmp ult i32 %311, %278
  %314 = and i1 %312, %313
  br i1 %314, label %315, label %359

315:                                              ; preds = %310
  %316 = zext nneg i32 %291 to i64
  %317 = add nsw i64 %287, %316
  %318 = icmp ne i32 %311, 0
  %319 = icmp ne i32 %289, 0
  %320 = select i1 %318, i1 true, i1 %319
  br i1 %320, label %321, label %363, !llvm.loop !135

321:                                              ; preds = %315
  %322 = icmp ult i32 %292, %275
  br i1 %322, label %323, label %355

323:                                              ; preds = %321
  %324 = zext nneg i32 %311 to i64
  %325 = load i32, ptr %282, align 4, !tbaa !136
  %326 = icmp eq i32 %325, 0
  br i1 %326, label %329, label %331

327:                                              ; preds = %331
  %328 = icmp eq i64 %340, 0
  br i1 %328, label %353, label %344

329:                                              ; preds = %323
  %330 = icmp eq i32 %311, 0
  br i1 %330, label %353, label %347

331:                                              ; preds = %323, %331
  %332 = phi i32 [ %341, %331 ], [ 0, %323 ]
  %333 = phi i64 [ %340, %331 ], [ %324, %323 ]
  %334 = getelementptr inbounds nuw i32, ptr %4, i32 %332
  %335 = load i32, ptr %334, align 4, !tbaa !1
  %336 = zext i32 %335 to i64
  %337 = mul nuw nsw i64 %336, %283
  %338 = add nuw nsw i64 %337, %333
  %339 = trunc i64 %338 to i32
  store i32 %339, ptr %334, align 4, !tbaa !1
  %340 = lshr i64 %338, 32
  %341 = add nuw i32 %332, 1
  %342 = load i32, ptr %282, align 4, !tbaa !136
  %343 = icmp ult i32 %341, %342
  br i1 %343, label %331, label %327, !llvm.loop !138

344:                                              ; preds = %327
  %345 = icmp eq i32 %342, 128
  br i1 %345, label %346, label %347

346:                                              ; preds = %344
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  br label %519

347:                                              ; preds = %344, %329
  %348 = phi i64 [ %340, %344 ], [ %324, %329 ]
  %349 = phi i32 [ %342, %344 ], [ 0, %329 ]
  %350 = trunc nuw nsw i64 %348 to i32
  %351 = add i32 %349, 1
  store i32 %351, ptr %282, align 4, !tbaa !136
  %352 = getelementptr inbounds nuw i32, ptr %4, i32 %349
  store i32 %350, ptr %352, align 4, !tbaa !1
  br label %353

353:                                              ; preds = %347, %329, %327
  %354 = add nuw nsw i32 %292, 1
  br label %363, !llvm.loop !135

355:                                              ; preds = %321
  %356 = add nsw i64 %286, 1
  %357 = zext i1 %318 to i32
  %358 = or i32 %288, %357
  br label %363, !llvm.loop !135

359:                                              ; preds = %310
  %360 = icmp ne i8 %294, 46
  %361 = icmp ne i32 %291, 0
  %362 = select i1 %360, i1 true, i1 %361
  br i1 %362, label %373, label %363, !llvm.loop !135

363:                                              ; preds = %359, %355, %353, %315
  %364 = phi i32 [ %292, %315 ], [ %354, %353 ], [ %292, %355 ], [ %292, %359 ]
  %365 = phi i32 [ %291, %315 ], [ %291, %353 ], [ %291, %355 ], [ 1, %359 ]
  %366 = phi i32 [ 1, %315 ], [ 1, %353 ], [ 1, %355 ], [ %290, %359 ]
  %367 = phi i32 [ 0, %315 ], [ 1, %353 ], [ 1, %355 ], [ %289, %359 ]
  %368 = phi i32 [ %288, %315 ], [ %288, %353 ], [ %358, %355 ], [ %288, %359 ]
  %369 = phi i64 [ %317, %315 ], [ %317, %353 ], [ %317, %355 ], [ %287, %359 ]
  %370 = phi i64 [ %286, %315 ], [ %286, %353 ], [ %356, %355 ], [ %286, %359 ]
  %371 = add i32 %285, 1
  %372 = icmp eq i32 %371, %61
  br i1 %372, label %374, label %284

373:                                              ; preds = %359
  br label %374, !llvm.loop !135

374:                                              ; preds = %363, %373
  %375 = phi i32 [ %292, %373 ], [ %364, %363 ]
  %376 = phi i32 [ %290, %373 ], [ %366, %363 ]
  %377 = phi i32 [ %289, %373 ], [ %367, %363 ]
  %378 = phi i32 [ %288, %373 ], [ %368, %363 ]
  %379 = phi i64 [ %287, %373 ], [ %369, %363 ]
  %380 = phi i64 [ %286, %373 ], [ %370, %363 ]
  %381 = phi i32 [ %285, %373 ], [ %61, %363 ]
  %382 = icmp eq i32 %376, 0
  br i1 %382, label %511, label %383

383:                                              ; preds = %374
  %384 = icmp ult i32 %381, %61
  br i1 %384, label %385, label %435

385:                                              ; preds = %383
  %386 = getelementptr inbounds nuw i8, ptr %59, i32 %381
  %387 = load i8, ptr %386, align 1, !tbaa !46
  %388 = add i8 %387, -65
  %389 = icmp ult i8 %388, 26
  %390 = add nuw nsw i8 %387, 32
  %391 = select i1 %389, i8 %390, i8 %387
  %392 = zext i8 %391 to i32
  %393 = icmp eq i32 %276, %392
  br i1 %393, label %394, label %435

394:                                              ; preds = %385
  %395 = add nuw i32 %381, 1
  %396 = icmp ult i32 %395, %61
  br i1 %396, label %397, label %403

397:                                              ; preds = %394
  %398 = getelementptr inbounds nuw i8, ptr %59, i32 %395
  %399 = load i8, ptr %398, align 1, !tbaa !46
  switch i8 %399, label %403 [
    i8 43, label %400
    i8 45, label %400
  ]

400:                                              ; preds = %397, %397
  %401 = icmp ne i8 %399, 45
  %402 = add nuw i32 %381, 2
  br label %403

403:                                              ; preds = %400, %397, %394
  %404 = phi i32 [ %402, %400 ], [ %395, %397 ], [ %395, %394 ]
  %405 = phi i1 [ %401, %400 ], [ true, %397 ], [ true, %394 ]
  %406 = icmp ult i32 %404, %61
  br i1 %406, label %407, label %435

407:                                              ; preds = %403
  %408 = getelementptr inbounds nuw i8, ptr %59, i32 %404
  %409 = load i8, ptr %408, align 1, !tbaa !46
  %410 = add i8 %409, -48
  %411 = icmp ult i8 %410, 10
  br i1 %411, label %412, label %435

412:                                              ; preds = %407, %427
  %413 = phi i32 [ %429, %427 ], [ %404, %407 ]
  %414 = phi i64 [ %428, %427 ], [ 0, %407 ]
  %415 = getelementptr inbounds nuw i8, ptr %59, i32 %413
  %416 = load i8, ptr %415, align 1, !tbaa !46
  %417 = add i8 %416, -48
  %418 = icmp ult i8 %417, 10
  br i1 %418, label %419, label %431

419:                                              ; preds = %412
  %420 = icmp slt i64 %414, 1099511627776
  br i1 %420, label %421, label %427

421:                                              ; preds = %419
  %422 = mul nsw i64 %414, 10
  %423 = and i8 %416, 15
  %424 = zext nneg i8 %423 to i64
  %425 = add nsw i64 %422, %424
  %426 = tail call i64 @llvm.smin.i64(i64 %425, i64 1099511627776)
  br label %427

427:                                              ; preds = %421, %419
  %428 = phi i64 [ %426, %421 ], [ %414, %419 ]
  %429 = add i32 %413, 1
  %430 = icmp eq i32 %429, %61
  br i1 %430, label %431, label %412, !llvm.loop !139

431:                                              ; preds = %427, %412
  %432 = phi i64 [ %428, %427 ], [ %414, %412 ]
  %433 = sub nsw i64 0, %432
  %434 = select i1 %405, i64 %432, i64 %433
  br label %435

435:                                              ; preds = %431, %407, %403, %385, %383
  %436 = phi i64 [ 0, %383 ], [ 0, %385 ], [ %434, %431 ], [ 0, %403 ], [ 0, %407 ]
  %437 = icmp eq i32 %377, 0
  br i1 %437, label %511, label %438

438:                                              ; preds = %435
  %439 = sub nsw i64 %380, %379
  %440 = select i1 %277, i64 2, i64 0
  %441 = shl i64 %439, %440
  %442 = add i64 %436, %441
  br i1 %277, label %443, label %453

443:                                              ; preds = %438
  %444 = load i32, ptr %282, align 4, !tbaa !136
  %445 = icmp eq i32 %444, 0
  br i1 %445, label %453, label %446

446:                                              ; preds = %443
  %447 = getelementptr i32, ptr %4, i32 %444
  %448 = getelementptr i8, ptr %447, i32 -4
  %449 = load i32, ptr %448, align 4, !tbaa !1
  %450 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %449, i1 false)
  %451 = shl i32 %444, 5
  %452 = sub i32 %451, %450
  br label %453

453:                                              ; preds = %446, %443, %438
  %454 = phi i64 [ 308, %438 ], [ 1023, %443 ], [ 1023, %446 ]
  %455 = phi i32 [ %375, %438 ], [ 0, %443 ], [ %452, %446 ]
  %456 = zext i32 %455 to i64
  %457 = add i64 %442, -1
  %458 = add i64 %457, %456
  %459 = icmp sgt i64 %458, %454
  br i1 %459, label %460, label %462

460:                                              ; preds = %453
  %461 = or disjoint i64 %81, 9218868437227405312
  br label %511

462:                                              ; preds = %453
  %463 = select i1 %277, i64 -1075, i64 -324
  %464 = icmp slt i64 %458, %463
  br i1 %464, label %511, label %465

465:                                              ; preds = %462
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  %466 = getelementptr inbounds nuw i8, ptr %5, i32 4
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(508) %466, i8 0, i32 508, i1 false)
  %467 = getelementptr inbounds nuw i8, ptr %5, i32 512
  store i32 1, ptr %467, align 4, !tbaa !136
  store i32 1, ptr %5, align 4, !tbaa !1
  %468 = icmp slt i64 %442, 0
  %469 = select i1 %468, ptr %5, ptr %4
  %470 = tail call i64 @llvm.abs.i64(i64 %442, i1 false)
  %471 = trunc i64 %470 to i32
  br i1 %277, label %476, label %472

472:                                              ; preds = %465
  %473 = icmp eq i32 %471, 0
  br i1 %473, label %507, label %474

474:                                              ; preds = %472
  %475 = select i1 %468, ptr %467, ptr %282
  br label %479

476:                                              ; preds = %465
  %477 = call fastcc i32 @nbp_shift(ptr noundef nonnull %469, i32 noundef %471) #27
  %478 = icmp eq i32 %477, 0
  br i1 %478, label %513, label %507

479:                                              ; preds = %504, %474
  %480 = phi i32 [ 0, %474 ], [ %505, %504 ]
  %481 = load i32, ptr %475, align 4, !tbaa !136
  %482 = icmp eq i32 %481, 0
  br i1 %482, label %504, label %485

483:                                              ; preds = %485
  %484 = icmp eq i64 %494, 0
  br i1 %484, label %504, label %498

485:                                              ; preds = %479, %485
  %486 = phi i32 [ %495, %485 ], [ 0, %479 ]
  %487 = phi i64 [ %494, %485 ], [ 0, %479 ]
  %488 = getelementptr inbounds nuw i32, ptr %469, i32 %486
  %489 = load i32, ptr %488, align 4, !tbaa !1
  %490 = zext i32 %489 to i64
  %491 = mul nuw nsw i64 %490, 10
  %492 = add nuw nsw i64 %491, %487
  %493 = trunc i64 %492 to i32
  store i32 %493, ptr %488, align 4, !tbaa !1
  %494 = lshr i64 %492, 32
  %495 = add nuw i32 %486, 1
  %496 = load i32, ptr %475, align 4, !tbaa !136
  %497 = icmp ult i32 %495, %496
  br i1 %497, label %485, label %483, !llvm.loop !138

498:                                              ; preds = %483
  %499 = icmp eq i32 %496, 128
  br i1 %499, label %513, label %500

500:                                              ; preds = %498
  %501 = trunc nuw nsw i64 %494 to i32
  %502 = add i32 %496, 1
  store i32 %502, ptr %475, align 4, !tbaa !136
  %503 = getelementptr inbounds nuw i32, ptr %469, i32 %496
  store i32 %501, ptr %503, align 4, !tbaa !1
  br label %504

504:                                              ; preds = %500, %483, %479
  %505 = add nuw i32 %480, 1
  %506 = icmp eq i32 %505, %471
  br i1 %506, label %507, label %479, !llvm.loop !140

507:                                              ; preds = %504, %476, %472
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  %508 = call fastcc i32 @nbp_rational(ptr noundef nonnull byval(%struct.NbpBig) align 4 %4, ptr noundef nonnull byval(%struct.NbpBig) align 4 %5, i32 noundef %378, ptr noundef %6) #27
  %509 = icmp eq i32 %508, 0
  br i1 %509, label %510, label %514

510:                                              ; preds = %507
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  br label %519

511:                                              ; preds = %462, %460, %435, %374, %274
  %512 = phi i64 [ %81, %462 ], [ 0, %374 ], [ %81, %435 ], [ %461, %460 ], [ 0, %274 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  br label %517

513:                                              ; preds = %498, %476
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  br label %519

514:                                              ; preds = %507
  %515 = load i64, ptr %6, align 8, !tbaa !45
  %516 = or i64 %515, %81
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  br label %517

517:                                              ; preds = %110, %225, %511, %514
  %518 = phi i64 [ %512, %511 ], [ %516, %514 ], [ %111, %110 ], [ %228, %225 ]
  store i64 %518, ptr %2, align 8, !tbaa !45
  br label %519

519:                                              ; preds = %17, %14, %32, %22, %41, %46, %39, %8, %26, %50, %3, %517, %58, %63, %510, %346, %513
  %520 = phi i32 [ 6, %513 ], [ 0, %517 ], [ 6, %58 ], [ 6, %63 ], [ 6, %510 ], [ 6, %346 ], [ 6, %17 ], [ 6, %14 ], [ 1, %32 ], [ 6, %22 ], [ 6, %41 ], [ 6, %46 ], [ 6, %39 ], [ 5, %8 ], [ 6, %26 ], [ 6, %50 ], [ 6, %3 ]
  ret i32 %520
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_parse_i64(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #11 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %106, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %7 = load i32, ptr %6, align 8, !tbaa !21
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %106

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %36, label %11

11:                                               ; preds = %9
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %106, label %14

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %16 = load i32, ptr %15, align 4, !tbaa !18
  %17 = zext i32 %16 to i64
  %18 = icmp samesign ugt i64 %12, %17
  br i1 %18, label %106, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %21 = load ptr, ptr %20, align 8, !tbaa !13
  %22 = icmp eq ptr %21, null
  br i1 %22, label %106, label %23

23:                                               ; preds = %19
  %24 = trunc i64 %1 to i32
  %25 = getelementptr inbounds nuw %struct.NmsSlot, ptr %21, i32 %24
  %26 = getelementptr inbounds nuw i8, ptr %25, i32 8
  %27 = load i64, ptr %26, align 8, !tbaa !23
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %106, label %29

29:                                               ; preds = %23
  %30 = getelementptr inbounds nuw i8, ptr %25, i32 28
  %31 = load i32, ptr %30, align 4, !tbaa !26
  %32 = icmp eq i32 %31, 1
  br i1 %32, label %33, label %106

33:                                               ; preds = %29
  %34 = load ptr, ptr %25, align 8, !tbaa !27
  %35 = getelementptr inbounds nuw i8, ptr %25, i32 16
  br label %55

36:                                               ; preds = %9
  %37 = icmp eq i64 %1, 0
  br i1 %37, label %106, label %38

38:                                               ; preds = %36
  %39 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %40 = load i32, ptr %39, align 8, !tbaa !12
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %1, %41
  br i1 %42, label %106, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %45 = load ptr, ptr %44, align 4, !tbaa !11
  %46 = icmp eq ptr %45, null
  br i1 %46, label %106, label %47

47:                                               ; preds = %43
  %48 = trunc nuw i64 %1 to i32
  %49 = getelementptr %struct.NmsView, ptr %45, i32 %48
  %50 = getelementptr i8, ptr %49, i32 -8
  %51 = load ptr, ptr %50, align 4, !tbaa !28
  %52 = icmp eq ptr %51, null
  br i1 %52, label %106, label %53

53:                                               ; preds = %47
  %54 = getelementptr i8, ptr %49, i32 -4
  br label %55

55:                                               ; preds = %53, %33
  %56 = phi ptr [ %51, %53 ], [ %34, %33 ]
  %57 = phi ptr [ %54, %53 ], [ %35, %33 ]
  %58 = load i32, ptr %57, align 4, !tbaa !1
  %59 = icmp eq ptr %2, null
  br i1 %59, label %106, label %60

60:                                               ; preds = %55
  %61 = icmp eq i32 %58, 0
  br i1 %61, label %69, label %62

62:                                               ; preds = %60, %66
  %63 = phi i32 [ %67, %66 ], [ 0, %60 ]
  %64 = getelementptr inbounds nuw i8, ptr %56, i32 %63
  %65 = load i8, ptr %64, align 1, !tbaa !46
  switch i8 %65, label %69 [
    i8 32, label %66
    i8 13, label %66
    i8 12, label %66
    i8 11, label %66
    i8 10, label %66
    i8 9, label %66
  ]

66:                                               ; preds = %62, %62, %62, %62, %62, %62
  %67 = add nuw i32 %63, 1
  %68 = icmp eq i32 %67, %58
  br i1 %68, label %79, label %62

69:                                               ; preds = %62, %60
  %70 = phi i32 [ 0, %60 ], [ %63, %62 ]
  %71 = icmp ult i32 %70, %58
  br i1 %71, label %72, label %79

72:                                               ; preds = %69
  %73 = getelementptr inbounds nuw i8, ptr %56, i32 %70
  %74 = load i8, ptr %73, align 1, !tbaa !46
  switch i8 %74, label %79 [
    i8 45, label %75
    i8 43, label %75
  ]

75:                                               ; preds = %72, %72
  %76 = icmp ne i8 %74, 45
  %77 = add nuw i32 %70, 1
  %78 = select i1 %76, i64 9223372036854775807, i64 -9223372036854775808
  br label %79

79:                                               ; preds = %66, %75, %69, %72
  %80 = phi i32 [ %77, %75 ], [ %70, %69 ], [ %70, %72 ], [ %58, %66 ]
  %81 = phi i1 [ %76, %75 ], [ true, %69 ], [ true, %72 ], [ true, %66 ]
  %82 = phi i64 [ %78, %75 ], [ 9223372036854775807, %69 ], [ 9223372036854775807, %72 ], [ 9223372036854775807, %66 ]
  %83 = tail call i32 @llvm.umax.i32(i32 %80, i32 %58)
  br label %84

84:                                               ; preds = %93, %79
  %85 = phi i32 [ %80, %79 ], [ %94, %93 ]
  %86 = phi i64 [ 0, %79 ], [ %101, %93 ]
  %87 = icmp eq i32 %85, %83
  br i1 %87, label %102, label %88

88:                                               ; preds = %84
  %89 = getelementptr inbounds nuw i8, ptr %56, i32 %85
  %90 = load i8, ptr %89, align 1, !tbaa !46
  %91 = add i8 %90, -58
  %92 = icmp ult i8 %91, -10
  br i1 %92, label %102, label %93

93:                                               ; preds = %88
  %94 = add i32 %85, 1
  %95 = and i8 %90, 15
  %96 = zext nneg i8 %95 to i64
  %97 = sub nuw i64 %82, %96
  %98 = udiv i64 %97, 10
  %99 = icmp ugt i64 %86, %98
  %100 = mul nuw nsw i64 %86, 10
  %101 = add nuw i64 %100, %96
  br i1 %99, label %102, label %84

102:                                              ; preds = %93, %88, %84
  %103 = phi i64 [ %86, %84 ], [ %86, %88 ], [ %82, %93 ]
  %104 = sub i64 0, %103
  %105 = select i1 %81, i64 %103, i64 %104
  store i64 %105, ptr %2, align 8, !tbaa !45
  br label %106

106:                                              ; preds = %14, %11, %29, %19, %38, %43, %36, %5, %23, %47, %3, %55, %102
  %107 = phi i32 [ 6, %55 ], [ 0, %102 ], [ 6, %14 ], [ 6, %11 ], [ 1, %29 ], [ 6, %19 ], [ 6, %38 ], [ 6, %43 ], [ 6, %36 ], [ 5, %5 ], [ 6, %23 ], [ 6, %47 ], [ 6, %3 ]
  ret i32 %107
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_case_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  store i64 0, ptr %5, align 8, !tbaa !45
  %6 = icmp ne ptr %3, null
  %7 = icmp ult i32 %2, 2
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %93

11:                                               ; preds = %4
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %13 = load i32, ptr %12, align 8, !tbaa !21
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %93

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %42, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %93, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %22 = load i32, ptr %21, align 4, !tbaa !18
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %93, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %27 = load ptr, ptr %26, align 8, !tbaa !13
  %28 = icmp eq ptr %27, null
  br i1 %28, label %93, label %29

29:                                               ; preds = %25
  %30 = trunc i64 %1 to i32
  %31 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i32 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i32 8
  %33 = load i64, ptr %32, align 8, !tbaa !23
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %93, label %35

35:                                               ; preds = %29
  %36 = getelementptr inbounds nuw i8, ptr %31, i32 28
  %37 = load i32, ptr %36, align 4, !tbaa !26
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %93

39:                                               ; preds = %35
  %40 = load ptr, ptr %31, align 8, !tbaa !27
  %41 = getelementptr inbounds nuw i8, ptr %31, i32 16
  br label %61

42:                                               ; preds = %15
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %93, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %46 = load i32, ptr %45, align 8, !tbaa !12
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %93, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %51 = load ptr, ptr %50, align 4, !tbaa !11
  %52 = icmp eq ptr %51, null
  br i1 %52, label %93, label %53

53:                                               ; preds = %49
  %54 = trunc nuw i64 %1 to i32
  %55 = getelementptr %struct.NmsView, ptr %51, i32 %54
  %56 = getelementptr i8, ptr %55, i32 -8
  %57 = load ptr, ptr %56, align 4, !tbaa !28
  %58 = icmp eq ptr %57, null
  br i1 %58, label %93, label %59

59:                                               ; preds = %53
  %60 = getelementptr i8, ptr %55, i32 -4
  br label %61

61:                                               ; preds = %39, %59
  %62 = phi ptr [ %57, %59 ], [ %40, %39 ]
  %63 = phi ptr [ %60, %59 ], [ %41, %39 ]
  %64 = load i32, ptr %63, align 4, !tbaa !1
  %65 = zext i32 %64 to i64
  %66 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %62, i64 noundef %65, ptr noundef null, i64 noundef 0, ptr noundef nonnull %5) #27
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %68, label %93

68:                                               ; preds = %61
  %69 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %70 = load ptr, ptr %69, align 8, !tbaa !13
  %71 = load i64, ptr %5, align 8, !tbaa !45
  %72 = trunc i64 %71 to i32
  %73 = getelementptr inbounds nuw %struct.NmsSlot, ptr %70, i32 %72
  %74 = getelementptr inbounds nuw i8, ptr %73, i32 16
  %75 = load i32, ptr %74, align 8, !tbaa !38
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %96, label %77

77:                                               ; preds = %68
  %78 = icmp eq i32 %2, 0
  %79 = select i1 %78, i8 -65, i8 -97
  %80 = select i1 %78, i8 32, i8 -32
  br label %81

81:                                               ; preds = %77, %81
  %82 = phi i32 [ 0, %77 ], [ %90, %81 ]
  %83 = load ptr, ptr %73, align 8, !tbaa !27
  %84 = getelementptr inbounds nuw i8, ptr %83, i32 %82
  %85 = load i8, ptr %84, align 1, !tbaa !46
  %86 = add i8 %85, %79
  %87 = icmp ult i8 %86, 26
  %88 = select i1 %87, i8 %80, i8 0
  %89 = add i8 %85, %88
  store i8 %89, ptr %84, align 1, !tbaa !46
  %90 = add nuw i32 %82, 1
  %91 = load i32, ptr %74, align 8, !tbaa !38
  %92 = icmp ult i32 %90, %91
  br i1 %92, label %81, label %96, !llvm.loop !141

93:                                               ; preds = %61, %20, %17, %35, %25, %44, %49, %42, %11, %29, %53, %4
  %94 = phi i32 [ %66, %61 ], [ 6, %20 ], [ 6, %17 ], [ 1, %35 ], [ 6, %25 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %11 ], [ 6, %29 ], [ 6, %53 ], [ 6, %4 ]
  %95 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #27
  br label %102

96:                                               ; preds = %81, %68
  %97 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %1) #27
  %98 = icmp eq i32 %97, 0
  br i1 %98, label %101, label %99

99:                                               ; preds = %96
  %100 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %71) #27
  br label %102

101:                                              ; preds = %96
  store i64 %71, ptr %3, align 8, !tbaa !45
  br label %102

102:                                              ; preds = %93, %101, %99
  %103 = phi i32 [ 0, %101 ], [ %97, %99 ], [ %94, %93 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  ret i32 %103
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_trim_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #4 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %55, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %7 = load i32, ptr %6, align 8, !tbaa !21
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %55

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %36, label %11

11:                                               ; preds = %9
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %55, label %14

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %16 = load i32, ptr %15, align 4, !tbaa !18
  %17 = zext i32 %16 to i64
  %18 = icmp samesign ugt i64 %12, %17
  br i1 %18, label %55, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %21 = load ptr, ptr %20, align 8, !tbaa !13
  %22 = icmp eq ptr %21, null
  br i1 %22, label %55, label %23

23:                                               ; preds = %19
  %24 = trunc i64 %1 to i32
  %25 = getelementptr inbounds nuw %struct.NmsSlot, ptr %21, i32 %24
  %26 = getelementptr inbounds nuw i8, ptr %25, i32 8
  %27 = load i64, ptr %26, align 8, !tbaa !23
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %55, label %29

29:                                               ; preds = %23
  %30 = getelementptr inbounds nuw i8, ptr %25, i32 28
  %31 = load i32, ptr %30, align 4, !tbaa !26
  %32 = icmp eq i32 %31, 1
  br i1 %32, label %33, label %55

33:                                               ; preds = %29
  %34 = load ptr, ptr %25, align 8, !tbaa !27
  %35 = getelementptr inbounds nuw i8, ptr %25, i32 16
  br label %58

36:                                               ; preds = %9
  %37 = icmp eq i64 %1, 0
  br i1 %37, label %55, label %38

38:                                               ; preds = %36
  %39 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %40 = load i32, ptr %39, align 8, !tbaa !12
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %1, %41
  br i1 %42, label %55, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %45 = load ptr, ptr %44, align 4, !tbaa !11
  %46 = icmp eq ptr %45, null
  br i1 %46, label %55, label %47

47:                                               ; preds = %43
  %48 = trunc nuw i64 %1 to i32
  %49 = getelementptr %struct.NmsView, ptr %45, i32 %48
  %50 = getelementptr i8, ptr %49, i32 -8
  %51 = load ptr, ptr %50, align 4, !tbaa !28
  %52 = icmp eq ptr %51, null
  br i1 %52, label %55, label %53

53:                                               ; preds = %47
  %54 = getelementptr i8, ptr %49, i32 -4
  br label %58

55:                                               ; preds = %3, %47, %23, %5, %36, %43, %38, %19, %29, %11, %14
  %56 = phi i32 [ 6, %14 ], [ 6, %11 ], [ 1, %29 ], [ 6, %19 ], [ 6, %38 ], [ 6, %43 ], [ 6, %36 ], [ 5, %5 ], [ 6, %23 ], [ 6, %47 ], [ 6, %3 ]
  %57 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %1) #27
  br label %85

58:                                               ; preds = %53, %33
  %59 = phi ptr [ %51, %53 ], [ %34, %33 ]
  %60 = phi ptr [ %54, %53 ], [ %35, %33 ]
  %61 = load i32, ptr %60, align 4, !tbaa !1
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %80, label %63

63:                                               ; preds = %58, %67
  %64 = phi i32 [ %68, %67 ], [ 0, %58 ]
  %65 = getelementptr inbounds nuw i8, ptr %59, i32 %64
  %66 = load i8, ptr %65, align 1, !tbaa !46
  switch i8 %66, label %70 [
    i8 32, label %67
    i8 10, label %67
    i8 9, label %67
    i8 13, label %67
  ]

67:                                               ; preds = %63, %63, %63, %63
  %68 = add nuw i32 %64, 1
  %69 = icmp eq i32 %68, %61
  br i1 %69, label %80, label %63, !llvm.loop !142

70:                                               ; preds = %63
  %71 = icmp ugt i32 %61, %64
  br i1 %71, label %72, label %80

72:                                               ; preds = %70, %77
  %73 = phi i32 [ %78, %77 ], [ %61, %70 ]
  %74 = getelementptr i8, ptr %59, i32 %73
  %75 = getelementptr i8, ptr %74, i32 -1
  %76 = load i8, ptr %75, align 1, !tbaa !46
  switch i8 %76, label %80 [
    i8 32, label %77
    i8 10, label %77
    i8 9, label %77
    i8 13, label %77
  ]

77:                                               ; preds = %72, %72, %72, %72
  %78 = add i32 %73, -1
  %79 = icmp ugt i32 %78, %64
  br i1 %79, label %72, label %80, !llvm.loop !143

80:                                               ; preds = %67, %77, %72, %58, %70
  %81 = phi i32 [ %64, %70 ], [ %64, %77 ], [ 0, %58 ], [ %64, %72 ], [ %61, %67 ]
  %82 = phi i32 [ %61, %70 ], [ %64, %77 ], [ 0, %58 ], [ %73, %72 ], [ %61, %67 ]
  %83 = sub i32 %82, %81
  %84 = tail call i32 @nms_substr_owned(ptr noundef nonnull %0, i64 noundef %1, i32 noundef %81, i32 noundef %83, ptr noundef %2) #27
  br label %85

85:                                               ; preds = %80, %55
  %86 = phi i32 [ %56, %55 ], [ %84, %80 ]
  ret i32 %86
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_substr_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #4 {
  %6 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  store i64 0, ptr %6, align 8, !tbaa !45
  %7 = icmp eq ptr %0, null
  br i1 %7, label %62, label %8

8:                                                ; preds = %5
  %9 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %10 = load i32, ptr %9, align 8, !tbaa !21
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %62

12:                                               ; preds = %8
  %13 = icmp sgt i64 %1, -1
  br i1 %13, label %39, label %14

14:                                               ; preds = %12
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %62, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %62, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %24 = load ptr, ptr %23, align 8, !tbaa !13
  %25 = icmp eq ptr %24, null
  br i1 %25, label %62, label %26

26:                                               ; preds = %22
  %27 = trunc i64 %1 to i32
  %28 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i32 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i32 8
  %30 = load i64, ptr %29, align 8, !tbaa !23
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %62, label %32

32:                                               ; preds = %26
  %33 = getelementptr inbounds nuw i8, ptr %28, i32 28
  %34 = load i32, ptr %33, align 4, !tbaa !26
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %36, label %62

36:                                               ; preds = %32
  %37 = load ptr, ptr %28, align 8, !tbaa !27
  %38 = getelementptr inbounds nuw i8, ptr %28, i32 16
  br label %58

39:                                               ; preds = %12
  %40 = icmp eq i64 %1, 0
  br i1 %40, label %62, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %43 = load i32, ptr %42, align 8, !tbaa !12
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %1, %44
  br i1 %45, label %62, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %48 = load ptr, ptr %47, align 4, !tbaa !11
  %49 = icmp eq ptr %48, null
  br i1 %49, label %62, label %50

50:                                               ; preds = %46
  %51 = trunc nuw i64 %1 to i32
  %52 = getelementptr %struct.NmsView, ptr %48, i32 %51
  %53 = getelementptr i8, ptr %52, i32 -8
  %54 = load ptr, ptr %53, align 4, !tbaa !28
  %55 = icmp eq ptr %54, null
  br i1 %55, label %62, label %56

56:                                               ; preds = %50
  %57 = getelementptr i8, ptr %52, i32 -4
  br label %58

58:                                               ; preds = %56, %36
  %59 = phi ptr [ %54, %56 ], [ %37, %36 ]
  %60 = phi ptr [ %57, %56 ], [ %38, %36 ]
  %61 = icmp eq ptr %4, null
  br i1 %61, label %62, label %65

62:                                               ; preds = %58, %5, %50, %26, %8, %39, %46, %41, %22, %32, %14, %17
  %63 = phi i32 [ 6, %58 ], [ 6, %17 ], [ 6, %14 ], [ 1, %32 ], [ 6, %22 ], [ 6, %41 ], [ 6, %46 ], [ 6, %39 ], [ 5, %8 ], [ 6, %26 ], [ 6, %50 ], [ 6, %5 ]
  %64 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %1) #27
  br label %85

65:                                               ; preds = %58
  %66 = load i32, ptr %60, align 4, !tbaa !1
  %67 = icmp ult i32 %2, %66
  %68 = select i1 %67, i32 %2, i32 0
  %69 = sub nuw i32 %66, %2
  %70 = tail call i32 @llvm.umin.i32(i32 %3, i32 %69)
  %71 = select i1 %67, i32 %70, i32 0
  %72 = icmp eq i32 %71, 0
  %73 = getelementptr inbounds nuw i8, ptr %59, i32 %68
  %74 = select i1 %72, ptr null, ptr %73
  %75 = zext i32 %71 to i64
  %76 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %74, i64 noundef %75, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #27
  %77 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %1) #27
  %78 = icmp eq i32 %76, 0
  br i1 %78, label %79, label %85

79:                                               ; preds = %65
  %80 = icmp eq i32 %77, 0
  %81 = load i64, ptr %6, align 8, !tbaa !45
  br i1 %80, label %84, label %82

82:                                               ; preds = %79
  %83 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %81) #27
  br label %85

84:                                               ; preds = %79
  store i64 %81, ptr %4, align 8, !tbaa !45
  br label %85

85:                                               ; preds = %62, %65, %84, %82
  %86 = phi i32 [ 0, %84 ], [ %77, %82 ], [ %76, %65 ], [ %63, %62 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  ret i32 %86
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_concat_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  store i64 0, ptr %5, align 8, !tbaa !45
  %6 = icmp eq ptr %0, null
  br i1 %6, label %115, label %7

7:                                                ; preds = %4
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %9 = load i32, ptr %8, align 8, !tbaa !21
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %115

11:                                               ; preds = %7
  %12 = icmp sgt i64 %1, -1
  br i1 %12, label %38, label %13

13:                                               ; preds = %11
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %115, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %18 = load i32, ptr %17, align 4, !tbaa !18
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  br i1 %20, label %115, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %23 = load ptr, ptr %22, align 8, !tbaa !13
  %24 = icmp eq ptr %23, null
  br i1 %24, label %115, label %25

25:                                               ; preds = %21
  %26 = trunc i64 %1 to i32
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i32 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i32 8
  %29 = load i64, ptr %28, align 8, !tbaa !23
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %115, label %31

31:                                               ; preds = %25
  %32 = getelementptr inbounds nuw i8, ptr %27, i32 28
  %33 = load i32, ptr %32, align 4, !tbaa !26
  %34 = icmp eq i32 %33, 1
  br i1 %34, label %35, label %115

35:                                               ; preds = %31
  %36 = load ptr, ptr %27, align 8, !tbaa !27
  %37 = getelementptr inbounds nuw i8, ptr %27, i32 16
  br label %57

38:                                               ; preds = %11
  %39 = icmp eq i64 %1, 0
  br i1 %39, label %115, label %40

40:                                               ; preds = %38
  %41 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %42 = load i32, ptr %41, align 8, !tbaa !12
  %43 = zext i32 %42 to i64
  %44 = icmp samesign ugt i64 %1, %43
  br i1 %44, label %115, label %45

45:                                               ; preds = %40
  %46 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %47 = load ptr, ptr %46, align 4, !tbaa !11
  %48 = icmp eq ptr %47, null
  br i1 %48, label %115, label %49

49:                                               ; preds = %45
  %50 = trunc nuw i64 %1 to i32
  %51 = getelementptr %struct.NmsView, ptr %47, i32 %50
  %52 = getelementptr i8, ptr %51, i32 -8
  %53 = load ptr, ptr %52, align 4, !tbaa !28
  %54 = icmp eq ptr %53, null
  br i1 %54, label %115, label %55

55:                                               ; preds = %49
  %56 = getelementptr i8, ptr %51, i32 -4
  br label %57

57:                                               ; preds = %55, %35
  %58 = phi ptr [ %53, %55 ], [ %36, %35 ]
  %59 = phi ptr [ %56, %55 ], [ %37, %35 ]
  %60 = load i32, ptr %59, align 4, !tbaa !1
  %61 = icmp sgt i64 %2, -1
  br i1 %61, label %87, label %62

62:                                               ; preds = %57
  %63 = and i64 %2, 9223372036854775807
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %115, label %65

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %67 = load i32, ptr %66, align 4, !tbaa !18
  %68 = zext i32 %67 to i64
  %69 = icmp samesign ugt i64 %63, %68
  br i1 %69, label %115, label %70

70:                                               ; preds = %65
  %71 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %72 = load ptr, ptr %71, align 8, !tbaa !13
  %73 = icmp eq ptr %72, null
  br i1 %73, label %115, label %74

74:                                               ; preds = %70
  %75 = trunc i64 %2 to i32
  %76 = getelementptr inbounds nuw %struct.NmsSlot, ptr %72, i32 %75
  %77 = getelementptr inbounds nuw i8, ptr %76, i32 8
  %78 = load i64, ptr %77, align 8, !tbaa !23
  %79 = icmp eq i64 %78, 0
  br i1 %79, label %115, label %80

80:                                               ; preds = %74
  %81 = getelementptr inbounds nuw i8, ptr %76, i32 28
  %82 = load i32, ptr %81, align 4, !tbaa !26
  %83 = icmp eq i32 %82, 1
  br i1 %83, label %84, label %115

84:                                               ; preds = %80
  %85 = load ptr, ptr %76, align 8, !tbaa !27
  %86 = getelementptr inbounds nuw i8, ptr %76, i32 16
  br label %106

87:                                               ; preds = %57
  %88 = icmp eq i64 %2, 0
  br i1 %88, label %115, label %89

89:                                               ; preds = %87
  %90 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %91 = load i32, ptr %90, align 8, !tbaa !12
  %92 = zext i32 %91 to i64
  %93 = icmp samesign ugt i64 %2, %92
  br i1 %93, label %115, label %94

94:                                               ; preds = %89
  %95 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %96 = load ptr, ptr %95, align 4, !tbaa !11
  %97 = icmp eq ptr %96, null
  br i1 %97, label %115, label %98

98:                                               ; preds = %94
  %99 = trunc nuw i64 %2 to i32
  %100 = getelementptr %struct.NmsView, ptr %96, i32 %99
  %101 = getelementptr i8, ptr %100, i32 -8
  %102 = load ptr, ptr %101, align 4, !tbaa !28
  %103 = icmp eq ptr %102, null
  br i1 %103, label %115, label %104

104:                                              ; preds = %98
  %105 = getelementptr i8, ptr %100, i32 -4
  br label %106

106:                                              ; preds = %104, %84
  %107 = phi ptr [ %102, %104 ], [ %85, %84 ]
  %108 = phi ptr [ %105, %104 ], [ %86, %84 ]
  %109 = icmp eq ptr %3, null
  br i1 %109, label %115, label %110

110:                                              ; preds = %106
  %111 = load i32, ptr %108, align 4, !tbaa !1
  %112 = zext i32 %60 to i64
  %113 = zext i32 %111 to i64
  %114 = call fastcc i32 @create_parts(ptr noundef nonnull %0, ptr noundef %58, i64 noundef %112, ptr noundef %107, i64 noundef %113, ptr noundef nonnull %5) #27
  br label %115

115:                                              ; preds = %16, %13, %31, %21, %40, %45, %38, %7, %25, %49, %4, %65, %62, %80, %70, %89, %94, %87, %74, %98, %110, %106
  %116 = phi i32 [ 6, %106 ], [ %114, %110 ], [ 6, %65 ], [ 6, %62 ], [ 1, %80 ], [ 6, %70 ], [ 6, %89 ], [ 6, %94 ], [ 6, %87 ], [ 6, %4 ], [ 6, %74 ], [ 6, %98 ], [ 6, %16 ], [ 6, %13 ], [ 1, %31 ], [ 6, %21 ], [ 6, %40 ], [ 6, %45 ], [ 6, %38 ], [ 5, %7 ], [ 6, %25 ], [ 6, %49 ]
  %117 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #27
  %118 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #27
  %119 = icmp eq i32 %116, 0
  br i1 %119, label %120, label %129

120:                                              ; preds = %115
  %121 = icmp ne i32 %117, 0
  %122 = icmp ne i32 %118, 0
  %123 = select i1 %121, i1 true, i1 %122
  %124 = load i64, ptr %5, align 8, !tbaa !45
  br i1 %123, label %125, label %128

125:                                              ; preds = %120
  %126 = call i32 @nms_release(ptr noundef %0, i64 noundef %124) #27
  %127 = select i1 %121, i32 %117, i32 %118
  br label %129

128:                                              ; preds = %120
  store i64 %124, ptr %3, align 8, !tbaa !45
  br label %129

129:                                              ; preds = %115, %128, %125
  %130 = phi i32 [ 0, %128 ], [ %127, %125 ], [ %116, %115 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  ret i32 %130
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 7) i32 @nms_collect(ptr noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %173, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %5 = load i32, ptr %4, align 8, !tbaa !21
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %173

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %9 = load i32, ptr %8, align 4, !tbaa !18
  %10 = icmp eq i32 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %12 = load ptr, ptr %11, align 8, !tbaa !13
  %13 = icmp eq ptr %12, null
  br i1 %10, label %14, label %24

14:                                               ; preds = %7
  br i1 %13, label %15, label %173

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 40
  %17 = load i64, ptr %16, align 8, !tbaa !19
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %173

19:                                               ; preds = %15
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %21 = load i64, ptr %20, align 8, !tbaa !20
  %22 = icmp eq i64 %21, 0
  %23 = select i1 %22, i32 0, i32 6
  br label %173

24:                                               ; preds = %7
  br i1 %13, label %173, label %25

25:                                               ; preds = %24
  %26 = icmp ugt i32 %9, 536870910
  br i1 %26, label %173, label %27

27:                                               ; preds = %25
  %28 = add nuw nsw i32 %9, 1
  %29 = zext nneg i32 %28 to i64
  %30 = shl nuw nsw i64 %29, 3
  %31 = tail call fastcc ptr @allocate(i64 noundef %30) #27
  %32 = tail call fastcc ptr @allocate(i64 noundef %29) #27
  %33 = shl nuw nsw i64 %29, 2
  %34 = tail call fastcc ptr @allocate(i64 noundef %33) #27
  %35 = icmp ne ptr %31, null
  %36 = icmp ne ptr %32, null
  %37 = select i1 %35, i1 %36, i1 false
  %38 = icmp ne ptr %34, null
  %39 = select i1 %37, i1 %38, i1 false
  br i1 %39, label %40, label %42

40:                                               ; preds = %27
  %41 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull %0, ptr noundef nonnull %31, ptr noundef nonnull %32, ptr noundef nonnull %34) #27
  br label %44

42:                                               ; preds = %27
  %43 = icmp eq ptr %34, null
  br i1 %43, label %86, label %44

44:                                               ; preds = %40, %42
  %45 = phi i32 [ %41, %40 ], [ 3, %42 ]
  %46 = getelementptr inbounds i8, ptr %34, i32 -16
  br label %47

47:                                               ; preds = %47, %44
  %48 = phi ptr [ null, %44 ], [ %50, %47 ]
  %49 = phi ptr [ @free_blocks, %44 ], [ %54, %47 ]
  %50 = load ptr, ptr %49, align 4, !tbaa !31
  %51 = icmp ne ptr %50, null
  %52 = icmp ult ptr %50, %46
  %53 = and i1 %51, %52
  %54 = getelementptr inbounds nuw i8, ptr %50, i32 8
  br i1 %53, label %47, label %55, !llvm.loop !33

55:                                               ; preds = %47
  %56 = ptrtoint ptr %46 to i32
  %57 = getelementptr inbounds i8, ptr %34, i32 -8
  store ptr %50, ptr %57, align 8, !tbaa !35
  br i1 %51, label %58, label %69

58:                                               ; preds = %55
  %59 = ptrtoint ptr %50 to i32
  %60 = zext i32 %56 to i64
  %61 = load i64, ptr %46, align 8, !tbaa !37
  %62 = add i64 %61, %60
  %63 = zext i32 %59 to i64
  %64 = icmp eq i64 %62, %63
  br i1 %64, label %65, label %69

65:                                               ; preds = %58
  %66 = load i64, ptr %50, align 8, !tbaa !37
  %67 = add i64 %66, %61
  store i64 %67, ptr %46, align 8, !tbaa !37
  %68 = load ptr, ptr %54, align 8, !tbaa !35
  store ptr %68, ptr %57, align 8, !tbaa !35
  br label %69

69:                                               ; preds = %65, %58, %55
  %70 = phi ptr [ %68, %65 ], [ %50, %58 ], [ null, %55 ]
  %71 = icmp eq ptr %48, null
  br i1 %71, label %85, label %72

72:                                               ; preds = %69
  %73 = ptrtoint ptr %48 to i32
  %74 = zext i32 %73 to i64
  %75 = load i64, ptr %48, align 8, !tbaa !37
  %76 = add i64 %75, %74
  %77 = zext i32 %56 to i64
  %78 = icmp eq i64 %76, %77
  br i1 %78, label %79, label %83

79:                                               ; preds = %72
  %80 = load i64, ptr %46, align 8, !tbaa !37
  %81 = add i64 %80, %75
  store i64 %81, ptr %48, align 8, !tbaa !37
  %82 = getelementptr inbounds nuw i8, ptr %48, i32 8
  store ptr %70, ptr %82, align 8, !tbaa !35
  br label %86

83:                                               ; preds = %72
  %84 = getelementptr inbounds nuw i8, ptr %48, i32 8
  store ptr %46, ptr %84, align 8, !tbaa !35
  br label %86

85:                                               ; preds = %69
  store ptr %46, ptr @free_blocks, align 4, !tbaa !31
  br label %86

86:                                               ; preds = %42, %79, %83, %85
  %87 = phi i32 [ 3, %42 ], [ %45, %79 ], [ %45, %83 ], [ %45, %85 ]
  %88 = icmp eq ptr %32, null
  br i1 %88, label %130, label %89

89:                                               ; preds = %86
  %90 = getelementptr inbounds i8, ptr %32, i32 -16
  br label %91

91:                                               ; preds = %91, %89
  %92 = phi ptr [ null, %89 ], [ %94, %91 ]
  %93 = phi ptr [ @free_blocks, %89 ], [ %98, %91 ]
  %94 = load ptr, ptr %93, align 4, !tbaa !31
  %95 = icmp ne ptr %94, null
  %96 = icmp ult ptr %94, %90
  %97 = and i1 %95, %96
  %98 = getelementptr inbounds nuw i8, ptr %94, i32 8
  br i1 %97, label %91, label %99, !llvm.loop !33

99:                                               ; preds = %91
  %100 = ptrtoint ptr %90 to i32
  %101 = getelementptr inbounds i8, ptr %32, i32 -8
  store ptr %94, ptr %101, align 8, !tbaa !35
  br i1 %95, label %102, label %113

102:                                              ; preds = %99
  %103 = ptrtoint ptr %94 to i32
  %104 = zext i32 %100 to i64
  %105 = load i64, ptr %90, align 8, !tbaa !37
  %106 = add i64 %105, %104
  %107 = zext i32 %103 to i64
  %108 = icmp eq i64 %106, %107
  br i1 %108, label %109, label %113

109:                                              ; preds = %102
  %110 = load i64, ptr %94, align 8, !tbaa !37
  %111 = add i64 %110, %105
  store i64 %111, ptr %90, align 8, !tbaa !37
  %112 = load ptr, ptr %98, align 8, !tbaa !35
  store ptr %112, ptr %101, align 8, !tbaa !35
  br label %113

113:                                              ; preds = %109, %102, %99
  %114 = phi ptr [ %112, %109 ], [ %94, %102 ], [ null, %99 ]
  %115 = icmp eq ptr %92, null
  br i1 %115, label %129, label %116

116:                                              ; preds = %113
  %117 = ptrtoint ptr %92 to i32
  %118 = zext i32 %117 to i64
  %119 = load i64, ptr %92, align 8, !tbaa !37
  %120 = add i64 %119, %118
  %121 = zext i32 %100 to i64
  %122 = icmp eq i64 %120, %121
  br i1 %122, label %123, label %127

123:                                              ; preds = %116
  %124 = load i64, ptr %90, align 8, !tbaa !37
  %125 = add i64 %124, %119
  store i64 %125, ptr %92, align 8, !tbaa !37
  %126 = getelementptr inbounds nuw i8, ptr %92, i32 8
  store ptr %114, ptr %126, align 8, !tbaa !35
  br label %130

127:                                              ; preds = %116
  %128 = getelementptr inbounds nuw i8, ptr %92, i32 8
  store ptr %90, ptr %128, align 8, !tbaa !35
  br label %130

129:                                              ; preds = %113
  store ptr %90, ptr @free_blocks, align 4, !tbaa !31
  br label %130

130:                                              ; preds = %86, %123, %127, %129
  %131 = icmp eq ptr %31, null
  br i1 %131, label %173, label %132

132:                                              ; preds = %130
  %133 = getelementptr inbounds i8, ptr %31, i32 -16
  br label %134

134:                                              ; preds = %134, %132
  %135 = phi ptr [ null, %132 ], [ %137, %134 ]
  %136 = phi ptr [ @free_blocks, %132 ], [ %141, %134 ]
  %137 = load ptr, ptr %136, align 4, !tbaa !31
  %138 = icmp ne ptr %137, null
  %139 = icmp ult ptr %137, %133
  %140 = and i1 %138, %139
  %141 = getelementptr inbounds nuw i8, ptr %137, i32 8
  br i1 %140, label %134, label %142, !llvm.loop !33

142:                                              ; preds = %134
  %143 = ptrtoint ptr %133 to i32
  %144 = getelementptr inbounds i8, ptr %31, i32 -8
  store ptr %137, ptr %144, align 8, !tbaa !35
  br i1 %138, label %145, label %156

145:                                              ; preds = %142
  %146 = ptrtoint ptr %137 to i32
  %147 = zext i32 %143 to i64
  %148 = load i64, ptr %133, align 8, !tbaa !37
  %149 = add i64 %148, %147
  %150 = zext i32 %146 to i64
  %151 = icmp eq i64 %149, %150
  br i1 %151, label %152, label %156

152:                                              ; preds = %145
  %153 = load i64, ptr %137, align 8, !tbaa !37
  %154 = add i64 %153, %148
  store i64 %154, ptr %133, align 8, !tbaa !37
  %155 = load ptr, ptr %141, align 8, !tbaa !35
  store ptr %155, ptr %144, align 8, !tbaa !35
  br label %156

156:                                              ; preds = %152, %145, %142
  %157 = phi ptr [ %155, %152 ], [ %137, %145 ], [ null, %142 ]
  %158 = icmp eq ptr %135, null
  br i1 %158, label %172, label %159

159:                                              ; preds = %156
  %160 = ptrtoint ptr %135 to i32
  %161 = zext i32 %160 to i64
  %162 = load i64, ptr %135, align 8, !tbaa !37
  %163 = add i64 %162, %161
  %164 = zext i32 %143 to i64
  %165 = icmp eq i64 %163, %164
  br i1 %165, label %166, label %170

166:                                              ; preds = %159
  %167 = load i64, ptr %133, align 8, !tbaa !37
  %168 = add i64 %167, %162
  store i64 %168, ptr %135, align 8, !tbaa !37
  %169 = getelementptr inbounds nuw i8, ptr %135, i32 8
  store ptr %157, ptr %169, align 8, !tbaa !35
  br label %173

170:                                              ; preds = %159
  %171 = getelementptr inbounds nuw i8, ptr %135, i32 8
  store ptr %133, ptr %171, align 8, !tbaa !35
  br label %173

172:                                              ; preds = %156
  store ptr %133, ptr @free_blocks, align 4, !tbaa !31
  br label %173

173:                                              ; preds = %19, %24, %14, %15, %3, %1, %172, %170, %166, %130, %25
  %174 = phi i32 [ %87, %172 ], [ 6, %24 ], [ 3, %25 ], [ %87, %130 ], [ %87, %166 ], [ %87, %170 ], [ 6, %1 ], [ %23, %19 ], [ 6, %14 ], [ 6, %15 ], [ 5, %3 ]
  ret i32 %174
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none)
define internal fastcc range(i32 0, 7) i32 @collect_with_workspace(ptr noundef captures(address_is_null) %0, ptr noundef captures(none) %1, ptr noundef captures(none) %2, ptr noundef captures(none) %3) unnamed_addr #10 {
  %5 = alloca %struct.NmsValue, align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %7 = load i32, ptr %6, align 4, !tbaa !18
  %8 = zext i32 %7 to i64
  %9 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 4
  br label %13

13:                                               ; preds = %4, %141
  %14 = phi i64 [ 0, %4 ], [ %143, %141 ]
  %15 = phi i64 [ 0, %4 ], [ %142, %141 ]
  %16 = phi i64 [ 0, %4 ], [ %144, %141 ]
  %17 = load ptr, ptr %9, align 8, !tbaa !13
  %18 = trunc i64 %16 to i32
  %19 = getelementptr inbounds nuw %struct.NmsSlot, ptr %17, i32 %18
  %20 = getelementptr inbounds nuw i8, ptr %19, i32 8
  %21 = load i64, ptr %20, align 8, !tbaa !23
  %22 = getelementptr inbounds nuw i64, ptr %1, i32 %18
  store i64 %21, ptr %22, align 8, !tbaa !45
  %23 = getelementptr inbounds nuw i8, ptr %2, i32 %18
  store i8 0, ptr %23, align 1, !tbaa !46
  %24 = load i64, ptr %20, align 8, !tbaa !23
  %25 = icmp eq i64 %24, 0
  br i1 %25, label %26, label %41

26:                                               ; preds = %13
  %27 = getelementptr inbounds nuw i8, ptr %19, i32 28
  %28 = load i32, ptr %27, align 4, !tbaa !26
  %29 = icmp eq i32 %28, 0
  br i1 %29, label %30, label %698

30:                                               ; preds = %26
  %31 = load ptr, ptr %19, align 8, !tbaa !27
  %32 = icmp eq ptr %31, null
  br i1 %32, label %33, label %698

33:                                               ; preds = %30
  %34 = getelementptr inbounds nuw i8, ptr %19, i32 16
  %35 = load i32, ptr %34, align 8, !tbaa !38
  %36 = icmp eq i32 %35, 0
  br i1 %36, label %37, label %698

37:                                               ; preds = %33
  %38 = getelementptr inbounds nuw i8, ptr %19, i32 24
  %39 = load i32, ptr %38, align 8, !tbaa !43
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %141, label %698

41:                                               ; preds = %13
  %42 = icmp eq i64 %16, 0
  br i1 %42, label %698, label %43

43:                                               ; preds = %41
  %44 = getelementptr inbounds nuw i8, ptr %19, i32 28
  %45 = load i32, ptr %44, align 4, !tbaa !26
  %46 = add i32 %45, -6
  %47 = icmp ult i32 %46, -5
  br i1 %47, label %698, label %48

48:                                               ; preds = %43
  %49 = icmp eq i32 %45, 1
  br i1 %49, label %50, label %57

50:                                               ; preds = %48
  %51 = load ptr, ptr %19, align 8, !tbaa !27
  %52 = icmp eq ptr %51, null
  br i1 %52, label %698, label %53

53:                                               ; preds = %50
  %54 = getelementptr inbounds nuw i8, ptr %19, i32 16
  %55 = load i32, ptr %54, align 8, !tbaa !38
  %56 = zext i32 %55 to i64
  br label %134

57:                                               ; preds = %48
  %58 = getelementptr inbounds nuw i8, ptr %19, i32 16
  %59 = load i32, ptr %58, align 8, !tbaa !38
  %60 = getelementptr inbounds nuw i8, ptr %19, i32 24
  %61 = load i32, ptr %60, align 8, !tbaa !43
  %62 = icmp ugt i32 %59, %61
  br i1 %62, label %698, label %63

63:                                               ; preds = %57
  %64 = icmp eq i32 %61, 0
  br i1 %64, label %68, label %65

65:                                               ; preds = %63
  %66 = load ptr, ptr %19, align 8, !tbaa !27
  %67 = icmp eq ptr %66, null
  br i1 %67, label %698, label %68

68:                                               ; preds = %65, %63
  switch i32 %45, label %128 [
    i32 4, label %69
    i32 5, label %74
    i32 2, label %129
  ]

69:                                               ; preds = %68
  %70 = getelementptr inbounds nuw i8, ptr %19, i32 32
  %71 = load i32, ptr %70, align 8, !tbaa !40
  %72 = add i32 %71, -1
  %73 = icmp ult i32 %72, 4
  br i1 %73, label %120, label %698

74:                                               ; preds = %68
  %75 = load i32, ptr %10, align 8, !tbaa !21
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %77, label %698

77:                                               ; preds = %74
  %78 = load i32, ptr %6, align 4, !tbaa !18
  %79 = zext i32 %78 to i64
  %80 = icmp samesign ugt i64 %16, %79
  br i1 %80, label %698, label %81

81:                                               ; preds = %77
  %82 = load ptr, ptr %9, align 8, !tbaa !13
  %83 = icmp eq ptr %82, null
  br i1 %83, label %698, label %84

84:                                               ; preds = %81
  %85 = getelementptr inbounds nuw %struct.NmsSlot, ptr %82, i32 %18
  %86 = getelementptr inbounds nuw i8, ptr %85, i32 8
  %87 = load i64, ptr %86, align 8, !tbaa !23
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %698, label %89

89:                                               ; preds = %84
  %90 = getelementptr inbounds nuw i8, ptr %85, i32 28
  %91 = load i32, ptr %90, align 4, !tbaa !26
  %92 = icmp eq i32 %91, 5
  br i1 %92, label %93, label %698

93:                                               ; preds = %89
  %94 = load i32, ptr %11, align 8, !tbaa !9
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %698, label %96

96:                                               ; preds = %93
  %97 = load ptr, ptr %0, align 8, !tbaa !5
  %98 = icmp eq ptr %97, null
  br i1 %98, label %698, label %99

99:                                               ; preds = %96
  %100 = getelementptr inbounds nuw i8, ptr %85, i32 40
  %101 = load i32, ptr %100, align 8, !tbaa !42
  %102 = load i32, ptr %12, align 4, !tbaa !10
  %103 = icmp ult i32 %101, %102
  br i1 %103, label %104, label %698

104:                                              ; preds = %99
  %105 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %97, i32 %101
  %106 = getelementptr inbounds nuw i8, ptr %105, i32 4
  %107 = load i32, ptr %106, align 4, !tbaa !57
  %108 = getelementptr inbounds nuw i8, ptr %85, i32 16
  %109 = load i32, ptr %108, align 8, !tbaa !38
  %110 = icmp eq i32 %109, %107
  br i1 %110, label %111, label %698

111:                                              ; preds = %104
  %112 = getelementptr inbounds nuw i8, ptr %85, i32 24
  %113 = load i32, ptr %112, align 8, !tbaa !43
  %114 = icmp eq i32 %113, %107
  br i1 %114, label %115, label %698

115:                                              ; preds = %111
  %116 = icmp eq i32 %107, 0
  br i1 %116, label %128, label %117

117:                                              ; preds = %115
  %118 = load ptr, ptr %85, align 8, !tbaa !27
  %119 = icmp eq ptr %118, null
  br i1 %119, label %698, label %128

120:                                              ; preds = %69
  %121 = and i32 %71, 5
  %122 = icmp eq i32 %121, 1
  %123 = icmp eq i32 %71, 2
  %124 = icmp eq i32 %71, 4
  %125 = or i1 %123, %124
  %126 = zext i1 %125 to i64
  %127 = select i1 %122, i64 8, i64 %126
  br label %129

128:                                              ; preds = %117, %115, %68
  br label %129

129:                                              ; preds = %68, %120, %128
  %130 = phi i64 [ 8, %68 ], [ %127, %120 ], [ 16, %128 ]
  %131 = zext i32 %61 to i64
  %132 = mul nuw nsw i64 %130, %131
  %133 = icmp samesign ugt i64 %132, 4294967295
  br i1 %133, label %698, label %134

134:                                              ; preds = %129, %53
  %135 = phi i64 [ %56, %53 ], [ %132, %129 ]
  %136 = xor i64 %14, -1
  %137 = icmp ugt i64 %135, %136
  br i1 %137, label %698, label %138

138:                                              ; preds = %134
  %139 = add i64 %135, %14
  %140 = add i64 %15, 1
  br label %141

141:                                              ; preds = %37, %138
  %142 = phi i64 [ %140, %138 ], [ %15, %37 ]
  %143 = phi i64 [ %139, %138 ], [ %14, %37 ]
  %144 = add nuw nsw i64 %16, 1
  %145 = icmp eq i64 %16, %8
  br i1 %145, label %146, label %13, !llvm.loop !144

146:                                              ; preds = %141
  %147 = getelementptr inbounds nuw i8, ptr %0, i32 40
  %148 = load i64, ptr %147, align 8, !tbaa !19
  %149 = icmp eq i64 %142, %148
  br i1 %149, label %150, label %698

150:                                              ; preds = %146
  %151 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %152 = load i64, ptr %151, align 8, !tbaa !20
  %153 = icmp eq i64 %143, %152
  br i1 %153, label %154, label %698

154:                                              ; preds = %150
  %155 = icmp eq i32 %7, 0
  br i1 %155, label %698, label %156

156:                                              ; preds = %154
  %157 = load ptr, ptr %9, align 8, !tbaa !13
  %158 = getelementptr inbounds nuw i8, ptr %5, i32 8
  %159 = getelementptr inbounds nuw i8, ptr %5, i32 12
  br label %160

160:                                              ; preds = %156, %278
  %161 = phi i64 [ 1, %156 ], [ %279, %278 ]
  %162 = trunc nuw i64 %161 to i32
  %163 = getelementptr inbounds nuw %struct.NmsSlot, ptr %157, i32 %162
  %164 = getelementptr inbounds nuw i8, ptr %163, i32 28
  %165 = load i32, ptr %164, align 4, !tbaa !26
  switch i32 %165, label %278 [
    i32 5, label %166
    i32 3, label %166
    i32 2, label %166
  ]

166:                                              ; preds = %160, %160, %160
  %167 = getelementptr inbounds nuw i8, ptr %163, i32 16
  %168 = load i32, ptr %167, align 8, !tbaa !38
  %169 = icmp eq i32 %168, 0
  br i1 %169, label %278, label %170

170:                                              ; preds = %166
  %171 = getelementptr inbounds nuw i8, ptr %163, i32 32
  br label %172

172:                                              ; preds = %170, %274
  %173 = phi i32 [ 0, %170 ], [ %275, %274 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  tail call void @llvm.experimental.noalias.scope.decl(metadata !145)
  switch i32 %165, label %256 [
    i32 4, label %174
    i32 2, label %252
  ]

174:                                              ; preds = %172
  tail call void @llvm.experimental.noalias.scope.decl(metadata !148)
  %175 = load i32, ptr %171, align 8, !tbaa !40, !noalias !151
  %176 = and i32 %175, -3
  %177 = icmp eq i32 %176, 1
  %178 = icmp eq i32 %175, 2
  %179 = icmp eq i32 %175, 4
  %180 = or i1 %178, %179
  %181 = zext i1 %180 to i32
  %182 = select i1 %177, i32 8, i32 %181
  store i32 %175, ptr %158, align 8, !tbaa !54, !alias.scope !151
  store i32 0, ptr %159, align 4, !alias.scope !151
  %183 = icmp eq i32 %182, 0
  br i1 %183, label %250, label %184

184:                                              ; preds = %174
  %185 = mul i32 %182, %173
  %186 = load ptr, ptr %163, align 8, !tbaa !27, !noalias !151
  %187 = getelementptr i8, ptr %186, i32 %185
  %188 = zext nneg i32 %182 to i64
  %189 = and i64 %188, 1
  br i1 %177, label %190, label %232

190:                                              ; preds = %184
  %191 = and i64 %188, 8
  br label %192

192:                                              ; preds = %192, %190
  %193 = phi i64 [ 0, %190 ], [ %227, %192 ]
  %194 = phi i64 [ 0, %190 ], [ %226, %192 ]
  %195 = phi i64 [ 0, %190 ], [ %228, %192 ]
  %196 = trunc nuw nsw i64 %193 to i32
  %197 = getelementptr i8, ptr %187, i32 %196
  %198 = load i8, ptr %197, align 1, !tbaa !46, !noalias !151
  %199 = zext i8 %198 to i64
  %200 = shl nuw nsw i64 %193, 3
  %201 = shl nuw i64 %199, %200
  %202 = or i64 %201, %194
  %203 = or disjoint i64 %193, 1
  %204 = trunc nuw nsw i64 %203 to i32
  %205 = getelementptr i8, ptr %187, i32 %204
  %206 = load i8, ptr %205, align 1, !tbaa !46, !noalias !151
  %207 = zext i8 %206 to i64
  %208 = shl nuw nsw i64 %203, 3
  %209 = shl nuw i64 %207, %208
  %210 = or i64 %209, %202
  %211 = or disjoint i64 %193, 2
  %212 = trunc nuw nsw i64 %211 to i32
  %213 = getelementptr i8, ptr %187, i32 %212
  %214 = load i8, ptr %213, align 1, !tbaa !46, !noalias !151
  %215 = zext i8 %214 to i64
  %216 = shl nuw nsw i64 %211, 3
  %217 = shl nuw i64 %215, %216
  %218 = or i64 %217, %210
  %219 = or disjoint i64 %193, 3
  %220 = trunc nuw nsw i64 %219 to i32
  %221 = getelementptr i8, ptr %187, i32 %220
  %222 = load i8, ptr %221, align 1, !tbaa !46, !noalias !151
  %223 = zext i8 %222 to i64
  %224 = shl nuw nsw i64 %219, 3
  %225 = shl nuw i64 %223, %224
  %226 = or i64 %225, %218
  %227 = add nuw nsw i64 %193, 4
  %228 = add i64 %195, 4
  %229 = icmp eq i64 %228, %191
  br i1 %229, label %230, label %192, !llvm.loop !64

230:                                              ; preds = %192
  %231 = icmp eq i64 %189, 0
  br i1 %231, label %250, label %232

232:                                              ; preds = %230, %184
  %233 = phi i64 [ 0, %184 ], [ %227, %230 ]
  %234 = phi i64 [ 0, %184 ], [ %226, %230 ]
  %235 = trunc i32 %182 to i1
  tail call void @llvm.assume(i1 %235)
  br label %236

236:                                              ; preds = %236, %232
  %237 = phi i64 [ %233, %232 ], [ %247, %236 ]
  %238 = phi i64 [ %234, %232 ], [ %246, %236 ]
  %239 = phi i64 [ 0, %232 ], [ %248, %236 ]
  %240 = trunc nuw nsw i64 %237 to i32
  %241 = getelementptr i8, ptr %187, i32 %240
  %242 = load i8, ptr %241, align 1, !tbaa !46, !noalias !151
  %243 = zext i8 %242 to i64
  %244 = shl nuw nsw i64 %237, 3
  %245 = shl nuw i64 %243, %244
  %246 = or i64 %245, %238
  %247 = add nuw nsw i64 %237, 1
  %248 = add i64 %239, 1
  %249 = icmp eq i64 %239, 0
  br i1 %249, label %250, label %236, !llvm.loop !152

250:                                              ; preds = %230, %236, %174
  %251 = phi i64 [ 0, %174 ], [ %226, %230 ], [ %246, %236 ]
  store i64 %251, ptr %5, align 8, !alias.scope !151
  br label %259

252:                                              ; preds = %172
  %253 = load ptr, ptr %163, align 8, !tbaa !27, !noalias !145
  %254 = getelementptr inbounds nuw i64, ptr %253, i32 %173
  %255 = load i64, ptr %254, align 8, !tbaa !45, !noalias !145
  store i64 %255, ptr %5, align 8, !tbaa !56, !alias.scope !145
  store i32 5, ptr %158, align 8, !tbaa !54, !alias.scope !145
  store i32 0, ptr %159, align 4, !alias.scope !145
  br label %259

256:                                              ; preds = %172
  %257 = load ptr, ptr %163, align 8, !tbaa !27, !noalias !145
  %258 = getelementptr inbounds nuw %struct.NmsValue, ptr %257, i32 %173
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %5, ptr noundef nonnull align 8 dereferenceable(16) %258, i32 16, i1 false), !tbaa.struct !73
  br label %259

259:                                              ; preds = %250, %252, %256
  %260 = tail call fastcc i32 @value_valid(ptr noundef %0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %5) #27
  %261 = icmp eq i32 %260, 0
  br i1 %261, label %262, label %277

262:                                              ; preds = %259
  %263 = load i32, ptr %158, align 8, !tbaa !54
  switch i32 %263, label %274 [
    i32 8, label %264
    i32 7, label %264
    i32 5, label %264
  ]

264:                                              ; preds = %262, %262, %262
  %265 = load i64, ptr %5, align 8, !tbaa !56
  %266 = icmp sgt i64 %265, -1
  br i1 %266, label %274, label %267

267:                                              ; preds = %264
  %268 = trunc i64 %265 to i32
  %269 = getelementptr inbounds nuw i64, ptr %1, i32 %268
  %270 = load i64, ptr %269, align 8, !tbaa !45
  %271 = icmp eq i64 %270, 0
  br i1 %271, label %277, label %272

272:                                              ; preds = %267
  %273 = add i64 %270, -1
  store i64 %273, ptr %269, align 8, !tbaa !45
  br label %274

274:                                              ; preds = %262, %272, %264
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  %275 = add nuw i32 %173, 1
  %276 = icmp eq i32 %275, %168
  br i1 %276, label %278, label %172, !llvm.loop !153

277:                                              ; preds = %259, %267
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  br label %698

278:                                              ; preds = %274, %166, %160
  %279 = add nuw nsw i64 %161, 1
  %280 = icmp eq i64 %161, %8
  br i1 %280, label %281, label %160, !llvm.loop !154

281:                                              ; preds = %278
  %282 = and i64 %8, 1
  %283 = icmp eq i32 %7, 1
  br i1 %283, label %288, label %284

284:                                              ; preds = %281
  %285 = and i64 %8, 4294967294
  br label %304

286:                                              ; preds = %329
  %287 = icmp eq i64 %282, 0
  br i1 %287, label %301, label %288

288:                                              ; preds = %286, %281
  %289 = phi i64 [ 1, %281 ], [ %331, %286 ]
  %290 = phi i64 [ 0, %281 ], [ %330, %286 ]
  %291 = trunc i32 %7 to i1
  tail call void @llvm.assume(i1 %291)
  %292 = trunc nuw i64 %289 to i32
  %293 = getelementptr inbounds nuw i64, ptr %1, i32 %292
  %294 = load i64, ptr %293, align 8, !tbaa !45
  %295 = icmp eq i64 %294, 0
  br i1 %295, label %301, label %296

296:                                              ; preds = %288
  %297 = getelementptr inbounds nuw i8, ptr %2, i32 %292
  store i8 1, ptr %297, align 1, !tbaa !46
  %298 = add i64 %290, 1
  %299 = trunc i64 %290 to i32
  %300 = getelementptr inbounds nuw i32, ptr %3, i32 %299
  store i32 %292, ptr %300, align 4, !tbaa !1
  br label %301

301:                                              ; preds = %288, %296, %286
  %302 = phi i64 [ %330, %286 ], [ %298, %296 ], [ %290, %288 ]
  %303 = icmp eq i64 %302, 0
  br i1 %303, label %334, label %336

304:                                              ; preds = %329, %284
  %305 = phi i64 [ 1, %284 ], [ %331, %329 ]
  %306 = phi i64 [ 0, %284 ], [ %330, %329 ]
  %307 = phi i64 [ 0, %284 ], [ %332, %329 ]
  %308 = trunc nuw i64 %305 to i32
  %309 = getelementptr inbounds nuw i64, ptr %1, i32 %308
  %310 = load i64, ptr %309, align 8, !tbaa !45
  %311 = icmp eq i64 %310, 0
  br i1 %311, label %317, label %312

312:                                              ; preds = %304
  %313 = getelementptr inbounds nuw i8, ptr %2, i32 %308
  store i8 1, ptr %313, align 1, !tbaa !46
  %314 = add i64 %306, 1
  %315 = trunc i64 %306 to i32
  %316 = getelementptr inbounds nuw i32, ptr %3, i32 %315
  store i32 %308, ptr %316, align 4, !tbaa !1
  br label %317

317:                                              ; preds = %304, %312
  %318 = phi i64 [ %314, %312 ], [ %306, %304 ]
  %319 = trunc i64 %305 to i32
  %320 = add i32 %319, 1
  %321 = getelementptr inbounds nuw i64, ptr %1, i32 %320
  %322 = load i64, ptr %321, align 8, !tbaa !45
  %323 = icmp eq i64 %322, 0
  br i1 %323, label %329, label %324

324:                                              ; preds = %317
  %325 = getelementptr inbounds nuw i8, ptr %2, i32 %320
  store i8 1, ptr %325, align 1, !tbaa !46
  %326 = add i64 %318, 1
  %327 = trunc i64 %318 to i32
  %328 = getelementptr inbounds nuw i32, ptr %3, i32 %327
  store i32 %320, ptr %328, align 4, !tbaa !1
  br label %329

329:                                              ; preds = %324, %317
  %330 = phi i64 [ %326, %324 ], [ %318, %317 ]
  %331 = add nuw nsw i64 %305, 2
  %332 = add i64 %307, 2
  %333 = icmp eq i64 %332, %285
  br i1 %333, label %286, label %304, !llvm.loop !155

334:                                              ; preds = %465, %301
  %335 = load ptr, ptr %9, align 8, !tbaa !13
  br label %471

336:                                              ; preds = %301, %465
  %337 = phi i64 [ %466, %465 ], [ %302, %301 ]
  %338 = phi i64 [ %340, %465 ], [ 0, %301 ]
  %339 = load ptr, ptr %9, align 8, !tbaa !13
  %340 = add nuw i64 %338, 1
  %341 = trunc i64 %338 to i32
  %342 = getelementptr inbounds nuw i32, ptr %3, i32 %341
  %343 = load i32, ptr %342, align 4, !tbaa !1
  %344 = getelementptr inbounds nuw %struct.NmsSlot, ptr %339, i32 %343
  %345 = getelementptr inbounds nuw i8, ptr %344, i32 28
  %346 = load i32, ptr %345, align 4, !tbaa !26
  switch i32 %346, label %465 [
    i32 5, label %347
    i32 3, label %347
    i32 2, label %347
  ]

347:                                              ; preds = %336, %336, %336
  %348 = getelementptr inbounds nuw i8, ptr %344, i32 16
  %349 = load i32, ptr %348, align 8, !tbaa !38
  %350 = icmp eq i32 %349, 0
  br i1 %350, label %465, label %351

351:                                              ; preds = %347
  %352 = getelementptr inbounds nuw i8, ptr %344, i32 32
  br label %353

353:                                              ; preds = %351, %460
  %354 = phi i32 [ %349, %351 ], [ %461, %460 ]
  %355 = phi i32 [ 0, %351 ], [ %463, %460 ]
  %356 = phi i64 [ %337, %351 ], [ %462, %460 ]
  %357 = load i32, ptr %345, align 4, !tbaa !26, !noalias !156
  switch i32 %357, label %418 [
    i32 4, label %358
    i32 2, label %414
  ]

358:                                              ; preds = %353
  %359 = load i32, ptr %352, align 8, !tbaa !40, !noalias !159
  %360 = and i32 %359, -3
  %361 = icmp eq i32 %360, 1
  %362 = icmp eq i32 %359, 2
  %363 = icmp eq i32 %359, 4
  %364 = or i1 %362, %363
  %365 = zext i1 %364 to i32
  %366 = select i1 %361, i32 8, i32 %365
  %367 = icmp eq i32 %366, 0
  br i1 %367, label %444, label %368

368:                                              ; preds = %358
  %369 = mul i32 %366, %355
  %370 = load ptr, ptr %344, align 8, !tbaa !27, !noalias !159
  %371 = getelementptr i8, ptr %370, i32 %369
  %372 = zext nneg i32 %366 to i64
  %373 = and i64 %372, 1
  br i1 %361, label %374, label %426

374:                                              ; preds = %368
  %375 = and i64 %372, 8
  br label %376

376:                                              ; preds = %376, %374
  %377 = phi i64 [ 0, %374 ], [ %411, %376 ]
  %378 = phi i64 [ 0, %374 ], [ %410, %376 ]
  %379 = phi i64 [ 0, %374 ], [ %412, %376 ]
  %380 = trunc nuw nsw i64 %377 to i32
  %381 = getelementptr i8, ptr %371, i32 %380
  %382 = load i8, ptr %381, align 1, !tbaa !46, !noalias !159
  %383 = zext i8 %382 to i64
  %384 = shl nuw nsw i64 %377, 3
  %385 = shl nuw i64 %383, %384
  %386 = or i64 %385, %378
  %387 = or disjoint i64 %377, 1
  %388 = trunc nuw nsw i64 %387 to i32
  %389 = getelementptr i8, ptr %371, i32 %388
  %390 = load i8, ptr %389, align 1, !tbaa !46, !noalias !159
  %391 = zext i8 %390 to i64
  %392 = shl nuw nsw i64 %387, 3
  %393 = shl nuw i64 %391, %392
  %394 = or i64 %393, %386
  %395 = or disjoint i64 %377, 2
  %396 = trunc nuw nsw i64 %395 to i32
  %397 = getelementptr i8, ptr %371, i32 %396
  %398 = load i8, ptr %397, align 1, !tbaa !46, !noalias !159
  %399 = zext i8 %398 to i64
  %400 = shl nuw nsw i64 %395, 3
  %401 = shl nuw i64 %399, %400
  %402 = or i64 %401, %394
  %403 = or disjoint i64 %377, 3
  %404 = trunc nuw nsw i64 %403 to i32
  %405 = getelementptr i8, ptr %371, i32 %404
  %406 = load i8, ptr %405, align 1, !tbaa !46, !noalias !159
  %407 = zext i8 %406 to i64
  %408 = shl nuw nsw i64 %403, 3
  %409 = shl nuw i64 %407, %408
  %410 = or i64 %409, %402
  %411 = add nuw nsw i64 %377, 4
  %412 = add i64 %379, 4
  %413 = icmp eq i64 %412, %375
  br i1 %413, label %424, label %376, !llvm.loop !64

414:                                              ; preds = %353
  %415 = load ptr, ptr %344, align 8, !tbaa !27, !noalias !156
  %416 = getelementptr inbounds nuw i64, ptr %415, i32 %355
  %417 = load i64, ptr %416, align 8, !tbaa !45, !noalias !156
  br label %447

418:                                              ; preds = %353
  %419 = load ptr, ptr %344, align 8, !tbaa !27, !noalias !156
  %420 = getelementptr inbounds nuw %struct.NmsValue, ptr %419, i32 %355
  %421 = load i64, ptr %420, align 8, !tbaa !45
  %422 = getelementptr inbounds nuw i8, ptr %420, i32 8
  %423 = load i32, ptr %422, align 8, !tbaa !1
  br label %444

424:                                              ; preds = %376
  %425 = icmp eq i64 %373, 0
  br i1 %425, label %444, label %426

426:                                              ; preds = %424, %368
  %427 = phi i64 [ 0, %368 ], [ %411, %424 ]
  %428 = phi i64 [ 0, %368 ], [ %410, %424 ]
  %429 = trunc i32 %366 to i1
  tail call void @llvm.assume(i1 %429)
  br label %430

430:                                              ; preds = %430, %426
  %431 = phi i64 [ %427, %426 ], [ %441, %430 ]
  %432 = phi i64 [ %428, %426 ], [ %440, %430 ]
  %433 = phi i64 [ 0, %426 ], [ %442, %430 ]
  %434 = trunc nuw nsw i64 %431 to i32
  %435 = getelementptr i8, ptr %371, i32 %434
  %436 = load i8, ptr %435, align 1, !tbaa !46, !noalias !159
  %437 = zext i8 %436 to i64
  %438 = shl nuw nsw i64 %431, 3
  %439 = shl nuw i64 %437, %438
  %440 = or i64 %439, %432
  %441 = add nuw nsw i64 %431, 1
  %442 = add i64 %433, 1
  %443 = icmp eq i64 %433, 0
  br i1 %443, label %444, label %430, !llvm.loop !162

444:                                              ; preds = %424, %430, %358, %418
  %445 = phi i32 [ %423, %418 ], [ %359, %358 ], [ %359, %430 ], [ %359, %424 ]
  %446 = phi i64 [ %421, %418 ], [ 0, %358 ], [ %410, %424 ], [ %440, %430 ]
  switch i32 %445, label %460 [
    i32 8, label %447
    i32 7, label %447
    i32 5, label %447
  ]

447:                                              ; preds = %444, %444, %444, %414
  %448 = phi i64 [ %417, %414 ], [ %446, %444 ], [ %446, %444 ], [ %446, %444 ]
  %449 = icmp sgt i64 %448, -1
  br i1 %449, label %460, label %450

450:                                              ; preds = %447
  %451 = trunc i64 %448 to i32
  %452 = getelementptr inbounds nuw i8, ptr %2, i32 %451
  %453 = load i8, ptr %452, align 1, !tbaa !46
  %454 = icmp eq i8 %453, 0
  br i1 %454, label %455, label %460

455:                                              ; preds = %450
  store i8 1, ptr %452, align 1, !tbaa !46
  %456 = add i64 %356, 1
  %457 = trunc i64 %356 to i32
  %458 = getelementptr inbounds nuw i32, ptr %3, i32 %457
  store i32 %451, ptr %458, align 4, !tbaa !1
  %459 = load i32, ptr %348, align 8, !tbaa !38
  br label %460

460:                                              ; preds = %444, %450, %455, %447
  %461 = phi i32 [ %354, %444 ], [ %354, %447 ], [ %354, %450 ], [ %459, %455 ]
  %462 = phi i64 [ %356, %444 ], [ %356, %447 ], [ %356, %450 ], [ %456, %455 ]
  %463 = add nuw i32 %355, 1
  %464 = icmp ult i32 %463, %461
  br i1 %464, label %353, label %465, !llvm.loop !163

465:                                              ; preds = %460, %347, %336
  %466 = phi i64 [ %337, %336 ], [ %337, %347 ], [ %462, %460 ]
  %467 = icmp ult i64 %340, %466
  br i1 %467, label %336, label %334

468:                                              ; preds = %598
  %469 = load ptr, ptr %9, align 8, !tbaa !13
  %470 = getelementptr inbounds nuw i8, ptr %0, i32 56
  br label %601

471:                                              ; preds = %334, %598
  %472 = phi i64 [ 1, %334 ], [ %599, %598 ]
  %473 = trunc nuw i64 %472 to i32
  %474 = getelementptr inbounds nuw %struct.NmsSlot, ptr %335, i32 %473
  %475 = getelementptr inbounds nuw i8, ptr %2, i32 %473
  %476 = load i8, ptr %475, align 1, !tbaa !46
  %477 = icmp eq i8 %476, 0
  br i1 %477, label %478, label %598

478:                                              ; preds = %471
  %479 = getelementptr inbounds nuw i8, ptr %474, i32 8
  %480 = load i64, ptr %479, align 8, !tbaa !23
  %481 = icmp eq i64 %480, 0
  br i1 %481, label %598, label %482

482:                                              ; preds = %478
  %483 = getelementptr inbounds nuw i8, ptr %474, i32 28
  %484 = load i32, ptr %483, align 4, !tbaa !26
  switch i32 %484, label %598 [
    i32 5, label %485
    i32 3, label %485
    i32 2, label %485
  ]

485:                                              ; preds = %482, %482, %482
  %486 = getelementptr inbounds nuw i8, ptr %474, i32 16
  %487 = load i32, ptr %486, align 8, !tbaa !38
  %488 = icmp eq i32 %487, 0
  br i1 %488, label %598, label %489

489:                                              ; preds = %485
  %490 = getelementptr inbounds nuw i8, ptr %474, i32 32
  br label %491

491:                                              ; preds = %489, %595
  %492 = phi i32 [ 0, %489 ], [ %596, %595 ]
  switch i32 %484, label %553 [
    i32 4, label %493
    i32 2, label %549
  ]

493:                                              ; preds = %491
  %494 = load i32, ptr %490, align 8, !tbaa !40, !noalias !164
  %495 = and i32 %494, -3
  %496 = icmp eq i32 %495, 1
  %497 = icmp eq i32 %494, 2
  %498 = icmp eq i32 %494, 4
  %499 = or i1 %497, %498
  %500 = zext i1 %499 to i32
  %501 = select i1 %496, i32 8, i32 %500
  %502 = icmp eq i32 %501, 0
  br i1 %502, label %579, label %503

503:                                              ; preds = %493
  %504 = mul i32 %501, %492
  %505 = load ptr, ptr %474, align 8, !tbaa !27, !noalias !164
  %506 = getelementptr i8, ptr %505, i32 %504
  %507 = zext nneg i32 %501 to i64
  %508 = and i64 %507, 1
  br i1 %496, label %509, label %561

509:                                              ; preds = %503
  %510 = and i64 %507, 8
  br label %511

511:                                              ; preds = %511, %509
  %512 = phi i64 [ 0, %509 ], [ %546, %511 ]
  %513 = phi i64 [ 0, %509 ], [ %545, %511 ]
  %514 = phi i64 [ 0, %509 ], [ %547, %511 ]
  %515 = trunc nuw nsw i64 %512 to i32
  %516 = getelementptr i8, ptr %506, i32 %515
  %517 = load i8, ptr %516, align 1, !tbaa !46, !noalias !164
  %518 = zext i8 %517 to i64
  %519 = shl nuw nsw i64 %512, 3
  %520 = shl nuw i64 %518, %519
  %521 = or i64 %520, %513
  %522 = or disjoint i64 %512, 1
  %523 = trunc nuw nsw i64 %522 to i32
  %524 = getelementptr i8, ptr %506, i32 %523
  %525 = load i8, ptr %524, align 1, !tbaa !46, !noalias !164
  %526 = zext i8 %525 to i64
  %527 = shl nuw nsw i64 %522, 3
  %528 = shl nuw i64 %526, %527
  %529 = or i64 %528, %521
  %530 = or disjoint i64 %512, 2
  %531 = trunc nuw nsw i64 %530 to i32
  %532 = getelementptr i8, ptr %506, i32 %531
  %533 = load i8, ptr %532, align 1, !tbaa !46, !noalias !164
  %534 = zext i8 %533 to i64
  %535 = shl nuw nsw i64 %530, 3
  %536 = shl nuw i64 %534, %535
  %537 = or i64 %536, %529
  %538 = or disjoint i64 %512, 3
  %539 = trunc nuw nsw i64 %538 to i32
  %540 = getelementptr i8, ptr %506, i32 %539
  %541 = load i8, ptr %540, align 1, !tbaa !46, !noalias !164
  %542 = zext i8 %541 to i64
  %543 = shl nuw nsw i64 %538, 3
  %544 = shl nuw i64 %542, %543
  %545 = or i64 %544, %537
  %546 = add nuw nsw i64 %512, 4
  %547 = add i64 %514, 4
  %548 = icmp eq i64 %547, %510
  br i1 %548, label %559, label %511, !llvm.loop !64

549:                                              ; preds = %491
  %550 = load ptr, ptr %474, align 8, !tbaa !27, !noalias !169
  %551 = getelementptr inbounds nuw i64, ptr %550, i32 %492
  %552 = load i64, ptr %551, align 8, !tbaa !45, !noalias !169
  br label %582

553:                                              ; preds = %491
  %554 = load ptr, ptr %474, align 8, !tbaa !27, !noalias !169
  %555 = getelementptr inbounds nuw %struct.NmsValue, ptr %554, i32 %492
  %556 = load i64, ptr %555, align 8, !tbaa !45
  %557 = getelementptr inbounds nuw i8, ptr %555, i32 8
  %558 = load i32, ptr %557, align 8, !tbaa !1
  br label %579

559:                                              ; preds = %511
  %560 = icmp eq i64 %508, 0
  br i1 %560, label %579, label %561

561:                                              ; preds = %559, %503
  %562 = phi i64 [ 0, %503 ], [ %546, %559 ]
  %563 = phi i64 [ 0, %503 ], [ %545, %559 ]
  %564 = trunc i32 %501 to i1
  tail call void @llvm.assume(i1 %564)
  br label %565

565:                                              ; preds = %565, %561
  %566 = phi i64 [ %562, %561 ], [ %576, %565 ]
  %567 = phi i64 [ %563, %561 ], [ %575, %565 ]
  %568 = phi i64 [ 0, %561 ], [ %577, %565 ]
  %569 = trunc nuw nsw i64 %566 to i32
  %570 = getelementptr i8, ptr %506, i32 %569
  %571 = load i8, ptr %570, align 1, !tbaa !46, !noalias !164
  %572 = zext i8 %571 to i64
  %573 = shl nuw nsw i64 %566, 3
  %574 = shl nuw i64 %572, %573
  %575 = or i64 %574, %567
  %576 = add nuw nsw i64 %566, 1
  %577 = add i64 %568, 1
  %578 = icmp eq i64 %568, 0
  br i1 %578, label %579, label %565, !llvm.loop !170

579:                                              ; preds = %559, %565, %493, %553
  %580 = phi i32 [ %558, %553 ], [ %494, %493 ], [ %494, %565 ], [ %494, %559 ]
  %581 = phi i64 [ %556, %553 ], [ 0, %493 ], [ %545, %559 ], [ %575, %565 ]
  switch i32 %580, label %595 [
    i32 8, label %582
    i32 7, label %582
    i32 5, label %582
  ]

582:                                              ; preds = %579, %579, %579, %549
  %583 = phi i64 [ %552, %549 ], [ %581, %579 ], [ %581, %579 ], [ %581, %579 ]
  %584 = icmp sgt i64 %583, -1
  br i1 %584, label %595, label %585

585:                                              ; preds = %582
  %586 = trunc i64 %583 to i32
  %587 = getelementptr inbounds nuw i8, ptr %2, i32 %586
  %588 = load i8, ptr %587, align 1, !tbaa !46
  %589 = icmp eq i8 %588, 0
  br i1 %589, label %595, label %590

590:                                              ; preds = %585
  %591 = getelementptr inbounds nuw %struct.NmsSlot, ptr %335, i32 %586
  %592 = getelementptr inbounds nuw i8, ptr %591, i32 8
  %593 = load i64, ptr %592, align 8, !tbaa !23
  %594 = add i64 %593, -1
  store i64 %594, ptr %592, align 8, !tbaa !23
  br label %595

595:                                              ; preds = %579, %585, %590, %582
  %596 = add nuw i32 %492, 1
  %597 = icmp eq i32 %596, %487
  br i1 %597, label %598, label %491, !llvm.loop !171

598:                                              ; preds = %595, %485, %482, %471, %478
  %599 = add nuw nsw i64 %472, 1
  %600 = icmp eq i64 %472, %8
  br i1 %600, label %468, label %471, !llvm.loop !172

601:                                              ; preds = %468, %695
  %602 = phi i64 [ 1, %468 ], [ %696, %695 ]
  %603 = trunc nuw i64 %602 to i32
  %604 = getelementptr inbounds nuw %struct.NmsSlot, ptr %469, i32 %603
  %605 = getelementptr inbounds nuw i8, ptr %2, i32 %603
  %606 = load i8, ptr %605, align 1, !tbaa !46
  %607 = icmp eq i8 %606, 0
  br i1 %607, label %608, label %695

608:                                              ; preds = %601
  %609 = getelementptr inbounds nuw i8, ptr %604, i32 8
  %610 = load i64, ptr %609, align 8, !tbaa !23
  %611 = icmp eq i64 %610, 0
  br i1 %611, label %695, label %612

612:                                              ; preds = %608
  %613 = getelementptr inbounds nuw i8, ptr %604, i32 28
  %614 = load i32, ptr %613, align 4, !tbaa !26
  %615 = icmp eq i32 %614, 1
  br i1 %615, label %616, label %620

616:                                              ; preds = %612
  %617 = getelementptr inbounds nuw i8, ptr %604, i32 16
  %618 = load i32, ptr %617, align 8, !tbaa !38
  %619 = zext i32 %618 to i64
  br label %638

620:                                              ; preds = %612
  %621 = getelementptr inbounds nuw i8, ptr %604, i32 24
  %622 = load i32, ptr %621, align 8, !tbaa !43
  switch i32 %614, label %633 [
    i32 2, label %634
    i32 4, label %623
  ]

623:                                              ; preds = %620
  %624 = getelementptr inbounds nuw i8, ptr %604, i32 32
  %625 = load i32, ptr %624, align 8, !tbaa !40
  %626 = and i32 %625, -3
  %627 = icmp eq i32 %626, 1
  %628 = icmp eq i32 %625, 2
  %629 = icmp eq i32 %625, 4
  %630 = or i1 %628, %629
  %631 = zext i1 %630 to i64
  %632 = select i1 %627, i64 8, i64 %631
  br label %634

633:                                              ; preds = %620
  br label %634

634:                                              ; preds = %620, %623, %633
  %635 = phi i64 [ 8, %620 ], [ %632, %623 ], [ 16, %633 ]
  %636 = zext i32 %622 to i64
  %637 = mul nuw nsw i64 %635, %636
  br label %638

638:                                              ; preds = %634, %616
  %639 = phi i64 [ %619, %616 ], [ %637, %634 ]
  %640 = load i64, ptr %151, align 8, !tbaa !20
  %641 = sub i64 %640, %639
  store i64 %641, ptr %151, align 8, !tbaa !20
  %642 = load i64, ptr %147, align 8, !tbaa !19
  %643 = add i64 %642, -1
  store i64 %643, ptr %147, align 8, !tbaa !19
  %644 = load ptr, ptr %604, align 8, !tbaa !27
  %645 = icmp eq ptr %644, null
  br i1 %645, label %687, label %646

646:                                              ; preds = %638
  %647 = getelementptr inbounds i8, ptr %644, i32 -16
  br label %648

648:                                              ; preds = %648, %646
  %649 = phi ptr [ null, %646 ], [ %651, %648 ]
  %650 = phi ptr [ @free_blocks, %646 ], [ %655, %648 ]
  %651 = load ptr, ptr %650, align 4, !tbaa !31
  %652 = icmp ne ptr %651, null
  %653 = icmp ult ptr %651, %647
  %654 = and i1 %652, %653
  %655 = getelementptr inbounds nuw i8, ptr %651, i32 8
  br i1 %654, label %648, label %656, !llvm.loop !33

656:                                              ; preds = %648
  %657 = ptrtoint ptr %647 to i32
  %658 = getelementptr inbounds i8, ptr %644, i32 -8
  store ptr %651, ptr %658, align 8, !tbaa !35
  br i1 %652, label %659, label %670

659:                                              ; preds = %656
  %660 = ptrtoint ptr %651 to i32
  %661 = zext i32 %657 to i64
  %662 = load i64, ptr %647, align 8, !tbaa !37
  %663 = add i64 %662, %661
  %664 = zext i32 %660 to i64
  %665 = icmp eq i64 %663, %664
  br i1 %665, label %666, label %670

666:                                              ; preds = %659
  %667 = load i64, ptr %651, align 8, !tbaa !37
  %668 = add i64 %667, %662
  store i64 %668, ptr %647, align 8, !tbaa !37
  %669 = load ptr, ptr %655, align 8, !tbaa !35
  store ptr %669, ptr %658, align 8, !tbaa !35
  br label %670

670:                                              ; preds = %666, %659, %656
  %671 = phi ptr [ %669, %666 ], [ %651, %659 ], [ null, %656 ]
  %672 = icmp eq ptr %649, null
  br i1 %672, label %686, label %673

673:                                              ; preds = %670
  %674 = ptrtoint ptr %649 to i32
  %675 = zext i32 %674 to i64
  %676 = load i64, ptr %649, align 8, !tbaa !37
  %677 = add i64 %676, %675
  %678 = zext i32 %657 to i64
  %679 = icmp eq i64 %677, %678
  br i1 %679, label %680, label %684

680:                                              ; preds = %673
  %681 = load i64, ptr %647, align 8, !tbaa !37
  %682 = add i64 %681, %676
  store i64 %682, ptr %649, align 8, !tbaa !37
  %683 = getelementptr inbounds nuw i8, ptr %649, i32 8
  store ptr %671, ptr %683, align 8, !tbaa !35
  br label %687

684:                                              ; preds = %673
  %685 = getelementptr inbounds nuw i8, ptr %649, i32 8
  store ptr %647, ptr %685, align 8, !tbaa !35
  br label %687

686:                                              ; preds = %670
  store ptr %647, ptr @free_blocks, align 4, !tbaa !31
  br label %687

687:                                              ; preds = %638, %680, %684, %686
  store ptr null, ptr %604, align 8, !tbaa !27
  store i64 0, ptr %609, align 8, !tbaa !23
  %688 = getelementptr inbounds nuw i8, ptr %604, i32 16
  store i32 0, ptr %688, align 8, !tbaa !38
  %689 = getelementptr inbounds nuw i8, ptr %604, i32 24
  store i32 0, ptr %689, align 8, !tbaa !43
  store i32 0, ptr %613, align 4, !tbaa !26
  %690 = getelementptr inbounds nuw i8, ptr %604, i32 32
  store i32 0, ptr %690, align 8, !tbaa !40
  %691 = getelementptr inbounds nuw i8, ptr %604, i32 36
  store i32 0, ptr %691, align 4, !tbaa !41
  %692 = getelementptr inbounds nuw i8, ptr %604, i32 40
  store i32 0, ptr %692, align 8, !tbaa !42
  %693 = load i32, ptr %470, align 8, !tbaa !17
  %694 = getelementptr inbounds nuw i8, ptr %604, i32 20
  store i32 %693, ptr %694, align 4, !tbaa !39
  store i32 %603, ptr %470, align 8, !tbaa !17
  br label %695

695:                                              ; preds = %601, %608, %687
  %696 = add nuw nsw i64 %602, 1
  %697 = icmp eq i64 %602, %8
  br i1 %697, label %698, label %601, !llvm.loop !173

698:                                              ; preds = %69, %117, %74, %84, %81, %77, %104, %111, %96, %99, %89, %93, %65, %50, %57, %129, %43, %30, %33, %37, %134, %41, %26, %695, %154, %277, %150, %146
  %699 = phi i32 [ 0, %695 ], [ 6, %277 ], [ 6, %146 ], [ 6, %150 ], [ 0, %154 ], [ 6, %26 ], [ 6, %41 ], [ 6, %134 ], [ 6, %37 ], [ 6, %33 ], [ 6, %30 ], [ 6, %43 ], [ 6, %129 ], [ 6, %57 ], [ 6, %50 ], [ 6, %65 ], [ 6, %93 ], [ 6, %89 ], [ 6, %99 ], [ 6, %96 ], [ 6, %111 ], [ 6, %104 ], [ 6, %77 ], [ 6, %81 ], [ 6, %84 ], [ 6, %74 ], [ 6, %117 ], [ 6, %69 ]
  ret i32 %699
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_collect_prepared(ptr noundef captures(address_is_null) %0) local_unnamed_addr #10 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %54, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %5 = load i32, ptr %4, align 8, !tbaa !21
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %54

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %9 = load i32, ptr %8, align 4, !tbaa !18
  %10 = icmp eq i32 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %12 = load ptr, ptr %11, align 8, !tbaa !13
  %13 = icmp eq ptr %12, null
  br i1 %10, label %14, label %23

14:                                               ; preds = %7
  br i1 %13, label %15, label %54

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 40
  %17 = load i64, ptr %16, align 8, !tbaa !19
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %54

19:                                               ; preds = %15
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %21 = load i64, ptr %20, align 8, !tbaa !20
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %24, label %54

23:                                               ; preds = %7
  br i1 %13, label %54, label %24

24:                                               ; preds = %19, %23
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 28
  %26 = load i32, ptr %25, align 4, !tbaa !15
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %54, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw i8, ptr %0, i32 20
  %30 = load ptr, ptr %29, align 4, !tbaa !14
  %31 = icmp eq ptr %30, null
  br i1 %31, label %54, label %32

32:                                               ; preds = %28
  %33 = getelementptr inbounds nuw i8, ptr %0, i32 24
  %34 = load i32, ptr %33, align 8, !tbaa !16
  %35 = icmp ult i32 %34, %9
  %36 = or i1 %35, %10
  %37 = select i1 %35, i32 6, i32 0
  br i1 %36, label %54, label %38

38:                                               ; preds = %32
  %39 = zext i32 %34 to i64
  %40 = add nuw nsw i64 %39, 1
  %41 = mul nuw nsw i64 %40, 9
  %42 = add nuw nsw i64 %41, 3
  %43 = shl nuw nsw i64 %40, 2
  %44 = add nuw nsw i64 %42, %43
  %45 = icmp samesign ugt i64 %44, 4294967295
  br i1 %45, label %54, label %46

46:                                               ; preds = %38
  %47 = trunc i64 %40 to i32
  %48 = shl i32 %47, 3
  %49 = getelementptr inbounds nuw i8, ptr %30, i32 %48
  %50 = trunc nuw i64 %42 to i32
  %51 = and i32 %50, -4
  %52 = getelementptr inbounds nuw i8, ptr %30, i32 %51
  %53 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull %0, ptr noundef nonnull %30, ptr noundef nonnull %49, ptr noundef nonnull %52) #27
  br label %54

54:                                               ; preds = %32, %38, %23, %19, %14, %15, %3, %1, %46, %24, %28
  %55 = phi i32 [ 6, %24 ], [ 6, %23 ], [ 6, %38 ], [ %37, %32 ], [ 6, %28 ], [ %53, %46 ], [ 6, %1 ], [ 6, %19 ], [ 6, %14 ], [ 6, %15 ], [ 5, %3 ]
  ret i32 %55
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define hidden range(i32 0, 7) i32 @nms_begin(ptr noundef captures(address_is_null) %0) local_unnamed_addr #12 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %12, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %5 = load i32, ptr %4, align 8, !tbaa !21
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %12

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 60
  %9 = load i32, ptr %8, align 4, !tbaa !22
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %7
  store i32 1, ptr %8, align 4, !tbaa !22
  br label %12

12:                                               ; preds = %7, %3, %1, %11
  %13 = phi i32 [ 6, %1 ], [ 5, %3 ], [ 0, %11 ], [ 4, %7 ]
  ret i32 %13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define hidden range(i64 0, 34359738368) i64 @nms_finish(ptr noundef captures(address_is_null) %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #12 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %18, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 60
  %7 = load i32, ptr %6, align 4, !tbaa !22
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %18, label %9

9:                                                ; preds = %5
  store i32 0, ptr %6, align 4, !tbaa !22
  %10 = icmp ugt i32 %1, 7
  %11 = select i1 %10, i32 6, i32 %1
  %12 = zext nneg i32 %11 to i64
  %13 = shl nuw nsw i64 %12, 32
  %14 = icmp eq i32 %11, 0
  %15 = select i1 %14, i32 %2, i32 0
  %16 = zext i32 %15 to i64
  %17 = or disjoint i64 %13, %16
  br label %18

18:                                               ; preds = %3, %5, %9
  %19 = phi i64 [ %17, %9 ], [ 25769803776, %5 ], [ 25769803776, %3 ]
  ret i64 %19
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_dispose(ptr noundef captures(address_is_null) %0) local_unnamed_addr #6 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %177, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 60
  %5 = load i32, ptr %4, align 4, !tbaa !22
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %177

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %9 = load i32, ptr %8, align 8, !tbaa !21
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %177

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %13 = load i32, ptr %12, align 4, !tbaa !18
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %19, label %15

15:                                               ; preds = %11
  %16 = zext i32 %13 to i64
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %18 = load ptr, ptr %17, align 8, !tbaa !13
  br label %121

19:                                               ; preds = %11
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %21 = load ptr, ptr %20, align 8, !tbaa !13
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %23 = icmp eq ptr %21, null
  br i1 %23, label %67, label %24

24:                                               ; preds = %175, %19
  %25 = phi ptr [ %176, %175 ], [ %22, %19 ]
  %26 = phi ptr [ %18, %175 ], [ %21, %19 ]
  %27 = getelementptr inbounds i8, ptr %26, i32 -16
  br label %28

28:                                               ; preds = %28, %24
  %29 = phi ptr [ null, %24 ], [ %31, %28 ]
  %30 = phi ptr [ @free_blocks, %24 ], [ %35, %28 ]
  %31 = load ptr, ptr %30, align 4, !tbaa !31
  %32 = icmp ne ptr %31, null
  %33 = icmp ult ptr %31, %27
  %34 = and i1 %32, %33
  %35 = getelementptr inbounds nuw i8, ptr %31, i32 8
  br i1 %34, label %28, label %36, !llvm.loop !33

36:                                               ; preds = %28
  %37 = ptrtoint ptr %27 to i32
  %38 = getelementptr inbounds i8, ptr %26, i32 -8
  store ptr %31, ptr %38, align 8, !tbaa !35
  br i1 %32, label %39, label %50

39:                                               ; preds = %36
  %40 = ptrtoint ptr %31 to i32
  %41 = zext i32 %37 to i64
  %42 = load i64, ptr %27, align 8, !tbaa !37
  %43 = add i64 %42, %41
  %44 = zext i32 %40 to i64
  %45 = icmp eq i64 %43, %44
  br i1 %45, label %46, label %50

46:                                               ; preds = %39
  %47 = load i64, ptr %31, align 8, !tbaa !37
  %48 = add i64 %47, %42
  store i64 %48, ptr %27, align 8, !tbaa !37
  %49 = load ptr, ptr %35, align 8, !tbaa !35
  store ptr %49, ptr %38, align 8, !tbaa !35
  br label %50

50:                                               ; preds = %46, %39, %36
  %51 = phi ptr [ %49, %46 ], [ %31, %39 ], [ null, %36 ]
  %52 = icmp eq ptr %29, null
  br i1 %52, label %66, label %53

53:                                               ; preds = %50
  %54 = ptrtoint ptr %29 to i32
  %55 = zext i32 %54 to i64
  %56 = load i64, ptr %29, align 8, !tbaa !37
  %57 = add i64 %56, %55
  %58 = zext i32 %37 to i64
  %59 = icmp eq i64 %57, %58
  br i1 %59, label %60, label %64

60:                                               ; preds = %53
  %61 = load i64, ptr %27, align 8, !tbaa !37
  %62 = add i64 %61, %56
  store i64 %62, ptr %29, align 8, !tbaa !37
  %63 = getelementptr inbounds nuw i8, ptr %29, i32 8
  store ptr %51, ptr %63, align 8, !tbaa !35
  br label %67

64:                                               ; preds = %53
  %65 = getelementptr inbounds nuw i8, ptr %29, i32 8
  store ptr %27, ptr %65, align 8, !tbaa !35
  br label %67

66:                                               ; preds = %50
  store ptr %27, ptr @free_blocks, align 4, !tbaa !31
  br label %67

67:                                               ; preds = %19, %60, %64, %66
  %68 = phi ptr [ %22, %19 ], [ %25, %60 ], [ %25, %64 ], [ %25, %66 ]
  %69 = getelementptr inbounds nuw i8, ptr %0, i32 20
  %70 = load ptr, ptr %69, align 4, !tbaa !14
  %71 = icmp eq ptr %70, null
  br i1 %71, label %113, label %72

72:                                               ; preds = %67
  %73 = getelementptr inbounds i8, ptr %70, i32 -16
  br label %74

74:                                               ; preds = %74, %72
  %75 = phi ptr [ null, %72 ], [ %77, %74 ]
  %76 = phi ptr [ @free_blocks, %72 ], [ %81, %74 ]
  %77 = load ptr, ptr %76, align 4, !tbaa !31
  %78 = icmp ne ptr %77, null
  %79 = icmp ult ptr %77, %73
  %80 = and i1 %78, %79
  %81 = getelementptr inbounds nuw i8, ptr %77, i32 8
  br i1 %80, label %74, label %82, !llvm.loop !33

82:                                               ; preds = %74
  %83 = ptrtoint ptr %73 to i32
  %84 = getelementptr inbounds i8, ptr %70, i32 -8
  store ptr %77, ptr %84, align 8, !tbaa !35
  br i1 %78, label %85, label %96

85:                                               ; preds = %82
  %86 = ptrtoint ptr %77 to i32
  %87 = zext i32 %83 to i64
  %88 = load i64, ptr %73, align 8, !tbaa !37
  %89 = add i64 %88, %87
  %90 = zext i32 %86 to i64
  %91 = icmp eq i64 %89, %90
  br i1 %91, label %92, label %96

92:                                               ; preds = %85
  %93 = load i64, ptr %77, align 8, !tbaa !37
  %94 = add i64 %93, %88
  store i64 %94, ptr %73, align 8, !tbaa !37
  %95 = load ptr, ptr %81, align 8, !tbaa !35
  store ptr %95, ptr %84, align 8, !tbaa !35
  br label %96

96:                                               ; preds = %92, %85, %82
  %97 = phi ptr [ %95, %92 ], [ %77, %85 ], [ null, %82 ]
  %98 = icmp eq ptr %75, null
  br i1 %98, label %112, label %99

99:                                               ; preds = %96
  %100 = ptrtoint ptr %75 to i32
  %101 = zext i32 %100 to i64
  %102 = load i64, ptr %75, align 8, !tbaa !37
  %103 = add i64 %102, %101
  %104 = zext i32 %83 to i64
  %105 = icmp eq i64 %103, %104
  br i1 %105, label %106, label %110

106:                                              ; preds = %99
  %107 = load i64, ptr %73, align 8, !tbaa !37
  %108 = add i64 %107, %102
  store i64 %108, ptr %75, align 8, !tbaa !37
  %109 = getelementptr inbounds nuw i8, ptr %75, i32 8
  store ptr %97, ptr %109, align 8, !tbaa !35
  br label %113

110:                                              ; preds = %99
  %111 = getelementptr inbounds nuw i8, ptr %75, i32 8
  store ptr %73, ptr %111, align 8, !tbaa !35
  br label %113

112:                                              ; preds = %96
  store ptr %73, ptr @free_blocks, align 4, !tbaa !31
  br label %113

113:                                              ; preds = %67, %106, %110, %112
  store ptr null, ptr %69, align 4, !tbaa !14
  %114 = getelementptr inbounds nuw i8, ptr %0, i32 28
  store i32 0, ptr %114, align 4, !tbaa !15
  %115 = getelementptr inbounds nuw i8, ptr %0, i32 24
  store i32 0, ptr %115, align 8, !tbaa !16
  store ptr null, ptr %68, align 8, !tbaa !13
  %116 = getelementptr inbounds nuw i8, ptr %0, i32 56
  store i32 0, ptr %116, align 8, !tbaa !17
  store i32 0, ptr %12, align 4, !tbaa !18
  %117 = getelementptr inbounds nuw i8, ptr %0, i32 40
  store i64 0, ptr %117, align 8, !tbaa !19
  %118 = getelementptr inbounds nuw i8, ptr %0, i32 32
  store i64 0, ptr %118, align 8, !tbaa !20
  store ptr null, ptr %0, align 8, !tbaa !5
  %119 = getelementptr inbounds nuw i8, ptr %0, i32 8
  store i32 0, ptr %119, align 8, !tbaa !9
  %120 = getelementptr inbounds nuw i8, ptr %0, i32 4
  store i32 0, ptr %120, align 4, !tbaa !10
  store i32 1, ptr %8, align 8, !tbaa !21
  br label %177

121:                                              ; preds = %15, %172
  %122 = phi i64 [ 1, %15 ], [ %173, %172 ]
  %123 = trunc nuw i64 %122 to i32
  %124 = getelementptr inbounds nuw %struct.NmsSlot, ptr %18, i32 %123
  %125 = getelementptr inbounds nuw i8, ptr %124, i32 8
  %126 = load i64, ptr %125, align 8, !tbaa !23
  %127 = icmp eq i64 %126, 0
  br i1 %127, label %172, label %128

128:                                              ; preds = %121
  %129 = load ptr, ptr %124, align 8, !tbaa !27
  %130 = icmp eq ptr %129, null
  br i1 %130, label %172, label %131

131:                                              ; preds = %128
  %132 = getelementptr inbounds i8, ptr %129, i32 -16
  br label %133

133:                                              ; preds = %133, %131
  %134 = phi ptr [ null, %131 ], [ %136, %133 ]
  %135 = phi ptr [ @free_blocks, %131 ], [ %140, %133 ]
  %136 = load ptr, ptr %135, align 4, !tbaa !31
  %137 = icmp ne ptr %136, null
  %138 = icmp ult ptr %136, %132
  %139 = and i1 %137, %138
  %140 = getelementptr inbounds nuw i8, ptr %136, i32 8
  br i1 %139, label %133, label %141, !llvm.loop !33

141:                                              ; preds = %133
  %142 = ptrtoint ptr %132 to i32
  %143 = getelementptr inbounds i8, ptr %129, i32 -8
  store ptr %136, ptr %143, align 8, !tbaa !35
  br i1 %137, label %144, label %155

144:                                              ; preds = %141
  %145 = ptrtoint ptr %136 to i32
  %146 = zext i32 %142 to i64
  %147 = load i64, ptr %132, align 8, !tbaa !37
  %148 = add i64 %147, %146
  %149 = zext i32 %145 to i64
  %150 = icmp eq i64 %148, %149
  br i1 %150, label %151, label %155

151:                                              ; preds = %144
  %152 = load i64, ptr %136, align 8, !tbaa !37
  %153 = add i64 %152, %147
  store i64 %153, ptr %132, align 8, !tbaa !37
  %154 = load ptr, ptr %140, align 8, !tbaa !35
  store ptr %154, ptr %143, align 8, !tbaa !35
  br label %155

155:                                              ; preds = %151, %144, %141
  %156 = phi ptr [ %154, %151 ], [ %136, %144 ], [ null, %141 ]
  %157 = icmp eq ptr %134, null
  br i1 %157, label %171, label %158

158:                                              ; preds = %155
  %159 = ptrtoint ptr %134 to i32
  %160 = zext i32 %159 to i64
  %161 = load i64, ptr %134, align 8, !tbaa !37
  %162 = add i64 %161, %160
  %163 = zext i32 %142 to i64
  %164 = icmp eq i64 %162, %163
  br i1 %164, label %165, label %169

165:                                              ; preds = %158
  %166 = load i64, ptr %132, align 8, !tbaa !37
  %167 = add i64 %166, %161
  store i64 %167, ptr %134, align 8, !tbaa !37
  %168 = getelementptr inbounds nuw i8, ptr %134, i32 8
  store ptr %156, ptr %168, align 8, !tbaa !35
  br label %172

169:                                              ; preds = %158
  %170 = getelementptr inbounds nuw i8, ptr %134, i32 8
  store ptr %132, ptr %170, align 8, !tbaa !35
  br label %172

171:                                              ; preds = %155
  store ptr %132, ptr @free_blocks, align 4, !tbaa !31
  br label %172

172:                                              ; preds = %171, %169, %165, %128, %121
  %173 = add nuw nsw i64 %122, 1
  %174 = icmp eq i64 %122, %16
  br i1 %174, label %175, label %121, !llvm.loop !174

175:                                              ; preds = %172
  %176 = getelementptr inbounds nuw i8, ptr %0, i32 16
  br label %24

177:                                              ; preds = %7, %3, %1, %113
  %178 = phi i32 [ 6, %1 ], [ 4, %3 ], [ 0, %113 ], [ 0, %7 ]
  ret i32 %178
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define hidden range(i32 0, 2) i32 @nms_reserved_entry(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #13 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %180, label %3

3:                                                ; preds = %1
  %4 = load i8, ptr %0, align 1, !tbaa !46
  %5 = icmp eq i8 %4, 110
  br i1 %5, label %6, label %179

6:                                                ; preds = %3
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 1
  %8 = load i8, ptr %7, align 1, !tbaa !46
  %9 = icmp eq i8 %8, 97
  br i1 %9, label %10, label %62

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 2
  %12 = load i8, ptr %11, align 1, !tbaa !46
  %13 = icmp eq i8 %12, 110
  br i1 %13, label %14, label %62

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 3
  %16 = load i8, ptr %15, align 1, !tbaa !46
  %17 = icmp eq i8 %16, 111
  br i1 %17, label %18, label %62

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %20 = load i8, ptr %19, align 1, !tbaa !46
  %21 = icmp eq i8 %20, 95
  br i1 %21, label %22, label %62

22:                                               ; preds = %18
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 5
  %24 = load i8, ptr %23, align 1, !tbaa !46
  %25 = icmp eq i8 %24, 116
  br i1 %25, label %26, label %62

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %0, i32 6
  %28 = load i8, ptr %27, align 1, !tbaa !46
  %29 = icmp eq i8 %28, 114
  br i1 %29, label %30, label %62

30:                                               ; preds = %26
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 7
  %32 = load i8, ptr %31, align 1, !tbaa !46
  %33 = icmp eq i8 %32, 121
  br i1 %33, label %34, label %62

34:                                               ; preds = %30
  %35 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %36 = load i8, ptr %35, align 1, !tbaa !46
  %37 = icmp eq i8 %36, 95
  br i1 %37, label %38, label %62

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i32 9
  %40 = load i8, ptr %39, align 1, !tbaa !46
  %41 = icmp eq i8 %40, 101
  br i1 %41, label %42, label %62

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i32 10
  %44 = load i8, ptr %43, align 1, !tbaa !46
  %45 = icmp eq i8 %44, 110
  br i1 %45, label %46, label %62

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %0, i32 11
  %48 = load i8, ptr %47, align 1, !tbaa !46
  %49 = icmp eq i8 %48, 116
  br i1 %49, label %50, label %62

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %52 = load i8, ptr %51, align 1, !tbaa !46
  %53 = icmp eq i8 %52, 114
  br i1 %53, label %54, label %62

54:                                               ; preds = %50
  %55 = getelementptr inbounds nuw i8, ptr %0, i32 13
  %56 = load i8, ptr %55, align 1, !tbaa !46
  %57 = icmp eq i8 %56, 121
  br i1 %57, label %58, label %62

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw i8, ptr %0, i32 14
  %60 = load i8, ptr %59, align 1, !tbaa !46
  %61 = icmp eq i8 %60, 0
  br i1 %61, label %180, label %62

62:                                               ; preds = %58, %54, %50, %46, %42, %38, %34, %30, %26, %22, %18, %14, %10, %6
  %63 = load i8, ptr %0, align 1, !tbaa !46
  %64 = icmp eq i8 %63, 110
  br i1 %64, label %65, label %179

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i32 1
  %67 = load i8, ptr %66, align 1, !tbaa !46
  %68 = icmp eq i8 %67, 97
  br i1 %68, label %69, label %113

69:                                               ; preds = %65
  %70 = getelementptr inbounds nuw i8, ptr %0, i32 2
  %71 = load i8, ptr %70, align 1, !tbaa !46
  %72 = icmp eq i8 %71, 110
  br i1 %72, label %73, label %113

73:                                               ; preds = %69
  %74 = getelementptr inbounds nuw i8, ptr %0, i32 3
  %75 = load i8, ptr %74, align 1, !tbaa !46
  %76 = icmp eq i8 %75, 111
  br i1 %76, label %77, label %113

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %79 = load i8, ptr %78, align 1, !tbaa !46
  %80 = icmp eq i8 %79, 95
  br i1 %80, label %81, label %113

81:                                               ; preds = %77
  %82 = getelementptr inbounds nuw i8, ptr %0, i32 5
  %83 = load i8, ptr %82, align 1, !tbaa !46
  %84 = icmp eq i8 %83, 100
  br i1 %84, label %85, label %113

85:                                               ; preds = %81
  %86 = getelementptr inbounds nuw i8, ptr %0, i32 6
  %87 = load i8, ptr %86, align 1, !tbaa !46
  %88 = icmp eq i8 %87, 105
  br i1 %88, label %89, label %113

89:                                               ; preds = %85
  %90 = getelementptr inbounds nuw i8, ptr %0, i32 7
  %91 = load i8, ptr %90, align 1, !tbaa !46
  %92 = icmp eq i8 %91, 115
  br i1 %92, label %93, label %113

93:                                               ; preds = %89
  %94 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %95 = load i8, ptr %94, align 1, !tbaa !46
  %96 = icmp eq i8 %95, 112
  br i1 %96, label %97, label %113

97:                                               ; preds = %93
  %98 = getelementptr inbounds nuw i8, ptr %0, i32 9
  %99 = load i8, ptr %98, align 1, !tbaa !46
  %100 = icmp eq i8 %99, 111
  br i1 %100, label %101, label %113

101:                                              ; preds = %97
  %102 = getelementptr inbounds nuw i8, ptr %0, i32 10
  %103 = load i8, ptr %102, align 1, !tbaa !46
  %104 = icmp eq i8 %103, 115
  br i1 %104, label %105, label %113

105:                                              ; preds = %101
  %106 = getelementptr inbounds nuw i8, ptr %0, i32 11
  %107 = load i8, ptr %106, align 1, !tbaa !46
  %108 = icmp eq i8 %107, 101
  br i1 %108, label %109, label %113

109:                                              ; preds = %105
  %110 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %111 = load i8, ptr %110, align 1, !tbaa !46
  %112 = icmp eq i8 %111, 0
  br i1 %112, label %180, label %113

113:                                              ; preds = %109, %105, %101, %97, %93, %89, %85, %81, %77, %73, %69, %65
  %114 = load i8, ptr %0, align 1, !tbaa !46
  %115 = icmp eq i8 %114, 110
  br i1 %115, label %116, label %179

116:                                              ; preds = %113
  %117 = getelementptr inbounds nuw i8, ptr %0, i32 1
  %118 = load i8, ptr %117, align 1, !tbaa !46
  %119 = icmp eq i8 %118, 97
  br i1 %119, label %120, label %164

120:                                              ; preds = %116
  %121 = getelementptr inbounds nuw i8, ptr %0, i32 2
  %122 = load i8, ptr %121, align 1, !tbaa !46
  %123 = icmp eq i8 %122, 110
  br i1 %123, label %124, label %164

124:                                              ; preds = %120
  %125 = getelementptr inbounds nuw i8, ptr %0, i32 3
  %126 = load i8, ptr %125, align 1, !tbaa !46
  %127 = icmp eq i8 %126, 111
  br i1 %127, label %128, label %164

128:                                              ; preds = %124
  %129 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %130 = load i8, ptr %129, align 1, !tbaa !46
  %131 = icmp eq i8 %130, 95
  br i1 %131, label %132, label %164

132:                                              ; preds = %128
  %133 = getelementptr inbounds nuw i8, ptr %0, i32 5
  %134 = load i8, ptr %133, align 1, !tbaa !46
  %135 = icmp eq i8 %134, 114
  br i1 %135, label %136, label %164

136:                                              ; preds = %132
  %137 = getelementptr inbounds nuw i8, ptr %0, i32 6
  %138 = load i8, ptr %137, align 1, !tbaa !46
  %139 = icmp eq i8 %138, 117
  br i1 %139, label %140, label %164

140:                                              ; preds = %136
  %141 = getelementptr inbounds nuw i8, ptr %0, i32 7
  %142 = load i8, ptr %141, align 1, !tbaa !46
  %143 = icmp eq i8 %142, 110
  br i1 %143, label %144, label %164

144:                                              ; preds = %140
  %145 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %146 = load i8, ptr %145, align 1, !tbaa !46
  %147 = icmp eq i8 %146, 116
  br i1 %147, label %148, label %164

148:                                              ; preds = %144
  %149 = getelementptr inbounds nuw i8, ptr %0, i32 9
  %150 = load i8, ptr %149, align 1, !tbaa !46
  %151 = icmp eq i8 %150, 105
  br i1 %151, label %152, label %164

152:                                              ; preds = %148
  %153 = getelementptr inbounds nuw i8, ptr %0, i32 10
  %154 = load i8, ptr %153, align 1, !tbaa !46
  %155 = icmp eq i8 %154, 109
  br i1 %155, label %156, label %164

156:                                              ; preds = %152
  %157 = getelementptr inbounds nuw i8, ptr %0, i32 11
  %158 = load i8, ptr %157, align 1, !tbaa !46
  %159 = icmp eq i8 %158, 101
  br i1 %159, label %160, label %164

160:                                              ; preds = %156
  %161 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %162 = load i8, ptr %161, align 1, !tbaa !46
  %163 = icmp eq i8 %162, 95
  br i1 %163, label %180, label %164

164:                                              ; preds = %160, %156, %152, %148, %144, %140, %136, %132, %128, %124, %120, %116
  %165 = load i8, ptr %0, align 1, !tbaa !46
  %166 = icmp eq i8 %165, 110
  br i1 %166, label %167, label %179

167:                                              ; preds = %164
  %168 = getelementptr inbounds nuw i8, ptr %0, i32 1
  %169 = load i8, ptr %168, align 1, !tbaa !46
  %170 = icmp eq i8 %169, 109
  br i1 %170, label %171, label %179

171:                                              ; preds = %167
  %172 = getelementptr inbounds nuw i8, ptr %0, i32 2
  %173 = load i8, ptr %172, align 1, !tbaa !46
  %174 = icmp eq i8 %173, 115
  br i1 %174, label %175, label %179

175:                                              ; preds = %171
  %176 = getelementptr inbounds nuw i8, ptr %0, i32 3
  %177 = load i8, ptr %176, align 1, !tbaa !46
  %178 = icmp eq i8 %177, 95
  br i1 %178, label %180, label %179

179:                                              ; preds = %62, %3, %113, %164, %167, %171, %175
  br label %180

180:                                              ; preds = %58, %109, %179, %160, %175, %1
  %181 = phi i32 [ 0, %1 ], [ 1, %58 ], [ 1, %160 ], [ 0, %179 ], [ 1, %109 ], [ 1, %175 ]
  ret i32 %181
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_split_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = tail call fastcc i32 @split_owned(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef %3, i32 noundef 0) #27
  ret i32 %5
}

; Function Attrs: nofree norecurse nounwind
define internal fastcc range(i32 0, 7) i32 @split_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3, i32 noundef range(i32 0, 2) %4) unnamed_addr #4 {
  %6 = alloca %struct.NmsValue, align 8
  %7 = alloca i64, align 8
  %8 = alloca %struct.NmsValue, align 8
  %9 = alloca i64, align 8
  %10 = alloca %struct.NmsValue, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %12) #28
  store i64 0, ptr %12, align 8, !tbaa !45
  %13 = icmp ne ptr %3, null
  %14 = icmp ne ptr %0, null
  %15 = and i1 %14, %13
  br i1 %15, label %16, label %291

16:                                               ; preds = %5
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %18 = load i32, ptr %17, align 8, !tbaa !21
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %20, label %291

20:                                               ; preds = %16
  %21 = icmp sgt i64 %1, -1
  br i1 %21, label %47, label %22

22:                                               ; preds = %20
  %23 = and i64 %1, 9223372036854775807
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %291, label %25

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %27 = load i32, ptr %26, align 4, !tbaa !18
  %28 = zext i32 %27 to i64
  %29 = icmp samesign ugt i64 %23, %28
  br i1 %29, label %291, label %30

30:                                               ; preds = %25
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %32 = load ptr, ptr %31, align 8, !tbaa !13
  %33 = icmp eq ptr %32, null
  br i1 %33, label %291, label %34

34:                                               ; preds = %30
  %35 = trunc i64 %1 to i32
  %36 = getelementptr inbounds nuw %struct.NmsSlot, ptr %32, i32 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i32 8
  %38 = load i64, ptr %37, align 8, !tbaa !23
  %39 = icmp eq i64 %38, 0
  br i1 %39, label %291, label %40

40:                                               ; preds = %34
  %41 = getelementptr inbounds nuw i8, ptr %36, i32 28
  %42 = load i32, ptr %41, align 4, !tbaa !26
  %43 = icmp eq i32 %42, 1
  br i1 %43, label %44, label %291

44:                                               ; preds = %40
  %45 = load ptr, ptr %36, align 8, !tbaa !27
  %46 = getelementptr inbounds nuw i8, ptr %36, i32 16
  br label %66

47:                                               ; preds = %20
  %48 = icmp eq i64 %1, 0
  br i1 %48, label %291, label %49

49:                                               ; preds = %47
  %50 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %51 = load i32, ptr %50, align 8, !tbaa !12
  %52 = zext i32 %51 to i64
  %53 = icmp samesign ugt i64 %1, %52
  br i1 %53, label %291, label %54

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %56 = load ptr, ptr %55, align 4, !tbaa !11
  %57 = icmp eq ptr %56, null
  br i1 %57, label %291, label %58

58:                                               ; preds = %54
  %59 = trunc nuw i64 %1 to i32
  %60 = getelementptr %struct.NmsView, ptr %56, i32 %59
  %61 = getelementptr i8, ptr %60, i32 -8
  %62 = load ptr, ptr %61, align 4, !tbaa !28
  %63 = icmp eq ptr %62, null
  br i1 %63, label %291, label %64

64:                                               ; preds = %58
  %65 = getelementptr i8, ptr %60, i32 -4
  br label %66

66:                                               ; preds = %64, %44
  %67 = phi ptr [ %62, %64 ], [ %45, %44 ]
  %68 = phi ptr [ %65, %64 ], [ %46, %44 ]
  %69 = load i32, ptr %68, align 4, !tbaa !1
  %70 = icmp sgt i64 %2, -1
  br i1 %70, label %96, label %71

71:                                               ; preds = %66
  %72 = and i64 %2, 9223372036854775807
  %73 = icmp eq i64 %72, 0
  br i1 %73, label %291, label %74

74:                                               ; preds = %71
  %75 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %76 = load i32, ptr %75, align 4, !tbaa !18
  %77 = zext i32 %76 to i64
  %78 = icmp samesign ugt i64 %72, %77
  br i1 %78, label %291, label %79

79:                                               ; preds = %74
  %80 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %81 = load ptr, ptr %80, align 8, !tbaa !13
  %82 = icmp eq ptr %81, null
  br i1 %82, label %291, label %83

83:                                               ; preds = %79
  %84 = trunc i64 %2 to i32
  %85 = getelementptr inbounds nuw %struct.NmsSlot, ptr %81, i32 %84
  %86 = getelementptr inbounds nuw i8, ptr %85, i32 8
  %87 = load i64, ptr %86, align 8, !tbaa !23
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %291, label %89

89:                                               ; preds = %83
  %90 = getelementptr inbounds nuw i8, ptr %85, i32 28
  %91 = load i32, ptr %90, align 4, !tbaa !26
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %93, label %291

93:                                               ; preds = %89
  %94 = load ptr, ptr %85, align 8, !tbaa !27
  %95 = getelementptr inbounds nuw i8, ptr %85, i32 16
  br label %115

96:                                               ; preds = %66
  %97 = icmp eq i64 %2, 0
  br i1 %97, label %291, label %98

98:                                               ; preds = %96
  %99 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %100 = load i32, ptr %99, align 8, !tbaa !12
  %101 = zext i32 %100 to i64
  %102 = icmp samesign ugt i64 %2, %101
  br i1 %102, label %291, label %103

103:                                              ; preds = %98
  %104 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %105 = load ptr, ptr %104, align 4, !tbaa !11
  %106 = icmp eq ptr %105, null
  br i1 %106, label %291, label %107

107:                                              ; preds = %103
  %108 = trunc nuw i64 %2 to i32
  %109 = getelementptr %struct.NmsView, ptr %105, i32 %108
  %110 = getelementptr i8, ptr %109, i32 -8
  %111 = load ptr, ptr %110, align 4, !tbaa !28
  %112 = icmp eq ptr %111, null
  br i1 %112, label %291, label %113

113:                                              ; preds = %107
  %114 = getelementptr i8, ptr %109, i32 -4
  br label %115

115:                                              ; preds = %113, %93
  %116 = phi ptr [ %111, %113 ], [ %94, %93 ]
  %117 = phi ptr [ %114, %113 ], [ %95, %93 ]
  %118 = load i32, ptr %117, align 4, !tbaa !1
  %119 = icmp eq i32 %4, 0
  br i1 %119, label %122, label %120

120:                                              ; preds = %115
  %121 = call fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr noundef nonnull %0, i32 noundef 5, i32 noundef 8, ptr noundef nonnull %12) #27
  br label %124

122:                                              ; preds = %115
  %123 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 2, i64 noundef 0, ptr noundef nonnull %12) #27
  br label %124

124:                                              ; preds = %122, %120
  %125 = phi i32 [ %123, %122 ], [ %121, %120 ]
  %126 = icmp ne i32 %125, 0
  %127 = icmp ne i32 %118, 0
  %128 = select i1 %126, i1 true, i1 %127
  br i1 %128, label %212, label %129

129:                                              ; preds = %124
  %130 = icmp eq i32 %69, 0
  br i1 %130, label %291, label %131

131:                                              ; preds = %129
  %132 = load i64, ptr %12, align 8, !tbaa !45
  %133 = icmp eq ptr %67, null
  %134 = getelementptr inbounds nuw i8, ptr %0, i32 32
  %135 = getelementptr inbounds nuw i8, ptr %10, i32 8
  %136 = getelementptr inbounds nuw i8, ptr %10, i32 12
  br label %137

137:                                              ; preds = %131, %203
  %138 = phi i32 [ 0, %131 ], [ %208, %203 ]
  %139 = getelementptr inbounds nuw i8, ptr %67, i32 %138
  call void @llvm.lifetime.start.p0(ptr nonnull %11) #28
  store i64 0, ptr %11, align 8, !tbaa !45
  br i1 %133, label %201, label %140

140:                                              ; preds = %137
  %141 = load i32, ptr %17, align 8, !tbaa !21
  %142 = icmp eq i32 %141, 0
  br i1 %142, label %143, label %201

143:                                              ; preds = %140
  %144 = load i64, ptr %134, align 8, !tbaa !20
  %145 = icmp eq i64 %144, -1
  br i1 %145, label %201, label %146

146:                                              ; preds = %143
  %147 = call fastcc ptr @allocate(i64 noundef 2) #27
  %148 = icmp eq ptr %147, null
  br i1 %148, label %201, label %149

149:                                              ; preds = %146
  %150 = load volatile i8, ptr %139, align 1, !tbaa !46
  store volatile i8 %150, ptr %147, align 1, !tbaa !46
  %151 = getelementptr inbounds nuw i8, ptr %147, i32 1
  store i8 0, ptr %151, align 1, !tbaa !46
  %152 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %147, i32 noundef 1, i32 noundef 0, i32 noundef 1, i64 noundef 1, ptr noundef nonnull %11) #27
  %153 = icmp eq i32 %152, 0
  br i1 %153, label %195, label %154

154:                                              ; preds = %149
  %155 = getelementptr inbounds i8, ptr %147, i32 -16
  br label %156

156:                                              ; preds = %156, %154
  %157 = phi ptr [ null, %154 ], [ %159, %156 ]
  %158 = phi ptr [ @free_blocks, %154 ], [ %163, %156 ]
  %159 = load ptr, ptr %158, align 4, !tbaa !31
  %160 = icmp ne ptr %159, null
  %161 = icmp ult ptr %159, %155
  %162 = and i1 %160, %161
  %163 = getelementptr inbounds nuw i8, ptr %159, i32 8
  br i1 %162, label %156, label %164, !llvm.loop !33

164:                                              ; preds = %156
  %165 = ptrtoint ptr %155 to i32
  %166 = getelementptr inbounds i8, ptr %147, i32 -8
  store ptr %159, ptr %166, align 8, !tbaa !35
  br i1 %160, label %167, label %178

167:                                              ; preds = %164
  %168 = ptrtoint ptr %159 to i32
  %169 = zext i32 %165 to i64
  %170 = load i64, ptr %155, align 8, !tbaa !37
  %171 = add i64 %170, %169
  %172 = zext i32 %168 to i64
  %173 = icmp eq i64 %171, %172
  br i1 %173, label %174, label %178

174:                                              ; preds = %167
  %175 = load i64, ptr %159, align 8, !tbaa !37
  %176 = add i64 %175, %170
  store i64 %176, ptr %155, align 8, !tbaa !37
  %177 = load ptr, ptr %163, align 8, !tbaa !35
  store ptr %177, ptr %166, align 8, !tbaa !35
  br label %178

178:                                              ; preds = %174, %167, %164
  %179 = phi ptr [ %177, %174 ], [ %159, %167 ], [ null, %164 ]
  %180 = icmp eq ptr %157, null
  br i1 %180, label %194, label %181

181:                                              ; preds = %178
  %182 = ptrtoint ptr %157 to i32
  %183 = zext i32 %182 to i64
  %184 = load i64, ptr %157, align 8, !tbaa !37
  %185 = add i64 %184, %183
  %186 = zext i32 %165 to i64
  %187 = icmp eq i64 %185, %186
  br i1 %187, label %188, label %192

188:                                              ; preds = %181
  %189 = load i64, ptr %155, align 8, !tbaa !37
  %190 = add i64 %189, %184
  store i64 %190, ptr %157, align 8, !tbaa !37
  %191 = getelementptr inbounds nuw i8, ptr %157, i32 8
  store ptr %179, ptr %191, align 8, !tbaa !35
  br label %201

192:                                              ; preds = %181
  %193 = getelementptr inbounds nuw i8, ptr %157, i32 8
  store ptr %155, ptr %193, align 8, !tbaa !35
  br label %201

194:                                              ; preds = %178
  store ptr %155, ptr @free_blocks, align 4, !tbaa !31
  br label %201

195:                                              ; preds = %149
  %196 = load i64, ptr %11, align 8, !tbaa !45
  br i1 %119, label %199, label %197

197:                                              ; preds = %195
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  store i64 %196, ptr %10, align 8
  store i32 5, ptr %135, align 8
  store i32 0, ptr %136, align 4
  %198 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %132, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %10, i32 noundef 1) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  br label %203

199:                                              ; preds = %195
  %200 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %132, i64 noundef %196) #27
  br label %203

201:                                              ; preds = %146, %143, %140, %137, %194, %192, %188
  %202 = phi i32 [ %152, %194 ], [ %152, %188 ], [ %152, %192 ], [ 3, %146 ], [ 3, %143 ], [ 5, %140 ], [ 6, %137 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %11) #28
  br label %291

203:                                              ; preds = %197, %199
  %204 = phi i32 [ %198, %197 ], [ %200, %199 ]
  %205 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %196) #27
  %206 = icmp eq i32 %204, 0
  %207 = select i1 %206, i32 %205, i32 %204
  call void @llvm.lifetime.end.p0(ptr nonnull %11) #28
  %208 = add nuw i32 %138, 1
  %209 = icmp ult i32 %208, %69
  %210 = icmp eq i32 %207, 0
  %211 = select i1 %209, i1 %210, i1 false
  br i1 %211, label %137, label %291, !llvm.loop !175

212:                                              ; preds = %124
  %213 = icmp eq i32 %125, 0
  br i1 %213, label %214, label %291

214:                                              ; preds = %212
  %215 = icmp eq i32 %118, 0
  %216 = sub i32 %69, %118
  %217 = getelementptr inbounds nuw i8, ptr %8, i32 8
  %218 = getelementptr inbounds nuw i8, ptr %8, i32 12
  br label %219

219:                                              ; preds = %214, %258
  %220 = phi i32 [ 0, %214 ], [ %263, %258 ]
  br i1 %215, label %265, label %221

221:                                              ; preds = %219
  %222 = icmp ugt i32 %220, %69
  %223 = sub i32 %69, %220
  %224 = icmp ugt i32 %118, %223
  %225 = icmp ugt i32 %220, %216
  %226 = or i1 %224, %225
  %227 = select i1 %222, i1 true, i1 %226
  br i1 %227, label %265, label %228

228:                                              ; preds = %221, %241
  %229 = phi i32 [ %242, %241 ], [ %220, %221 ]
  %230 = getelementptr inbounds nuw i8, ptr %67, i32 %229
  br label %234

231:                                              ; preds = %234
  %232 = add nuw i32 %235, 1
  %233 = icmp eq i32 %232, %118
  br i1 %233, label %244, label %234, !llvm.loop !176

234:                                              ; preds = %231, %228
  %235 = phi i32 [ %232, %231 ], [ 0, %228 ]
  %236 = getelementptr inbounds nuw i8, ptr %230, i32 %235
  %237 = load i8, ptr %236, align 1, !tbaa !46
  %238 = getelementptr inbounds nuw i8, ptr %116, i32 %235
  %239 = load i8, ptr %238, align 1, !tbaa !46
  %240 = icmp eq i8 %237, %239
  br i1 %240, label %231, label %241

241:                                              ; preds = %234
  %242 = add i32 %229, 1
  %243 = icmp ugt i32 %242, %216
  br i1 %243, label %268, label %228, !llvm.loop !177

244:                                              ; preds = %231
  %245 = load i64, ptr %12, align 8, !tbaa !45
  %246 = getelementptr inbounds nuw i8, ptr %67, i32 %220
  %247 = sub i32 %229, %220
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #28
  store i64 0, ptr %9, align 8, !tbaa !45
  %248 = zext i32 %247 to i64
  %249 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %246, i64 noundef %248, ptr noundef null, i64 noundef 0, ptr noundef nonnull %9) #27
  %250 = icmp eq i32 %249, 0
  br i1 %250, label %252, label %251

251:                                              ; preds = %244
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #28
  br label %291

252:                                              ; preds = %244
  %253 = load i64, ptr %9, align 8, !tbaa !45
  br i1 %119, label %256, label %254

254:                                              ; preds = %252
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  store i64 %253, ptr %8, align 8
  store i32 5, ptr %217, align 8
  store i32 0, ptr %218, align 4
  %255 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %245, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %8, i32 noundef 1) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  br label %258

256:                                              ; preds = %252
  %257 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %245, i64 noundef %253) #27
  br label %258

258:                                              ; preds = %254, %256
  %259 = phi i32 [ %255, %254 ], [ %257, %256 ]
  %260 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %253) #27
  %261 = icmp eq i32 %259, 0
  %262 = select i1 %261, i32 %260, i32 %259
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #28
  %263 = add i32 %229, %118
  %264 = icmp eq i32 %262, 0
  br i1 %264, label %219, label %291, !llvm.loop !178

265:                                              ; preds = %221, %219
  %266 = phi i32 [ 0, %219 ], [ %220, %221 ]
  %267 = sub i32 %69, %266
  br label %268

268:                                              ; preds = %241, %265
  %269 = phi i32 [ %267, %265 ], [ %223, %241 ]
  %270 = phi i32 [ %266, %265 ], [ %220, %241 ]
  %271 = load i64, ptr %12, align 8, !tbaa !45
  %272 = getelementptr inbounds nuw i8, ptr %67, i32 %270
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #28
  store i64 0, ptr %7, align 8, !tbaa !45
  %273 = zext i32 %269 to i64
  %274 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %272, i64 noundef %273, ptr noundef null, i64 noundef 0, ptr noundef nonnull %7) #27
  %275 = icmp eq i32 %274, 0
  br i1 %275, label %276, label %289

276:                                              ; preds = %268
  %277 = load i64, ptr %7, align 8, !tbaa !45
  br i1 %119, label %282, label %278

278:                                              ; preds = %276
  call void @llvm.lifetime.start.p0(ptr nonnull %6)
  store i64 %277, ptr %6, align 8
  %279 = getelementptr inbounds nuw i8, ptr %6, i32 8
  store i32 5, ptr %279, align 8
  %280 = getelementptr inbounds nuw i8, ptr %6, i32 12
  store i32 0, ptr %280, align 4
  %281 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %271, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %6, i32 noundef 1) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %6)
  br label %284

282:                                              ; preds = %276
  %283 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %271, i64 noundef %277) #27
  br label %284

284:                                              ; preds = %282, %278
  %285 = phi i32 [ %281, %278 ], [ %283, %282 ]
  %286 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %277) #27
  %287 = icmp eq i32 %285, 0
  %288 = select i1 %287, i32 %286, i32 %285
  br label %289

289:                                              ; preds = %268, %284
  %290 = phi i32 [ %288, %284 ], [ %274, %268 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #28
  br label %291

291:                                              ; preds = %203, %258, %201, %251, %129, %107, %83, %96, %103, %98, %79, %89, %71, %74, %5, %58, %34, %16, %47, %54, %49, %30, %40, %22, %25, %289, %212
  %292 = phi i32 [ 6, %5 ], [ %125, %212 ], [ 6, %58 ], [ %290, %289 ], [ 0, %129 ], [ 6, %74 ], [ 6, %71 ], [ 1, %89 ], [ 6, %79 ], [ 6, %98 ], [ 6, %103 ], [ 6, %96 ], [ %262, %258 ], [ 6, %83 ], [ 6, %107 ], [ 6, %25 ], [ 6, %22 ], [ 1, %40 ], [ 6, %30 ], [ 6, %49 ], [ 6, %54 ], [ 6, %47 ], [ 5, %16 ], [ 6, %34 ], [ %249, %251 ], [ %202, %201 ], [ %207, %203 ]
  %293 = freeze i32 %292
  %294 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #27
  %295 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #27
  %296 = icmp eq i32 %293, 0
  %297 = icmp eq i32 %294, 0
  %298 = select i1 %297, i32 %295, i32 %294
  %299 = select i1 %296, i32 %298, i32 %293
  %300 = icmp eq i32 %299, 0
  %301 = load i64, ptr %12, align 8, !tbaa !45
  br i1 %300, label %306, label %302

302:                                              ; preds = %291
  %303 = icmp eq i64 %301, 0
  br i1 %303, label %307, label %304

304:                                              ; preds = %302
  %305 = call i32 @nms_release(ptr noundef %0, i64 noundef %301) #27
  br label %307

306:                                              ; preds = %291
  store i64 %301, ptr %3, align 8, !tbaa !45
  br label %307

307:                                              ; preds = %302, %304, %306
  call void @llvm.lifetime.end.p0(ptr nonnull %12) #28
  ret i32 %299
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_split_values_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = tail call fastcc i32 @split_owned(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef %3, i32 noundef 1) #27
  ret i32 %5
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_replace_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i64 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #4 {
  %6 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  store i64 0, ptr %6, align 8, !tbaa !45
  %7 = icmp ne ptr %4, null
  %8 = icmp ne ptr %0, null
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %451

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %12 = load i32, ptr %11, align 8, !tbaa !21
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %451

14:                                               ; preds = %10
  %15 = icmp sgt i64 %1, -1
  br i1 %15, label %41, label %16

16:                                               ; preds = %14
  %17 = and i64 %1, 9223372036854775807
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %451, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %21 = load i32, ptr %20, align 4, !tbaa !18
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %17, %22
  br i1 %23, label %451, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %26 = load ptr, ptr %25, align 8, !tbaa !13
  %27 = icmp eq ptr %26, null
  br i1 %27, label %451, label %28

28:                                               ; preds = %24
  %29 = trunc i64 %1 to i32
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i32 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i32 8
  %32 = load i64, ptr %31, align 8, !tbaa !23
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %451, label %34

34:                                               ; preds = %28
  %35 = getelementptr inbounds nuw i8, ptr %30, i32 28
  %36 = load i32, ptr %35, align 4, !tbaa !26
  %37 = icmp eq i32 %36, 1
  br i1 %37, label %38, label %451

38:                                               ; preds = %34
  %39 = load ptr, ptr %30, align 8, !tbaa !27
  %40 = getelementptr inbounds nuw i8, ptr %30, i32 16
  br label %60

41:                                               ; preds = %14
  %42 = icmp eq i64 %1, 0
  br i1 %42, label %451, label %43

43:                                               ; preds = %41
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %45 = load i32, ptr %44, align 8, !tbaa !12
  %46 = zext i32 %45 to i64
  %47 = icmp samesign ugt i64 %1, %46
  br i1 %47, label %451, label %48

48:                                               ; preds = %43
  %49 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %50 = load ptr, ptr %49, align 4, !tbaa !11
  %51 = icmp eq ptr %50, null
  br i1 %51, label %451, label %52

52:                                               ; preds = %48
  %53 = trunc nuw i64 %1 to i32
  %54 = getelementptr %struct.NmsView, ptr %50, i32 %53
  %55 = getelementptr i8, ptr %54, i32 -8
  %56 = load ptr, ptr %55, align 4, !tbaa !28
  %57 = icmp eq ptr %56, null
  br i1 %57, label %451, label %58

58:                                               ; preds = %52
  %59 = getelementptr i8, ptr %54, i32 -4
  br label %60

60:                                               ; preds = %58, %38
  %61 = phi ptr [ %56, %58 ], [ %39, %38 ]
  %62 = phi ptr [ %59, %58 ], [ %40, %38 ]
  %63 = load i32, ptr %62, align 4, !tbaa !1
  %64 = freeze i32 %63
  %65 = icmp sgt i64 %2, -1
  br i1 %65, label %91, label %66

66:                                               ; preds = %60
  %67 = and i64 %2, 9223372036854775807
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %451, label %69

69:                                               ; preds = %66
  %70 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %71 = load i32, ptr %70, align 4, !tbaa !18
  %72 = zext i32 %71 to i64
  %73 = icmp samesign ugt i64 %67, %72
  br i1 %73, label %451, label %74

74:                                               ; preds = %69
  %75 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %76 = load ptr, ptr %75, align 8, !tbaa !13
  %77 = icmp eq ptr %76, null
  br i1 %77, label %451, label %78

78:                                               ; preds = %74
  %79 = trunc i64 %2 to i32
  %80 = getelementptr inbounds nuw %struct.NmsSlot, ptr %76, i32 %79
  %81 = getelementptr inbounds nuw i8, ptr %80, i32 8
  %82 = load i64, ptr %81, align 8, !tbaa !23
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %451, label %84

84:                                               ; preds = %78
  %85 = getelementptr inbounds nuw i8, ptr %80, i32 28
  %86 = load i32, ptr %85, align 4, !tbaa !26
  %87 = icmp eq i32 %86, 1
  br i1 %87, label %88, label %451

88:                                               ; preds = %84
  %89 = load ptr, ptr %80, align 8, !tbaa !27
  %90 = getelementptr inbounds nuw i8, ptr %80, i32 16
  br label %110

91:                                               ; preds = %60
  %92 = icmp eq i64 %2, 0
  br i1 %92, label %451, label %93

93:                                               ; preds = %91
  %94 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %95 = load i32, ptr %94, align 8, !tbaa !12
  %96 = zext i32 %95 to i64
  %97 = icmp samesign ugt i64 %2, %96
  br i1 %97, label %451, label %98

98:                                               ; preds = %93
  %99 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %100 = load ptr, ptr %99, align 4, !tbaa !11
  %101 = icmp eq ptr %100, null
  br i1 %101, label %451, label %102

102:                                              ; preds = %98
  %103 = trunc nuw i64 %2 to i32
  %104 = getelementptr %struct.NmsView, ptr %100, i32 %103
  %105 = getelementptr i8, ptr %104, i32 -8
  %106 = load ptr, ptr %105, align 4, !tbaa !28
  %107 = icmp eq ptr %106, null
  br i1 %107, label %451, label %108

108:                                              ; preds = %102
  %109 = getelementptr i8, ptr %104, i32 -4
  br label %110

110:                                              ; preds = %108, %88
  %111 = phi ptr [ %106, %108 ], [ %89, %88 ]
  %112 = phi ptr [ %109, %108 ], [ %90, %88 ]
  %113 = load i32, ptr %112, align 4, !tbaa !1
  %114 = freeze i32 %113
  %115 = icmp sgt i64 %3, -1
  br i1 %115, label %141, label %116

116:                                              ; preds = %110
  %117 = and i64 %3, 9223372036854775807
  %118 = icmp eq i64 %117, 0
  br i1 %118, label %451, label %119

119:                                              ; preds = %116
  %120 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %121 = load i32, ptr %120, align 4, !tbaa !18
  %122 = zext i32 %121 to i64
  %123 = icmp samesign ugt i64 %117, %122
  br i1 %123, label %451, label %124

124:                                              ; preds = %119
  %125 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %126 = load ptr, ptr %125, align 8, !tbaa !13
  %127 = icmp eq ptr %126, null
  br i1 %127, label %451, label %128

128:                                              ; preds = %124
  %129 = trunc i64 %3 to i32
  %130 = getelementptr inbounds nuw %struct.NmsSlot, ptr %126, i32 %129
  %131 = getelementptr inbounds nuw i8, ptr %130, i32 8
  %132 = load i64, ptr %131, align 8, !tbaa !23
  %133 = icmp eq i64 %132, 0
  br i1 %133, label %451, label %134

134:                                              ; preds = %128
  %135 = getelementptr inbounds nuw i8, ptr %130, i32 28
  %136 = load i32, ptr %135, align 4, !tbaa !26
  %137 = icmp eq i32 %136, 1
  br i1 %137, label %138, label %451

138:                                              ; preds = %134
  %139 = load ptr, ptr %130, align 8, !tbaa !27
  %140 = getelementptr inbounds nuw i8, ptr %130, i32 16
  br label %160

141:                                              ; preds = %110
  %142 = icmp eq i64 %3, 0
  br i1 %142, label %451, label %143

143:                                              ; preds = %141
  %144 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %145 = load i32, ptr %144, align 8, !tbaa !12
  %146 = zext i32 %145 to i64
  %147 = icmp samesign ugt i64 %3, %146
  br i1 %147, label %451, label %148

148:                                              ; preds = %143
  %149 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %150 = load ptr, ptr %149, align 4, !tbaa !11
  %151 = icmp eq ptr %150, null
  br i1 %151, label %451, label %152

152:                                              ; preds = %148
  %153 = trunc nuw i64 %3 to i32
  %154 = getelementptr %struct.NmsView, ptr %150, i32 %153
  %155 = getelementptr i8, ptr %154, i32 -8
  %156 = load ptr, ptr %155, align 4, !tbaa !28
  %157 = icmp eq ptr %156, null
  br i1 %157, label %451, label %158

158:                                              ; preds = %152
  %159 = getelementptr i8, ptr %154, i32 -4
  br label %160

160:                                              ; preds = %138, %158
  %161 = phi ptr [ %156, %158 ], [ %139, %138 ]
  %162 = phi ptr [ %159, %158 ], [ %140, %138 ]
  %163 = load i32, ptr %162, align 4, !tbaa !1
  %164 = freeze i32 %163
  %165 = icmp eq i32 %114, 0
  br i1 %165, label %170, label %166

166:                                              ; preds = %160
  %167 = icmp ugt i32 %114, %64
  br i1 %167, label %205, label %168

168:                                              ; preds = %166
  %169 = sub nuw i32 %64, %114
  br label %173

170:                                              ; preds = %160
  %171 = zext i32 %64 to i64
  %172 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %61, i64 noundef %171, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #27
  br label %451

173:                                              ; preds = %168, %193
  %174 = phi i64 [ 0, %168 ], [ %194, %193 ]
  %175 = phi i32 [ 0, %168 ], [ %195, %193 ]
  %176 = icmp ugt i32 %175, %169
  br i1 %176, label %200, label %177

177:                                              ; preds = %173, %190
  %178 = phi i32 [ %191, %190 ], [ %175, %173 ]
  %179 = getelementptr inbounds nuw i8, ptr %61, i32 %178
  br label %183

180:                                              ; preds = %183
  %181 = add nuw i32 %184, 1
  %182 = icmp eq i32 %181, %114
  br i1 %182, label %193, label %183, !llvm.loop !176

183:                                              ; preds = %180, %177
  %184 = phi i32 [ %181, %180 ], [ 0, %177 ]
  %185 = getelementptr inbounds nuw i8, ptr %179, i32 %184
  %186 = load i8, ptr %185, align 1, !tbaa !46
  %187 = getelementptr inbounds nuw i8, ptr %111, i32 %184
  %188 = load i8, ptr %187, align 1, !tbaa !46
  %189 = icmp eq i8 %186, %188
  br i1 %189, label %180, label %190

190:                                              ; preds = %183
  %191 = add nuw i32 %178, 1
  %192 = icmp ult i32 %178, %169
  br i1 %192, label %177, label %200, !llvm.loop !177

193:                                              ; preds = %180
  %194 = add i64 %174, 1
  %195 = add i32 %178, %114
  %196 = icmp ugt i32 %195, %64
  %197 = sub nuw i32 %64, %195
  %198 = icmp ugt i32 %114, %197
  %199 = select i1 %196, i1 true, i1 %198
  br i1 %199, label %200, label %173, !llvm.loop !179

200:                                              ; preds = %173, %193, %190
  %201 = phi i64 [ %174, %190 ], [ %194, %193 ], [ %174, %173 ]
  %202 = udiv i32 %64, %114
  %203 = zext i32 %202 to i64
  %204 = icmp ugt i64 %201, %203
  br i1 %204, label %451, label %205

205:                                              ; preds = %166, %200
  %206 = phi i64 [ %201, %200 ], [ 0, %166 ]
  %207 = trunc nuw i64 %206 to i32
  %208 = mul i32 %114, %207
  %209 = sub i32 %64, %208
  %210 = icmp eq i32 %164, 0
  br i1 %210, label %216, label %211

211:                                              ; preds = %205
  %212 = xor i32 %209, -1
  %213 = udiv i32 %212, %164
  %214 = zext i32 %213 to i64
  %215 = icmp samesign ugt i64 %206, %214
  br i1 %215, label %451, label %216

216:                                              ; preds = %205, %211
  %217 = mul i32 %164, %207
  %218 = add i32 %209, %217
  %219 = icmp eq i32 %218, -1
  br i1 %219, label %451, label %220

220:                                              ; preds = %216
  %221 = zext i32 %218 to i64
  %222 = add nuw nsw i64 %221, 1
  %223 = tail call fastcc ptr @allocate(i64 noundef %222) #27
  %224 = icmp eq ptr %223, null
  br i1 %224, label %451, label %225

225:                                              ; preds = %220
  br i1 %167, label %354, label %226

226:                                              ; preds = %225
  %227 = sub nuw i32 %64, %114
  %228 = zext i32 %164 to i64
  %229 = and i64 %228, 3
  %230 = icmp ult i32 %164, 4
  %231 = and i64 %228, 4294967292
  %232 = icmp eq i64 %229, 0
  %233 = icmp ne i64 %229, 0
  br label %234

234:                                              ; preds = %226, %347
  %235 = phi i32 [ 0, %226 ], [ %348, %347 ]
  %236 = phi i32 [ 0, %226 ], [ %349, %347 ]
  %237 = icmp ugt i32 %236, %227
  br i1 %237, label %354, label %238

238:                                              ; preds = %234, %251
  %239 = phi i32 [ %252, %251 ], [ %236, %234 ]
  %240 = getelementptr inbounds nuw i8, ptr %61, i32 %239
  br label %244

241:                                              ; preds = %244
  %242 = add nuw i32 %245, 1
  %243 = icmp eq i32 %242, %114
  br i1 %243, label %254, label %244, !llvm.loop !176

244:                                              ; preds = %241, %238
  %245 = phi i32 [ %242, %241 ], [ 0, %238 ]
  %246 = getelementptr inbounds nuw i8, ptr %240, i32 %245
  %247 = load i8, ptr %246, align 1, !tbaa !46
  %248 = getelementptr inbounds nuw i8, ptr %111, i32 %245
  %249 = load i8, ptr %248, align 1, !tbaa !46
  %250 = icmp eq i8 %247, %249
  br i1 %250, label %241, label %251

251:                                              ; preds = %244
  %252 = add i32 %239, 1
  %253 = icmp ult i32 %239, %227
  br i1 %253, label %238, label %354, !llvm.loop !177

254:                                              ; preds = %241
  %255 = sub i32 %239, %236
  %256 = getelementptr inbounds nuw i8, ptr %223, i32 %235
  %257 = getelementptr inbounds nuw i8, ptr %61, i32 %236
  %258 = icmp eq i32 %239, %236
  br i1 %258, label %305, label %259

259:                                              ; preds = %254
  %260 = zext i32 %255 to i64
  %261 = and i64 %260, 3
  %262 = icmp ult i32 %255, 4
  br i1 %262, label %292, label %263

263:                                              ; preds = %259
  %264 = and i64 %260, 4294967292
  br label %265

265:                                              ; preds = %265, %263
  %266 = phi i64 [ 0, %263 ], [ %287, %265 ]
  %267 = phi i64 [ 0, %263 ], [ %288, %265 ]
  %268 = trunc i64 %266 to i32
  %269 = getelementptr inbounds nuw i8, ptr %257, i32 %268
  %270 = load volatile i8, ptr %269, align 1, !tbaa !46
  %271 = getelementptr inbounds nuw i8, ptr %256, i32 %268
  store volatile i8 %270, ptr %271, align 1, !tbaa !46
  %272 = trunc i64 %266 to i32
  %273 = or disjoint i32 %272, 1
  %274 = getelementptr inbounds nuw i8, ptr %257, i32 %273
  %275 = load volatile i8, ptr %274, align 1, !tbaa !46
  %276 = getelementptr inbounds nuw i8, ptr %256, i32 %273
  store volatile i8 %275, ptr %276, align 1, !tbaa !46
  %277 = trunc i64 %266 to i32
  %278 = or disjoint i32 %277, 2
  %279 = getelementptr inbounds nuw i8, ptr %257, i32 %278
  %280 = load volatile i8, ptr %279, align 1, !tbaa !46
  %281 = getelementptr inbounds nuw i8, ptr %256, i32 %278
  store volatile i8 %280, ptr %281, align 1, !tbaa !46
  %282 = trunc i64 %266 to i32
  %283 = or disjoint i32 %282, 3
  %284 = getelementptr inbounds nuw i8, ptr %257, i32 %283
  %285 = load volatile i8, ptr %284, align 1, !tbaa !46
  %286 = getelementptr inbounds nuw i8, ptr %256, i32 %283
  store volatile i8 %285, ptr %286, align 1, !tbaa !46
  %287 = add nuw nsw i64 %266, 4
  %288 = add i64 %267, 4
  %289 = icmp eq i64 %288, %264
  br i1 %289, label %290, label %265, !llvm.loop !47

290:                                              ; preds = %265
  %291 = icmp eq i64 %261, 0
  br i1 %291, label %305, label %292

292:                                              ; preds = %290, %259
  %293 = phi i64 [ 0, %259 ], [ %287, %290 ]
  %294 = icmp ne i64 %261, 0
  tail call void @llvm.assume(i1 %294)
  br label %295

295:                                              ; preds = %295, %292
  %296 = phi i64 [ %302, %295 ], [ %293, %292 ]
  %297 = phi i64 [ %303, %295 ], [ 0, %292 ]
  %298 = trunc i64 %296 to i32
  %299 = getelementptr inbounds nuw i8, ptr %257, i32 %298
  %300 = load volatile i8, ptr %299, align 1, !tbaa !46
  %301 = getelementptr inbounds nuw i8, ptr %256, i32 %298
  store volatile i8 %300, ptr %301, align 1, !tbaa !46
  %302 = add nuw nsw i64 %296, 1
  %303 = add i64 %297, 1
  %304 = icmp eq i64 %303, %261
  br i1 %304, label %305, label %295, !llvm.loop !180

305:                                              ; preds = %290, %295, %254
  %306 = add i32 %255, %235
  %307 = getelementptr inbounds nuw i8, ptr %223, i32 %306
  br i1 %210, label %347, label %308

308:                                              ; preds = %305
  br i1 %230, label %335, label %309

309:                                              ; preds = %308, %309
  %310 = phi i64 [ %331, %309 ], [ 0, %308 ]
  %311 = phi i64 [ %332, %309 ], [ 0, %308 ]
  %312 = trunc i64 %310 to i32
  %313 = getelementptr inbounds nuw i8, ptr %161, i32 %312
  %314 = load volatile i8, ptr %313, align 1, !tbaa !46
  %315 = getelementptr inbounds nuw i8, ptr %307, i32 %312
  store volatile i8 %314, ptr %315, align 1, !tbaa !46
  %316 = trunc i64 %310 to i32
  %317 = or disjoint i32 %316, 1
  %318 = getelementptr inbounds nuw i8, ptr %161, i32 %317
  %319 = load volatile i8, ptr %318, align 1, !tbaa !46
  %320 = getelementptr inbounds nuw i8, ptr %307, i32 %317
  store volatile i8 %319, ptr %320, align 1, !tbaa !46
  %321 = trunc i64 %310 to i32
  %322 = or disjoint i32 %321, 2
  %323 = getelementptr inbounds nuw i8, ptr %161, i32 %322
  %324 = load volatile i8, ptr %323, align 1, !tbaa !46
  %325 = getelementptr inbounds nuw i8, ptr %307, i32 %322
  store volatile i8 %324, ptr %325, align 1, !tbaa !46
  %326 = trunc i64 %310 to i32
  %327 = or disjoint i32 %326, 3
  %328 = getelementptr inbounds nuw i8, ptr %161, i32 %327
  %329 = load volatile i8, ptr %328, align 1, !tbaa !46
  %330 = getelementptr inbounds nuw i8, ptr %307, i32 %327
  store volatile i8 %329, ptr %330, align 1, !tbaa !46
  %331 = add nuw nsw i64 %310, 4
  %332 = add i64 %311, 4
  %333 = icmp eq i64 %332, %231
  br i1 %333, label %334, label %309, !llvm.loop !47

334:                                              ; preds = %309
  br i1 %232, label %347, label %335

335:                                              ; preds = %334, %308
  %336 = phi i64 [ 0, %308 ], [ %331, %334 ]
  tail call void @llvm.assume(i1 %233)
  br label %337

337:                                              ; preds = %337, %335
  %338 = phi i64 [ %344, %337 ], [ %336, %335 ]
  %339 = phi i64 [ %345, %337 ], [ 0, %335 ]
  %340 = trunc i64 %338 to i32
  %341 = getelementptr inbounds nuw i8, ptr %161, i32 %340
  %342 = load volatile i8, ptr %341, align 1, !tbaa !46
  %343 = getelementptr inbounds nuw i8, ptr %307, i32 %340
  store volatile i8 %342, ptr %343, align 1, !tbaa !46
  %344 = add nuw nsw i64 %338, 1
  %345 = add i64 %339, 1
  %346 = icmp eq i64 %345, %229
  br i1 %346, label %347, label %337, !llvm.loop !181

347:                                              ; preds = %334, %337, %305
  %348 = add i32 %306, %164
  %349 = add i32 %239, %114
  %350 = icmp ugt i32 %349, %64
  %351 = sub nuw i32 %64, %349
  %352 = icmp ugt i32 %114, %351
  %353 = select i1 %350, i1 true, i1 %352
  br i1 %353, label %354, label %234, !llvm.loop !182

354:                                              ; preds = %234, %347, %251, %225
  %355 = phi i32 [ %236, %251 ], [ 0, %225 ], [ %236, %234 ], [ %349, %347 ]
  %356 = phi i32 [ %235, %251 ], [ 0, %225 ], [ %235, %234 ], [ %348, %347 ]
  %357 = freeze i32 %355
  %358 = getelementptr inbounds nuw i8, ptr %223, i32 %356
  %359 = getelementptr inbounds nuw i8, ptr %61, i32 %357
  %360 = icmp eq i32 %64, %357
  br i1 %360, label %408, label %361

361:                                              ; preds = %354
  %362 = sub i32 %64, %357
  %363 = zext i32 %362 to i64
  %364 = and i64 %363, 3
  %365 = icmp ult i32 %362, 4
  br i1 %365, label %395, label %366

366:                                              ; preds = %361
  %367 = and i64 %363, 4294967292
  br label %368

368:                                              ; preds = %368, %366
  %369 = phi i64 [ 0, %366 ], [ %390, %368 ]
  %370 = phi i64 [ 0, %366 ], [ %391, %368 ]
  %371 = trunc i64 %369 to i32
  %372 = getelementptr inbounds nuw i8, ptr %359, i32 %371
  %373 = load volatile i8, ptr %372, align 1, !tbaa !46
  %374 = getelementptr inbounds nuw i8, ptr %358, i32 %371
  store volatile i8 %373, ptr %374, align 1, !tbaa !46
  %375 = trunc i64 %369 to i32
  %376 = or disjoint i32 %375, 1
  %377 = getelementptr inbounds nuw i8, ptr %359, i32 %376
  %378 = load volatile i8, ptr %377, align 1, !tbaa !46
  %379 = getelementptr inbounds nuw i8, ptr %358, i32 %376
  store volatile i8 %378, ptr %379, align 1, !tbaa !46
  %380 = trunc i64 %369 to i32
  %381 = or disjoint i32 %380, 2
  %382 = getelementptr inbounds nuw i8, ptr %359, i32 %381
  %383 = load volatile i8, ptr %382, align 1, !tbaa !46
  %384 = getelementptr inbounds nuw i8, ptr %358, i32 %381
  store volatile i8 %383, ptr %384, align 1, !tbaa !46
  %385 = trunc i64 %369 to i32
  %386 = or disjoint i32 %385, 3
  %387 = getelementptr inbounds nuw i8, ptr %359, i32 %386
  %388 = load volatile i8, ptr %387, align 1, !tbaa !46
  %389 = getelementptr inbounds nuw i8, ptr %358, i32 %386
  store volatile i8 %388, ptr %389, align 1, !tbaa !46
  %390 = add nuw nsw i64 %369, 4
  %391 = add i64 %370, 4
  %392 = icmp eq i64 %391, %367
  br i1 %392, label %393, label %368, !llvm.loop !47

393:                                              ; preds = %368
  %394 = icmp eq i64 %364, 0
  br i1 %394, label %408, label %395

395:                                              ; preds = %393, %361
  %396 = phi i64 [ 0, %361 ], [ %390, %393 ]
  %397 = icmp ne i64 %364, 0
  tail call void @llvm.assume(i1 %397)
  br label %398

398:                                              ; preds = %398, %395
  %399 = phi i64 [ %405, %398 ], [ %396, %395 ]
  %400 = phi i64 [ %406, %398 ], [ 0, %395 ]
  %401 = trunc i64 %399 to i32
  %402 = getelementptr inbounds nuw i8, ptr %359, i32 %401
  %403 = load volatile i8, ptr %402, align 1, !tbaa !46
  %404 = getelementptr inbounds nuw i8, ptr %358, i32 %401
  store volatile i8 %403, ptr %404, align 1, !tbaa !46
  %405 = add nuw nsw i64 %399, 1
  %406 = add i64 %400, 1
  %407 = icmp eq i64 %406, %364
  br i1 %407, label %408, label %398, !llvm.loop !183

408:                                              ; preds = %393, %398, %354
  %409 = getelementptr inbounds nuw i8, ptr %223, i32 %218
  store i8 0, ptr %409, align 1, !tbaa !46
  %410 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef nonnull %223, i64 noundef %221, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #27
  %411 = getelementptr inbounds i8, ptr %223, i32 -16
  br label %412

412:                                              ; preds = %412, %408
  %413 = phi ptr [ null, %408 ], [ %415, %412 ]
  %414 = phi ptr [ @free_blocks, %408 ], [ %419, %412 ]
  %415 = load ptr, ptr %414, align 4, !tbaa !31
  %416 = icmp ne ptr %415, null
  %417 = icmp ult ptr %415, %411
  %418 = and i1 %416, %417
  %419 = getelementptr inbounds nuw i8, ptr %415, i32 8
  br i1 %418, label %412, label %420, !llvm.loop !33

420:                                              ; preds = %412
  %421 = ptrtoint ptr %411 to i32
  %422 = getelementptr inbounds i8, ptr %223, i32 -8
  store ptr %415, ptr %422, align 8, !tbaa !35
  br i1 %416, label %423, label %434

423:                                              ; preds = %420
  %424 = ptrtoint ptr %415 to i32
  %425 = zext i32 %421 to i64
  %426 = load i64, ptr %411, align 8, !tbaa !37
  %427 = add i64 %426, %425
  %428 = zext i32 %424 to i64
  %429 = icmp eq i64 %427, %428
  br i1 %429, label %430, label %434

430:                                              ; preds = %423
  %431 = load i64, ptr %415, align 8, !tbaa !37
  %432 = add i64 %431, %426
  store i64 %432, ptr %411, align 8, !tbaa !37
  %433 = load ptr, ptr %419, align 8, !tbaa !35
  store ptr %433, ptr %422, align 8, !tbaa !35
  br label %434

434:                                              ; preds = %430, %423, %420
  %435 = phi ptr [ %433, %430 ], [ %415, %423 ], [ null, %420 ]
  %436 = icmp eq ptr %413, null
  br i1 %436, label %450, label %437

437:                                              ; preds = %434
  %438 = ptrtoint ptr %413 to i32
  %439 = zext i32 %438 to i64
  %440 = load i64, ptr %413, align 8, !tbaa !37
  %441 = add i64 %440, %439
  %442 = zext i32 %421 to i64
  %443 = icmp eq i64 %441, %442
  br i1 %443, label %444, label %448

444:                                              ; preds = %437
  %445 = load i64, ptr %411, align 8, !tbaa !37
  %446 = add i64 %445, %440
  store i64 %446, ptr %413, align 8, !tbaa !37
  %447 = getelementptr inbounds nuw i8, ptr %413, i32 8
  store ptr %435, ptr %447, align 8, !tbaa !35
  br label %451

448:                                              ; preds = %437
  %449 = getelementptr inbounds nuw i8, ptr %413, i32 8
  store ptr %411, ptr %449, align 8, !tbaa !35
  br label %451

450:                                              ; preds = %434
  store ptr %411, ptr @free_blocks, align 4, !tbaa !31
  br label %451

451:                                              ; preds = %220, %216, %211, %200, %19, %16, %34, %24, %43, %48, %41, %10, %28, %52, %5, %69, %66, %84, %74, %93, %98, %91, %78, %102, %116, %134, %124, %143, %148, %141, %128, %152, %170, %119, %444, %448, %450
  %452 = phi i32 [ %410, %448 ], [ %410, %450 ], [ %410, %444 ], [ 6, %5 ], [ 6, %152 ], [ 6, %128 ], [ 6, %200 ], [ 6, %141 ], [ 6, %148 ], [ 6, %143 ], [ 6, %124 ], [ 1, %134 ], [ 6, %116 ], [ 6, %119 ], [ %172, %170 ], [ 6, %69 ], [ 6, %66 ], [ 1, %84 ], [ 6, %74 ], [ 6, %93 ], [ 6, %98 ], [ 6, %91 ], [ 3, %211 ], [ 6, %78 ], [ 6, %102 ], [ 6, %19 ], [ 6, %16 ], [ 1, %34 ], [ 6, %24 ], [ 6, %43 ], [ 6, %48 ], [ 6, %41 ], [ 5, %10 ], [ 6, %28 ], [ 6, %52 ], [ 3, %220 ], [ 3, %216 ]
  %453 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #27
  %454 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #27
  %455 = call i32 @nms_release(ptr noundef %0, i64 noundef %3) #27
  %456 = icmp eq i32 %452, 0
  br i1 %456, label %457, label %469

457:                                              ; preds = %451
  %458 = icmp ne i32 %453, 0
  %459 = icmp ne i32 %454, 0
  %460 = select i1 %458, i1 true, i1 %459
  %461 = icmp ne i32 %455, 0
  %462 = select i1 %460, i1 true, i1 %461
  %463 = load i64, ptr %6, align 8, !tbaa !45
  br i1 %462, label %464, label %468

464:                                              ; preds = %457
  %465 = call i32 @nms_release(ptr noundef %0, i64 noundef %463) #27
  %466 = select i1 %459, i32 %454, i32 %455
  %467 = select i1 %458, i32 %453, i32 %466
  br label %469

468:                                              ; preds = %457
  store i64 %463, ptr %4, align 8, !tbaa !45
  br label %469

469:                                              ; preds = %451, %468, %464
  %470 = phi i32 [ 0, %468 ], [ %467, %464 ], [ %452, %451 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  ret i32 %470
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_char_at(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #1 {
  %6 = icmp ne ptr %4, null
  %7 = icmp ult i32 %3, 2
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %78

11:                                               ; preds = %5
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %13 = load i32, ptr %12, align 8, !tbaa !21
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %78

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %42, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %78, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %22 = load i32, ptr %21, align 4, !tbaa !18
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %78, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %27 = load ptr, ptr %26, align 8, !tbaa !13
  %28 = icmp eq ptr %27, null
  br i1 %28, label %78, label %29

29:                                               ; preds = %25
  %30 = trunc i64 %1 to i32
  %31 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i32 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i32 8
  %33 = load i64, ptr %32, align 8, !tbaa !23
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %78, label %35

35:                                               ; preds = %29
  %36 = getelementptr inbounds nuw i8, ptr %31, i32 28
  %37 = load i32, ptr %36, align 4, !tbaa !26
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %78

39:                                               ; preds = %35
  %40 = load ptr, ptr %31, align 8, !tbaa !27
  %41 = getelementptr inbounds nuw i8, ptr %31, i32 16
  br label %61

42:                                               ; preds = %15
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %78, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %46 = load i32, ptr %45, align 8, !tbaa !12
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %78, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %51 = load ptr, ptr %50, align 4, !tbaa !11
  %52 = icmp eq ptr %51, null
  br i1 %52, label %78, label %53

53:                                               ; preds = %49
  %54 = trunc nuw i64 %1 to i32
  %55 = getelementptr %struct.NmsView, ptr %51, i32 %54
  %56 = getelementptr i8, ptr %55, i32 -8
  %57 = load ptr, ptr %56, align 4, !tbaa !28
  %58 = icmp eq ptr %57, null
  br i1 %58, label %78, label %59

59:                                               ; preds = %53
  %60 = getelementptr i8, ptr %55, i32 -4
  br label %61

61:                                               ; preds = %59, %39
  %62 = phi ptr [ %57, %59 ], [ %40, %39 ]
  %63 = phi ptr [ %60, %59 ], [ %41, %39 ]
  %64 = load i32, ptr %63, align 4, !tbaa !1
  %65 = icmp eq i32 %3, 0
  %66 = select i1 %65, i64 0, i64 %2
  %67 = icmp sgt i64 %66, -1
  %68 = zext i32 %64 to i64
  %69 = icmp samesign ult i64 %66, %68
  %70 = select i1 %67, i1 %69, i1 false
  br i1 %70, label %71, label %76

71:                                               ; preds = %61
  %72 = trunc nuw i64 %66 to i32
  %73 = getelementptr inbounds nuw i8, ptr %62, i32 %72
  %74 = load i8, ptr %73, align 1, !tbaa !46
  %75 = zext i8 %74 to i64
  br label %76

76:                                               ; preds = %61, %71
  %77 = phi i64 [ %75, %71 ], [ -1, %61 ]
  store i64 %77, ptr %4, align 8, !tbaa !45
  br label %78

78:                                               ; preds = %20, %17, %35, %25, %44, %49, %42, %11, %29, %53, %76, %5
  %79 = phi i32 [ 6, %5 ], [ 0, %76 ], [ 6, %20 ], [ 6, %17 ], [ 1, %35 ], [ 6, %25 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %11 ], [ 6, %29 ], [ 6, %53 ]
  ret i32 %79
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_predicate(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #11 {
  %6 = icmp ne ptr %4, null
  %7 = icmp ult i32 %3, 3
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %159

11:                                               ; preds = %5
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 64
  %13 = load i32, ptr %12, align 8, !tbaa !21
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %159

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %42, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %159, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %22 = load i32, ptr %21, align 4, !tbaa !18
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %159, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %27 = load ptr, ptr %26, align 8, !tbaa !13
  %28 = icmp eq ptr %27, null
  br i1 %28, label %159, label %29

29:                                               ; preds = %25
  %30 = trunc i64 %1 to i32
  %31 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i32 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i32 8
  %33 = load i64, ptr %32, align 8, !tbaa !23
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %159, label %35

35:                                               ; preds = %29
  %36 = getelementptr inbounds nuw i8, ptr %31, i32 28
  %37 = load i32, ptr %36, align 4, !tbaa !26
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %159

39:                                               ; preds = %35
  %40 = load ptr, ptr %31, align 8, !tbaa !27
  %41 = getelementptr inbounds nuw i8, ptr %31, i32 16
  br label %61

42:                                               ; preds = %15
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %159, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %46 = load i32, ptr %45, align 8, !tbaa !12
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %159, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %51 = load ptr, ptr %50, align 4, !tbaa !11
  %52 = icmp eq ptr %51, null
  br i1 %52, label %159, label %53

53:                                               ; preds = %49
  %54 = trunc nuw i64 %1 to i32
  %55 = getelementptr %struct.NmsView, ptr %51, i32 %54
  %56 = getelementptr i8, ptr %55, i32 -8
  %57 = load ptr, ptr %56, align 4, !tbaa !28
  %58 = icmp eq ptr %57, null
  br i1 %58, label %159, label %59

59:                                               ; preds = %53
  %60 = getelementptr i8, ptr %55, i32 -4
  br label %61

61:                                               ; preds = %59, %39
  %62 = phi ptr [ %57, %59 ], [ %40, %39 ]
  %63 = phi ptr [ %60, %59 ], [ %41, %39 ]
  %64 = load i32, ptr %63, align 4, !tbaa !1
  %65 = icmp sgt i64 %2, -1
  br i1 %65, label %91, label %66

66:                                               ; preds = %61
  %67 = and i64 %2, 9223372036854775807
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %159, label %69

69:                                               ; preds = %66
  %70 = getelementptr inbounds nuw i8, ptr %0, i32 52
  %71 = load i32, ptr %70, align 4, !tbaa !18
  %72 = zext i32 %71 to i64
  %73 = icmp samesign ugt i64 %67, %72
  br i1 %73, label %159, label %74

74:                                               ; preds = %69
  %75 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %76 = load ptr, ptr %75, align 8, !tbaa !13
  %77 = icmp eq ptr %76, null
  br i1 %77, label %159, label %78

78:                                               ; preds = %74
  %79 = trunc i64 %2 to i32
  %80 = getelementptr inbounds nuw %struct.NmsSlot, ptr %76, i32 %79
  %81 = getelementptr inbounds nuw i8, ptr %80, i32 8
  %82 = load i64, ptr %81, align 8, !tbaa !23
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %159, label %84

84:                                               ; preds = %78
  %85 = getelementptr inbounds nuw i8, ptr %80, i32 28
  %86 = load i32, ptr %85, align 4, !tbaa !26
  %87 = icmp eq i32 %86, 1
  br i1 %87, label %88, label %159

88:                                               ; preds = %84
  %89 = load ptr, ptr %80, align 8, !tbaa !27
  %90 = getelementptr inbounds nuw i8, ptr %80, i32 16
  br label %110

91:                                               ; preds = %61
  %92 = icmp eq i64 %2, 0
  br i1 %92, label %159, label %93

93:                                               ; preds = %91
  %94 = getelementptr inbounds nuw i8, ptr %0, i32 48
  %95 = load i32, ptr %94, align 8, !tbaa !12
  %96 = zext i32 %95 to i64
  %97 = icmp samesign ugt i64 %2, %96
  br i1 %97, label %159, label %98

98:                                               ; preds = %93
  %99 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %100 = load ptr, ptr %99, align 4, !tbaa !11
  %101 = icmp eq ptr %100, null
  br i1 %101, label %159, label %102

102:                                              ; preds = %98
  %103 = trunc nuw i64 %2 to i32
  %104 = getelementptr %struct.NmsView, ptr %100, i32 %103
  %105 = getelementptr i8, ptr %104, i32 -8
  %106 = load ptr, ptr %105, align 4, !tbaa !28
  %107 = icmp eq ptr %106, null
  br i1 %107, label %159, label %108

108:                                              ; preds = %102
  %109 = getelementptr i8, ptr %104, i32 -4
  br label %110

110:                                              ; preds = %108, %88
  %111 = phi ptr [ %106, %108 ], [ %89, %88 ]
  %112 = phi ptr [ %109, %108 ], [ %90, %88 ]
  %113 = load i32, ptr %112, align 4, !tbaa !1
  %114 = icmp eq i32 %113, 0
  br i1 %114, label %157, label %115

115:                                              ; preds = %110
  %116 = icmp ugt i32 %113, %64
  br i1 %116, label %157, label %117

117:                                              ; preds = %115
  %118 = sub nuw i32 %64, %113
  switch i32 %3, label %141 [
    i32 1, label %122
    i32 2, label %129
  ]

119:                                              ; preds = %122
  %120 = add nuw i32 %123, 1
  %121 = icmp eq i32 %120, %113
  br i1 %121, label %157, label %122, !llvm.loop !176

122:                                              ; preds = %117, %119
  %123 = phi i32 [ %120, %119 ], [ 0, %117 ]
  %124 = getelementptr inbounds nuw i8, ptr %62, i32 %123
  %125 = load i8, ptr %124, align 1, !tbaa !46
  %126 = getelementptr inbounds nuw i8, ptr %111, i32 %123
  %127 = load i8, ptr %126, align 1, !tbaa !46
  %128 = icmp eq i8 %125, %127
  br i1 %128, label %119, label %157

129:                                              ; preds = %117
  %130 = getelementptr inbounds nuw i8, ptr %62, i32 %118
  br label %134

131:                                              ; preds = %134
  %132 = add nuw i32 %135, 1
  %133 = icmp eq i32 %132, %113
  br i1 %133, label %157, label %134, !llvm.loop !176

134:                                              ; preds = %129, %131
  %135 = phi i32 [ %132, %131 ], [ 0, %129 ]
  %136 = getelementptr inbounds nuw i8, ptr %130, i32 %135
  %137 = load i8, ptr %136, align 1, !tbaa !46
  %138 = getelementptr inbounds nuw i8, ptr %111, i32 %135
  %139 = load i8, ptr %138, align 1, !tbaa !46
  %140 = icmp eq i8 %137, %139
  br i1 %140, label %131, label %157

141:                                              ; preds = %117, %154
  %142 = phi i32 [ %155, %154 ], [ 0, %117 ]
  %143 = getelementptr inbounds nuw i8, ptr %62, i32 %142
  br label %147

144:                                              ; preds = %147
  %145 = add nuw i32 %148, 1
  %146 = icmp eq i32 %145, %113
  br i1 %146, label %157, label %147, !llvm.loop !176

147:                                              ; preds = %141, %144
  %148 = phi i32 [ %145, %144 ], [ 0, %141 ]
  %149 = getelementptr inbounds nuw i8, ptr %143, i32 %148
  %150 = load i8, ptr %149, align 1, !tbaa !46
  %151 = getelementptr inbounds nuw i8, ptr %111, i32 %148
  %152 = load i8, ptr %151, align 1, !tbaa !46
  %153 = icmp eq i8 %150, %152
  br i1 %153, label %144, label %154

154:                                              ; preds = %147
  %155 = add i32 %142, 1
  %156 = icmp ugt i32 %155, %118
  br i1 %156, label %157, label %141, !llvm.loop !184

157:                                              ; preds = %134, %131, %122, %119, %154, %144, %110, %115
  %158 = phi i32 [ 0, %115 ], [ 1, %110 ], [ 1, %144 ], [ 0, %154 ], [ 1, %119 ], [ 0, %122 ], [ 0, %134 ], [ 1, %131 ]
  store i32 %158, ptr %4, align 4, !tbaa !1
  br label %159

159:                                              ; preds = %69, %66, %84, %74, %93, %98, %91, %78, %102, %20, %17, %35, %25, %44, %49, %42, %11, %29, %53, %157, %5
  %160 = phi i32 [ 6, %5 ], [ 0, %157 ], [ 6, %102 ], [ 6, %20 ], [ 6, %17 ], [ 1, %35 ], [ 6, %25 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %11 ], [ 6, %29 ], [ 6, %53 ], [ 6, %69 ], [ 6, %66 ], [ 1, %84 ], [ 6, %74 ], [ 6, %93 ], [ 6, %98 ], [ 6, %91 ], [ 6, %78 ]
  ret i32 %160
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden void @nms_module_fail(i32 noundef %0) local_unnamed_addr #14 {
  %2 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %3 = icmp eq i32 %2, 0
  %4 = icmp ne i32 %0, 0
  %5 = and i1 %4, %3
  br i1 %5, label %6, label %9

6:                                                ; preds = %1
  %7 = icmp ult i32 %0, 8
  %8 = select i1 %7, i32 %0, i32 6
  store i32 %8, ptr @nms_module_error, align 4, !tbaa !1
  br label %9

9:                                                ; preds = %6, %1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i32 @nms_module_status() local_unnamed_addr #15 {
  %1 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  ret i32 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 6) i32 @nms_module_begin(ptr noundef %0, i32 noundef %1) local_unnamed_addr #14 {
  %3 = load i1, ptr @nms_module_ready, align 4
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !5
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8, !tbaa !12
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 56), align 8, !tbaa !17
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8, !tbaa !19
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8, !tbaa !20
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  store i1 true, ptr @nms_module_ready, align 4
  br label %11

5:                                                ; preds = %2
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %12

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %4, %8
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  store i32 0, ptr @nms_module_error, align 4, !tbaa !1
  br label %12

12:                                               ; preds = %5, %8, %11
  %13 = phi i32 [ 0, %11 ], [ 5, %5 ], [ 4, %8 ]
  ret i32 %13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i64 0, -9223372036854775808) i64 @nms_module_finish(i32 noundef %0) local_unnamed_addr #14 {
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %14, label %4

4:                                                ; preds = %1
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %6 = icmp ugt i32 %5, 7
  %7 = select i1 %6, i32 6, i32 %5
  %8 = zext nneg i32 %7 to i64
  %9 = shl nuw nsw i64 %8, 32
  %10 = icmp eq i32 %7, 0
  %11 = select i1 %10, i32 %0, i32 0
  %12 = zext i32 %11 to i64
  %13 = or disjoint i64 %9, %12
  br label %14

14:                                               ; preds = %1, %4
  %15 = phi i64 [ %13, %4 ], [ 25769803776, %1 ]
  ret i64 %15
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i32 0, 6) i32 @nms_module_graph_begin(ptr noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = load i1, ptr @nms_module_ready, align 4
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !5
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8, !tbaa !12
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 56), align 8, !tbaa !17
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8, !tbaa !19
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8, !tbaa !20
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  store i1 true, ptr @nms_module_ready, align 4
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  store i32 0, ptr @nms_module_error, align 4, !tbaa !1
  br label %14

5:                                                ; preds = %2
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %30

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %30

11:                                               ; preds = %8
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  %13 = icmp eq i32 %12, 0
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  store i32 0, ptr @nms_module_error, align 4, !tbaa !1
  br i1 %13, label %14, label %30

14:                                               ; preds = %4, %11
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  %16 = zext i32 %15 to i64
  %17 = add nuw nsw i64 %16, 1
  %18 = mul nuw nsw i64 %17, 9
  %19 = add nuw nsw i64 %18, 3
  %20 = and i64 %19, 274877906940
  %21 = shl nuw nsw i64 %17, 2
  %22 = add nuw nsw i64 %20, %21
  %23 = icmp samesign ugt i64 %22, 4294967295
  br i1 %23, label %29, label %24

24:                                               ; preds = %14
  %25 = tail call fastcc ptr @allocate(i64 noundef %22) #27
  %26 = icmp eq ptr %25, null
  br i1 %26, label %29, label %27

27:                                               ; preds = %24
  store ptr %25, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  %28 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  store i32 %28, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  br label %30

29:                                               ; preds = %24, %14
  store i32 3, ptr @nms_module_error, align 4, !tbaa !1
  br label %30

30:                                               ; preds = %27, %11, %8, %5, %29
  %31 = phi i32 [ 3, %29 ], [ 5, %5 ], [ 0, %27 ], [ 4, %8 ], [ 0, %11 ]
  ret i32 %31
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden range(i64 1, 4294967304) i64 @nms_module_record_begin(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3) local_unnamed_addr #3 {
  %5 = load i1, ptr @nms_module_ready, align 4
  br i1 %5, label %7, label %6

6:                                                ; preds = %4
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !5
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8, !tbaa !12
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 56), align 8, !tbaa !17
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8, !tbaa !19
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8, !tbaa !20
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  store i1 true, ptr @nms_module_ready, align 4
  br label %19

7:                                                ; preds = %4
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %82

10:                                               ; preds = %7
  %11 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %82

13:                                               ; preds = %10
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %16 = icmp eq ptr %14, %0
  %17 = icmp eq i32 %15, %1
  %18 = select i1 %16, i1 %17, i1 false
  br i1 %18, label %19, label %82

19:                                               ; preds = %6, %13
  %20 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %69

22:                                               ; preds = %19
  %23 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  %24 = icmp eq i32 %23, 0
  %25 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8
  %26 = icmp eq i64 %25, 0
  %27 = select i1 %24, i1 %26, i1 false
  %28 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8
  %29 = icmp eq i64 %28, 0
  %30 = select i1 %27, i1 %29, i1 false
  br i1 %30, label %31, label %82

31:                                               ; preds = %22
  %32 = icmp eq i32 %3, 0
  %33 = icmp ne ptr %2, null
  %34 = or i1 %33, %32
  br i1 %34, label %35, label %82

35:                                               ; preds = %31
  %36 = icmp ugt i32 %3, 256
  br i1 %36, label %82, label %37

37:                                               ; preds = %35
  br i1 %32, label %68, label %38

38:                                               ; preds = %37
  %39 = load i32, ptr %2, align 4, !tbaa !69
  %40 = icmp ugt i32 %39, 255
  br i1 %40, label %82, label %41

41:                                               ; preds = %38
  %42 = getelementptr inbounds nuw i8, ptr %2, i32 4
  %43 = load i32, ptr %42, align 4, !tbaa !57
  %44 = icmp ugt i32 %43, 65535
  br i1 %44, label %82, label %45

45:                                               ; preds = %41
  %46 = icmp eq i32 %3, 1
  br i1 %46, label %68, label %47

47:                                               ; preds = %45, %64
  %48 = phi i32 [ %66, %64 ], [ 1, %45 ]
  %49 = phi i32 [ %65, %64 ], [ %43, %45 ]
  %50 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %2, i32 %48
  %51 = load i32, ptr %50, align 4, !tbaa !69
  %52 = icmp ugt i32 %51, 255
  br i1 %52, label %82, label %53

53:                                               ; preds = %47
  %54 = getelementptr i8, ptr %50, i32 -8
  %55 = load i32, ptr %54, align 4, !tbaa !69
  %56 = icmp ugt i32 %51, %55
  br i1 %56, label %57, label %82

57:                                               ; preds = %53
  %58 = getelementptr inbounds nuw i8, ptr %50, i32 4
  %59 = load i32, ptr %58, align 4, !tbaa !57
  %60 = icmp ugt i32 %59, 65535
  %61 = sub i32 65536, %49
  %62 = icmp ugt i32 %59, %61
  %63 = select i1 %60, i1 true, i1 %62
  br i1 %63, label %82, label %64

64:                                               ; preds = %57
  %65 = add i32 %59, %49
  %66 = add nuw i32 %48, 1
  %67 = icmp eq i32 %66, %3
  br i1 %67, label %68, label %47, !llvm.loop !70

68:                                               ; preds = %64, %37, %45
  store ptr %2, ptr @nms_module_instance, align 8, !tbaa !5
  store i32 %3, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  br label %75

69:                                               ; preds = %19
  %70 = load ptr, ptr @nms_module_instance, align 8, !tbaa !5
  %71 = icmp eq ptr %70, %2
  %72 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4
  %73 = icmp eq i32 %72, %3
  %74 = select i1 %71, i1 %73, i1 false
  br i1 %74, label %75, label %82

75:                                               ; preds = %68, %69
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  store i32 0, ptr @nms_module_error, align 4, !tbaa !1
  %76 = tail call i32 @nms_prepare_collection(ptr noundef nonnull @nms_module_instance) #27
  %77 = icmp eq i32 %76, 0
  br i1 %77, label %79, label %78

78:                                               ; preds = %75
  store i32 %76, ptr @nms_module_error, align 4, !tbaa !1
  br label %79

79:                                               ; preds = %75, %78
  %80 = zext nneg i32 %76 to i64
  %81 = or disjoint i64 %80, 4294967296
  br label %82

82:                                               ; preds = %47, %53, %57, %38, %22, %31, %35, %41, %79, %69, %13, %10, %7
  %83 = phi i64 [ 6, %13 ], [ 5, %7 ], [ 4, %10 ], [ %81, %79 ], [ 6, %69 ], [ 1, %38 ], [ 6, %22 ], [ 1, %35 ], [ 1, %41 ], [ 6, %31 ], [ 1, %57 ], [ 1, %53 ], [ 1, %47 ]
  ret i64 %83
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none)
define hidden i32 @nms_module_graph_collect() local_unnamed_addr #10 {
  %1 = load i1, ptr @nms_module_ready, align 4
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4
  %3 = icmp ne i32 %2, 0
  %4 = select i1 %1, i1 %3, i1 false
  br i1 %4, label %5, label %55

5:                                                ; preds = %0
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %48

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  %10 = icmp eq i32 %9, 0
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %12 = icmp eq ptr %11, null
  br i1 %10, label %13, label %20

13:                                               ; preds = %8
  %14 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8
  %15 = icmp eq i64 %14, 0
  %16 = select i1 %12, i1 %15, i1 false
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8
  %18 = icmp eq i64 %17, 0
  %19 = select i1 %16, i1 %18, i1 false
  br i1 %19, label %21, label %48

20:                                               ; preds = %8
  br i1 %12, label %48, label %21

21:                                               ; preds = %13, %20
  %22 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  %23 = icmp eq i32 %22, 0
  br i1 %23, label %48, label %24

24:                                               ; preds = %21
  %25 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  %26 = icmp eq ptr %25, null
  br i1 %26, label %48, label %27

27:                                               ; preds = %24
  %28 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  %29 = icmp ult i32 %28, %9
  %30 = or i1 %10, %29
  %31 = select i1 %29, i32 6, i32 0
  br i1 %30, label %48, label %32

32:                                               ; preds = %27
  %33 = zext i32 %28 to i64
  %34 = add nuw nsw i64 %33, 1
  %35 = mul nuw nsw i64 %34, 9
  %36 = add nuw nsw i64 %35, 3
  %37 = shl nuw nsw i64 %34, 2
  %38 = add nuw nsw i64 %36, %37
  %39 = icmp samesign ugt i64 %38, 4294967295
  br i1 %39, label %48, label %40

40:                                               ; preds = %32
  %41 = trunc i64 %34 to i32
  %42 = shl i32 %41, 3
  %43 = getelementptr inbounds nuw i8, ptr %25, i32 %42
  %44 = trunc nuw i64 %36 to i32
  %45 = and i32 %44, -4
  %46 = getelementptr inbounds nuw i8, ptr %25, i32 %45
  %47 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull @nms_module_instance, ptr noundef nonnull %25, ptr noundef nonnull %43, ptr noundef nonnull %46) #27
  br label %48

48:                                               ; preds = %5, %13, %20, %21, %24, %27, %32, %40
  %49 = phi i32 [ 6, %21 ], [ 6, %20 ], [ 6, %32 ], [ %31, %27 ], [ 6, %24 ], [ %47, %40 ], [ 5, %5 ], [ 6, %13 ]
  %50 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %51 = icmp eq i32 %50, 0
  %52 = icmp ne i32 %49, 0
  %53 = and i1 %52, %51
  br i1 %53, label %54, label %55

54:                                               ; preds = %48
  store i32 %49, ptr @nms_module_error, align 4, !tbaa !1
  br label %55

55:                                               ; preds = %54, %48, %0
  %56 = phi i32 [ 6, %0 ], [ %50, %48 ], [ %49, %54 ]
  ret i32 %56
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none)
define hidden range(i64 0, -9223372036854775808) i64 @nms_module_graph_finish(i32 noundef %0) local_unnamed_addr #10 {
  %2 = load i1, ptr @nms_module_ready, align 4
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4
  %4 = icmp ne i32 %3, 0
  %5 = select i1 %2, i1 %4, i1 false
  br i1 %5, label %6, label %73

6:                                                ; preds = %1
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %55, label %9

9:                                                ; preds = %6
  %10 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %49

12:                                               ; preds = %9
  %13 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  %14 = icmp eq i32 %13, 0
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %16 = icmp eq ptr %15, null
  br i1 %14, label %17, label %24

17:                                               ; preds = %12
  %18 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8
  %19 = icmp eq i64 %18, 0
  %20 = select i1 %16, i1 %19, i1 false
  %21 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8
  %22 = icmp eq i64 %21, 0
  %23 = select i1 %20, i1 %22, i1 false
  br i1 %23, label %25, label %49

24:                                               ; preds = %12
  br i1 %16, label %49, label %25

25:                                               ; preds = %17, %24
  %26 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  %27 = icmp eq ptr %26, null
  br i1 %27, label %49, label %28

28:                                               ; preds = %25
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  %30 = icmp ult i32 %29, %13
  %31 = or i1 %14, %30
  %32 = select i1 %30, i32 6, i32 0
  br i1 %31, label %49, label %33

33:                                               ; preds = %28
  %34 = zext i32 %29 to i64
  %35 = add nuw nsw i64 %34, 1
  %36 = mul nuw nsw i64 %35, 9
  %37 = add nuw nsw i64 %36, 3
  %38 = shl nuw nsw i64 %35, 2
  %39 = add nuw nsw i64 %37, %38
  %40 = icmp samesign ugt i64 %39, 4294967295
  br i1 %40, label %49, label %41

41:                                               ; preds = %33
  %42 = trunc i64 %35 to i32
  %43 = shl i32 %42, 3
  %44 = getelementptr inbounds nuw i8, ptr %26, i32 %43
  %45 = trunc nuw i64 %37 to i32
  %46 = and i32 %45, -4
  %47 = getelementptr inbounds nuw i8, ptr %26, i32 %46
  %48 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull @nms_module_instance, ptr noundef nonnull %26, ptr noundef nonnull %44, ptr noundef nonnull %47) #27
  br label %49

49:                                               ; preds = %9, %17, %24, %25, %28, %33, %41
  %50 = phi i32 [ 6, %17 ], [ 6, %24 ], [ 6, %33 ], [ %32, %28 ], [ 6, %25 ], [ %48, %41 ], [ 5, %9 ]
  %51 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %52 = icmp eq i32 %51, 0
  %53 = icmp ne i32 %50, 0
  %54 = and i1 %53, %52
  br i1 %54, label %58, label %60

55:                                               ; preds = %6
  %56 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %58, label %60

58:                                               ; preds = %55, %49
  %59 = phi i32 [ %50, %49 ], [ 6, %55 ]
  store i32 %59, ptr @nms_module_error, align 4, !tbaa !1
  br label %60

60:                                               ; preds = %58, %55, %49
  %61 = phi i32 [ %51, %49 ], [ %56, %55 ], [ %59, %58 ]
  %62 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %63 = icmp eq i32 %62, 0
  br i1 %63, label %73, label %64

64:                                               ; preds = %60
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  %65 = icmp ugt i32 %61, 7
  %66 = select i1 %65, i32 6, i32 %61
  %67 = zext nneg i32 %66 to i64
  %68 = shl nuw nsw i64 %67, 32
  %69 = icmp eq i32 %66, 0
  %70 = select i1 %69, i32 %0, i32 0
  %71 = zext i32 %70 to i64
  %72 = or disjoint i64 %68, %71
  br label %73

73:                                               ; preds = %64, %60, %1
  %74 = phi i64 [ 25769803776, %1 ], [ %72, %64 ], [ 25769803776, %60 ]
  ret i64 %74
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i32 @nms_module_active() local_unnamed_addr #15 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  ret i32 %1
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_module_dispose() local_unnamed_addr #6 {
  %1 = load i1, ptr @nms_module_ready, align 4
  br i1 %1, label %3, label %2

2:                                                ; preds = %0
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !5
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8, !tbaa !12
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 20), align 4, !tbaa !14
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 28), align 4, !tbaa !15
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 24), align 8, !tbaa !16
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 56), align 8, !tbaa !17
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4, !tbaa !18
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8, !tbaa !19
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8, !tbaa !20
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 60), align 4, !tbaa !22
  store i1 true, ptr @nms_module_ready, align 4
  br label %3

3:                                                ; preds = %2, %0
  %4 = tail call i32 @nms_dispose(ptr noundef nonnull @nms_module_instance) #27
  ret i32 %4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_module_retain(i64 noundef %0, i32 noundef %1) local_unnamed_addr #5 {
  switch i32 %1, label %50 [
    i32 8, label %3
    i32 7, label %3
    i32 5, label %3
  ]

3:                                                ; preds = %2, %2, %2
  %4 = icmp sgt i64 %0, -1
  %5 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %6 = icmp eq i32 %5, 0
  br i1 %4, label %7, label %24

7:                                                ; preds = %3
  br i1 %6, label %8, label %43

8:                                                ; preds = %7
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %10 = freeze i32 %9
  %11 = zext i32 %10 to i64
  %12 = add nsw i64 %0, -1
  %13 = icmp ult i64 %12, %11
  br i1 %13, label %14, label %43

14:                                               ; preds = %8
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %16 = icmp eq ptr %15, null
  br i1 %16, label %43, label %17

17:                                               ; preds = %14
  %18 = trunc nuw i64 %0 to i32
  %19 = getelementptr %struct.NmsView, ptr %15, i32 %18
  %20 = getelementptr i8, ptr %19, i32 -8
  %21 = load ptr, ptr %20, align 4, !tbaa !28
  %22 = icmp eq ptr %21, null
  %23 = select i1 %22, i32 6, i32 0
  br label %43

24:                                               ; preds = %3
  br i1 %6, label %25, label %43

25:                                               ; preds = %24
  %26 = and i64 %0, 9223372036854775807
  %27 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %28 = freeze i32 %27
  %29 = zext i32 %28 to i64
  %30 = add nsw i64 %26, -1
  %31 = icmp ult i64 %30, %29
  br i1 %31, label %32, label %43

32:                                               ; preds = %25
  %33 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %34 = icmp eq ptr %33, null
  br i1 %34, label %43, label %35

35:                                               ; preds = %32
  %36 = trunc i64 %0 to i32
  %37 = getelementptr inbounds nuw %struct.NmsSlot, ptr %33, i32 %36
  %38 = getelementptr inbounds nuw i8, ptr %37, i32 8
  %39 = load i64, ptr %38, align 8, !tbaa !23
  switch i64 %39, label %40 [
    i64 0, label %43
    i64 -1, label %42
  ]

40:                                               ; preds = %35
  %41 = add nuw i64 %39, 1
  store i64 %41, ptr %38, align 8, !tbaa !23
  br label %50

42:                                               ; preds = %35
  br label %43

43:                                               ; preds = %42, %35, %32, %25, %24, %17, %14, %8, %7
  %44 = phi i32 [ 5, %24 ], [ 6, %25 ], [ 6, %35 ], [ %23, %17 ], [ 3, %42 ], [ 5, %7 ], [ 6, %8 ], [ 6, %14 ], [ 6, %32 ]
  %45 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %46 = icmp eq i32 %45, 0
  %47 = icmp ne i32 %44, 0
  %48 = and i1 %47, %46
  br i1 %48, label %49, label %50

49:                                               ; preds = %43
  store i32 %44, ptr @nms_module_error, align 4, !tbaa !1
  br label %50

50:                                               ; preds = %40, %2, %43, %49
  %51 = phi i32 [ %44, %49 ], [ %44, %43 ], [ 0, %2 ], [ 0, %40 ]
  ret i32 %51
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden void @nms_module_release(i64 noundef %0, i32 noundef %1) local_unnamed_addr #6 {
  switch i32 %1, label %10 [
    i32 8, label %3
    i32 7, label %3
    i32 5, label %3
  ]

3:                                                ; preds = %2, %2, %2
  %4 = tail call i32 @nms_release(ptr noundef nonnull @nms_module_instance, i64 noundef %0) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %3
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %9, %3, %2
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden i64 @nms_module_record_literal(i32 noundef %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca [256 x %struct.NmsValue], align 16
  %6 = alloca i64, align 8
  %7 = icmp ugt i32 %1, 256
  br i1 %7, label %8, label %12

8:                                                ; preds = %4
  %9 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %70

11:                                               ; preds = %8
  store i32 1, ptr @nms_module_error, align 4, !tbaa !1
  br label %70

12:                                               ; preds = %4
  %13 = icmp eq i32 %1, 0
  br i1 %13, label %14, label %15

14:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  br label %40

15:                                               ; preds = %12
  %16 = icmp ne ptr %2, null
  %17 = icmp ne ptr %3, null
  %18 = and i1 %16, %17
  br i1 %18, label %23, label %19

19:                                               ; preds = %15
  %20 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %70

22:                                               ; preds = %19
  store i32 6, ptr @nms_module_error, align 4, !tbaa !1
  br label %70

23:                                               ; preds = %15
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  %24 = and i32 %1, 1
  %25 = icmp eq i32 %1, 1
  br i1 %25, label %30, label %26

26:                                               ; preds = %23
  %27 = and i32 %1, 510
  br label %49

28:                                               ; preds = %49
  %29 = icmp eq i32 %24, 0
  br i1 %29, label %40, label %30

30:                                               ; preds = %28, %23
  %31 = phi i32 [ 0, %23 ], [ %67, %28 ]
  %32 = trunc i32 %1 to i1
  tail call void @llvm.assume(i1 %32)
  %33 = getelementptr inbounds nuw %struct.NmsValue, ptr %5, i32 %31
  %34 = getelementptr inbounds nuw i64, ptr %2, i32 %31
  %35 = load i64, ptr %34, align 8, !tbaa !45
  %36 = getelementptr inbounds nuw i32, ptr %3, i32 %31
  %37 = load i32, ptr %36, align 4, !tbaa !1
  store i64 %35, ptr %33, align 16, !tbaa !45
  %38 = getelementptr inbounds nuw i8, ptr %33, i32 8
  store i32 %37, ptr %38, align 8, !tbaa !1
  %39 = getelementptr inbounds nuw i8, ptr %33, i32 12
  store i32 0, ptr %39, align 4
  br label %40

40:                                               ; preds = %30, %28, %14
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  store i64 0, ptr %6, align 8, !tbaa !45
  %41 = call i32 @nms_record_create(ptr noundef nonnull @nms_module_instance, i32 noundef %0, ptr noundef nonnull %5, i32 noundef %1, ptr noundef nonnull %6) #27
  %42 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %43 = icmp eq i32 %42, 0
  %44 = icmp ne i32 %41, 0
  %45 = and i1 %44, %43
  br i1 %45, label %46, label %47

46:                                               ; preds = %40
  store i32 %41, ptr @nms_module_error, align 4, !tbaa !1
  br label %47

47:                                               ; preds = %40, %46
  %48 = load i64, ptr %6, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  br label %70

49:                                               ; preds = %49, %26
  %50 = phi i32 [ 0, %26 ], [ %67, %49 ]
  %51 = phi i32 [ 0, %26 ], [ %68, %49 ]
  %52 = getelementptr inbounds nuw %struct.NmsValue, ptr %5, i32 %50
  %53 = getelementptr inbounds nuw i64, ptr %2, i32 %50
  %54 = load i64, ptr %53, align 8, !tbaa !45
  %55 = getelementptr inbounds nuw i32, ptr %3, i32 %50
  %56 = load i32, ptr %55, align 4, !tbaa !1
  store i64 %54, ptr %52, align 16, !tbaa !45
  %57 = getelementptr inbounds nuw i8, ptr %52, i32 8
  store i32 %56, ptr %57, align 8, !tbaa !1
  %58 = getelementptr inbounds nuw i8, ptr %52, i32 12
  store i32 0, ptr %58, align 4
  %59 = or disjoint i32 %50, 1
  %60 = getelementptr inbounds nuw %struct.NmsValue, ptr %5, i32 %59
  %61 = getelementptr inbounds nuw i64, ptr %2, i32 %59
  %62 = load i64, ptr %61, align 8, !tbaa !45
  %63 = getelementptr inbounds nuw i32, ptr %3, i32 %59
  %64 = load i32, ptr %63, align 4, !tbaa !1
  store i64 %62, ptr %60, align 16, !tbaa !45
  %65 = getelementptr inbounds nuw i8, ptr %60, i32 8
  store i32 %64, ptr %65, align 8, !tbaa !1
  %66 = getelementptr inbounds nuw i8, ptr %60, i32 12
  store i32 0, ptr %66, align 4
  %67 = add nuw nsw i32 %50, 2
  %68 = add i32 %51, 2
  %69 = icmp eq i32 %68, %27
  br i1 %69, label %28, label %49, !llvm.loop !185

70:                                               ; preds = %22, %19, %11, %8, %47
  %71 = phi i64 [ 0, %11 ], [ %48, %47 ], [ 0, %8 ], [ 0, %19 ], [ 0, %22 ]
  ret i64 %71
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 8) i32 @nms_module_record_get_value(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4, ptr noundef writeonly captures(address_is_null) %5) local_unnamed_addr #5 {
  %7 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %7, i8 0, i32 16, i1 false)
  %8 = icmp eq ptr %4, null
  %9 = icmp eq ptr %5, null
  %10 = or i1 %8, %9
  %11 = icmp ugt i32 %3, 1
  %12 = or i1 %11, %10
  br i1 %12, label %81, label %13

13:                                               ; preds = %6
  %14 = icmp eq i32 %1, 8
  br i1 %14, label %18, label %15

15:                                               ; preds = %13
  %16 = icmp eq i32 %3, 0
  %17 = select i1 %16, i32 1, i32 7
  br label %81

18:                                               ; preds = %13
  %19 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %20 = icmp eq i32 %19, 0
  br i1 %20, label %21, label %81

21:                                               ; preds = %18
  %22 = and i64 %0, 9223372036854775807
  %23 = icmp sgt i64 %0, -1
  %24 = icmp eq i64 %22, 0
  %25 = or i1 %23, %24
  %26 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %27 = zext i32 %26 to i64
  %28 = icmp samesign ugt i64 %22, %27
  %29 = select i1 %25, i1 true, i1 %28
  br i1 %29, label %81, label %30

30:                                               ; preds = %21
  %31 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %32 = icmp eq ptr %31, null
  br i1 %32, label %81, label %33

33:                                               ; preds = %30
  %34 = trunc i64 %0 to i32
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %31, i32 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i32 8
  %37 = load i64, ptr %36, align 8, !tbaa !23
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %81, label %39

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %35, i32 28
  %41 = load i32, ptr %40, align 4, !tbaa !26
  %42 = icmp eq i32 %41, 5
  br i1 %42, label %43, label %70

43:                                               ; preds = %39
  %44 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %81, label %46

46:                                               ; preds = %43
  %47 = load ptr, ptr @nms_module_instance, align 8, !tbaa !5
  %48 = icmp eq ptr %47, null
  br i1 %48, label %81, label %49

49:                                               ; preds = %46
  %50 = getelementptr inbounds nuw i8, ptr %35, i32 40
  %51 = load i32, ptr %50, align 8, !tbaa !42
  %52 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  %53 = icmp ult i32 %51, %52
  br i1 %53, label %54, label %81

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %47, i32 %51
  %56 = getelementptr inbounds nuw i8, ptr %55, i32 4
  %57 = load i32, ptr %56, align 4, !tbaa !57
  %58 = getelementptr inbounds nuw i8, ptr %35, i32 16
  %59 = load i32, ptr %58, align 8, !tbaa !38
  %60 = icmp eq i32 %59, %57
  br i1 %60, label %61, label %81

61:                                               ; preds = %54
  %62 = getelementptr inbounds nuw i8, ptr %35, i32 24
  %63 = load i32, ptr %62, align 8, !tbaa !43
  %64 = icmp eq i32 %63, %57
  br i1 %64, label %65, label %81

65:                                               ; preds = %61
  %66 = icmp eq i32 %57, 0
  br i1 %66, label %73, label %67

67:                                               ; preds = %65
  %68 = load ptr, ptr %35, align 8, !tbaa !27
  %69 = icmp eq ptr %68, null
  br i1 %69, label %81, label %73

70:                                               ; preds = %39
  %71 = icmp eq i32 %3, 0
  %72 = select i1 %71, i32 1, i32 7
  br label %81

73:                                               ; preds = %67, %65
  %74 = zext i32 %2 to i64
  %75 = call i32 @nms_record_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %74, ptr noundef nonnull %7) #27
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %77, label %81

77:                                               ; preds = %73
  %78 = load i64, ptr %7, align 8, !tbaa !56
  store i64 %78, ptr %4, align 8, !tbaa !45
  %79 = getelementptr inbounds nuw i8, ptr %7, i32 8
  %80 = load i32, ptr %79, align 8, !tbaa !54
  store i32 %80, ptr %5, align 4, !tbaa !1
  br label %86

81:                                               ; preds = %70, %43, %67, %18, %33, %30, %49, %21, %54, %61, %46, %15, %6, %73
  %82 = phi i32 [ %75, %73 ], [ 6, %61 ], [ 6, %6 ], [ 6, %46 ], [ %17, %15 ], [ %72, %70 ], [ 6, %43 ], [ 6, %67 ], [ 5, %18 ], [ 6, %33 ], [ 6, %30 ], [ 6, %49 ], [ 6, %21 ], [ 6, %54 ]
  %83 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %84 = icmp eq i32 %83, 0
  br i1 %84, label %85, label %86

85:                                               ; preds = %81
  store i32 %82, ptr @nms_module_error, align 4, !tbaa !1
  br label %86

86:                                               ; preds = %77, %81, %85
  %87 = phi i32 [ 0, %77 ], [ %82, %81 ], [ %82, %85 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #28
  ret i32 %87
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr writeonly captures(none), i8, i32, i1 immarg) #16

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 8) i32 @nms_module_record_set_value(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i64 noundef %4, i32 noundef %5) local_unnamed_addr #6 {
  %7 = alloca %struct.NmsValue, align 8
  %8 = icmp ugt i32 %3, 1
  br i1 %8, label %74, label %9

9:                                                ; preds = %6
  %10 = icmp eq i32 %1, 8
  br i1 %10, label %14, label %11

11:                                               ; preds = %9
  %12 = icmp eq i32 %3, 0
  %13 = select i1 %12, i32 1, i32 7
  br label %74

14:                                               ; preds = %9
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %74

17:                                               ; preds = %14
  %18 = and i64 %0, 9223372036854775807
  %19 = icmp sgt i64 %0, -1
  %20 = icmp eq i64 %18, 0
  %21 = or i1 %19, %20
  %22 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  %25 = select i1 %21, i1 true, i1 %24
  br i1 %25, label %74, label %26

26:                                               ; preds = %17
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %28 = icmp eq ptr %27, null
  br i1 %28, label %74, label %29

29:                                               ; preds = %26
  %30 = trunc i64 %0 to i32
  %31 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i32 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i32 8
  %33 = load i64, ptr %32, align 8, !tbaa !23
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %74, label %35

35:                                               ; preds = %29
  %36 = getelementptr inbounds nuw i8, ptr %31, i32 28
  %37 = load i32, ptr %36, align 4, !tbaa !26
  %38 = icmp eq i32 %37, 5
  br i1 %38, label %39, label %66

39:                                               ; preds = %35
  %40 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 8), align 8, !tbaa !9
  %41 = icmp eq i32 %40, 0
  br i1 %41, label %74, label %42

42:                                               ; preds = %39
  %43 = load ptr, ptr @nms_module_instance, align 8, !tbaa !5
  %44 = icmp eq ptr %43, null
  br i1 %44, label %74, label %45

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i8, ptr %31, i32 40
  %47 = load i32, ptr %46, align 8, !tbaa !42
  %48 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 4), align 4, !tbaa !10
  %49 = icmp ult i32 %47, %48
  br i1 %49, label %50, label %74

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %43, i32 %47
  %52 = getelementptr inbounds nuw i8, ptr %51, i32 4
  %53 = load i32, ptr %52, align 4, !tbaa !57
  %54 = getelementptr inbounds nuw i8, ptr %31, i32 16
  %55 = load i32, ptr %54, align 8, !tbaa !38
  %56 = icmp eq i32 %55, %53
  br i1 %56, label %57, label %74

57:                                               ; preds = %50
  %58 = getelementptr inbounds nuw i8, ptr %31, i32 24
  %59 = load i32, ptr %58, align 8, !tbaa !43
  %60 = icmp eq i32 %59, %53
  br i1 %60, label %61, label %74

61:                                               ; preds = %57
  %62 = icmp eq i32 %53, 0
  br i1 %62, label %69, label %63

63:                                               ; preds = %61
  %64 = load ptr, ptr %31, align 8, !tbaa !27
  %65 = icmp eq ptr %64, null
  br i1 %65, label %74, label %69

66:                                               ; preds = %35
  %67 = icmp eq i32 %3, 0
  %68 = select i1 %67, i32 1, i32 7
  br label %74

69:                                               ; preds = %63, %61
  %70 = zext i32 %2 to i64
  store i64 %4, ptr %7, align 8, !tbaa !56
  %71 = getelementptr inbounds nuw i8, ptr %7, i32 8
  store i32 %5, ptr %71, align 8, !tbaa !54
  %72 = getelementptr inbounds nuw i8, ptr %7, i32 12
  store i32 0, ptr %72, align 4
  %73 = tail call i32 @nms_record_set(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %70, ptr noundef nonnull byval(%struct.NmsValue) align 8 %7) #27
  br label %74

74:                                               ; preds = %66, %39, %63, %14, %29, %26, %45, %17, %50, %57, %42, %6, %11, %69
  %75 = phi i32 [ %73, %69 ], [ 6, %42 ], [ %13, %11 ], [ 6, %6 ], [ %68, %66 ], [ 6, %39 ], [ 6, %63 ], [ 5, %14 ], [ 6, %29 ], [ 6, %26 ], [ 6, %45 ], [ 6, %17 ], [ 6, %50 ], [ 6, %57 ]
  %76 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %77 = icmp eq i32 %76, 0
  %78 = icmp ne i32 %75, 0
  %79 = and i1 %78, %77
  br i1 %79, label %80, label %81

80:                                               ; preds = %74
  store i32 %75, ptr @nms_module_error, align 4, !tbaa !1
  br label %81

81:                                               ; preds = %74, %80
  ret i32 %75
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_format_scalar(i64 noundef %0, i32 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  store i64 0, ptr %3, align 8, !tbaa !45
  %4 = call i32 @nms_format_scalar(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, ptr noundef nonnull %3) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i64 -1, 256) i64 @nms_module_char_at(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #17 {
  %4 = icmp ult i32 %2, 2
  br i1 %4, label %5, label %65

5:                                                ; preds = %3
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %65

8:                                                ; preds = %5
  %9 = icmp sgt i64 %0, -1
  br i1 %9, label %33, label %10

10:                                               ; preds = %8
  %11 = and i64 %0, 9223372036854775807
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %13 = freeze i32 %12
  %14 = zext i32 %13 to i64
  %15 = add nsw i64 %11, -1
  %16 = icmp ult i64 %15, %14
  br i1 %16, label %17, label %65

17:                                               ; preds = %10
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %19 = icmp eq ptr %18, null
  br i1 %19, label %65, label %20

20:                                               ; preds = %17
  %21 = trunc i64 %0 to i32
  %22 = getelementptr inbounds nuw %struct.NmsSlot, ptr %18, i32 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i32 8
  %24 = load i64, ptr %23, align 8, !tbaa !23
  %25 = icmp eq i64 %24, 0
  br i1 %25, label %65, label %26

26:                                               ; preds = %20
  %27 = getelementptr inbounds nuw i8, ptr %22, i32 28
  %28 = load i32, ptr %27, align 4, !tbaa !26
  %29 = icmp eq i32 %28, 1
  br i1 %29, label %30, label %65

30:                                               ; preds = %26
  %31 = load ptr, ptr %22, align 8, !tbaa !27
  %32 = getelementptr inbounds nuw i8, ptr %22, i32 16
  br label %50

33:                                               ; preds = %8
  %34 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %35 = freeze i32 %34
  %36 = zext i32 %35 to i64
  %37 = add nsw i64 %0, -1
  %38 = icmp ult i64 %37, %36
  br i1 %38, label %39, label %65

39:                                               ; preds = %33
  %40 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %41 = icmp eq ptr %40, null
  br i1 %41, label %65, label %42

42:                                               ; preds = %39
  %43 = trunc nuw i64 %0 to i32
  %44 = getelementptr %struct.NmsView, ptr %40, i32 %43
  %45 = getelementptr i8, ptr %44, i32 -8
  %46 = load ptr, ptr %45, align 4, !tbaa !28
  %47 = icmp eq ptr %46, null
  br i1 %47, label %65, label %48

48:                                               ; preds = %42
  %49 = getelementptr i8, ptr %44, i32 -4
  br label %50

50:                                               ; preds = %48, %30
  %51 = phi ptr [ %46, %48 ], [ %31, %30 ]
  %52 = phi ptr [ %49, %48 ], [ %32, %30 ]
  %53 = load i32, ptr %52, align 4, !tbaa !1
  %54 = icmp eq i32 %2, 0
  %55 = select i1 %54, i64 0, i64 %1
  %56 = icmp sgt i64 %55, -1
  %57 = zext i32 %53 to i64
  %58 = icmp samesign ult i64 %55, %57
  %59 = select i1 %56, i1 %58, i1 false
  br i1 %59, label %60, label %70

60:                                               ; preds = %50
  %61 = trunc nuw i64 %55 to i32
  %62 = getelementptr inbounds nuw i8, ptr %51, i32 %61
  %63 = load i8, ptr %62, align 1, !tbaa !46
  %64 = zext i8 %63 to i64
  br label %70

65:                                               ; preds = %3, %5, %10, %17, %20, %26, %33, %39, %42
  %66 = phi i32 [ 6, %3 ], [ 6, %42 ], [ 6, %20 ], [ 6, %10 ], [ 1, %26 ], [ 6, %17 ], [ 5, %5 ], [ 6, %39 ], [ 6, %33 ]
  %67 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %68 = icmp eq i32 %67, 0
  br i1 %68, label %69, label %70

69:                                               ; preds = %65
  store i32 %66, ptr @nms_module_error, align 4, !tbaa !1
  br label %70

70:                                               ; preds = %50, %60, %65, %69
  %71 = phi i64 [ 0, %69 ], [ 0, %65 ], [ -1, %50 ], [ %64, %60 ]
  ret i64 %71
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i32 @nms_module_predicate(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #18 {
  %4 = alloca i32, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #28
  store i32 0, ptr %4, align 4, !tbaa !1
  %5 = call i32 @nms_predicate(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, i32 noundef %2, ptr noundef nonnull %4) #27
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !1
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i32, ptr %4, align 4, !tbaa !1
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  ret i32 %12
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i64 @nms_module_parse_f64(i64 noundef %0) local_unnamed_addr #6 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #28
  store i64 0, ptr %2, align 8, !tbaa !45
  %3 = call i32 @nms_parse_f64(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #27
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !1
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #28
  ret i64 %10
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i64 @nms_module_parse_i64(i64 noundef %0) local_unnamed_addr #18 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #28
  store i64 0, ptr %2, align 8, !tbaa !45
  %3 = call i32 @nms_parse_i64(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #27
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !1
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #28
  ret i64 %10
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_split(i64 noundef %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  store i64 0, ptr %3, align 8, !tbaa !45
  %4 = call fastcc range(i32 0, 7) i32 @split_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3, i32 noundef 0) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  ret i64 %11
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_array_literal(i32 noundef %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  store i64 0, ptr %5, align 8, !tbaa !45
  %6 = call i32 @nms_vm_array_literal(ptr noundef nonnull @nms_module_instance, i32 noundef %0, ptr noundef %2, ptr noundef %3, i32 noundef %1, ptr noundef nonnull %5) #27
  %7 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %8 = icmp eq i32 %7, 0
  %9 = icmp ne i32 %6, 0
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %12

11:                                               ; preds = %4
  store i32 %6, ptr @nms_module_error, align 4, !tbaa !1
  br label %12

12:                                               ; preds = %4, %11
  %13 = load i64, ptr %5, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  ret i64 %13
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_array_slice(i64 noundef %0, i64 noundef %1, i32 noundef %2, i64 noundef %3, i32 noundef %4) local_unnamed_addr #4 {
  %6 = alloca i64, align 8
  %7 = icmp sgt i64 %0, -1
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %9 = icmp eq i32 %8, 0
  br i1 %7, label %10, label %27

10:                                               ; preds = %5
  br i1 %9, label %11, label %49

11:                                               ; preds = %10
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %13 = freeze i32 %12
  %14 = zext i32 %13 to i64
  %15 = add nsw i64 %0, -1
  %16 = icmp ult i64 %15, %14
  br i1 %16, label %17, label %49

17:                                               ; preds = %11
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %19 = icmp eq ptr %18, null
  br i1 %19, label %49, label %20

20:                                               ; preds = %17
  %21 = trunc nuw i64 %0 to i32
  %22 = getelementptr %struct.NmsView, ptr %18, i32 %21
  %23 = getelementptr i8, ptr %22, i32 -8
  %24 = load ptr, ptr %23, align 4, !tbaa !28
  %25 = icmp eq ptr %24, null
  %26 = select i1 %25, i32 6, i32 1
  br label %49

27:                                               ; preds = %5
  br i1 %9, label %28, label %49

28:                                               ; preds = %27
  %29 = and i64 %0, 9223372036854775807
  %30 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %31 = freeze i32 %30
  %32 = zext i32 %31 to i64
  %33 = add nsw i64 %29, -1
  %34 = icmp ult i64 %33, %32
  br i1 %34, label %35, label %49

35:                                               ; preds = %28
  %36 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %37 = icmp eq ptr %36, null
  br i1 %37, label %49, label %38

38:                                               ; preds = %35
  %39 = trunc i64 %0 to i32
  %40 = getelementptr inbounds nuw %struct.NmsSlot, ptr %36, i32 %39
  %41 = getelementptr inbounds nuw i8, ptr %40, i32 8
  %42 = load i64, ptr %41, align 8, !tbaa !23
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %49, label %44

44:                                               ; preds = %38
  %45 = getelementptr inbounds nuw i8, ptr %40, i32 28
  %46 = load i32, ptr %45, align 4, !tbaa !26
  %47 = add i32 %46, -2
  %48 = icmp ult i32 %47, 3
  br i1 %48, label %51, label %49

49:                                               ; preds = %44, %17, %11, %10, %20, %28, %27, %38, %35
  %50 = phi i32 [ 6, %35 ], [ 6, %38 ], [ 5, %27 ], [ 6, %28 ], [ %26, %20 ], [ 1, %44 ], [ 5, %10 ], [ 6, %11 ], [ 6, %17 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  store i64 0, ptr %6, align 8, !tbaa !45
  br label %61

51:                                               ; preds = %44
  %52 = getelementptr inbounds nuw i8, ptr %40, i32 16
  %53 = load i32, ptr %52, align 8, !tbaa !38
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  store i64 0, ptr %6, align 8, !tbaa !45
  %54 = icmp eq i32 %2, 1
  %55 = trunc i64 %1 to i32
  %56 = select i1 %54, i32 %55, i32 0
  %57 = icmp eq i32 %4, 1
  %58 = trunc i64 %3 to i32
  %59 = select i1 %57, i32 %58, i32 %53
  %60 = call i32 @nms_vm_array_slice(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %56, i32 noundef %59, ptr noundef nonnull %6) #27
  br label %61

61:                                               ; preds = %49, %51
  %62 = phi i32 [ %60, %51 ], [ %50, %49 ]
  %63 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %64 = icmp eq i32 %63, 0
  %65 = icmp ne i32 %62, 0
  %66 = and i1 %65, %64
  br i1 %66, label %67, label %68

67:                                               ; preds = %61
  store i32 %62, ptr @nms_module_error, align 4, !tbaa !1
  br label %68

68:                                               ; preds = %61, %67
  %69 = load i64, ptr %6, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  ret i64 %69
}

; Function Attrs: nofree norecurse nosync nounwind
define hidden i64 @nms_module_array_create(i32 noundef %0) local_unnamed_addr #3 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #28
  store i64 0, ptr %2, align 8, !tbaa !45
  %3 = call fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr noundef nonnull @nms_module_instance, i32 noundef %0, i32 noundef 8, ptr noundef nonnull %2) #27
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !1
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #28
  ret i64 %10
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_split_values(i64 noundef %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  store i64 0, ptr %3, align 8, !tbaa !45
  %4 = call fastcc range(i32 0, 7) i32 @split_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3, i32 noundef 1) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  ret i64 %11
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 7) i32 @nms_module_array_append_value(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #4 {
  %4 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4)
  store i64 %1, ptr %4, align 8
  %5 = getelementptr inbounds nuw i8, ptr %4, i32 8
  store i32 %2, ptr %5, align 8
  %6 = getelementptr inbounds nuw i8, ptr %4, i32 12
  store i32 0, ptr %6, align 4
  %7 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef 0, ptr noundef nonnull byval(%struct.NmsValue) align 8 %4, i32 noundef 1) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %4)
  %8 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %9 = icmp eq i32 %8, 0
  %10 = icmp ne i32 %7, 0
  %11 = and i1 %10, %9
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  store i32 %7, ptr @nms_module_error, align 4, !tbaa !1
  br label %13

13:                                               ; preds = %3, %12
  ret i32 %7
}

; Function Attrs: nofree norecurse nounwind
define hidden range(i32 0, 8) i32 @nms_module_array_set_value(i64 noundef %0, i64 noundef %1, i64 noundef %2, i32 noundef %3) local_unnamed_addr #4 {
  %5 = alloca %struct.NmsValue, align 8
  %6 = icmp sgt i64 %0, -1
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %8 = icmp eq i32 %7, 0
  br i1 %6, label %9, label %26

9:                                                ; preds = %4
  br i1 %8, label %10, label %57

10:                                               ; preds = %9
  %11 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %12 = freeze i32 %11
  %13 = zext i32 %12 to i64
  %14 = add nsw i64 %0, -1
  %15 = icmp ult i64 %14, %13
  br i1 %15, label %16, label %57

16:                                               ; preds = %10
  %17 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %18 = icmp eq ptr %17, null
  br i1 %18, label %57, label %19

19:                                               ; preds = %16
  %20 = trunc nuw i64 %0 to i32
  %21 = getelementptr %struct.NmsView, ptr %17, i32 %20
  %22 = getelementptr i8, ptr %21, i32 -8
  %23 = load ptr, ptr %22, align 4, !tbaa !28
  %24 = icmp eq ptr %23, null
  %25 = select i1 %24, i32 6, i32 1
  br label %57

26:                                               ; preds = %4
  br i1 %8, label %27, label %57

27:                                               ; preds = %26
  %28 = and i64 %0, 9223372036854775807
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %30 = freeze i32 %29
  %31 = zext i32 %30 to i64
  %32 = add nsw i64 %28, -1
  %33 = icmp ult i64 %32, %31
  br i1 %33, label %34, label %57

34:                                               ; preds = %27
  %35 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %36 = icmp eq ptr %35, null
  br i1 %36, label %57, label %37

37:                                               ; preds = %34
  %38 = trunc i64 %0 to i32
  %39 = getelementptr inbounds nuw %struct.NmsSlot, ptr %35, i32 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i32 8
  %41 = load i64, ptr %40, align 8, !tbaa !23
  %42 = icmp eq i64 %41, 0
  br i1 %42, label %57, label %43

43:                                               ; preds = %37
  %44 = getelementptr inbounds nuw i8, ptr %39, i32 28
  %45 = load i32, ptr %44, align 4, !tbaa !26
  %46 = add i32 %45, -2
  %47 = icmp ult i32 %46, 3
  br i1 %47, label %48, label %57

48:                                               ; preds = %43
  %49 = getelementptr inbounds nuw i8, ptr %39, i32 16
  %50 = load i32, ptr %49, align 8, !tbaa !38
  %51 = zext i32 %50 to i64
  %52 = icmp ult i64 %1, %51
  br i1 %52, label %53, label %57

53:                                               ; preds = %48
  call void @llvm.lifetime.start.p0(ptr nonnull %5)
  store i64 %2, ptr %5, align 8
  %54 = getelementptr inbounds nuw i8, ptr %5, i32 8
  store i32 %3, ptr %54, align 8
  %55 = getelementptr inbounds nuw i8, ptr %5, i32 12
  store i32 0, ptr %55, align 4
  %56 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull byval(%struct.NmsValue) align 8 %5, i32 noundef 0) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  br label %57

57:                                               ; preds = %34, %37, %26, %27, %19, %9, %10, %16, %43, %48, %53
  %58 = phi i32 [ %56, %53 ], [ 7, %48 ], [ 6, %34 ], [ 6, %37 ], [ 5, %26 ], [ 6, %27 ], [ %25, %19 ], [ 1, %43 ], [ 5, %9 ], [ 6, %10 ], [ 6, %16 ]
  %59 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %60 = icmp eq i32 %59, 0
  %61 = icmp ne i32 %58, 0
  %62 = and i1 %61, %60
  br i1 %62, label %63, label %64

63:                                               ; preds = %57
  store i32 %58, ptr @nms_module_error, align 4, !tbaa !1
  br label %64

64:                                               ; preds = %57, %63
  ret i32 %58
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_module_array_get_value(i64 noundef %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #6 {
  %5 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %5, i8 0, i32 16, i1 false)
  %6 = icmp ne ptr %2, null
  %7 = icmp ne ptr %3, null
  %8 = and i1 %6, %7
  br i1 %8, label %9, label %16

9:                                                ; preds = %4
  %10 = call i32 @nms_value_array_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %5) #27
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %16

12:                                               ; preds = %9
  %13 = load i64, ptr %5, align 8, !tbaa !56
  store i64 %13, ptr %2, align 8, !tbaa !45
  %14 = getelementptr inbounds nuw i8, ptr %5, i32 8
  %15 = load i32, ptr %14, align 8, !tbaa !54
  store i32 %15, ptr %3, align 4, !tbaa !1
  br label %21

16:                                               ; preds = %4, %9
  %17 = phi i32 [ %10, %9 ], [ 6, %4 ]
  %18 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %20, label %21

20:                                               ; preds = %16
  store i32 %17, ptr @nms_module_error, align 4, !tbaa !1
  br label %21

21:                                               ; preds = %12, %16, %20
  %22 = phi i32 [ 0, %12 ], [ %17, %16 ], [ %17, %20 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  ret i32 %22
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i32 0, 7) i32 @nms_module_array_pop_value(i64 noundef %0, ptr noundef writeonly captures(address_is_null) %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #6 {
  %4 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 8 dereferenceable(16) %4, i8 0, i32 16, i1 false)
  %5 = icmp ne ptr %1, null
  %6 = icmp ne ptr %2, null
  %7 = and i1 %5, %6
  br i1 %7, label %8, label %15

8:                                                ; preds = %3
  %9 = call i32 @nms_value_array_pop(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %4) #27
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %15

11:                                               ; preds = %8
  %12 = load i64, ptr %4, align 8, !tbaa !56
  store i64 %12, ptr %1, align 8, !tbaa !45
  %13 = getelementptr inbounds nuw i8, ptr %4, i32 8
  %14 = load i32, ptr %13, align 8, !tbaa !54
  store i32 %14, ptr %2, align 4, !tbaa !1
  br label %20

15:                                               ; preds = %3, %8
  %16 = phi i32 [ %9, %8 ], [ 6, %3 ]
  %17 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %18 = icmp eq i32 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %15
  store i32 %16, ptr @nms_module_error, align 4, !tbaa !1
  br label %20

20:                                               ; preds = %11, %15, %19
  %21 = phi i32 [ 0, %11 ], [ %16, %15 ], [ %16, %19 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  ret i32 %21
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i64 @nms_module_array_get(i64 noundef %0, i64 noundef %1) local_unnamed_addr #5 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  store i64 0, ptr %3, align 8, !tbaa !45
  %4 = call i32 @nms_string_array_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i32 @nms_module_array_length(i64 noundef %0) local_unnamed_addr #17 {
  %2 = icmp sgt i64 %0, -1
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %4 = icmp eq i32 %3, 0
  br i1 %2, label %5, label %22

5:                                                ; preds = %1
  br i1 %4, label %6, label %46

6:                                                ; preds = %5
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %8 = freeze i32 %7
  %9 = zext i32 %8 to i64
  %10 = add nsw i64 %0, -1
  %11 = icmp ult i64 %10, %9
  br i1 %11, label %12, label %46

12:                                               ; preds = %6
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %14 = icmp eq ptr %13, null
  br i1 %14, label %46, label %15

15:                                               ; preds = %12
  %16 = trunc nuw i64 %0 to i32
  %17 = getelementptr %struct.NmsView, ptr %13, i32 %16
  %18 = getelementptr i8, ptr %17, i32 -8
  %19 = load ptr, ptr %18, align 4, !tbaa !28
  %20 = icmp eq ptr %19, null
  %21 = select i1 %20, i32 6, i32 1
  br label %46

22:                                               ; preds = %1
  br i1 %4, label %23, label %46

23:                                               ; preds = %22
  %24 = and i64 %0, 9223372036854775807
  %25 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %26 = freeze i32 %25
  %27 = zext i32 %26 to i64
  %28 = add nsw i64 %24, -1
  %29 = icmp ult i64 %28, %27
  br i1 %29, label %30, label %46

30:                                               ; preds = %23
  %31 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %32 = icmp eq ptr %31, null
  br i1 %32, label %46, label %33

33:                                               ; preds = %30
  %34 = trunc i64 %0 to i32
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %31, i32 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i32 8
  %37 = load i64, ptr %36, align 8, !tbaa !23
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %46, label %39

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %35, i32 28
  %41 = load i32, ptr %40, align 4, !tbaa !26
  %42 = icmp eq i32 %41, 2
  br i1 %42, label %43, label %46

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %35, i32 16
  %45 = load i32, ptr %44, align 8, !tbaa !38
  br label %51

46:                                               ; preds = %5, %6, %12, %15, %22, %23, %30, %33, %39
  %47 = phi i32 [ 5, %22 ], [ 1, %39 ], [ 6, %30 ], [ 6, %12 ], [ 6, %6 ], [ 5, %5 ], [ 6, %33 ], [ %21, %15 ], [ 6, %23 ]
  %48 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %49 = icmp eq i32 %48, 0
  br i1 %49, label %50, label %51

50:                                               ; preds = %46
  store i32 %47, ptr @nms_module_error, align 4, !tbaa !1
  br label %51

51:                                               ; preds = %43, %46, %50
  %52 = phi i32 [ %45, %43 ], [ 0, %46 ], [ 0, %50 ]
  ret i32 %52
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i32 @nms_module_array_value_length(i64 noundef %0) local_unnamed_addr #17 {
  %2 = icmp sgt i64 %0, -1
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %4 = icmp eq i32 %3, 0
  br i1 %2, label %5, label %22

5:                                                ; preds = %1
  br i1 %4, label %6, label %47

6:                                                ; preds = %5
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %8 = freeze i32 %7
  %9 = zext i32 %8 to i64
  %10 = add nsw i64 %0, -1
  %11 = icmp ult i64 %10, %9
  br i1 %11, label %12, label %47

12:                                               ; preds = %6
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %14 = icmp eq ptr %13, null
  br i1 %14, label %47, label %15

15:                                               ; preds = %12
  %16 = trunc nuw i64 %0 to i32
  %17 = getelementptr %struct.NmsView, ptr %13, i32 %16
  %18 = getelementptr i8, ptr %17, i32 -8
  %19 = load ptr, ptr %18, align 4, !tbaa !28
  %20 = icmp eq ptr %19, null
  %21 = select i1 %20, i32 6, i32 1
  br label %47

22:                                               ; preds = %1
  br i1 %4, label %23, label %47

23:                                               ; preds = %22
  %24 = and i64 %0, 9223372036854775807
  %25 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %26 = freeze i32 %25
  %27 = zext i32 %26 to i64
  %28 = add nsw i64 %24, -1
  %29 = icmp ult i64 %28, %27
  br i1 %29, label %30, label %47

30:                                               ; preds = %23
  %31 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %32 = icmp eq ptr %31, null
  br i1 %32, label %47, label %33

33:                                               ; preds = %30
  %34 = trunc i64 %0 to i32
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %31, i32 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i32 8
  %37 = load i64, ptr %36, align 8, !tbaa !23
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %47, label %39

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %35, i32 28
  %41 = load i32, ptr %40, align 4, !tbaa !26
  %42 = add i32 %41, -2
  %43 = icmp ult i32 %42, 3
  br i1 %43, label %44, label %47

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %35, i32 16
  %46 = load i32, ptr %45, align 8, !tbaa !38
  br label %52

47:                                               ; preds = %5, %6, %12, %15, %22, %23, %30, %33, %39
  %48 = phi i32 [ 5, %22 ], [ 1, %39 ], [ 6, %30 ], [ 6, %12 ], [ 6, %6 ], [ 5, %5 ], [ 6, %33 ], [ %21, %15 ], [ 6, %23 ]
  %49 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %50 = icmp eq i32 %49, 0
  br i1 %50, label %51, label %52

51:                                               ; preds = %47
  store i32 %48, ptr @nms_module_error, align 4, !tbaa !1
  br label %52

52:                                               ; preds = %44, %47, %51
  %53 = phi i32 [ %46, %44 ], [ 0, %47 ], [ 0, %51 ]
  ret i32 %53
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_replace(i64 noundef %0, i64 noundef %1, i64 noundef %2) local_unnamed_addr #4 {
  %4 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #28
  store i64 0, ptr %4, align 8, !tbaa !45
  %5 = call i32 @nms_replace_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef nonnull %4) #27
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !1
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i64, ptr %4, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  ret i64 %12
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_case(i64 noundef %0, i32 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  store i64 0, ptr %3, align 8, !tbaa !45
  %4 = call i32 @nms_case_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, ptr noundef nonnull %3) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  ret i64 %11
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_trim(i64 noundef %0) local_unnamed_addr #4 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #28
  store i64 0, ptr %2, align 8, !tbaa !45
  %3 = call i32 @nms_trim_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #27
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !1
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #28
  ret i64 %10
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_substr(i64 noundef %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #4 {
  %4 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #28
  store i64 0, ptr %4, align 8, !tbaa !45
  %5 = call i32 @nms_substr_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull %4) #27
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !1
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i64, ptr %4, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #28
  ret i64 %12
}

; Function Attrs: nofree norecurse nounwind
define hidden i64 @nms_module_concat(i64 noundef %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  store i64 0, ptr %3, align 8, !tbaa !45
  %4 = call i32 @nms_concat_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3) #27
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !1
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !45
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i64 0, 4294967296) i64 @nms_module_length(i64 noundef %0) local_unnamed_addr #17 {
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %4, label %45

4:                                                ; preds = %1
  %5 = icmp sgt i64 %0, -1
  br i1 %5, label %28, label %6

6:                                                ; preds = %4
  %7 = and i64 %0, 9223372036854775807
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %9 = freeze i32 %8
  %10 = zext i32 %9 to i64
  %11 = add nsw i64 %7, -1
  %12 = icmp ult i64 %11, %10
  br i1 %12, label %13, label %45

13:                                               ; preds = %6
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %15 = icmp eq ptr %14, null
  br i1 %15, label %45, label %16

16:                                               ; preds = %13
  %17 = trunc i64 %0 to i32
  %18 = getelementptr inbounds nuw %struct.NmsSlot, ptr %14, i32 %17
  %19 = getelementptr inbounds nuw i8, ptr %18, i32 8
  %20 = load i64, ptr %19, align 8, !tbaa !23
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %45, label %22

22:                                               ; preds = %16
  %23 = getelementptr inbounds nuw i8, ptr %18, i32 28
  %24 = load i32, ptr %23, align 4, !tbaa !26
  %25 = icmp eq i32 %24, 1
  br i1 %25, label %26, label %45

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %18, i32 16
  br label %50

28:                                               ; preds = %4
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %30 = freeze i32 %29
  %31 = zext i32 %30 to i64
  %32 = add nsw i64 %0, -1
  %33 = icmp ult i64 %32, %31
  br i1 %33, label %34, label %45

34:                                               ; preds = %28
  %35 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %36 = icmp eq ptr %35, null
  br i1 %36, label %45, label %37

37:                                               ; preds = %34
  %38 = trunc nuw i64 %0 to i32
  %39 = getelementptr %struct.NmsView, ptr %35, i32 %38
  %40 = getelementptr i8, ptr %39, i32 -8
  %41 = load ptr, ptr %40, align 4, !tbaa !28
  %42 = icmp eq ptr %41, null
  br i1 %42, label %45, label %43

43:                                               ; preds = %37
  %44 = getelementptr i8, ptr %39, i32 -4
  br label %50

45:                                               ; preds = %1, %6, %13, %16, %22, %28, %34, %37
  %46 = phi i32 [ 6, %6 ], [ 6, %37 ], [ 6, %16 ], [ 5, %1 ], [ 6, %28 ], [ 6, %34 ], [ 1, %22 ], [ 6, %13 ]
  %47 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %49, label %54

49:                                               ; preds = %45
  store i32 %46, ptr @nms_module_error, align 4, !tbaa !1
  br label %54

50:                                               ; preds = %43, %26
  %51 = phi ptr [ %27, %26 ], [ %44, %43 ]
  %52 = load i32, ptr %51, align 4, !tbaa !1
  %53 = zext i32 %52 to i64
  br label %54

54:                                               ; preds = %49, %45, %50
  %55 = phi i64 [ %53, %50 ], [ 0, %45 ], [ 0, %49 ]
  ret i64 %55
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden range(i64 -4294967295, 4294967296) i64 @nms_module_order(i64 noundef %0, i64 noundef %1) local_unnamed_addr #18 {
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 64), align 8, !tbaa !21
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %92

5:                                                ; preds = %2
  %6 = icmp sgt i64 %0, -1
  br i1 %6, label %30, label %7

7:                                                ; preds = %5
  %8 = and i64 %0, 9223372036854775807
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %10 = freeze i32 %9
  %11 = zext i32 %10 to i64
  %12 = add nsw i64 %8, -1
  %13 = icmp ult i64 %12, %11
  br i1 %13, label %14, label %92

14:                                               ; preds = %7
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %16 = icmp eq ptr %15, null
  br i1 %16, label %92, label %17

17:                                               ; preds = %14
  %18 = trunc i64 %0 to i32
  %19 = getelementptr inbounds nuw %struct.NmsSlot, ptr %15, i32 %18
  %20 = getelementptr inbounds nuw i8, ptr %19, i32 8
  %21 = load i64, ptr %20, align 8, !tbaa !23
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %92, label %23

23:                                               ; preds = %17
  %24 = getelementptr inbounds nuw i8, ptr %19, i32 28
  %25 = load i32, ptr %24, align 4, !tbaa !26
  %26 = icmp eq i32 %25, 1
  br i1 %26, label %27, label %92

27:                                               ; preds = %23
  %28 = load ptr, ptr %19, align 8, !tbaa !27
  %29 = getelementptr inbounds nuw i8, ptr %19, i32 16
  br label %47

30:                                               ; preds = %5
  %31 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %32 = freeze i32 %31
  %33 = zext i32 %32 to i64
  %34 = add nsw i64 %0, -1
  %35 = icmp ult i64 %34, %33
  br i1 %35, label %36, label %92

36:                                               ; preds = %30
  %37 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %38 = icmp eq ptr %37, null
  br i1 %38, label %92, label %39

39:                                               ; preds = %36
  %40 = trunc nuw i64 %0 to i32
  %41 = getelementptr %struct.NmsView, ptr %37, i32 %40
  %42 = getelementptr i8, ptr %41, i32 -8
  %43 = load ptr, ptr %42, align 4, !tbaa !28
  %44 = icmp eq ptr %43, null
  br i1 %44, label %92, label %45

45:                                               ; preds = %39
  %46 = getelementptr i8, ptr %41, i32 -4
  br label %47

47:                                               ; preds = %27, %45
  %48 = phi ptr [ %43, %45 ], [ %28, %27 ]
  %49 = phi ptr [ %46, %45 ], [ %29, %27 ]
  %50 = load i32, ptr %49, align 4, !tbaa !1
  %51 = icmp sgt i64 %1, -1
  br i1 %51, label %75, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 9223372036854775807
  %54 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 52), align 4
  %55 = freeze i32 %54
  %56 = zext i32 %55 to i64
  %57 = add nsw i64 %53, -1
  %58 = icmp ult i64 %57, %56
  br i1 %58, label %59, label %92

59:                                               ; preds = %52
  %60 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 16), align 8, !tbaa !13
  %61 = icmp eq ptr %60, null
  br i1 %61, label %92, label %62

62:                                               ; preds = %59
  %63 = trunc i64 %1 to i32
  %64 = getelementptr inbounds nuw %struct.NmsSlot, ptr %60, i32 %63
  %65 = getelementptr inbounds nuw i8, ptr %64, i32 8
  %66 = load i64, ptr %65, align 8, !tbaa !23
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %92, label %68

68:                                               ; preds = %62
  %69 = getelementptr inbounds nuw i8, ptr %64, i32 28
  %70 = load i32, ptr %69, align 4, !tbaa !26
  %71 = icmp eq i32 %70, 1
  br i1 %71, label %72, label %92

72:                                               ; preds = %68
  %73 = load ptr, ptr %64, align 8, !tbaa !27
  %74 = getelementptr inbounds nuw i8, ptr %64, i32 16
  br label %97

75:                                               ; preds = %47
  %76 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 48), align 8
  %77 = freeze i32 %76
  %78 = zext i32 %77 to i64
  %79 = add nsw i64 %1, -1
  %80 = icmp ult i64 %79, %78
  br i1 %80, label %81, label %92

81:                                               ; preds = %75
  %82 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 12), align 4, !tbaa !11
  %83 = icmp eq ptr %82, null
  br i1 %83, label %92, label %84

84:                                               ; preds = %81
  %85 = trunc nuw i64 %1 to i32
  %86 = getelementptr %struct.NmsView, ptr %82, i32 %85
  %87 = getelementptr i8, ptr %86, i32 -8
  %88 = load ptr, ptr %87, align 4, !tbaa !28
  %89 = icmp eq ptr %88, null
  br i1 %89, label %92, label %90

90:                                               ; preds = %84
  %91 = getelementptr i8, ptr %86, i32 -4
  br label %97

92:                                               ; preds = %7, %23, %14, %36, %30, %2, %17, %39, %84, %81, %75, %68, %62, %59, %52
  %93 = phi i32 [ 1, %68 ], [ 6, %52 ], [ 6, %84 ], [ 6, %62 ], [ 5, %2 ], [ 6, %75 ], [ 6, %81 ], [ 6, %30 ], [ 6, %59 ], [ 6, %39 ], [ 6, %7 ], [ 1, %23 ], [ 6, %14 ], [ 6, %17 ], [ 6, %36 ]
  %94 = load i32, ptr @nms_module_error, align 4, !tbaa !1
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %96, label %121

96:                                               ; preds = %92
  store i32 %93, ptr @nms_module_error, align 4, !tbaa !1
  br label %121

97:                                               ; preds = %90, %72
  %98 = phi ptr [ %88, %90 ], [ %73, %72 ]
  %99 = phi ptr [ %91, %90 ], [ %74, %72 ]
  %100 = load i32, ptr %99, align 4, !tbaa !1
  %101 = tail call i32 @llvm.umin.i32(i32 %50, i32 %100)
  %102 = icmp eq i32 %101, 0
  br i1 %102, label %113, label %106

103:                                              ; preds = %106
  %104 = add nuw i32 %107, 1
  %105 = icmp eq i32 %104, %101
  br i1 %105, label %113, label %106, !llvm.loop !186

106:                                              ; preds = %97, %103
  %107 = phi i32 [ %104, %103 ], [ 0, %97 ]
  %108 = getelementptr inbounds nuw i8, ptr %48, i32 %107
  %109 = load i8, ptr %108, align 1, !tbaa !46
  %110 = getelementptr inbounds nuw i8, ptr %98, i32 %107
  %111 = load i8, ptr %110, align 1, !tbaa !46
  %112 = icmp eq i8 %109, %111
  br i1 %112, label %103, label %117

113:                                              ; preds = %103, %97
  %114 = zext i32 %50 to i64
  %115 = zext i32 %100 to i64
  %116 = sub nsw i64 %114, %115
  br label %121

117:                                              ; preds = %106
  %118 = zext i8 %109 to i64
  %119 = zext i8 %111 to i64
  %120 = sub nsw i64 %118, %119
  br label %121

121:                                              ; preds = %117, %113, %96, %92
  %122 = phi i64 [ 0, %96 ], [ 0, %92 ], [ %120, %117 ], [ %116, %113 ]
  ret i64 %122
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i64 @nms_module_live_objects() local_unnamed_addr #15 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 40), align 8, !tbaa !19
  ret i64 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define hidden i64 @nms_module_live_bytes() local_unnamed_addr #15 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i32 32), align 8, !tbaa !20
  ret i64 %1
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(read)
declare i32 @llvm.wasm.memory.size.i32(i32) #19

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare i32 @llvm.wasm.memory.grow.i32(i32, i32) #20

; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @nbp_shift(ptr noundef captures(none) %0, i32 noundef %1) unnamed_addr #21 {
  %3 = alloca %struct.NbpBig, align 4
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 512
  %5 = load i32, ptr %4, align 4, !tbaa !136
  %6 = icmp ne i32 %5, 0
  %7 = icmp ne i32 %1, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %53

9:                                                ; preds = %2
  %10 = lshr i32 %1, 5
  %11 = and i32 %1, 31
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %21, label %13

13:                                               ; preds = %9
  %14 = getelementptr i32, ptr %0, i32 %5
  %15 = getelementptr i8, ptr %14, i32 -4
  %16 = load i32, ptr %15, align 4, !tbaa !1
  %17 = sub nuw nsw i32 32, %11
  %18 = lshr i32 %16, %17
  %19 = icmp ne i32 %18, 0
  %20 = zext i1 %19 to i32
  br label %21

21:                                               ; preds = %13, %9
  %22 = phi i32 [ 0, %9 ], [ %20, %13 ]
  %23 = icmp ugt i32 %1, 4095
  br i1 %23, label %53, label %24

24:                                               ; preds = %21
  %25 = add i32 %5, %10
  %26 = add i32 %25, %22
  %27 = icmp ugt i32 %26, 128
  br i1 %27, label %53, label %28

28:                                               ; preds = %24
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %3, i8 0, i32 512, i1 false)
  %29 = getelementptr inbounds nuw i8, ptr %3, i32 512
  store i32 %26, ptr %29, align 4, !tbaa !136
  %30 = zext nneg i32 %11 to i64
  %31 = getelementptr i32, ptr %3, i32 %10
  br label %33

32:                                               ; preds = %50
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %0, ptr noundef nonnull align 4 dereferenceable(516) %3, i32 516, i1 false), !tbaa.struct !187
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #28
  br label %53

33:                                               ; preds = %28, %50
  %34 = phi i32 [ 0, %28 ], [ %51, %50 ]
  %35 = getelementptr inbounds nuw i32, ptr %0, i32 %34
  %36 = load i32, ptr %35, align 4, !tbaa !1
  %37 = zext i32 %36 to i64
  %38 = shl nuw nsw i64 %37, %30
  %39 = trunc i64 %38 to i32
  %40 = getelementptr i32, ptr %31, i32 %34
  %41 = load i32, ptr %40, align 4, !tbaa !1
  %42 = or i32 %41, %39
  store i32 %42, ptr %40, align 4, !tbaa !1
  %43 = lshr i64 %38, 32
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %50, label %45

45:                                               ; preds = %33
  %46 = trunc nuw nsw i64 %43 to i32
  %47 = getelementptr i8, ptr %40, i32 4
  %48 = load i32, ptr %47, align 4, !tbaa !1
  %49 = or i32 %48, %46
  store i32 %49, ptr %47, align 4, !tbaa !1
  br label %50

50:                                               ; preds = %45, %33
  %51 = add nuw i32 %34, 1
  %52 = icmp eq i32 %51, %5
  br i1 %52, label %32, label %33, !llvm.loop !188

53:                                               ; preds = %32, %24, %21, %2
  %54 = phi i32 [ 1, %2 ], [ 1, %32 ], [ 0, %24 ], [ 0, %21 ]
  ret i32 %54
}

; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc range(i32 0, 2) i32 @nbp_rational(ptr noundef byval(%struct.NbpBig) align 4 captures(none) %0, ptr noundef byval(%struct.NbpBig) align 4 captures(none) %1, i32 noundef range(i32 0, 2) %2, ptr noundef nonnull writeonly captures(none) %3) unnamed_addr #22 {
  %5 = alloca %struct.NbpBig, align 4
  %6 = alloca %struct.NbpBig, align 4
  %7 = alloca %struct.NbpBig, align 4
  %8 = alloca %struct.NbpBig, align 4
  %9 = alloca %struct.NbpBig, align 4
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 512
  %11 = load i32, ptr %10, align 4, !tbaa !136
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %20, label %13

13:                                               ; preds = %4
  %14 = getelementptr i32, ptr %0, i32 %11
  %15 = getelementptr i8, ptr %14, i32 -4
  %16 = load i32, ptr %15, align 4, !tbaa !1
  %17 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %16, i1 false)
  %18 = shl i32 %11, 5
  %19 = sub i32 %18, %17
  br label %20

20:                                               ; preds = %4, %13
  %21 = phi i32 [ %19, %13 ], [ 0, %4 ]
  %22 = getelementptr inbounds nuw i8, ptr %1, i32 512
  %23 = load i32, ptr %22, align 4, !tbaa !136
  %24 = icmp eq i32 %23, 0
  br i1 %24, label %32, label %25

25:                                               ; preds = %20
  %26 = getelementptr i32, ptr %1, i32 %23
  %27 = getelementptr i8, ptr %26, i32 -4
  %28 = load i32, ptr %27, align 4, !tbaa !1
  %29 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %28, i1 false)
  %30 = shl i32 %23, 5
  %31 = sub i32 %29, %30
  br label %32

32:                                               ; preds = %20, %25
  %33 = phi i32 [ %31, %25 ], [ 0, %20 ]
  %34 = add i32 %33, %21
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #28
  %35 = icmp slt i32 %34, 0
  %36 = select i1 %35, ptr %0, ptr %1
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %36, i32 516, i1 false)
  %37 = tail call i32 @llvm.abs.i32(i32 %34, i1 true)
  %38 = getelementptr inbounds nuw i8, ptr %9, i32 512
  %39 = load i32, ptr %38, align 4, !tbaa !136
  %40 = icmp ne i32 %39, 0
  %41 = icmp ne i32 %34, 0
  %42 = and i1 %41, %40
  br i1 %42, label %43, label %87

43:                                               ; preds = %32
  %44 = lshr i32 %37, 5
  %45 = and i32 %37, 31
  %46 = icmp eq i32 %45, 0
  br i1 %46, label %55, label %47

47:                                               ; preds = %43
  %48 = getelementptr i32, ptr %9, i32 %39
  %49 = getelementptr i8, ptr %48, i32 -4
  %50 = load i32, ptr %49, align 4, !tbaa !1
  %51 = sub nuw nsw i32 32, %45
  %52 = lshr i32 %50, %51
  %53 = icmp ne i32 %52, 0
  %54 = zext i1 %53 to i32
  br label %55

55:                                               ; preds = %47, %43
  %56 = phi i32 [ 0, %43 ], [ %54, %47 ]
  %57 = icmp samesign ugt i32 %37, 4095
  br i1 %57, label %442, label %58

58:                                               ; preds = %55
  %59 = add i32 %39, %44
  %60 = add i32 %59, %56
  %61 = icmp ugt i32 %60, 128
  br i1 %61, label %442, label %62

62:                                               ; preds = %58
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %8, i8 0, i32 512, i1 false)
  %63 = getelementptr inbounds nuw i8, ptr %8, i32 512
  store i32 %60, ptr %63, align 4, !tbaa !136
  %64 = zext nneg i32 %45 to i64
  %65 = getelementptr i32, ptr %8, i32 %44
  br label %67

66:                                               ; preds = %84
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %8, i32 516, i1 false), !tbaa.struct !187
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #28
  br label %87

67:                                               ; preds = %84, %62
  %68 = phi i32 [ 0, %62 ], [ %85, %84 ]
  %69 = getelementptr inbounds nuw i32, ptr %9, i32 %68
  %70 = load i32, ptr %69, align 4, !tbaa !1
  %71 = zext i32 %70 to i64
  %72 = shl nuw nsw i64 %71, %64
  %73 = trunc i64 %72 to i32
  %74 = getelementptr i32, ptr %65, i32 %68
  %75 = load i32, ptr %74, align 4, !tbaa !1
  %76 = or i32 %75, %73
  store i32 %76, ptr %74, align 4, !tbaa !1
  %77 = lshr i64 %72, 32
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %84, label %79

79:                                               ; preds = %67
  %80 = trunc nuw nsw i64 %77 to i32
  %81 = getelementptr i8, ptr %74, i32 4
  %82 = load i32, ptr %81, align 4, !tbaa !1
  %83 = or i32 %82, %80
  store i32 %83, ptr %81, align 4, !tbaa !1
  br label %84

84:                                               ; preds = %79, %67
  %85 = add nuw i32 %68, 1
  %86 = icmp eq i32 %85, %39
  br i1 %86, label %66, label %67, !llvm.loop !188

87:                                               ; preds = %66, %32
  %88 = load i32, ptr %38, align 4, !tbaa !136
  br i1 %35, label %89, label %105

89:                                               ; preds = %87
  %90 = icmp eq i32 %88, %23
  br i1 %90, label %93, label %91

91:                                               ; preds = %89
  %92 = icmp ugt i32 %88, %23
  br i1 %92, label %126, label %121

93:                                               ; preds = %89, %96
  %94 = phi i32 [ %97, %96 ], [ %23, %89 ]
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %123, label %96

96:                                               ; preds = %93
  %97 = add i32 %94, -1
  %98 = getelementptr inbounds nuw i32, ptr %9, i32 %97
  %99 = load i32, ptr %98, align 4, !tbaa !1
  %100 = getelementptr inbounds nuw i32, ptr %1, i32 %97
  %101 = load i32, ptr %100, align 4, !tbaa !1
  %102 = icmp eq i32 %99, %101
  br i1 %102, label %93, label %103, !llvm.loop !189

103:                                              ; preds = %96
  %104 = icmp ugt i32 %99, %101
  br i1 %104, label %123, label %121

105:                                              ; preds = %87
  %106 = icmp eq i32 %11, %88
  br i1 %106, label %109, label %107

107:                                              ; preds = %105
  %108 = icmp ugt i32 %11, %88
  br i1 %108, label %123, label %121

109:                                              ; preds = %105, %112
  %110 = phi i32 [ %113, %112 ], [ %11, %105 ]
  %111 = icmp eq i32 %110, 0
  br i1 %111, label %123, label %112

112:                                              ; preds = %109
  %113 = add i32 %110, -1
  %114 = getelementptr inbounds nuw i32, ptr %0, i32 %113
  %115 = load i32, ptr %114, align 4, !tbaa !1
  %116 = getelementptr inbounds nuw i32, ptr %9, i32 %113
  %117 = load i32, ptr %116, align 4, !tbaa !1
  %118 = icmp eq i32 %115, %117
  br i1 %118, label %109, label %119, !llvm.loop !189

119:                                              ; preds = %112
  %120 = icmp ugt i32 %115, %117
  br i1 %120, label %123, label %121

121:                                              ; preds = %91, %103, %107, %119
  %122 = add nsw i32 %34, -1
  br label %123

123:                                              ; preds = %109, %93, %119, %107, %103, %121
  %124 = phi i32 [ %122, %121 ], [ %34, %107 ], [ %34, %93 ], [ %34, %119 ], [ %34, %103 ], [ %34, %109 ]
  %125 = icmp sgt i32 %124, 1023
  br i1 %125, label %440, label %126

126:                                              ; preds = %91, %123
  %127 = phi i32 [ %124, %123 ], [ %34, %91 ]
  %128 = icmp sgt i32 %127, -1023
  %129 = sub nsw i32 52, %127
  %130 = select i1 %128, i32 %129, i32 1074
  %131 = icmp slt i32 %130, 0
  %132 = select i1 %131, ptr %1, ptr %0
  %133 = tail call i32 @llvm.abs.i32(i32 %130, i1 true)
  %134 = getelementptr inbounds nuw i8, ptr %132, i32 512
  %135 = load i32, ptr %134, align 4, !tbaa !136
  %136 = icmp ne i32 %135, 0
  %137 = icmp ne i32 %130, 0
  %138 = and i1 %136, %137
  br i1 %138, label %139, label %184

139:                                              ; preds = %126
  %140 = lshr i32 %133, 5
  %141 = and i32 %133, 31
  %142 = icmp eq i32 %141, 0
  br i1 %142, label %151, label %143

143:                                              ; preds = %139
  %144 = getelementptr i32, ptr %132, i32 %135
  %145 = getelementptr i8, ptr %144, i32 -4
  %146 = load i32, ptr %145, align 4, !tbaa !1
  %147 = sub nuw nsw i32 32, %141
  %148 = lshr i32 %146, %147
  %149 = icmp ne i32 %148, 0
  %150 = zext i1 %149 to i32
  br label %151

151:                                              ; preds = %143, %139
  %152 = phi i32 [ 0, %139 ], [ %150, %143 ]
  %153 = icmp samesign ugt i32 %133, 4095
  br i1 %153, label %442, label %154

154:                                              ; preds = %151
  %155 = add i32 %140, %135
  %156 = add i32 %155, %152
  %157 = icmp ugt i32 %156, 128
  br i1 %157, label %442, label %158

158:                                              ; preds = %154
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %7, i8 0, i32 512, i1 false)
  %159 = getelementptr inbounds nuw i8, ptr %7, i32 512
  store i32 %156, ptr %159, align 4, !tbaa !136
  %160 = zext nneg i32 %141 to i64
  %161 = getelementptr i32, ptr %7, i32 %140
  br label %164

162:                                              ; preds = %181
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %132, ptr noundef nonnull align 4 dereferenceable(516) %7, i32 516, i1 false), !tbaa.struct !187
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #28
  %163 = load i32, ptr %10, align 4, !tbaa !136
  br label %184

164:                                              ; preds = %181, %158
  %165 = phi i32 [ 0, %158 ], [ %182, %181 ]
  %166 = getelementptr inbounds nuw i32, ptr %132, i32 %165
  %167 = load i32, ptr %166, align 4, !tbaa !1
  %168 = zext i32 %167 to i64
  %169 = shl nuw nsw i64 %168, %160
  %170 = trunc i64 %169 to i32
  %171 = getelementptr i32, ptr %161, i32 %165
  %172 = load i32, ptr %171, align 4, !tbaa !1
  %173 = or i32 %172, %170
  store i32 %173, ptr %171, align 4, !tbaa !1
  %174 = lshr i64 %169, 32
  %175 = icmp eq i64 %174, 0
  br i1 %175, label %181, label %176

176:                                              ; preds = %164
  %177 = trunc nuw nsw i64 %174 to i32
  %178 = getelementptr i8, ptr %171, i32 4
  %179 = load i32, ptr %178, align 4, !tbaa !1
  %180 = or i32 %179, %177
  store i32 %180, ptr %178, align 4, !tbaa !1
  br label %181

181:                                              ; preds = %176, %164
  %182 = add nuw i32 %165, 1
  %183 = icmp eq i32 %182, %135
  br i1 %183, label %162, label %164, !llvm.loop !188

184:                                              ; preds = %162, %126
  %185 = phi i32 [ %163, %162 ], [ %11, %126 ]
  %186 = icmp eq i32 %185, 0
  br i1 %186, label %194, label %187

187:                                              ; preds = %184
  %188 = getelementptr i32, ptr %0, i32 %185
  %189 = getelementptr i8, ptr %188, i32 -4
  %190 = load i32, ptr %189, align 4, !tbaa !1
  %191 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %190, i1 false)
  %192 = shl i32 %185, 5
  %193 = sub i32 %192, %191
  br label %194

194:                                              ; preds = %184, %187
  %195 = phi i32 [ %193, %187 ], [ 0, %184 ]
  %196 = load i32, ptr %22, align 4, !tbaa !136
  %197 = icmp eq i32 %196, 0
  br i1 %197, label %205, label %198

198:                                              ; preds = %194
  %199 = getelementptr i32, ptr %1, i32 %196
  %200 = getelementptr i8, ptr %199, i32 -4
  %201 = load i32, ptr %200, align 4, !tbaa !1
  %202 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %201, i1 false)
  %203 = shl i32 %196, 5
  %204 = sub i32 %202, %203
  br label %205

205:                                              ; preds = %194, %198
  %206 = phi i32 [ %204, %198 ], [ 0, %194 ]
  %207 = add i32 %206, %195
  %208 = icmp sgt i32 %207, 63
  br i1 %208, label %442, label %209

209:                                              ; preds = %205
  %210 = icmp sgt i32 %207, -1
  br i1 %210, label %211, label %331

211:                                              ; preds = %209
  %212 = getelementptr inbounds nuw i8, ptr %6, i32 512
  %213 = zext nneg i32 %207 to i64
  br label %214

214:                                              ; preds = %211, %325
  %215 = phi i32 [ %185, %211 ], [ %326, %325 ]
  %216 = phi i32 [ %185, %211 ], [ %327, %325 ]
  %217 = phi i64 [ %213, %211 ], [ %329, %325 ]
  %218 = phi i64 [ 0, %211 ], [ %328, %325 ]
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %1, i32 516, i1 false), !tbaa.struct !187
  %219 = load i32, ptr %38, align 4, !tbaa !136
  %220 = icmp ne i32 %219, 0
  %221 = icmp ne i64 %217, 0
  %222 = and i1 %221, %220
  br i1 %222, label %223, label %268

223:                                              ; preds = %214
  %224 = trunc nuw nsw i64 %217 to i32
  %225 = lshr i32 %224, 5
  %226 = and i32 %224, 31
  %227 = icmp eq i32 %226, 0
  br i1 %227, label %236, label %228

228:                                              ; preds = %223
  %229 = getelementptr i32, ptr %9, i32 %219
  %230 = getelementptr i8, ptr %229, i32 -4
  %231 = load i32, ptr %230, align 4, !tbaa !1
  %232 = sub nuw nsw i32 32, %226
  %233 = lshr i32 %231, %232
  %234 = icmp ne i32 %233, 0
  %235 = zext i1 %234 to i32
  br label %236

236:                                              ; preds = %228, %223
  %237 = phi i32 [ 0, %223 ], [ %235, %228 ]
  %238 = icmp samesign ugt i64 %217, 4095
  br i1 %238, label %442, label %239

239:                                              ; preds = %236
  %240 = add i32 %219, %225
  %241 = add i32 %240, %237
  %242 = icmp ugt i32 %241, 128
  br i1 %242, label %442, label %243

243:                                              ; preds = %239
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %6, i8 0, i32 512, i1 false)
  store i32 %241, ptr %212, align 4, !tbaa !136
  %244 = and i64 %217, 31
  %245 = getelementptr i32, ptr %6, i32 %225
  br label %248

246:                                              ; preds = %265
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %6, i32 516, i1 false), !tbaa.struct !187
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #28
  %247 = load i32, ptr %38, align 4, !tbaa !136
  br label %268

248:                                              ; preds = %265, %243
  %249 = phi i32 [ 0, %243 ], [ %266, %265 ]
  %250 = getelementptr inbounds nuw i32, ptr %9, i32 %249
  %251 = load i32, ptr %250, align 4, !tbaa !1
  %252 = zext i32 %251 to i64
  %253 = shl nuw nsw i64 %252, %244
  %254 = trunc i64 %253 to i32
  %255 = getelementptr i32, ptr %245, i32 %249
  %256 = load i32, ptr %255, align 4, !tbaa !1
  %257 = or i32 %256, %254
  store i32 %257, ptr %255, align 4, !tbaa !1
  %258 = lshr i64 %253, 32
  %259 = icmp eq i64 %258, 0
  br i1 %259, label %265, label %260

260:                                              ; preds = %248
  %261 = trunc nuw nsw i64 %258 to i32
  %262 = getelementptr i8, ptr %255, i32 4
  %263 = load i32, ptr %262, align 4, !tbaa !1
  %264 = or i32 %263, %261
  store i32 %264, ptr %262, align 4, !tbaa !1
  br label %265

265:                                              ; preds = %260, %248
  %266 = add nuw i32 %249, 1
  %267 = icmp eq i32 %266, %219
  br i1 %267, label %246, label %248, !llvm.loop !188

268:                                              ; preds = %246, %214
  %269 = phi i32 [ %247, %246 ], [ %219, %214 ]
  %270 = icmp eq i32 %216, %269
  br i1 %270, label %273, label %271

271:                                              ; preds = %268
  %272 = icmp ugt i32 %216, %269
  br i1 %272, label %287, label %325

273:                                              ; preds = %268, %276
  %274 = phi i32 [ %277, %276 ], [ %216, %268 ]
  %275 = icmp eq i32 %274, 0
  br i1 %275, label %285, label %276

276:                                              ; preds = %273
  %277 = add i32 %274, -1
  %278 = getelementptr inbounds nuw i32, ptr %0, i32 %277
  %279 = load i32, ptr %278, align 4, !tbaa !1
  %280 = getelementptr inbounds nuw i32, ptr %9, i32 %277
  %281 = load i32, ptr %280, align 4, !tbaa !1
  %282 = icmp eq i32 %279, %281
  br i1 %282, label %273, label %283, !llvm.loop !189

283:                                              ; preds = %276
  %284 = icmp ugt i32 %279, %281
  br i1 %284, label %285, label %325

285:                                              ; preds = %273, %283
  %286 = icmp eq i32 %216, 0
  br i1 %286, label %320, label %287

287:                                              ; preds = %271, %285
  br label %299

288:                                              ; preds = %307
  %289 = icmp eq i32 %318, 0
  br i1 %289, label %320, label %290

290:                                              ; preds = %288, %296
  %291 = phi i32 [ %297, %296 ], [ %318, %288 ]
  %292 = getelementptr i32, ptr %0, i32 %291
  %293 = getelementptr i8, ptr %292, i32 -4
  %294 = load i32, ptr %293, align 4, !tbaa !1
  %295 = icmp eq i32 %294, 0
  br i1 %295, label %296, label %320

296:                                              ; preds = %290
  %297 = add i32 %291, -1
  store i32 %297, ptr %10, align 4, !tbaa !136
  %298 = icmp eq i32 %297, 0
  br i1 %298, label %320, label %290, !llvm.loop !190

299:                                              ; preds = %287, %307
  %300 = phi i64 [ %316, %307 ], [ 0, %287 ]
  %301 = phi i32 [ %317, %307 ], [ 0, %287 ]
  %302 = icmp ult i32 %301, %269
  br i1 %302, label %303, label %307

303:                                              ; preds = %299
  %304 = getelementptr inbounds nuw i32, ptr %9, i32 %301
  %305 = load i32, ptr %304, align 4, !tbaa !1
  %306 = zext i32 %305 to i64
  br label %307

307:                                              ; preds = %303, %299
  %308 = phi i64 [ %306, %303 ], [ 0, %299 ]
  %309 = add nuw nsw i64 %308, %300
  %310 = getelementptr inbounds nuw i32, ptr %0, i32 %301
  %311 = load i32, ptr %310, align 4, !tbaa !1
  %312 = zext i32 %311 to i64
  %313 = trunc i64 %309 to i32
  %314 = sub i32 %311, %313
  store i32 %314, ptr %310, align 4, !tbaa !1
  %315 = icmp samesign ugt i64 %309, %312
  %316 = zext i1 %315 to i64
  %317 = add nuw i32 %301, 1
  %318 = load i32, ptr %10, align 4, !tbaa !136
  %319 = icmp ult i32 %317, %318
  br i1 %319, label %299, label %288, !llvm.loop !191

320:                                              ; preds = %290, %296, %285, %288
  %321 = phi i32 [ 0, %288 ], [ %215, %285 ], [ %291, %290 ], [ 0, %296 ]
  %322 = phi i32 [ 0, %288 ], [ 0, %285 ], [ %291, %290 ], [ 0, %296 ]
  %323 = shl nuw i64 1, %217
  %324 = or i64 %323, %218
  br label %325

325:                                              ; preds = %271, %283, %320
  %326 = phi i32 [ %321, %320 ], [ %215, %283 ], [ %215, %271 ]
  %327 = phi i32 [ %322, %320 ], [ %216, %283 ], [ %216, %271 ]
  %328 = phi i64 [ %324, %320 ], [ %218, %283 ], [ %218, %271 ]
  %329 = add nsw i64 %217, -1
  %330 = icmp sgt i64 %217, 0
  br i1 %330, label %214, label %331, !llvm.loop !192

331:                                              ; preds = %325, %209
  %332 = phi i32 [ %185, %209 ], [ %326, %325 ]
  %333 = phi i64 [ 0, %209 ], [ %328, %325 ]
  %334 = icmp eq i32 %332, 0
  br i1 %334, label %397, label %335

335:                                              ; preds = %331
  %336 = getelementptr i32, ptr %0, i32 %332
  %337 = getelementptr i8, ptr %336, i32 -4
  %338 = load i32, ptr %337, align 4, !tbaa !1
  %339 = lshr i32 %338, 31
  %340 = add i32 %339, %332
  %341 = icmp ugt i32 %340, 128
  br i1 %341, label %442, label %342

342:                                              ; preds = %335
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %5, i8 0, i32 512, i1 false)
  %343 = getelementptr inbounds nuw i8, ptr %5, i32 512
  store i32 %340, ptr %343, align 4, !tbaa !136
  %344 = and i32 %332, 1
  %345 = icmp eq i32 %332, 1
  br i1 %345, label %350, label %346

346:                                              ; preds = %342
  %347 = and i32 %332, -2
  br label %366

348:                                              ; preds = %393
  %349 = icmp eq i32 %344, 0
  br i1 %349, label %364, label %350

350:                                              ; preds = %348, %342
  %351 = phi i32 [ 0, %342 ], [ %394, %348 ]
  %352 = trunc i32 %332 to i1
  tail call void @llvm.assume(i1 %352)
  %353 = getelementptr inbounds nuw i32, ptr %0, i32 %351
  %354 = load i32, ptr %353, align 4, !tbaa !1
  %355 = shl i32 %354, 1
  %356 = getelementptr i32, ptr %5, i32 %351
  %357 = load i32, ptr %356, align 4, !tbaa !1
  %358 = or i32 %357, %355
  store i32 %358, ptr %356, align 4, !tbaa !1
  %359 = icmp sgt i32 %354, -1
  br i1 %359, label %364, label %360

360:                                              ; preds = %350
  %361 = getelementptr i8, ptr %356, i32 4
  %362 = load i32, ptr %361, align 4, !tbaa !1
  %363 = or i32 %362, 1
  store i32 %363, ptr %361, align 4, !tbaa !1
  br label %364

364:                                              ; preds = %350, %360, %348
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(516) %0, ptr noundef nonnull align 4 dereferenceable(516) %5, i32 516, i1 false), !tbaa.struct !187
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #28
  %365 = load i32, ptr %10, align 4, !tbaa !136
  br label %397

366:                                              ; preds = %393, %346
  %367 = phi i32 [ 0, %346 ], [ %394, %393 ]
  %368 = phi i32 [ 0, %346 ], [ %395, %393 ]
  %369 = getelementptr inbounds nuw i32, ptr %0, i32 %367
  %370 = load i32, ptr %369, align 4, !tbaa !1
  %371 = shl i32 %370, 1
  %372 = getelementptr i32, ptr %5, i32 %367
  %373 = load i32, ptr %372, align 4, !tbaa !1
  %374 = or i32 %373, %371
  store i32 %374, ptr %372, align 4, !tbaa !1
  %375 = icmp sgt i32 %370, -1
  br i1 %375, label %380, label %376

376:                                              ; preds = %366
  %377 = getelementptr i8, ptr %372, i32 4
  %378 = load i32, ptr %377, align 4, !tbaa !1
  %379 = or i32 %378, 1
  store i32 %379, ptr %377, align 4, !tbaa !1
  br label %380

380:                                              ; preds = %376, %366
  %381 = or disjoint i32 %367, 1
  %382 = getelementptr inbounds nuw i32, ptr %0, i32 %381
  %383 = load i32, ptr %382, align 4, !tbaa !1
  %384 = shl i32 %383, 1
  %385 = getelementptr i32, ptr %5, i32 %381
  %386 = load i32, ptr %385, align 4, !tbaa !1
  %387 = or i32 %386, %384
  store i32 %387, ptr %385, align 4, !tbaa !1
  %388 = icmp sgt i32 %383, -1
  br i1 %388, label %393, label %389

389:                                              ; preds = %380
  %390 = getelementptr i8, ptr %385, i32 4
  %391 = load i32, ptr %390, align 4, !tbaa !1
  %392 = or i32 %391, 1
  store i32 %392, ptr %390, align 4, !tbaa !1
  br label %393

393:                                              ; preds = %389, %380
  %394 = add nuw i32 %367, 2
  %395 = add i32 %368, 2
  %396 = icmp eq i32 %395, %347
  br i1 %396, label %348, label %366, !llvm.loop !188

397:                                              ; preds = %331, %364
  %398 = phi i32 [ 0, %331 ], [ %365, %364 ]
  %399 = icmp eq i32 %398, %196
  br i1 %399, label %402, label %400

400:                                              ; preds = %397
  %401 = icmp ugt i32 %398, %196
  br i1 %401, label %419, label %421

402:                                              ; preds = %397, %405
  %403 = phi i32 [ %406, %405 ], [ %196, %397 ]
  %404 = icmp eq i32 %403, 0
  br i1 %404, label %414, label %405

405:                                              ; preds = %402
  %406 = add i32 %403, -1
  %407 = getelementptr inbounds nuw i32, ptr %0, i32 %406
  %408 = load i32, ptr %407, align 4, !tbaa !1
  %409 = getelementptr inbounds nuw i32, ptr %1, i32 %406
  %410 = load i32, ptr %409, align 4, !tbaa !1
  %411 = icmp eq i32 %408, %410
  br i1 %411, label %402, label %412, !llvm.loop !189

412:                                              ; preds = %405
  %413 = icmp ugt i32 %408, %410
  br i1 %413, label %419, label %421

414:                                              ; preds = %402
  %415 = icmp eq i32 %2, 0
  %416 = and i64 %333, 1
  %417 = icmp eq i64 %416, 0
  %418 = select i1 %415, i1 %417, i1 false
  br i1 %418, label %421, label %419

419:                                              ; preds = %412, %400, %414
  %420 = add i64 %333, 1
  br label %421

421:                                              ; preds = %400, %412, %414, %419
  %422 = phi i64 [ %420, %419 ], [ %333, %414 ], [ %333, %412 ], [ %333, %400 ]
  br i1 %128, label %423, label %438

423:                                              ; preds = %421
  %424 = icmp eq i64 %422, 9007199254740992
  %425 = zext i1 %424 to i32
  %426 = add nsw i32 %127, %425
  %427 = select i1 %424, i64 4503599627370496, i64 %422
  %428 = icmp sgt i32 %426, 1023
  br i1 %428, label %440, label %429

429:                                              ; preds = %423
  %430 = and i64 %427, -4503599627370496
  %431 = icmp eq i64 %430, 4503599627370496
  br i1 %431, label %432, label %442

432:                                              ; preds = %429
  %433 = add nsw i32 %426, 1023
  %434 = zext nneg i32 %433 to i64
  %435 = shl nuw nsw i64 %434, 52
  %436 = add nsw i64 %427, -4503599627370496
  %437 = or disjoint i64 %435, %436
  br label %440

438:                                              ; preds = %421
  %439 = icmp ugt i64 %422, 4503599627370496
  br i1 %439, label %442, label %440

440:                                              ; preds = %432, %438, %423, %123
  %441 = phi i64 [ 9218868437227405312, %423 ], [ 9218868437227405312, %123 ], [ %437, %432 ], [ %422, %438 ]
  store i64 %441, ptr %3, align 8, !tbaa !45
  br label %442

442:                                              ; preds = %236, %239, %440, %151, %154, %55, %58, %335, %438, %429, %205
  %443 = phi i32 [ 0, %154 ], [ 0, %335 ], [ 0, %55 ], [ 0, %205 ], [ 0, %151 ], [ 0, %438 ], [ 0, %58 ], [ 0, %429 ], [ 1, %440 ], [ 0, %239 ], [ 0, %236 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #28
  ret i32 %443
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #23

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.usub.sat.i32(i32, i32) #23

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #24

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #23

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #23

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #23

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.abs.i64(i64, i1 immarg) #24

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #23

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #23

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #25

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.cttz.i32(i32, i1 immarg) #24

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #24

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #26

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nofree norecurse nosync nounwind "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #4 = { nofree norecurse nounwind "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #6 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #7 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #8 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #9 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #11 = { nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #12 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #13 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #14 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #15 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #16 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #17 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #18 = { nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #19 = { mustprogress nocallback nofree nosync nounwind willreturn memory(read) }
attributes #20 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #21 = { inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #22 = { inlinehint nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext" }
attributes #23 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #24 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #25 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #26 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #27 = { nobuiltin "no-builtins" }
attributes #28 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.errno.tbaa = !{!1}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{!2, !2, i64 0}
!2 = !{!"int", !3, i64 0}
!3 = !{!"omnipotent char", !4, i64 0}
!4 = !{!"Simple C/C++ TBAA"}
!5 = !{!6, !7, i64 0}
!6 = !{!"", !7, i64 0, !2, i64 4, !2, i64 8, !7, i64 12, !7, i64 16, !7, i64 20, !2, i64 24, !2, i64 28, !8, i64 32, !8, i64 40, !2, i64 48, !2, i64 52, !2, i64 56, !2, i64 60, !2, i64 64}
!7 = !{!"any pointer", !3, i64 0}
!8 = !{!"long long", !3, i64 0}
!9 = !{!6, !2, i64 8}
!10 = !{!6, !2, i64 4}
!11 = !{!6, !7, i64 12}
!12 = !{!6, !2, i64 48}
!13 = !{!6, !7, i64 16}
!14 = !{!6, !7, i64 20}
!15 = !{!6, !2, i64 28}
!16 = !{!6, !2, i64 24}
!17 = !{!6, !2, i64 56}
!18 = !{!6, !2, i64 52}
!19 = !{!6, !8, i64 40}
!20 = !{!6, !8, i64 32}
!21 = !{!6, !2, i64 64}
!22 = !{!6, !2, i64 60}
!23 = !{!24, !8, i64 8}
!24 = !{!"", !25, i64 0, !8, i64 8, !2, i64 16, !2, i64 20, !2, i64 24, !2, i64 28, !2, i64 32, !2, i64 36, !2, i64 40}
!25 = !{!"p1 omnipotent char", !7, i64 0}
!26 = !{!24, !2, i64 28}
!27 = !{!24, !25, i64 0}
!28 = !{!29, !25, i64 0}
!29 = !{!"", !25, i64 0, !2, i64 4}
!30 = !{!29, !2, i64 4}
!31 = !{!32, !32, i64 0}
!32 = !{!"p1 _ZTS9FreeBlock", !7, i64 0}
!33 = distinct !{!33, !34}
!34 = !{!"llvm.loop.mustprogress"}
!35 = !{!36, !32, i64 8}
!36 = !{!"FreeBlock", !8, i64 0, !32, i64 8}
!37 = !{!36, !8, i64 0}
!38 = !{!24, !2, i64 16}
!39 = !{!24, !2, i64 20}
!40 = !{!24, !2, i64 32}
!41 = !{!24, !2, i64 36}
!42 = !{!24, !2, i64 40}
!43 = !{!24, !2, i64 24}
!44 = distinct !{!44, !34}
!45 = !{!8, !8, i64 0}
!46 = !{!3, !3, i64 0}
!47 = distinct !{!47, !34}
!48 = distinct !{!48, !34}
!49 = distinct !{!49, !34}
!50 = distinct !{!50, !34}
!51 = distinct !{!51, !52}
!52 = !{!"llvm.loop.unroll.disable"}
!53 = distinct !{!53, !52}
!54 = !{!55, !2, i64 8}
!55 = !{!"", !8, i64 0, !2, i64 8}
!56 = !{!55, !8, i64 0}
!57 = !{!58, !2, i64 4}
!58 = !{!"", !2, i64 0, !2, i64 4}
!59 = !{!60, !62}
!60 = distinct !{!60, !61, !"packed_value: argument 0"}
!61 = distinct !{!61, !"packed_value"}
!62 = distinct !{!62, !63, !"slot_value: argument 0"}
!63 = distinct !{!63, !"slot_value"}
!64 = distinct !{!64, !34}
!65 = !{!62}
!66 = distinct !{!66, !52}
!67 = distinct !{!67, !34}
!68 = distinct !{!68, !34}
!69 = !{!58, !2, i64 0}
!70 = distinct !{!70, !34, !71}
!71 = !{!"llvm.loop.peeled.count", i32 1}
!72 = distinct !{!72, !34}
!73 = !{i64 0, i64 8, !45, i64 8, i64 4, !1}
!74 = distinct !{!74, !34}
!75 = distinct !{!75, !34}
!76 = !{!77}
!77 = distinct !{!77, !78, !"slot_value: argument 0"}
!78 = distinct !{!78, !"slot_value"}
!79 = !{!80}
!80 = distinct !{!80, !81, !"packed_value: argument 0"}
!81 = distinct !{!81, !"packed_value"}
!82 = distinct !{!82, !52}
!83 = !{!84, !84, i64 0}
!84 = !{!"double", !3, i64 0}
!85 = distinct !{!85, !52}
!86 = distinct !{!86, !34}
!87 = !{!88}
!88 = distinct !{!88, !89, !"slot_value: argument 0"}
!89 = distinct !{!89, !"slot_value"}
!90 = !{!91, !88}
!91 = distinct !{!91, !92, !"packed_value: argument 0"}
!92 = distinct !{!92, !"packed_value"}
!93 = distinct !{!93, !52}
!94 = distinct !{!94, !34}
!95 = !{!96, !98}
!96 = distinct !{!96, !97, !"packed_value: argument 0"}
!97 = distinct !{!97, !"packed_value"}
!98 = distinct !{!98, !99, !"slot_value: argument 0"}
!99 = distinct !{!99, !"slot_value"}
!100 = !{!98}
!101 = distinct !{!101, !52}
!102 = !{!103, !105}
!103 = distinct !{!103, !104, !"packed_value: argument 0"}
!104 = distinct !{!104, !"packed_value"}
!105 = distinct !{!105, !106, !"slot_value: argument 0"}
!106 = distinct !{!106, !"slot_value"}
!107 = !{!105}
!108 = distinct !{!108, !52}
!109 = distinct !{!109, !52}
!110 = distinct !{!110, !34}
!111 = distinct !{!111, !34}
!112 = distinct !{!112, !52}
!113 = distinct !{!113, !34}
!114 = !{!115}
!115 = distinct !{!115, !116, !"slot_value: argument 0"}
!116 = distinct !{!116, !"slot_value"}
!117 = !{!118, !115}
!118 = distinct !{!118, !119, !"packed_value: argument 0"}
!119 = distinct !{!119, !"packed_value"}
!120 = distinct !{!120, !52}
!121 = distinct !{!121, !34}
!122 = distinct !{!122, !34}
!123 = distinct !{!123, !34}
!124 = distinct !{!124, !52}
!125 = distinct !{!125, !34}
!126 = distinct !{!126, !52}
!127 = distinct !{!127, !34}
!128 = distinct !{!128, !52}
!129 = distinct !{!129, !34}
!130 = distinct !{!130, !52}
!131 = distinct !{!131, !34}
!132 = distinct !{!132, !34}
!133 = distinct !{!133, !34}
!134 = distinct !{!134, !34}
!135 = distinct !{!135, !34}
!136 = !{!137, !2, i64 512}
!137 = !{!"", !3, i64 0, !2, i64 512}
!138 = distinct !{!138, !34}
!139 = distinct !{!139, !34}
!140 = distinct !{!140, !34}
!141 = distinct !{!141, !34}
!142 = distinct !{!142, !34}
!143 = distinct !{!143, !34}
!144 = distinct !{!144, !34}
!145 = !{!146}
!146 = distinct !{!146, !147, !"slot_value: argument 0"}
!147 = distinct !{!147, !"slot_value"}
!148 = !{!149}
!149 = distinct !{!149, !150, !"packed_value: argument 0"}
!150 = distinct !{!150, !"packed_value"}
!151 = !{!149, !146}
!152 = distinct !{!152, !52}
!153 = distinct !{!153, !34}
!154 = distinct !{!154, !34}
!155 = distinct !{!155, !34}
!156 = !{!157}
!157 = distinct !{!157, !158, !"slot_value: argument 0"}
!158 = distinct !{!158, !"slot_value"}
!159 = !{!160, !157}
!160 = distinct !{!160, !161, !"packed_value: argument 0"}
!161 = distinct !{!161, !"packed_value"}
!162 = distinct !{!162, !52}
!163 = distinct !{!163, !34}
!164 = !{!165, !167}
!165 = distinct !{!165, !166, !"packed_value: argument 0"}
!166 = distinct !{!166, !"packed_value"}
!167 = distinct !{!167, !168, !"slot_value: argument 0"}
!168 = distinct !{!168, !"slot_value"}
!169 = !{!167}
!170 = distinct !{!170, !52}
!171 = distinct !{!171, !34}
!172 = distinct !{!172, !34}
!173 = distinct !{!173, !34}
!174 = distinct !{!174, !34}
!175 = distinct !{!175, !34}
!176 = distinct !{!176, !34}
!177 = distinct !{!177, !34}
!178 = distinct !{!178, !34}
!179 = distinct !{!179, !34}
!180 = distinct !{!180, !52}
!181 = distinct !{!181, !52}
!182 = distinct !{!182, !34}
!183 = distinct !{!183, !52}
!184 = distinct !{!184, !34}
!185 = distinct !{!185, !34}
!186 = distinct !{!186, !34}
!187 = !{i64 0, i64 512, !46, i64 512, i64 4, !1}
!188 = distinct !{!188, !34}
!189 = distinct !{!189, !34}
!190 = distinct !{!190, !34}
!191 = distinct !{!191, !34}
!192 = distinct !{!192, !34}

@package_name = private constant [15 x i8] c"nano_try_entry\00"
define i32 @nano_package() {
 %v = call i32 @nms_reserved_entry(ptr @package_name)
 %result = sub i32 1, %v
 ret i32 %result
}
