; ModuleID = 'src/nanoisa/managed_module.c'
source_filename = "src/nanoisa/managed_module.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

%struct.NmsRuntime = type { ptr, i32, i32, ptr, ptr, ptr, i32, i32, i64, i64, i32, i32, i32, i32, i32 }
%struct.NmsSlot = type { ptr, i64, i32, i32, i32, i32, i32, i32, i32 }
%struct.NmsView = type { ptr, i32 }
%struct.NmsRecordDescriptor = type { i32, i32 }
%struct.NmsValue = type { i64, i32 }
%struct.NbpBig = type { [128 x i32], i32 }

@.str = private unnamed_addr constant [5 x i8] c"true\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"false\00", align 1
@nms_module_error = internal unnamed_addr global i32 0, align 4
@nms_module_ready = internal unnamed_addr global i1 false, align 4
@nms_module_instance = internal global %struct.NmsRuntime zeroinitializer, align 8

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define dso_local void @nms_init(ptr noundef writeonly captures(none) initializes((0, 84)) %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #0 {
  store ptr null, ptr %0, align 8, !tbaa !8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store <2 x i32> zeroinitializer, ptr %4, align 8, !tbaa !4
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store ptr %1, ptr %5, align 8, !tbaa !12
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 64
  store i32 %2, ptr %6, align 8, !tbaa !13
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store <2 x ptr> zeroinitializer, ptr %7, align 8, !tbaa !14
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store <2 x i32> zeroinitializer, ptr %8, align 8, !tbaa !4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 48
  store <2 x i64> zeroinitializer, ptr %10, align 8, !tbaa !15
  store <4 x i32> zeroinitializer, ptr %9, align 4, !tbaa !4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_view(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp ne ptr %0, null
  %5 = icmp ne ptr %2, null
  %6 = and i1 %4, %5
  br i1 %6, label %7, label %61

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !16
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %61

11:                                               ; preds = %7
  %12 = icmp sgt i64 %1, -1
  br i1 %12, label %39, label %13

13:                                               ; preds = %11
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %61, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %18 = load i32, ptr %17, align 4, !tbaa !17
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  br i1 %20, label %61, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %23 = load ptr, ptr %22, align 8, !tbaa !18
  %24 = icmp eq ptr %23, null
  br i1 %24, label %61, label %25

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i64 %14
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load i64, ptr %27, align 8, !tbaa !19
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %61, label %30

30:                                               ; preds = %25
  %31 = and i64 %1, 4294967295
  %32 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 28
  %34 = load i32, ptr %33, align 4, !tbaa !22
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %36, label %61

36:                                               ; preds = %30
  %37 = load ptr, ptr %32, align 8, !tbaa !23
  store ptr %37, ptr %2, align 8, !tbaa !24
  %38 = getelementptr inbounds nuw i8, ptr %32, i64 16
  br label %57

39:                                               ; preds = %11
  %40 = icmp eq i64 %1, 0
  br i1 %40, label %61, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %43 = load i32, ptr %42, align 8, !tbaa !13
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %1, %44
  br i1 %45, label %61, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %48 = load ptr, ptr %47, align 8, !tbaa !12
  %49 = icmp eq ptr %48, null
  br i1 %49, label %61, label %50

50:                                               ; preds = %46
  %51 = getelementptr %struct.NmsView, ptr %48, i64 %1
  %52 = getelementptr i8, ptr %51, i64 -16
  %53 = load ptr, ptr %52, align 8, !tbaa !24
  %54 = icmp eq ptr %53, null
  br i1 %54, label %61, label %55

55:                                               ; preds = %50
  store ptr %53, ptr %2, align 8, !tbaa !24
  %56 = getelementptr i8, ptr %51, i64 -8
  br label %57

57:                                               ; preds = %55, %36
  %58 = phi ptr [ %38, %36 ], [ %56, %55 ]
  %59 = load i32, ptr %58, align 8, !tbaa !4
  %60 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i32 %59, ptr %60, align 8, !tbaa !26
  br label %61

61:                                               ; preds = %57, %21, %25, %16, %13, %30, %50, %39, %41, %46, %7, %3
  %62 = phi i32 [ 6, %3 ], [ 6, %50 ], [ 6, %25 ], [ 5, %7 ], [ 6, %39 ], [ 6, %46 ], [ 6, %41 ], [ 6, %21 ], [ 1, %30 ], [ 6, %13 ], [ 6, %16 ], [ 0, %57 ]
  ret i32 %62
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_prepare_collection(ptr noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %27, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !16
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %27

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %9 = load i32, ptr %8, align 4, !tbaa !27
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %27

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %13 = load i32, ptr %12, align 4, !tbaa !17
  %14 = zext i32 %13 to i64
  %15 = add nuw nsw i64 %14, 1
  %16 = mul nuw nsw i64 %15, 9
  %17 = add nuw nsw i64 %16, 3
  %18 = and i64 %17, 274877906940
  %19 = shl nuw nsw i64 %15, 2
  %20 = add nuw nsw i64 %18, %19
  %21 = tail call noalias ptr @malloc(i64 noundef %20) #22
  %22 = icmp eq ptr %21, null
  br i1 %22, label %27, label %23

23:                                               ; preds = %11
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr %21, ptr %24, align 8, !tbaa !28
  %25 = load i32, ptr %12, align 4, !tbaa !17
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store i32 %25, ptr %26, align 8, !tbaa !29
  store i32 1, ptr %8, align 4, !tbaa !27
  br label %27

27:                                               ; preds = %23, %11, %7, %3, %1
  %28 = phi i32 [ 6, %1 ], [ 5, %3 ], [ 0, %7 ], [ 0, %23 ], [ 3, %11 ]
  ret i32 %28
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_string_array_create(ptr noundef captures(address_is_null) %0, ptr noundef writeonly captures(address_is_null) %1) local_unnamed_addr #3 {
  %3 = icmp ne ptr %0, null
  %4 = icmp ne ptr %1, null
  %5 = and i1 %3, %4
  br i1 %5, label %6, label %12

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !16
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 2, i64 noundef 0, ptr noundef %1) #23
  br label %12

12:                                               ; preds = %6, %2, %10
  %13 = phi i32 [ 6, %2 ], [ %11, %10 ], [ 5, %6 ]
  ret i32 %13
}

; Function Attrs: nounwind
define internal fastcc range(i32 0, 4) i32 @publish_slot(ptr noundef nonnull captures(none) %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef range(i32 1, 6) %4, i64 noundef range(i64 0, 68719476721) %5, ptr noundef nonnull writeonly captures(none) %6) unnamed_addr #3 {
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %9 = load i64, ptr %8, align 8, !tbaa !30
  %10 = xor i64 %9, -1
  %11 = icmp ugt i64 %5, %10
  br i1 %11, label %122, label %12

12:                                               ; preds = %7
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %14 = load i32, ptr %13, align 4, !tbaa !17
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %16 = load i32, ptr %15, align 8, !tbaa !31
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %21, label %18

18:                                               ; preds = %12
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %20 = load ptr, ptr %19, align 8, !tbaa !18
  br label %105

21:                                               ; preds = %12
  %22 = icmp ugt i32 %14, -3
  br i1 %22, label %122, label %23

23:                                               ; preds = %21
  %24 = icmp eq i32 %14, 0
  %25 = tail call i32 @llvm.smax.i32(i32 %14, i32 -1)
  %26 = shl i32 %25, 1
  %27 = select i1 %24, i32 8, i32 %26
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %29 = load ptr, ptr %28, align 8, !tbaa !18
  %30 = icmp eq i32 %27, %14
  br i1 %30, label %105, label %31

31:                                               ; preds = %23
  %32 = zext i32 %27 to i64
  %33 = mul nuw nsw i64 %32, 48
  %34 = add nuw nsw i64 %33, 48
  %35 = tail call noalias ptr @malloc(i64 noundef %34) #22
  %36 = icmp eq ptr %35, null
  br i1 %36, label %122, label %37

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %39 = load i32, ptr %38, align 4, !tbaa !27
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %51, label %41

41:                                               ; preds = %37
  %42 = or disjoint i64 %32, 1
  %43 = mul nuw nsw i64 %42, 9
  %44 = add nuw nsw i64 %43, 3
  %45 = and i64 %44, 137438953468
  %46 = shl nuw nsw i64 %42, 2
  %47 = add nuw nsw i64 %45, %46
  %48 = tail call noalias ptr @malloc(i64 noundef %47) #22
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %41
  tail call void @free(ptr noundef nonnull %35) #22
  br label %122

51:                                               ; preds = %41, %37
  %52 = phi ptr [ %48, %41 ], [ null, %37 ]
  %53 = load ptr, ptr %28, align 8, !tbaa !18
  %54 = icmp eq ptr %53, null
  br label %58

55:                                               ; preds = %91
  %56 = load i32, ptr %38, align 4, !tbaa !27
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %100, label %94

58:                                               ; preds = %51, %91
  %59 = phi i64 [ 0, %51 ], [ %92, %91 ]
  br i1 %54, label %80, label %60

60:                                               ; preds = %58
  %61 = load i32, ptr %13, align 4, !tbaa !17
  %62 = zext i32 %61 to i64
  %63 = icmp samesign ugt i64 %59, %62
  br i1 %63, label %80, label %64

64:                                               ; preds = %60
  %65 = getelementptr inbounds nuw %struct.NmsSlot, ptr %53, i64 %59
  %66 = load ptr, ptr %65, align 8, !tbaa !23
  %67 = getelementptr inbounds nuw %struct.NmsSlot, ptr %35, i64 %59
  store ptr %66, ptr %67, align 8, !tbaa !23
  %68 = getelementptr inbounds nuw i8, ptr %65, i64 8
  %69 = load i64, ptr %68, align 8, !tbaa !19
  %70 = getelementptr inbounds nuw i8, ptr %67, i64 8
  store i64 %69, ptr %70, align 8, !tbaa !19
  %71 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %72 = getelementptr inbounds nuw i8, ptr %67, i64 16
  %73 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %74 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %75 = load <2 x i32>, ptr %73, align 8, !tbaa !4
  store <2 x i32> %75, ptr %74, align 8, !tbaa !4
  %76 = getelementptr inbounds nuw i8, ptr %65, i64 40
  %77 = load i32, ptr %76, align 8, !tbaa !32
  %78 = getelementptr inbounds nuw i8, ptr %67, i64 40
  store i32 %77, ptr %78, align 8, !tbaa !32
  %79 = load <4 x i32>, ptr %71, align 8, !tbaa !4
  store <4 x i32> %79, ptr %72, align 8, !tbaa !4
  br label %91

80:                                               ; preds = %60, %58
  %81 = getelementptr inbounds nuw %struct.NmsSlot, ptr %35, i64 %59
  store ptr null, ptr %81, align 8, !tbaa !23
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 8
  store i64 0, ptr %82, align 8, !tbaa !19
  %83 = getelementptr inbounds nuw i8, ptr %81, i64 16
  store i32 0, ptr %83, align 8, !tbaa !33
  %84 = getelementptr inbounds nuw i8, ptr %81, i64 24
  store <4 x i32> zeroinitializer, ptr %84, align 8, !tbaa !4
  %85 = getelementptr inbounds nuw i8, ptr %81, i64 40
  store i32 0, ptr %85, align 8, !tbaa !32
  %86 = icmp samesign ult i64 %59, %32
  %87 = trunc nuw i64 %59 to i32
  %88 = add i32 %87, 1
  %89 = select i1 %86, i32 %88, i32 0
  %90 = getelementptr inbounds nuw i8, ptr %81, i64 20
  store i32 %89, ptr %90, align 4, !tbaa !34
  br label %91

91:                                               ; preds = %64, %80
  %92 = add nuw nsw i64 %59, 1
  %93 = icmp eq i64 %59, %32
  br i1 %93, label %55, label %58, !llvm.loop !35

94:                                               ; preds = %55
  %95 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %96 = load ptr, ptr %95, align 8, !tbaa !28
  store ptr %52, ptr %95, align 8, !tbaa !28
  %97 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store i32 %27, ptr %97, align 8, !tbaa !29
  %98 = icmp eq ptr %96, null
  br i1 %98, label %100, label %99

99:                                               ; preds = %94
  tail call void @free(ptr noundef nonnull %96) #22
  br label %100

100:                                              ; preds = %99, %94, %55
  store ptr %35, ptr %28, align 8, !tbaa !18
  %101 = load i32, ptr %13, align 4, !tbaa !17
  %102 = add i32 %101, 1
  store i32 %102, ptr %15, align 8, !tbaa !31
  store i32 %27, ptr %13, align 4, !tbaa !17
  br i1 %54, label %105, label %103

103:                                              ; preds = %100
  tail call void @free(ptr noundef nonnull %53) #22
  %104 = load i32, ptr %15, align 8, !tbaa !31
  br label %105

105:                                              ; preds = %103, %100, %18, %23
  %106 = phi i32 [ %16, %18 ], [ 0, %23 ], [ %102, %100 ], [ %104, %103 ]
  %107 = phi ptr [ %20, %18 ], [ %29, %23 ], [ %35, %100 ], [ %35, %103 ]
  %108 = zext i32 %106 to i64
  %109 = getelementptr inbounds nuw %struct.NmsSlot, ptr %107, i64 %108
  %110 = getelementptr inbounds nuw i8, ptr %109, i64 20
  %111 = load i32, ptr %110, align 4, !tbaa !34
  store i32 %111, ptr %15, align 8, !tbaa !31
  store ptr %1, ptr %109, align 8, !tbaa !23
  %112 = getelementptr inbounds nuw i8, ptr %109, i64 16
  store i32 %2, ptr %112, align 8, !tbaa !33
  %113 = getelementptr inbounds nuw i8, ptr %109, i64 32
  store <2 x i32> zeroinitializer, ptr %113, align 8, !tbaa !4
  %114 = getelementptr inbounds nuw i8, ptr %109, i64 40
  store i32 0, ptr %114, align 8, !tbaa !32
  %115 = getelementptr inbounds nuw i8, ptr %109, i64 28
  store i32 %4, ptr %115, align 4, !tbaa !22
  %116 = getelementptr inbounds nuw i8, ptr %109, i64 24
  store i32 %3, ptr %116, align 8, !tbaa !37
  %117 = getelementptr inbounds nuw i8, ptr %109, i64 8
  store i64 1, ptr %117, align 8, !tbaa !19
  store i32 0, ptr %110, align 4, !tbaa !34
  %118 = load <2 x i64>, ptr %8, align 8, !tbaa !15
  %119 = insertelement <2 x i64> <i64 poison, i64 1>, i64 %5, i64 0
  %120 = add <2 x i64> %118, %119
  store <2 x i64> %120, ptr %8, align 8, !tbaa !15
  %121 = or disjoint i64 %108, -9223372036854775808
  store i64 %121, ptr %6, align 8, !tbaa !15
  br label %122

122:                                              ; preds = %21, %50, %31, %105, %7
  %123 = phi i32 [ 3, %7 ], [ 3, %21 ], [ 0, %105 ], [ 3, %50 ], [ 3, %31 ]
  ret i32 %123
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_string_array_append(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2) local_unnamed_addr #3 {
  %4 = icmp sgt i64 %1, -1
  %5 = icmp eq ptr %0, null
  br i1 %4, label %6, label %28

6:                                                ; preds = %3
  br i1 %5, label %204, label %7

7:                                                ; preds = %6
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !16
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %204

11:                                               ; preds = %7
  %12 = icmp eq i64 %1, 0
  br i1 %12, label %204, label %13

13:                                               ; preds = %11
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %15 = load i32, ptr %14, align 8, !tbaa !13
  %16 = zext i32 %15 to i64
  %17 = icmp samesign ugt i64 %1, %16
  br i1 %17, label %204, label %18

18:                                               ; preds = %13
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %20 = load ptr, ptr %19, align 8, !tbaa !12
  %21 = icmp eq ptr %20, null
  br i1 %21, label %204, label %22

22:                                               ; preds = %18
  %23 = getelementptr %struct.NmsView, ptr %20, i64 %1
  %24 = getelementptr i8, ptr %23, i64 -16
  %25 = load ptr, ptr %24, align 8, !tbaa !24
  %26 = icmp eq ptr %25, null
  %27 = select i1 %26, i32 6, i32 1
  br label %204

28:                                               ; preds = %3
  br i1 %5, label %204, label %29

29:                                               ; preds = %28
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %31 = load i32, ptr %30, align 8, !tbaa !16
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %33, label %204

33:                                               ; preds = %29
  %34 = and i64 %1, 9223372036854775807
  %35 = icmp eq i64 %34, 0
  br i1 %35, label %204, label %36

36:                                               ; preds = %33
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %38 = load i32, ptr %37, align 4, !tbaa !17
  %39 = freeze i32 %38
  %40 = zext i32 %39 to i64
  %41 = icmp samesign ugt i64 %34, %40
  br i1 %41, label %204, label %42

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %44 = load ptr, ptr %43, align 8, !tbaa !18
  %45 = icmp eq ptr %44, null
  br i1 %45, label %204, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i64 %34
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 8
  %49 = load i64, ptr %48, align 8, !tbaa !19
  %50 = icmp eq i64 %49, 0
  br i1 %50, label %204, label %51

51:                                               ; preds = %46
  %52 = and i64 %1, 4294967295
  %53 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i64 %52
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 28
  %55 = load i32, ptr %54, align 4, !tbaa !22
  %56 = icmp eq i32 %55, 2
  br i1 %56, label %57, label %204

57:                                               ; preds = %51
  %58 = icmp sgt i64 %2, -1
  br i1 %58, label %74, label %59

59:                                               ; preds = %57
  %60 = and i64 %2, 9223372036854775807
  %61 = add nsw i64 %60, -1
  %62 = icmp ult i64 %61, %40
  br i1 %62, label %63, label %204

63:                                               ; preds = %59
  %64 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i64 %60
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 8
  %66 = load i64, ptr %65, align 8, !tbaa !19
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %204, label %68

68:                                               ; preds = %63
  %69 = and i64 %2, 4294967295
  %70 = getelementptr inbounds nuw %struct.NmsSlot, ptr %44, i64 %69
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 28
  %72 = load i32, ptr %71, align 4, !tbaa !22
  %73 = icmp eq i32 %72, 1
  br i1 %73, label %90, label %204

74:                                               ; preds = %57
  %75 = icmp eq i64 %2, 0
  br i1 %75, label %204, label %76

76:                                               ; preds = %74
  %77 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %78 = load i32, ptr %77, align 8, !tbaa !13
  %79 = zext i32 %78 to i64
  %80 = icmp samesign ugt i64 %2, %79
  br i1 %80, label %204, label %81

81:                                               ; preds = %76
  %82 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %83 = load ptr, ptr %82, align 8, !tbaa !12
  %84 = icmp eq ptr %83, null
  br i1 %84, label %204, label %85

85:                                               ; preds = %81
  %86 = getelementptr %struct.NmsView, ptr %83, i64 %2
  %87 = getelementptr i8, ptr %86, i64 -16
  %88 = load ptr, ptr %87, align 8, !tbaa !24
  %89 = icmp eq ptr %88, null
  br i1 %89, label %204, label %90

90:                                               ; preds = %85, %68
  %91 = getelementptr inbounds nuw i8, ptr %53, i64 16
  %92 = load i32, ptr %91, align 8, !tbaa !33
  %93 = icmp eq i32 %92, -1
  br i1 %93, label %204, label %94

94:                                               ; preds = %90
  %95 = getelementptr inbounds nuw i8, ptr %53, i64 24
  %96 = load i32, ptr %95, align 8, !tbaa !37
  %97 = load ptr, ptr %53, align 8, !tbaa !23
  %98 = icmp eq i32 %92, %96
  br i1 %98, label %99, label %130

99:                                               ; preds = %94
  %100 = icmp eq i32 %92, 0
  %101 = shl i32 %92, 1
  %102 = icmp sgt i32 %92, -1
  %103 = select i1 %102, i32 %101, i32 -1
  %104 = select i1 %100, i32 4, i32 %103
  %105 = sub i32 %104, %92
  %106 = zext i32 %105 to i64
  %107 = shl nuw nsw i64 %106, 3
  %108 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %109 = load i64, ptr %108, align 8, !tbaa !30
  %110 = xor i64 %109, -1
  %111 = icmp ugt i64 %107, %110
  br i1 %111, label %204, label %112

112:                                              ; preds = %99
  %113 = zext i32 %104 to i64
  %114 = shl nuw nsw i64 %113, 3
  %115 = tail call noalias ptr @malloc(i64 noundef %114) #22
  %116 = icmp eq ptr %115, null
  br i1 %116, label %204, label %117

117:                                              ; preds = %112
  %118 = load ptr, ptr %53, align 8, !tbaa !23
  %119 = load i32, ptr %91, align 8, !tbaa !33
  %120 = zext i32 %119 to i64
  %121 = shl nuw nsw i64 %120, 3
  %122 = icmp eq i32 %119, 0
  br i1 %122, label %130, label %123

123:                                              ; preds = %117, %123
  %124 = phi i64 [ %128, %123 ], [ 0, %117 ]
  %125 = getelementptr inbounds nuw i8, ptr %118, i64 %124
  %126 = load volatile i8, ptr %125, align 1, !tbaa !38
  %127 = getelementptr inbounds nuw i8, ptr %115, i64 %124
  store volatile i8 %126, ptr %127, align 1, !tbaa !38
  %128 = add nuw nsw i64 %124, 1
  %129 = icmp eq i64 %128, %121
  br i1 %129, label %130, label %123, !llvm.loop !39

130:                                              ; preds = %123, %117, %94
  %131 = phi i32 [ %92, %94 ], [ 0, %117 ], [ %119, %123 ]
  %132 = phi ptr [ %97, %94 ], [ %118, %117 ], [ %118, %123 ]
  %133 = phi i32 [ %96, %94 ], [ %104, %117 ], [ %104, %123 ]
  %134 = phi ptr [ %97, %94 ], [ %115, %117 ], [ %115, %123 ]
  %135 = load i32, ptr %30, align 8, !tbaa !16
  %136 = icmp eq i32 %135, 0
  br i1 %58, label %137, label %154

137:                                              ; preds = %130
  br i1 %136, label %138, label %178

138:                                              ; preds = %137
  %139 = icmp eq i64 %2, 0
  br i1 %139, label %178, label %140

140:                                              ; preds = %138
  %141 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %142 = load i32, ptr %141, align 8, !tbaa !13
  %143 = zext i32 %142 to i64
  %144 = icmp samesign ugt i64 %2, %143
  br i1 %144, label %178, label %145

145:                                              ; preds = %140
  %146 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %147 = load ptr, ptr %146, align 8, !tbaa !12
  %148 = icmp eq ptr %147, null
  br i1 %148, label %178, label %149

149:                                              ; preds = %145
  %150 = getelementptr %struct.NmsView, ptr %147, i64 %2
  %151 = getelementptr i8, ptr %150, i64 -16
  %152 = load ptr, ptr %151, align 8, !tbaa !24
  %153 = icmp eq ptr %152, null
  br i1 %153, label %178, label %184

154:                                              ; preds = %130
  br i1 %136, label %155, label %178

155:                                              ; preds = %154
  %156 = and i64 %2, 9223372036854775807
  %157 = icmp eq i64 %156, 0
  br i1 %157, label %178, label %158

158:                                              ; preds = %155
  %159 = load i32, ptr %37, align 4, !tbaa !17
  %160 = zext i32 %159 to i64
  %161 = icmp samesign ugt i64 %156, %160
  br i1 %161, label %178, label %162

162:                                              ; preds = %158
  %163 = load ptr, ptr %43, align 8, !tbaa !18
  %164 = icmp eq ptr %163, null
  br i1 %164, label %178, label %165

165:                                              ; preds = %162
  %166 = getelementptr inbounds nuw %struct.NmsSlot, ptr %163, i64 %156
  %167 = getelementptr inbounds nuw i8, ptr %166, i64 8
  %168 = load i64, ptr %167, align 8, !tbaa !19
  %169 = icmp eq i64 %168, 0
  br i1 %169, label %178, label %170

170:                                              ; preds = %165
  %171 = and i64 %2, 4294967295
  %172 = getelementptr inbounds nuw %struct.NmsSlot, ptr %163, i64 %171
  %173 = getelementptr inbounds nuw i8, ptr %172, i64 8
  %174 = load i64, ptr %173, align 8, !tbaa !19
  %175 = icmp eq i64 %174, -1
  br i1 %175, label %178, label %176

176:                                              ; preds = %170
  %177 = add nuw i64 %174, 1
  store i64 %177, ptr %173, align 8, !tbaa !19
  br label %184

178:                                              ; preds = %149, %140, %154, %165, %137, %138, %145, %170, %155, %158, %162
  %179 = phi i32 [ 6, %140 ], [ 6, %162 ], [ 6, %158 ], [ 6, %155 ], [ 3, %170 ], [ 6, %145 ], [ 6, %138 ], [ 5, %137 ], [ 6, %165 ], [ 5, %154 ], [ 6, %149 ]
  %180 = icmp eq ptr %134, %132
  %181 = icmp eq ptr %134, null
  %182 = or i1 %181, %180
  br i1 %182, label %204, label %183

183:                                              ; preds = %178
  tail call void @free(ptr noundef nonnull %134) #22
  br label %204

184:                                              ; preds = %176, %149
  %185 = icmp eq ptr %134, %132
  br i1 %185, label %199, label %186

186:                                              ; preds = %184
  %187 = load i32, ptr %95, align 8, !tbaa !37
  %188 = sub i32 %133, %187
  %189 = zext i32 %188 to i64
  %190 = shl nuw nsw i64 %189, 3
  %191 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %192 = load i64, ptr %191, align 8, !tbaa !30
  %193 = add i64 %190, %192
  store i64 %193, ptr %191, align 8, !tbaa !30
  %194 = icmp eq ptr %132, null
  br i1 %194, label %197, label %195

195:                                              ; preds = %186
  tail call void @free(ptr noundef nonnull %132) #22
  %196 = load i32, ptr %91, align 8, !tbaa !33
  br label %197

197:                                              ; preds = %186, %195
  %198 = phi i32 [ %131, %186 ], [ %196, %195 ]
  store ptr %134, ptr %53, align 8, !tbaa !23
  store i32 %133, ptr %95, align 8, !tbaa !37
  br label %199

199:                                              ; preds = %197, %184
  %200 = phi i32 [ %198, %197 ], [ %131, %184 ]
  %201 = add i32 %200, 1
  store i32 %201, ptr %91, align 8, !tbaa !33
  %202 = zext i32 %200 to i64
  %203 = getelementptr inbounds nuw i64, ptr %134, i64 %202
  store i64 %2, ptr %203, align 8, !tbaa !15
  br label %204

204:                                              ; preds = %59, %68, %76, %81, %74, %63, %85, %18, %11, %7, %13, %22, %6, %29, %46, %42, %36, %33, %28, %199, %178, %112, %99, %90, %183, %51
  %205 = phi i32 [ %179, %183 ], [ 1, %51 ], [ 6, %28 ], [ 3, %90 ], [ %179, %178 ], [ 0, %199 ], [ 3, %99 ], [ 3, %112 ], [ 6, %85 ], [ 6, %18 ], [ 6, %11 ], [ 5, %7 ], [ 6, %13 ], [ %27, %22 ], [ 6, %6 ], [ 5, %29 ], [ 6, %46 ], [ 6, %42 ], [ 6, %36 ], [ 6, %33 ], [ 6, %59 ], [ 1, %68 ], [ 6, %63 ], [ 6, %76 ], [ 6, %81 ], [ 6, %74 ]
  ret i32 %205
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_retain(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = icmp sgt i64 %1, -1
  %4 = icmp eq ptr %0, null
  br i1 %3, label %5, label %27

5:                                                ; preds = %2
  br i1 %4, label %57, label %6

6:                                                ; preds = %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !16
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %57

10:                                               ; preds = %6
  %11 = icmp eq i64 %1, 0
  br i1 %11, label %57, label %12

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %14 = load i32, ptr %13, align 8, !tbaa !13
  %15 = zext i32 %14 to i64
  %16 = icmp samesign ugt i64 %1, %15
  br i1 %16, label %57, label %17

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %19 = load ptr, ptr %18, align 8, !tbaa !12
  %20 = icmp eq ptr %19, null
  br i1 %20, label %57, label %21

21:                                               ; preds = %17
  %22 = getelementptr %struct.NmsView, ptr %19, i64 %1
  %23 = getelementptr i8, ptr %22, i64 -16
  %24 = load ptr, ptr %23, align 8, !tbaa !24
  %25 = icmp eq ptr %24, null
  %26 = select i1 %25, i32 6, i32 0
  br label %57

27:                                               ; preds = %2
  br i1 %4, label %57, label %28

28:                                               ; preds = %27
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %30 = load i32, ptr %29, align 8, !tbaa !16
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %32, label %57

32:                                               ; preds = %28
  %33 = and i64 %1, 9223372036854775807
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %57, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %37 = load i32, ptr %36, align 4, !tbaa !17
  %38 = zext i32 %37 to i64
  %39 = icmp samesign ugt i64 %33, %38
  br i1 %39, label %57, label %40

40:                                               ; preds = %35
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !18
  %43 = icmp eq ptr %42, null
  br i1 %43, label %57, label %44

44:                                               ; preds = %40
  %45 = getelementptr inbounds nuw %struct.NmsSlot, ptr %42, i64 %33
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 8
  %47 = load i64, ptr %46, align 8, !tbaa !19
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %57, label %49

49:                                               ; preds = %44
  %50 = and i64 %1, 4294967295
  %51 = getelementptr inbounds nuw %struct.NmsSlot, ptr %42, i64 %50
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 8
  %53 = load i64, ptr %52, align 8, !tbaa !19
  %54 = icmp eq i64 %53, -1
  br i1 %54, label %57, label %55

55:                                               ; preds = %49
  %56 = add nuw i64 %53, 1
  store i64 %56, ptr %52, align 8, !tbaa !19
  br label %57

57:                                               ; preds = %21, %32, %35, %40, %44, %28, %27, %55, %49, %17, %12, %10, %6, %5
  %58 = phi i32 [ 6, %12 ], [ 6, %5 ], [ %26, %21 ], [ 6, %27 ], [ 5, %6 ], [ 6, %10 ], [ 6, %17 ], [ 0, %55 ], [ 3, %49 ], [ 6, %32 ], [ 6, %35 ], [ 6, %40 ], [ 6, %44 ], [ 5, %28 ]
  ret i32 %58
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_string_array_get(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = icmp eq ptr %3, null
  br i1 %5, label %105, label %6

6:                                                ; preds = %4
  %7 = icmp sgt i64 %1, -1
  %8 = icmp eq ptr %0, null
  br i1 %7, label %9, label %31

9:                                                ; preds = %6
  br i1 %8, label %105, label %10

10:                                               ; preds = %9
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !16
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %105

14:                                               ; preds = %10
  %15 = icmp eq i64 %1, 0
  br i1 %15, label %105, label %16

16:                                               ; preds = %14
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %18 = load i32, ptr %17, align 8, !tbaa !13
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %1, %19
  br i1 %20, label %105, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %23 = load ptr, ptr %22, align 8, !tbaa !12
  %24 = icmp eq ptr %23, null
  br i1 %24, label %105, label %25

25:                                               ; preds = %21
  %26 = getelementptr %struct.NmsView, ptr %23, i64 %1
  %27 = getelementptr i8, ptr %26, i64 -16
  %28 = load ptr, ptr %27, align 8, !tbaa !24
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %105

31:                                               ; preds = %6
  br i1 %8, label %105, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %34 = load i32, ptr %33, align 8, !tbaa !16
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %105

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %105, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %41 = load i32, ptr %40, align 4, !tbaa !17
  %42 = freeze i32 %41
  %43 = zext i32 %42 to i64
  %44 = icmp samesign ugt i64 %37, %43
  br i1 %44, label %105, label %45

45:                                               ; preds = %39
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %47 = load ptr, ptr %46, align 8, !tbaa !18
  %48 = icmp eq ptr %47, null
  br i1 %48, label %105, label %49

49:                                               ; preds = %45
  %50 = getelementptr inbounds nuw %struct.NmsSlot, ptr %47, i64 %37
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 8
  %52 = load i64, ptr %51, align 8, !tbaa !19
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %105, label %54

54:                                               ; preds = %49
  %55 = and i64 %1, 4294967295
  %56 = getelementptr inbounds nuw %struct.NmsSlot, ptr %47, i64 %55
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 28
  %58 = load i32, ptr %57, align 4, !tbaa !22
  %59 = icmp eq i32 %58, 2
  br i1 %59, label %60, label %105

60:                                               ; preds = %54
  %61 = getelementptr inbounds nuw i8, ptr %56, i64 16
  %62 = load i32, ptr %61, align 8, !tbaa !33
  %63 = zext i32 %62 to i64
  %64 = icmp ult i64 %2, %63
  br i1 %64, label %66, label %65

65:                                               ; preds = %60
  store i64 0, ptr %3, align 8, !tbaa !15
  br label %105

66:                                               ; preds = %60
  %67 = load ptr, ptr %56, align 8, !tbaa !23
  %68 = getelementptr inbounds nuw i64, ptr %67, i64 %2
  %69 = load i64, ptr %68, align 8, !tbaa !15
  %70 = icmp sgt i64 %69, -1
  br i1 %70, label %71, label %87

71:                                               ; preds = %66
  %72 = icmp eq i64 %69, 0
  br i1 %72, label %105, label %73

73:                                               ; preds = %71
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %75 = load i32, ptr %74, align 8, !tbaa !13
  %76 = zext i32 %75 to i64
  %77 = icmp samesign ugt i64 %69, %76
  br i1 %77, label %105, label %78

78:                                               ; preds = %73
  %79 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %80 = load ptr, ptr %79, align 8, !tbaa !12
  %81 = icmp eq ptr %80, null
  br i1 %81, label %105, label %82

82:                                               ; preds = %78
  %83 = getelementptr %struct.NmsView, ptr %80, i64 %69
  %84 = getelementptr i8, ptr %83, i64 -16
  %85 = load ptr, ptr %84, align 8, !tbaa !24
  %86 = icmp eq ptr %85, null
  br i1 %86, label %105, label %104

87:                                               ; preds = %66
  %88 = and i64 %69, 9223372036854775807
  %89 = add nsw i64 %88, -1
  %90 = icmp ult i64 %89, %43
  br i1 %90, label %91, label %105

91:                                               ; preds = %87
  %92 = getelementptr inbounds nuw %struct.NmsSlot, ptr %47, i64 %88
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 8
  %94 = load i64, ptr %93, align 8, !tbaa !19
  %95 = icmp eq i64 %94, 0
  br i1 %95, label %105, label %96

96:                                               ; preds = %91
  %97 = and i64 %69, 4294967295
  %98 = getelementptr inbounds nuw %struct.NmsSlot, ptr %47, i64 %97
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 8
  %100 = load i64, ptr %99, align 8, !tbaa !19
  %101 = icmp eq i64 %100, -1
  br i1 %101, label %105, label %102

102:                                              ; preds = %96
  %103 = add nuw i64 %100, 1
  store i64 %103, ptr %99, align 8, !tbaa !19
  br label %104

104:                                              ; preds = %102, %82
  store i64 %69, ptr %3, align 8, !tbaa !15
  br label %105

105:                                              ; preds = %82, %87, %96, %78, %71, %91, %73, %21, %14, %10, %16, %25, %9, %32, %49, %45, %39, %36, %31, %54, %104, %65, %4
  %106 = phi i32 [ 6, %4 ], [ 1, %54 ], [ 0, %65 ], [ 0, %104 ], [ 6, %31 ], [ 6, %21 ], [ 6, %14 ], [ 5, %10 ], [ 6, %16 ], [ %30, %25 ], [ 6, %9 ], [ 5, %32 ], [ 6, %49 ], [ 6, %45 ], [ 6, %39 ], [ 6, %36 ], [ 6, %73 ], [ 6, %91 ], [ 6, %87 ], [ 3, %96 ], [ 6, %78 ], [ 6, %71 ], [ 6, %82 ]
  ret i32 %106
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_string_array_length(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %61, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %30

8:                                                ; preds = %5
  br i1 %7, label %61, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !16
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %61

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %61, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load i32, ptr %16, align 8, !tbaa !13
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %61, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %22 = load ptr, ptr %21, align 8, !tbaa !12
  %23 = icmp eq ptr %22, null
  br i1 %23, label %61, label %24

24:                                               ; preds = %20
  %25 = getelementptr %struct.NmsView, ptr %22, i64 %1
  %26 = getelementptr i8, ptr %25, i64 -16
  %27 = load ptr, ptr %26, align 8, !tbaa !24
  %28 = icmp eq ptr %27, null
  %29 = select i1 %28, i32 6, i32 1
  br label %61

30:                                               ; preds = %5
  br i1 %7, label %61, label %31

31:                                               ; preds = %30
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = load i32, ptr %32, align 8, !tbaa !16
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %61

35:                                               ; preds = %31
  %36 = and i64 %1, 9223372036854775807
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %61, label %38

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !17
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %36, %41
  br i1 %42, label %61, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %45 = load ptr, ptr %44, align 8, !tbaa !18
  %46 = icmp eq ptr %45, null
  br i1 %46, label %61, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i64 %36
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %50 = load i64, ptr %49, align 8, !tbaa !19
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %61, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 4294967295
  %54 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 28
  %56 = load i32, ptr %55, align 4, !tbaa !22
  %57 = icmp eq i32 %56, 2
  br i1 %57, label %58, label %61

58:                                               ; preds = %52
  %59 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %60 = load i32, ptr %59, align 8, !tbaa !33
  store i32 %60, ptr %2, align 4, !tbaa !4
  br label %61

61:                                               ; preds = %20, %13, %9, %15, %24, %8, %31, %47, %43, %38, %35, %30, %52, %58, %3
  %62 = phi i32 [ 6, %3 ], [ 1, %52 ], [ 0, %58 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %29, %24 ], [ 6, %8 ], [ 5, %31 ], [ 6, %47 ], [ 6, %43 ], [ 6, %38 ], [ 6, %35 ], [ 6, %30 ]
  ret i32 %62
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_create(ptr noundef captures(address_is_null) %0, ptr noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @create_parts(ptr noundef %0, ptr noundef %1, i64 noundef %2, ptr noundef null, i64 noundef 0, ptr noundef %3) #23
  ret i32 %5
}

; Function Attrs: nounwind
define internal fastcc range(i32 0, 7) i32 @create_parts(ptr noundef captures(address_is_null) %0, ptr noundef %1, i64 noundef %2, ptr noundef %3, i64 noundef range(i64 0, 4294967296) %4, ptr noundef writeonly captures(address_is_null) %5) unnamed_addr #3 {
  %7 = icmp ne ptr %0, null
  %8 = icmp ne ptr %5, null
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %61

10:                                               ; preds = %6
  %11 = icmp eq ptr %1, null
  %12 = icmp ne i64 %2, 0
  %13 = and i1 %11, %12
  br i1 %13, label %61, label %14

14:                                               ; preds = %10
  %15 = icmp eq ptr %3, null
  %16 = icmp ne i64 %4, 0
  %17 = and i1 %15, %16
  br i1 %17, label %61, label %18

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %20 = load i32, ptr %19, align 8, !tbaa !16
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %61

22:                                               ; preds = %18
  %23 = icmp ugt i64 %2, 4294967295
  br i1 %23, label %61, label %24

24:                                               ; preds = %22
  %25 = add nuw nsw i64 %4, %2
  %26 = icmp samesign ugt i64 %25, 4294967295
  br i1 %26, label %61, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %29 = load i64, ptr %28, align 8, !tbaa !30
  %30 = xor i64 %29, -1
  %31 = icmp ugt i64 %25, %30
  br i1 %31, label %61, label %32

32:                                               ; preds = %27
  %33 = add nuw nsw i64 %25, 1
  %34 = tail call noalias ptr @malloc(i64 noundef %33) #22
  %35 = icmp eq ptr %34, null
  br i1 %35, label %61, label %36

36:                                               ; preds = %32
  %37 = icmp eq i64 %2, 0
  br i1 %37, label %45, label %38

38:                                               ; preds = %36, %38
  %39 = phi i64 [ %43, %38 ], [ 0, %36 ]
  %40 = getelementptr inbounds nuw i8, ptr %1, i64 %39
  %41 = load volatile i8, ptr %40, align 1, !tbaa !38
  %42 = getelementptr inbounds nuw i8, ptr %34, i64 %39
  store volatile i8 %41, ptr %42, align 1, !tbaa !38
  %43 = add nuw nsw i64 %39, 1
  %44 = icmp eq i64 %43, %2
  br i1 %44, label %45, label %38, !llvm.loop !39

45:                                               ; preds = %38, %36
  %46 = getelementptr inbounds nuw i8, ptr %34, i64 %2
  %47 = icmp eq i64 %4, 0
  br i1 %47, label %55, label %48

48:                                               ; preds = %45, %48
  %49 = phi i64 [ %53, %48 ], [ 0, %45 ]
  %50 = getelementptr inbounds nuw i8, ptr %3, i64 %49
  %51 = load volatile i8, ptr %50, align 1, !tbaa !38
  %52 = getelementptr inbounds nuw i8, ptr %46, i64 %49
  store volatile i8 %51, ptr %52, align 1, !tbaa !38
  %53 = add nuw nsw i64 %49, 1
  %54 = icmp eq i64 %53, %4
  br i1 %54, label %55, label %48, !llvm.loop !39

55:                                               ; preds = %48, %45
  %56 = getelementptr inbounds nuw i8, ptr %34, i64 %25
  store i8 0, ptr %56, align 1, !tbaa !38
  %57 = trunc nuw i64 %25 to i32
  %58 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %34, i32 noundef %57, i32 noundef 0, i32 noundef 1, i64 noundef %25, ptr noundef %5) #23
  %59 = icmp eq i32 %58, 0
  br i1 %59, label %61, label %60

60:                                               ; preds = %55
  tail call void @free(ptr noundef nonnull %34) #22
  br label %61

61:                                               ; preds = %27, %24, %55, %60, %32, %22, %18, %6, %10, %14
  %62 = phi i32 [ 3, %22 ], [ 6, %6 ], [ 5, %18 ], [ 6, %14 ], [ 6, %10 ], [ 3, %24 ], [ 3, %27 ], [ 3, %32 ], [ %58, %60 ], [ 0, %55 ]
  ret i32 %62
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_value_retain(ptr noundef readonly captures(address_is_null) %0, [2 x i64] %1) local_unnamed_addr #4 {
  %3 = extractvalue [2 x i64] %1, 0
  %4 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %1) #23
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %64

6:                                                ; preds = %2
  %7 = extractvalue [2 x i64] %1, 1
  %8 = trunc i64 %7 to i32
  switch i32 %8, label %64 [
    i32 8, label %9
    i32 7, label %9
    i32 5, label %9
  ]

9:                                                ; preds = %6, %6, %6
  %10 = icmp sgt i64 %3, -1
  %11 = icmp eq ptr %0, null
  br i1 %10, label %12, label %34

12:                                               ; preds = %9
  br i1 %11, label %64, label %13

13:                                               ; preds = %12
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %15 = load i32, ptr %14, align 8, !tbaa !16
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %64

17:                                               ; preds = %13
  %18 = icmp eq i64 %3, 0
  br i1 %18, label %64, label %19

19:                                               ; preds = %17
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %21 = load i32, ptr %20, align 8, !tbaa !13
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %3, %22
  br i1 %23, label %64, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %26 = load ptr, ptr %25, align 8, !tbaa !12
  %27 = icmp eq ptr %26, null
  br i1 %27, label %64, label %28

28:                                               ; preds = %24
  %29 = getelementptr %struct.NmsView, ptr %26, i64 %3
  %30 = getelementptr i8, ptr %29, i64 -16
  %31 = load ptr, ptr %30, align 8, !tbaa !24
  %32 = icmp eq ptr %31, null
  %33 = select i1 %32, i32 6, i32 0
  br label %64

34:                                               ; preds = %9
  br i1 %11, label %64, label %35

35:                                               ; preds = %34
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %37 = load i32, ptr %36, align 8, !tbaa !16
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %39, label %64

39:                                               ; preds = %35
  %40 = and i64 %3, 9223372036854775807
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %64, label %42

42:                                               ; preds = %39
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %44 = load i32, ptr %43, align 4, !tbaa !17
  %45 = zext i32 %44 to i64
  %46 = icmp samesign ugt i64 %40, %45
  br i1 %46, label %64, label %47

47:                                               ; preds = %42
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %49 = load ptr, ptr %48, align 8, !tbaa !18
  %50 = icmp eq ptr %49, null
  br i1 %50, label %64, label %51

51:                                               ; preds = %47
  %52 = getelementptr inbounds nuw %struct.NmsSlot, ptr %49, i64 %40
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 8
  %54 = load i64, ptr %53, align 8, !tbaa !19
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %64, label %56

56:                                               ; preds = %51
  %57 = and i64 %3, 4294967295
  %58 = getelementptr inbounds nuw %struct.NmsSlot, ptr %49, i64 %57
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 8
  %60 = load i64, ptr %59, align 8, !tbaa !19
  %61 = icmp eq i64 %60, -1
  br i1 %61, label %64, label %62

62:                                               ; preds = %56
  %63 = add nuw i64 %60, 1
  store i64 %63, ptr %59, align 8, !tbaa !19
  br label %64

64:                                               ; preds = %6, %62, %56, %51, %47, %42, %39, %35, %34, %28, %24, %19, %17, %13, %12, %2
  %65 = phi i32 [ %4, %2 ], [ 0, %6 ], [ 6, %19 ], [ 6, %12 ], [ %33, %28 ], [ 6, %34 ], [ 5, %13 ], [ 6, %17 ], [ 6, %24 ], [ 0, %62 ], [ 3, %56 ], [ 6, %39 ], [ 6, %42 ], [ 6, %47 ], [ 6, %51 ], [ 5, %35 ]
  ret i32 %65
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc range(i32 0, 7) i32 @value_valid(ptr noundef readonly captures(address_is_null) %0, [2 x i64] %1) unnamed_addr #5 {
  %3 = extractvalue [2 x i64] %1, 0
  %4 = extractvalue [2 x i64] %1, 1
  %5 = trunc i64 %4 to i32
  %6 = icmp eq ptr %0, null
  br i1 %6, label %160, label %7

7:                                                ; preds = %2
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !16
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %160

11:                                               ; preds = %7
  switch i32 %5, label %155 [
    i32 5, label %12
    i32 7, label %55
    i32 8, label %99
  ]

12:                                               ; preds = %11
  %13 = icmp sgt i64 %3, -1
  br i1 %13, label %38, label %14

14:                                               ; preds = %12
  %15 = and i64 %3, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %160, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !17
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %160, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !18
  %25 = icmp eq ptr %24, null
  br i1 %25, label %160, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %15
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !19
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %160, label %31

31:                                               ; preds = %26
  %32 = and i64 %3, 4294967295
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !22
  %36 = icmp ne i32 %35, 1
  %37 = zext i1 %36 to i32
  br label %160

38:                                               ; preds = %12
  %39 = icmp eq i64 %3, 0
  br i1 %39, label %160, label %40

40:                                               ; preds = %38
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %42 = load i32, ptr %41, align 8, !tbaa !13
  %43 = zext i32 %42 to i64
  %44 = icmp samesign ugt i64 %3, %43
  br i1 %44, label %160, label %45

45:                                               ; preds = %40
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %47 = load ptr, ptr %46, align 8, !tbaa !12
  %48 = icmp eq ptr %47, null
  br i1 %48, label %160, label %49

49:                                               ; preds = %45
  %50 = getelementptr %struct.NmsView, ptr %47, i64 %3
  %51 = getelementptr i8, ptr %50, i64 -16
  %52 = load ptr, ptr %51, align 8, !tbaa !24
  %53 = icmp eq ptr %52, null
  %54 = select i1 %53, i32 6, i32 0
  br label %160

55:                                               ; preds = %11
  %56 = icmp sgt i64 %3, -1
  br i1 %56, label %57, label %74

57:                                               ; preds = %55
  %58 = icmp eq i64 %3, 0
  br i1 %58, label %160, label %59

59:                                               ; preds = %57
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %61 = load i32, ptr %60, align 8, !tbaa !13
  %62 = zext i32 %61 to i64
  %63 = icmp samesign ugt i64 %3, %62
  br i1 %63, label %160, label %64

64:                                               ; preds = %59
  %65 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %66 = load ptr, ptr %65, align 8, !tbaa !12
  %67 = icmp eq ptr %66, null
  br i1 %67, label %160, label %68

68:                                               ; preds = %64
  %69 = getelementptr %struct.NmsView, ptr %66, i64 %3
  %70 = getelementptr i8, ptr %69, i64 -16
  %71 = load ptr, ptr %70, align 8, !tbaa !24
  %72 = icmp eq ptr %71, null
  %73 = select i1 %72, i32 6, i32 1
  br label %160

74:                                               ; preds = %55
  %75 = and i64 %3, 9223372036854775807
  %76 = icmp eq i64 %75, 0
  br i1 %76, label %160, label %77

77:                                               ; preds = %74
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %79 = load i32, ptr %78, align 4, !tbaa !17
  %80 = zext i32 %79 to i64
  %81 = icmp samesign ugt i64 %75, %80
  br i1 %81, label %160, label %82

82:                                               ; preds = %77
  %83 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %84 = load ptr, ptr %83, align 8, !tbaa !18
  %85 = icmp eq ptr %84, null
  br i1 %85, label %160, label %86

86:                                               ; preds = %82
  %87 = getelementptr inbounds nuw %struct.NmsSlot, ptr %84, i64 %75
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 8
  %89 = load i64, ptr %88, align 8, !tbaa !19
  %90 = icmp eq i64 %89, 0
  br i1 %90, label %160, label %91

91:                                               ; preds = %86
  %92 = and i64 %3, 4294967295
  %93 = getelementptr inbounds nuw %struct.NmsSlot, ptr %84, i64 %92
  %94 = getelementptr inbounds nuw i8, ptr %93, i64 28
  %95 = load i32, ptr %94, align 4, !tbaa !22
  %96 = add i32 %95, -5
  %97 = icmp ult i32 %96, -3
  %98 = zext i1 %97 to i32
  br label %160

99:                                               ; preds = %11
  %100 = and i64 %3, 9223372036854775807
  %101 = icmp slt i64 %3, 0
  %102 = icmp ne i64 %100, 0
  %103 = and i1 %101, %102
  br i1 %103, label %104, label %160

104:                                              ; preds = %99
  %105 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %106 = load i32, ptr %105, align 4, !tbaa !17
  %107 = zext i32 %106 to i64
  %108 = icmp samesign ugt i64 %100, %107
  br i1 %108, label %160, label %109

109:                                              ; preds = %104
  %110 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %111 = load ptr, ptr %110, align 8, !tbaa !18
  %112 = icmp eq ptr %111, null
  br i1 %112, label %160, label %113

113:                                              ; preds = %109
  %114 = getelementptr inbounds nuw %struct.NmsSlot, ptr %111, i64 %100
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 8
  %116 = load i64, ptr %115, align 8, !tbaa !19
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %160, label %118

118:                                              ; preds = %113
  %119 = and i64 %3, 4294967295
  %120 = getelementptr inbounds nuw %struct.NmsSlot, ptr %111, i64 %119
  %121 = getelementptr inbounds nuw i8, ptr %120, i64 28
  %122 = load i32, ptr %121, align 4, !tbaa !22
  %123 = icmp eq i32 %122, 5
  br i1 %123, label %124, label %160

124:                                              ; preds = %118
  %125 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %126 = load i32, ptr %125, align 4, !tbaa !40
  %127 = icmp eq i32 %126, 0
  br i1 %127, label %160, label %128

128:                                              ; preds = %124
  %129 = load ptr, ptr %0, align 8, !tbaa !8
  %130 = icmp eq ptr %129, null
  br i1 %130, label %160, label %131

131:                                              ; preds = %128
  %132 = getelementptr inbounds nuw i8, ptr %120, i64 40
  %133 = load i32, ptr %132, align 8, !tbaa !32
  %134 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %135 = load i32, ptr %134, align 8, !tbaa !41
  %136 = icmp ult i32 %133, %135
  br i1 %136, label %137, label %160

137:                                              ; preds = %131
  %138 = zext i32 %133 to i64
  %139 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %129, i64 %138
  %140 = getelementptr inbounds nuw i8, ptr %139, i64 4
  %141 = load i32, ptr %140, align 4, !tbaa !42
  %142 = getelementptr inbounds nuw i8, ptr %120, i64 16
  %143 = load i32, ptr %142, align 8, !tbaa !33
  %144 = icmp eq i32 %143, %141
  br i1 %144, label %145, label %160

145:                                              ; preds = %137
  %146 = getelementptr inbounds nuw i8, ptr %120, i64 24
  %147 = load i32, ptr %146, align 8, !tbaa !37
  %148 = icmp eq i32 %147, %141
  br i1 %148, label %149, label %160

149:                                              ; preds = %145
  %150 = icmp eq i32 %141, 0
  br i1 %150, label %160, label %151

151:                                              ; preds = %149
  %152 = load ptr, ptr %120, align 8, !tbaa !23
  %153 = icmp eq ptr %152, null
  %154 = select i1 %153, i32 6, i32 0
  br label %160

155:                                              ; preds = %11
  %156 = icmp ugt i32 %5, 4
  %157 = icmp ne i32 %5, 9
  %158 = and i1 %156, %157
  %159 = zext i1 %158 to i32
  br label %160

160:                                              ; preds = %49, %31, %151, %149, %145, %137, %131, %128, %124, %118, %113, %109, %104, %99, %91, %86, %82, %77, %74, %68, %64, %59, %57, %45, %40, %38, %26, %22, %17, %14, %7, %2, %155
  %161 = phi i32 [ 6, %2 ], [ 5, %7 ], [ 6, %113 ], [ %73, %68 ], [ %159, %155 ], [ 6, %14 ], [ 6, %109 ], [ 6, %26 ], [ 6, %17 ], [ 6, %38 ], [ 6, %45 ], [ 6, %40 ], [ 6, %22 ], [ %54, %49 ], [ %37, %31 ], [ 6, %57 ], [ %98, %91 ], [ 6, %74 ], [ 6, %77 ], [ 6, %82 ], [ 6, %86 ], [ 6, %59 ], [ 6, %64 ], [ %154, %151 ], [ 6, %124 ], [ 1, %118 ], [ 6, %131 ], [ 6, %128 ], [ 6, %145 ], [ 6, %137 ], [ 0, %149 ], [ 6, %99 ], [ 6, %104 ]
  ret i32 %161
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_value_release(ptr noundef captures(address_is_null) %0, [2 x i64] %1) local_unnamed_addr #3 {
  %3 = extractvalue [2 x i64] %1, 0
  %4 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %1) #23
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %11

6:                                                ; preds = %2
  %7 = extractvalue [2 x i64] %1, 1
  %8 = trunc i64 %7 to i32
  switch i32 %8, label %11 [
    i32 8, label %9
    i32 7, label %9
    i32 5, label %9
  ]

9:                                                ; preds = %6, %6, %6
  %10 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %3) #23
  br label %11

11:                                               ; preds = %6, %9, %2
  %12 = phi i32 [ %4, %2 ], [ %10, %9 ], [ 0, %6 ]
  ret i32 %12
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_release(ptr noundef captures(address_is_null) %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = icmp sgt i64 %1, -1
  %4 = icmp eq ptr %0, null
  br i1 %3, label %5, label %27

5:                                                ; preds = %2
  br i1 %4, label %208, label %6

6:                                                ; preds = %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !16
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %208

10:                                               ; preds = %6
  %11 = icmp eq i64 %1, 0
  br i1 %11, label %208, label %12

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %14 = load i32, ptr %13, align 8, !tbaa !13
  %15 = zext i32 %14 to i64
  %16 = icmp samesign ugt i64 %1, %15
  br i1 %16, label %208, label %17

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %19 = load ptr, ptr %18, align 8, !tbaa !12
  %20 = icmp eq ptr %19, null
  br i1 %20, label %208, label %21

21:                                               ; preds = %17
  %22 = getelementptr %struct.NmsView, ptr %19, i64 %1
  %23 = getelementptr i8, ptr %22, i64 -16
  %24 = load ptr, ptr %23, align 8, !tbaa !24
  %25 = icmp eq ptr %24, null
  %26 = select i1 %25, i32 6, i32 0
  br label %208

27:                                               ; preds = %2
  br i1 %4, label %208, label %28

28:                                               ; preds = %27
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %30 = load i32, ptr %29, align 8, !tbaa !16
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %32, label %208

32:                                               ; preds = %28
  %33 = and i64 %1, 9223372036854775807
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %208, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %37 = load i32, ptr %36, align 4, !tbaa !17
  %38 = zext i32 %37 to i64
  %39 = icmp samesign ugt i64 %33, %38
  br i1 %39, label %208, label %40

40:                                               ; preds = %35
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !18
  %43 = icmp eq ptr %42, null
  br i1 %43, label %208, label %44

44:                                               ; preds = %40
  %45 = getelementptr inbounds nuw %struct.NmsSlot, ptr %42, i64 %33
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 8
  %47 = load i64, ptr %46, align 8, !tbaa !19
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %208, label %49

49:                                               ; preds = %44
  %50 = and i64 %1, 4294967295
  %51 = getelementptr inbounds nuw %struct.NmsSlot, ptr %42, i64 %50
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 8
  %53 = load i64, ptr %52, align 8, !tbaa !19
  %54 = add i64 %53, -1
  store i64 %54, ptr %52, align 8, !tbaa !19
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %56, label %208

56:                                               ; preds = %49
  %57 = trunc i64 %1 to i32
  %58 = getelementptr inbounds nuw i8, ptr %51, i64 20
  store i32 0, ptr %58, align 4, !tbaa !34
  %59 = icmp eq i32 %57, 0
  br i1 %59, label %208, label %60

60:                                               ; preds = %56
  %61 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %62 = getelementptr inbounds nuw i8, ptr %0, i64 72
  br label %63

63:                                               ; preds = %60, %202
  %64 = phi i32 [ %57, %60 ], [ %193, %202 ]
  %65 = phi i32 [ 0, %60 ], [ %194, %202 ]
  %66 = load ptr, ptr %41, align 8, !tbaa !18
  %67 = zext i32 %64 to i64
  %68 = getelementptr inbounds nuw %struct.NmsSlot, ptr %66, i64 %67
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 20
  %70 = load i32, ptr %69, align 4, !tbaa !34
  %71 = getelementptr inbounds nuw i8, ptr %68, i64 28
  %72 = load i32, ptr %71, align 4, !tbaa !22
  switch i32 %72, label %164 [
    i32 5, label %73
    i32 3, label %73
    i32 2, label %73
  ]

73:                                               ; preds = %63, %63, %63
  %74 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %75 = load i32, ptr %74, align 8, !tbaa !33
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %172, label %77

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw i8, ptr %68, i64 32
  %79 = zext i32 %75 to i64
  br label %80

80:                                               ; preds = %77, %159
  %81 = phi i64 [ 0, %77 ], [ %162, %159 ]
  %82 = phi i32 [ %70, %77 ], [ %161, %159 ]
  %83 = phi i32 [ %65, %77 ], [ %160, %159 ]
  switch i32 %72, label %114 [
    i32 4, label %84
    i32 2, label %110
  ]

84:                                               ; preds = %80
  %85 = load i32, ptr %78, align 8, !tbaa !44
  %86 = and i32 %85, -3
  %87 = icmp eq i32 %86, 1
  %88 = icmp eq i32 %85, 2
  %89 = icmp eq i32 %85, 4
  %90 = or i1 %88, %89
  %91 = zext i1 %90 to i32
  %92 = select i1 %87, i32 8, i32 %91
  %93 = icmp eq i32 %92, 0
  br i1 %93, label %159, label %94

94:                                               ; preds = %84
  %95 = zext nneg i32 %92 to i64
  %96 = mul nuw nsw i64 %81, %95
  %97 = load ptr, ptr %68, align 8, !tbaa !23
  %98 = getelementptr inbounds nuw i8, ptr %97, i64 %96
  br label %99

99:                                               ; preds = %99, %94
  %100 = phi i64 [ 0, %94 ], [ %108, %99 ]
  %101 = phi i64 [ 0, %94 ], [ %107, %99 ]
  %102 = getelementptr inbounds nuw i8, ptr %98, i64 %100
  %103 = load i8, ptr %102, align 1, !tbaa !38
  %104 = zext i8 %103 to i64
  %105 = shl nuw nsw i64 %100, 3
  %106 = shl nuw i64 %104, %105
  %107 = or i64 %106, %101
  %108 = add nuw nsw i64 %100, 1
  %109 = icmp eq i64 %108, %95
  br i1 %109, label %121, label %99, !llvm.loop !45

110:                                              ; preds = %80
  %111 = load ptr, ptr %68, align 8, !tbaa !23
  %112 = getelementptr inbounds nuw i64, ptr %111, i64 %81
  %113 = load i64, ptr %112, align 8, !tbaa !15
  br label %121

114:                                              ; preds = %80
  %115 = load ptr, ptr %68, align 8, !tbaa !23
  %116 = getelementptr inbounds nuw %struct.NmsValue, ptr %115, i64 %81
  %117 = load i64, ptr %116, align 8, !tbaa !15
  %118 = getelementptr inbounds nuw i8, ptr %116, i64 8
  %119 = load i64, ptr %118, align 8
  %120 = trunc i64 %119 to i32
  br label %121

121:                                              ; preds = %99, %110, %114
  %122 = phi i64 [ %117, %114 ], [ %113, %110 ], [ %107, %99 ]
  %123 = phi i32 [ %120, %114 ], [ 5, %110 ], [ %85, %99 ]
  %124 = and i32 %123, -3
  %125 = icmp ne i32 %124, 5
  %126 = icmp ne i32 %123, 8
  %127 = and i1 %126, %125
  %128 = icmp sgt i64 %122, -1
  %129 = select i1 %127, i1 true, i1 %128
  br i1 %129, label %159, label %130

130:                                              ; preds = %121
  %131 = load i32, ptr %29, align 8, !tbaa !16
  %132 = icmp eq i32 %131, 0
  br i1 %132, label %133, label %145

133:                                              ; preds = %130
  %134 = and i64 %122, 9223372036854775807
  %135 = icmp eq i64 %134, 0
  br i1 %135, label %145, label %136

136:                                              ; preds = %133
  %137 = load i32, ptr %36, align 4, !tbaa !17
  %138 = zext i32 %137 to i64
  %139 = icmp samesign ugt i64 %134, %138
  br i1 %139, label %145, label %140

140:                                              ; preds = %136
  %141 = getelementptr inbounds nuw %struct.NmsSlot, ptr %66, i64 %134
  %142 = getelementptr inbounds nuw i8, ptr %141, i64 8
  %143 = load i64, ptr %142, align 8, !tbaa !19
  %144 = icmp eq i64 %143, 0
  br i1 %144, label %145, label %149

145:                                              ; preds = %130, %140, %133, %136
  %146 = phi i32 [ 6, %136 ], [ 6, %133 ], [ 6, %140 ], [ 5, %130 ]
  %147 = icmp eq i32 %83, 0
  %148 = select i1 %147, i32 %146, i32 %83
  br label %159

149:                                              ; preds = %140
  %150 = and i64 %122, 4294967295
  %151 = getelementptr inbounds nuw %struct.NmsSlot, ptr %66, i64 %150
  %152 = getelementptr inbounds nuw i8, ptr %151, i64 8
  %153 = load i64, ptr %152, align 8, !tbaa !19
  %154 = add i64 %153, -1
  store i64 %154, ptr %152, align 8, !tbaa !19
  %155 = icmp eq i64 %154, 0
  br i1 %155, label %156, label %159

156:                                              ; preds = %149
  %157 = trunc i64 %122 to i32
  %158 = getelementptr inbounds nuw i8, ptr %151, i64 20
  store i32 %82, ptr %158, align 4, !tbaa !34
  br label %159

159:                                              ; preds = %84, %145, %156, %149, %121
  %160 = phi i32 [ %83, %121 ], [ %148, %145 ], [ %83, %156 ], [ %83, %149 ], [ %83, %84 ]
  %161 = phi i32 [ %82, %121 ], [ %82, %145 ], [ %157, %156 ], [ %82, %149 ], [ %82, %84 ]
  %162 = add nuw nsw i64 %81, 1
  %163 = icmp eq i64 %162, %79
  br i1 %163, label %164, label %80, !llvm.loop !46

164:                                              ; preds = %159, %63
  %165 = phi i32 [ %65, %63 ], [ %160, %159 ]
  %166 = phi i32 [ %70, %63 ], [ %161, %159 ]
  %167 = icmp eq i32 %72, 1
  br i1 %167, label %168, label %172

168:                                              ; preds = %164
  %169 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %170 = load i32, ptr %169, align 8, !tbaa !33
  %171 = zext i32 %170 to i64
  br label %192

172:                                              ; preds = %73, %164
  %173 = phi i32 [ %166, %164 ], [ %70, %73 ]
  %174 = phi i32 [ %165, %164 ], [ %65, %73 ]
  %175 = getelementptr inbounds nuw i8, ptr %68, i64 24
  %176 = load i32, ptr %175, align 8, !tbaa !37
  switch i32 %72, label %187 [
    i32 2, label %188
    i32 4, label %177
  ]

177:                                              ; preds = %172
  %178 = getelementptr inbounds nuw i8, ptr %68, i64 32
  %179 = load i32, ptr %178, align 8, !tbaa !44
  %180 = and i32 %179, -3
  %181 = icmp eq i32 %180, 1
  %182 = icmp eq i32 %179, 2
  %183 = icmp eq i32 %179, 4
  %184 = or i1 %182, %183
  %185 = zext i1 %184 to i64
  %186 = select i1 %181, i64 8, i64 %185
  br label %188

187:                                              ; preds = %172
  br label %188

188:                                              ; preds = %172, %177, %187
  %189 = phi i64 [ 8, %172 ], [ %186, %177 ], [ 16, %187 ]
  %190 = zext i32 %176 to i64
  %191 = mul nuw nsw i64 %189, %190
  br label %192

192:                                              ; preds = %188, %168
  %193 = phi i32 [ %166, %168 ], [ %173, %188 ]
  %194 = phi i32 [ %165, %168 ], [ %174, %188 ]
  %195 = phi i64 [ %171, %168 ], [ %191, %188 ]
  %196 = load <2 x i64>, ptr %61, align 8, !tbaa !15
  %197 = insertelement <2 x i64> <i64 poison, i64 1>, i64 %195, i64 0
  %198 = sub <2 x i64> %196, %197
  store <2 x i64> %198, ptr %61, align 8, !tbaa !15
  %199 = load ptr, ptr %68, align 8, !tbaa !23
  %200 = icmp eq ptr %199, null
  br i1 %200, label %202, label %201

201:                                              ; preds = %192
  tail call void @free(ptr noundef nonnull %199) #22
  br label %202

202:                                              ; preds = %192, %201
  store ptr null, ptr %68, align 8, !tbaa !23
  %203 = getelementptr inbounds nuw i8, ptr %68, i64 16
  store i32 0, ptr %203, align 8, !tbaa !33
  %204 = getelementptr inbounds nuw i8, ptr %68, i64 24
  store <4 x i32> zeroinitializer, ptr %204, align 8, !tbaa !4
  %205 = getelementptr inbounds nuw i8, ptr %68, i64 40
  store i32 0, ptr %205, align 8, !tbaa !32
  %206 = load i32, ptr %62, align 8, !tbaa !31
  store i32 %206, ptr %69, align 4, !tbaa !34
  store i32 %64, ptr %62, align 8, !tbaa !31
  %207 = icmp eq i32 %193, 0
  br i1 %207, label %208, label %63, !llvm.loop !47

208:                                              ; preds = %202, %56, %21, %32, %35, %40, %44, %28, %27, %49, %17, %12, %10, %6, %5
  %209 = phi i32 [ 6, %12 ], [ 6, %5 ], [ %26, %21 ], [ 6, %27 ], [ 5, %6 ], [ 6, %10 ], [ 6, %17 ], [ 0, %49 ], [ 5, %28 ], [ 6, %32 ], [ 6, %35 ], [ 6, %40 ], [ 6, %44 ], [ 0, %56 ], [ %194, %202 ]
  ret i32 %209
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_vm_array_create(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = tail call fastcc i32 @vm_array_create_capacity(ptr noundef %0, i32 noundef %1, i32 noundef 8, ptr noundef %2) #23
  ret i32 %4
}

; Function Attrs: nounwind
define internal fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr noundef captures(address_is_null) %0, i32 noundef %1, i32 noundef %2, ptr noundef writeonly captures(address_is_null) %3) unnamed_addr #3 {
  %5 = alloca i64, align 8
  %6 = icmp ne ptr %0, null
  %7 = icmp ne ptr %3, null
  %8 = and i1 %6, %7
  br i1 %8, label %9, label %49

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !16
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %49

13:                                               ; preds = %9
  switch i32 %1, label %49 [
    i32 9, label %14
    i32 7, label %14
    i32 5, label %14
    i32 4, label %14
    i32 3, label %14
    i32 2, label %14
    i32 1, label %14
    i32 0, label %14
  ]

14:                                               ; preds = %13, %13, %13, %13, %13, %13, %13, %13
  %15 = and i32 %1, -3
  %16 = icmp eq i32 %15, 1
  %17 = icmp eq i32 %1, 2
  %18 = icmp eq i32 %1, 4
  %19 = or i1 %17, %18
  %20 = zext i1 %19 to i32
  %21 = select i1 %16, i32 8, i32 %20
  %22 = icmp eq i32 %21, 0
  %23 = select i1 %22, i32 3, i32 4
  %24 = select i1 %22, i32 16, i32 %21
  %25 = tail call i32 @llvm.umax.i32(i32 %2, i32 8)
  %26 = zext i32 %25 to i64
  %27 = zext nneg i32 %24 to i64
  %28 = mul nuw nsw i64 %27, %26
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %30 = load i64, ptr %29, align 8, !tbaa !30
  %31 = xor i64 %30, -1
  %32 = icmp ugt i64 %28, %31
  br i1 %32, label %49, label %33

33:                                               ; preds = %14
  %34 = tail call noalias ptr @malloc(i64 noundef %28) #22
  %35 = icmp eq ptr %34, null
  br i1 %35, label %49, label %36

36:                                               ; preds = %33
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  store i64 0, ptr %5, align 8, !tbaa !15
  %37 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %34, i32 noundef 0, i32 noundef %25, i32 noundef %23, i64 noundef %28, ptr noundef %5) #23
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %40, label %39

39:                                               ; preds = %36
  tail call void @free(ptr noundef nonnull %34) #22
  br label %48

40:                                               ; preds = %36
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !18
  %43 = load i64, ptr %5, align 8, !tbaa !15
  %44 = and i64 %43, 4294967295
  %45 = getelementptr inbounds nuw %struct.NmsSlot, ptr %42, i64 %44
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  store i32 %1, ptr %46, align 8, !tbaa !44
  %47 = getelementptr inbounds nuw i8, ptr %45, i64 36
  store i32 1, ptr %47, align 4, !tbaa !48
  store i64 %43, ptr %3, align 8, !tbaa !15
  br label %48

48:                                               ; preds = %40, %39
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  br label %49

49:                                               ; preds = %14, %33, %48, %13, %9, %4
  %50 = phi i32 [ 6, %4 ], [ 1, %13 ], [ 5, %9 ], [ 3, %14 ], [ %37, %48 ], [ 3, %33 ]
  ret i32 %50
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_packed_array_create(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  %5 = icmp ne ptr %0, null
  %6 = icmp ne ptr %2, null
  %7 = and i1 %5, %6
  br i1 %7, label %8, label %26

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !16
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %26

12:                                               ; preds = %8
  %13 = add i32 %1, -1
  %14 = icmp ult i32 %13, 4
  br i1 %14, label %15, label %26

15:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #24
  store i64 0, ptr %4, align 8, !tbaa !15
  %16 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 4, i64 noundef 0, ptr noundef %4) #23
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %25

18:                                               ; preds = %15
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %20 = load ptr, ptr %19, align 8, !tbaa !18
  %21 = load i64, ptr %4, align 8, !tbaa !15
  %22 = and i64 %21, 4294967295
  %23 = getelementptr inbounds nuw %struct.NmsSlot, ptr %20, i64 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 32
  store i32 %1, ptr %24, align 8, !tbaa !44
  store i64 %21, ptr %2, align 8, !tbaa !15
  br label %25

25:                                               ; preds = %15, %18
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  br label %26

26:                                               ; preds = %12, %8, %3, %25
  %27 = phi i32 [ 6, %3 ], [ %16, %25 ], [ 5, %8 ], [ 1, %12 ]
  ret i32 %27
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define dso_local range(i32 0, 7) i32 @nms_bind_records(ptr noundef captures(address_is_null) %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #6 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %69, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %7 = load i32, ptr %6, align 8, !tbaa !16
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %69

9:                                                ; preds = %5
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %11 = load i32, ptr %10, align 4, !tbaa !49
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %69

13:                                               ; preds = %9
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %15 = load i32, ptr %14, align 4, !tbaa !40
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %69

17:                                               ; preds = %13
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !17
  %20 = icmp eq i32 %19, 0
  br i1 %20, label %21, label %69

21:                                               ; preds = %17
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %23 = load i64, ptr %22, align 8, !tbaa !50
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %69

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %27 = load i64, ptr %26, align 8, !tbaa !30
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %29, label %69

29:                                               ; preds = %25
  %30 = icmp eq i32 %2, 0
  %31 = icmp ne ptr %1, null
  %32 = or i1 %31, %30
  br i1 %32, label %33, label %69

33:                                               ; preds = %29
  %34 = icmp ugt i32 %2, 256
  br i1 %34, label %69, label %35

35:                                               ; preds = %33
  br i1 %30, label %67, label %36

36:                                               ; preds = %35
  %37 = zext nneg i32 %2 to i64
  %38 = load i32, ptr %1, align 4, !tbaa !51
  %39 = icmp ugt i32 %38, 255
  br i1 %39, label %69, label %40

40:                                               ; preds = %36
  %41 = getelementptr inbounds nuw i8, ptr %1, i64 4
  %42 = load i32, ptr %41, align 4, !tbaa !42
  %43 = icmp ugt i32 %42, 65535
  br i1 %43, label %69, label %44

44:                                               ; preds = %40
  %45 = icmp eq i32 %2, 1
  br i1 %45, label %67, label %46

46:                                               ; preds = %44, %63
  %47 = phi i64 [ %65, %63 ], [ 1, %44 ]
  %48 = phi i32 [ %64, %63 ], [ %42, %44 ]
  %49 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %1, i64 %47
  %50 = load i32, ptr %49, align 4, !tbaa !51
  %51 = icmp ugt i32 %50, 255
  br i1 %51, label %69, label %52

52:                                               ; preds = %46
  %53 = getelementptr i8, ptr %49, i64 -8
  %54 = load i32, ptr %53, align 4, !tbaa !51
  %55 = icmp ugt i32 %50, %54
  br i1 %55, label %56, label %69

56:                                               ; preds = %52
  %57 = getelementptr inbounds nuw i8, ptr %49, i64 4
  %58 = load i32, ptr %57, align 4, !tbaa !42
  %59 = icmp ugt i32 %58, 65535
  %60 = sub i32 65536, %48
  %61 = icmp ugt i32 %58, %60
  %62 = select i1 %59, i1 true, i1 %61
  br i1 %62, label %69, label %63

63:                                               ; preds = %56
  %64 = add i32 %58, %48
  %65 = add nuw nsw i64 %47, 1
  %66 = icmp eq i64 %65, %37
  br i1 %66, label %67, label %46, !llvm.loop !52

67:                                               ; preds = %63, %44, %35
  store ptr %1, ptr %0, align 8, !tbaa !8
  %68 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i32 %2, ptr %68, align 8, !tbaa !41
  store i32 1, ptr %14, align 4, !tbaa !40
  br label %69

69:                                               ; preds = %56, %52, %46, %36, %40, %67, %33, %13, %17, %21, %25, %29, %9, %5, %3
  %70 = phi i32 [ 6, %3 ], [ 5, %5 ], [ 4, %9 ], [ 6, %13 ], [ 1, %33 ], [ 6, %29 ], [ 6, %25 ], [ 6, %21 ], [ 6, %17 ], [ 0, %67 ], [ 1, %36 ], [ 1, %40 ], [ 1, %46 ], [ 1, %52 ], [ 1, %56 ]
  ret i32 %70
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_record_create(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp ne ptr %0, null
  %8 = icmp ne ptr %4, null
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %115

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !16
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %115

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %16 = load i32, ptr %15, align 4, !tbaa !40
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %115, label %18

18:                                               ; preds = %14
  %19 = load ptr, ptr %0, align 8, !tbaa !8
  %20 = icmp eq ptr %19, null
  br i1 %20, label %115, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %23 = load i32, ptr %22, align 8, !tbaa !41
  %24 = icmp ult i32 %1, %23
  br i1 %24, label %25, label %115

25:                                               ; preds = %21
  %26 = zext i32 %1 to i64
  %27 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %19, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 4
  %29 = load i32, ptr %28, align 4, !tbaa !42
  %30 = icmp eq i32 %3, %29
  br i1 %30, label %31, label %115

31:                                               ; preds = %25
  %32 = icmp eq i32 %3, 0
  %33 = icmp ne ptr %2, null
  %34 = or i1 %33, %32
  br i1 %34, label %35, label %115

35:                                               ; preds = %31
  %36 = zext i32 %3 to i64
  %37 = shl nuw nsw i64 %36, 4
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %39 = load i64, ptr %38, align 8, !tbaa !30
  %40 = xor i64 %39, -1
  %41 = icmp ugt i64 %37, %40
  br i1 %41, label %115, label %42

42:                                               ; preds = %35
  br i1 %32, label %75, label %46

43:                                               ; preds = %46
  %44 = add nuw nsw i64 %47, 1
  %45 = icmp eq i64 %44, %36
  br i1 %45, label %56, label %46, !llvm.loop !54

46:                                               ; preds = %42, %43
  %47 = phi i64 [ %44, %43 ], [ 0, %42 ]
  %48 = getelementptr inbounds nuw %struct.NmsValue, ptr %2, i64 %47
  %49 = load i64, ptr %48, align 8
  %50 = insertvalue [2 x i64] poison, i64 %49, 0
  %51 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %52 = load i64, ptr %51, align 8
  %53 = insertvalue [2 x i64] %50, i64 %52, 1
  %54 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %53) #23
  %55 = icmp eq i32 %54, 0
  br i1 %55, label %43, label %115

56:                                               ; preds = %43
  %57 = tail call noalias ptr @malloc(i64 noundef %37) #22
  %58 = icmp eq ptr %57, null
  br i1 %58, label %115, label %59

59:                                               ; preds = %56, %70
  %60 = phi i64 [ %71, %70 ], [ 0, %56 ]
  %61 = getelementptr inbounds nuw %struct.NmsValue, ptr %57, i64 %60
  %62 = getelementptr inbounds nuw %struct.NmsValue, ptr %2, i64 %60
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %61, ptr noundef nonnull align 8 dereferenceable(16) %62, i64 16, i1 false), !tbaa.struct !55
  %63 = load i64, ptr %61, align 8
  %64 = insertvalue [2 x i64] poison, i64 %63, 0
  %65 = getelementptr inbounds nuw i8, ptr %61, i64 8
  %66 = load i64, ptr %65, align 8
  %67 = insertvalue [2 x i64] %64, i64 %66, 1
  %68 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %67) #23
  %69 = icmp eq i32 %68, 0
  br i1 %69, label %70, label %73

70:                                               ; preds = %59
  %71 = add nuw nsw i64 %60, 1
  %72 = icmp eq i64 %71, %36
  br i1 %72, label %75, label %59, !llvm.loop !56

73:                                               ; preds = %59
  %74 = trunc nuw i64 %60 to i32
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  br label %79

75:                                               ; preds = %70, %42
  %76 = phi ptr [ null, %42 ], [ %57, %70 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  %77 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef %76, i32 noundef %3, i32 noundef %3, i32 noundef 5, i64 noundef %37, ptr noundef %6) #23
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %106, label %79

79:                                               ; preds = %73, %75
  %80 = phi i32 [ %68, %73 ], [ %77, %75 ]
  %81 = phi i32 [ %74, %73 ], [ %3, %75 ]
  %82 = phi ptr [ %57, %73 ], [ %76, %75 ]
  %83 = icmp eq i32 %81, 0
  br i1 %83, label %103, label %84

84:                                               ; preds = %79
  %85 = zext i32 %81 to i64
  br label %86

86:                                               ; preds = %84, %101
  %87 = phi i64 [ %85, %84 ], [ %88, %101 ]
  %88 = add nsw i64 %87, -1
  %89 = getelementptr inbounds nuw %struct.NmsValue, ptr %82, i64 %88
  %90 = load i64, ptr %89, align 8
  %91 = insertvalue [2 x i64] poison, i64 %90, 0
  %92 = getelementptr inbounds nuw i8, ptr %89, i64 8
  %93 = load i64, ptr %92, align 8
  %94 = insertvalue [2 x i64] %91, i64 %93, 1
  %95 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %94) #23
  %96 = icmp eq i32 %95, 0
  br i1 %96, label %97, label %101

97:                                               ; preds = %86
  %98 = trunc i64 %93 to i32
  switch i32 %98, label %101 [
    i32 8, label %99
    i32 7, label %99
    i32 5, label %99
  ]

99:                                               ; preds = %97, %97, %97
  %100 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %90) #23
  br label %101

101:                                              ; preds = %86, %97, %99
  %102 = icmp eq i64 %88, 0
  br i1 %102, label %105, label %86, !llvm.loop !57

103:                                              ; preds = %79
  %104 = icmp eq ptr %82, null
  br i1 %104, label %113, label %105

105:                                              ; preds = %101, %103
  tail call void @free(ptr noundef nonnull %82) #22
  br label %113

106:                                              ; preds = %75
  %107 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %108 = load ptr, ptr %107, align 8, !tbaa !18
  %109 = load i64, ptr %6, align 8, !tbaa !15
  %110 = and i64 %109, 4294967295
  %111 = getelementptr inbounds nuw %struct.NmsSlot, ptr %108, i64 %110
  %112 = getelementptr inbounds nuw i8, ptr %111, i64 40
  store i32 %1, ptr %112, align 8, !tbaa !32
  store i64 %109, ptr %4, align 8, !tbaa !15
  br label %113

113:                                              ; preds = %105, %103, %106
  %114 = phi i32 [ %80, %105 ], [ %80, %103 ], [ 0, %106 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  br label %115

115:                                              ; preds = %46, %35, %56, %113, %31, %25, %14, %18, %21, %10, %5
  %116 = phi i32 [ 6, %5 ], [ 5, %10 ], [ 1, %14 ], [ 6, %31 ], [ 1, %25 ], [ 1, %21 ], [ 1, %18 ], [ 3, %56 ], [ 3, %35 ], [ %114, %113 ], [ %54, %46 ]
  ret i32 %116
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_record_identity(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #1 {
  %5 = icmp eq ptr %2, null
  %6 = icmp eq ptr %3, null
  %7 = or i1 %5, %6
  %8 = icmp eq ptr %0, null
  %9 = or i1 %8, %7
  br i1 %9, label %71, label %10

10:                                               ; preds = %4
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !16
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %71

14:                                               ; preds = %10
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp slt i64 %1, 0
  %17 = icmp ne i64 %15, 0
  %18 = and i1 %16, %17
  br i1 %18, label %19, label %71

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %21 = load i32, ptr %20, align 4, !tbaa !17
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %15, %22
  br i1 %23, label %71, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !18
  %27 = icmp eq ptr %26, null
  br i1 %27, label %71, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i64 %15
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !19
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %71, label %33

33:                                               ; preds = %28
  %34 = and i64 %1, 4294967295
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 28
  %37 = load i32, ptr %36, align 4, !tbaa !22
  %38 = icmp eq i32 %37, 5
  br i1 %38, label %39, label %71

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %41 = load i32, ptr %40, align 4, !tbaa !40
  %42 = icmp eq i32 %41, 0
  br i1 %42, label %71, label %43

43:                                               ; preds = %39
  %44 = load ptr, ptr %0, align 8, !tbaa !8
  %45 = icmp eq ptr %44, null
  br i1 %45, label %71, label %46

46:                                               ; preds = %43
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 40
  %48 = load i32, ptr %47, align 8, !tbaa !32
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %50 = load i32, ptr %49, align 8, !tbaa !41
  %51 = icmp ult i32 %48, %50
  br i1 %51, label %52, label %71

52:                                               ; preds = %46
  %53 = zext i32 %48 to i64
  %54 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %44, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 4
  %56 = load i32, ptr %55, align 4, !tbaa !42
  %57 = getelementptr inbounds nuw i8, ptr %35, i64 16
  %58 = load i32, ptr %57, align 8, !tbaa !33
  %59 = icmp eq i32 %58, %56
  br i1 %59, label %60, label %71

60:                                               ; preds = %52
  %61 = getelementptr inbounds nuw i8, ptr %35, i64 24
  %62 = load i32, ptr %61, align 8, !tbaa !37
  %63 = icmp eq i32 %62, %56
  br i1 %63, label %64, label %71

64:                                               ; preds = %60
  %65 = icmp eq i32 %56, 0
  br i1 %65, label %69, label %66

66:                                               ; preds = %64
  %67 = load ptr, ptr %35, align 8, !tbaa !23
  %68 = icmp eq ptr %67, null
  br i1 %68, label %71, label %69

69:                                               ; preds = %64, %66
  store i32 %48, ptr %2, align 4, !tbaa !4
  %70 = load i32, ptr %54, align 4, !tbaa !51
  store i32 %70, ptr %3, align 4, !tbaa !4
  br label %71

71:                                               ; preds = %66, %10, %28, %24, %19, %14, %52, %60, %43, %46, %33, %39, %69, %4
  %72 = phi i32 [ 6, %4 ], [ 0, %69 ], [ 6, %39 ], [ 6, %66 ], [ 5, %10 ], [ 6, %28 ], [ 6, %24 ], [ 6, %19 ], [ 6, %14 ], [ 6, %52 ], [ 6, %60 ], [ 6, %43 ], [ 6, %46 ], [ 1, %33 ]
  ret i32 %72
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 8) i32 @nms_record_get(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = icmp eq ptr %3, null
  %6 = icmp eq ptr %0, null
  %7 = or i1 %6, %5
  br i1 %7, label %82, label %8

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !16
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %82

12:                                               ; preds = %8
  %13 = and i64 %1, 9223372036854775807
  %14 = icmp slt i64 %1, 0
  %15 = icmp ne i64 %13, 0
  %16 = and i1 %14, %15
  br i1 %16, label %17, label %82

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !17
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %13, %20
  br i1 %21, label %82, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !18
  %25 = icmp eq ptr %24, null
  br i1 %25, label %82, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %13
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !19
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %82, label %31

31:                                               ; preds = %26
  %32 = and i64 %1, 4294967295
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !22
  %36 = icmp eq i32 %35, 5
  br i1 %36, label %37, label %82

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %39 = load i32, ptr %38, align 4, !tbaa !40
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %82, label %41

41:                                               ; preds = %37
  %42 = load ptr, ptr %0, align 8, !tbaa !8
  %43 = icmp eq ptr %42, null
  br i1 %43, label %82, label %44

44:                                               ; preds = %41
  %45 = getelementptr inbounds nuw i8, ptr %33, i64 40
  %46 = load i32, ptr %45, align 8, !tbaa !32
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %48 = load i32, ptr %47, align 8, !tbaa !41
  %49 = icmp ult i32 %46, %48
  br i1 %49, label %50, label %82

50:                                               ; preds = %44
  %51 = zext i32 %46 to i64
  %52 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %42, i64 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 4
  %54 = load i32, ptr %53, align 4, !tbaa !42
  %55 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %56 = load i32, ptr %55, align 8, !tbaa !33
  %57 = icmp eq i32 %56, %54
  br i1 %57, label %58, label %82

58:                                               ; preds = %50
  %59 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %60 = load i32, ptr %59, align 8, !tbaa !37
  %61 = icmp eq i32 %60, %54
  br i1 %61, label %62, label %82

62:                                               ; preds = %58
  %63 = icmp eq i32 %54, 0
  br i1 %63, label %67, label %64

64:                                               ; preds = %62
  %65 = load ptr, ptr %33, align 8, !tbaa !23
  %66 = icmp eq ptr %65, null
  br i1 %66, label %82, label %67

67:                                               ; preds = %62, %64
  %68 = zext i32 %54 to i64
  %69 = icmp ult i64 %2, %68
  br i1 %69, label %70, label %82

70:                                               ; preds = %67
  %71 = load ptr, ptr %33, align 8, !tbaa !23
  %72 = getelementptr inbounds nuw %struct.NmsValue, ptr %71, i64 %2
  %73 = load i64, ptr %72, align 8, !tbaa !15
  %74 = getelementptr inbounds nuw i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue [2 x i64] poison, i64 %73, 0
  %77 = insertvalue [2 x i64] %76, i64 %75, 1
  %78 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %77) #23
  %79 = icmp eq i32 %78, 0
  br i1 %79, label %80, label %82

80:                                               ; preds = %70
  store i64 %73, ptr %3, align 8, !tbaa !15
  %81 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i64 %75, ptr %81, align 8
  br label %82

82:                                               ; preds = %64, %8, %26, %22, %17, %12, %50, %58, %41, %44, %31, %37, %67, %80, %70, %4
  %83 = phi i32 [ 6, %4 ], [ 7, %67 ], [ %78, %70 ], [ 0, %80 ], [ 6, %37 ], [ 6, %64 ], [ 5, %8 ], [ 6, %26 ], [ 6, %22 ], [ 6, %17 ], [ 6, %12 ], [ 6, %50 ], [ 6, %58 ], [ 6, %41 ], [ 6, %44 ], [ 1, %31 ]
  ret i32 %83
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc [2 x i64] @slot_value(ptr noundef readonly captures(none) %0, i32 noundef %1) unnamed_addr #8 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 28
  %4 = load i32, ptr %3, align 4, !tbaa !22
  switch i32 %4, label %41 [
    i32 4, label %5
    i32 2, label %36
  ]

5:                                                ; preds = %2
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %7 = load i32, ptr %6, align 8, !tbaa !44
  %8 = and i32 %7, -3
  %9 = icmp eq i32 %8, 1
  %10 = icmp eq i32 %7, 2
  %11 = icmp eq i32 %7, 4
  %12 = or i1 %10, %11
  %13 = zext i1 %12 to i32
  %14 = select i1 %9, i32 8, i32 %13
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %33, label %16

16:                                               ; preds = %5
  %17 = zext nneg i32 %14 to i64
  %18 = zext i32 %1 to i64
  %19 = mul nuw nsw i64 %17, %18
  %20 = load ptr, ptr %0, align 8, !tbaa !23
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 %19
  br label %22

22:                                               ; preds = %22, %16
  %23 = phi i64 [ 0, %16 ], [ %31, %22 ]
  %24 = phi i64 [ 0, %16 ], [ %30, %22 ]
  %25 = getelementptr inbounds nuw i8, ptr %21, i64 %23
  %26 = load i8, ptr %25, align 1, !tbaa !38
  %27 = zext i8 %26 to i64
  %28 = shl nuw nsw i64 %23, 3
  %29 = shl nuw i64 %27, %28
  %30 = or i64 %29, %24
  %31 = add nuw nsw i64 %23, 1
  %32 = icmp eq i64 %31, %17
  br i1 %32, label %33, label %22, !llvm.loop !45

33:                                               ; preds = %22, %5
  %34 = phi i64 [ 0, %5 ], [ %30, %22 ]
  %35 = zext i32 %7 to i64
  br label %48

36:                                               ; preds = %2
  %37 = load ptr, ptr %0, align 8, !tbaa !23
  %38 = zext i32 %1 to i64
  %39 = getelementptr inbounds nuw i64, ptr %37, i64 %38
  %40 = load i64, ptr %39, align 8, !tbaa !15
  br label %48

41:                                               ; preds = %2
  %42 = load ptr, ptr %0, align 8, !tbaa !23
  %43 = zext i32 %1 to i64
  %44 = getelementptr inbounds nuw %struct.NmsValue, ptr %42, i64 %43
  %45 = load i64, ptr %44, align 8, !tbaa !15
  %46 = getelementptr inbounds nuw i8, ptr %44, i64 8
  %47 = load i64, ptr %46, align 8
  br label %48

48:                                               ; preds = %41, %36, %33
  %49 = phi i64 [ %34, %33 ], [ %40, %36 ], [ %45, %41 ]
  %50 = phi i64 [ %35, %33 ], [ 5, %36 ], [ %47, %41 ]
  %51 = insertvalue [2 x i64] poison, i64 %49, 0
  %52 = insertvalue [2 x i64] %51, i64 %50, 1
  ret [2 x i64] %52
}

; Function Attrs: nounwind
define dso_local range(i32 0, 8) i32 @nms_record_set(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3) local_unnamed_addr #3 {
  %5 = extractvalue [2 x i64] %3, 0
  %6 = extractvalue [2 x i64] %3, 1
  %7 = icmp eq ptr %0, null
  br i1 %7, label %87, label %8

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !16
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %87

12:                                               ; preds = %8
  %13 = and i64 %1, 9223372036854775807
  %14 = icmp slt i64 %1, 0
  %15 = icmp ne i64 %13, 0
  %16 = and i1 %14, %15
  br i1 %16, label %17, label %87

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !17
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %13, %20
  br i1 %21, label %87, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !18
  %25 = icmp eq ptr %24, null
  br i1 %25, label %87, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %13
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !19
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %87, label %31

31:                                               ; preds = %26
  %32 = and i64 %1, 4294967295
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !22
  %36 = icmp eq i32 %35, 5
  br i1 %36, label %37, label %87

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %39 = load i32, ptr %38, align 4, !tbaa !40
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %87, label %41

41:                                               ; preds = %37
  %42 = load ptr, ptr %0, align 8, !tbaa !8
  %43 = icmp eq ptr %42, null
  br i1 %43, label %87, label %44

44:                                               ; preds = %41
  %45 = getelementptr inbounds nuw i8, ptr %33, i64 40
  %46 = load i32, ptr %45, align 8, !tbaa !32
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %48 = load i32, ptr %47, align 8, !tbaa !41
  %49 = icmp ult i32 %46, %48
  br i1 %49, label %50, label %87

50:                                               ; preds = %44
  %51 = zext i32 %46 to i64
  %52 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %42, i64 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 4
  %54 = load i32, ptr %53, align 4, !tbaa !42
  %55 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %56 = load i32, ptr %55, align 8, !tbaa !33
  %57 = icmp eq i32 %56, %54
  br i1 %57, label %58, label %87

58:                                               ; preds = %50
  %59 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %60 = load i32, ptr %59, align 8, !tbaa !37
  %61 = icmp eq i32 %60, %54
  br i1 %61, label %62, label %87

62:                                               ; preds = %58
  %63 = icmp eq i32 %54, 0
  br i1 %63, label %67, label %64

64:                                               ; preds = %62
  %65 = load ptr, ptr %33, align 8, !tbaa !23
  %66 = icmp eq ptr %65, null
  br i1 %66, label %87, label %67

67:                                               ; preds = %62, %64
  %68 = zext i32 %54 to i64
  %69 = icmp ult i64 %2, %68
  br i1 %69, label %70, label %87

70:                                               ; preds = %67
  %71 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %3) #23
  %72 = icmp eq i32 %71, 0
  br i1 %72, label %73, label %87

73:                                               ; preds = %70
  %74 = load ptr, ptr %33, align 8, !tbaa !23
  %75 = getelementptr inbounds nuw %struct.NmsValue, ptr %74, i64 %2
  %76 = load i64, ptr %75, align 8, !tbaa !15
  %77 = getelementptr inbounds nuw i8, ptr %75, i64 8
  %78 = load i64, ptr %77, align 8
  store i64 %5, ptr %75, align 8, !tbaa !15
  store i64 %6, ptr %77, align 8
  %79 = insertvalue [2 x i64] poison, i64 %76, 0
  %80 = insertvalue [2 x i64] %79, i64 %78, 1
  %81 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %80) #23
  %82 = icmp eq i32 %81, 0
  br i1 %82, label %83, label %87

83:                                               ; preds = %73
  %84 = trunc i64 %78 to i32
  switch i32 %84, label %87 [
    i32 8, label %85
    i32 7, label %85
    i32 5, label %85
  ]

85:                                               ; preds = %83, %83, %83
  %86 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %76) #23
  br label %87

87:                                               ; preds = %64, %4, %8, %26, %22, %17, %12, %50, %58, %41, %44, %31, %37, %85, %83, %73, %67, %70
  %88 = phi i32 [ 0, %83 ], [ %71, %70 ], [ 7, %67 ], [ %81, %73 ], [ %86, %85 ], [ 6, %37 ], [ 6, %4 ], [ 5, %8 ], [ 6, %26 ], [ 6, %22 ], [ 6, %17 ], [ 6, %12 ], [ 6, %50 ], [ 6, %58 ], [ 6, %41 ], [ 6, %44 ], [ 1, %31 ], [ 6, %64 ]
  ret i32 %88
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_value_array_create(ptr noundef captures(address_is_null) %0, ptr noundef writeonly captures(address_is_null) %1) local_unnamed_addr #3 {
  %3 = icmp ne ptr %0, null
  %4 = icmp ne ptr %1, null
  %5 = and i1 %3, %4
  br i1 %5, label %6, label %12

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !16
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 3, i64 noundef 0, ptr noundef %1) #23
  br label %12

12:                                               ; preds = %6, %2, %10
  %13 = phi i32 [ 6, %2 ], [ %11, %10 ], [ 5, %6 ]
  ret i32 %13
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_value_array_append(ptr noundef captures(address_is_null) %0, i64 noundef %1, [2 x i64] %2) local_unnamed_addr #3 {
  %4 = tail call fastcc i32 @value_array_write(ptr noundef %0, i64 noundef %1, i64 noundef 0, [2 x i64] %2, i32 noundef 1) #23
  ret i32 %4
}

; Function Attrs: nounwind
define internal fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3, i32 noundef range(i32 0, 2) %4) unnamed_addr #3 {
  %6 = alloca double, align 8
  %7 = alloca i8, align 8
  %8 = alloca i8, align 4
  %9 = alloca i8, align 4
  %10 = alloca i8, align 4
  %11 = alloca i8, align 4
  %12 = alloca i8, align 4
  %13 = alloca i8, align 4
  %14 = alloca i8, align 4
  %15 = extractvalue [2 x i64] %3, 0
  %16 = extractvalue [2 x i64] %3, 1
  %17 = icmp sgt i64 %1, -1
  %18 = icmp eq ptr %0, null
  br i1 %17, label %19, label %41

19:                                               ; preds = %5
  br i1 %18, label %472, label %20

20:                                               ; preds = %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %22 = load i32, ptr %21, align 8, !tbaa !16
  %23 = icmp eq i32 %22, 0
  br i1 %23, label %24, label %472

24:                                               ; preds = %20
  %25 = icmp eq i64 %1, 0
  br i1 %25, label %472, label %26

26:                                               ; preds = %24
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %28 = load i32, ptr %27, align 8, !tbaa !13
  %29 = zext i32 %28 to i64
  %30 = icmp samesign ugt i64 %1, %29
  br i1 %30, label %472, label %31

31:                                               ; preds = %26
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %33 = load ptr, ptr %32, align 8, !tbaa !12
  %34 = icmp eq ptr %33, null
  br i1 %34, label %472, label %35

35:                                               ; preds = %31
  %36 = getelementptr %struct.NmsView, ptr %33, i64 %1
  %37 = getelementptr i8, ptr %36, i64 -16
  %38 = load ptr, ptr %37, align 8, !tbaa !24
  %39 = icmp eq ptr %38, null
  %40 = select i1 %39, i32 6, i32 1
  br label %472

41:                                               ; preds = %5
  br i1 %18, label %472, label %42

42:                                               ; preds = %41
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %44 = load i32, ptr %43, align 8, !tbaa !16
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %46, label %472

46:                                               ; preds = %42
  %47 = and i64 %1, 9223372036854775807
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %472, label %49

49:                                               ; preds = %46
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %51 = load i32, ptr %50, align 4, !tbaa !17
  %52 = zext i32 %51 to i64
  %53 = icmp samesign ugt i64 %47, %52
  br i1 %53, label %472, label %54

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %56 = load ptr, ptr %55, align 8, !tbaa !18
  %57 = icmp eq ptr %56, null
  br i1 %57, label %472, label %58

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw %struct.NmsSlot, ptr %56, i64 %47
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 8
  %61 = load i64, ptr %60, align 8, !tbaa !19
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %472, label %63

63:                                               ; preds = %58
  %64 = and i64 %1, 4294967295
  %65 = getelementptr inbounds nuw %struct.NmsSlot, ptr %56, i64 %64
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 28
  %67 = load i32, ptr %66, align 4, !tbaa !22
  %68 = add i32 %67, -2
  %69 = icmp ult i32 %68, 3
  br i1 %69, label %70, label %472

70:                                               ; preds = %63
  %71 = icmp eq i32 %67, 4
  br i1 %71, label %72, label %321

72:                                               ; preds = %70
  call void @llvm.lifetime.start.p0(ptr nonnull %7)
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  call void @llvm.lifetime.start.p0(ptr nonnull %9)
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  call void @llvm.lifetime.start.p0(ptr nonnull %11)
  call void @llvm.lifetime.start.p0(ptr nonnull %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %13)
  call void @llvm.lifetime.start.p0(ptr nonnull %14)
  %73 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %74 = load i32, ptr %73, align 8, !tbaa !44
  %75 = trunc i64 %16 to i32
  %76 = icmp eq i32 %75, 2
  %77 = icmp ugt i64 %15, 255
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %319, label %79

79:                                               ; preds = %72
  %80 = icmp eq i32 %75, 4
  %81 = icmp ugt i64 %15, 1
  %82 = select i1 %80, i1 %81, i1 false
  br i1 %82, label %319, label %83

83:                                               ; preds = %79
  %84 = icmp eq i32 %74, %75
  %85 = add i32 %74, -1
  %86 = icmp ult i32 %85, 4
  %87 = and i1 %84, %86
  br i1 %87, label %88, label %104

88:                                               ; preds = %83
  %89 = trunc i64 %15 to i8
  store i8 %89, ptr %7, align 8, !tbaa !15
  %90 = lshr i64 %15, 8
  %91 = trunc i64 %90 to i8
  store i8 %91, ptr %8, align 4, !tbaa !15
  %92 = lshr i64 %15, 16
  %93 = trunc i64 %92 to i8
  store i8 %93, ptr %9, align 4, !tbaa !15
  %94 = lshr i64 %15, 24
  %95 = trunc i64 %94 to i8
  store i8 %95, ptr %10, align 4, !tbaa !15
  %96 = lshr i64 %15, 32
  %97 = trunc i64 %96 to i8
  store i8 %97, ptr %11, align 4, !tbaa !15
  %98 = lshr i64 %15, 40
  %99 = trunc i64 %98 to i8
  store i8 %99, ptr %12, align 4, !tbaa !15
  %100 = lshr i64 %15, 48
  %101 = trunc i64 %100 to i8
  store i8 %101, ptr %13, align 4, !tbaa !15
  %102 = lshr i64 %15, 56
  %103 = trunc nuw i64 %102 to i8
  store i8 %103, ptr %14, align 4, !tbaa !15
  br label %149

104:                                              ; preds = %83
  %105 = icmp eq i32 %74, 1
  %106 = and i1 %76, %105
  br i1 %106, label %107, label %123

107:                                              ; preds = %104
  %108 = trunc i64 %15 to i8
  store i8 %108, ptr %7, align 8, !tbaa !15
  %109 = lshr i64 %15, 8
  %110 = trunc i64 %109 to i8
  store i8 %110, ptr %8, align 4, !tbaa !15
  %111 = lshr i64 %15, 16
  %112 = trunc i64 %111 to i8
  store i8 %112, ptr %9, align 4, !tbaa !15
  %113 = lshr i64 %15, 24
  %114 = trunc i64 %113 to i8
  store i8 %114, ptr %10, align 4, !tbaa !15
  %115 = lshr i64 %15, 32
  %116 = trunc i64 %115 to i8
  store i8 %116, ptr %11, align 4, !tbaa !15
  %117 = lshr i64 %15, 40
  %118 = trunc i64 %117 to i8
  store i8 %118, ptr %12, align 4, !tbaa !15
  %119 = lshr i64 %15, 48
  %120 = trunc i64 %119 to i8
  store i8 %120, ptr %13, align 4, !tbaa !15
  %121 = lshr i64 %15, 56
  %122 = trunc nuw i64 %121 to i8
  store i8 %122, ptr %14, align 4, !tbaa !15
  br label %149

123:                                              ; preds = %104
  %124 = icmp eq i32 %74, 2
  %125 = icmp eq i32 %75, 1
  %126 = and i1 %125, %124
  br i1 %126, label %127, label %129

127:                                              ; preds = %123
  %128 = trunc i64 %15 to i8
  store i8 %128, ptr %7, align 8, !tbaa !15
  store i8 0, ptr %8, align 4, !tbaa !15
  store i8 0, ptr %9, align 4, !tbaa !15
  store i8 0, ptr %10, align 4, !tbaa !15
  store i8 0, ptr %11, align 4, !tbaa !15
  store i8 0, ptr %12, align 4, !tbaa !15
  store i8 0, ptr %13, align 4, !tbaa !15
  store i8 0, ptr %14, align 4, !tbaa !15
  br label %149

129:                                              ; preds = %123
  %130 = icmp eq i32 %74, 3
  %131 = and i1 %125, %130
  br i1 %131, label %132, label %319

132:                                              ; preds = %129
  call void @llvm.lifetime.start.p0(ptr nonnull %6)
  %133 = sitofp i64 %15 to double
  store double %133, ptr %6, align 8, !tbaa !58
  %134 = load volatile i8, ptr %6, align 8, !tbaa !38
  store volatile i8 %134, ptr %7, align 8, !tbaa !38
  %135 = getelementptr inbounds nuw i8, ptr %6, i64 1
  %136 = load volatile i8, ptr %135, align 1, !tbaa !38
  store volatile i8 %136, ptr %8, align 4, !tbaa !38
  %137 = getelementptr inbounds nuw i8, ptr %6, i64 2
  %138 = load volatile i8, ptr %137, align 2, !tbaa !38
  store volatile i8 %138, ptr %9, align 4, !tbaa !38
  %139 = getelementptr inbounds nuw i8, ptr %6, i64 3
  %140 = load volatile i8, ptr %139, align 1, !tbaa !38
  store volatile i8 %140, ptr %10, align 4, !tbaa !38
  %141 = getelementptr inbounds nuw i8, ptr %6, i64 4
  %142 = load volatile i8, ptr %141, align 4, !tbaa !38
  store volatile i8 %142, ptr %11, align 4, !tbaa !38
  %143 = getelementptr inbounds nuw i8, ptr %6, i64 5
  %144 = load volatile i8, ptr %143, align 1, !tbaa !38
  store volatile i8 %144, ptr %12, align 4, !tbaa !38
  %145 = getelementptr inbounds nuw i8, ptr %6, i64 6
  %146 = load volatile i8, ptr %145, align 2, !tbaa !38
  store volatile i8 %146, ptr %13, align 4, !tbaa !38
  %147 = getelementptr inbounds nuw i8, ptr %6, i64 7
  %148 = load volatile i8, ptr %147, align 1, !tbaa !38
  store volatile i8 %148, ptr %14, align 4, !tbaa !38
  call void @llvm.lifetime.end.p0(ptr nonnull %6)
  br label %149

149:                                              ; preds = %132, %127, %107, %88
  %150 = phi i8 [ %103, %88 ], [ %122, %107 ], [ 0, %127 ], [ %148, %132 ]
  %151 = phi i8 [ %101, %88 ], [ %120, %107 ], [ 0, %127 ], [ %146, %132 ]
  %152 = phi i8 [ %99, %88 ], [ %118, %107 ], [ 0, %127 ], [ %144, %132 ]
  %153 = phi i8 [ %97, %88 ], [ %116, %107 ], [ 0, %127 ], [ %142, %132 ]
  %154 = phi i8 [ %95, %88 ], [ %114, %107 ], [ 0, %127 ], [ %140, %132 ]
  %155 = phi i8 [ %93, %88 ], [ %112, %107 ], [ 0, %127 ], [ %138, %132 ]
  %156 = phi i8 [ %91, %88 ], [ %110, %107 ], [ 0, %127 ], [ %136, %132 ]
  %157 = phi i8 [ %89, %88 ], [ %108, %107 ], [ %128, %127 ], [ %134, %132 ]
  %158 = icmp eq i32 %4, 0
  %159 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %160 = load i32, ptr %159, align 8, !tbaa !33
  br i1 %158, label %161, label %164

161:                                              ; preds = %149
  %162 = zext i32 %160 to i64
  %163 = icmp ult i64 %2, %162
  br i1 %163, label %166, label %319

164:                                              ; preds = %149
  %165 = icmp eq i32 %160, -1
  br i1 %165, label %319, label %166

166:                                              ; preds = %164, %161
  %167 = and i32 %74, -3
  %168 = icmp eq i32 %167, 1
  %169 = icmp eq i32 %74, 2
  %170 = icmp eq i32 %74, 4
  %171 = or i1 %169, %170
  %172 = zext i1 %171 to i32
  %173 = select i1 %168, i32 8, i32 %172
  %174 = icmp eq i32 %173, 0
  br i1 %174, label %319, label %175

175:                                              ; preds = %166
  br i1 %158, label %283, label %176

176:                                              ; preds = %175
  %177 = getelementptr inbounds nuw i8, ptr %65, i64 24
  %178 = load i32, ptr %177, align 8, !tbaa !37
  %179 = icmp eq i32 %160, %178
  br i1 %179, label %182, label %180

180:                                              ; preds = %176
  %181 = zext i32 %160 to i64
  br label %235

182:                                              ; preds = %176
  %183 = getelementptr inbounds nuw i8, ptr %65, i64 36
  %184 = load i32, ptr %183, align 4, !tbaa !48
  %185 = icmp eq i32 %160, 0
  %186 = zext i32 %160 to i64
  %187 = shl nuw nsw i64 %186, 1
  %188 = select i1 %185, i64 4, i64 %187
  %189 = icmp eq i32 %184, 0
  br i1 %189, label %197, label %190

190:                                              ; preds = %182
  %191 = icmp samesign ugt i64 %188, %186
  br i1 %191, label %192, label %319

192:                                              ; preds = %190
  %193 = tail call range(i32 0, 33) i32 @llvm.cttz.i32(i32 %173, i1 true)
  %194 = lshr i32 -1, %193
  %195 = zext i32 %194 to i64
  %196 = icmp samesign ugt i64 %188, %195
  br i1 %196, label %319, label %199

197:                                              ; preds = %182
  %198 = tail call i64 @llvm.umin.i64(i64 %188, i64 4294967295)
  br label %199

199:                                              ; preds = %197, %192
  %200 = phi i64 [ %188, %192 ], [ %198, %197 ]
  %201 = trunc nuw i64 %200 to i32
  %202 = zext nneg i32 %173 to i64
  %203 = sub i32 %201, %160
  %204 = zext i32 %203 to i64
  %205 = mul nuw nsw i64 %204, %202
  %206 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %207 = load i64, ptr %206, align 8, !tbaa !30
  %208 = xor i64 %207, -1
  %209 = icmp ugt i64 %205, %208
  br i1 %209, label %319, label %210

210:                                              ; preds = %199
  %211 = mul nuw nsw i64 %200, %202
  %212 = tail call noalias ptr @malloc(i64 noundef %211) #22
  %213 = icmp eq ptr %212, null
  br i1 %213, label %319, label %214

214:                                              ; preds = %210
  %215 = load ptr, ptr %65, align 8, !tbaa !23
  %216 = load i32, ptr %159, align 8, !tbaa !33
  %217 = zext i32 %216 to i64
  %218 = mul nuw nsw i64 %217, %202
  %219 = icmp eq i32 %216, 0
  br i1 %219, label %230, label %220

220:                                              ; preds = %214, %220
  %221 = phi i64 [ %225, %220 ], [ 0, %214 ]
  %222 = getelementptr inbounds nuw i8, ptr %215, i64 %221
  %223 = load volatile i8, ptr %222, align 1, !tbaa !38
  %224 = getelementptr inbounds nuw i8, ptr %212, i64 %221
  store volatile i8 %223, ptr %224, align 1, !tbaa !38
  %225 = add nuw nsw i64 %221, 1
  %226 = icmp eq i64 %225, %218
  br i1 %226, label %227, label %220, !llvm.loop !39

227:                                              ; preds = %220
  store ptr %212, ptr %65, align 8, !tbaa !23
  store i32 %201, ptr %177, align 8, !tbaa !37
  %228 = load i64, ptr %206, align 8, !tbaa !30
  %229 = add i64 %228, %205
  store i64 %229, ptr %206, align 8, !tbaa !30
  br label %234

230:                                              ; preds = %214
  store ptr %212, ptr %65, align 8, !tbaa !23
  store i32 %201, ptr %177, align 8, !tbaa !37
  %231 = load i64, ptr %206, align 8, !tbaa !30
  %232 = add i64 %231, %205
  store i64 %232, ptr %206, align 8, !tbaa !30
  %233 = icmp eq ptr %215, null
  br i1 %233, label %235, label %234

234:                                              ; preds = %230, %227
  tail call void @free(ptr noundef nonnull %215) #22
  br label %235

235:                                              ; preds = %234, %230, %180
  %236 = phi i64 [ %181, %180 ], [ %186, %230 ], [ %186, %234 ]
  %237 = zext i8 %150 to i64
  %238 = shl nuw i64 %237, 56
  %239 = zext i8 %151 to i64
  %240 = shl nuw nsw i64 %239, 48
  %241 = zext i8 %152 to i64
  %242 = shl nuw nsw i64 %241, 40
  %243 = zext i8 %153 to i64
  %244 = shl nuw nsw i64 %243, 32
  %245 = zext i8 %154 to i64
  %246 = shl nuw nsw i64 %245, 24
  %247 = zext i8 %155 to i64
  %248 = shl nuw nsw i64 %247, 16
  %249 = zext i8 %156 to i64
  %250 = shl nuw nsw i64 %249, 8
  %251 = zext i8 %157 to i64
  %252 = or disjoint i64 %250, %251
  %253 = or disjoint i64 %252, %248
  %254 = or disjoint i64 %253, %246
  %255 = or disjoint i64 %254, %244
  %256 = or disjoint i64 %255, %242
  %257 = or disjoint i64 %240, %238
  %258 = or i64 %257, %256
  %259 = load i32, ptr %73, align 8, !tbaa !44
  %260 = and i32 %259, -3
  %261 = icmp eq i32 %260, 1
  %262 = icmp eq i32 %259, 2
  %263 = icmp eq i32 %259, 4
  %264 = or i1 %262, %263
  %265 = zext i1 %264 to i32
  %266 = select i1 %261, i32 8, i32 %265
  %267 = zext nneg i32 %266 to i64
  %268 = mul nuw nsw i64 %236, %267
  %269 = icmp eq i32 %266, 0
  br i1 %269, label %280, label %270

270:                                              ; preds = %235, %270
  %271 = phi i64 [ %278, %270 ], [ 0, %235 ]
  %272 = shl nuw nsw i64 %271, 3
  %273 = lshr i64 %258, %272
  %274 = trunc i64 %273 to i8
  %275 = load ptr, ptr %65, align 8, !tbaa !23
  %276 = getelementptr inbounds nuw i8, ptr %275, i64 %268
  %277 = getelementptr inbounds nuw i8, ptr %276, i64 %271
  store i8 %274, ptr %277, align 1, !tbaa !38
  %278 = add nuw nsw i64 %271, 1
  %279 = icmp eq i64 %278, %267
  br i1 %279, label %280, label %270, !llvm.loop !60

280:                                              ; preds = %270, %235
  %281 = load i32, ptr %159, align 8, !tbaa !33
  %282 = add i32 %281, 1
  store i32 %282, ptr %159, align 8, !tbaa !33
  br label %319

283:                                              ; preds = %175
  %284 = zext i8 %150 to i64
  %285 = shl nuw i64 %284, 56
  %286 = zext i8 %151 to i64
  %287 = shl nuw nsw i64 %286, 48
  %288 = zext i8 %152 to i64
  %289 = shl nuw nsw i64 %288, 40
  %290 = zext i8 %153 to i64
  %291 = shl nuw nsw i64 %290, 32
  %292 = zext i8 %154 to i64
  %293 = shl nuw nsw i64 %292, 24
  %294 = zext i8 %155 to i64
  %295 = shl nuw nsw i64 %294, 16
  %296 = zext i8 %156 to i64
  %297 = shl nuw nsw i64 %296, 8
  %298 = zext i8 %157 to i64
  %299 = or disjoint i64 %297, %298
  %300 = or disjoint i64 %299, %295
  %301 = or disjoint i64 %300, %293
  %302 = or disjoint i64 %301, %291
  %303 = or disjoint i64 %302, %289
  %304 = or disjoint i64 %287, %285
  %305 = or i64 %304, %303
  %306 = and i64 %2, 4294967295
  %307 = zext nneg i32 %173 to i64
  %308 = mul nuw nsw i64 %306, %307
  br label %309

309:                                              ; preds = %309, %283
  %310 = phi i64 [ %317, %309 ], [ 0, %283 ]
  %311 = shl nuw nsw i64 %310, 3
  %312 = lshr i64 %305, %311
  %313 = trunc i64 %312 to i8
  %314 = load ptr, ptr %65, align 8, !tbaa !23
  %315 = getelementptr inbounds nuw i8, ptr %314, i64 %308
  %316 = getelementptr inbounds nuw i8, ptr %315, i64 %310
  store i8 %313, ptr %316, align 1, !tbaa !38
  %317 = add nuw nsw i64 %310, 1
  %318 = icmp eq i64 %317, %307
  br i1 %318, label %319, label %309, !llvm.loop !60

319:                                              ; preds = %309, %72, %79, %129, %161, %164, %166, %190, %192, %199, %210, %280
  %320 = phi i32 [ 1, %129 ], [ 6, %161 ], [ 3, %164 ], [ 6, %166 ], [ 3, %190 ], [ 1, %79 ], [ 0, %280 ], [ 1, %72 ], [ 3, %199 ], [ 3, %210 ], [ 3, %192 ], [ 0, %309 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7)
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  br label %472

321:                                              ; preds = %70
  %322 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %3) #23
  %323 = icmp eq i32 %322, 0
  br i1 %323, label %324, label %472

324:                                              ; preds = %321
  %325 = icmp eq i32 %4, 0
  %326 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %327 = load i32, ptr %326, align 8, !tbaa !33
  br i1 %325, label %328, label %331

328:                                              ; preds = %324
  %329 = zext i32 %327 to i64
  %330 = icmp ult i64 %2, %329
  br i1 %330, label %333, label %472

331:                                              ; preds = %324
  %332 = icmp eq i32 %327, -1
  br i1 %332, label %472, label %337

333:                                              ; preds = %328
  %334 = trunc nuw i64 %2 to i32
  %335 = getelementptr inbounds nuw i8, ptr %65, i64 24
  %336 = load i32, ptr %335, align 8, !tbaa !37
  br label %358

337:                                              ; preds = %331
  %338 = getelementptr inbounds nuw i8, ptr %65, i64 24
  %339 = load i32, ptr %338, align 8, !tbaa !37
  %340 = icmp eq i32 %327, %339
  br i1 %340, label %341, label %358

341:                                              ; preds = %337
  %342 = getelementptr inbounds nuw i8, ptr %65, i64 36
  %343 = load i32, ptr %342, align 4, !tbaa !48
  %344 = icmp eq i32 %327, 0
  %345 = zext i32 %327 to i64
  %346 = shl nuw nsw i64 %345, 1
  %347 = select i1 %344, i64 4, i64 %346
  %348 = icmp eq i32 %343, 0
  br i1 %348, label %353, label %349

349:                                              ; preds = %341
  %350 = icmp samesign ule i64 %347, %345
  %351 = icmp samesign ugt i64 %347, 268435455
  %352 = select i1 %350, i1 true, i1 %351
  br i1 %352, label %472, label %355

353:                                              ; preds = %341
  %354 = tail call i64 @llvm.umin.i64(i64 %347, i64 4294967295)
  br label %355

355:                                              ; preds = %349, %353
  %356 = phi i64 [ %347, %349 ], [ %354, %353 ]
  %357 = trunc nuw i64 %356 to i32
  br label %358

358:                                              ; preds = %355, %333, %337
  %359 = phi i32 [ %336, %333 ], [ %327, %355 ], [ %339, %337 ]
  %360 = phi ptr [ %335, %333 ], [ %338, %355 ], [ %338, %337 ]
  %361 = phi i32 [ %334, %333 ], [ %327, %355 ], [ %327, %337 ]
  %362 = phi i32 [ %336, %333 ], [ %357, %355 ], [ %339, %337 ]
  %363 = zext i32 %362 to i64
  %364 = shl nuw nsw i64 %363, 4
  %365 = icmp eq i32 %67, 2
  %366 = zext i32 %359 to i64
  %367 = select i1 %365, i64 3, i64 4
  %368 = shl nuw nsw i64 %366, %367
  %369 = sub nsw i64 %364, %368
  %370 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %371 = load i64, ptr %370, align 8, !tbaa !30
  %372 = xor i64 %371, -1
  %373 = icmp ugt i64 %369, %372
  br i1 %373, label %472, label %374

374:                                              ; preds = %358
  %375 = load ptr, ptr %65, align 8, !tbaa !23
  %376 = icmp ne i32 %67, 2
  %377 = icmp eq i32 %362, %359
  %378 = and i1 %376, %377
  br i1 %378, label %438, label %379

379:                                              ; preds = %374
  %380 = tail call noalias ptr @malloc(i64 noundef %364) #22
  %381 = icmp eq ptr %380, null
  br i1 %381, label %472, label %382

382:                                              ; preds = %379
  %383 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %384 = load i32, ptr %383, align 8, !tbaa !33
  %385 = icmp eq i32 %384, 0
  br i1 %385, label %438, label %386

386:                                              ; preds = %382
  %387 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %388 = load i32, ptr %66, align 4, !tbaa !22
  %389 = zext i32 %384 to i64
  br label %390

390:                                              ; preds = %386, %432
  %391 = phi i64 [ 0, %386 ], [ %436, %432 ]
  %392 = getelementptr inbounds nuw %struct.NmsValue, ptr %380, i64 %391
  switch i32 %388, label %426 [
    i32 4, label %393
    i32 2, label %422
  ]

393:                                              ; preds = %390
  %394 = load i32, ptr %387, align 8, !tbaa !44
  %395 = and i32 %394, -3
  %396 = icmp eq i32 %395, 1
  %397 = icmp eq i32 %394, 2
  %398 = icmp eq i32 %394, 4
  %399 = or i1 %397, %398
  %400 = zext i1 %399 to i32
  %401 = select i1 %396, i32 8, i32 %400
  %402 = icmp eq i32 %401, 0
  br i1 %402, label %419, label %403

403:                                              ; preds = %393
  %404 = zext nneg i32 %401 to i64
  %405 = mul nuw nsw i64 %391, %404
  %406 = load ptr, ptr %65, align 8, !tbaa !23
  %407 = getelementptr inbounds nuw i8, ptr %406, i64 %405
  br label %408

408:                                              ; preds = %408, %403
  %409 = phi i64 [ 0, %403 ], [ %417, %408 ]
  %410 = phi i64 [ 0, %403 ], [ %416, %408 ]
  %411 = getelementptr inbounds nuw i8, ptr %407, i64 %409
  %412 = load i8, ptr %411, align 1, !tbaa !38
  %413 = zext i8 %412 to i64
  %414 = shl nuw nsw i64 %409, 3
  %415 = shl nuw i64 %413, %414
  %416 = or i64 %415, %410
  %417 = add nuw nsw i64 %409, 1
  %418 = icmp eq i64 %417, %404
  br i1 %418, label %419, label %408, !llvm.loop !45

419:                                              ; preds = %408, %393
  %420 = phi i64 [ 0, %393 ], [ %416, %408 ]
  %421 = zext i32 %394 to i64
  br label %432

422:                                              ; preds = %390
  %423 = load ptr, ptr %65, align 8, !tbaa !23
  %424 = getelementptr inbounds nuw i64, ptr %423, i64 %391
  %425 = load i64, ptr %424, align 8, !tbaa !15
  br label %432

426:                                              ; preds = %390
  %427 = load ptr, ptr %65, align 8, !tbaa !23
  %428 = getelementptr inbounds nuw %struct.NmsValue, ptr %427, i64 %391
  %429 = load i64, ptr %428, align 8, !tbaa !15
  %430 = getelementptr inbounds nuw i8, ptr %428, i64 8
  %431 = load i64, ptr %430, align 8
  br label %432

432:                                              ; preds = %419, %422, %426
  %433 = phi i64 [ %420, %419 ], [ %425, %422 ], [ %429, %426 ]
  %434 = phi i64 [ %421, %419 ], [ 5, %422 ], [ %431, %426 ]
  store i64 %433, ptr %392, align 8, !tbaa !15
  %435 = getelementptr inbounds nuw i8, ptr %392, i64 8
  store i64 %434, ptr %435, align 8
  %436 = add nuw nsw i64 %391, 1
  %437 = icmp samesign ult i64 %436, %389
  br i1 %437, label %390, label %438, !llvm.loop !61

438:                                              ; preds = %432, %382, %374
  %439 = phi ptr [ %375, %374 ], [ %380, %382 ], [ %380, %432 ]
  %440 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %3) #23
  %441 = icmp eq i32 %440, 0
  br i1 %441, label %446, label %442

442:                                              ; preds = %438
  %443 = icmp eq ptr %439, null
  %444 = select i1 %378, i1 true, i1 %443
  br i1 %444, label %472, label %445

445:                                              ; preds = %442
  tail call void @free(ptr noundef nonnull %439) #22
  br label %472

446:                                              ; preds = %438
  br i1 %325, label %447, label %451

447:                                              ; preds = %446
  %448 = tail call fastcc [2 x i64] @slot_value(ptr noundef nonnull %65, i32 noundef %361) #23
  %449 = extractvalue [2 x i64] %448, 0
  %450 = extractvalue [2 x i64] %448, 1
  br label %451

451:                                              ; preds = %447, %446
  %452 = phi i64 [ 0, %446 ], [ %449, %447 ]
  %453 = phi i64 [ 0, %446 ], [ %450, %447 ]
  br i1 %378, label %460, label %454

454:                                              ; preds = %451
  %455 = load ptr, ptr %65, align 8, !tbaa !23
  store ptr %439, ptr %65, align 8, !tbaa !23
  store i32 %362, ptr %360, align 8, !tbaa !37
  store i32 3, ptr %66, align 4, !tbaa !22
  %456 = load i64, ptr %370, align 8, !tbaa !30
  %457 = add i64 %456, %369
  store i64 %457, ptr %370, align 8, !tbaa !30
  %458 = icmp eq ptr %455, null
  br i1 %458, label %460, label %459

459:                                              ; preds = %454
  tail call void @free(ptr noundef nonnull %455) #22
  br label %460

460:                                              ; preds = %459, %454, %451
  %461 = zext i32 %361 to i64
  %462 = getelementptr inbounds nuw %struct.NmsValue, ptr %439, i64 %461
  store i64 %15, ptr %462, align 8, !tbaa !15
  %463 = getelementptr inbounds nuw i8, ptr %462, i64 8
  store i64 %16, ptr %463, align 8
  br i1 %325, label %468, label %464

464:                                              ; preds = %460
  %465 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %466 = load i32, ptr %465, align 8, !tbaa !33
  %467 = add i32 %466, 1
  store i32 %467, ptr %465, align 8, !tbaa !33
  br label %472

468:                                              ; preds = %460
  %469 = insertvalue [2 x i64] poison, i64 %452, 0
  %470 = insertvalue [2 x i64] %469, i64 %453, 1
  %471 = tail call i32 @nms_value_release(ptr noundef nonnull %0, [2 x i64] %470) #23
  br label %472

472:                                              ; preds = %349, %31, %24, %20, %26, %35, %19, %42, %58, %54, %49, %46, %41, %379, %442, %468, %358, %464, %445, %319, %321, %328, %331, %63
  %473 = phi i32 [ 1, %63 ], [ %320, %319 ], [ %322, %321 ], [ 6, %328 ], [ %440, %445 ], [ 3, %331 ], [ 6, %41 ], [ 3, %358 ], [ 3, %379 ], [ %440, %442 ], [ 0, %464 ], [ %471, %468 ], [ 3, %349 ], [ 6, %31 ], [ 6, %24 ], [ 5, %20 ], [ 6, %26 ], [ %40, %35 ], [ 6, %19 ], [ 5, %42 ], [ 6, %58 ], [ 6, %54 ], [ 6, %49 ], [ 6, %46 ]
  ret i32 %473
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_value_array_set(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @value_array_write(ptr noundef %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3, i32 noundef 0) #23
  ret i32 %5
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_value_array_get(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #9 {
  %5 = icmp eq ptr %3, null
  br i1 %5, label %117, label %6

6:                                                ; preds = %4
  %7 = icmp sgt i64 %1, -1
  %8 = icmp eq ptr %0, null
  br i1 %7, label %9, label %31

9:                                                ; preds = %6
  br i1 %8, label %117, label %10

10:                                               ; preds = %9
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !16
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %117

14:                                               ; preds = %10
  %15 = icmp eq i64 %1, 0
  br i1 %15, label %117, label %16

16:                                               ; preds = %14
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %18 = load i32, ptr %17, align 8, !tbaa !13
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %1, %19
  br i1 %20, label %117, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %23 = load ptr, ptr %22, align 8, !tbaa !12
  %24 = icmp eq ptr %23, null
  br i1 %24, label %117, label %25

25:                                               ; preds = %21
  %26 = getelementptr %struct.NmsView, ptr %23, i64 %1
  %27 = getelementptr i8, ptr %26, i64 -16
  %28 = load ptr, ptr %27, align 8, !tbaa !24
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %117

31:                                               ; preds = %6
  br i1 %8, label %117, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %34 = load i32, ptr %33, align 8, !tbaa !16
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %117

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %117, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %41 = load i32, ptr %40, align 4, !tbaa !17
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %37, %42
  br i1 %43, label %117, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %46 = load ptr, ptr %45, align 8, !tbaa !18
  %47 = icmp eq ptr %46, null
  br i1 %47, label %117, label %48

48:                                               ; preds = %44
  %49 = getelementptr inbounds nuw %struct.NmsSlot, ptr %46, i64 %37
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 8
  %51 = load i64, ptr %50, align 8, !tbaa !19
  %52 = icmp eq i64 %51, 0
  br i1 %52, label %117, label %53

53:                                               ; preds = %48
  %54 = and i64 %1, 4294967295
  %55 = getelementptr inbounds nuw %struct.NmsSlot, ptr %46, i64 %54
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 28
  %57 = load i32, ptr %56, align 4, !tbaa !22
  %58 = add i32 %57, -2
  %59 = icmp ult i32 %58, 3
  br i1 %59, label %60, label %117

60:                                               ; preds = %53
  %61 = getelementptr inbounds nuw i8, ptr %55, i64 16
  %62 = load i32, ptr %61, align 8, !tbaa !33
  %63 = zext i32 %62 to i64
  %64 = icmp ult i64 %2, %63
  br i1 %64, label %67, label %65

65:                                               ; preds = %60
  store i64 0, ptr %3, align 8, !tbaa !15
  %66 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store <2 x i32> zeroinitializer, ptr %66, align 8
  br label %117

67:                                               ; preds = %60
  switch i32 %57, label %102 [
    i32 4, label %68
    i32 2, label %98
  ]

68:                                               ; preds = %67
  %69 = getelementptr inbounds nuw i8, ptr %55, i64 32
  %70 = load i32, ptr %69, align 8, !tbaa !44
  %71 = and i32 %70, -3
  %72 = icmp eq i32 %71, 1
  %73 = icmp eq i32 %70, 2
  %74 = icmp eq i32 %70, 4
  %75 = or i1 %73, %74
  %76 = zext i1 %75 to i32
  %77 = select i1 %72, i32 8, i32 %76
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %95, label %79

79:                                               ; preds = %68
  %80 = zext nneg i32 %77 to i64
  %81 = mul nuw nsw i64 %2, %80
  %82 = load ptr, ptr %55, align 8, !tbaa !23
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 %81
  br label %84

84:                                               ; preds = %84, %79
  %85 = phi i64 [ 0, %79 ], [ %93, %84 ]
  %86 = phi i64 [ 0, %79 ], [ %92, %84 ]
  %87 = getelementptr inbounds nuw i8, ptr %83, i64 %85
  %88 = load i8, ptr %87, align 1, !tbaa !38
  %89 = zext i8 %88 to i64
  %90 = shl nuw nsw i64 %85, 3
  %91 = shl nuw i64 %89, %90
  %92 = or i64 %91, %86
  %93 = add nuw nsw i64 %85, 1
  %94 = icmp eq i64 %93, %80
  br i1 %94, label %95, label %84, !llvm.loop !45

95:                                               ; preds = %84, %68
  %96 = phi i64 [ 0, %68 ], [ %92, %84 ]
  %97 = zext i32 %70 to i64
  br label %108

98:                                               ; preds = %67
  %99 = load ptr, ptr %55, align 8, !tbaa !23
  %100 = getelementptr inbounds nuw i64, ptr %99, i64 %2
  %101 = load i64, ptr %100, align 8, !tbaa !15
  br label %108

102:                                              ; preds = %67
  %103 = load ptr, ptr %55, align 8, !tbaa !23
  %104 = getelementptr inbounds nuw %struct.NmsValue, ptr %103, i64 %2
  %105 = load i64, ptr %104, align 8, !tbaa !15
  %106 = getelementptr inbounds nuw i8, ptr %104, i64 8
  %107 = load i64, ptr %106, align 8
  br label %108

108:                                              ; preds = %95, %98, %102
  %109 = phi i64 [ %96, %95 ], [ %101, %98 ], [ %105, %102 ]
  %110 = phi i64 [ %97, %95 ], [ 5, %98 ], [ %107, %102 ]
  %111 = insertvalue [2 x i64] poison, i64 %109, 0
  %112 = insertvalue [2 x i64] %111, i64 %110, 1
  %113 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %112) #23
  %114 = icmp eq i32 %113, 0
  br i1 %114, label %115, label %117

115:                                              ; preds = %108
  store i64 %109, ptr %3, align 8, !tbaa !15
  %116 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i64 %110, ptr %116, align 8
  br label %117

117:                                              ; preds = %21, %14, %10, %16, %25, %9, %32, %48, %44, %39, %36, %31, %53, %108, %115, %65, %4
  %118 = phi i32 [ 6, %4 ], [ 1, %53 ], [ 0, %65 ], [ 0, %115 ], [ %113, %108 ], [ 6, %21 ], [ 6, %14 ], [ 5, %10 ], [ 6, %16 ], [ %30, %25 ], [ 6, %9 ], [ 5, %32 ], [ 6, %48 ], [ 6, %44 ], [ 6, %39 ], [ 6, %36 ], [ 6, %31 ]
  ret i32 %118
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #10

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_value_array_pop(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #9 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %122, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %30

8:                                                ; preds = %5
  br i1 %7, label %122, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !16
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %122

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %122, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load i32, ptr %16, align 8, !tbaa !13
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %122, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %22 = load ptr, ptr %21, align 8, !tbaa !12
  %23 = icmp eq ptr %22, null
  br i1 %23, label %122, label %24

24:                                               ; preds = %20
  %25 = getelementptr %struct.NmsView, ptr %22, i64 %1
  %26 = getelementptr i8, ptr %25, i64 -16
  %27 = load ptr, ptr %26, align 8, !tbaa !24
  %28 = icmp eq ptr %27, null
  %29 = select i1 %28, i32 6, i32 1
  br label %122

30:                                               ; preds = %5
  br i1 %7, label %122, label %31

31:                                               ; preds = %30
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = load i32, ptr %32, align 8, !tbaa !16
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %122

35:                                               ; preds = %31
  %36 = and i64 %1, 9223372036854775807
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %122, label %38

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !17
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %36, %41
  br i1 %42, label %122, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %45 = load ptr, ptr %44, align 8, !tbaa !18
  %46 = icmp eq ptr %45, null
  br i1 %46, label %122, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i64 %36
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %50 = load i64, ptr %49, align 8, !tbaa !19
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %122, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 4294967295
  %54 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 28
  %56 = load i32, ptr %55, align 4, !tbaa !22
  %57 = add i32 %56, -2
  %58 = icmp ult i32 %57, 3
  br i1 %58, label %59, label %122

59:                                               ; preds = %52
  %60 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %61 = load i32, ptr %60, align 8, !tbaa !33
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %63, label %65

63:                                               ; preds = %59
  store i64 0, ptr %2, align 8, !tbaa !15
  %64 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store <2 x i32> zeroinitializer, ptr %64, align 8
  br label %122

65:                                               ; preds = %59
  %66 = add i32 %61, -1
  switch i32 %56, label %104 [
    i32 4, label %67
    i32 2, label %99
  ]

67:                                               ; preds = %65
  %68 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %69 = load i32, ptr %68, align 8, !tbaa !44
  %70 = and i32 %69, -3
  %71 = icmp eq i32 %70, 1
  %72 = icmp eq i32 %69, 2
  %73 = icmp eq i32 %69, 4
  %74 = or i1 %72, %73
  %75 = zext i1 %74 to i32
  %76 = select i1 %71, i32 8, i32 %75
  %77 = icmp eq i32 %76, 0
  br i1 %77, label %78, label %80

78:                                               ; preds = %67
  %79 = zext i32 %69 to i64
  store i32 %66, ptr %60, align 8, !tbaa !33
  br label %118

80:                                               ; preds = %67
  %81 = zext nneg i32 %76 to i64
  %82 = zext i32 %66 to i64
  %83 = mul nuw nsw i64 %81, %82
  %84 = load ptr, ptr %54, align 8, !tbaa !23
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 %83
  br label %86

86:                                               ; preds = %86, %80
  %87 = phi i64 [ 0, %80 ], [ %95, %86 ]
  %88 = phi i64 [ 0, %80 ], [ %94, %86 ]
  %89 = getelementptr inbounds nuw i8, ptr %85, i64 %87
  %90 = load i8, ptr %89, align 1, !tbaa !38
  %91 = zext i8 %90 to i64
  %92 = shl nuw nsw i64 %87, 3
  %93 = shl nuw i64 %91, %92
  %94 = or i64 %93, %88
  %95 = add nuw nsw i64 %87, 1
  %96 = icmp eq i64 %95, %81
  br i1 %96, label %97, label %86, !llvm.loop !45

97:                                               ; preds = %86
  %98 = zext i32 %69 to i64
  store i32 %66, ptr %60, align 8, !tbaa !33
  br label %111

99:                                               ; preds = %65
  %100 = load ptr, ptr %54, align 8, !tbaa !23
  %101 = zext i32 %66 to i64
  %102 = getelementptr inbounds nuw i64, ptr %100, i64 %101
  %103 = load i64, ptr %102, align 8, !tbaa !15
  store i32 %66, ptr %60, align 8, !tbaa !33
  store i64 0, ptr %102, align 8, !tbaa !15
  br label %118

104:                                              ; preds = %65
  %105 = load ptr, ptr %54, align 8, !tbaa !23
  %106 = zext i32 %66 to i64
  %107 = getelementptr inbounds nuw %struct.NmsValue, ptr %105, i64 %106
  %108 = load i64, ptr %107, align 8, !tbaa !15
  %109 = getelementptr inbounds nuw i8, ptr %107, i64 8
  %110 = load i64, ptr %109, align 8
  store i32 %66, ptr %60, align 8, !tbaa !33
  store i64 0, ptr %107, align 8, !tbaa !15
  store <2 x i32> zeroinitializer, ptr %109, align 8
  br label %118

111:                                              ; preds = %97, %111
  %112 = phi i64 [ %116, %111 ], [ 0, %97 ]
  %113 = load ptr, ptr %54, align 8, !tbaa !23
  %114 = getelementptr inbounds nuw i8, ptr %113, i64 %83
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 %112
  store i8 0, ptr %115, align 1, !tbaa !38
  %116 = add nuw nsw i64 %112, 1
  %117 = icmp eq i64 %116, %81
  br i1 %117, label %118, label %111, !llvm.loop !60

118:                                              ; preds = %111, %78, %99, %104
  %119 = phi i64 [ 5, %99 ], [ %110, %104 ], [ %79, %78 ], [ %98, %111 ]
  %120 = phi i64 [ %103, %99 ], [ %108, %104 ], [ 0, %78 ], [ %94, %111 ]
  store i64 %120, ptr %2, align 8, !tbaa !15
  %121 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i64 %119, ptr %121, align 8
  br label %122

122:                                              ; preds = %20, %13, %9, %15, %24, %8, %31, %47, %43, %38, %35, %30, %52, %118, %63, %3
  %123 = phi i32 [ 6, %3 ], [ 1, %52 ], [ 0, %118 ], [ 0, %63 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %29, %24 ], [ 6, %8 ], [ 5, %31 ], [ 6, %47 ], [ 6, %43 ], [ 6, %38 ], [ 6, %35 ], [ 6, %30 ]
  ret i32 %123
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_value_array_length(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %62, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %30

8:                                                ; preds = %5
  br i1 %7, label %62, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !16
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %62

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %62, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load i32, ptr %16, align 8, !tbaa !13
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %62, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %22 = load ptr, ptr %21, align 8, !tbaa !12
  %23 = icmp eq ptr %22, null
  br i1 %23, label %62, label %24

24:                                               ; preds = %20
  %25 = getelementptr %struct.NmsView, ptr %22, i64 %1
  %26 = getelementptr i8, ptr %25, i64 -16
  %27 = load ptr, ptr %26, align 8, !tbaa !24
  %28 = icmp eq ptr %27, null
  %29 = select i1 %28, i32 6, i32 1
  br label %62

30:                                               ; preds = %5
  br i1 %7, label %62, label %31

31:                                               ; preds = %30
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = load i32, ptr %32, align 8, !tbaa !16
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %62

35:                                               ; preds = %31
  %36 = and i64 %1, 9223372036854775807
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %62, label %38

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !17
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %36, %41
  br i1 %42, label %62, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %45 = load ptr, ptr %44, align 8, !tbaa !18
  %46 = icmp eq ptr %45, null
  br i1 %46, label %62, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i64 %36
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %50 = load i64, ptr %49, align 8, !tbaa !19
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %62, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 4294967295
  %54 = getelementptr inbounds nuw %struct.NmsSlot, ptr %45, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 28
  %56 = load i32, ptr %55, align 4, !tbaa !22
  %57 = add i32 %56, -2
  %58 = icmp ult i32 %57, 3
  br i1 %58, label %59, label %62

59:                                               ; preds = %52
  %60 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %61 = load i32, ptr %60, align 8, !tbaa !33
  store i32 %61, ptr %2, align 4, !tbaa !4
  br label %62

62:                                               ; preds = %20, %13, %9, %15, %24, %8, %31, %47, %43, %38, %35, %30, %52, %59, %3
  %63 = phi i32 [ 6, %3 ], [ 1, %52 ], [ 0, %59 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %29, %24 ], [ 6, %8 ], [ 5, %31 ], [ 6, %47 ], [ 6, %43 ], [ 6, %38 ], [ 6, %35 ], [ 6, %30 ]
  ret i32 %63
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_vm_array_literal(ptr noundef captures(address_is_null) %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(address_is_null) %3, i32 noundef %4, ptr noundef writeonly captures(address_is_null) %5) local_unnamed_addr #3 {
  %7 = alloca double, align 8
  %8 = alloca i8, align 8
  %9 = alloca i8, align 4
  %10 = alloca i8, align 4
  %11 = alloca i8, align 4
  %12 = alloca i8, align 4
  %13 = alloca i8, align 4
  %14 = alloca i8, align 4
  %15 = alloca i8, align 4
  %16 = alloca i64, align 8
  %17 = icmp eq ptr %0, null
  %18 = icmp eq ptr %5, null
  %19 = or i1 %17, %18
  %20 = icmp ugt i32 %4, 65535
  %21 = or i1 %20, %19
  br i1 %21, label %126, label %22

22:                                               ; preds = %6
  %23 = icmp eq i32 %4, 0
  br i1 %23, label %28, label %24

24:                                               ; preds = %22
  %25 = icmp ne ptr %2, null
  %26 = icmp ne ptr %3, null
  %27 = and i1 %25, %26
  br i1 %27, label %28, label %126

28:                                               ; preds = %24, %22
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %30 = load i32, ptr %29, align 8, !tbaa !16
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %32, label %126

32:                                               ; preds = %28
  switch i32 %1, label %126 [
    i32 9, label %33
    i32 7, label %33
    i32 5, label %33
    i32 4, label %33
    i32 3, label %33
    i32 2, label %33
    i32 1, label %33
    i32 0, label %33
  ]

33:                                               ; preds = %32, %32, %32, %32, %32, %32, %32, %32
  br i1 %23, label %100, label %34

34:                                               ; preds = %33
  %35 = and i32 %1, -3
  %36 = icmp ne i32 %35, 1
  %37 = icmp eq i32 %1, 2
  %38 = icmp eq i32 %1, 4
  %39 = or i1 %37, %38
  %40 = xor i1 %39, %36
  %41 = add nsw i32 %1, -1
  %42 = icmp ult i32 %41, 4
  %43 = icmp eq i32 %1, 1
  %44 = icmp eq i32 %1, 3
  %45 = zext nneg i32 %4 to i64
  %46 = getelementptr inbounds nuw i8, ptr %7, i64 1
  %47 = getelementptr inbounds nuw i8, ptr %7, i64 2
  %48 = getelementptr inbounds nuw i8, ptr %7, i64 3
  %49 = getelementptr inbounds nuw i8, ptr %7, i64 4
  %50 = getelementptr inbounds nuw i8, ptr %7, i64 5
  %51 = getelementptr inbounds nuw i8, ptr %7, i64 6
  %52 = getelementptr inbounds nuw i8, ptr %7, i64 7
  br label %53

53:                                               ; preds = %34, %97
  %54 = phi i64 [ 0, %34 ], [ %98, %97 ]
  %55 = getelementptr inbounds nuw i64, ptr %2, i64 %54
  %56 = load i64, ptr %55, align 8, !tbaa !15
  %57 = getelementptr inbounds nuw i32, ptr %3, i64 %54
  %58 = load i32, ptr %57, align 4, !tbaa !4
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  call void @llvm.lifetime.start.p0(ptr nonnull %9)
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  call void @llvm.lifetime.start.p0(ptr nonnull %11)
  call void @llvm.lifetime.start.p0(ptr nonnull %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %13)
  call void @llvm.lifetime.start.p0(ptr nonnull %14)
  call void @llvm.lifetime.start.p0(ptr nonnull %15)
  br i1 %40, label %91, label %59

59:                                               ; preds = %53
  %60 = icmp eq i32 %58, 2
  %61 = icmp ugt i64 %56, 255
  %62 = select i1 %60, i1 %61, i1 false
  br i1 %62, label %90, label %63

63:                                               ; preds = %59
  %64 = icmp eq i32 %58, 4
  %65 = icmp ugt i64 %56, 1
  %66 = select i1 %64, i1 %65, i1 false
  br i1 %66, label %90, label %67

67:                                               ; preds = %63
  %68 = icmp eq i32 %1, %58
  %69 = and i1 %42, %68
  %70 = and i1 %43, %60
  %71 = or i1 %69, %70
  br i1 %71, label %89, label %72

72:                                               ; preds = %67
  %73 = icmp eq i32 %58, 1
  %74 = and i1 %37, %73
  br i1 %74, label %75, label %77

75:                                               ; preds = %72
  %76 = trunc i64 %56 to i8
  store i8 %76, ptr %8, align 8, !tbaa !15
  store i8 0, ptr %9, align 4, !tbaa !15
  store i8 0, ptr %10, align 4, !tbaa !15
  br label %89

77:                                               ; preds = %72
  %78 = and i1 %44, %73
  br i1 %78, label %79, label %90

79:                                               ; preds = %77
  call void @llvm.lifetime.start.p0(ptr nonnull %7)
  %80 = sitofp i64 %56 to double
  store double %80, ptr %7, align 8, !tbaa !58
  %81 = load volatile i8, ptr %7, align 8, !tbaa !38
  store volatile i8 %81, ptr %8, align 8, !tbaa !38
  %82 = load volatile i8, ptr %46, align 1, !tbaa !38
  store volatile i8 %82, ptr %9, align 4, !tbaa !38
  %83 = load volatile i8, ptr %47, align 2, !tbaa !38
  store volatile i8 %83, ptr %10, align 4, !tbaa !38
  %84 = load volatile i8, ptr %48, align 1, !tbaa !38
  store volatile i8 %84, ptr %11, align 4, !tbaa !38
  %85 = load volatile i8, ptr %49, align 4, !tbaa !38
  store volatile i8 %85, ptr %12, align 4, !tbaa !38
  %86 = load volatile i8, ptr %50, align 1, !tbaa !38
  store volatile i8 %86, ptr %13, align 4, !tbaa !38
  %87 = load volatile i8, ptr %51, align 2, !tbaa !38
  store volatile i8 %87, ptr %14, align 4, !tbaa !38
  %88 = load volatile i8, ptr %52, align 1, !tbaa !38
  store volatile i8 %88, ptr %15, align 4, !tbaa !38
  call void @llvm.lifetime.end.p0(ptr nonnull %7)
  br label %89

89:                                               ; preds = %67, %75, %79
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br label %97

90:                                               ; preds = %59, %63, %77
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br label %126

91:                                               ; preds = %53
  %92 = zext i32 %58 to i64
  %93 = insertvalue [2 x i64] poison, i64 %56, 0
  %94 = insertvalue [2 x i64] %93, i64 %92, 1
  %95 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %94) #23
  %96 = icmp eq i32 %95, 0
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br i1 %96, label %97, label %126

97:                                               ; preds = %89, %91
  %98 = add nuw nsw i64 %54, 1
  %99 = icmp eq i64 %98, %45
  br i1 %99, label %100, label %53, !llvm.loop !62

100:                                              ; preds = %97, %33
  call void @llvm.lifetime.start.p0(ptr nonnull %16) #24
  store i64 0, ptr %16, align 8, !tbaa !15
  %101 = call fastcc i32 @vm_array_create_capacity(ptr noundef %0, i32 noundef %1, i32 noundef %4, ptr noundef nonnull %16) #23
  %102 = icmp eq i32 %101, 0
  br i1 %102, label %103, label %124

103:                                              ; preds = %100
  %104 = load i64, ptr %16, align 8, !tbaa !15
  br i1 %23, label %123, label %105

105:                                              ; preds = %103
  %106 = zext nneg i32 %4 to i64
  br label %110

107:                                              ; preds = %110
  %108 = add nuw nsw i64 %111, 1
  %109 = icmp eq i64 %108, %106
  br i1 %109, label %123, label %110, !llvm.loop !63

110:                                              ; preds = %105, %107
  %111 = phi i64 [ 0, %105 ], [ %108, %107 ]
  %112 = getelementptr inbounds nuw i64, ptr %2, i64 %111
  %113 = load i64, ptr %112, align 8, !tbaa !15
  %114 = getelementptr inbounds nuw i32, ptr %3, i64 %111
  %115 = load i32, ptr %114, align 4, !tbaa !4
  %116 = insertvalue [2 x i64] poison, i64 %113, 0
  %117 = zext i32 %115 to i64
  %118 = insertvalue [2 x i64] %116, i64 %117, 1
  %119 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef %0, i64 noundef %104, i64 noundef 0, [2 x i64] %118, i32 noundef 1) #23
  %120 = icmp eq i32 %119, 0
  br i1 %120, label %107, label %121

121:                                              ; preds = %110
  %122 = call i32 @nms_release(ptr noundef %0, i64 noundef %104) #23
  br label %124

123:                                              ; preds = %107, %103
  store i64 %104, ptr %5, align 8, !tbaa !15
  br label %124

124:                                              ; preds = %121, %100, %123
  %125 = phi i32 [ %119, %121 ], [ 0, %123 ], [ %101, %100 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %16) #24
  br label %126

126:                                              ; preds = %91, %90, %32, %28, %6, %24, %124
  %127 = phi i32 [ 5, %28 ], [ 6, %6 ], [ %125, %124 ], [ 1, %32 ], [ 6, %24 ], [ 1, %90 ], [ %95, %91 ]
  ret i32 %127
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_vm_array_slice(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp eq ptr %4, null
  br i1 %7, label %178, label %8

8:                                                ; preds = %5
  %9 = icmp sgt i64 %1, -1
  %10 = icmp eq ptr %0, null
  br i1 %9, label %11, label %33

11:                                               ; preds = %8
  br i1 %10, label %178, label %12

12:                                               ; preds = %11
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %14 = load i32, ptr %13, align 8, !tbaa !16
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %16, label %178

16:                                               ; preds = %12
  %17 = icmp eq i64 %1, 0
  br i1 %17, label %178, label %18

18:                                               ; preds = %16
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %20 = load i32, ptr %19, align 8, !tbaa !13
  %21 = zext i32 %20 to i64
  %22 = icmp samesign ugt i64 %1, %21
  br i1 %22, label %178, label %23

23:                                               ; preds = %18
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %25 = load ptr, ptr %24, align 8, !tbaa !12
  %26 = icmp eq ptr %25, null
  br i1 %26, label %178, label %27

27:                                               ; preds = %23
  %28 = getelementptr %struct.NmsView, ptr %25, i64 %1
  %29 = getelementptr i8, ptr %28, i64 -16
  %30 = load ptr, ptr %29, align 8, !tbaa !24
  %31 = icmp eq ptr %30, null
  %32 = select i1 %31, i32 6, i32 1
  br label %178

33:                                               ; preds = %8
  br i1 %10, label %178, label %34

34:                                               ; preds = %33
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %36 = load i32, ptr %35, align 8, !tbaa !16
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %38, label %178

38:                                               ; preds = %34
  %39 = and i64 %1, 9223372036854775807
  %40 = icmp eq i64 %39, 0
  br i1 %40, label %178, label %41

41:                                               ; preds = %38
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %43 = load i32, ptr %42, align 4, !tbaa !17
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %39, %44
  br i1 %45, label %178, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %48 = load ptr, ptr %47, align 8, !tbaa !18
  %49 = icmp eq ptr %48, null
  br i1 %49, label %178, label %50

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw %struct.NmsSlot, ptr %48, i64 %39
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 8
  %53 = load i64, ptr %52, align 8, !tbaa !19
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %178, label %55

55:                                               ; preds = %50
  %56 = and i64 %1, 4294967295
  %57 = getelementptr inbounds nuw %struct.NmsSlot, ptr %48, i64 %56
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 28
  %59 = load i32, ptr %58, align 4, !tbaa !22
  %60 = add i32 %59, -2
  %61 = icmp ult i32 %60, 3
  br i1 %61, label %62, label %178

62:                                               ; preds = %55
  %63 = getelementptr inbounds nuw i8, ptr %57, i64 16
  %64 = load i32, ptr %63, align 8, !tbaa !33
  %65 = icmp eq i32 %59, 2
  br i1 %65, label %69, label %66

66:                                               ; preds = %62
  %67 = getelementptr inbounds nuw i8, ptr %57, i64 32
  %68 = load i32, ptr %67, align 8, !tbaa !44
  br label %69

69:                                               ; preds = %62, %66
  %70 = phi i32 [ %68, %66 ], [ 5, %62 ]
  %71 = tail call i32 @llvm.umin.i32(i32 %2, i32 %64)
  %72 = tail call i32 @llvm.umin.i32(i32 %3, i32 %64)
  %73 = tail call i32 @llvm.usub.sat.i32(i32 %72, i32 %71)
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  %74 = call fastcc i32 @vm_array_create_capacity(ptr noundef nonnull %0, i32 noundef %70, i32 noundef %73, ptr noundef nonnull %6) #23
  %75 = icmp eq i32 %74, 0
  br i1 %75, label %76, label %176

76:                                               ; preds = %69
  %77 = load ptr, ptr %47, align 8, !tbaa !18
  %78 = getelementptr inbounds nuw %struct.NmsSlot, ptr %77, i64 %56
  %79 = load i64, ptr %6, align 8, !tbaa !15
  %80 = and i64 %79, 4294967295
  %81 = getelementptr inbounds nuw %struct.NmsSlot, ptr %77, i64 %80
  %82 = getelementptr inbounds nuw i8, ptr %78, i64 28
  %83 = load i32, ptr %82, align 4, !tbaa !22
  %84 = icmp eq i32 %83, 4
  %85 = icmp ult i32 %2, %72
  br i1 %84, label %90, label %86

86:                                               ; preds = %76
  br i1 %85, label %87, label %175

87:                                               ; preds = %86
  %88 = getelementptr inbounds nuw i8, ptr %78, i64 32
  %89 = zext i32 %73 to i64
  br label %119

90:                                               ; preds = %76
  br i1 %85, label %91, label %114

91:                                               ; preds = %90
  %92 = and i32 %70, -3
  %93 = icmp eq i32 %92, 1
  %94 = icmp eq i32 %70, 2
  %95 = icmp eq i32 %70, 4
  %96 = or i1 %94, %95
  %97 = zext i1 %96 to i64
  %98 = select i1 %93, i64 8, i64 %97
  %99 = load ptr, ptr %81, align 8, !tbaa !23
  %100 = load ptr, ptr %78, align 8, !tbaa !23
  %101 = zext i32 %71 to i64
  %102 = mul nuw nsw i64 %98, %101
  %103 = getelementptr inbounds nuw i8, ptr %100, i64 %102
  %104 = zext i32 %73 to i64
  %105 = mul nuw nsw i64 %98, %104
  %106 = icmp eq i64 %105, 0
  br i1 %106, label %114, label %107

107:                                              ; preds = %91, %107
  %108 = phi i64 [ %112, %107 ], [ 0, %91 ]
  %109 = getelementptr inbounds nuw i8, ptr %103, i64 %108
  %110 = load volatile i8, ptr %109, align 1, !tbaa !38
  %111 = getelementptr inbounds nuw i8, ptr %99, i64 %108
  store volatile i8 %110, ptr %111, align 1, !tbaa !38
  %112 = add nuw nsw i64 %108, 1
  %113 = icmp eq i64 %112, %105
  br i1 %113, label %114, label %107, !llvm.loop !39

114:                                              ; preds = %107, %91, %90
  %115 = getelementptr inbounds nuw i8, ptr %81, i64 16
  store i32 %73, ptr %115, align 8, !tbaa !33
  br label %175

116:                                              ; preds = %166
  %117 = add nuw nsw i64 %120, 1
  %118 = icmp samesign ult i64 %117, %89
  br i1 %118, label %119, label %175, !llvm.loop !64

119:                                              ; preds = %87, %116
  %120 = phi i64 [ 0, %87 ], [ %117, %116 ]
  %121 = trunc nuw i64 %120 to i32
  %122 = add i32 %71, %121
  %123 = load i32, ptr %82, align 4, !tbaa !22
  switch i32 %123, label %159 [
    i32 4, label %124
    i32 2, label %154
  ]

124:                                              ; preds = %119
  %125 = load i32, ptr %88, align 8, !tbaa !44
  %126 = and i32 %125, -3
  %127 = icmp eq i32 %126, 1
  %128 = icmp eq i32 %125, 2
  %129 = icmp eq i32 %125, 4
  %130 = or i1 %128, %129
  %131 = zext i1 %130 to i32
  %132 = select i1 %127, i32 8, i32 %131
  %133 = icmp eq i32 %132, 0
  br i1 %133, label %151, label %134

134:                                              ; preds = %124
  %135 = zext nneg i32 %132 to i64
  %136 = zext i32 %122 to i64
  %137 = mul nuw nsw i64 %135, %136
  %138 = load ptr, ptr %78, align 8, !tbaa !23
  %139 = getelementptr inbounds nuw i8, ptr %138, i64 %137
  br label %140

140:                                              ; preds = %140, %134
  %141 = phi i64 [ 0, %134 ], [ %149, %140 ]
  %142 = phi i64 [ 0, %134 ], [ %148, %140 ]
  %143 = getelementptr inbounds nuw i8, ptr %139, i64 %141
  %144 = load i8, ptr %143, align 1, !tbaa !38
  %145 = zext i8 %144 to i64
  %146 = shl nuw nsw i64 %141, 3
  %147 = shl nuw i64 %145, %146
  %148 = or i64 %147, %142
  %149 = add nuw nsw i64 %141, 1
  %150 = icmp eq i64 %149, %135
  br i1 %150, label %151, label %140, !llvm.loop !45

151:                                              ; preds = %140, %124
  %152 = phi i64 [ 0, %124 ], [ %148, %140 ]
  %153 = zext i32 %125 to i64
  br label %166

154:                                              ; preds = %119
  %155 = load ptr, ptr %78, align 8, !tbaa !23
  %156 = zext i32 %122 to i64
  %157 = getelementptr inbounds nuw i64, ptr %155, i64 %156
  %158 = load i64, ptr %157, align 8, !tbaa !15
  br label %166

159:                                              ; preds = %119
  %160 = load ptr, ptr %78, align 8, !tbaa !23
  %161 = zext i32 %122 to i64
  %162 = getelementptr inbounds nuw %struct.NmsValue, ptr %160, i64 %161
  %163 = load i64, ptr %162, align 8, !tbaa !15
  %164 = getelementptr inbounds nuw i8, ptr %162, i64 8
  %165 = load i64, ptr %164, align 8
  br label %166

166:                                              ; preds = %151, %154, %159
  %167 = phi i64 [ %152, %151 ], [ %158, %154 ], [ %163, %159 ]
  %168 = phi i64 [ %153, %151 ], [ 5, %154 ], [ %165, %159 ]
  %169 = insertvalue [2 x i64] poison, i64 %167, 0
  %170 = insertvalue [2 x i64] %169, i64 %168, 1
  %171 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %79, i64 noundef 0, [2 x i64] %170, i32 noundef 1) #23
  %172 = icmp eq i32 %171, 0
  br i1 %172, label %116, label %173

173:                                              ; preds = %166
  %174 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %79) #23
  br label %176

175:                                              ; preds = %116, %86, %114
  store i64 %79, ptr %4, align 8, !tbaa !15
  br label %176

176:                                              ; preds = %173, %175, %69
  %177 = phi i32 [ %74, %69 ], [ 0, %175 ], [ %171, %173 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  br label %178

178:                                              ; preds = %23, %16, %12, %18, %27, %11, %34, %50, %46, %41, %38, %33, %176, %55, %5
  %179 = phi i32 [ 6, %5 ], [ %177, %176 ], [ 1, %55 ], [ 6, %23 ], [ 6, %16 ], [ 5, %12 ], [ 6, %18 ], [ %32, %27 ], [ 6, %11 ], [ 5, %34 ], [ 6, %50 ], [ 6, %46 ], [ 6, %41 ], [ 6, %38 ], [ 6, %33 ]
  ret i32 %179
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_format_scalar(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca [32 x i8], align 4
  %6 = alloca [1100 x i8], align 1
  %7 = alloca [6 x i8], align 4
  %8 = alloca [20 x i8], align 1
  switch i32 %2, label %696 [
    i32 3, label %9
    i32 9, label %641
    i32 7, label %641
    i32 0, label %641
    i32 4, label %656
  ]

9:                                                ; preds = %4
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %12, label %11

11:                                               ; preds = %9
  store i8 45, ptr %5, align 4, !tbaa !38
  br label %12

12:                                               ; preds = %11, %9
  %13 = phi i32 [ 1, %11 ], [ 0, %9 ]
  %14 = lshr i64 %1, 52
  %15 = trunc nuw nsw i64 %14 to i32
  %16 = and i32 %15, 2047
  %17 = and i64 %1, 4503599627370495
  %18 = icmp eq i32 %16, 2047
  br i1 %18, label %19, label %63

19:                                               ; preds = %12
  %20 = icmp eq i64 %17, 0
  %21 = zext nneg i32 %13 to i64
  %22 = select i1 %20, i8 105, i8 110
  %23 = getelementptr inbounds nuw i8, ptr %5, i64 %21
  store i8 %22, ptr %23, align 1, !tbaa !38
  %24 = select i1 %20, i8 110, i8 97
  %25 = getelementptr inbounds nuw i8, ptr %23, i64 1
  store i8 %24, ptr %25, align 1, !tbaa !38
  %26 = select i1 %20, i8 102, i8 110
  %27 = add nuw nsw i32 %13, 3
  %28 = getelementptr inbounds nuw i8, ptr %23, i64 2
  store i8 %26, ptr %28, align 1, !tbaa !38
  %29 = zext nneg i32 %27 to i64
  %30 = icmp ne ptr %0, null
  %31 = icmp ne ptr %3, null
  %32 = and i1 %30, %31
  br i1 %32, label %33, label %639

33:                                               ; preds = %19
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %35 = load i32, ptr %34, align 8, !tbaa !16
  %36 = icmp eq i32 %35, 0
  br i1 %36, label %37, label %639

37:                                               ; preds = %33
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %39 = load i64, ptr %38, align 8, !tbaa !30
  %40 = xor i64 %39, -1
  %41 = icmp ugt i64 %29, %40
  br i1 %41, label %639, label %42

42:                                               ; preds = %37
  %43 = add nuw nsw i64 %29, 1
  %44 = tail call noalias ptr @malloc(i64 noundef %43) #22
  %45 = icmp eq ptr %44, null
  br i1 %45, label %639, label %46

46:                                               ; preds = %42
  %47 = load volatile i8, ptr %5, align 4, !tbaa !38
  store volatile i8 %47, ptr %44, align 1, !tbaa !38
  %48 = getelementptr inbounds nuw i8, ptr %5, i64 1
  %49 = load volatile i8, ptr %48, align 1, !tbaa !38
  %50 = getelementptr inbounds nuw i8, ptr %44, i64 1
  store volatile i8 %49, ptr %50, align 1, !tbaa !38
  %51 = getelementptr inbounds nuw i8, ptr %5, i64 2
  %52 = load volatile i8, ptr %51, align 2, !tbaa !38
  %53 = getelementptr inbounds nuw i8, ptr %44, i64 2
  store volatile i8 %52, ptr %53, align 1, !tbaa !38
  br i1 %10, label %58, label %54

54:                                               ; preds = %46
  %55 = getelementptr inbounds nuw i8, ptr %5, i64 3
  %56 = load volatile i8, ptr %55, align 1, !tbaa !38
  %57 = getelementptr inbounds nuw i8, ptr %44, i64 3
  store volatile i8 %56, ptr %57, align 1, !tbaa !38
  br label %58

58:                                               ; preds = %54, %46
  %59 = getelementptr inbounds nuw i8, ptr %44, i64 %29
  store i8 0, ptr %59, align 1, !tbaa !38
  %60 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %44, i32 noundef %27, i32 noundef 0, i32 noundef 1, i64 noundef %29, ptr noundef %3) #23
  %61 = icmp eq i32 %60, 0
  br i1 %61, label %639, label %62

62:                                               ; preds = %58
  tail call void @free(ptr noundef nonnull %44) #22
  br label %639

63:                                               ; preds = %12
  %64 = icmp ne i32 %16, 0
  %65 = icmp ne i64 %17, 0
  %66 = or i1 %65, %64
  br i1 %66, label %99, label %67

67:                                               ; preds = %63
  %68 = add nuw nsw i32 %13, 1
  %69 = zext nneg i32 %13 to i64
  %70 = getelementptr inbounds nuw i8, ptr %5, i64 %69
  store i8 48, ptr %70, align 1, !tbaa !38
  %71 = zext nneg i32 %68 to i64
  %72 = icmp ne ptr %0, null
  %73 = icmp ne ptr %3, null
  %74 = and i1 %72, %73
  br i1 %74, label %75, label %639

75:                                               ; preds = %67
  %76 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %77 = load i32, ptr %76, align 8, !tbaa !16
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %79, label %639

79:                                               ; preds = %75
  %80 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %81 = load i64, ptr %80, align 8, !tbaa !30
  %82 = xor i64 %81, -1
  %83 = icmp ugt i64 %71, %82
  br i1 %83, label %639, label %84

84:                                               ; preds = %79
  %85 = add nuw nsw i64 %71, 1
  %86 = tail call noalias ptr @malloc(i64 noundef %85) #22
  %87 = icmp eq ptr %86, null
  br i1 %87, label %639, label %88

88:                                               ; preds = %84
  %89 = load volatile i8, ptr %5, align 4, !tbaa !38
  store volatile i8 %89, ptr %86, align 1, !tbaa !38
  br i1 %10, label %94, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %5, i64 1
  %92 = load volatile i8, ptr %91, align 1, !tbaa !38
  %93 = getelementptr inbounds nuw i8, ptr %86, i64 1
  store volatile i8 %92, ptr %93, align 1, !tbaa !38
  br label %94

94:                                               ; preds = %90, %88
  %95 = getelementptr inbounds nuw i8, ptr %86, i64 %71
  store i8 0, ptr %95, align 1, !tbaa !38
  %96 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %86, i32 noundef %68, i32 noundef 0, i32 noundef 1, i64 noundef %71, ptr noundef %3) #23
  %97 = icmp eq i32 %96, 0
  br i1 %97, label %639, label %98

98:                                               ; preds = %94
  tail call void @free(ptr noundef nonnull %86) #22
  br label %639

99:                                               ; preds = %63
  %100 = or disjoint i64 %17, 4503599627370496
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  %101 = select i1 %64, i64 %100, i64 %17
  br label %102

102:                                              ; preds = %99, %102
  %103 = phi i32 [ %110, %102 ], [ 0, %99 ]
  %104 = phi i64 [ %106, %102 ], [ %101, %99 ]
  %105 = freeze i64 %104
  %106 = udiv i64 %105, 10
  %107 = mul i64 %106, 10
  %108 = sub i64 %105, %107
  %109 = trunc nuw nsw i64 %108 to i8
  %110 = add i32 %103, 1
  %111 = zext i32 %103 to i64
  %112 = getelementptr inbounds nuw i8, ptr %6, i64 %111
  store i8 %109, ptr %112, align 1, !tbaa !38
  %113 = icmp samesign ult i64 %104, 10
  br i1 %113, label %114, label %102, !llvm.loop !65

114:                                              ; preds = %102
  %115 = add nsw i32 %16, -1075
  %116 = select i1 %64, i32 %115, i32 -1074
  %117 = icmp slt i32 %116, 0
  %118 = tail call i32 @llvm.abs.i32(i32 %116, i1 true)
  %119 = select i1 %117, i32 5, i32 2
  %120 = icmp eq i32 %116, 0
  br i1 %120, label %154, label %121

121:                                              ; preds = %114, %150
  %122 = phi i32 [ %152, %150 ], [ 0, %114 ]
  %123 = phi i32 [ %151, %150 ], [ %110, %114 ]
  %124 = icmp eq i32 %123, 0
  br i1 %124, label %150, label %125

125:                                              ; preds = %121
  %126 = zext i32 %123 to i64
  br label %129

127:                                              ; preds = %129
  %128 = icmp samesign ult i32 %136, 10
  br i1 %128, label %150, label %144

129:                                              ; preds = %129, %125
  %130 = phi i64 [ 0, %125 ], [ %142, %129 ]
  %131 = phi i32 [ 0, %125 ], [ %138, %129 ]
  %132 = getelementptr inbounds nuw i8, ptr %6, i64 %130
  %133 = load i8, ptr %132, align 1, !tbaa !38
  %134 = zext i8 %133 to i32
  %135 = mul nuw nsw i32 %119, %134
  %136 = add nuw nsw i32 %135, %131
  %137 = freeze i32 %136
  %138 = udiv i32 %137, 10
  %139 = mul i32 %138, 10
  %140 = sub i32 %137, %139
  %141 = trunc nuw nsw i32 %140 to i8
  store i8 %141, ptr %132, align 1, !tbaa !38
  %142 = add nuw nsw i64 %130, 1
  %143 = icmp eq i64 %142, %126
  br i1 %143, label %127, label %129, !llvm.loop !66

144:                                              ; preds = %127
  %145 = icmp eq i32 %123, 1100
  br i1 %145, label %637, label %146

146:                                              ; preds = %144
  %147 = trunc i32 %138 to i8
  %148 = add i32 %123, 1
  %149 = getelementptr inbounds nuw i8, ptr %6, i64 %126
  store i8 %147, ptr %149, align 1, !tbaa !38
  br label %150

150:                                              ; preds = %146, %127, %121
  %151 = phi i32 [ %123, %127 ], [ %148, %146 ], [ 0, %121 ]
  %152 = add nuw i32 %122, 1
  %153 = icmp eq i32 %152, %118
  br i1 %153, label %154, label %121, !llvm.loop !67

154:                                              ; preds = %150, %114
  %155 = phi i32 [ %110, %114 ], [ %151, %150 ]
  %156 = add i32 %155, -1
  %157 = icmp eq i32 %155, 0
  br i1 %157, label %165, label %158

158:                                              ; preds = %154
  %159 = zext i32 %156 to i64
  %160 = getelementptr inbounds nuw i8, ptr %6, i64 %159
  %161 = load i8, ptr %160, align 1, !tbaa !38
  %162 = zext i8 %161 to i32
  %163 = mul nuw nsw i32 %162, 10
  %164 = icmp eq i32 %155, 1
  br i1 %164, label %165, label %168

165:                                              ; preds = %158, %154
  %166 = phi i32 [ %163, %158 ], [ 0, %154 ]
  %167 = mul nuw nsw i32 %166, 10
  br label %177

168:                                              ; preds = %158
  %169 = add i32 %155, -2
  %170 = zext i32 %169 to i64
  %171 = getelementptr inbounds nuw i8, ptr %6, i64 %170
  %172 = load i8, ptr %171, align 1, !tbaa !38
  %173 = zext i8 %172 to i32
  %174 = add nuw nsw i32 %163, %173
  %175 = mul nuw nsw i32 %174, 10
  %176 = icmp ugt i32 %155, 2
  br i1 %176, label %180, label %177

177:                                              ; preds = %168, %165
  %178 = phi i32 [ %167, %165 ], [ %175, %168 ]
  %179 = mul nuw nsw i32 %178, 10
  br label %189

180:                                              ; preds = %168
  %181 = add i32 %155, -3
  %182 = zext i32 %181 to i64
  %183 = getelementptr inbounds nuw i8, ptr %6, i64 %182
  %184 = load i8, ptr %183, align 1, !tbaa !38
  %185 = zext i8 %184 to i32
  %186 = add nuw nsw i32 %175, %185
  %187 = mul nuw nsw i32 %186, 10
  %188 = icmp eq i32 %155, 3
  br i1 %188, label %189, label %192

189:                                              ; preds = %180, %177
  %190 = phi i32 [ %179, %177 ], [ %187, %180 ]
  %191 = mul nuw nsw i32 %190, 10
  br label %201

192:                                              ; preds = %180
  %193 = add i32 %155, -4
  %194 = zext i32 %193 to i64
  %195 = getelementptr inbounds nuw i8, ptr %6, i64 %194
  %196 = load i8, ptr %195, align 1, !tbaa !38
  %197 = zext i8 %196 to i32
  %198 = add nuw nsw i32 %187, %197
  %199 = mul nuw nsw i32 %198, 10
  %200 = icmp ugt i32 %155, 4
  br i1 %200, label %204, label %201

201:                                              ; preds = %192, %189
  %202 = phi i32 [ %191, %189 ], [ %199, %192 ]
  %203 = mul nuw nsw i32 %202, 10
  br label %213

204:                                              ; preds = %192
  %205 = add i32 %155, -5
  %206 = zext i32 %205 to i64
  %207 = getelementptr inbounds nuw i8, ptr %6, i64 %206
  %208 = load i8, ptr %207, align 1, !tbaa !38
  %209 = zext i8 %208 to i32
  %210 = add nuw nsw i32 %199, %209
  %211 = mul nuw nsw i32 %210, 10
  %212 = icmp eq i32 %155, 5
  br i1 %212, label %213, label %217

213:                                              ; preds = %204, %201
  %214 = phi i32 [ %203, %201 ], [ %211, %204 ]
  %215 = tail call i32 @llvm.smin.i32(i32 %116, i32 0)
  %216 = add nsw i32 %156, %215
  br label %313

217:                                              ; preds = %204
  %218 = add i32 %155, -6
  %219 = zext i32 %218 to i64
  %220 = getelementptr inbounds nuw i8, ptr %6, i64 %219
  %221 = load i8, ptr %220, align 1, !tbaa !38
  %222 = zext i8 %221 to i32
  %223 = add nuw nsw i32 %211, %222
  %224 = tail call i32 @llvm.smin.i32(i32 %116, i32 0)
  %225 = add nsw i32 %156, %224
  %226 = icmp ugt i32 %155, 6
  br i1 %226, label %227, label %313

227:                                              ; preds = %217
  %228 = add i32 %155, -7
  %229 = zext i32 %228 to i64
  %230 = getelementptr inbounds nuw i8, ptr %6, i64 %229
  %231 = load i8, ptr %230, align 1, !tbaa !38
  %232 = icmp eq i32 %155, 7
  br i1 %232, label %286, label %233

233:                                              ; preds = %227
  %234 = icmp ult i32 %228, 4
  br i1 %234, label %280, label %235

235:                                              ; preds = %233
  %236 = icmp ult i32 %228, 32
  br i1 %236, label %262, label %237

237:                                              ; preds = %235
  %238 = and i64 %229, 28
  %239 = and i64 %229, 4294967264
  br label %240

240:                                              ; preds = %240, %237
  %241 = phi i64 [ 0, %237 ], [ %254, %240 ]
  %242 = phi <16 x i32> [ zeroinitializer, %237 ], [ %252, %240 ]
  %243 = phi <16 x i32> [ zeroinitializer, %237 ], [ %253, %240 ]
  %244 = getelementptr inbounds nuw i8, ptr %6, i64 %241
  %245 = getelementptr inbounds nuw i8, ptr %244, i64 16
  %246 = load <16 x i8>, ptr %244, align 1, !tbaa !38
  %247 = load <16 x i8>, ptr %245, align 1, !tbaa !38
  %248 = icmp ne <16 x i8> %246, zeroinitializer
  %249 = icmp ne <16 x i8> %247, zeroinitializer
  %250 = zext <16 x i1> %248 to <16 x i32>
  %251 = zext <16 x i1> %249 to <16 x i32>
  %252 = or <16 x i32> %242, %250
  %253 = or <16 x i32> %243, %251
  %254 = add nuw i64 %241, 32
  %255 = icmp eq i64 %254, %239
  br i1 %255, label %256, label %240, !llvm.loop !68

256:                                              ; preds = %240
  %257 = or <16 x i32> %253, %252
  %258 = tail call i32 @llvm.vector.reduce.or.v16i32(<16 x i32> %257)
  %259 = icmp eq i64 %239, %229
  br i1 %259, label %283, label %260

260:                                              ; preds = %256
  %261 = icmp eq i64 %238, 0
  br i1 %261, label %280, label %262, !prof !71

262:                                              ; preds = %235, %260
  %263 = phi i64 [ %239, %260 ], [ 0, %235 ]
  %264 = phi i32 [ %258, %260 ], [ 0, %235 ]
  %265 = and i64 %229, 4294967292
  %266 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %264, i64 0
  br label %267

267:                                              ; preds = %267, %262
  %268 = phi i64 [ %263, %262 ], [ %275, %267 ]
  %269 = phi <4 x i32> [ %266, %262 ], [ %274, %267 ]
  %270 = getelementptr inbounds nuw i8, ptr %6, i64 %268
  %271 = load <4 x i8>, ptr %270, align 1, !tbaa !38
  %272 = icmp ne <4 x i8> %271, zeroinitializer
  %273 = zext <4 x i1> %272 to <4 x i32>
  %274 = or <4 x i32> %269, %273
  %275 = add nuw i64 %268, 4
  %276 = icmp eq i64 %275, %265
  br i1 %276, label %277, label %267, !llvm.loop !72

277:                                              ; preds = %267
  %278 = tail call i32 @llvm.vector.reduce.or.v4i32(<4 x i32> %274)
  %279 = icmp eq i64 %265, %229
  br i1 %279, label %283, label %280

280:                                              ; preds = %233, %260, %277
  %281 = phi i64 [ 0, %233 ], [ %239, %260 ], [ %265, %277 ]
  %282 = phi i32 [ 0, %233 ], [ %258, %260 ], [ %278, %277 ]
  br label %289

283:                                              ; preds = %289, %277, %256
  %284 = phi i32 [ %278, %277 ], [ %258, %256 ], [ %296, %289 ]
  %285 = icmp eq i32 %284, 0
  br label %286

286:                                              ; preds = %283, %227
  %287 = phi i1 [ true, %227 ], [ %285, %283 ]
  %288 = icmp ugt i8 %231, 5
  br i1 %288, label %305, label %299

289:                                              ; preds = %280, %289
  %290 = phi i64 [ %297, %289 ], [ %281, %280 ]
  %291 = phi i32 [ %296, %289 ], [ %282, %280 ]
  %292 = getelementptr inbounds nuw i8, ptr %6, i64 %290
  %293 = load i8, ptr %292, align 1, !tbaa !38
  %294 = icmp ne i8 %293, 0
  %295 = zext i1 %294 to i32
  %296 = or i32 %291, %295
  %297 = add nuw nsw i64 %290, 1
  %298 = icmp eq i64 %297, %229
  br i1 %298, label %283, label %289, !llvm.loop !73

299:                                              ; preds = %286
  %300 = icmp eq i8 %231, 5
  br i1 %300, label %301, label %307

301:                                              ; preds = %299
  %302 = and i32 %222, 1
  %303 = icmp eq i32 %302, 0
  %304 = select i1 %287, i1 %303, i1 false
  br i1 %304, label %307, label %305

305:                                              ; preds = %301, %286
  %306 = add nuw nsw i32 %223, 1
  br label %307

307:                                              ; preds = %305, %301, %299
  %308 = phi i32 [ %306, %305 ], [ %223, %301 ], [ %223, %299 ]
  %309 = icmp eq i32 %308, 1000000
  %310 = add i32 %155, %224
  %311 = select i1 %309, i32 %310, i32 %225
  %312 = select i1 %309, i32 100000, i32 %308
  br label %313

313:                                              ; preds = %307, %217, %213
  %314 = phi i32 [ %311, %307 ], [ %225, %217 ], [ %216, %213 ]
  %315 = phi i32 [ %312, %307 ], [ %223, %217 ], [ %214, %213 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #24
  %316 = freeze i32 %315
  %317 = udiv i32 %316, 10
  %318 = mul i32 %317, 10
  %319 = sub i32 %316, %318
  %320 = trunc nuw nsw i32 %319 to i8
  %321 = or disjoint i8 %320, 48
  %322 = getelementptr inbounds nuw i8, ptr %7, i64 5
  store i8 %321, ptr %322, align 1, !tbaa !38
  %323 = urem i32 %317, 10
  %324 = trunc nuw nsw i32 %323 to i8
  %325 = or disjoint i8 %324, 48
  %326 = getelementptr inbounds nuw i8, ptr %7, i64 4
  store i8 %325, ptr %326, align 4, !tbaa !38
  %327 = udiv i32 %315, 100
  %328 = urem i32 %327, 10
  %329 = trunc nuw nsw i32 %328 to i8
  %330 = or disjoint i8 %329, 48
  %331 = getelementptr inbounds nuw i8, ptr %7, i64 3
  store i8 %330, ptr %331, align 1, !tbaa !38
  %332 = udiv i32 %315, 1000
  %333 = trunc nuw nsw i32 %332 to i16
  %334 = urem i16 %333, 10
  %335 = trunc nuw nsw i16 %334 to i8
  %336 = or disjoint i8 %335, 48
  %337 = getelementptr inbounds nuw i8, ptr %7, i64 2
  store i8 %336, ptr %337, align 2, !tbaa !38
  %338 = udiv i32 %315, 10000
  %339 = trunc nuw nsw i32 %338 to i16
  %340 = urem i16 %339, 10
  %341 = trunc nuw nsw i16 %340 to i8
  %342 = or disjoint i8 %341, 48
  %343 = getelementptr inbounds nuw i8, ptr %7, i64 1
  store i8 %342, ptr %343, align 1, !tbaa !38
  %344 = udiv i32 %315, 100000
  %345 = trunc nuw nsw i32 %344 to i16
  %346 = urem i16 %345, 10
  %347 = trunc nuw nsw i16 %346 to i8
  %348 = or disjoint i8 %347, 48
  store i8 %348, ptr %7, align 4, !tbaa !38
  %349 = icmp eq i32 %319, 0
  br i1 %349, label %350, label %358

350:                                              ; preds = %313
  %351 = icmp eq i32 %323, 0
  br i1 %351, label %352, label %358

352:                                              ; preds = %350
  %353 = icmp eq i32 %328, 0
  br i1 %353, label %354, label %358

354:                                              ; preds = %352
  %355 = icmp eq i16 %334, 0
  br i1 %355, label %356, label %358

356:                                              ; preds = %354
  %357 = icmp eq i16 %340, 0
  br i1 %357, label %366, label %358

358:                                              ; preds = %356, %354, %352, %350, %313
  %359 = phi i1 [ false, %313 ], [ false, %350 ], [ false, %352 ], [ false, %354 ], [ true, %356 ]
  %360 = phi i1 [ false, %313 ], [ false, %350 ], [ false, %352 ], [ true, %354 ], [ false, %356 ]
  %361 = phi i1 [ false, %313 ], [ false, %350 ], [ true, %352 ], [ false, %354 ], [ false, %356 ]
  %362 = phi i1 [ false, %313 ], [ true, %350 ], [ false, %352 ], [ false, %354 ], [ false, %356 ]
  %363 = phi i32 [ 6, %313 ], [ 5, %350 ], [ 4, %352 ], [ 3, %354 ], [ 2, %356 ]
  %364 = add i32 %314, -6
  %365 = icmp ult i32 %364, -10
  br i1 %365, label %373, label %431

366:                                              ; preds = %356
  %367 = add i32 %314, -6
  %368 = icmp ult i32 %367, -10
  br i1 %368, label %369, label %431

369:                                              ; preds = %366
  %370 = add nuw nsw i32 %13, 1
  %371 = zext nneg i32 %13 to i64
  %372 = getelementptr inbounds nuw i8, ptr %5, i64 %371
  store i8 %348, ptr %372, align 1, !tbaa !38
  br label %395

373:                                              ; preds = %358
  %374 = zext nneg i32 %13 to i64
  %375 = getelementptr inbounds nuw i8, ptr %5, i64 %374
  store i8 %348, ptr %375, align 1, !tbaa !38
  %376 = getelementptr inbounds nuw i8, ptr %375, i64 1
  store i8 46, ptr %376, align 1, !tbaa !38
  %377 = add nuw nsw i64 %374, 3
  %378 = getelementptr inbounds nuw i8, ptr %5, i64 %374
  %379 = getelementptr inbounds nuw i8, ptr %378, i64 2
  store i8 %342, ptr %379, align 1, !tbaa !38
  br i1 %359, label %392, label %380

380:                                              ; preds = %373
  %381 = or disjoint i64 %374, 4
  %382 = getelementptr inbounds nuw i8, ptr %5, i64 %377
  store i8 %336, ptr %382, align 1, !tbaa !38
  br i1 %360, label %392, label %383

383:                                              ; preds = %380
  %384 = add nuw nsw i64 %374, 5
  %385 = getelementptr inbounds nuw i8, ptr %5, i64 %381
  store i8 %330, ptr %385, align 1, !tbaa !38
  br i1 %361, label %392, label %386

386:                                              ; preds = %383
  %387 = or disjoint i64 %374, 6
  %388 = getelementptr inbounds nuw i8, ptr %5, i64 %384
  store i8 %325, ptr %388, align 1, !tbaa !38
  br i1 %362, label %392, label %389

389:                                              ; preds = %386
  %390 = add nuw nsw i64 %374, 7
  %391 = getelementptr inbounds nuw i8, ptr %5, i64 %387
  store i8 %321, ptr %391, align 1, !tbaa !38
  br label %392

392:                                              ; preds = %389, %386, %383, %380, %373
  %393 = phi i64 [ %377, %373 ], [ %381, %380 ], [ %384, %383 ], [ %387, %386 ], [ %390, %389 ]
  %394 = trunc nuw nsw i64 %393 to i32
  br label %395

395:                                              ; preds = %392, %369
  %396 = phi i32 [ %370, %369 ], [ %394, %392 ]
  %397 = add i32 %396, 1
  %398 = zext i32 %396 to i64
  %399 = getelementptr inbounds nuw i8, ptr %5, i64 %398
  store i8 101, ptr %399, align 1, !tbaa !38
  %400 = icmp slt i32 %314, 0
  %401 = select i1 %400, i8 45, i8 43
  %402 = add i32 %396, 2
  %403 = zext i32 %397 to i64
  %404 = getelementptr inbounds nuw i8, ptr %5, i64 %403
  store i8 %401, ptr %404, align 1, !tbaa !38
  %405 = tail call i32 @llvm.abs.i32(i32 %314, i1 true)
  %406 = icmp samesign ugt i32 %405, 99
  br i1 %406, label %407, label %414

407:                                              ; preds = %395
  %408 = udiv i32 %405, 100
  %409 = trunc i32 %408 to i8
  %410 = add i8 %409, 48
  %411 = add i32 %396, 3
  %412 = zext i32 %402 to i64
  %413 = getelementptr inbounds nuw i8, ptr %5, i64 %412
  store i8 %410, ptr %413, align 1, !tbaa !38
  br label %414

414:                                              ; preds = %407, %395
  %415 = phi i32 [ %411, %407 ], [ %402, %395 ]
  %416 = freeze i32 %405
  %417 = udiv i32 %416, 10
  %418 = urem i32 %417, 10
  %419 = trunc nuw nsw i32 %418 to i8
  %420 = or disjoint i8 %419, 48
  %421 = add i32 %415, 1
  %422 = zext i32 %415 to i64
  %423 = getelementptr inbounds nuw i8, ptr %5, i64 %422
  store i8 %420, ptr %423, align 1, !tbaa !38
  %424 = mul i32 %417, 10
  %425 = sub i32 %416, %424
  %426 = trunc nuw nsw i32 %425 to i8
  %427 = or disjoint i8 %426, 48
  %428 = add i32 %415, 2
  %429 = zext i32 %421 to i64
  %430 = getelementptr inbounds nuw i8, ptr %5, i64 %429
  store i8 %427, ptr %430, align 1, !tbaa !38
  br label %602

431:                                              ; preds = %366, %358
  %432 = phi i32 [ 1, %366 ], [ %363, %358 ]
  %433 = icmp slt i32 %314, 0
  br i1 %433, label %434, label %510

434:                                              ; preds = %431
  %435 = zext nneg i32 %13 to i64
  %436 = getelementptr inbounds nuw i8, ptr %5, i64 %435
  store i8 48, ptr %436, align 1, !tbaa !38
  %437 = getelementptr inbounds nuw i8, ptr %436, i64 1
  store i8 46, ptr %437, align 1, !tbaa !38
  %438 = icmp eq i32 %314, -1
  br i1 %438, label %439, label %442

439:                                              ; preds = %434
  %440 = or disjoint i32 %13, 2
  %441 = zext nneg i32 %440 to i64
  br label %486

442:                                              ; preds = %434
  %443 = or disjoint i64 %435, 2
  %444 = add nuw nsw i32 %13, 1
  %445 = sub i32 %444, %314
  %446 = zext i32 %445 to i64
  %447 = add nsw i64 %446, -2
  %448 = sub nsw i64 %447, %435
  %449 = icmp ult i64 %448, 8
  br i1 %449, label %479, label %450

450:                                              ; preds = %442
  %451 = icmp ult i64 %448, 32
  br i1 %451, label %467, label %452

452:                                              ; preds = %450
  %453 = and i64 %448, 24
  %454 = and i64 %448, -32
  %455 = getelementptr inbounds nuw i8, ptr %5, i64 %443
  br label %456

456:                                              ; preds = %456, %452
  %457 = phi i64 [ 0, %452 ], [ %460, %456 ]
  %458 = getelementptr inbounds nuw i8, ptr %455, i64 %457
  %459 = getelementptr inbounds nuw i8, ptr %458, i64 16
  store <16 x i8> splat (i8 48), ptr %458, align 1, !tbaa !38
  store <16 x i8> splat (i8 48), ptr %459, align 1, !tbaa !38
  %460 = add nuw i64 %457, 32
  %461 = icmp eq i64 %460, %454
  br i1 %461, label %462, label %456, !llvm.loop !74

462:                                              ; preds = %456
  %463 = icmp eq i64 %448, %454
  br i1 %463, label %486, label %464

464:                                              ; preds = %462
  %465 = or disjoint i64 %443, %454
  %466 = icmp eq i64 %453, 0
  br i1 %466, label %479, label %467, !prof !75

467:                                              ; preds = %450, %464
  %468 = phi i64 [ %454, %464 ], [ 0, %450 ]
  %469 = and i64 %448, -8
  %470 = or disjoint i64 %443, %469
  %471 = getelementptr inbounds nuw i8, ptr %5, i64 %443
  br label %472

472:                                              ; preds = %472, %467
  %473 = phi i64 [ %468, %467 ], [ %475, %472 ]
  %474 = getelementptr inbounds nuw i8, ptr %471, i64 %473
  store <8 x i8> splat (i8 48), ptr %474, align 1, !tbaa !38
  %475 = add nuw i64 %473, 8
  %476 = icmp eq i64 %475, %469
  br i1 %476, label %477, label %472, !llvm.loop !76

477:                                              ; preds = %472
  %478 = icmp eq i64 %448, %469
  br i1 %478, label %486, label %479

479:                                              ; preds = %442, %464, %477
  %480 = phi i64 [ %443, %442 ], [ %465, %464 ], [ %470, %477 ]
  br label %481

481:                                              ; preds = %479, %481
  %482 = phi i64 [ %483, %481 ], [ %480, %479 ]
  %483 = add nuw nsw i64 %482, 1
  %484 = getelementptr inbounds nuw i8, ptr %5, i64 %482
  store i8 48, ptr %484, align 1, !tbaa !38
  %485 = icmp eq i64 %483, %446
  br i1 %485, label %486, label %481, !llvm.loop !77

486:                                              ; preds = %439, %477, %462, %481
  %487 = phi i64 [ %441, %439 ], [ %446, %462 ], [ %446, %477 ], [ %446, %481 ]
  %488 = add nuw nsw i64 %487, 1
  %489 = getelementptr inbounds nuw i8, ptr %5, i64 %487
  store i8 %348, ptr %489, align 1, !tbaa !38
  %490 = icmp eq i32 %432, 1
  br i1 %490, label %599, label %491

491:                                              ; preds = %486
  %492 = add nuw nsw i64 %487, 2
  %493 = getelementptr inbounds nuw i8, ptr %5, i64 %488
  store i8 %342, ptr %493, align 1, !tbaa !38
  %494 = icmp eq i32 %432, 2
  br i1 %494, label %599, label %495

495:                                              ; preds = %491
  %496 = add nuw nsw i64 %487, 3
  %497 = getelementptr inbounds nuw i8, ptr %5, i64 %492
  store i8 %336, ptr %497, align 1, !tbaa !38
  %498 = icmp eq i32 %432, 3
  br i1 %498, label %599, label %499

499:                                              ; preds = %495
  %500 = add nuw nsw i64 %487, 4
  %501 = getelementptr inbounds nuw i8, ptr %5, i64 %496
  store i8 %330, ptr %501, align 1, !tbaa !38
  %502 = icmp eq i32 %432, 4
  br i1 %502, label %599, label %503

503:                                              ; preds = %499
  %504 = add nuw nsw i64 %487, 5
  %505 = getelementptr inbounds nuw i8, ptr %5, i64 %500
  store i8 %325, ptr %505, align 1, !tbaa !38
  %506 = icmp eq i32 %432, 5
  br i1 %506, label %599, label %507

507:                                              ; preds = %503
  %508 = add nuw nsw i64 %487, 6
  %509 = getelementptr inbounds nuw i8, ptr %5, i64 %504
  store i8 %321, ptr %509, align 1, !tbaa !38
  br label %599

510:                                              ; preds = %431
  %511 = add nuw nsw i32 %314, 1
  %512 = zext nneg i32 %511 to i64
  %513 = zext nneg i32 %13 to i64
  %514 = icmp ult i32 %314, 31
  br i1 %514, label %532, label %515

515:                                              ; preds = %510
  %516 = and i64 %512, 2147483616
  %517 = or disjoint i64 %516, %513
  %518 = getelementptr i8, ptr %5, i64 %513
  br label %519

519:                                              ; preds = %519, %515
  %520 = phi i64 [ 0, %515 ], [ %527, %519 ]
  %521 = getelementptr inbounds nuw i8, ptr %7, i64 %520
  %522 = getelementptr inbounds nuw i8, ptr %521, i64 16
  %523 = load <16 x i8>, ptr %521, align 4, !tbaa !38
  %524 = load <16 x i8>, ptr %522, align 4, !tbaa !38
  %525 = getelementptr i8, ptr %518, i64 %520
  %526 = getelementptr inbounds nuw i8, ptr %525, i64 16
  store <16 x i8> %523, ptr %525, align 1, !tbaa !38
  store <16 x i8> %524, ptr %526, align 1, !tbaa !38
  %527 = add nuw i64 %520, 32
  %528 = icmp eq i64 %527, %516
  br i1 %528, label %529, label %519, !llvm.loop !78

529:                                              ; preds = %519
  %530 = icmp eq i64 %516, %512
  %531 = add nsw i64 %517, -1
  br i1 %530, label %535, label %532

532:                                              ; preds = %510, %529
  %533 = phi i64 [ %513, %510 ], [ %517, %529 ]
  %534 = phi i64 [ 0, %510 ], [ %516, %529 ]
  br label %540

535:                                              ; preds = %540, %529
  %536 = phi i64 [ %531, %529 ], [ %541, %540 ]
  %537 = phi i64 [ %517, %529 ], [ %545, %540 ]
  %538 = trunc nuw i64 %537 to i32
  %539 = icmp samesign ugt i32 %432, %511
  br i1 %539, label %549, label %602

540:                                              ; preds = %532, %540
  %541 = phi i64 [ %545, %540 ], [ %533, %532 ]
  %542 = phi i64 [ %547, %540 ], [ %534, %532 ]
  %543 = getelementptr inbounds nuw i8, ptr %7, i64 %542
  %544 = load i8, ptr %543, align 1, !tbaa !38
  %545 = add nuw nsw i64 %541, 1
  %546 = getelementptr inbounds nuw i8, ptr %5, i64 %541
  store i8 %544, ptr %546, align 1, !tbaa !38
  %547 = add nuw nsw i64 %542, 1
  %548 = icmp eq i64 %547, %512
  br i1 %548, label %535, label %540, !llvm.loop !79

549:                                              ; preds = %535
  %550 = trunc i64 %536 to i32
  %551 = and i64 %537, 4294967295
  %552 = getelementptr inbounds nuw i8, ptr %5, i64 %551
  store i8 46, ptr %552, align 1, !tbaa !38
  %553 = add i32 %550, 2
  %554 = add nsw i32 %432, -2
  %555 = sub i32 %554, %314
  %556 = zext i32 %555 to i64
  %557 = add nuw nsw i64 %556, 1
  %558 = icmp ult i32 %555, 31
  br i1 %558, label %585, label %559

559:                                              ; preds = %549
  %560 = add nsw i32 %432, -2
  %561 = sub i32 %560, %314
  %562 = sub i32 -3, %550
  %563 = icmp ult i32 %562, %561
  br i1 %563, label %585, label %564

564:                                              ; preds = %559
  %565 = and i64 %557, 8589934560
  %566 = add nuw nsw i64 %565, %512
  %567 = trunc i64 %565 to i32
  %568 = add i32 %553, %567
  %569 = getelementptr i8, ptr %7, i64 %512
  br label %570

570:                                              ; preds = %570, %564
  %571 = phi i64 [ 0, %564 ], [ %581, %570 ]
  %572 = trunc i64 %571 to i32
  %573 = add i32 %553, %572
  %574 = getelementptr i8, ptr %569, i64 %571
  %575 = getelementptr inbounds nuw i8, ptr %574, i64 16
  %576 = load <16 x i8>, ptr %574, align 1, !tbaa !38
  %577 = load <16 x i8>, ptr %575, align 1, !tbaa !38
  %578 = zext i32 %573 to i64
  %579 = getelementptr inbounds nuw i8, ptr %5, i64 %578
  %580 = getelementptr inbounds nuw i8, ptr %579, i64 16
  store <16 x i8> %576, ptr %579, align 1, !tbaa !38
  store <16 x i8> %577, ptr %580, align 1, !tbaa !38
  %581 = add nuw i64 %571, 32
  %582 = icmp eq i64 %581, %565
  br i1 %582, label %583, label %570, !llvm.loop !80

583:                                              ; preds = %570
  %584 = icmp eq i64 %557, %565
  br i1 %584, label %602, label %585

585:                                              ; preds = %559, %549, %583
  %586 = phi i64 [ %512, %559 ], [ %512, %549 ], [ %566, %583 ]
  %587 = phi i32 [ %553, %559 ], [ %553, %549 ], [ %568, %583 ]
  br label %588

588:                                              ; preds = %585, %588
  %589 = phi i64 [ %595, %588 ], [ %586, %585 ]
  %590 = phi i32 [ %596, %588 ], [ %587, %585 ]
  %591 = getelementptr inbounds nuw i8, ptr %7, i64 %589
  %592 = load i8, ptr %591, align 1, !tbaa !38
  %593 = zext i32 %590 to i64
  %594 = getelementptr inbounds nuw i8, ptr %5, i64 %593
  store i8 %592, ptr %594, align 1, !tbaa !38
  %595 = add nuw nsw i64 %589, 1
  %596 = add i32 %590, 1
  %597 = trunc i64 %595 to i32
  %598 = icmp eq i32 %432, %597
  br i1 %598, label %602, label %588, !llvm.loop !81

599:                                              ; preds = %507, %503, %499, %495, %491, %486
  %600 = phi i64 [ %488, %486 ], [ %492, %491 ], [ %496, %495 ], [ %500, %499 ], [ %504, %503 ], [ %508, %507 ]
  %601 = trunc nuw i64 %600 to i32
  br label %602

602:                                              ; preds = %588, %583, %599, %535, %414
  %603 = phi i32 [ %428, %414 ], [ %601, %599 ], [ %538, %535 ], [ %568, %583 ], [ %596, %588 ]
  %604 = zext i32 %603 to i64
  %605 = icmp ne ptr %0, null
  %606 = icmp ne ptr %3, null
  %607 = and i1 %605, %606
  br i1 %607, label %608, label %635

608:                                              ; preds = %602
  %609 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %610 = load i32, ptr %609, align 8, !tbaa !16
  %611 = icmp eq i32 %610, 0
  br i1 %611, label %612, label %635

612:                                              ; preds = %608
  %613 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %614 = load i64, ptr %613, align 8, !tbaa !30
  %615 = xor i64 %614, -1
  %616 = icmp ugt i64 %604, %615
  br i1 %616, label %635, label %617

617:                                              ; preds = %612
  %618 = add nuw nsw i64 %604, 1
  %619 = tail call noalias ptr @malloc(i64 noundef %618) #22
  %620 = icmp eq ptr %619, null
  br i1 %620, label %635, label %621

621:                                              ; preds = %617
  %622 = icmp eq i32 %603, 0
  br i1 %622, label %630, label %623

623:                                              ; preds = %621, %623
  %624 = phi i64 [ %628, %623 ], [ 0, %621 ]
  %625 = getelementptr inbounds nuw i8, ptr %5, i64 %624
  %626 = load volatile i8, ptr %625, align 1, !tbaa !38
  %627 = getelementptr inbounds nuw i8, ptr %619, i64 %624
  store volatile i8 %626, ptr %627, align 1, !tbaa !38
  %628 = add nuw nsw i64 %624, 1
  %629 = icmp eq i64 %628, %604
  br i1 %629, label %630, label %623, !llvm.loop !39

630:                                              ; preds = %623, %621
  %631 = getelementptr inbounds nuw i8, ptr %619, i64 %604
  store i8 0, ptr %631, align 1, !tbaa !38
  %632 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %619, i32 noundef %603, i32 noundef 0, i32 noundef 1, i64 noundef %604, ptr noundef %3) #23
  %633 = icmp eq i32 %632, 0
  br i1 %633, label %635, label %634

634:                                              ; preds = %630
  tail call void @free(ptr noundef nonnull %619) #22
  br label %635

635:                                              ; preds = %634, %630, %617, %612, %608, %602
  %636 = phi i32 [ 3, %617 ], [ 6, %602 ], [ 5, %608 ], [ 0, %630 ], [ %632, %634 ], [ 3, %612 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #24
  br label %637

637:                                              ; preds = %144, %635
  %638 = phi i32 [ %636, %635 ], [ 6, %144 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  br label %639

639:                                              ; preds = %19, %33, %37, %42, %58, %62, %67, %75, %79, %84, %94, %98, %637
  %640 = phi i32 [ 3, %37 ], [ %638, %637 ], [ 3, %42 ], [ 6, %19 ], [ 5, %33 ], [ 0, %58 ], [ %60, %62 ], [ 3, %84 ], [ 6, %67 ], [ 5, %75 ], [ 0, %94 ], [ %96, %98 ], [ 3, %79 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  br label %766

641:                                              ; preds = %4, %4, %4
  %642 = icmp ne ptr %0, null
  %643 = icmp ne ptr %3, null
  %644 = and i1 %642, %643
  br i1 %644, label %645, label %766

645:                                              ; preds = %641
  %646 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %647 = load i32, ptr %646, align 8, !tbaa !16
  %648 = icmp eq i32 %647, 0
  br i1 %648, label %649, label %766

649:                                              ; preds = %645
  %650 = tail call noalias ptr @malloc(i64 noundef 1) #22
  %651 = icmp eq ptr %650, null
  br i1 %651, label %766, label %652

652:                                              ; preds = %649
  store i8 0, ptr %650, align 1, !tbaa !38
  %653 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %650, i32 noundef 0, i32 noundef 0, i32 noundef 1, i64 noundef 0, ptr noundef %3) #23
  %654 = icmp eq i32 %653, 0
  br i1 %654, label %766, label %655

655:                                              ; preds = %652
  tail call void @free(ptr noundef nonnull %650) #22
  br label %766

656:                                              ; preds = %4
  %657 = icmp eq i64 %1, 0
  %658 = select i1 %657, ptr @.str.1, ptr @.str
  %659 = select i1 %657, i64 5, i64 4
  %660 = icmp ne ptr %0, null
  %661 = icmp ne ptr %3, null
  %662 = and i1 %660, %661
  br i1 %662, label %663, label %766

663:                                              ; preds = %656
  %664 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %665 = load i32, ptr %664, align 8, !tbaa !16
  %666 = icmp eq i32 %665, 0
  br i1 %666, label %667, label %766

667:                                              ; preds = %663
  %668 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %669 = load i64, ptr %668, align 8, !tbaa !30
  %670 = xor i64 %669, -1
  %671 = icmp ugt i64 %659, %670
  br i1 %671, label %766, label %672

672:                                              ; preds = %667
  %673 = add nuw nsw i64 %659, 1
  %674 = tail call noalias ptr @malloc(i64 noundef %673) #22
  %675 = icmp eq ptr %674, null
  br i1 %675, label %766, label %676

676:                                              ; preds = %672
  %677 = load volatile i8, ptr %658, align 1, !tbaa !38
  store volatile i8 %677, ptr %674, align 1, !tbaa !38
  %678 = select i1 %657, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 1), ptr getelementptr inbounds nuw (i8, ptr @.str, i64 1)
  %679 = load volatile i8, ptr %678, align 1, !tbaa !38
  %680 = getelementptr inbounds nuw i8, ptr %674, i64 1
  store volatile i8 %679, ptr %680, align 1, !tbaa !38
  %681 = select i1 %657, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 2), ptr getelementptr inbounds nuw (i8, ptr @.str, i64 2)
  %682 = load volatile i8, ptr %681, align 1, !tbaa !38
  %683 = getelementptr inbounds nuw i8, ptr %674, i64 2
  store volatile i8 %682, ptr %683, align 1, !tbaa !38
  %684 = select i1 %657, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 3), ptr getelementptr inbounds nuw (i8, ptr @.str, i64 3)
  %685 = load volatile i8, ptr %684, align 1, !tbaa !38
  %686 = getelementptr inbounds nuw i8, ptr %674, i64 3
  store volatile i8 %685, ptr %686, align 1, !tbaa !38
  br i1 %657, label %687, label %690

687:                                              ; preds = %676
  %688 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 4), align 1, !tbaa !38
  %689 = getelementptr inbounds nuw i8, ptr %674, i64 4
  store volatile i8 %688, ptr %689, align 1, !tbaa !38
  br label %690

690:                                              ; preds = %687, %676
  %691 = getelementptr inbounds nuw i8, ptr %674, i64 %659
  store i8 0, ptr %691, align 1, !tbaa !38
  %692 = trunc nuw nsw i64 %659 to i32
  %693 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %674, i32 noundef %692, i32 noundef 0, i32 noundef 1, i64 noundef %659, ptr noundef %3) #23
  %694 = icmp eq i32 %693, 0
  br i1 %694, label %766, label %695

695:                                              ; preds = %690
  tail call void @free(ptr noundef nonnull %674) #22
  br label %766

696:                                              ; preds = %4
  %697 = add i32 %2, -3
  %698 = icmp ult i32 %697, -2
  br i1 %698, label %766, label %699

699:                                              ; preds = %696
  %700 = icmp eq i32 %2, 1
  %701 = icmp slt i64 %1, 0
  %702 = and i1 %701, %700
  %703 = icmp eq i32 %2, 2
  %704 = and i64 %1, 255
  %705 = sub i64 0, %1
  %706 = select i1 %702, i64 %705, i64 %1
  %707 = select i1 %703, i64 %704, i64 %706
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #24
  br label %708

708:                                              ; preds = %708, %699
  %709 = phi i64 [ %707, %699 ], [ %712, %708 ]
  %710 = phi i32 [ 20, %699 ], [ %717, %708 ]
  %711 = freeze i64 %709
  %712 = udiv i64 %711, 10
  %713 = mul i64 %712, 10
  %714 = sub i64 %711, %713
  %715 = trunc nuw nsw i64 %714 to i8
  %716 = or disjoint i8 %715, 48
  %717 = add i32 %710, -1
  %718 = zext i32 %717 to i64
  %719 = getelementptr inbounds nuw i8, ptr %8, i64 %718
  store i8 %716, ptr %719, align 1, !tbaa !38
  %720 = icmp ult i64 %709, 10
  br i1 %720, label %721, label %708, !llvm.loop !82

721:                                              ; preds = %708
  br i1 %702, label %722, label %726

722:                                              ; preds = %721
  %723 = add i32 %710, -2
  %724 = zext i32 %723 to i64
  %725 = getelementptr inbounds nuw i8, ptr %8, i64 %724
  store i8 45, ptr %725, align 1, !tbaa !38
  br label %726

726:                                              ; preds = %722, %721
  %727 = phi i64 [ %724, %722 ], [ %718, %721 ]
  %728 = phi i32 [ %723, %722 ], [ %717, %721 ]
  %729 = getelementptr inbounds nuw i8, ptr %8, i64 %727
  %730 = sub nsw i64 20, %727
  %731 = icmp ne ptr %0, null
  %732 = icmp ne ptr %3, null
  %733 = and i1 %731, %732
  br i1 %733, label %734, label %764

734:                                              ; preds = %726
  %735 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %736 = load i32, ptr %735, align 8, !tbaa !16
  %737 = icmp eq i32 %736, 0
  br i1 %737, label %738, label %764

738:                                              ; preds = %734
  %739 = icmp ugt i64 %730, 4294967295
  br i1 %739, label %764, label %740

740:                                              ; preds = %738
  %741 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %742 = load i64, ptr %741, align 8, !tbaa !30
  %743 = xor i64 %742, -1
  %744 = icmp ugt i64 %730, %743
  br i1 %744, label %764, label %745

745:                                              ; preds = %740
  %746 = sub nsw i64 21, %727
  %747 = tail call noalias ptr @malloc(i64 noundef %746) #22
  %748 = icmp eq ptr %747, null
  br i1 %748, label %764, label %749

749:                                              ; preds = %745
  %750 = icmp eq i32 %728, 20
  br i1 %750, label %758, label %751

751:                                              ; preds = %749, %751
  %752 = phi i64 [ %756, %751 ], [ 0, %749 ]
  %753 = getelementptr inbounds nuw i8, ptr %729, i64 %752
  %754 = load volatile i8, ptr %753, align 1, !tbaa !38
  %755 = getelementptr inbounds nuw i8, ptr %747, i64 %752
  store volatile i8 %754, ptr %755, align 1, !tbaa !38
  %756 = add nuw nsw i64 %752, 1
  %757 = icmp eq i64 %756, %730
  br i1 %757, label %758, label %751, !llvm.loop !39

758:                                              ; preds = %751, %749
  %759 = getelementptr inbounds nuw i8, ptr %747, i64 %730
  store i8 0, ptr %759, align 1, !tbaa !38
  %760 = trunc nuw nsw i64 %730 to i32
  %761 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %747, i32 noundef %760, i32 noundef 0, i32 noundef 1, i64 noundef %730, ptr noundef %3) #23
  %762 = icmp eq i32 %761, 0
  br i1 %762, label %764, label %763

763:                                              ; preds = %758
  tail call void @free(ptr noundef nonnull %747) #22
  br label %764

764:                                              ; preds = %726, %734, %738, %740, %745, %758, %763
  %765 = phi i32 [ 3, %738 ], [ 6, %726 ], [ 5, %734 ], [ 0, %758 ], [ %761, %763 ], [ 3, %745 ], [ 3, %740 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #24
  br label %766

766:                                              ; preds = %695, %690, %672, %667, %663, %656, %655, %652, %649, %645, %641, %696, %764, %639
  %767 = phi i32 [ %640, %639 ], [ 1, %696 ], [ %653, %655 ], [ %765, %764 ], [ 0, %652 ], [ 6, %641 ], [ 5, %645 ], [ 3, %649 ], [ 3, %672 ], [ 6, %656 ], [ 5, %663 ], [ 0, %690 ], [ %693, %695 ], [ 3, %667 ]
  ret i32 %767
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_parse_f64(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #9 {
  %4 = alloca %struct.NbpBig, align 4
  %5 = alloca %struct.NbpBig, align 4
  %6 = alloca i64, align 8
  %7 = alloca %struct.NbpBig, align 4
  %8 = alloca %struct.NbpBig, align 4
  %9 = icmp eq ptr %0, null
  br i1 %9, label %563, label %10

10:                                               ; preds = %3
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !16
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %563

14:                                               ; preds = %10
  %15 = icmp sgt i64 %1, -1
  br i1 %15, label %42, label %16

16:                                               ; preds = %14
  %17 = and i64 %1, 9223372036854775807
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %563, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %21 = load i32, ptr %20, align 4, !tbaa !17
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %17, %22
  br i1 %23, label %563, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !18
  %27 = icmp eq ptr %26, null
  br i1 %27, label %563, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i64 %17
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !19
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %563, label %33

33:                                               ; preds = %28
  %34 = and i64 %1, 4294967295
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 28
  %37 = load i32, ptr %36, align 4, !tbaa !22
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %563

39:                                               ; preds = %33
  %40 = load ptr, ptr %35, align 8, !tbaa !23
  %41 = getelementptr inbounds nuw i8, ptr %35, i64 16
  br label %60

42:                                               ; preds = %14
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %563, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %46 = load i32, ptr %45, align 8, !tbaa !13
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %563, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %51 = load ptr, ptr %50, align 8, !tbaa !12
  %52 = icmp eq ptr %51, null
  br i1 %52, label %563, label %53

53:                                               ; preds = %49
  %54 = getelementptr %struct.NmsView, ptr %51, i64 %1
  %55 = getelementptr i8, ptr %54, i64 -16
  %56 = load ptr, ptr %55, align 8, !tbaa !24
  %57 = icmp eq ptr %56, null
  br i1 %57, label %563, label %58

58:                                               ; preds = %53
  %59 = getelementptr i8, ptr %54, i64 -8
  br label %60

60:                                               ; preds = %58, %39
  %61 = phi ptr [ %56, %58 ], [ %40, %39 ]
  %62 = phi ptr [ %59, %58 ], [ %41, %39 ]
  %63 = load i32, ptr %62, align 8, !tbaa !4
  %64 = icmp eq ptr %2, null
  br i1 %64, label %563, label %65

65:                                               ; preds = %60
  %66 = icmp eq ptr %61, null
  %67 = icmp ne i32 %63, 0
  %68 = and i1 %66, %67
  br i1 %68, label %563, label %69

69:                                               ; preds = %65
  %70 = icmp eq i32 %63, 0
  br i1 %70, label %87, label %71

71:                                               ; preds = %69
  %72 = zext i32 %63 to i64
  br label %73

73:                                               ; preds = %77, %71
  %74 = phi i64 [ 0, %71 ], [ %78, %77 ]
  %75 = getelementptr inbounds nuw i8, ptr %61, i64 %74
  %76 = load i8, ptr %75, align 1, !tbaa !38
  switch i8 %76, label %85 [
    i8 32, label %77
    i8 9, label %77
    i8 10, label %77
    i8 13, label %77
    i8 11, label %77
    i8 12, label %77
    i8 45, label %80
    i8 43, label %80
  ]

77:                                               ; preds = %73, %73, %73, %73, %73, %73
  %78 = add nuw nsw i64 %74, 1
  %79 = icmp eq i64 %78, %72
  br i1 %79, label %87, label %73, !llvm.loop !83

80:                                               ; preds = %73, %73
  %81 = trunc nuw i64 %74 to i32
  %82 = icmp eq i8 %76, 45
  %83 = select i1 %82, i64 -9223372036854775808, i64 0
  %84 = add nuw i32 %81, 1
  br label %87

85:                                               ; preds = %73
  %86 = trunc nuw i64 %74 to i32
  br label %87

87:                                               ; preds = %77, %85, %80, %69
  %88 = phi i64 [ %83, %80 ], [ 0, %69 ], [ 0, %85 ], [ 0, %77 ]
  %89 = phi i32 [ %84, %80 ], [ 0, %69 ], [ %86, %85 ], [ %63, %77 ]
  %90 = icmp ugt i32 %89, %63
  %91 = sub i32 %63, %89
  %92 = icmp ult i32 %91, 3
  %93 = or i1 %90, %92
  br i1 %93, label %257, label %94

94:                                               ; preds = %87
  %95 = zext i32 %89 to i64
  %96 = getelementptr inbounds nuw i8, ptr %61, i64 %95
  %97 = load i8, ptr %96, align 1, !tbaa !38
  %98 = add i8 %97, -65
  %99 = icmp ult i8 %98, 26
  %100 = add nuw nsw i8 %97, 32
  %101 = select i1 %99, i8 %100, i8 %97
  switch i8 %101, label %263 [
    i8 105, label %102
    i8 110, label %124
  ]

102:                                              ; preds = %94
  %103 = add i32 %89, 1
  %104 = zext i32 %103 to i64
  %105 = getelementptr inbounds nuw i8, ptr %61, i64 %104
  %106 = load i8, ptr %105, align 1, !tbaa !38
  %107 = add i8 %106, -65
  %108 = icmp ult i8 %107, 26
  %109 = add nuw nsw i8 %106, 32
  %110 = select i1 %108, i8 %109, i8 %106
  %111 = icmp eq i8 %110, 110
  br i1 %111, label %112, label %263

112:                                              ; preds = %102
  %113 = add i32 %89, 2
  %114 = zext i32 %113 to i64
  %115 = getelementptr inbounds nuw i8, ptr %61, i64 %114
  %116 = load i8, ptr %115, align 1, !tbaa !38
  %117 = add i8 %116, -65
  %118 = icmp ult i8 %117, 26
  %119 = add nuw nsw i8 %116, 32
  %120 = select i1 %118, i8 %119, i8 %116
  %121 = icmp eq i8 %120, 102
  br i1 %121, label %122, label %263

122:                                              ; preds = %112
  %123 = or disjoint i64 %88, 9218868437227405312
  br label %561

124:                                              ; preds = %94
  %125 = add i32 %89, 1
  %126 = zext i32 %125 to i64
  %127 = getelementptr inbounds nuw i8, ptr %61, i64 %126
  %128 = load i8, ptr %127, align 1, !tbaa !38
  %129 = add i8 %128, -65
  %130 = icmp ult i8 %129, 26
  %131 = add nuw nsw i8 %128, 32
  %132 = select i1 %130, i8 %131, i8 %128
  %133 = icmp eq i8 %132, 97
  br i1 %133, label %134, label %263

134:                                              ; preds = %124
  %135 = add i32 %89, 2
  %136 = zext i32 %135 to i64
  %137 = getelementptr inbounds nuw i8, ptr %61, i64 %136
  %138 = load i8, ptr %137, align 1, !tbaa !38
  %139 = add i8 %138, -65
  %140 = icmp ult i8 %139, 26
  %141 = add nuw nsw i8 %138, 32
  %142 = select i1 %140, i8 %141, i8 %138
  %143 = icmp eq i8 %142, 110
  br i1 %143, label %144, label %263

144:                                              ; preds = %134
  %145 = add i32 %89, 3
  %146 = icmp ult i32 %145, %63
  br i1 %146, label %147, label %253

147:                                              ; preds = %144
  %148 = zext i32 %145 to i64
  %149 = getelementptr inbounds nuw i8, ptr %61, i64 %148
  %150 = load i8, ptr %149, align 1, !tbaa !38
  %151 = icmp eq i8 %150, 40
  br i1 %151, label %152, label %253

152:                                              ; preds = %147
  %153 = add i32 %89, 4
  %154 = icmp ult i32 %153, %63
  br i1 %154, label %155, label %178

155:                                              ; preds = %152
  %156 = add nuw nsw i64 %148, 1
  br label %157

157:                                              ; preds = %172, %155
  %158 = phi i64 [ %156, %155 ], [ %173, %172 ]
  %159 = getelementptr inbounds nuw i8, ptr %61, i64 %158
  %160 = load i8, ptr %159, align 1, !tbaa !38
  %161 = add i8 %160, -65
  %162 = icmp ult i8 %161, 26
  %163 = add nuw nsw i8 %160, 32
  %164 = select i1 %162, i8 %163, i8 %160
  %165 = add i8 %164, -97
  %166 = icmp ult i8 %165, 26
  br i1 %166, label %172, label %167

167:                                              ; preds = %157
  %168 = add i8 %164, -48
  %169 = icmp ult i8 %168, 10
  %170 = icmp eq i8 %164, 95
  %171 = or i1 %170, %169
  br i1 %171, label %172, label %176

172:                                              ; preds = %167, %157
  %173 = add nuw nsw i64 %158, 1
  %174 = trunc i64 %173 to i32
  %175 = icmp eq i32 %63, %174
  br i1 %175, label %253, label %157

176:                                              ; preds = %167
  %177 = trunc nuw i64 %158 to i32
  br label %178

178:                                              ; preds = %176, %152
  %179 = phi i32 [ %153, %152 ], [ %177, %176 ]
  %180 = icmp eq i32 %179, %63
  br i1 %180, label %253, label %181

181:                                              ; preds = %178
  %182 = zext i32 %179 to i64
  %183 = getelementptr inbounds nuw i8, ptr %61, i64 %182
  %184 = load i8, ptr %183, align 1, !tbaa !38
  %185 = icmp eq i8 %184, 41
  br i1 %185, label %186, label %253

186:                                              ; preds = %181
  %187 = sub i32 %179, %153
  %188 = icmp ugt i32 %187, 1
  br i1 %188, label %189, label %207

189:                                              ; preds = %186
  %190 = zext i32 %153 to i64
  %191 = getelementptr inbounds nuw i8, ptr %61, i64 %190
  %192 = load i8, ptr %191, align 1, !tbaa !38
  %193 = icmp eq i8 %192, 48
  br i1 %193, label %194, label %207

194:                                              ; preds = %189
  %195 = add i32 %89, 5
  %196 = zext i32 %195 to i64
  %197 = getelementptr inbounds nuw i8, ptr %61, i64 %196
  %198 = load i8, ptr %197, align 1, !tbaa !38
  %199 = add i8 %198, -65
  %200 = icmp ult i8 %199, 26
  %201 = add nuw nsw i8 %198, 32
  %202 = select i1 %200, i8 %201, i8 %198
  %203 = icmp eq i8 %202, 120
  %204 = add i32 %89, 6
  %205 = select i1 %203, i32 %204, i32 %153
  %206 = select i1 %203, i32 16, i32 8
  br label %207

207:                                              ; preds = %194, %189, %186
  %208 = phi i32 [ %153, %189 ], [ %153, %186 ], [ %205, %194 ]
  %209 = phi i32 [ 10, %189 ], [ 10, %186 ], [ %206, %194 ]
  %210 = icmp ult i32 %208, %179
  br i1 %210, label %211, label %253

211:                                              ; preds = %207
  %212 = zext nneg i32 %209 to i64
  %213 = zext i32 %208 to i64
  br label %214

214:                                              ; preds = %239, %211
  %215 = phi i64 [ %213, %211 ], [ %247, %239 ]
  %216 = phi i64 [ 0, %211 ], [ %246, %239 ]
  %217 = getelementptr inbounds nuw i8, ptr %61, i64 %215
  %218 = load i8, ptr %217, align 1, !tbaa !38
  %219 = add i8 %218, -48
  %220 = icmp ult i8 %219, 10
  br i1 %220, label %221, label %224

221:                                              ; preds = %214
  %222 = zext nneg i8 %218 to i32
  %223 = add nsw i32 %222, -48
  br label %234

224:                                              ; preds = %214
  %225 = add i8 %218, -65
  %226 = icmp ult i8 %225, 26
  %227 = add nuw nsw i8 %218, 32
  %228 = select i1 %226, i8 %227, i8 %218
  %229 = zext nneg i8 %228 to i32
  %230 = add i8 %228, -97
  %231 = icmp ult i8 %230, 6
  %232 = add nsw i32 %229, -87
  %233 = select i1 %231, i32 %232, i32 -1
  br label %234

234:                                              ; preds = %224, %221
  %235 = phi i32 [ %223, %221 ], [ %233, %224 ]
  %236 = icmp sgt i32 %235, -1
  %237 = icmp ult i32 %235, %209
  %238 = and i1 %236, %237
  br i1 %238, label %239, label %250

239:                                              ; preds = %234
  %240 = zext nneg i32 %235 to i64
  %241 = xor i64 %240, -1
  %242 = udiv i64 %241, %212
  %243 = icmp ugt i64 %216, %242
  %244 = mul i64 %216, %212
  %245 = add i64 %244, %240
  %246 = select i1 %243, i64 -1, i64 %245
  %247 = add nuw nsw i64 %215, 1
  %248 = trunc i64 %247 to i32
  %249 = icmp eq i32 %179, %248
  br i1 %249, label %250, label %214, !llvm.loop !84

250:                                              ; preds = %239, %234
  %251 = phi i64 [ 0, %234 ], [ %246, %239 ]
  %252 = and i64 %251, 2251799813685247
  br label %253

253:                                              ; preds = %172, %250, %207, %181, %178, %147, %144
  %254 = phi i64 [ 0, %144 ], [ 0, %147 ], [ 0, %178 ], [ 0, %181 ], [ 0, %207 ], [ %252, %250 ], [ 0, %172 ]
  %255 = or disjoint i64 %88, %254
  %256 = or disjoint i64 %255, 9221120237041090560
  br label %561

257:                                              ; preds = %87
  %258 = icmp ugt i32 %91, 2
  br i1 %258, label %259, label %307

259:                                              ; preds = %257
  %260 = zext i32 %89 to i64
  %261 = getelementptr inbounds nuw i8, ptr %61, i64 %260
  %262 = load i8, ptr %261, align 1, !tbaa !38
  br label %263

263:                                              ; preds = %259, %134, %124, %112, %102, %94
  %264 = phi i8 [ %262, %259 ], [ %97, %134 ], [ %97, %124 ], [ %97, %112 ], [ %97, %102 ], [ %97, %94 ]
  %265 = icmp eq i8 %264, 48
  br i1 %265, label %266, label %307

266:                                              ; preds = %263
  %267 = add i32 %89, 1
  %268 = zext i32 %267 to i64
  %269 = getelementptr inbounds nuw i8, ptr %61, i64 %268
  %270 = load i8, ptr %269, align 1, !tbaa !38
  %271 = add i8 %270, -65
  %272 = icmp ult i8 %271, 26
  %273 = add nuw nsw i8 %270, 32
  %274 = select i1 %272, i8 %273, i8 %270
  %275 = icmp eq i8 %274, 120
  br i1 %275, label %276, label %307

276:                                              ; preds = %266
  %277 = add i32 %89, 2
  %278 = zext i32 %277 to i64
  %279 = getelementptr inbounds nuw i8, ptr %61, i64 %278
  %280 = load i8, ptr %279, align 1, !tbaa !38
  %281 = add i8 %280, -48
  %282 = icmp ult i8 %281, 10
  br i1 %282, label %306, label %283

283:                                              ; preds = %276
  %284 = add i8 %280, -65
  %285 = icmp ult i8 %284, 26
  %286 = select i1 %285, i8 -65, i8 -97
  %287 = add i8 %286, %280
  %288 = icmp ult i8 %287, 6
  br i1 %288, label %306, label %289

289:                                              ; preds = %283
  %290 = icmp ne i32 %91, 3
  %291 = icmp eq i8 %280, 46
  %292 = and i1 %290, %291
  br i1 %292, label %293, label %307

293:                                              ; preds = %289
  %294 = add i32 %89, 3
  %295 = zext i32 %294 to i64
  %296 = getelementptr inbounds nuw i8, ptr %61, i64 %295
  %297 = load i8, ptr %296, align 1, !tbaa !38
  %298 = add i8 %297, -48
  %299 = icmp ult i8 %298, 10
  br i1 %299, label %306, label %300

300:                                              ; preds = %293
  %301 = add i8 %297, -65
  %302 = icmp ult i8 %301, 26
  %303 = select i1 %302, i8 -65, i8 -97
  %304 = add i8 %303, %297
  %305 = icmp ult i8 %304, 6
  br i1 %305, label %306, label %307

306:                                              ; preds = %300, %293, %283, %276
  br label %307

307:                                              ; preds = %306, %300, %289, %266, %263, %257
  %308 = phi i32 [ 32, %306 ], [ 800, %257 ], [ 800, %300 ], [ 800, %289 ], [ 800, %266 ], [ 800, %263 ]
  %309 = phi i32 [ 112, %306 ], [ 101, %257 ], [ 101, %300 ], [ 101, %289 ], [ 101, %266 ], [ 101, %263 ]
  %310 = phi i1 [ true, %306 ], [ false, %257 ], [ false, %300 ], [ false, %289 ], [ false, %266 ], [ false, %263 ]
  %311 = phi i32 [ 16, %306 ], [ 10, %257 ], [ 10, %300 ], [ 10, %289 ], [ 10, %266 ], [ 10, %263 ]
  %312 = phi i32 [ %277, %306 ], [ %89, %257 ], [ %89, %300 ], [ %89, %289 ], [ %89, %266 ], [ %89, %263 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %4, i8 0, i64 516, i1 false)
  %313 = icmp ult i32 %312, %63
  br i1 %313, label %314, label %555

314:                                              ; preds = %307
  %315 = getelementptr inbounds nuw i8, ptr %4, i64 512
  %316 = zext nneg i32 %311 to i64
  %317 = zext i32 %312 to i64
  br label %318

318:                                              ; preds = %399, %314
  %319 = phi i64 [ %317, %314 ], [ %407, %399 ]
  %320 = phi i64 [ 0, %314 ], [ %406, %399 ]
  %321 = phi i64 [ 0, %314 ], [ %405, %399 ]
  %322 = phi i32 [ 0, %314 ], [ %404, %399 ]
  %323 = phi i32 [ 0, %314 ], [ %403, %399 ]
  %324 = phi i32 [ 0, %314 ], [ %402, %399 ]
  %325 = phi i32 [ 0, %314 ], [ %401, %399 ]
  %326 = phi i32 [ 0, %314 ], [ %400, %399 ]
  %327 = getelementptr inbounds nuw i8, ptr %61, i64 %319
  %328 = load i8, ptr %327, align 1, !tbaa !38
  %329 = add i8 %328, -48
  %330 = icmp ult i8 %329, 10
  br i1 %330, label %331, label %334

331:                                              ; preds = %318
  %332 = zext nneg i8 %328 to i32
  %333 = add nsw i32 %332, -48
  br label %344

334:                                              ; preds = %318
  %335 = add i8 %328, -65
  %336 = icmp ult i8 %335, 26
  %337 = add nuw nsw i8 %328, 32
  %338 = select i1 %336, i8 %337, i8 %328
  %339 = zext nneg i8 %338 to i32
  %340 = add i8 %338, -97
  %341 = icmp ult i8 %340, 6
  %342 = add nsw i32 %339, -87
  %343 = select i1 %341, i32 %342, i32 -1
  br label %344

344:                                              ; preds = %334, %331
  %345 = phi i32 [ %333, %331 ], [ %343, %334 ]
  %346 = icmp sgt i32 %345, -1
  %347 = icmp ult i32 %345, %311
  %348 = and i1 %346, %347
  br i1 %348, label %349, label %395

349:                                              ; preds = %344
  %350 = zext nneg i32 %325 to i64
  %351 = add nsw i64 %321, %350
  %352 = icmp ne i32 %345, 0
  %353 = icmp ne i32 %323, 0
  %354 = select i1 %352, i1 true, i1 %353
  br i1 %354, label %355, label %399, !llvm.loop !85

355:                                              ; preds = %349
  %356 = icmp ult i32 %326, %308
  br i1 %356, label %357, label %391

357:                                              ; preds = %355
  %358 = zext nneg i32 %345 to i64
  %359 = load i32, ptr %315, align 4, !tbaa !86
  %360 = icmp eq i32 %359, 0
  br i1 %360, label %363, label %365

361:                                              ; preds = %365
  %362 = icmp eq i64 %374, 0
  br i1 %362, label %389, label %379

363:                                              ; preds = %357
  %364 = icmp eq i32 %345, 0
  br i1 %364, label %389, label %382

365:                                              ; preds = %357, %365
  %366 = phi i64 [ %375, %365 ], [ 0, %357 ]
  %367 = phi i64 [ %374, %365 ], [ %358, %357 ]
  %368 = getelementptr inbounds nuw i32, ptr %4, i64 %366
  %369 = load i32, ptr %368, align 4, !tbaa !4
  %370 = zext i32 %369 to i64
  %371 = mul nuw nsw i64 %370, %316
  %372 = add nuw nsw i64 %371, %367
  %373 = trunc i64 %372 to i32
  store i32 %373, ptr %368, align 4, !tbaa !4
  %374 = lshr i64 %372, 32
  %375 = add nuw nsw i64 %366, 1
  %376 = load i32, ptr %315, align 4, !tbaa !86
  %377 = zext i32 %376 to i64
  %378 = icmp samesign ult i64 %375, %377
  br i1 %378, label %365, label %361, !llvm.loop !88

379:                                              ; preds = %361
  %380 = icmp eq i32 %376, 128
  br i1 %380, label %381, label %382

381:                                              ; preds = %379
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  br label %563

382:                                              ; preds = %363, %379
  %383 = phi i64 [ %374, %379 ], [ %358, %363 ]
  %384 = phi i32 [ %376, %379 ], [ 0, %363 ]
  %385 = trunc nuw nsw i64 %383 to i32
  %386 = add i32 %384, 1
  store i32 %386, ptr %315, align 4, !tbaa !86
  %387 = zext i32 %384 to i64
  %388 = getelementptr inbounds nuw i32, ptr %4, i64 %387
  store i32 %385, ptr %388, align 4, !tbaa !4
  br label %389

389:                                              ; preds = %382, %363, %361
  %390 = add nuw nsw i32 %326, 1
  br label %399, !llvm.loop !85

391:                                              ; preds = %355
  %392 = add nsw i64 %320, 1
  %393 = zext i1 %352 to i32
  %394 = or i32 %322, %393
  br label %399, !llvm.loop !85

395:                                              ; preds = %344
  %396 = icmp ne i8 %328, 46
  %397 = icmp ne i32 %325, 0
  %398 = select i1 %396, i1 true, i1 %397
  br i1 %398, label %410, label %399, !llvm.loop !85

399:                                              ; preds = %395, %391, %389, %349
  %400 = phi i32 [ %326, %349 ], [ %390, %389 ], [ %326, %391 ], [ %326, %395 ]
  %401 = phi i32 [ %325, %349 ], [ %325, %389 ], [ %325, %391 ], [ 1, %395 ]
  %402 = phi i32 [ 1, %349 ], [ 1, %389 ], [ 1, %391 ], [ %324, %395 ]
  %403 = phi i32 [ 0, %349 ], [ 1, %389 ], [ 1, %391 ], [ %323, %395 ]
  %404 = phi i32 [ %322, %349 ], [ %322, %389 ], [ %394, %391 ], [ %322, %395 ]
  %405 = phi i64 [ %351, %349 ], [ %351, %389 ], [ %351, %391 ], [ %321, %395 ]
  %406 = phi i64 [ %320, %349 ], [ %320, %389 ], [ %392, %391 ], [ %320, %395 ]
  %407 = add nuw nsw i64 %319, 1
  %408 = trunc i64 %407 to i32
  %409 = icmp eq i32 %63, %408
  br i1 %409, label %412, label %318

410:                                              ; preds = %395
  %411 = trunc nuw i64 %319 to i32
  br label %412, !llvm.loop !85

412:                                              ; preds = %399, %410
  %413 = phi i32 [ %326, %410 ], [ %400, %399 ]
  %414 = phi i32 [ %324, %410 ], [ %402, %399 ]
  %415 = phi i32 [ %323, %410 ], [ %403, %399 ]
  %416 = phi i32 [ %322, %410 ], [ %404, %399 ]
  %417 = phi i64 [ %321, %410 ], [ %405, %399 ]
  %418 = phi i64 [ %320, %410 ], [ %406, %399 ]
  %419 = phi i32 [ %411, %410 ], [ %63, %399 ]
  %420 = icmp eq i32 %414, 0
  br i1 %420, label %555, label %421

421:                                              ; preds = %412
  %422 = icmp ult i32 %419, %63
  br i1 %422, label %423, label %477

423:                                              ; preds = %421
  %424 = zext i32 %419 to i64
  %425 = getelementptr inbounds nuw i8, ptr %61, i64 %424
  %426 = load i8, ptr %425, align 1, !tbaa !38
  %427 = add i8 %426, -65
  %428 = icmp ult i8 %427, 26
  %429 = add nuw nsw i8 %426, 32
  %430 = select i1 %428, i8 %429, i8 %426
  %431 = zext i8 %430 to i32
  %432 = icmp eq i32 %309, %431
  br i1 %432, label %433, label %477

433:                                              ; preds = %423
  %434 = add nuw i32 %419, 1
  %435 = icmp ult i32 %434, %63
  br i1 %435, label %436, label %443

436:                                              ; preds = %433
  %437 = zext i32 %434 to i64
  %438 = getelementptr inbounds nuw i8, ptr %61, i64 %437
  %439 = load i8, ptr %438, align 1, !tbaa !38
  switch i8 %439, label %443 [
    i8 43, label %440
    i8 45, label %440
  ]

440:                                              ; preds = %436, %436
  %441 = icmp ne i8 %439, 45
  %442 = add nuw i32 %419, 2
  br label %443

443:                                              ; preds = %440, %436, %433
  %444 = phi i32 [ %442, %440 ], [ %434, %436 ], [ %434, %433 ]
  %445 = phi i1 [ %441, %440 ], [ true, %436 ], [ true, %433 ]
  %446 = icmp ult i32 %444, %63
  br i1 %446, label %447, label %477

447:                                              ; preds = %443
  %448 = zext i32 %444 to i64
  %449 = getelementptr inbounds nuw i8, ptr %61, i64 %448
  %450 = load i8, ptr %449, align 1, !tbaa !38
  %451 = add i8 %450, -48
  %452 = icmp ult i8 %451, 10
  br i1 %452, label %453, label %477

453:                                              ; preds = %447, %468
  %454 = phi i64 [ %470, %468 ], [ %448, %447 ]
  %455 = phi i64 [ %469, %468 ], [ 0, %447 ]
  %456 = getelementptr inbounds nuw i8, ptr %61, i64 %454
  %457 = load i8, ptr %456, align 1, !tbaa !38
  %458 = add i8 %457, -48
  %459 = icmp ult i8 %458, 10
  br i1 %459, label %460, label %473

460:                                              ; preds = %453
  %461 = icmp slt i64 %455, 1099511627776
  br i1 %461, label %462, label %468

462:                                              ; preds = %460
  %463 = mul nsw i64 %455, 10
  %464 = and i8 %457, 15
  %465 = zext nneg i8 %464 to i64
  %466 = add nsw i64 %463, %465
  %467 = tail call i64 @llvm.smin.i64(i64 %466, i64 1099511627776)
  br label %468

468:                                              ; preds = %462, %460
  %469 = phi i64 [ %467, %462 ], [ %455, %460 ]
  %470 = add nuw nsw i64 %454, 1
  %471 = trunc i64 %470 to i32
  %472 = icmp eq i32 %63, %471
  br i1 %472, label %473, label %453, !llvm.loop !89

473:                                              ; preds = %468, %453
  %474 = phi i64 [ %469, %468 ], [ %455, %453 ]
  %475 = sub nsw i64 0, %474
  %476 = select i1 %445, i64 %474, i64 %475
  br label %477

477:                                              ; preds = %473, %447, %443, %423, %421
  %478 = phi i64 [ 0, %421 ], [ 0, %423 ], [ %476, %473 ], [ 0, %443 ], [ 0, %447 ]
  %479 = icmp eq i32 %415, 0
  br i1 %479, label %555, label %480

480:                                              ; preds = %477
  %481 = sub nsw i64 %418, %417
  %482 = select i1 %310, i64 2, i64 0
  %483 = shl i64 %481, %482
  %484 = add i64 %478, %483
  br i1 %310, label %485, label %496

485:                                              ; preds = %480
  %486 = load i32, ptr %315, align 4, !tbaa !86
  %487 = icmp eq i32 %486, 0
  br i1 %487, label %496, label %488

488:                                              ; preds = %485
  %489 = add i32 %486, -1
  %490 = zext i32 %489 to i64
  %491 = getelementptr inbounds nuw i32, ptr %4, i64 %490
  %492 = load i32, ptr %491, align 4, !tbaa !4
  %493 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %492, i1 false)
  %494 = shl i32 %486, 5
  %495 = sub i32 %494, %493
  br label %496

496:                                              ; preds = %488, %485, %480
  %497 = phi i64 [ 308, %480 ], [ 1023, %485 ], [ 1023, %488 ]
  %498 = phi i32 [ %413, %480 ], [ 0, %485 ], [ %495, %488 ]
  %499 = zext i32 %498 to i64
  %500 = add i64 %484, -1
  %501 = add i64 %500, %499
  %502 = icmp sgt i64 %501, %497
  br i1 %502, label %503, label %505

503:                                              ; preds = %496
  %504 = or disjoint i64 %88, 9218868437227405312
  br label %555

505:                                              ; preds = %496
  %506 = select i1 %310, i64 -1075, i64 -324
  %507 = icmp slt i64 %501, %506
  br i1 %507, label %555, label %508

508:                                              ; preds = %505
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  %509 = getelementptr inbounds nuw i8, ptr %5, i64 4
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(508) %509, i8 0, i64 508, i1 false)
  %510 = getelementptr inbounds nuw i8, ptr %5, i64 512
  store i32 1, ptr %510, align 4, !tbaa !86
  store i32 1, ptr %5, align 4, !tbaa !4
  %511 = icmp slt i64 %484, 0
  %512 = select i1 %511, ptr %5, ptr %4
  %513 = tail call i64 @llvm.abs.i64(i64 %484, i1 false)
  %514 = trunc i64 %513 to i32
  br i1 %310, label %519, label %515

515:                                              ; preds = %508
  %516 = icmp eq i32 %514, 0
  br i1 %516, label %551, label %517

517:                                              ; preds = %515
  %518 = select i1 %511, ptr %510, ptr %315
  br label %522

519:                                              ; preds = %508
  %520 = call fastcc i32 @nbp_shift(ptr noundef %512, i32 noundef %514) #23
  %521 = icmp eq i32 %520, 0
  br i1 %521, label %557, label %551

522:                                              ; preds = %548, %517
  %523 = phi i32 [ 0, %517 ], [ %549, %548 ]
  %524 = load i32, ptr %518, align 4, !tbaa !86
  %525 = icmp eq i32 %524, 0
  br i1 %525, label %548, label %528

526:                                              ; preds = %528
  %527 = icmp eq i64 %537, 0
  br i1 %527, label %548, label %542

528:                                              ; preds = %522, %528
  %529 = phi i64 [ %538, %528 ], [ 0, %522 ]
  %530 = phi i64 [ %537, %528 ], [ 0, %522 ]
  %531 = getelementptr inbounds nuw i32, ptr %512, i64 %529
  %532 = load i32, ptr %531, align 4, !tbaa !4
  %533 = zext i32 %532 to i64
  %534 = mul nuw nsw i64 %533, 10
  %535 = add nuw nsw i64 %534, %530
  %536 = trunc i64 %535 to i32
  store i32 %536, ptr %531, align 4, !tbaa !4
  %537 = lshr i64 %535, 32
  %538 = add nuw nsw i64 %529, 1
  %539 = load i32, ptr %518, align 4, !tbaa !86
  %540 = zext i32 %539 to i64
  %541 = icmp samesign ult i64 %538, %540
  br i1 %541, label %528, label %526, !llvm.loop !88

542:                                              ; preds = %526
  %543 = icmp eq i32 %539, 128
  br i1 %543, label %557, label %544

544:                                              ; preds = %542
  %545 = trunc nuw nsw i64 %537 to i32
  %546 = add i32 %539, 1
  store i32 %546, ptr %518, align 4, !tbaa !86
  %547 = getelementptr inbounds nuw i32, ptr %512, i64 %540
  store i32 %545, ptr %547, align 4, !tbaa !4
  br label %548

548:                                              ; preds = %544, %526, %522
  %549 = add nuw i32 %523, 1
  %550 = icmp eq i32 %549, %514
  br i1 %550, label %551, label %522, !llvm.loop !90

551:                                              ; preds = %548, %519, %515
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %7, ptr noundef nonnull align 4 dereferenceable(516) %4, i64 516, i1 false), !tbaa.struct !91
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %8, ptr noundef nonnull align 4 dereferenceable(516) %5, i64 516, i1 false), !tbaa.struct !91
  %552 = call fastcc i32 @nbp_rational(ptr noundef dead_on_return %7, ptr noundef dead_on_return %8, i32 noundef %416, ptr noundef %6) #23
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #24
  %553 = icmp eq i32 %552, 0
  br i1 %553, label %554, label %558

554:                                              ; preds = %551
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  br label %563

555:                                              ; preds = %505, %503, %477, %412, %307
  %556 = phi i64 [ %88, %505 ], [ 0, %412 ], [ %88, %477 ], [ %504, %503 ], [ 0, %307 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  br label %561

557:                                              ; preds = %542, %519
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  br label %563

558:                                              ; preds = %551
  %559 = load i64, ptr %6, align 8, !tbaa !15
  %560 = or i64 %559, %88
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  br label %561

561:                                              ; preds = %122, %253, %555, %558
  %562 = phi i64 [ %556, %555 ], [ %560, %558 ], [ %123, %122 ], [ %256, %253 ]
  store i64 %562, ptr %2, align 8, !tbaa !15
  br label %563

563:                                              ; preds = %19, %16, %33, %24, %44, %49, %42, %10, %28, %53, %3, %561, %60, %65, %554, %381, %557
  %564 = phi i32 [ 6, %557 ], [ 0, %561 ], [ 6, %60 ], [ 6, %65 ], [ 6, %554 ], [ 6, %381 ], [ 6, %19 ], [ 6, %16 ], [ 1, %33 ], [ 6, %24 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %10 ], [ 6, %28 ], [ 6, %53 ], [ 6, %3 ]
  ret i32 %564
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_parse_i64(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #11 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %113, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %7 = load i32, ptr %6, align 8, !tbaa !16
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %113

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %37, label %11

11:                                               ; preds = %9
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %113, label %14

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %16 = load i32, ptr %15, align 4, !tbaa !17
  %17 = zext i32 %16 to i64
  %18 = icmp samesign ugt i64 %12, %17
  br i1 %18, label %113, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !18
  %22 = icmp eq ptr %21, null
  br i1 %22, label %113, label %23

23:                                               ; preds = %19
  %24 = getelementptr inbounds nuw %struct.NmsSlot, ptr %21, i64 %12
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %26 = load i64, ptr %25, align 8, !tbaa !19
  %27 = icmp eq i64 %26, 0
  br i1 %27, label %113, label %28

28:                                               ; preds = %23
  %29 = and i64 %1, 4294967295
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %21, i64 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 28
  %32 = load i32, ptr %31, align 4, !tbaa !22
  %33 = icmp eq i32 %32, 1
  br i1 %33, label %34, label %113

34:                                               ; preds = %28
  %35 = load ptr, ptr %30, align 8, !tbaa !23
  %36 = getelementptr inbounds nuw i8, ptr %30, i64 16
  br label %55

37:                                               ; preds = %9
  %38 = icmp eq i64 %1, 0
  br i1 %38, label %113, label %39

39:                                               ; preds = %37
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %41 = load i32, ptr %40, align 8, !tbaa !13
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %1, %42
  br i1 %43, label %113, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %46 = load ptr, ptr %45, align 8, !tbaa !12
  %47 = icmp eq ptr %46, null
  br i1 %47, label %113, label %48

48:                                               ; preds = %44
  %49 = getelementptr %struct.NmsView, ptr %46, i64 %1
  %50 = getelementptr i8, ptr %49, i64 -16
  %51 = load ptr, ptr %50, align 8, !tbaa !24
  %52 = icmp eq ptr %51, null
  br i1 %52, label %113, label %53

53:                                               ; preds = %48
  %54 = getelementptr i8, ptr %49, i64 -8
  br label %55

55:                                               ; preds = %53, %34
  %56 = phi ptr [ %51, %53 ], [ %35, %34 ]
  %57 = phi ptr [ %54, %53 ], [ %36, %34 ]
  %58 = load i32, ptr %57, align 8, !tbaa !4
  %59 = icmp eq ptr %2, null
  br i1 %59, label %113, label %60

60:                                               ; preds = %55
  %61 = icmp eq i32 %58, 0
  br i1 %61, label %73, label %62

62:                                               ; preds = %60
  %63 = zext i32 %58 to i64
  br label %64

64:                                               ; preds = %62, %68
  %65 = phi i64 [ 0, %62 ], [ %69, %68 ]
  %66 = getelementptr inbounds nuw i8, ptr %56, i64 %65
  %67 = load i8, ptr %66, align 1, !tbaa !38
  switch i8 %67, label %71 [
    i8 32, label %68
    i8 13, label %68
    i8 12, label %68
    i8 11, label %68
    i8 10, label %68
    i8 9, label %68
  ]

68:                                               ; preds = %64, %64, %64, %64, %64, %64
  %69 = add nuw nsw i64 %65, 1
  %70 = icmp eq i64 %69, %63
  br i1 %70, label %84, label %64

71:                                               ; preds = %64
  %72 = trunc nuw i64 %65 to i32
  br label %73

73:                                               ; preds = %71, %60
  %74 = phi i32 [ 0, %60 ], [ %72, %71 ]
  %75 = icmp ult i32 %74, %58
  br i1 %75, label %76, label %84

76:                                               ; preds = %73
  %77 = zext i32 %74 to i64
  %78 = getelementptr inbounds nuw i8, ptr %56, i64 %77
  %79 = load i8, ptr %78, align 1, !tbaa !38
  switch i8 %79, label %84 [
    i8 45, label %80
    i8 43, label %80
  ]

80:                                               ; preds = %76, %76
  %81 = icmp ne i8 %79, 45
  %82 = add nuw i32 %74, 1
  %83 = select i1 %81, i64 9223372036854775807, i64 -9223372036854775808
  br label %84

84:                                               ; preds = %68, %80, %73, %76
  %85 = phi i32 [ %82, %80 ], [ %74, %73 ], [ %74, %76 ], [ %58, %68 ]
  %86 = phi i1 [ %81, %80 ], [ true, %73 ], [ true, %76 ], [ true, %68 ]
  %87 = phi i64 [ %83, %80 ], [ 9223372036854775807, %73 ], [ 9223372036854775807, %76 ], [ 9223372036854775807, %68 ]
  %88 = zext i32 %85 to i64
  %89 = tail call i32 @llvm.umax.i32(i32 %85, i32 %58)
  %90 = zext i32 %89 to i64
  br label %91

91:                                               ; preds = %100, %84
  %92 = phi i64 [ %101, %100 ], [ %88, %84 ]
  %93 = phi i64 [ %108, %100 ], [ 0, %84 ]
  %94 = icmp eq i64 %92, %90
  br i1 %94, label %109, label %95

95:                                               ; preds = %91
  %96 = getelementptr inbounds nuw i8, ptr %56, i64 %92
  %97 = load i8, ptr %96, align 1, !tbaa !38
  %98 = add i8 %97, -58
  %99 = icmp ult i8 %98, -10
  br i1 %99, label %109, label %100

100:                                              ; preds = %95
  %101 = add nuw nsw i64 %92, 1
  %102 = and i8 %97, 15
  %103 = zext nneg i8 %102 to i64
  %104 = sub nuw i64 %87, %103
  %105 = udiv i64 %104, 10
  %106 = icmp ugt i64 %93, %105
  %107 = mul nuw nsw i64 %93, 10
  %108 = add nuw i64 %107, %103
  br i1 %106, label %109, label %91

109:                                              ; preds = %100, %95, %91
  %110 = phi i64 [ %93, %91 ], [ %93, %95 ], [ %87, %100 ]
  %111 = sub i64 0, %110
  %112 = select i1 %86, i64 %110, i64 %111
  store i64 %112, ptr %2, align 8, !tbaa !15
  br label %113

113:                                              ; preds = %14, %11, %28, %19, %39, %44, %37, %5, %23, %48, %3, %55, %109
  %114 = phi i32 [ 6, %55 ], [ 0, %109 ], [ 6, %14 ], [ 6, %11 ], [ 1, %28 ], [ 6, %19 ], [ 6, %39 ], [ 6, %44 ], [ 6, %37 ], [ 5, %5 ], [ 6, %23 ], [ 6, %48 ], [ 6, %3 ]
  ret i32 %114
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_case_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  store i64 0, ptr %5, align 8, !tbaa !15
  %6 = icmp ne ptr %3, null
  %7 = icmp ult i32 %2, 2
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %94

11:                                               ; preds = %4
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %13 = load i32, ptr %12, align 8, !tbaa !16
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %94

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %43, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %94, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %22 = load i32, ptr %21, align 4, !tbaa !17
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %94, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %27 = load ptr, ptr %26, align 8, !tbaa !18
  %28 = icmp eq ptr %27, null
  br i1 %28, label %94, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i64 %18
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load i64, ptr %31, align 8, !tbaa !19
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %94, label %34

34:                                               ; preds = %29
  %35 = and i64 %1, 4294967295
  %36 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 28
  %38 = load i32, ptr %37, align 4, !tbaa !22
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %40, label %94

40:                                               ; preds = %34
  %41 = load ptr, ptr %36, align 8, !tbaa !23
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 16
  br label %61

43:                                               ; preds = %15
  %44 = icmp eq i64 %1, 0
  br i1 %44, label %94, label %45

45:                                               ; preds = %43
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %47 = load i32, ptr %46, align 8, !tbaa !13
  %48 = zext i32 %47 to i64
  %49 = icmp samesign ugt i64 %1, %48
  br i1 %49, label %94, label %50

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !12
  %53 = icmp eq ptr %52, null
  br i1 %53, label %94, label %54

54:                                               ; preds = %50
  %55 = getelementptr %struct.NmsView, ptr %52, i64 %1
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load ptr, ptr %56, align 8, !tbaa !24
  %58 = icmp eq ptr %57, null
  br i1 %58, label %94, label %59

59:                                               ; preds = %54
  %60 = getelementptr i8, ptr %55, i64 -8
  br label %61

61:                                               ; preds = %40, %59
  %62 = phi ptr [ %57, %59 ], [ %41, %40 ]
  %63 = phi ptr [ %60, %59 ], [ %42, %40 ]
  %64 = load i32, ptr %63, align 8, !tbaa !4
  %65 = zext i32 %64 to i64
  %66 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %62, i64 noundef %65, ptr noundef null, i64 noundef 0, ptr noundef nonnull %5) #23
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %68, label %94

68:                                               ; preds = %61
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %70 = load ptr, ptr %69, align 8, !tbaa !18
  %71 = load i64, ptr %5, align 8, !tbaa !15
  %72 = and i64 %71, 4294967295
  %73 = getelementptr inbounds nuw %struct.NmsSlot, ptr %70, i64 %72
  %74 = getelementptr inbounds nuw i8, ptr %73, i64 16
  %75 = load i32, ptr %74, align 8, !tbaa !33
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %97, label %77

77:                                               ; preds = %68
  %78 = icmp eq i32 %2, 0
  %79 = select i1 %78, i8 -65, i8 -97
  %80 = select i1 %78, i8 32, i8 -32
  br label %81

81:                                               ; preds = %77, %81
  %82 = phi i64 [ 0, %77 ], [ %90, %81 ]
  %83 = load ptr, ptr %73, align 8, !tbaa !23
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 %82
  %85 = load i8, ptr %84, align 1, !tbaa !38
  %86 = add i8 %85, %79
  %87 = icmp ult i8 %86, 26
  %88 = select i1 %87, i8 %80, i8 0
  %89 = add i8 %85, %88
  store i8 %89, ptr %84, align 1, !tbaa !38
  %90 = add nuw nsw i64 %82, 1
  %91 = load i32, ptr %74, align 8, !tbaa !33
  %92 = zext i32 %91 to i64
  %93 = icmp samesign ult i64 %90, %92
  br i1 %93, label %81, label %97, !llvm.loop !92

94:                                               ; preds = %61, %20, %17, %34, %25, %45, %50, %43, %11, %29, %54, %4
  %95 = phi i32 [ %66, %61 ], [ 6, %20 ], [ 6, %17 ], [ 1, %34 ], [ 6, %25 ], [ 6, %45 ], [ 6, %50 ], [ 6, %43 ], [ 5, %11 ], [ 6, %29 ], [ 6, %54 ], [ 6, %4 ]
  %96 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #23
  br label %103

97:                                               ; preds = %81, %68
  %98 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %1) #23
  %99 = icmp eq i32 %98, 0
  br i1 %99, label %102, label %100

100:                                              ; preds = %97
  %101 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %71) #23
  br label %103

102:                                              ; preds = %97
  store i64 %71, ptr %3, align 8, !tbaa !15
  br label %103

103:                                              ; preds = %94, %102, %100
  %104 = phi i32 [ 0, %102 ], [ %98, %100 ], [ %95, %94 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  ret i32 %104
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_trim_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %55, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %7 = load i32, ptr %6, align 8, !tbaa !16
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %55

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %37, label %11

11:                                               ; preds = %9
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %55, label %14

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %16 = load i32, ptr %15, align 4, !tbaa !17
  %17 = zext i32 %16 to i64
  %18 = icmp samesign ugt i64 %12, %17
  br i1 %18, label %55, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !18
  %22 = icmp eq ptr %21, null
  br i1 %22, label %55, label %23

23:                                               ; preds = %19
  %24 = getelementptr inbounds nuw %struct.NmsSlot, ptr %21, i64 %12
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %26 = load i64, ptr %25, align 8, !tbaa !19
  %27 = icmp eq i64 %26, 0
  br i1 %27, label %55, label %28

28:                                               ; preds = %23
  %29 = and i64 %1, 4294967295
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %21, i64 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 28
  %32 = load i32, ptr %31, align 4, !tbaa !22
  %33 = icmp eq i32 %32, 1
  br i1 %33, label %34, label %55

34:                                               ; preds = %28
  %35 = load ptr, ptr %30, align 8, !tbaa !23
  %36 = getelementptr inbounds nuw i8, ptr %30, i64 16
  br label %58

37:                                               ; preds = %9
  %38 = icmp eq i64 %1, 0
  br i1 %38, label %55, label %39

39:                                               ; preds = %37
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %41 = load i32, ptr %40, align 8, !tbaa !13
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %1, %42
  br i1 %43, label %55, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %46 = load ptr, ptr %45, align 8, !tbaa !12
  %47 = icmp eq ptr %46, null
  br i1 %47, label %55, label %48

48:                                               ; preds = %44
  %49 = getelementptr %struct.NmsView, ptr %46, i64 %1
  %50 = getelementptr i8, ptr %49, i64 -16
  %51 = load ptr, ptr %50, align 8, !tbaa !24
  %52 = icmp eq ptr %51, null
  br i1 %52, label %55, label %53

53:                                               ; preds = %48
  %54 = getelementptr i8, ptr %49, i64 -8
  br label %58

55:                                               ; preds = %3, %48, %23, %5, %37, %44, %39, %19, %28, %11, %14
  %56 = phi i32 [ 6, %14 ], [ 6, %11 ], [ 1, %28 ], [ 6, %19 ], [ 6, %39 ], [ 6, %44 ], [ 6, %37 ], [ 5, %5 ], [ 6, %23 ], [ 6, %48 ], [ 6, %3 ]
  %57 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %1) #23
  br label %93

58:                                               ; preds = %53, %34
  %59 = phi ptr [ %51, %53 ], [ %35, %34 ]
  %60 = phi ptr [ %54, %53 ], [ %36, %34 ]
  %61 = load i32, ptr %60, align 8, !tbaa !4
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %88, label %63

63:                                               ; preds = %58
  %64 = zext i32 %61 to i64
  br label %65

65:                                               ; preds = %63, %69
  %66 = phi i64 [ 0, %63 ], [ %70, %69 ]
  %67 = getelementptr inbounds nuw i8, ptr %59, i64 %66
  %68 = load i8, ptr %67, align 1, !tbaa !38
  switch i8 %68, label %72 [
    i8 32, label %69
    i8 10, label %69
    i8 9, label %69
    i8 13, label %69
  ]

69:                                               ; preds = %65, %65, %65, %65
  %70 = add nuw nsw i64 %66, 1
  %71 = icmp eq i64 %70, %64
  br i1 %71, label %88, label %65, !llvm.loop !93

72:                                               ; preds = %65
  %73 = trunc nuw i64 %66 to i32
  %74 = icmp ugt i32 %61, %73
  br i1 %74, label %75, label %88

75:                                               ; preds = %72
  %76 = zext i32 %61 to i64
  br label %77

77:                                               ; preds = %75, %83
  %78 = phi i64 [ %76, %75 ], [ %79, %83 ]
  %79 = add nsw i64 %78, -1
  %80 = and i64 %79, 4294967295
  %81 = getelementptr inbounds nuw i8, ptr %59, i64 %80
  %82 = load i8, ptr %81, align 1, !tbaa !38
  switch i8 %82, label %86 [
    i8 32, label %83
    i8 10, label %83
    i8 9, label %83
    i8 13, label %83
  ]

83:                                               ; preds = %77, %77, %77, %77
  %84 = trunc i64 %79 to i32
  %85 = icmp ult i32 %73, %84
  br i1 %85, label %77, label %88, !llvm.loop !94

86:                                               ; preds = %77
  %87 = trunc nuw i64 %78 to i32
  br label %88

88:                                               ; preds = %69, %83, %86, %58, %72
  %89 = phi i32 [ %73, %72 ], [ %73, %86 ], [ 0, %58 ], [ %73, %83 ], [ %61, %69 ]
  %90 = phi i32 [ %61, %72 ], [ %87, %86 ], [ 0, %58 ], [ %73, %83 ], [ %61, %69 ]
  %91 = sub i32 %90, %89
  %92 = tail call i32 @nms_substr_owned(ptr noundef nonnull %0, i64 noundef %1, i32 noundef %89, i32 noundef %91, ptr noundef %2) #23
  br label %93

93:                                               ; preds = %88, %55
  %94 = phi i32 [ %56, %55 ], [ %92, %88 ]
  ret i32 %94
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_substr_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  %7 = icmp eq ptr %0, null
  br i1 %7, label %62, label %8

8:                                                ; preds = %5
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !16
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %62

12:                                               ; preds = %8
  %13 = icmp sgt i64 %1, -1
  br i1 %13, label %40, label %14

14:                                               ; preds = %12
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %62, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !17
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %62, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !18
  %25 = icmp eq ptr %24, null
  br i1 %25, label %62, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %15
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !19
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %62, label %31

31:                                               ; preds = %26
  %32 = and i64 %1, 4294967295
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !22
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %37, label %62

37:                                               ; preds = %31
  %38 = load ptr, ptr %33, align 8, !tbaa !23
  %39 = getelementptr inbounds nuw i8, ptr %33, i64 16
  br label %58

40:                                               ; preds = %12
  %41 = icmp eq i64 %1, 0
  br i1 %41, label %62, label %42

42:                                               ; preds = %40
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %44 = load i32, ptr %43, align 8, !tbaa !13
  %45 = zext i32 %44 to i64
  %46 = icmp samesign ugt i64 %1, %45
  br i1 %46, label %62, label %47

47:                                               ; preds = %42
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %49 = load ptr, ptr %48, align 8, !tbaa !12
  %50 = icmp eq ptr %49, null
  br i1 %50, label %62, label %51

51:                                               ; preds = %47
  %52 = getelementptr %struct.NmsView, ptr %49, i64 %1
  %53 = getelementptr i8, ptr %52, i64 -16
  %54 = load ptr, ptr %53, align 8, !tbaa !24
  %55 = icmp eq ptr %54, null
  br i1 %55, label %62, label %56

56:                                               ; preds = %51
  %57 = getelementptr i8, ptr %52, i64 -8
  br label %58

58:                                               ; preds = %56, %37
  %59 = phi ptr [ %54, %56 ], [ %38, %37 ]
  %60 = phi ptr [ %57, %56 ], [ %39, %37 ]
  %61 = icmp eq ptr %4, null
  br i1 %61, label %62, label %65

62:                                               ; preds = %58, %5, %51, %26, %8, %40, %47, %42, %22, %31, %14, %17
  %63 = phi i32 [ 6, %58 ], [ 6, %17 ], [ 6, %14 ], [ 1, %31 ], [ 6, %22 ], [ 6, %42 ], [ 6, %47 ], [ 6, %40 ], [ 5, %8 ], [ 6, %26 ], [ 6, %51 ], [ 6, %5 ]
  %64 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %1) #23
  br label %86

65:                                               ; preds = %58
  %66 = load i32, ptr %60, align 8, !tbaa !4
  %67 = icmp ult i32 %2, %66
  %68 = select i1 %67, i32 %2, i32 0
  %69 = sub nuw i32 %66, %2
  %70 = tail call i32 @llvm.umin.i32(i32 %3, i32 %69)
  %71 = select i1 %67, i32 %70, i32 0
  %72 = icmp eq i32 %71, 0
  %73 = zext i32 %68 to i64
  %74 = getelementptr inbounds nuw i8, ptr %59, i64 %73
  %75 = select i1 %72, ptr null, ptr %74
  %76 = zext i32 %71 to i64
  %77 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %75, i64 noundef %76, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #23
  %78 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %1) #23
  %79 = icmp eq i32 %77, 0
  br i1 %79, label %80, label %86

80:                                               ; preds = %65
  %81 = icmp eq i32 %78, 0
  %82 = load i64, ptr %6, align 8, !tbaa !15
  br i1 %81, label %85, label %83

83:                                               ; preds = %80
  %84 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %82) #23
  br label %86

85:                                               ; preds = %80
  store i64 %82, ptr %4, align 8, !tbaa !15
  br label %86

86:                                               ; preds = %62, %65, %85, %83
  %87 = phi i32 [ 0, %85 ], [ %78, %83 ], [ %77, %65 ], [ %63, %62 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  ret i32 %87
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_concat_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  store i64 0, ptr %5, align 8, !tbaa !15
  %6 = icmp eq ptr %0, null
  br i1 %6, label %115, label %7

7:                                                ; preds = %4
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !16
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %115

11:                                               ; preds = %7
  %12 = icmp sgt i64 %1, -1
  br i1 %12, label %39, label %13

13:                                               ; preds = %11
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %115, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %18 = load i32, ptr %17, align 4, !tbaa !17
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  br i1 %20, label %115, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %23 = load ptr, ptr %22, align 8, !tbaa !18
  %24 = icmp eq ptr %23, null
  br i1 %24, label %115, label %25

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i64 %14
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load i64, ptr %27, align 8, !tbaa !19
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %115, label %30

30:                                               ; preds = %25
  %31 = and i64 %1, 4294967295
  %32 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 28
  %34 = load i32, ptr %33, align 4, !tbaa !22
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %36, label %115

36:                                               ; preds = %30
  %37 = load ptr, ptr %32, align 8, !tbaa !23
  %38 = getelementptr inbounds nuw i8, ptr %32, i64 16
  br label %57

39:                                               ; preds = %11
  %40 = icmp eq i64 %1, 0
  br i1 %40, label %115, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %43 = load i32, ptr %42, align 8, !tbaa !13
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %1, %44
  br i1 %45, label %115, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %48 = load ptr, ptr %47, align 8, !tbaa !12
  %49 = icmp eq ptr %48, null
  br i1 %49, label %115, label %50

50:                                               ; preds = %46
  %51 = getelementptr %struct.NmsView, ptr %48, i64 %1
  %52 = getelementptr i8, ptr %51, i64 -16
  %53 = load ptr, ptr %52, align 8, !tbaa !24
  %54 = icmp eq ptr %53, null
  br i1 %54, label %115, label %55

55:                                               ; preds = %50
  %56 = getelementptr i8, ptr %51, i64 -8
  br label %57

57:                                               ; preds = %55, %36
  %58 = phi ptr [ %53, %55 ], [ %37, %36 ]
  %59 = phi ptr [ %56, %55 ], [ %38, %36 ]
  %60 = load i32, ptr %59, align 8, !tbaa !4
  %61 = icmp sgt i64 %2, -1
  br i1 %61, label %88, label %62

62:                                               ; preds = %57
  %63 = and i64 %2, 9223372036854775807
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %115, label %65

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %67 = load i32, ptr %66, align 4, !tbaa !17
  %68 = zext i32 %67 to i64
  %69 = icmp samesign ugt i64 %63, %68
  br i1 %69, label %115, label %70

70:                                               ; preds = %65
  %71 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %72 = load ptr, ptr %71, align 8, !tbaa !18
  %73 = icmp eq ptr %72, null
  br i1 %73, label %115, label %74

74:                                               ; preds = %70
  %75 = getelementptr inbounds nuw %struct.NmsSlot, ptr %72, i64 %63
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 8
  %77 = load i64, ptr %76, align 8, !tbaa !19
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %115, label %79

79:                                               ; preds = %74
  %80 = and i64 %2, 4294967295
  %81 = getelementptr inbounds nuw %struct.NmsSlot, ptr %72, i64 %80
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 28
  %83 = load i32, ptr %82, align 4, !tbaa !22
  %84 = icmp eq i32 %83, 1
  br i1 %84, label %85, label %115

85:                                               ; preds = %79
  %86 = load ptr, ptr %81, align 8, !tbaa !23
  %87 = getelementptr inbounds nuw i8, ptr %81, i64 16
  br label %106

88:                                               ; preds = %57
  %89 = icmp eq i64 %2, 0
  br i1 %89, label %115, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %92 = load i32, ptr %91, align 8, !tbaa !13
  %93 = zext i32 %92 to i64
  %94 = icmp samesign ugt i64 %2, %93
  br i1 %94, label %115, label %95

95:                                               ; preds = %90
  %96 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %97 = load ptr, ptr %96, align 8, !tbaa !12
  %98 = icmp eq ptr %97, null
  br i1 %98, label %115, label %99

99:                                               ; preds = %95
  %100 = getelementptr %struct.NmsView, ptr %97, i64 %2
  %101 = getelementptr i8, ptr %100, i64 -16
  %102 = load ptr, ptr %101, align 8, !tbaa !24
  %103 = icmp eq ptr %102, null
  br i1 %103, label %115, label %104

104:                                              ; preds = %99
  %105 = getelementptr i8, ptr %100, i64 -8
  br label %106

106:                                              ; preds = %104, %85
  %107 = phi ptr [ %102, %104 ], [ %86, %85 ]
  %108 = phi ptr [ %105, %104 ], [ %87, %85 ]
  %109 = icmp eq ptr %3, null
  br i1 %109, label %115, label %110

110:                                              ; preds = %106
  %111 = load i32, ptr %108, align 8, !tbaa !4
  %112 = zext i32 %60 to i64
  %113 = zext i32 %111 to i64
  %114 = call fastcc i32 @create_parts(ptr noundef nonnull %0, ptr noundef %58, i64 noundef %112, ptr noundef %107, i64 noundef %113, ptr noundef nonnull %5) #23
  br label %115

115:                                              ; preds = %16, %13, %30, %21, %41, %46, %39, %7, %25, %50, %4, %65, %62, %79, %70, %90, %95, %88, %74, %99, %110, %106
  %116 = phi i32 [ 6, %106 ], [ %114, %110 ], [ 6, %65 ], [ 6, %62 ], [ 1, %79 ], [ 6, %70 ], [ 6, %90 ], [ 6, %95 ], [ 6, %88 ], [ 6, %4 ], [ 6, %74 ], [ 6, %99 ], [ 6, %16 ], [ 6, %13 ], [ 1, %30 ], [ 6, %21 ], [ 6, %41 ], [ 6, %46 ], [ 6, %39 ], [ 5, %7 ], [ 6, %25 ], [ 6, %50 ]
  %117 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #23
  %118 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #23
  %119 = icmp eq i32 %116, 0
  br i1 %119, label %120, label %129

120:                                              ; preds = %115
  %121 = icmp ne i32 %117, 0
  %122 = icmp ne i32 %118, 0
  %123 = select i1 %121, i1 true, i1 %122
  %124 = load i64, ptr %5, align 8, !tbaa !15
  br i1 %123, label %125, label %128

125:                                              ; preds = %120
  %126 = call i32 @nms_release(ptr noundef %0, i64 noundef %124) #23
  %127 = select i1 %121, i32 %117, i32 %118
  br label %129

128:                                              ; preds = %120
  store i64 %124, ptr %3, align 8, !tbaa !15
  br label %129

129:                                              ; preds = %115, %128, %125
  %130 = phi i32 [ 0, %128 ], [ %127, %125 ], [ %116, %115 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  ret i32 %130
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_collect(ptr noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %51, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !16
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %51

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %9 = load i32, ptr %8, align 4, !tbaa !17
  %10 = icmp eq i32 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %12 = load ptr, ptr %11, align 8, !tbaa !18
  %13 = icmp eq ptr %12, null
  br i1 %10, label %14, label %24

14:                                               ; preds = %7
  br i1 %13, label %15, label %51

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %17 = load i64, ptr %16, align 8, !tbaa !50
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %51

19:                                               ; preds = %15
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %21 = load i64, ptr %20, align 8, !tbaa !30
  %22 = icmp eq i64 %21, 0
  %23 = select i1 %22, i32 0, i32 6
  br label %51

24:                                               ; preds = %7
  br i1 %13, label %51, label %25

25:                                               ; preds = %24
  %26 = zext i32 %9 to i64
  %27 = add nuw nsw i64 %26, 1
  %28 = shl nuw nsw i64 %27, 3
  %29 = tail call noalias ptr @malloc(i64 noundef %28) #22
  %30 = tail call noalias ptr @malloc(i64 noundef %27) #22
  %31 = shl nuw nsw i64 %27, 2
  %32 = tail call noalias ptr @malloc(i64 noundef %31) #22
  %33 = icmp ne ptr %29, null
  %34 = icmp ne ptr %30, null
  %35 = select i1 %33, i1 %34, i1 false
  %36 = icmp ne ptr %32, null
  %37 = select i1 %35, i1 %36, i1 false
  br i1 %37, label %38, label %40

38:                                               ; preds = %25
  %39 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull %0, ptr noundef nonnull %29, ptr noundef nonnull %30, ptr noundef nonnull %32) #23
  br label %42

40:                                               ; preds = %25
  %41 = icmp eq ptr %32, null
  br i1 %41, label %44, label %42

42:                                               ; preds = %38, %40
  %43 = phi i32 [ %39, %38 ], [ 3, %40 ]
  tail call void @free(ptr noundef nonnull %32) #22
  br label %44

44:                                               ; preds = %40, %42
  %45 = phi i32 [ 3, %40 ], [ %43, %42 ]
  %46 = icmp eq ptr %30, null
  br i1 %46, label %48, label %47

47:                                               ; preds = %44
  tail call void @free(ptr noundef nonnull %30) #22
  br label %48

48:                                               ; preds = %44, %47
  %49 = icmp eq ptr %29, null
  br i1 %49, label %51, label %50

50:                                               ; preds = %48
  tail call void @free(ptr noundef nonnull %29) #22
  br label %51

51:                                               ; preds = %19, %24, %14, %15, %3, %1, %50, %48
  %52 = phi i32 [ %45, %50 ], [ 6, %24 ], [ %45, %48 ], [ 6, %1 ], [ %23, %19 ], [ 6, %14 ], [ 6, %15 ], [ 5, %3 ]
  ret i32 %52
}

; Function Attrs: nounwind
define internal fastcc range(i32 0, 7) i32 @collect_with_workspace(ptr noundef captures(address_is_null) %0, ptr noundef captures(none) %1, ptr noundef captures(none) %2, ptr noundef captures(none) %3) unnamed_addr #3 {
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %6 = load i32, ptr %5, align 4, !tbaa !17
  %7 = zext i32 %6 to i64
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br label %12

12:                                               ; preds = %4, %139
  %13 = phi i64 [ 0, %4 ], [ %141, %139 ]
  %14 = phi i64 [ 0, %4 ], [ %140, %139 ]
  %15 = phi i64 [ 0, %4 ], [ %142, %139 ]
  %16 = load ptr, ptr %8, align 8, !tbaa !18
  %17 = getelementptr inbounds nuw %struct.NmsSlot, ptr %16, i64 %15
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 8
  %19 = load i64, ptr %18, align 8, !tbaa !19
  %20 = getelementptr inbounds nuw i64, ptr %1, i64 %15
  store i64 %19, ptr %20, align 8, !tbaa !15
  %21 = getelementptr inbounds nuw i8, ptr %2, i64 %15
  store i8 0, ptr %21, align 1, !tbaa !38
  %22 = load i64, ptr %18, align 8, !tbaa !19
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %39

24:                                               ; preds = %12
  %25 = getelementptr inbounds nuw i8, ptr %17, i64 28
  %26 = load i32, ptr %25, align 4, !tbaa !22
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %28, label %484

28:                                               ; preds = %24
  %29 = load ptr, ptr %17, align 8, !tbaa !23
  %30 = icmp eq ptr %29, null
  br i1 %30, label %31, label %484

31:                                               ; preds = %28
  %32 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %33 = load i32, ptr %32, align 8, !tbaa !33
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %484

35:                                               ; preds = %31
  %36 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %37 = load i32, ptr %36, align 8, !tbaa !37
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %139, label %484

39:                                               ; preds = %12
  %40 = icmp eq i64 %15, 0
  br i1 %40, label %484, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %17, i64 28
  %43 = load i32, ptr %42, align 4, !tbaa !22
  %44 = add i32 %43, -6
  %45 = icmp ult i32 %44, -5
  br i1 %45, label %484, label %46

46:                                               ; preds = %41
  %47 = icmp eq i32 %43, 1
  br i1 %47, label %48, label %55

48:                                               ; preds = %46
  %49 = load ptr, ptr %17, align 8, !tbaa !23
  %50 = icmp eq ptr %49, null
  br i1 %50, label %484, label %51

51:                                               ; preds = %48
  %52 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %53 = load i32, ptr %52, align 8, !tbaa !33
  %54 = zext i32 %53 to i64
  br label %132

55:                                               ; preds = %46
  %56 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %57 = load i32, ptr %56, align 8, !tbaa !33
  %58 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %59 = load i32, ptr %58, align 8, !tbaa !37
  %60 = icmp ugt i32 %57, %59
  br i1 %60, label %484, label %61

61:                                               ; preds = %55
  %62 = icmp eq i32 %59, 0
  br i1 %62, label %66, label %63

63:                                               ; preds = %61
  %64 = load ptr, ptr %17, align 8, !tbaa !23
  %65 = icmp eq ptr %64, null
  br i1 %65, label %484, label %66

66:                                               ; preds = %63, %61
  switch i32 %43, label %127 [
    i32 4, label %67
    i32 5, label %72
    i32 2, label %128
  ]

67:                                               ; preds = %66
  %68 = getelementptr inbounds nuw i8, ptr %17, i64 32
  %69 = load i32, ptr %68, align 8, !tbaa !44
  %70 = add i32 %69, -1
  %71 = icmp ult i32 %70, 4
  br i1 %71, label %119, label %484

72:                                               ; preds = %66
  %73 = load i32, ptr %9, align 8, !tbaa !16
  %74 = icmp eq i32 %73, 0
  br i1 %74, label %75, label %484

75:                                               ; preds = %72
  %76 = load i32, ptr %5, align 4, !tbaa !17
  %77 = zext i32 %76 to i64
  %78 = icmp samesign ugt i64 %15, %77
  br i1 %78, label %484, label %79

79:                                               ; preds = %75
  %80 = load ptr, ptr %8, align 8, !tbaa !18
  %81 = icmp eq ptr %80, null
  br i1 %81, label %484, label %82

82:                                               ; preds = %79
  %83 = getelementptr inbounds nuw %struct.NmsSlot, ptr %80, i64 %15
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 8
  %85 = load i64, ptr %84, align 8, !tbaa !19
  %86 = icmp eq i64 %85, 0
  br i1 %86, label %484, label %87

87:                                               ; preds = %82
  %88 = getelementptr inbounds nuw i8, ptr %83, i64 28
  %89 = load i32, ptr %88, align 4, !tbaa !22
  %90 = icmp eq i32 %89, 5
  br i1 %90, label %91, label %484

91:                                               ; preds = %87
  %92 = load i32, ptr %10, align 4, !tbaa !40
  %93 = icmp eq i32 %92, 0
  br i1 %93, label %484, label %94

94:                                               ; preds = %91
  %95 = load ptr, ptr %0, align 8, !tbaa !8
  %96 = icmp eq ptr %95, null
  br i1 %96, label %484, label %97

97:                                               ; preds = %94
  %98 = getelementptr inbounds nuw i8, ptr %83, i64 40
  %99 = load i32, ptr %98, align 8, !tbaa !32
  %100 = load i32, ptr %11, align 8, !tbaa !41
  %101 = icmp ult i32 %99, %100
  br i1 %101, label %102, label %484

102:                                              ; preds = %97
  %103 = zext i32 %99 to i64
  %104 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %95, i64 %103
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 4
  %106 = load i32, ptr %105, align 4, !tbaa !42
  %107 = getelementptr inbounds nuw i8, ptr %83, i64 16
  %108 = load i32, ptr %107, align 8, !tbaa !33
  %109 = icmp eq i32 %108, %106
  br i1 %109, label %110, label %484

110:                                              ; preds = %102
  %111 = getelementptr inbounds nuw i8, ptr %83, i64 24
  %112 = load i32, ptr %111, align 8, !tbaa !37
  %113 = icmp eq i32 %112, %106
  br i1 %113, label %114, label %484

114:                                              ; preds = %110
  %115 = icmp eq i32 %106, 0
  br i1 %115, label %127, label %116

116:                                              ; preds = %114
  %117 = load ptr, ptr %83, align 8, !tbaa !23
  %118 = icmp eq ptr %117, null
  br i1 %118, label %484, label %127

119:                                              ; preds = %67
  %120 = and i32 %69, 5
  %121 = icmp eq i32 %120, 1
  %122 = icmp eq i32 %69, 2
  %123 = icmp eq i32 %69, 4
  %124 = or i1 %122, %123
  %125 = zext i1 %124 to i64
  %126 = select i1 %121, i64 8, i64 %125
  br label %128

127:                                              ; preds = %116, %114, %66
  br label %128

128:                                              ; preds = %66, %119, %127
  %129 = phi i64 [ 8, %66 ], [ %126, %119 ], [ 16, %127 ]
  %130 = zext i32 %59 to i64
  %131 = mul nuw nsw i64 %129, %130
  br label %132

132:                                              ; preds = %128, %51
  %133 = phi i64 [ %54, %51 ], [ %131, %128 ]
  %134 = xor i64 %13, -1
  %135 = icmp ugt i64 %133, %134
  br i1 %135, label %484, label %136

136:                                              ; preds = %132
  %137 = add i64 %133, %13
  %138 = add i64 %14, 1
  br label %139

139:                                              ; preds = %35, %136
  %140 = phi i64 [ %138, %136 ], [ %14, %35 ]
  %141 = phi i64 [ %137, %136 ], [ %13, %35 ]
  %142 = add nuw nsw i64 %15, 1
  %143 = icmp eq i64 %15, %7
  br i1 %143, label %144, label %12, !llvm.loop !95

144:                                              ; preds = %139
  %145 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %146 = load i64, ptr %145, align 8, !tbaa !50
  %147 = icmp eq i64 %140, %146
  br i1 %147, label %148, label %484

148:                                              ; preds = %144
  %149 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %150 = load i64, ptr %149, align 8, !tbaa !30
  %151 = icmp eq i64 %141, %150
  br i1 %151, label %152, label %484

152:                                              ; preds = %148
  %153 = icmp eq i32 %6, 0
  br i1 %153, label %484, label %154

154:                                              ; preds = %152
  %155 = load ptr, ptr %8, align 8, !tbaa !18
  br label %156

156:                                              ; preds = %154, %234
  %157 = phi i64 [ 1, %154 ], [ %235, %234 ]
  %158 = getelementptr inbounds nuw %struct.NmsSlot, ptr %155, i64 %157
  %159 = getelementptr inbounds nuw i8, ptr %158, i64 28
  %160 = load i32, ptr %159, align 4, !tbaa !22
  switch i32 %160, label %234 [
    i32 5, label %161
    i32 3, label %161
    i32 2, label %161
  ]

161:                                              ; preds = %156, %156, %156
  %162 = getelementptr inbounds nuw i8, ptr %158, i64 16
  %163 = load i32, ptr %162, align 8, !tbaa !33
  %164 = icmp eq i32 %163, 0
  br i1 %164, label %234, label %165

165:                                              ; preds = %161
  %166 = getelementptr inbounds nuw i8, ptr %158, i64 32
  %167 = zext i32 %163 to i64
  br label %168

168:                                              ; preds = %165, %231
  %169 = phi i64 [ 0, %165 ], [ %232, %231 ]
  switch i32 %160, label %203 [
    i32 4, label %170
    i32 2, label %199
  ]

170:                                              ; preds = %168
  %171 = load i32, ptr %166, align 8, !tbaa !44
  %172 = and i32 %171, -3
  %173 = icmp eq i32 %172, 1
  %174 = icmp eq i32 %171, 2
  %175 = icmp eq i32 %171, 4
  %176 = or i1 %174, %175
  %177 = zext i1 %176 to i32
  %178 = select i1 %173, i32 8, i32 %177
  %179 = icmp eq i32 %178, 0
  br i1 %179, label %196, label %180

180:                                              ; preds = %170
  %181 = zext nneg i32 %178 to i64
  %182 = mul nuw nsw i64 %169, %181
  %183 = load ptr, ptr %158, align 8, !tbaa !23
  %184 = getelementptr inbounds nuw i8, ptr %183, i64 %182
  br label %185

185:                                              ; preds = %185, %180
  %186 = phi i64 [ 0, %180 ], [ %194, %185 ]
  %187 = phi i64 [ 0, %180 ], [ %193, %185 ]
  %188 = getelementptr inbounds nuw i8, ptr %184, i64 %186
  %189 = load i8, ptr %188, align 1, !tbaa !38
  %190 = zext i8 %189 to i64
  %191 = shl nuw nsw i64 %186, 3
  %192 = shl nuw i64 %190, %191
  %193 = or i64 %192, %187
  %194 = add nuw nsw i64 %186, 1
  %195 = icmp eq i64 %194, %181
  br i1 %195, label %196, label %185, !llvm.loop !45

196:                                              ; preds = %185, %170
  %197 = phi i64 [ 0, %170 ], [ %193, %185 ]
  %198 = zext i32 %171 to i64
  br label %209

199:                                              ; preds = %168
  %200 = load ptr, ptr %158, align 8, !tbaa !23
  %201 = getelementptr inbounds nuw i64, ptr %200, i64 %169
  %202 = load i64, ptr %201, align 8, !tbaa !15
  br label %209

203:                                              ; preds = %168
  %204 = load ptr, ptr %158, align 8, !tbaa !23
  %205 = getelementptr inbounds nuw %struct.NmsValue, ptr %204, i64 %169
  %206 = load i64, ptr %205, align 8, !tbaa !15
  %207 = getelementptr inbounds nuw i8, ptr %205, i64 8
  %208 = load i64, ptr %207, align 8
  br label %209

209:                                              ; preds = %196, %199, %203
  %210 = phi i64 [ %197, %196 ], [ %202, %199 ], [ %206, %203 ]
  %211 = phi i64 [ %198, %196 ], [ 5, %199 ], [ %208, %203 ]
  %212 = insertvalue [2 x i64] poison, i64 %210, 0
  %213 = insertvalue [2 x i64] %212, i64 %211, 1
  %214 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %213) #23
  %215 = icmp eq i32 %214, 0
  br i1 %215, label %216, label %484

216:                                              ; preds = %209
  %217 = trunc i64 %211 to i32
  %218 = and i32 %217, -3
  %219 = icmp ne i32 %218, 5
  %220 = icmp ne i32 %217, 8
  %221 = and i1 %220, %219
  %222 = icmp sgt i64 %210, -1
  %223 = select i1 %221, i1 true, i1 %222
  br i1 %223, label %231, label %224

224:                                              ; preds = %216
  %225 = and i64 %210, 4294967295
  %226 = getelementptr inbounds nuw i64, ptr %1, i64 %225
  %227 = load i64, ptr %226, align 8, !tbaa !15
  %228 = icmp eq i64 %227, 0
  br i1 %228, label %484, label %229

229:                                              ; preds = %224
  %230 = add i64 %227, -1
  store i64 %230, ptr %226, align 8, !tbaa !15
  br label %231

231:                                              ; preds = %229, %216
  %232 = add nuw nsw i64 %169, 1
  %233 = icmp eq i64 %232, %167
  br i1 %233, label %234, label %168, !llvm.loop !96

234:                                              ; preds = %231, %161, %156
  %235 = add nuw nsw i64 %157, 1
  %236 = icmp eq i64 %157, %7
  br i1 %236, label %239, label %156, !llvm.loop !97

237:                                              ; preds = %250
  %238 = icmp eq i64 %251, 0
  br i1 %238, label %254, label %256

239:                                              ; preds = %234, %250
  %240 = phi i64 [ %252, %250 ], [ 1, %234 ]
  %241 = phi i64 [ %251, %250 ], [ 0, %234 ]
  %242 = getelementptr inbounds nuw i64, ptr %1, i64 %240
  %243 = load i64, ptr %242, align 8, !tbaa !15
  %244 = icmp eq i64 %243, 0
  br i1 %244, label %250, label %245

245:                                              ; preds = %239
  %246 = getelementptr inbounds nuw i8, ptr %2, i64 %240
  store i8 1, ptr %246, align 1, !tbaa !38
  %247 = trunc nuw i64 %240 to i32
  %248 = add i64 %241, 1
  %249 = getelementptr inbounds nuw i32, ptr %3, i64 %241
  store i32 %247, ptr %249, align 4, !tbaa !4
  br label %250

250:                                              ; preds = %239, %245
  %251 = phi i64 [ %248, %245 ], [ %241, %239 ]
  %252 = add nuw nsw i64 %240, 1
  %253 = icmp eq i64 %240, %7
  br i1 %253, label %237, label %239, !llvm.loop !98

254:                                              ; preds = %340, %237
  %255 = load ptr, ptr %8, align 8, !tbaa !18
  br label %345

256:                                              ; preds = %237, %340
  %257 = phi i64 [ %341, %340 ], [ %251, %237 ]
  %258 = phi i64 [ %260, %340 ], [ 0, %237 ]
  %259 = load ptr, ptr %8, align 8, !tbaa !18
  %260 = add nuw i64 %258, 1
  %261 = getelementptr inbounds nuw i32, ptr %3, i64 %258
  %262 = load i32, ptr %261, align 4, !tbaa !4
  %263 = zext i32 %262 to i64
  %264 = getelementptr inbounds nuw %struct.NmsSlot, ptr %259, i64 %263
  %265 = getelementptr inbounds nuw i8, ptr %264, i64 28
  %266 = load i32, ptr %265, align 4, !tbaa !22
  switch i32 %266, label %340 [
    i32 5, label %267
    i32 3, label %267
    i32 2, label %267
  ]

267:                                              ; preds = %256, %256, %256
  %268 = getelementptr inbounds nuw i8, ptr %264, i64 16
  %269 = load i32, ptr %268, align 8, !tbaa !33
  %270 = icmp eq i32 %269, 0
  br i1 %270, label %340, label %271

271:                                              ; preds = %267
  %272 = getelementptr inbounds nuw i8, ptr %264, i64 32
  br label %273

273:                                              ; preds = %271, %334
  %274 = phi i32 [ %269, %271 ], [ %335, %334 ]
  %275 = phi i64 [ 0, %271 ], [ %337, %334 ]
  %276 = phi i64 [ %257, %271 ], [ %336, %334 ]
  %277 = load i32, ptr %265, align 4, !tbaa !22
  switch i32 %277, label %308 [
    i32 4, label %278
    i32 2, label %304
  ]

278:                                              ; preds = %273
  %279 = load i32, ptr %272, align 8, !tbaa !44
  %280 = and i32 %279, -3
  %281 = icmp eq i32 %280, 1
  %282 = icmp eq i32 %279, 2
  %283 = icmp eq i32 %279, 4
  %284 = or i1 %282, %283
  %285 = zext i1 %284 to i32
  %286 = select i1 %281, i32 8, i32 %285
  %287 = icmp eq i32 %286, 0
  br i1 %287, label %334, label %288

288:                                              ; preds = %278
  %289 = zext nneg i32 %286 to i64
  %290 = mul nuw nsw i64 %275, %289
  %291 = load ptr, ptr %264, align 8, !tbaa !23
  %292 = getelementptr inbounds nuw i8, ptr %291, i64 %290
  br label %293

293:                                              ; preds = %293, %288
  %294 = phi i64 [ 0, %288 ], [ %302, %293 ]
  %295 = phi i64 [ 0, %288 ], [ %301, %293 ]
  %296 = getelementptr inbounds nuw i8, ptr %292, i64 %294
  %297 = load i8, ptr %296, align 1, !tbaa !38
  %298 = zext i8 %297 to i64
  %299 = shl nuw nsw i64 %294, 3
  %300 = shl nuw i64 %298, %299
  %301 = or i64 %300, %295
  %302 = add nuw nsw i64 %294, 1
  %303 = icmp eq i64 %302, %289
  br i1 %303, label %315, label %293, !llvm.loop !45

304:                                              ; preds = %273
  %305 = load ptr, ptr %264, align 8, !tbaa !23
  %306 = getelementptr inbounds nuw i64, ptr %305, i64 %275
  %307 = load i64, ptr %306, align 8, !tbaa !15
  br label %315

308:                                              ; preds = %273
  %309 = load ptr, ptr %264, align 8, !tbaa !23
  %310 = getelementptr inbounds nuw %struct.NmsValue, ptr %309, i64 %275
  %311 = load i64, ptr %310, align 8, !tbaa !15
  %312 = getelementptr inbounds nuw i8, ptr %310, i64 8
  %313 = load i64, ptr %312, align 8
  %314 = trunc i64 %313 to i32
  br label %315

315:                                              ; preds = %293, %304, %308
  %316 = phi i64 [ %311, %308 ], [ %307, %304 ], [ %301, %293 ]
  %317 = phi i32 [ %314, %308 ], [ 5, %304 ], [ %279, %293 ]
  %318 = and i32 %317, -3
  %319 = icmp ne i32 %318, 5
  %320 = icmp ne i32 %317, 8
  %321 = and i1 %320, %319
  %322 = icmp sgt i64 %316, -1
  %323 = select i1 %321, i1 true, i1 %322
  br i1 %323, label %334, label %324

324:                                              ; preds = %315
  %325 = and i64 %316, 4294967295
  %326 = getelementptr inbounds nuw i8, ptr %2, i64 %325
  %327 = load i8, ptr %326, align 1, !tbaa !38
  %328 = icmp eq i8 %327, 0
  br i1 %328, label %329, label %334

329:                                              ; preds = %324
  %330 = trunc i64 %316 to i32
  store i8 1, ptr %326, align 1, !tbaa !38
  %331 = add i64 %276, 1
  %332 = getelementptr inbounds nuw i32, ptr %3, i64 %276
  store i32 %330, ptr %332, align 4, !tbaa !4
  %333 = load i32, ptr %268, align 8, !tbaa !33
  br label %334

334:                                              ; preds = %278, %324, %329, %315
  %335 = phi i32 [ %274, %315 ], [ %274, %324 ], [ %333, %329 ], [ %274, %278 ]
  %336 = phi i64 [ %276, %315 ], [ %276, %324 ], [ %331, %329 ], [ %276, %278 ]
  %337 = add nuw nsw i64 %275, 1
  %338 = zext i32 %335 to i64
  %339 = icmp samesign ult i64 %337, %338
  br i1 %339, label %273, label %340, !llvm.loop !99

340:                                              ; preds = %334, %267, %256
  %341 = phi i64 [ %257, %256 ], [ %257, %267 ], [ %336, %334 ]
  %342 = icmp ult i64 %260, %341
  br i1 %342, label %256, label %254

343:                                              ; preds = %426
  %344 = getelementptr inbounds nuw i8, ptr %0, i64 72
  br label %429

345:                                              ; preds = %254, %426
  %346 = phi i64 [ 1, %254 ], [ %427, %426 ]
  %347 = getelementptr inbounds nuw %struct.NmsSlot, ptr %255, i64 %346
  %348 = getelementptr inbounds nuw i8, ptr %2, i64 %346
  %349 = load i8, ptr %348, align 1, !tbaa !38
  %350 = icmp eq i8 %349, 0
  br i1 %350, label %351, label %426

351:                                              ; preds = %345
  %352 = getelementptr inbounds nuw i8, ptr %347, i64 8
  %353 = load i64, ptr %352, align 8, !tbaa !19
  %354 = icmp eq i64 %353, 0
  br i1 %354, label %426, label %355

355:                                              ; preds = %351
  %356 = getelementptr inbounds nuw i8, ptr %347, i64 28
  %357 = load i32, ptr %356, align 4, !tbaa !22
  switch i32 %357, label %426 [
    i32 5, label %358
    i32 3, label %358
    i32 2, label %358
  ]

358:                                              ; preds = %355, %355, %355
  %359 = getelementptr inbounds nuw i8, ptr %347, i64 16
  %360 = load i32, ptr %359, align 8, !tbaa !33
  %361 = icmp eq i32 %360, 0
  br i1 %361, label %426, label %362

362:                                              ; preds = %358
  %363 = getelementptr inbounds nuw i8, ptr %347, i64 32
  %364 = zext i32 %360 to i64
  br label %365

365:                                              ; preds = %362, %423
  %366 = phi i64 [ 0, %362 ], [ %424, %423 ]
  switch i32 %357, label %397 [
    i32 4, label %367
    i32 2, label %393
  ]

367:                                              ; preds = %365
  %368 = load i32, ptr %363, align 8, !tbaa !44
  %369 = and i32 %368, -3
  %370 = icmp eq i32 %369, 1
  %371 = icmp eq i32 %368, 2
  %372 = icmp eq i32 %368, 4
  %373 = or i1 %371, %372
  %374 = zext i1 %373 to i32
  %375 = select i1 %370, i32 8, i32 %374
  %376 = icmp eq i32 %375, 0
  br i1 %376, label %423, label %377

377:                                              ; preds = %367
  %378 = zext nneg i32 %375 to i64
  %379 = mul nuw nsw i64 %366, %378
  %380 = load ptr, ptr %347, align 8, !tbaa !23
  %381 = getelementptr inbounds nuw i8, ptr %380, i64 %379
  br label %382

382:                                              ; preds = %382, %377
  %383 = phi i64 [ 0, %377 ], [ %391, %382 ]
  %384 = phi i64 [ 0, %377 ], [ %390, %382 ]
  %385 = getelementptr inbounds nuw i8, ptr %381, i64 %383
  %386 = load i8, ptr %385, align 1, !tbaa !38
  %387 = zext i8 %386 to i64
  %388 = shl nuw nsw i64 %383, 3
  %389 = shl nuw i64 %387, %388
  %390 = or i64 %389, %384
  %391 = add nuw nsw i64 %383, 1
  %392 = icmp eq i64 %391, %378
  br i1 %392, label %404, label %382, !llvm.loop !45

393:                                              ; preds = %365
  %394 = load ptr, ptr %347, align 8, !tbaa !23
  %395 = getelementptr inbounds nuw i64, ptr %394, i64 %366
  %396 = load i64, ptr %395, align 8, !tbaa !15
  br label %404

397:                                              ; preds = %365
  %398 = load ptr, ptr %347, align 8, !tbaa !23
  %399 = getelementptr inbounds nuw %struct.NmsValue, ptr %398, i64 %366
  %400 = load i64, ptr %399, align 8, !tbaa !15
  %401 = getelementptr inbounds nuw i8, ptr %399, i64 8
  %402 = load i64, ptr %401, align 8
  %403 = trunc i64 %402 to i32
  br label %404

404:                                              ; preds = %382, %393, %397
  %405 = phi i64 [ %400, %397 ], [ %396, %393 ], [ %390, %382 ]
  %406 = phi i32 [ %403, %397 ], [ 5, %393 ], [ %368, %382 ]
  %407 = and i32 %406, -3
  %408 = icmp ne i32 %407, 5
  %409 = icmp ne i32 %406, 8
  %410 = and i1 %409, %408
  %411 = icmp sgt i64 %405, -1
  %412 = select i1 %410, i1 true, i1 %411
  br i1 %412, label %423, label %413

413:                                              ; preds = %404
  %414 = and i64 %405, 4294967295
  %415 = getelementptr inbounds nuw i8, ptr %2, i64 %414
  %416 = load i8, ptr %415, align 1, !tbaa !38
  %417 = icmp eq i8 %416, 0
  br i1 %417, label %423, label %418

418:                                              ; preds = %413
  %419 = getelementptr inbounds nuw %struct.NmsSlot, ptr %255, i64 %414
  %420 = getelementptr inbounds nuw i8, ptr %419, i64 8
  %421 = load i64, ptr %420, align 8, !tbaa !19
  %422 = add i64 %421, -1
  store i64 %422, ptr %420, align 8, !tbaa !19
  br label %423

423:                                              ; preds = %367, %413, %418, %404
  %424 = add nuw nsw i64 %366, 1
  %425 = icmp eq i64 %424, %364
  br i1 %425, label %426, label %365, !llvm.loop !100

426:                                              ; preds = %423, %358, %355, %345, %351
  %427 = add nuw nsw i64 %346, 1
  %428 = icmp eq i64 %346, %7
  br i1 %428, label %343, label %345, !llvm.loop !101

429:                                              ; preds = %343, %481
  %430 = phi i64 [ 1, %343 ], [ %482, %481 ]
  %431 = load ptr, ptr %8, align 8, !tbaa !18
  %432 = getelementptr inbounds nuw %struct.NmsSlot, ptr %431, i64 %430
  %433 = getelementptr inbounds nuw i8, ptr %2, i64 %430
  %434 = load i8, ptr %433, align 1, !tbaa !38
  %435 = icmp eq i8 %434, 0
  br i1 %435, label %436, label %481

436:                                              ; preds = %429
  %437 = getelementptr inbounds nuw i8, ptr %432, i64 8
  %438 = load i64, ptr %437, align 8, !tbaa !19
  %439 = icmp eq i64 %438, 0
  br i1 %439, label %481, label %440

440:                                              ; preds = %436
  %441 = getelementptr inbounds nuw i8, ptr %432, i64 28
  %442 = load i32, ptr %441, align 4, !tbaa !22
  %443 = icmp eq i32 %442, 1
  br i1 %443, label %444, label %448

444:                                              ; preds = %440
  %445 = getelementptr inbounds nuw i8, ptr %432, i64 16
  %446 = load i32, ptr %445, align 8, !tbaa !33
  %447 = zext i32 %446 to i64
  br label %466

448:                                              ; preds = %440
  %449 = getelementptr inbounds nuw i8, ptr %432, i64 24
  %450 = load i32, ptr %449, align 8, !tbaa !37
  switch i32 %442, label %461 [
    i32 2, label %462
    i32 4, label %451
  ]

451:                                              ; preds = %448
  %452 = getelementptr inbounds nuw i8, ptr %432, i64 32
  %453 = load i32, ptr %452, align 8, !tbaa !44
  %454 = and i32 %453, -3
  %455 = icmp eq i32 %454, 1
  %456 = icmp eq i32 %453, 2
  %457 = icmp eq i32 %453, 4
  %458 = or i1 %456, %457
  %459 = zext i1 %458 to i64
  %460 = select i1 %455, i64 8, i64 %459
  br label %462

461:                                              ; preds = %448
  br label %462

462:                                              ; preds = %448, %451, %461
  %463 = phi i64 [ 8, %448 ], [ %460, %451 ], [ 16, %461 ]
  %464 = zext i32 %450 to i64
  %465 = mul nuw nsw i64 %463, %464
  br label %466

466:                                              ; preds = %462, %444
  %467 = phi i64 [ %447, %444 ], [ %465, %462 ]
  %468 = load <2 x i64>, ptr %149, align 8, !tbaa !15
  %469 = insertelement <2 x i64> <i64 poison, i64 1>, i64 %467, i64 0
  %470 = sub <2 x i64> %468, %469
  store <2 x i64> %470, ptr %149, align 8, !tbaa !15
  %471 = load ptr, ptr %432, align 8, !tbaa !23
  %472 = icmp eq ptr %471, null
  br i1 %472, label %474, label %473

473:                                              ; preds = %466
  tail call void @free(ptr noundef nonnull %471) #22
  br label %474

474:                                              ; preds = %466, %473
  store ptr null, ptr %432, align 8, !tbaa !23
  store i64 0, ptr %437, align 8, !tbaa !19
  %475 = getelementptr inbounds nuw i8, ptr %432, i64 16
  store i32 0, ptr %475, align 8, !tbaa !33
  %476 = getelementptr inbounds nuw i8, ptr %432, i64 24
  store <4 x i32> zeroinitializer, ptr %476, align 8, !tbaa !4
  %477 = getelementptr inbounds nuw i8, ptr %432, i64 40
  store i32 0, ptr %477, align 8, !tbaa !32
  %478 = load i32, ptr %344, align 8, !tbaa !31
  %479 = getelementptr inbounds nuw i8, ptr %432, i64 20
  store i32 %478, ptr %479, align 4, !tbaa !34
  %480 = trunc nuw i64 %430 to i32
  store i32 %480, ptr %344, align 8, !tbaa !31
  br label %481

481:                                              ; preds = %429, %436, %474
  %482 = add nuw nsw i64 %430, 1
  %483 = icmp eq i64 %430, %7
  br i1 %483, label %484, label %429, !llvm.loop !102

484:                                              ; preds = %67, %116, %72, %82, %79, %75, %102, %110, %94, %97, %87, %91, %63, %55, %48, %41, %28, %31, %35, %132, %39, %24, %224, %209, %481, %152, %148, %144
  %485 = phi i32 [ 0, %152 ], [ 6, %224 ], [ 6, %144 ], [ 6, %148 ], [ 0, %481 ], [ 6, %209 ], [ 6, %24 ], [ 6, %39 ], [ 6, %132 ], [ 6, %35 ], [ 6, %31 ], [ 6, %28 ], [ 6, %41 ], [ 6, %48 ], [ 6, %55 ], [ 6, %63 ], [ 6, %91 ], [ 6, %87 ], [ 6, %97 ], [ 6, %94 ], [ 6, %110 ], [ 6, %102 ], [ 6, %75 ], [ 6, %79 ], [ 6, %82 ], [ 6, %72 ], [ 6, %116 ], [ 6, %67 ]
  ret i32 %485
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_collect_prepared(ptr noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %48, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !16
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %48

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %9 = load i32, ptr %8, align 4, !tbaa !17
  %10 = icmp eq i32 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %12 = load ptr, ptr %11, align 8, !tbaa !18
  %13 = icmp eq ptr %12, null
  br i1 %10, label %14, label %23

14:                                               ; preds = %7
  br i1 %13, label %15, label %48

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %17 = load i64, ptr %16, align 8, !tbaa !50
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %48

19:                                               ; preds = %15
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %21 = load i64, ptr %20, align 8, !tbaa !30
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %24, label %48

23:                                               ; preds = %7
  br i1 %13, label %48, label %24

24:                                               ; preds = %19, %23
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %26 = load i32, ptr %25, align 4, !tbaa !27
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %48, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %30 = load ptr, ptr %29, align 8, !tbaa !28
  %31 = icmp eq ptr %30, null
  br i1 %31, label %48, label %32

32:                                               ; preds = %28
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %34 = load i32, ptr %33, align 8, !tbaa !29
  %35 = icmp ult i32 %34, %9
  %36 = or i1 %35, %10
  %37 = select i1 %35, i32 6, i32 0
  br i1 %36, label %48, label %38

38:                                               ; preds = %32
  %39 = zext i32 %34 to i64
  %40 = add nuw nsw i64 %39, 1
  %41 = mul nuw nsw i64 %40, 9
  %42 = add nuw nsw i64 %41, 3
  %43 = and i64 %42, 274877906940
  %44 = shl nuw nsw i64 %40, 3
  %45 = getelementptr inbounds nuw i8, ptr %30, i64 %44
  %46 = getelementptr inbounds nuw i8, ptr %30, i64 %43
  %47 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull %0, ptr noundef nonnull %30, ptr noundef nonnull %45, ptr noundef nonnull %46) #23
  br label %48

48:                                               ; preds = %32, %23, %19, %14, %15, %3, %1, %24, %28, %38
  %49 = phi i32 [ 6, %24 ], [ 6, %23 ], [ %47, %38 ], [ %37, %32 ], [ 6, %28 ], [ 6, %1 ], [ 6, %19 ], [ 6, %14 ], [ 6, %15 ], [ 5, %3 ]
  ret i32 %49
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local range(i32 0, 7) i32 @nms_begin(ptr noundef captures(address_is_null) %0) local_unnamed_addr #12 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %12, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !16
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %12

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %9 = load i32, ptr %8, align 4, !tbaa !49
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %7
  store i32 1, ptr %8, align 4, !tbaa !49
  br label %12

12:                                               ; preds = %7, %3, %1, %11
  %13 = phi i32 [ 6, %1 ], [ 5, %3 ], [ 0, %11 ], [ 4, %7 ]
  ret i32 %13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local range(i64 0, 34359738368) i64 @nms_finish(ptr noundef captures(address_is_null) %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #12 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %18, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %7 = load i32, ptr %6, align 4, !tbaa !49
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %18, label %9

9:                                                ; preds = %5
  store i32 0, ptr %6, align 4, !tbaa !49
  %10 = icmp ugt i32 %1, 7
  %11 = select i1 %10, i32 6, i32 %1
  %12 = zext nneg i32 %11 to i64
  %13 = shl nuw nsw i64 %12, 32
  %14 = icmp eq i32 %11, 0
  %15 = select i1 %14, i32 %2, i32 0
  %16 = zext i32 %15 to i64
  %17 = or disjoint i64 %13, %16
  br label %18

18:                                               ; preds = %3, %5, %9
  %19 = phi i64 [ %17, %9 ], [ 25769803776, %5 ], [ 25769803776, %3 ]
  ret i64 %19
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_dispose(ptr noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %49, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %5 = load i32, ptr %4, align 4, !tbaa !49
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %49

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !16
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %49

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %13 = load i32, ptr %12, align 4, !tbaa !17
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %17, label %15

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 24
  br label %31

17:                                               ; preds = %44, %11
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %19 = load ptr, ptr %18, align 8, !tbaa !18
  %20 = icmp eq ptr %19, null
  br i1 %20, label %22, label %21

21:                                               ; preds = %17
  tail call void @free(ptr noundef nonnull %19) #22
  br label %22

22:                                               ; preds = %17, %21
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %24 = load ptr, ptr %23, align 8, !tbaa !28
  %25 = icmp eq ptr %24, null
  br i1 %25, label %27, label %26

26:                                               ; preds = %22
  tail call void @free(ptr noundef nonnull %24) #22
  br label %27

27:                                               ; preds = %22, %26
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store <2 x i32> zeroinitializer, ptr %28, align 8, !tbaa !4
  store <2 x ptr> zeroinitializer, ptr %18, align 8, !tbaa !14
  store <2 x i32> zeroinitializer, ptr %12, align 4, !tbaa !4
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 48
  store <2 x i64> zeroinitializer, ptr %29, align 8, !tbaa !15
  store ptr null, ptr %0, align 8, !tbaa !8
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store <2 x i32> zeroinitializer, ptr %30, align 8, !tbaa !4
  store i32 1, ptr %8, align 8, !tbaa !16
  br label %49

31:                                               ; preds = %15, %44
  %32 = phi i32 [ %13, %15 ], [ %45, %44 ]
  %33 = phi i64 [ 1, %15 ], [ %46, %44 ]
  %34 = load ptr, ptr %16, align 8, !tbaa !18
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %34, i64 %33
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %37 = load i64, ptr %36, align 8, !tbaa !19
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %44, label %39

39:                                               ; preds = %31
  %40 = load ptr, ptr %35, align 8, !tbaa !23
  %41 = icmp eq ptr %40, null
  br i1 %41, label %44, label %42

42:                                               ; preds = %39
  tail call void @free(ptr noundef nonnull %40) #22
  %43 = load i32, ptr %12, align 4, !tbaa !17
  br label %44

44:                                               ; preds = %42, %39, %31
  %45 = phi i32 [ %43, %42 ], [ %32, %39 ], [ %32, %31 ]
  %46 = add nuw nsw i64 %33, 1
  %47 = zext i32 %45 to i64
  %48 = icmp samesign ult i64 %33, %47
  br i1 %48, label %31, label %17, !llvm.loop !103

49:                                               ; preds = %7, %3, %1, %27
  %50 = phi i32 [ 6, %1 ], [ 4, %3 ], [ 0, %27 ], [ 0, %7 ]
  ret i32 %50
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define dso_local range(i32 0, 2) i32 @nms_reserved_entry(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #13 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %180, label %3

3:                                                ; preds = %1
  %4 = load i8, ptr %0, align 1, !tbaa !38
  %5 = icmp eq i8 %4, 110
  br i1 %5, label %6, label %179

6:                                                ; preds = %3
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %8 = load i8, ptr %7, align 1, !tbaa !38
  %9 = icmp eq i8 %8, 97
  br i1 %9, label %10, label %62

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %12 = load i8, ptr %11, align 1, !tbaa !38
  %13 = icmp eq i8 %12, 110
  br i1 %13, label %14, label %62

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %16 = load i8, ptr %15, align 1, !tbaa !38
  %17 = icmp eq i8 %16, 111
  br i1 %17, label %18, label %62

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %20 = load i8, ptr %19, align 1, !tbaa !38
  %21 = icmp eq i8 %20, 95
  br i1 %21, label %22, label %62

22:                                               ; preds = %18
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 5
  %24 = load i8, ptr %23, align 1, !tbaa !38
  %25 = icmp eq i8 %24, 116
  br i1 %25, label %26, label %62

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 6
  %28 = load i8, ptr %27, align 1, !tbaa !38
  %29 = icmp eq i8 %28, 114
  br i1 %29, label %30, label %62

30:                                               ; preds = %26
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 7
  %32 = load i8, ptr %31, align 1, !tbaa !38
  %33 = icmp eq i8 %32, 121
  br i1 %33, label %34, label %62

34:                                               ; preds = %30
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %36 = load i8, ptr %35, align 1, !tbaa !38
  %37 = icmp eq i8 %36, 95
  br i1 %37, label %38, label %62

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %40 = load i8, ptr %39, align 1, !tbaa !38
  %41 = icmp eq i8 %40, 101
  br i1 %41, label %42, label %62

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 10
  %44 = load i8, ptr %43, align 1, !tbaa !38
  %45 = icmp eq i8 %44, 110
  br i1 %45, label %46, label %62

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 11
  %48 = load i8, ptr %47, align 1, !tbaa !38
  %49 = icmp eq i8 %48, 116
  br i1 %49, label %50, label %62

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %52 = load i8, ptr %51, align 1, !tbaa !38
  %53 = icmp eq i8 %52, 114
  br i1 %53, label %54, label %62

54:                                               ; preds = %50
  %55 = getelementptr inbounds nuw i8, ptr %0, i64 13
  %56 = load i8, ptr %55, align 1, !tbaa !38
  %57 = icmp eq i8 %56, 121
  br i1 %57, label %58, label %62

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw i8, ptr %0, i64 14
  %60 = load i8, ptr %59, align 1, !tbaa !38
  %61 = icmp eq i8 %60, 0
  br i1 %61, label %180, label %62

62:                                               ; preds = %58, %54, %50, %46, %42, %38, %34, %30, %26, %22, %18, %14, %10, %6
  %63 = load i8, ptr %0, align 1, !tbaa !38
  %64 = icmp eq i8 %63, 110
  br i1 %64, label %65, label %179

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %67 = load i8, ptr %66, align 1, !tbaa !38
  %68 = icmp eq i8 %67, 97
  br i1 %68, label %69, label %113

69:                                               ; preds = %65
  %70 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %71 = load i8, ptr %70, align 1, !tbaa !38
  %72 = icmp eq i8 %71, 110
  br i1 %72, label %73, label %113

73:                                               ; preds = %69
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %75 = load i8, ptr %74, align 1, !tbaa !38
  %76 = icmp eq i8 %75, 111
  br i1 %76, label %77, label %113

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %79 = load i8, ptr %78, align 1, !tbaa !38
  %80 = icmp eq i8 %79, 95
  br i1 %80, label %81, label %113

81:                                               ; preds = %77
  %82 = getelementptr inbounds nuw i8, ptr %0, i64 5
  %83 = load i8, ptr %82, align 1, !tbaa !38
  %84 = icmp eq i8 %83, 100
  br i1 %84, label %85, label %113

85:                                               ; preds = %81
  %86 = getelementptr inbounds nuw i8, ptr %0, i64 6
  %87 = load i8, ptr %86, align 1, !tbaa !38
  %88 = icmp eq i8 %87, 105
  br i1 %88, label %89, label %113

89:                                               ; preds = %85
  %90 = getelementptr inbounds nuw i8, ptr %0, i64 7
  %91 = load i8, ptr %90, align 1, !tbaa !38
  %92 = icmp eq i8 %91, 115
  br i1 %92, label %93, label %113

93:                                               ; preds = %89
  %94 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %95 = load i8, ptr %94, align 1, !tbaa !38
  %96 = icmp eq i8 %95, 112
  br i1 %96, label %97, label %113

97:                                               ; preds = %93
  %98 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %99 = load i8, ptr %98, align 1, !tbaa !38
  %100 = icmp eq i8 %99, 111
  br i1 %100, label %101, label %113

101:                                              ; preds = %97
  %102 = getelementptr inbounds nuw i8, ptr %0, i64 10
  %103 = load i8, ptr %102, align 1, !tbaa !38
  %104 = icmp eq i8 %103, 115
  br i1 %104, label %105, label %113

105:                                              ; preds = %101
  %106 = getelementptr inbounds nuw i8, ptr %0, i64 11
  %107 = load i8, ptr %106, align 1, !tbaa !38
  %108 = icmp eq i8 %107, 101
  br i1 %108, label %109, label %113

109:                                              ; preds = %105
  %110 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %111 = load i8, ptr %110, align 1, !tbaa !38
  %112 = icmp eq i8 %111, 0
  br i1 %112, label %180, label %113

113:                                              ; preds = %109, %105, %101, %97, %93, %89, %85, %81, %77, %73, %69, %65
  %114 = load i8, ptr %0, align 1, !tbaa !38
  %115 = icmp eq i8 %114, 110
  br i1 %115, label %116, label %179

116:                                              ; preds = %113
  %117 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %118 = load i8, ptr %117, align 1, !tbaa !38
  %119 = icmp eq i8 %118, 97
  br i1 %119, label %120, label %164

120:                                              ; preds = %116
  %121 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %122 = load i8, ptr %121, align 1, !tbaa !38
  %123 = icmp eq i8 %122, 110
  br i1 %123, label %124, label %164

124:                                              ; preds = %120
  %125 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %126 = load i8, ptr %125, align 1, !tbaa !38
  %127 = icmp eq i8 %126, 111
  br i1 %127, label %128, label %164

128:                                              ; preds = %124
  %129 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %130 = load i8, ptr %129, align 1, !tbaa !38
  %131 = icmp eq i8 %130, 95
  br i1 %131, label %132, label %164

132:                                              ; preds = %128
  %133 = getelementptr inbounds nuw i8, ptr %0, i64 5
  %134 = load i8, ptr %133, align 1, !tbaa !38
  %135 = icmp eq i8 %134, 114
  br i1 %135, label %136, label %164

136:                                              ; preds = %132
  %137 = getelementptr inbounds nuw i8, ptr %0, i64 6
  %138 = load i8, ptr %137, align 1, !tbaa !38
  %139 = icmp eq i8 %138, 117
  br i1 %139, label %140, label %164

140:                                              ; preds = %136
  %141 = getelementptr inbounds nuw i8, ptr %0, i64 7
  %142 = load i8, ptr %141, align 1, !tbaa !38
  %143 = icmp eq i8 %142, 110
  br i1 %143, label %144, label %164

144:                                              ; preds = %140
  %145 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %146 = load i8, ptr %145, align 1, !tbaa !38
  %147 = icmp eq i8 %146, 116
  br i1 %147, label %148, label %164

148:                                              ; preds = %144
  %149 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %150 = load i8, ptr %149, align 1, !tbaa !38
  %151 = icmp eq i8 %150, 105
  br i1 %151, label %152, label %164

152:                                              ; preds = %148
  %153 = getelementptr inbounds nuw i8, ptr %0, i64 10
  %154 = load i8, ptr %153, align 1, !tbaa !38
  %155 = icmp eq i8 %154, 109
  br i1 %155, label %156, label %164

156:                                              ; preds = %152
  %157 = getelementptr inbounds nuw i8, ptr %0, i64 11
  %158 = load i8, ptr %157, align 1, !tbaa !38
  %159 = icmp eq i8 %158, 101
  br i1 %159, label %160, label %164

160:                                              ; preds = %156
  %161 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %162 = load i8, ptr %161, align 1, !tbaa !38
  %163 = icmp eq i8 %162, 95
  br i1 %163, label %180, label %164

164:                                              ; preds = %160, %156, %152, %148, %144, %140, %136, %132, %128, %124, %120, %116
  %165 = load i8, ptr %0, align 1, !tbaa !38
  %166 = icmp eq i8 %165, 110
  br i1 %166, label %167, label %179

167:                                              ; preds = %164
  %168 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %169 = load i8, ptr %168, align 1, !tbaa !38
  %170 = icmp eq i8 %169, 109
  br i1 %170, label %171, label %179

171:                                              ; preds = %167
  %172 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %173 = load i8, ptr %172, align 1, !tbaa !38
  %174 = icmp eq i8 %173, 115
  br i1 %174, label %175, label %179

175:                                              ; preds = %171
  %176 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %177 = load i8, ptr %176, align 1, !tbaa !38
  %178 = icmp eq i8 %177, 95
  br i1 %178, label %180, label %179

179:                                              ; preds = %62, %3, %113, %164, %167, %171, %175
  br label %180

180:                                              ; preds = %58, %109, %179, %160, %175, %1
  %181 = phi i32 [ 0, %1 ], [ 1, %58 ], [ 1, %160 ], [ 0, %179 ], [ 1, %109 ], [ 1, %175 ]
  ret i32 %181
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_split_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @split_owned(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef %3, i32 noundef 0) #23
  ret i32 %5
}

; Function Attrs: nounwind
define internal fastcc range(i32 0, 7) i32 @split_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3, i32 noundef range(i32 0, 2) %4) unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %10) #24
  store i64 0, ptr %10, align 8, !tbaa !15
  %11 = icmp ne ptr %3, null
  %12 = icmp ne ptr %0, null
  %13 = and i1 %12, %11
  br i1 %13, label %14, label %266

14:                                               ; preds = %5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %16 = load i32, ptr %15, align 8, !tbaa !16
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %266

18:                                               ; preds = %14
  %19 = icmp sgt i64 %1, -1
  br i1 %19, label %46, label %20

20:                                               ; preds = %18
  %21 = and i64 %1, 9223372036854775807
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %266, label %23

23:                                               ; preds = %20
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %25 = load i32, ptr %24, align 4, !tbaa !17
  %26 = zext i32 %25 to i64
  %27 = icmp samesign ugt i64 %21, %26
  br i1 %27, label %266, label %28

28:                                               ; preds = %23
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %30 = load ptr, ptr %29, align 8, !tbaa !18
  %31 = icmp eq ptr %30, null
  br i1 %31, label %266, label %32

32:                                               ; preds = %28
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %30, i64 %21
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !19
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %266, label %37

37:                                               ; preds = %32
  %38 = and i64 %1, 4294967295
  %39 = getelementptr inbounds nuw %struct.NmsSlot, ptr %30, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 28
  %41 = load i32, ptr %40, align 4, !tbaa !22
  %42 = icmp eq i32 %41, 1
  br i1 %42, label %43, label %266

43:                                               ; preds = %37
  %44 = load ptr, ptr %39, align 8, !tbaa !23
  %45 = getelementptr inbounds nuw i8, ptr %39, i64 16
  br label %64

46:                                               ; preds = %18
  %47 = icmp eq i64 %1, 0
  br i1 %47, label %266, label %48

48:                                               ; preds = %46
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %50 = load i32, ptr %49, align 8, !tbaa !13
  %51 = zext i32 %50 to i64
  %52 = icmp samesign ugt i64 %1, %51
  br i1 %52, label %266, label %53

53:                                               ; preds = %48
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %55 = load ptr, ptr %54, align 8, !tbaa !12
  %56 = icmp eq ptr %55, null
  br i1 %56, label %266, label %57

57:                                               ; preds = %53
  %58 = getelementptr %struct.NmsView, ptr %55, i64 %1
  %59 = getelementptr i8, ptr %58, i64 -16
  %60 = load ptr, ptr %59, align 8, !tbaa !24
  %61 = icmp eq ptr %60, null
  br i1 %61, label %266, label %62

62:                                               ; preds = %57
  %63 = getelementptr i8, ptr %58, i64 -8
  br label %64

64:                                               ; preds = %62, %43
  %65 = phi ptr [ %60, %62 ], [ %44, %43 ]
  %66 = phi ptr [ %63, %62 ], [ %45, %43 ]
  %67 = load i32, ptr %66, align 8, !tbaa !4
  %68 = icmp sgt i64 %2, -1
  br i1 %68, label %95, label %69

69:                                               ; preds = %64
  %70 = and i64 %2, 9223372036854775807
  %71 = icmp eq i64 %70, 0
  br i1 %71, label %266, label %72

72:                                               ; preds = %69
  %73 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %74 = load i32, ptr %73, align 4, !tbaa !17
  %75 = zext i32 %74 to i64
  %76 = icmp samesign ugt i64 %70, %75
  br i1 %76, label %266, label %77

77:                                               ; preds = %72
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %79 = load ptr, ptr %78, align 8, !tbaa !18
  %80 = icmp eq ptr %79, null
  br i1 %80, label %266, label %81

81:                                               ; preds = %77
  %82 = getelementptr inbounds nuw %struct.NmsSlot, ptr %79, i64 %70
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 8
  %84 = load i64, ptr %83, align 8, !tbaa !19
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %266, label %86

86:                                               ; preds = %81
  %87 = and i64 %2, 4294967295
  %88 = getelementptr inbounds nuw %struct.NmsSlot, ptr %79, i64 %87
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 28
  %90 = load i32, ptr %89, align 4, !tbaa !22
  %91 = icmp eq i32 %90, 1
  br i1 %91, label %92, label %266

92:                                               ; preds = %86
  %93 = load ptr, ptr %88, align 8, !tbaa !23
  %94 = getelementptr inbounds nuw i8, ptr %88, i64 16
  br label %113

95:                                               ; preds = %64
  %96 = icmp eq i64 %2, 0
  br i1 %96, label %266, label %97

97:                                               ; preds = %95
  %98 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %99 = load i32, ptr %98, align 8, !tbaa !13
  %100 = zext i32 %99 to i64
  %101 = icmp samesign ugt i64 %2, %100
  br i1 %101, label %266, label %102

102:                                              ; preds = %97
  %103 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %104 = load ptr, ptr %103, align 8, !tbaa !12
  %105 = icmp eq ptr %104, null
  br i1 %105, label %266, label %106

106:                                              ; preds = %102
  %107 = getelementptr %struct.NmsView, ptr %104, i64 %2
  %108 = getelementptr i8, ptr %107, i64 -16
  %109 = load ptr, ptr %108, align 8, !tbaa !24
  %110 = icmp eq ptr %109, null
  br i1 %110, label %266, label %111

111:                                              ; preds = %106
  %112 = getelementptr i8, ptr %107, i64 -8
  br label %113

113:                                              ; preds = %111, %92
  %114 = phi ptr [ %109, %111 ], [ %93, %92 ]
  %115 = phi ptr [ %112, %111 ], [ %94, %92 ]
  %116 = load i32, ptr %115, align 8, !tbaa !4
  %117 = zext i32 %116 to i64
  %118 = icmp eq i32 %4, 0
  br i1 %118, label %138, label %119

119:                                              ; preds = %113
  %120 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %121 = load i64, ptr %120, align 8, !tbaa !30
  %122 = icmp ugt i64 %121, -129
  br i1 %122, label %266, label %123

123:                                              ; preds = %119
  %124 = tail call noalias ptr @malloc(i64 noundef 128) #22
  %125 = icmp eq ptr %124, null
  br i1 %125, label %266, label %126

126:                                              ; preds = %123
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  %127 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %124, i32 noundef 0, i32 noundef 8, i32 noundef 3, i64 noundef 128, ptr noundef %6) #23
  %128 = icmp eq i32 %127, 0
  br i1 %128, label %130, label %129

129:                                              ; preds = %126
  tail call void @free(ptr noundef nonnull %124) #22
  br label %137

130:                                              ; preds = %126
  %131 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %132 = load ptr, ptr %131, align 8, !tbaa !18
  %133 = load i64, ptr %6, align 8, !tbaa !15
  %134 = and i64 %133, 4294967295
  %135 = getelementptr inbounds nuw %struct.NmsSlot, ptr %132, i64 %134
  %136 = getelementptr inbounds nuw i8, ptr %135, i64 32
  store <2 x i32> <i32 5, i32 1>, ptr %136, align 8, !tbaa !4
  store i64 %133, ptr %10, align 8, !tbaa !15
  br label %137

137:                                              ; preds = %130, %129
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  br label %140

138:                                              ; preds = %113
  %139 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 2, i64 noundef 0, ptr noundef nonnull %10) #23
  br label %140

140:                                              ; preds = %138, %137
  %141 = phi i32 [ %127, %137 ], [ %139, %138 ]
  %142 = icmp ne i32 %141, 0
  %143 = icmp ne i32 %116, 0
  %144 = select i1 %142, i1 true, i1 %143
  br i1 %144, label %189, label %145

145:                                              ; preds = %140
  %146 = icmp eq i32 %67, 0
  br i1 %146, label %266, label %147

147:                                              ; preds = %145
  %148 = load i64, ptr %10, align 8, !tbaa !15
  %149 = icmp eq ptr %65, null
  %150 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %151 = zext i32 %67 to i64
  br label %152

152:                                              ; preds = %147, %180
  %153 = phi i64 [ 0, %147 ], [ %185, %180 ]
  %154 = getelementptr inbounds nuw i8, ptr %65, i64 %153
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #24
  store i64 0, ptr %9, align 8, !tbaa !15
  br i1 %149, label %178, label %155

155:                                              ; preds = %152
  %156 = load i32, ptr %15, align 8, !tbaa !16
  %157 = icmp eq i32 %156, 0
  br i1 %157, label %158, label %178

158:                                              ; preds = %155
  %159 = load i64, ptr %150, align 8, !tbaa !30
  %160 = icmp eq i64 %159, -1
  br i1 %160, label %178, label %161

161:                                              ; preds = %158
  %162 = tail call noalias ptr @malloc(i64 noundef 2) #22
  %163 = icmp eq ptr %162, null
  br i1 %163, label %178, label %164

164:                                              ; preds = %161
  %165 = load volatile i8, ptr %154, align 1, !tbaa !38
  store volatile i8 %165, ptr %162, align 1, !tbaa !38
  %166 = getelementptr inbounds nuw i8, ptr %162, i64 1
  store i8 0, ptr %166, align 1, !tbaa !38
  %167 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %162, i32 noundef 1, i32 noundef 0, i32 noundef 1, i64 noundef 1, ptr noundef nonnull %9) #23
  %168 = icmp eq i32 %167, 0
  br i1 %168, label %170, label %169

169:                                              ; preds = %164
  tail call void @free(ptr noundef nonnull %162) #22
  br label %178

170:                                              ; preds = %164
  %171 = load i64, ptr %9, align 8, !tbaa !15
  br i1 %118, label %176, label %172

172:                                              ; preds = %170
  %173 = insertvalue [2 x i64] poison, i64 %171, 0
  %174 = insertvalue [2 x i64] %173, i64 5, 1
  %175 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %148, i64 noundef 0, [2 x i64] %174, i32 noundef 1) #23
  br label %180

176:                                              ; preds = %170
  %177 = tail call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %148, i64 noundef %171) #23
  br label %180

178:                                              ; preds = %158, %161, %155, %152, %169
  %179 = phi i32 [ %167, %169 ], [ 3, %158 ], [ 3, %161 ], [ 5, %155 ], [ 6, %152 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #24
  br label %266

180:                                              ; preds = %172, %176
  %181 = phi i32 [ %175, %172 ], [ %177, %176 ]
  %182 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %171) #23
  %183 = icmp eq i32 %181, 0
  %184 = select i1 %183, i32 %182, i32 %181
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #24
  %185 = add nuw nsw i64 %153, 1
  %186 = icmp samesign ult i64 %185, %151
  %187 = icmp eq i32 %184, 0
  %188 = select i1 %186, i1 %187, i1 false
  br i1 %188, label %152, label %266, !llvm.loop !104

189:                                              ; preds = %140
  %190 = icmp eq i32 %141, 0
  br i1 %190, label %191, label %266

191:                                              ; preds = %189
  %192 = icmp eq i32 %116, 0
  %193 = sub i32 %67, %116
  br label %194

194:                                              ; preds = %191, %237
  %195 = phi i32 [ 0, %191 ], [ %242, %237 ]
  %196 = icmp ugt i32 %195, %67
  %197 = select i1 %192, i1 true, i1 %196
  %198 = sub i32 %67, %195
  %199 = icmp ult i32 %198, %116
  %200 = icmp ugt i32 %195, %193
  %201 = or i1 %199, %200
  %202 = select i1 %197, i1 true, i1 %201
  br i1 %202, label %244, label %203

203:                                              ; preds = %194, %217
  %204 = phi i32 [ %218, %217 ], [ %195, %194 ]
  %205 = zext i32 %204 to i64
  %206 = getelementptr inbounds nuw i8, ptr %65, i64 %205
  br label %210

207:                                              ; preds = %210
  %208 = add nuw nsw i64 %211, 1
  %209 = icmp eq i64 %208, %117
  br i1 %209, label %220, label %210, !llvm.loop !105

210:                                              ; preds = %207, %203
  %211 = phi i64 [ 0, %203 ], [ %208, %207 ]
  %212 = getelementptr inbounds nuw i8, ptr %206, i64 %211
  %213 = load i8, ptr %212, align 1, !tbaa !38
  %214 = getelementptr inbounds nuw i8, ptr %114, i64 %211
  %215 = load i8, ptr %214, align 1, !tbaa !38
  %216 = icmp eq i8 %213, %215
  br i1 %216, label %207, label %217

217:                                              ; preds = %210
  %218 = add i32 %204, 1
  %219 = icmp ugt i32 %218, %193
  br i1 %219, label %244, label %203, !llvm.loop !106

220:                                              ; preds = %207
  %221 = load i64, ptr %10, align 8, !tbaa !15
  %222 = zext i32 %195 to i64
  %223 = getelementptr inbounds nuw i8, ptr %65, i64 %222
  %224 = sub i32 %204, %195
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #24
  store i64 0, ptr %8, align 8, !tbaa !15
  %225 = zext i32 %224 to i64
  %226 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %223, i64 noundef %225, ptr noundef null, i64 noundef 0, ptr noundef nonnull %8) #23
  %227 = icmp eq i32 %226, 0
  br i1 %227, label %229, label %228

228:                                              ; preds = %220
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #24
  br label %266

229:                                              ; preds = %220
  %230 = load i64, ptr %8, align 8, !tbaa !15
  br i1 %118, label %235, label %231

231:                                              ; preds = %229
  %232 = insertvalue [2 x i64] poison, i64 %230, 0
  %233 = insertvalue [2 x i64] %232, i64 5, 1
  %234 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %221, i64 noundef 0, [2 x i64] %233, i32 noundef 1) #23
  br label %237

235:                                              ; preds = %229
  %236 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %221, i64 noundef %230) #23
  br label %237

237:                                              ; preds = %231, %235
  %238 = phi i32 [ %234, %231 ], [ %236, %235 ]
  %239 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %230) #23
  %240 = icmp eq i32 %238, 0
  %241 = select i1 %240, i32 %239, i32 %238
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #24
  %242 = add i32 %204, %116
  %243 = icmp eq i32 %241, 0
  br i1 %243, label %194, label %266, !llvm.loop !107

244:                                              ; preds = %194, %217
  %245 = load i64, ptr %10, align 8, !tbaa !15
  %246 = zext i32 %195 to i64
  %247 = getelementptr inbounds nuw i8, ptr %65, i64 %246
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #24
  store i64 0, ptr %7, align 8, !tbaa !15
  %248 = zext i32 %198 to i64
  %249 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %247, i64 noundef %248, ptr noundef null, i64 noundef 0, ptr noundef nonnull %7) #23
  %250 = icmp eq i32 %249, 0
  br i1 %250, label %251, label %264

251:                                              ; preds = %244
  %252 = load i64, ptr %7, align 8, !tbaa !15
  br i1 %118, label %257, label %253

253:                                              ; preds = %251
  %254 = insertvalue [2 x i64] poison, i64 %252, 0
  %255 = insertvalue [2 x i64] %254, i64 5, 1
  %256 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %245, i64 noundef 0, [2 x i64] %255, i32 noundef 1) #23
  br label %259

257:                                              ; preds = %251
  %258 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %245, i64 noundef %252) #23
  br label %259

259:                                              ; preds = %257, %253
  %260 = phi i32 [ %256, %253 ], [ %258, %257 ]
  %261 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %252) #23
  %262 = icmp eq i32 %260, 0
  %263 = select i1 %262, i32 %261, i32 %260
  br label %264

264:                                              ; preds = %244, %259
  %265 = phi i32 [ %263, %259 ], [ %249, %244 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #24
  br label %266

266:                                              ; preds = %180, %237, %178, %228, %145, %119, %123, %106, %81, %95, %102, %97, %77, %86, %69, %72, %5, %57, %32, %14, %46, %53, %48, %28, %37, %20, %23, %264, %189
  %267 = phi i32 [ 6, %5 ], [ %141, %189 ], [ 6, %32 ], [ %265, %264 ], [ 6, %57 ], [ 0, %145 ], [ 3, %123 ], [ 3, %119 ], [ 6, %72 ], [ 6, %69 ], [ 1, %86 ], [ 6, %77 ], [ 6, %97 ], [ 6, %102 ], [ 6, %95 ], [ %241, %237 ], [ 6, %81 ], [ 6, %106 ], [ 6, %23 ], [ 6, %20 ], [ 1, %37 ], [ 6, %28 ], [ 6, %48 ], [ 6, %53 ], [ 6, %46 ], [ 5, %14 ], [ %226, %228 ], [ %179, %178 ], [ %184, %180 ]
  %268 = freeze i32 %267
  %269 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #23
  %270 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #23
  %271 = icmp eq i32 %268, 0
  %272 = icmp eq i32 %269, 0
  %273 = select i1 %272, i32 %270, i32 %269
  %274 = select i1 %271, i32 %273, i32 %268
  %275 = icmp eq i32 %274, 0
  %276 = load i64, ptr %10, align 8, !tbaa !15
  br i1 %275, label %281, label %277

277:                                              ; preds = %266
  %278 = icmp eq i64 %276, 0
  br i1 %278, label %282, label %279

279:                                              ; preds = %277
  %280 = call i32 @nms_release(ptr noundef %0, i64 noundef %276) #23
  br label %282

281:                                              ; preds = %266
  store i64 %276, ptr %3, align 8, !tbaa !15
  br label %282

282:                                              ; preds = %277, %279, %281
  call void @llvm.lifetime.end.p0(ptr nonnull %10) #24
  ret i32 %274
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_split_values_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @split_owned(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef %3, i32 noundef 1) #23
  ret i32 %5
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_replace_owned(ptr noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i64 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  %7 = icmp ne ptr %4, null
  %8 = icmp ne ptr %0, null
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %301

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !16
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %301

14:                                               ; preds = %10
  %15 = icmp sgt i64 %1, -1
  br i1 %15, label %42, label %16

16:                                               ; preds = %14
  %17 = and i64 %1, 9223372036854775807
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %301, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %21 = load i32, ptr %20, align 4, !tbaa !17
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %17, %22
  br i1 %23, label %301, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !18
  %27 = icmp eq ptr %26, null
  br i1 %27, label %301, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i64 %17
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !19
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %301, label %33

33:                                               ; preds = %28
  %34 = and i64 %1, 4294967295
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %26, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 28
  %37 = load i32, ptr %36, align 4, !tbaa !22
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %301

39:                                               ; preds = %33
  %40 = load ptr, ptr %35, align 8, !tbaa !23
  %41 = getelementptr inbounds nuw i8, ptr %35, i64 16
  br label %60

42:                                               ; preds = %14
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %301, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %46 = load i32, ptr %45, align 8, !tbaa !13
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %301, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %51 = load ptr, ptr %50, align 8, !tbaa !12
  %52 = icmp eq ptr %51, null
  br i1 %52, label %301, label %53

53:                                               ; preds = %49
  %54 = getelementptr %struct.NmsView, ptr %51, i64 %1
  %55 = getelementptr i8, ptr %54, i64 -16
  %56 = load ptr, ptr %55, align 8, !tbaa !24
  %57 = icmp eq ptr %56, null
  br i1 %57, label %301, label %58

58:                                               ; preds = %53
  %59 = getelementptr i8, ptr %54, i64 -8
  br label %60

60:                                               ; preds = %58, %39
  %61 = phi ptr [ %56, %58 ], [ %40, %39 ]
  %62 = phi ptr [ %59, %58 ], [ %41, %39 ]
  %63 = load i32, ptr %62, align 8, !tbaa !4
  %64 = icmp sgt i64 %2, -1
  br i1 %64, label %91, label %65

65:                                               ; preds = %60
  %66 = and i64 %2, 9223372036854775807
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %301, label %68

68:                                               ; preds = %65
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %70 = load i32, ptr %69, align 4, !tbaa !17
  %71 = zext i32 %70 to i64
  %72 = icmp samesign ugt i64 %66, %71
  br i1 %72, label %301, label %73

73:                                               ; preds = %68
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %75 = load ptr, ptr %74, align 8, !tbaa !18
  %76 = icmp eq ptr %75, null
  br i1 %76, label %301, label %77

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw %struct.NmsSlot, ptr %75, i64 %66
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 8
  %80 = load i64, ptr %79, align 8, !tbaa !19
  %81 = icmp eq i64 %80, 0
  br i1 %81, label %301, label %82

82:                                               ; preds = %77
  %83 = and i64 %2, 4294967295
  %84 = getelementptr inbounds nuw %struct.NmsSlot, ptr %75, i64 %83
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 28
  %86 = load i32, ptr %85, align 4, !tbaa !22
  %87 = icmp eq i32 %86, 1
  br i1 %87, label %88, label %301

88:                                               ; preds = %82
  %89 = load ptr, ptr %84, align 8, !tbaa !23
  %90 = getelementptr inbounds nuw i8, ptr %84, i64 16
  br label %109

91:                                               ; preds = %60
  %92 = icmp eq i64 %2, 0
  br i1 %92, label %301, label %93

93:                                               ; preds = %91
  %94 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %95 = load i32, ptr %94, align 8, !tbaa !13
  %96 = zext i32 %95 to i64
  %97 = icmp samesign ugt i64 %2, %96
  br i1 %97, label %301, label %98

98:                                               ; preds = %93
  %99 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %100 = load ptr, ptr %99, align 8, !tbaa !12
  %101 = icmp eq ptr %100, null
  br i1 %101, label %301, label %102

102:                                              ; preds = %98
  %103 = getelementptr %struct.NmsView, ptr %100, i64 %2
  %104 = getelementptr i8, ptr %103, i64 -16
  %105 = load ptr, ptr %104, align 8, !tbaa !24
  %106 = icmp eq ptr %105, null
  br i1 %106, label %301, label %107

107:                                              ; preds = %102
  %108 = getelementptr i8, ptr %103, i64 -8
  br label %109

109:                                              ; preds = %107, %88
  %110 = phi ptr [ %105, %107 ], [ %89, %88 ]
  %111 = phi ptr [ %108, %107 ], [ %90, %88 ]
  %112 = load i32, ptr %111, align 8, !tbaa !4
  %113 = zext i32 %112 to i64
  %114 = icmp sgt i64 %3, -1
  br i1 %114, label %141, label %115

115:                                              ; preds = %109
  %116 = and i64 %3, 9223372036854775807
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %301, label %118

118:                                              ; preds = %115
  %119 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %120 = load i32, ptr %119, align 4, !tbaa !17
  %121 = zext i32 %120 to i64
  %122 = icmp samesign ugt i64 %116, %121
  br i1 %122, label %301, label %123

123:                                              ; preds = %118
  %124 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %125 = load ptr, ptr %124, align 8, !tbaa !18
  %126 = icmp eq ptr %125, null
  br i1 %126, label %301, label %127

127:                                              ; preds = %123
  %128 = getelementptr inbounds nuw %struct.NmsSlot, ptr %125, i64 %116
  %129 = getelementptr inbounds nuw i8, ptr %128, i64 8
  %130 = load i64, ptr %129, align 8, !tbaa !19
  %131 = icmp eq i64 %130, 0
  br i1 %131, label %301, label %132

132:                                              ; preds = %127
  %133 = and i64 %3, 4294967295
  %134 = getelementptr inbounds nuw %struct.NmsSlot, ptr %125, i64 %133
  %135 = getelementptr inbounds nuw i8, ptr %134, i64 28
  %136 = load i32, ptr %135, align 4, !tbaa !22
  %137 = icmp eq i32 %136, 1
  br i1 %137, label %138, label %301

138:                                              ; preds = %132
  %139 = load ptr, ptr %134, align 8, !tbaa !23
  %140 = getelementptr inbounds nuw i8, ptr %134, i64 16
  br label %159

141:                                              ; preds = %109
  %142 = icmp eq i64 %3, 0
  br i1 %142, label %301, label %143

143:                                              ; preds = %141
  %144 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %145 = load i32, ptr %144, align 8, !tbaa !13
  %146 = zext i32 %145 to i64
  %147 = icmp samesign ugt i64 %3, %146
  br i1 %147, label %301, label %148

148:                                              ; preds = %143
  %149 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %150 = load ptr, ptr %149, align 8, !tbaa !12
  %151 = icmp eq ptr %150, null
  br i1 %151, label %301, label %152

152:                                              ; preds = %148
  %153 = getelementptr %struct.NmsView, ptr %150, i64 %3
  %154 = getelementptr i8, ptr %153, i64 -16
  %155 = load ptr, ptr %154, align 8, !tbaa !24
  %156 = icmp eq ptr %155, null
  br i1 %156, label %301, label %157

157:                                              ; preds = %152
  %158 = getelementptr i8, ptr %153, i64 -8
  br label %159

159:                                              ; preds = %138, %157
  %160 = phi ptr [ %155, %157 ], [ %139, %138 ]
  %161 = phi ptr [ %158, %157 ], [ %140, %138 ]
  %162 = load i32, ptr %161, align 8, !tbaa !4
  %163 = icmp eq i32 %112, 0
  br i1 %163, label %168, label %164

164:                                              ; preds = %159
  %165 = icmp ult i32 %63, %112
  br i1 %165, label %204, label %166

166:                                              ; preds = %164
  %167 = sub nuw i32 %63, %112
  br label %171

168:                                              ; preds = %159
  %169 = zext i32 %63 to i64
  %170 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %61, i64 noundef %169, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #23
  br label %301

171:                                              ; preds = %166, %192
  %172 = phi i64 [ 0, %166 ], [ %193, %192 ]
  %173 = phi i32 [ 0, %166 ], [ %194, %192 ]
  %174 = icmp ugt i32 %173, %167
  br i1 %174, label %199, label %175

175:                                              ; preds = %171, %189
  %176 = phi i32 [ %190, %189 ], [ %173, %171 ]
  %177 = zext i32 %176 to i64
  %178 = getelementptr inbounds nuw i8, ptr %61, i64 %177
  br label %182

179:                                              ; preds = %182
  %180 = add nuw nsw i64 %183, 1
  %181 = icmp eq i64 %180, %113
  br i1 %181, label %192, label %182, !llvm.loop !105

182:                                              ; preds = %179, %175
  %183 = phi i64 [ 0, %175 ], [ %180, %179 ]
  %184 = getelementptr inbounds nuw i8, ptr %178, i64 %183
  %185 = load i8, ptr %184, align 1, !tbaa !38
  %186 = getelementptr inbounds nuw i8, ptr %110, i64 %183
  %187 = load i8, ptr %186, align 1, !tbaa !38
  %188 = icmp eq i8 %185, %187
  br i1 %188, label %179, label %189

189:                                              ; preds = %182
  %190 = add nuw i32 %176, 1
  %191 = icmp ult i32 %176, %167
  br i1 %191, label %175, label %199, !llvm.loop !106

192:                                              ; preds = %179
  %193 = add i64 %172, 1
  %194 = add i32 %176, %112
  %195 = icmp ugt i32 %194, %63
  %196 = sub nuw i32 %63, %194
  %197 = icmp ult i32 %196, %112
  %198 = select i1 %195, i1 true, i1 %197
  br i1 %198, label %199, label %171, !llvm.loop !108

199:                                              ; preds = %171, %192, %189
  %200 = phi i64 [ %172, %189 ], [ %193, %192 ], [ %172, %171 ]
  %201 = udiv i32 %63, %112
  %202 = zext i32 %201 to i64
  %203 = icmp ugt i64 %200, %202
  br i1 %203, label %301, label %204

204:                                              ; preds = %164, %199
  %205 = phi i64 [ %200, %199 ], [ 0, %164 ]
  %206 = trunc nuw i64 %205 to i32
  %207 = mul i32 %112, %206
  %208 = sub i32 %63, %207
  %209 = icmp eq i32 %162, 0
  br i1 %209, label %215, label %210

210:                                              ; preds = %204
  %211 = xor i32 %208, -1
  %212 = udiv i32 %211, %162
  %213 = zext i32 %212 to i64
  %214 = icmp samesign ugt i64 %205, %213
  br i1 %214, label %301, label %215

215:                                              ; preds = %210, %204
  %216 = mul i32 %162, %206
  %217 = add i32 %208, %216
  %218 = zext i32 %217 to i64
  %219 = add nuw nsw i64 %218, 1
  %220 = tail call noalias ptr @malloc(i64 noundef %219) #22
  %221 = icmp eq ptr %220, null
  br i1 %221, label %301, label %222

222:                                              ; preds = %215
  br i1 %165, label %281, label %223

223:                                              ; preds = %222
  %224 = sub nuw i32 %63, %112
  %225 = zext i32 %162 to i64
  br label %226

226:                                              ; preds = %223, %274
  %227 = phi i32 [ %63, %223 ], [ %278, %274 ]
  %228 = phi i32 [ 0, %223 ], [ %275, %274 ]
  %229 = phi i32 [ 0, %223 ], [ %276, %274 ]
  %230 = icmp ugt i32 %229, %224
  br i1 %230, label %281, label %231

231:                                              ; preds = %226, %245
  %232 = phi i32 [ %246, %245 ], [ %229, %226 ]
  %233 = zext i32 %232 to i64
  %234 = getelementptr inbounds nuw i8, ptr %61, i64 %233
  br label %238

235:                                              ; preds = %238
  %236 = add nuw nsw i64 %239, 1
  %237 = icmp eq i64 %236, %113
  br i1 %237, label %248, label %238, !llvm.loop !105

238:                                              ; preds = %235, %231
  %239 = phi i64 [ 0, %231 ], [ %236, %235 ]
  %240 = getelementptr inbounds nuw i8, ptr %234, i64 %239
  %241 = load i8, ptr %240, align 1, !tbaa !38
  %242 = getelementptr inbounds nuw i8, ptr %110, i64 %239
  %243 = load i8, ptr %242, align 1, !tbaa !38
  %244 = icmp eq i8 %241, %243
  br i1 %244, label %235, label %245

245:                                              ; preds = %238
  %246 = add nuw i32 %232, 1
  %247 = icmp ult i32 %232, %224
  br i1 %247, label %231, label %281, !llvm.loop !106

248:                                              ; preds = %235
  %249 = sub i32 %232, %229
  %250 = zext i32 %228 to i64
  %251 = getelementptr inbounds nuw i8, ptr %220, i64 %250
  %252 = zext i32 %229 to i64
  %253 = getelementptr inbounds nuw i8, ptr %61, i64 %252
  %254 = zext i32 %249 to i64
  %255 = icmp eq i32 %232, %229
  br i1 %255, label %263, label %256

256:                                              ; preds = %248, %256
  %257 = phi i64 [ %261, %256 ], [ 0, %248 ]
  %258 = getelementptr inbounds nuw i8, ptr %253, i64 %257
  %259 = load volatile i8, ptr %258, align 1, !tbaa !38
  %260 = getelementptr inbounds nuw i8, ptr %251, i64 %257
  store volatile i8 %259, ptr %260, align 1, !tbaa !38
  %261 = add nuw nsw i64 %257, 1
  %262 = icmp eq i64 %261, %254
  br i1 %262, label %263, label %256, !llvm.loop !39

263:                                              ; preds = %256, %248
  %264 = add i32 %249, %228
  %265 = zext i32 %264 to i64
  %266 = getelementptr inbounds nuw i8, ptr %220, i64 %265
  br i1 %209, label %274, label %267

267:                                              ; preds = %263, %267
  %268 = phi i64 [ %272, %267 ], [ 0, %263 ]
  %269 = getelementptr inbounds nuw i8, ptr %160, i64 %268
  %270 = load volatile i8, ptr %269, align 1, !tbaa !38
  %271 = getelementptr inbounds nuw i8, ptr %266, i64 %268
  store volatile i8 %270, ptr %271, align 1, !tbaa !38
  %272 = add nuw nsw i64 %268, 1
  %273 = icmp eq i64 %272, %225
  br i1 %273, label %274, label %267, !llvm.loop !39

274:                                              ; preds = %267, %263
  %275 = add i32 %264, %162
  %276 = add i32 %232, %112
  %277 = icmp ugt i32 %276, %63
  %278 = sub i32 %63, %276
  %279 = icmp ult i32 %278, %112
  %280 = or i1 %277, %279
  br i1 %280, label %281, label %226, !llvm.loop !109

281:                                              ; preds = %226, %274, %245, %222
  %282 = phi i32 [ %229, %245 ], [ 0, %222 ], [ %229, %226 ], [ %276, %274 ]
  %283 = phi i32 [ %228, %245 ], [ 0, %222 ], [ %228, %226 ], [ %275, %274 ]
  %284 = phi i32 [ %227, %245 ], [ %63, %222 ], [ %227, %226 ], [ %278, %274 ]
  %285 = zext i32 %283 to i64
  %286 = getelementptr inbounds nuw i8, ptr %220, i64 %285
  %287 = zext i32 %282 to i64
  %288 = getelementptr inbounds nuw i8, ptr %61, i64 %287
  %289 = zext i32 %284 to i64
  %290 = icmp eq i32 %63, %282
  br i1 %290, label %298, label %291

291:                                              ; preds = %281, %291
  %292 = phi i64 [ %296, %291 ], [ 0, %281 ]
  %293 = getelementptr inbounds nuw i8, ptr %288, i64 %292
  %294 = load volatile i8, ptr %293, align 1, !tbaa !38
  %295 = getelementptr inbounds nuw i8, ptr %286, i64 %292
  store volatile i8 %294, ptr %295, align 1, !tbaa !38
  %296 = add nuw nsw i64 %292, 1
  %297 = icmp eq i64 %296, %289
  br i1 %297, label %298, label %291, !llvm.loop !39

298:                                              ; preds = %291, %281
  %299 = getelementptr inbounds nuw i8, ptr %220, i64 %218
  store i8 0, ptr %299, align 1, !tbaa !38
  %300 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef nonnull %220, i64 noundef %218, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #23
  call void @free(ptr noundef nonnull %220) #22
  br label %301

301:                                              ; preds = %118, %115, %132, %123, %143, %148, %141, %127, %152, %102, %77, %91, %98, %93, %73, %82, %65, %68, %5, %53, %28, %10, %42, %49, %44, %24, %33, %16, %19, %215, %210, %199, %168, %298
  %302 = phi i32 [ %300, %298 ], [ %170, %168 ], [ 3, %215 ], [ 6, %199 ], [ 3, %210 ], [ 6, %118 ], [ 6, %115 ], [ 1, %132 ], [ 6, %123 ], [ 6, %143 ], [ 6, %148 ], [ 6, %141 ], [ 6, %53 ], [ 6, %127 ], [ 6, %152 ], [ 6, %68 ], [ 6, %65 ], [ 1, %82 ], [ 6, %73 ], [ 6, %93 ], [ 6, %98 ], [ 6, %91 ], [ 6, %5 ], [ 6, %77 ], [ 6, %102 ], [ 6, %19 ], [ 6, %16 ], [ 1, %33 ], [ 6, %24 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %10 ], [ 6, %28 ]
  %303 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #23
  %304 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #23
  %305 = call i32 @nms_release(ptr noundef %0, i64 noundef %3) #23
  %306 = icmp eq i32 %302, 0
  br i1 %306, label %307, label %319

307:                                              ; preds = %301
  %308 = icmp ne i32 %303, 0
  %309 = icmp ne i32 %304, 0
  %310 = select i1 %308, i1 true, i1 %309
  %311 = icmp ne i32 %305, 0
  %312 = select i1 %310, i1 true, i1 %311
  %313 = load i64, ptr %6, align 8, !tbaa !15
  br i1 %312, label %314, label %318

314:                                              ; preds = %307
  %315 = call i32 @nms_release(ptr noundef %0, i64 noundef %313) #23
  %316 = select i1 %309, i32 %304, i32 %305
  %317 = select i1 %308, i32 %303, i32 %316
  br label %319

318:                                              ; preds = %307
  store i64 %313, ptr %4, align 8, !tbaa !15
  br label %319

319:                                              ; preds = %301, %318, %314
  %320 = phi i32 [ 0, %318 ], [ %317, %314 ], [ %302, %301 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  ret i32 %320
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_char_at(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #1 {
  %6 = icmp ne ptr %4, null
  %7 = icmp ult i32 %3, 2
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %77

11:                                               ; preds = %5
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %13 = load i32, ptr %12, align 8, !tbaa !16
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %77

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %43, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %77, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %22 = load i32, ptr %21, align 4, !tbaa !17
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %77, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %27 = load ptr, ptr %26, align 8, !tbaa !18
  %28 = icmp eq ptr %27, null
  br i1 %28, label %77, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i64 %18
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load i64, ptr %31, align 8, !tbaa !19
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %77, label %34

34:                                               ; preds = %29
  %35 = and i64 %1, 4294967295
  %36 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 28
  %38 = load i32, ptr %37, align 4, !tbaa !22
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %40, label %77

40:                                               ; preds = %34
  %41 = load ptr, ptr %36, align 8, !tbaa !23
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 16
  br label %61

43:                                               ; preds = %15
  %44 = icmp eq i64 %1, 0
  br i1 %44, label %77, label %45

45:                                               ; preds = %43
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %47 = load i32, ptr %46, align 8, !tbaa !13
  %48 = zext i32 %47 to i64
  %49 = icmp samesign ugt i64 %1, %48
  br i1 %49, label %77, label %50

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !12
  %53 = icmp eq ptr %52, null
  br i1 %53, label %77, label %54

54:                                               ; preds = %50
  %55 = getelementptr %struct.NmsView, ptr %52, i64 %1
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load ptr, ptr %56, align 8, !tbaa !24
  %58 = icmp eq ptr %57, null
  br i1 %58, label %77, label %59

59:                                               ; preds = %54
  %60 = getelementptr i8, ptr %55, i64 -8
  br label %61

61:                                               ; preds = %59, %40
  %62 = phi ptr [ %57, %59 ], [ %41, %40 ]
  %63 = phi ptr [ %60, %59 ], [ %42, %40 ]
  %64 = load i32, ptr %63, align 8, !tbaa !4
  %65 = icmp eq i32 %3, 0
  %66 = select i1 %65, i64 0, i64 %2
  %67 = icmp sgt i64 %66, -1
  %68 = zext i32 %64 to i64
  %69 = icmp samesign ult i64 %66, %68
  %70 = select i1 %67, i1 %69, i1 false
  br i1 %70, label %71, label %75

71:                                               ; preds = %61
  %72 = getelementptr inbounds nuw i8, ptr %62, i64 %66
  %73 = load i8, ptr %72, align 1, !tbaa !38
  %74 = zext i8 %73 to i64
  br label %75

75:                                               ; preds = %61, %71
  %76 = phi i64 [ %74, %71 ], [ -1, %61 ]
  store i64 %76, ptr %4, align 8, !tbaa !15
  br label %77

77:                                               ; preds = %20, %17, %34, %25, %45, %50, %43, %11, %29, %54, %75, %5
  %78 = phi i32 [ 6, %5 ], [ 0, %75 ], [ 6, %20 ], [ 6, %17 ], [ 1, %34 ], [ 6, %25 ], [ 6, %45 ], [ 6, %50 ], [ 6, %43 ], [ 5, %11 ], [ 6, %29 ], [ 6, %54 ]
  ret i32 %78
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_predicate(ptr noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4) local_unnamed_addr #11 {
  %6 = icmp ne ptr %4, null
  %7 = icmp ult i32 %3, 3
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %166

11:                                               ; preds = %5
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %13 = load i32, ptr %12, align 8, !tbaa !16
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %166

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %43, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %166, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %22 = load i32, ptr %21, align 4, !tbaa !17
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %166, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %27 = load ptr, ptr %26, align 8, !tbaa !18
  %28 = icmp eq ptr %27, null
  br i1 %28, label %166, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i64 %18
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load i64, ptr %31, align 8, !tbaa !19
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %166, label %34

34:                                               ; preds = %29
  %35 = and i64 %1, 4294967295
  %36 = getelementptr inbounds nuw %struct.NmsSlot, ptr %27, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 28
  %38 = load i32, ptr %37, align 4, !tbaa !22
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %40, label %166

40:                                               ; preds = %34
  %41 = load ptr, ptr %36, align 8, !tbaa !23
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 16
  br label %61

43:                                               ; preds = %15
  %44 = icmp eq i64 %1, 0
  br i1 %44, label %166, label %45

45:                                               ; preds = %43
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %47 = load i32, ptr %46, align 8, !tbaa !13
  %48 = zext i32 %47 to i64
  %49 = icmp samesign ugt i64 %1, %48
  br i1 %49, label %166, label %50

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !12
  %53 = icmp eq ptr %52, null
  br i1 %53, label %166, label %54

54:                                               ; preds = %50
  %55 = getelementptr %struct.NmsView, ptr %52, i64 %1
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load ptr, ptr %56, align 8, !tbaa !24
  %58 = icmp eq ptr %57, null
  br i1 %58, label %166, label %59

59:                                               ; preds = %54
  %60 = getelementptr i8, ptr %55, i64 -8
  br label %61

61:                                               ; preds = %59, %40
  %62 = phi ptr [ %57, %59 ], [ %41, %40 ]
  %63 = phi ptr [ %60, %59 ], [ %42, %40 ]
  %64 = load i32, ptr %63, align 8, !tbaa !4
  %65 = icmp sgt i64 %2, -1
  br i1 %65, label %92, label %66

66:                                               ; preds = %61
  %67 = and i64 %2, 9223372036854775807
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %166, label %69

69:                                               ; preds = %66
  %70 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %71 = load i32, ptr %70, align 4, !tbaa !17
  %72 = zext i32 %71 to i64
  %73 = icmp samesign ugt i64 %67, %72
  br i1 %73, label %166, label %74

74:                                               ; preds = %69
  %75 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %76 = load ptr, ptr %75, align 8, !tbaa !18
  %77 = icmp eq ptr %76, null
  br i1 %77, label %166, label %78

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw %struct.NmsSlot, ptr %76, i64 %67
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 8
  %81 = load i64, ptr %80, align 8, !tbaa !19
  %82 = icmp eq i64 %81, 0
  br i1 %82, label %166, label %83

83:                                               ; preds = %78
  %84 = and i64 %2, 4294967295
  %85 = getelementptr inbounds nuw %struct.NmsSlot, ptr %76, i64 %84
  %86 = getelementptr inbounds nuw i8, ptr %85, i64 28
  %87 = load i32, ptr %86, align 4, !tbaa !22
  %88 = icmp eq i32 %87, 1
  br i1 %88, label %89, label %166

89:                                               ; preds = %83
  %90 = load ptr, ptr %85, align 8, !tbaa !23
  %91 = getelementptr inbounds nuw i8, ptr %85, i64 16
  br label %110

92:                                               ; preds = %61
  %93 = icmp eq i64 %2, 0
  br i1 %93, label %166, label %94

94:                                               ; preds = %92
  %95 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %96 = load i32, ptr %95, align 8, !tbaa !13
  %97 = zext i32 %96 to i64
  %98 = icmp samesign ugt i64 %2, %97
  br i1 %98, label %166, label %99

99:                                               ; preds = %94
  %100 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %101 = load ptr, ptr %100, align 8, !tbaa !12
  %102 = icmp eq ptr %101, null
  br i1 %102, label %166, label %103

103:                                              ; preds = %99
  %104 = getelementptr %struct.NmsView, ptr %101, i64 %2
  %105 = getelementptr i8, ptr %104, i64 -16
  %106 = load ptr, ptr %105, align 8, !tbaa !24
  %107 = icmp eq ptr %106, null
  br i1 %107, label %166, label %108

108:                                              ; preds = %103
  %109 = getelementptr i8, ptr %104, i64 -8
  br label %110

110:                                              ; preds = %108, %89
  %111 = phi ptr [ %106, %108 ], [ %90, %89 ]
  %112 = phi ptr [ %109, %108 ], [ %91, %89 ]
  %113 = load i32, ptr %112, align 8, !tbaa !4
  %114 = icmp eq i32 %113, 0
  br i1 %114, label %164, label %115

115:                                              ; preds = %110
  %116 = icmp ugt i32 %113, %64
  br i1 %116, label %164, label %117

117:                                              ; preds = %115
  %118 = sub nuw i32 %64, %113
  switch i32 %3, label %119 [
    i32 1, label %121
    i32 2, label %133
  ]

119:                                              ; preds = %117
  %120 = zext i32 %113 to i64
  br label %147

121:                                              ; preds = %117
  %122 = zext i32 %113 to i64
  br label %126

123:                                              ; preds = %126
  %124 = add nuw nsw i64 %127, 1
  %125 = icmp eq i64 %124, %122
  br i1 %125, label %164, label %126, !llvm.loop !105

126:                                              ; preds = %123, %121
  %127 = phi i64 [ 0, %121 ], [ %124, %123 ]
  %128 = getelementptr inbounds nuw i8, ptr %62, i64 %127
  %129 = load i8, ptr %128, align 1, !tbaa !38
  %130 = getelementptr inbounds nuw i8, ptr %111, i64 %127
  %131 = load i8, ptr %130, align 1, !tbaa !38
  %132 = icmp eq i8 %129, %131
  br i1 %132, label %123, label %164

133:                                              ; preds = %117
  %134 = zext i32 %118 to i64
  %135 = getelementptr inbounds nuw i8, ptr %62, i64 %134
  %136 = zext i32 %113 to i64
  br label %140

137:                                              ; preds = %140
  %138 = add nuw nsw i64 %141, 1
  %139 = icmp eq i64 %138, %136
  br i1 %139, label %164, label %140, !llvm.loop !105

140:                                              ; preds = %137, %133
  %141 = phi i64 [ 0, %133 ], [ %138, %137 ]
  %142 = getelementptr inbounds nuw i8, ptr %135, i64 %141
  %143 = load i8, ptr %142, align 1, !tbaa !38
  %144 = getelementptr inbounds nuw i8, ptr %111, i64 %141
  %145 = load i8, ptr %144, align 1, !tbaa !38
  %146 = icmp eq i8 %143, %145
  br i1 %146, label %137, label %164

147:                                              ; preds = %119, %161
  %148 = phi i32 [ 0, %119 ], [ %162, %161 ]
  %149 = zext i32 %148 to i64
  %150 = getelementptr inbounds nuw i8, ptr %62, i64 %149
  br label %154

151:                                              ; preds = %154
  %152 = add nuw nsw i64 %155, 1
  %153 = icmp eq i64 %152, %120
  br i1 %153, label %164, label %154, !llvm.loop !105

154:                                              ; preds = %151, %147
  %155 = phi i64 [ 0, %147 ], [ %152, %151 ]
  %156 = getelementptr inbounds nuw i8, ptr %150, i64 %155
  %157 = load i8, ptr %156, align 1, !tbaa !38
  %158 = getelementptr inbounds nuw i8, ptr %111, i64 %155
  %159 = load i8, ptr %158, align 1, !tbaa !38
  %160 = icmp eq i8 %157, %159
  br i1 %160, label %151, label %161

161:                                              ; preds = %154
  %162 = add i32 %148, 1
  %163 = icmp ugt i32 %162, %118
  br i1 %163, label %164, label %147, !llvm.loop !110

164:                                              ; preds = %140, %137, %126, %123, %161, %151, %110, %115
  %165 = phi i32 [ 0, %115 ], [ 1, %110 ], [ 1, %151 ], [ 0, %161 ], [ 1, %123 ], [ 0, %126 ], [ 0, %140 ], [ 1, %137 ]
  store i32 %165, ptr %4, align 4, !tbaa !4
  br label %166

166:                                              ; preds = %69, %66, %83, %74, %94, %99, %92, %78, %103, %20, %17, %34, %25, %45, %50, %43, %11, %29, %54, %164, %5
  %167 = phi i32 [ 6, %5 ], [ 0, %164 ], [ 6, %103 ], [ 6, %20 ], [ 6, %17 ], [ 1, %34 ], [ 6, %25 ], [ 6, %45 ], [ 6, %50 ], [ 6, %43 ], [ 5, %11 ], [ 6, %29 ], [ 6, %54 ], [ 6, %69 ], [ 6, %66 ], [ 1, %83 ], [ 6, %74 ], [ 6, %94 ], [ 6, %99 ], [ 6, %92 ], [ 6, %78 ]
  ret i32 %167
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local void @nms_module_fail(i32 noundef %0) local_unnamed_addr #14 {
  %2 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %3 = icmp eq i32 %2, 0
  %4 = icmp ne i32 %0, 0
  %5 = and i1 %4, %3
  br i1 %5, label %6, label %9

6:                                                ; preds = %1
  %7 = icmp ult i32 %0, 8
  %8 = select i1 %7, i32 %0, i32 6
  store i32 %8, ptr @nms_module_error, align 4, !tbaa !4
  br label %9

9:                                                ; preds = %6, %1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i32 @nms_module_status() local_unnamed_addr #15 {
  %1 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  ret i32 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 6) i32 @nms_module_begin(ptr noundef %0, i32 noundef %1) local_unnamed_addr #14 {
  %3 = load i1, ptr @nms_module_ready, align 4
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !4
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !13
  store <2 x ptr> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !14
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !4
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !4
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !15
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  store i1 true, ptr @nms_module_ready, align 4
  br label %11

5:                                                ; preds = %2
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %12

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %4, %8
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  store i32 0, ptr @nms_module_error, align 4, !tbaa !4
  br label %12

12:                                               ; preds = %5, %8, %11
  %13 = phi i32 [ 0, %11 ], [ 5, %5 ], [ 4, %8 ]
  ret i32 %13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i64 0, -9223372036854775808) i64 @nms_module_finish(i32 noundef %0) local_unnamed_addr #14 {
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %14, label %4

4:                                                ; preds = %1
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %6 = icmp ugt i32 %5, 7
  %7 = select i1 %6, i32 6, i32 %5
  %8 = zext nneg i32 %7 to i64
  %9 = shl nuw nsw i64 %8, 32
  %10 = icmp eq i32 %7, 0
  %11 = select i1 %10, i32 %0, i32 0
  %12 = zext i32 %11 to i64
  %13 = or disjoint i64 %9, %12
  br label %14

14:                                               ; preds = %1, %4
  %15 = phi i64 [ %13, %4 ], [ 25769803776, %1 ]
  ret i64 %15
}

; Function Attrs: nounwind
define dso_local range(i32 0, 6) i32 @nms_module_graph_begin(ptr noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = load i1, ptr @nms_module_ready, align 4
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !4
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !13
  store <2 x ptr> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !14
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !4
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !15
  store i1 true, ptr @nms_module_ready, align 4
  store <4 x i32> <i32 0, i32 0, i32 1, i32 0>, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !4
  store i32 0, ptr @nms_module_error, align 4, !tbaa !4
  br label %14

5:                                                ; preds = %2
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %31

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %31

11:                                               ; preds = %8
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !27
  %13 = icmp eq i32 %12, 0
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  store i32 0, ptr @nms_module_error, align 4, !tbaa !4
  br i1 %13, label %14, label %31

14:                                               ; preds = %4, %11
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !17
  %16 = zext i32 %15 to i64
  %17 = add nuw nsw i64 %16, 1
  %18 = mul nuw nsw i64 %17, 9
  %19 = add nuw nsw i64 %18, 3
  %20 = and i64 %19, 274877906940
  %21 = shl nuw nsw i64 %17, 2
  %22 = add nuw nsw i64 %20, %21
  %23 = tail call noalias ptr @malloc(i64 noundef %22) #22
  %24 = icmp eq ptr %23, null
  br i1 %24, label %27, label %25

25:                                               ; preds = %14
  store ptr %23, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !28
  %26 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !17
  store i32 %26, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !29
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !27
  br label %31

27:                                               ; preds = %14
  %28 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %29 = icmp eq i32 %28, 0
  br i1 %29, label %30, label %31

30:                                               ; preds = %27
  store i32 3, ptr @nms_module_error, align 4, !tbaa !4
  br label %31

31:                                               ; preds = %11, %25, %8, %5, %30, %27
  %32 = phi i32 [ 3, %30 ], [ 5, %5 ], [ 3, %27 ], [ 4, %8 ], [ 0, %25 ], [ 0, %11 ]
  ret i32 %32
}

; Function Attrs: nounwind
define dso_local range(i64 1, 4294967304) i64 @nms_module_record_begin(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3) local_unnamed_addr #3 {
  %5 = load i1, ptr @nms_module_ready, align 4
  br i1 %5, label %7, label %6

6:                                                ; preds = %4
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !4
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !13
  store <2 x ptr> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !14
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !4
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !15
  store <4 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !4
  store i1 true, ptr @nms_module_ready, align 4
  br label %19

7:                                                ; preds = %4
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %86

10:                                               ; preds = %7
  %11 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %86

13:                                               ; preds = %10
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %16 = icmp eq ptr %14, %0
  %17 = icmp eq i32 %15, %1
  %18 = select i1 %16, i1 %17, i1 false
  br i1 %18, label %19, label %86

19:                                               ; preds = %6, %13
  %20 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 12), align 4, !tbaa !40
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %70

22:                                               ; preds = %19
  %23 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !17
  %24 = icmp eq i32 %23, 0
  %25 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8
  %26 = icmp eq i64 %25, 0
  %27 = select i1 %24, i1 %26, i1 false
  %28 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8
  %29 = icmp eq i64 %28, 0
  %30 = select i1 %27, i1 %29, i1 false
  br i1 %30, label %31, label %86

31:                                               ; preds = %22
  %32 = icmp eq i32 %3, 0
  %33 = icmp ne ptr %2, null
  %34 = or i1 %33, %32
  br i1 %34, label %35, label %86

35:                                               ; preds = %31
  %36 = icmp ugt i32 %3, 256
  br i1 %36, label %86, label %37

37:                                               ; preds = %35
  br i1 %32, label %69, label %38

38:                                               ; preds = %37
  %39 = zext nneg i32 %3 to i64
  %40 = load i32, ptr %2, align 4, !tbaa !51
  %41 = icmp ugt i32 %40, 255
  br i1 %41, label %86, label %42

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %44 = load i32, ptr %43, align 4, !tbaa !42
  %45 = icmp ugt i32 %44, 65535
  br i1 %45, label %86, label %46

46:                                               ; preds = %42
  %47 = icmp eq i32 %3, 1
  br i1 %47, label %69, label %48

48:                                               ; preds = %46, %65
  %49 = phi i64 [ %67, %65 ], [ 1, %46 ]
  %50 = phi i32 [ %66, %65 ], [ %44, %46 ]
  %51 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %2, i64 %49
  %52 = load i32, ptr %51, align 4, !tbaa !51
  %53 = icmp ugt i32 %52, 255
  br i1 %53, label %86, label %54

54:                                               ; preds = %48
  %55 = getelementptr i8, ptr %51, i64 -8
  %56 = load i32, ptr %55, align 4, !tbaa !51
  %57 = icmp ugt i32 %52, %56
  br i1 %57, label %58, label %86

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw i8, ptr %51, i64 4
  %60 = load i32, ptr %59, align 4, !tbaa !42
  %61 = icmp ugt i32 %60, 65535
  %62 = sub i32 65536, %50
  %63 = icmp ugt i32 %60, %62
  %64 = select i1 %61, i1 true, i1 %63
  br i1 %64, label %86, label %65

65:                                               ; preds = %58
  %66 = add i32 %60, %50
  %67 = add nuw nsw i64 %49, 1
  %68 = icmp eq i64 %67, %39
  br i1 %68, label %69, label %48, !llvm.loop !52

69:                                               ; preds = %65, %37, %46
  store ptr %2, ptr @nms_module_instance, align 8, !tbaa !8
  store i32 %3, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !41
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 12), align 4, !tbaa !40
  br label %76

70:                                               ; preds = %19
  %71 = load ptr, ptr @nms_module_instance, align 8, !tbaa !8
  %72 = icmp eq ptr %71, %2
  %73 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8
  %74 = icmp eq i32 %73, %3
  %75 = select i1 %72, i1 %74, i1 false
  br i1 %75, label %76, label %86

76:                                               ; preds = %69, %70
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  store i32 0, ptr @nms_module_error, align 4, !tbaa !4
  %77 = tail call i32 @nms_prepare_collection(ptr noundef nonnull @nms_module_instance) #23
  %78 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %79 = icmp eq i32 %78, 0
  %80 = icmp ne i32 %77, 0
  %81 = and i1 %80, %79
  br i1 %81, label %82, label %83

82:                                               ; preds = %76
  store i32 %77, ptr @nms_module_error, align 4, !tbaa !4
  br label %83

83:                                               ; preds = %76, %82
  %84 = zext nneg i32 %77 to i64
  %85 = or disjoint i64 %84, 4294967296
  br label %86

86:                                               ; preds = %48, %54, %58, %38, %22, %31, %35, %42, %83, %70, %13, %10, %7
  %87 = phi i64 [ 6, %13 ], [ 5, %7 ], [ 4, %10 ], [ %85, %83 ], [ 6, %70 ], [ 1, %38 ], [ 6, %22 ], [ 1, %35 ], [ 1, %42 ], [ 6, %31 ], [ 1, %58 ], [ 1, %54 ], [ 1, %48 ]
  ret i64 %87
}

; Function Attrs: nounwind
define dso_local i32 @nms_module_graph_collect() local_unnamed_addr #3 {
  %1 = load i1, ptr @nms_module_ready, align 4
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4
  %3 = icmp ne i32 %2, 0
  %4 = select i1 %1, i1 %3, i1 false
  br i1 %4, label %5, label %49

5:                                                ; preds = %0
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %42

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !17
  %10 = icmp eq i32 %9, 0
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %12 = icmp eq ptr %11, null
  br i1 %10, label %13, label %20

13:                                               ; preds = %8
  %14 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8
  %15 = icmp eq i64 %14, 0
  %16 = select i1 %12, i1 %15, i1 false
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8
  %18 = icmp eq i64 %17, 0
  %19 = select i1 %16, i1 %18, i1 false
  br i1 %19, label %21, label %42

20:                                               ; preds = %8
  br i1 %12, label %42, label %21

21:                                               ; preds = %13, %20
  %22 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !27
  %23 = icmp eq i32 %22, 0
  br i1 %23, label %42, label %24

24:                                               ; preds = %21
  %25 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !28
  %26 = icmp eq ptr %25, null
  br i1 %26, label %42, label %27

27:                                               ; preds = %24
  %28 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !29
  %29 = icmp ult i32 %28, %9
  %30 = or i1 %10, %29
  %31 = select i1 %29, i32 6, i32 0
  br i1 %30, label %42, label %32

32:                                               ; preds = %27
  %33 = zext i32 %28 to i64
  %34 = add nuw nsw i64 %33, 1
  %35 = mul nuw nsw i64 %34, 9
  %36 = add nuw nsw i64 %35, 3
  %37 = and i64 %36, 274877906940
  %38 = shl nuw nsw i64 %34, 3
  %39 = getelementptr inbounds nuw i8, ptr %25, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %25, i64 %37
  %41 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull @nms_module_instance, ptr noundef nonnull %25, ptr noundef nonnull %39, ptr noundef nonnull %40) #23
  br label %42

42:                                               ; preds = %5, %13, %20, %21, %24, %27, %32
  %43 = phi i32 [ 6, %21 ], [ 6, %20 ], [ %41, %32 ], [ %31, %27 ], [ 6, %24 ], [ 5, %5 ], [ 6, %13 ]
  %44 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %45 = icmp eq i32 %44, 0
  %46 = icmp ne i32 %43, 0
  %47 = and i1 %46, %45
  br i1 %47, label %48, label %49

48:                                               ; preds = %42
  store i32 %43, ptr @nms_module_error, align 4, !tbaa !4
  br label %49

49:                                               ; preds = %48, %42, %0
  %50 = phi i32 [ 6, %0 ], [ %44, %42 ], [ %43, %48 ]
  ret i32 %50
}

; Function Attrs: nounwind
define dso_local range(i64 0, -9223372036854775808) i64 @nms_module_graph_finish(i32 noundef %0) local_unnamed_addr #3 {
  %2 = load i1, ptr @nms_module_ready, align 4
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4
  %4 = icmp ne i32 %3, 0
  %5 = select i1 %2, i1 %4, i1 false
  br i1 %5, label %6, label %67

6:                                                ; preds = %1
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !27
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %49, label %9

9:                                                ; preds = %6
  %10 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %43

12:                                               ; preds = %9
  %13 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !17
  %14 = icmp eq i32 %13, 0
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %16 = icmp eq ptr %15, null
  br i1 %14, label %17, label %24

17:                                               ; preds = %12
  %18 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8
  %19 = icmp eq i64 %18, 0
  %20 = select i1 %16, i1 %19, i1 false
  %21 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8
  %22 = icmp eq i64 %21, 0
  %23 = select i1 %20, i1 %22, i1 false
  br i1 %23, label %25, label %43

24:                                               ; preds = %12
  br i1 %16, label %43, label %25

25:                                               ; preds = %17, %24
  %26 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !28
  %27 = icmp eq ptr %26, null
  br i1 %27, label %43, label %28

28:                                               ; preds = %25
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !29
  %30 = icmp ult i32 %29, %13
  %31 = or i1 %14, %30
  %32 = select i1 %30, i32 6, i32 0
  br i1 %31, label %43, label %33

33:                                               ; preds = %28
  %34 = zext i32 %29 to i64
  %35 = add nuw nsw i64 %34, 1
  %36 = mul nuw nsw i64 %35, 9
  %37 = add nuw nsw i64 %36, 3
  %38 = and i64 %37, 274877906940
  %39 = shl nuw nsw i64 %35, 3
  %40 = getelementptr inbounds nuw i8, ptr %26, i64 %39
  %41 = getelementptr inbounds nuw i8, ptr %26, i64 %38
  %42 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull @nms_module_instance, ptr noundef nonnull %26, ptr noundef nonnull %40, ptr noundef nonnull %41) #23
  br label %43

43:                                               ; preds = %9, %17, %24, %25, %28, %33
  %44 = phi i32 [ 6, %17 ], [ 6, %24 ], [ %42, %33 ], [ %32, %28 ], [ 6, %25 ], [ 5, %9 ]
  %45 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %46 = icmp eq i32 %45, 0
  %47 = icmp ne i32 %44, 0
  %48 = and i1 %47, %46
  br i1 %48, label %52, label %54

49:                                               ; preds = %6
  %50 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %52, label %54

52:                                               ; preds = %49, %43
  %53 = phi i32 [ %44, %43 ], [ 6, %49 ]
  store i32 %53, ptr @nms_module_error, align 4, !tbaa !4
  br label %54

54:                                               ; preds = %52, %49, %43
  %55 = phi i32 [ %45, %43 ], [ %50, %49 ], [ %53, %52 ]
  %56 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %67, label %58

58:                                               ; preds = %54
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  %59 = icmp ugt i32 %55, 7
  %60 = select i1 %59, i32 6, i32 %55
  %61 = zext nneg i32 %60 to i64
  %62 = shl nuw nsw i64 %61, 32
  %63 = icmp eq i32 %60, 0
  %64 = select i1 %63, i32 %0, i32 0
  %65 = zext i32 %64 to i64
  %66 = or disjoint i64 %62, %65
  br label %67

67:                                               ; preds = %58, %54, %1
  %68 = phi i64 [ 25769803776, %1 ], [ %66, %58 ], [ 25769803776, %54 ]
  ret i64 %68
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i32 @nms_module_active() local_unnamed_addr #15 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !49
  ret i32 %1
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_module_dispose() local_unnamed_addr #3 {
  %1 = load i1, ptr @nms_module_ready, align 4
  br i1 %1, label %3, label %2

2:                                                ; preds = %0
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !4
  store <2 x ptr> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !14
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !28
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !4
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !15
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  store <4 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !4
  store i1 true, ptr @nms_module_ready, align 4
  br label %3

3:                                                ; preds = %2, %0
  %4 = tail call i32 @nms_dispose(ptr noundef nonnull @nms_module_instance) #23
  ret i32 %4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_module_retain(i64 noundef %0, i32 noundef %1) local_unnamed_addr #4 {
  switch i32 %1, label %54 [
    i32 8, label %3
    i32 7, label %3
    i32 5, label %3
  ]

3:                                                ; preds = %2, %2, %2
  %4 = icmp sgt i64 %0, -1
  %5 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %6 = icmp eq i32 %5, 0
  br i1 %4, label %7, label %23

7:                                                ; preds = %3
  br i1 %6, label %8, label %47

8:                                                ; preds = %7
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %10 = freeze i32 %9
  %11 = zext i32 %10 to i64
  %12 = add nsw i64 %0, -1
  %13 = icmp ult i64 %12, %11
  br i1 %13, label %14, label %47

14:                                               ; preds = %8
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %16 = icmp eq ptr %15, null
  br i1 %16, label %47, label %17

17:                                               ; preds = %14
  %18 = getelementptr %struct.NmsView, ptr %15, i64 %0
  %19 = getelementptr i8, ptr %18, i64 -16
  %20 = load ptr, ptr %19, align 8, !tbaa !24
  %21 = icmp eq ptr %20, null
  %22 = select i1 %21, i32 6, i32 0
  br label %47

23:                                               ; preds = %3
  br i1 %6, label %24, label %47

24:                                               ; preds = %23
  %25 = and i64 %0, 9223372036854775807
  %26 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %27 = freeze i32 %26
  %28 = zext i32 %27 to i64
  %29 = add nsw i64 %25, -1
  %30 = icmp ult i64 %29, %28
  br i1 %30, label %31, label %47

31:                                               ; preds = %24
  %32 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %33 = icmp eq ptr %32, null
  br i1 %33, label %47, label %34

34:                                               ; preds = %31
  %35 = getelementptr inbounds nuw %struct.NmsSlot, ptr %32, i64 %25
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %37 = load i64, ptr %36, align 8, !tbaa !19
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %47, label %39

39:                                               ; preds = %34
  %40 = and i64 %0, 4294967295
  %41 = getelementptr inbounds nuw %struct.NmsSlot, ptr %32, i64 %40
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 8
  %43 = load i64, ptr %42, align 8, !tbaa !19
  %44 = icmp eq i64 %43, -1
  br i1 %44, label %47, label %45

45:                                               ; preds = %39
  %46 = add nuw i64 %43, 1
  store i64 %46, ptr %42, align 8, !tbaa !19
  br label %54

47:                                               ; preds = %39, %34, %31, %24, %23, %17, %14, %8, %7
  %48 = phi i32 [ 3, %39 ], [ 6, %24 ], [ 6, %34 ], [ %22, %17 ], [ 5, %23 ], [ 5, %7 ], [ 6, %8 ], [ 6, %14 ], [ 6, %31 ]
  %49 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %50 = icmp eq i32 %49, 0
  %51 = icmp ne i32 %48, 0
  %52 = and i1 %51, %50
  br i1 %52, label %53, label %54

53:                                               ; preds = %47
  store i32 %48, ptr @nms_module_error, align 4, !tbaa !4
  br label %54

54:                                               ; preds = %45, %2, %47, %53
  %55 = phi i32 [ %48, %53 ], [ %48, %47 ], [ 0, %2 ], [ 0, %45 ]
  ret i32 %55
}

; Function Attrs: nounwind
define dso_local void @nms_module_release(i64 noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  switch i32 %1, label %10 [
    i32 8, label %3
    i32 7, label %3
    i32 5, label %3
  ]

3:                                                ; preds = %2, %2, %2
  %4 = tail call i32 @nms_release(ptr noundef nonnull @nms_module_instance, i64 noundef %0) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %3
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %9, %3, %2
  ret void
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_record_literal(i32 noundef %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca [256 x %struct.NmsValue], align 8
  %6 = alloca i64, align 8
  %7 = icmp ugt i32 %1, 256
  br i1 %7, label %8, label %12

8:                                                ; preds = %4
  %9 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %45

11:                                               ; preds = %8
  store i32 1, ptr @nms_module_error, align 4, !tbaa !4
  br label %45

12:                                               ; preds = %4
  %13 = icmp eq i32 %1, 0
  br i1 %13, label %14, label %15

14:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  br label %25

15:                                               ; preds = %12
  %16 = icmp ne ptr %2, null
  %17 = icmp ne ptr %3, null
  %18 = and i1 %16, %17
  br i1 %18, label %23, label %19

19:                                               ; preds = %15
  %20 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %45

22:                                               ; preds = %19
  store i32 6, ptr @nms_module_error, align 4, !tbaa !4
  br label %45

23:                                               ; preds = %15
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  %24 = zext nneg i32 %1 to i64
  br label %34

25:                                               ; preds = %34, %14
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  %26 = call i32 @nms_record_create(ptr noundef nonnull @nms_module_instance, i32 noundef %0, ptr noundef nonnull %5, i32 noundef %1, ptr noundef nonnull %6) #23
  %27 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %28 = icmp eq i32 %27, 0
  %29 = icmp ne i32 %26, 0
  %30 = and i1 %29, %28
  br i1 %30, label %31, label %32

31:                                               ; preds = %25
  store i32 %26, ptr @nms_module_error, align 4, !tbaa !4
  br label %32

32:                                               ; preds = %25, %31
  %33 = load i64, ptr %6, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  br label %45

34:                                               ; preds = %23, %34
  %35 = phi i64 [ 0, %23 ], [ %43, %34 ]
  %36 = getelementptr inbounds nuw %struct.NmsValue, ptr %5, i64 %35
  %37 = getelementptr inbounds nuw i64, ptr %2, i64 %35
  %38 = load i64, ptr %37, align 8, !tbaa !15
  %39 = getelementptr inbounds nuw i32, ptr %3, i64 %35
  %40 = load i32, ptr %39, align 4, !tbaa !4
  store i64 %38, ptr %36, align 8, !tbaa !15
  %41 = getelementptr inbounds nuw i8, ptr %36, i64 8
  store i32 %40, ptr %41, align 8, !tbaa !4
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 12
  store i32 0, ptr %42, align 4
  %43 = add nuw nsw i64 %35, 1
  %44 = icmp eq i64 %43, %24
  br i1 %44, label %25, label %34, !llvm.loop !111

45:                                               ; preds = %22, %19, %11, %8, %32
  %46 = phi i64 [ 0, %11 ], [ %33, %32 ], [ 0, %8 ], [ 0, %19 ], [ 0, %22 ]
  ret i64 %46
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 8) i32 @nms_module_record_get_value(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(address_is_null) %4, ptr noundef writeonly captures(address_is_null) %5) local_unnamed_addr #4 {
  %7 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %7, i8 0, i64 16, i1 false)
  %8 = icmp ne ptr %4, null
  %9 = icmp ne ptr %5, null
  %10 = and i1 %8, %9
  br i1 %10, label %11, label %22

11:                                               ; preds = %6
  %12 = tail call fastcc i32 @nms_module_record_receiver(i64 noundef %0, i32 noundef %1, i32 noundef %3) #23
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %22

14:                                               ; preds = %11
  %15 = zext i32 %2 to i64
  %16 = call i32 @nms_record_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %15, ptr noundef nonnull %7) #23
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %22

18:                                               ; preds = %14
  %19 = load i64, ptr %7, align 8, !tbaa !112
  store i64 %19, ptr %4, align 8, !tbaa !15
  %20 = getelementptr inbounds nuw i8, ptr %7, i64 8
  %21 = load i32, ptr %20, align 8, !tbaa !114
  store i32 %21, ptr %5, align 4, !tbaa !4
  br label %27

22:                                               ; preds = %6, %11, %14
  %23 = phi i32 [ %16, %14 ], [ %12, %11 ], [ 6, %6 ]
  %24 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %25 = icmp eq i32 %24, 0
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  store i32 %23, ptr @nms_module_error, align 4, !tbaa !4
  br label %27

27:                                               ; preds = %18, %22, %26
  %28 = phi i32 [ 0, %18 ], [ %23, %22 ], [ %23, %26 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #24
  ret i32 %28
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc range(i32 0, 8) i32 @nms_module_record_receiver(i64 noundef %0, i32 noundef %1, i32 noundef %2) unnamed_addr #5 {
  %4 = icmp ugt i32 %2, 1
  br i1 %4, label %71, label %5

5:                                                ; preds = %3
  %6 = icmp eq i32 %1, 8
  br i1 %6, label %10, label %7

7:                                                ; preds = %5
  %8 = icmp eq i32 %2, 0
  %9 = select i1 %8, i32 1, i32 7
  br label %71

10:                                               ; preds = %5
  %11 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %65

13:                                               ; preds = %10
  %14 = and i64 %0, 9223372036854775807
  %15 = icmp sgt i64 %0, -1
  %16 = icmp eq i64 %14, 0
  %17 = or i1 %15, %16
  %18 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  %21 = select i1 %17, i1 true, i1 %20
  br i1 %21, label %65, label %22

22:                                               ; preds = %13
  %23 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %24 = icmp eq ptr %23, null
  br i1 %24, label %65, label %25

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i64 %14
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load i64, ptr %27, align 8, !tbaa !19
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %65, label %30

30:                                               ; preds = %25
  %31 = and i64 %0, 4294967295
  %32 = getelementptr inbounds nuw %struct.NmsSlot, ptr %23, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 28
  %34 = load i32, ptr %33, align 4, !tbaa !22
  %35 = icmp eq i32 %34, 5
  br i1 %35, label %36, label %65

36:                                               ; preds = %30
  %37 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 12), align 4, !tbaa !40
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %65, label %39

39:                                               ; preds = %36
  %40 = load ptr, ptr @nms_module_instance, align 8, !tbaa !8
  %41 = icmp eq ptr %40, null
  br i1 %41, label %65, label %42

42:                                               ; preds = %39
  %43 = getelementptr inbounds nuw i8, ptr %32, i64 40
  %44 = load i32, ptr %43, align 8, !tbaa !32
  %45 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !41
  %46 = icmp ult i32 %44, %45
  br i1 %46, label %47, label %65

47:                                               ; preds = %42
  %48 = zext i32 %44 to i64
  %49 = getelementptr inbounds nuw %struct.NmsRecordDescriptor, ptr %40, i64 %48
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 4
  %51 = load i32, ptr %50, align 4, !tbaa !42
  %52 = getelementptr inbounds nuw i8, ptr %32, i64 16
  %53 = load i32, ptr %52, align 8, !tbaa !33
  %54 = icmp eq i32 %53, %51
  br i1 %54, label %55, label %65

55:                                               ; preds = %47
  %56 = getelementptr inbounds nuw i8, ptr %32, i64 24
  %57 = load i32, ptr %56, align 8, !tbaa !37
  %58 = icmp eq i32 %57, %51
  br i1 %58, label %59, label %65

59:                                               ; preds = %55
  %60 = icmp eq i32 %51, 0
  br i1 %60, label %64, label %61

61:                                               ; preds = %59
  %62 = load ptr, ptr %32, align 8, !tbaa !23
  %63 = icmp eq ptr %62, null
  br i1 %63, label %65, label %64

64:                                               ; preds = %61, %59
  br label %65

65:                                               ; preds = %10, %13, %22, %25, %30, %36, %39, %42, %47, %55, %61, %64
  %66 = phi i1 [ true, %30 ], [ false, %64 ], [ false, %36 ], [ false, %61 ], [ false, %10 ], [ false, %25 ], [ false, %22 ], [ false, %42 ], [ false, %13 ], [ false, %47 ], [ false, %55 ], [ false, %39 ]
  %67 = phi i32 [ 1, %30 ], [ 0, %64 ], [ 6, %36 ], [ 6, %61 ], [ 5, %10 ], [ 6, %25 ], [ 6, %22 ], [ 6, %42 ], [ 6, %13 ], [ 6, %47 ], [ 6, %55 ], [ 6, %39 ]
  %68 = icmp ne i32 %2, 0
  %69 = and i1 %68, %66
  %70 = select i1 %69, i32 7, i32 %67
  br label %71

71:                                               ; preds = %3, %65, %7
  %72 = phi i32 [ %70, %65 ], [ %9, %7 ], [ 6, %3 ]
  ret i32 %72
}

; Function Attrs: nounwind
define dso_local range(i32 0, 8) i32 @nms_module_record_set_value(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i64 noundef %4, i32 noundef %5) local_unnamed_addr #3 {
  %7 = tail call fastcc i32 @nms_module_record_receiver(i64 noundef %0, i32 noundef %1, i32 noundef %3) #23
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %15

9:                                                ; preds = %6
  %10 = zext i32 %2 to i64
  %11 = insertvalue [2 x i64] poison, i64 %4, 0
  %12 = zext i32 %5 to i64
  %13 = insertvalue [2 x i64] %11, i64 %12, 1
  %14 = tail call i32 @nms_record_set(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %10, [2 x i64] %13) #23
  br label %15

15:                                               ; preds = %9, %6
  %16 = phi i32 [ %14, %9 ], [ %7, %6 ]
  %17 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %18 = icmp eq i32 %17, 0
  %19 = icmp ne i32 %16, 0
  %20 = and i1 %19, %18
  br i1 %20, label %21, label %22

21:                                               ; preds = %15
  store i32 %16, ptr @nms_module_error, align 4, !tbaa !4
  br label %22

22:                                               ; preds = %15, %21
  ret i32 %16
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_format_scalar(i64 noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  store i64 0, ptr %3, align 8, !tbaa !15
  %4 = call i32 @nms_format_scalar(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, ptr noundef nonnull %3) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i64 -1, 256) i64 @nms_module_char_at(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #16 {
  %4 = icmp ult i32 %2, 2
  br i1 %4, label %5, label %64

5:                                                ; preds = %3
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %64

8:                                                ; preds = %5
  %9 = icmp sgt i64 %0, -1
  br i1 %9, label %34, label %10

10:                                               ; preds = %8
  %11 = and i64 %0, 9223372036854775807
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %13 = freeze i32 %12
  %14 = zext i32 %13 to i64
  %15 = add nsw i64 %11, -1
  %16 = icmp ult i64 %15, %14
  br i1 %16, label %17, label %64

17:                                               ; preds = %10
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %19 = icmp eq ptr %18, null
  br i1 %19, label %64, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw %struct.NmsSlot, ptr %18, i64 %11
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 8
  %23 = load i64, ptr %22, align 8, !tbaa !19
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %64, label %25

25:                                               ; preds = %20
  %26 = and i64 %0, 4294967295
  %27 = getelementptr inbounds nuw %struct.NmsSlot, ptr %18, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 28
  %29 = load i32, ptr %28, align 4, !tbaa !22
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %31, label %64

31:                                               ; preds = %25
  %32 = load ptr, ptr %27, align 8, !tbaa !23
  %33 = getelementptr inbounds nuw i8, ptr %27, i64 16
  br label %50

34:                                               ; preds = %8
  %35 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %36 = freeze i32 %35
  %37 = zext i32 %36 to i64
  %38 = add nsw i64 %0, -1
  %39 = icmp ult i64 %38, %37
  br i1 %39, label %40, label %64

40:                                               ; preds = %34
  %41 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %42 = icmp eq ptr %41, null
  br i1 %42, label %64, label %43

43:                                               ; preds = %40
  %44 = getelementptr %struct.NmsView, ptr %41, i64 %0
  %45 = getelementptr i8, ptr %44, i64 -16
  %46 = load ptr, ptr %45, align 8, !tbaa !24
  %47 = icmp eq ptr %46, null
  br i1 %47, label %64, label %48

48:                                               ; preds = %43
  %49 = getelementptr i8, ptr %44, i64 -8
  br label %50

50:                                               ; preds = %48, %31
  %51 = phi ptr [ %46, %48 ], [ %32, %31 ]
  %52 = phi ptr [ %49, %48 ], [ %33, %31 ]
  %53 = load i32, ptr %52, align 8, !tbaa !4
  %54 = icmp eq i32 %2, 0
  %55 = select i1 %54, i64 0, i64 %1
  %56 = icmp sgt i64 %55, -1
  %57 = zext i32 %53 to i64
  %58 = icmp samesign ult i64 %55, %57
  %59 = select i1 %56, i1 %58, i1 false
  br i1 %59, label %60, label %69

60:                                               ; preds = %50
  %61 = getelementptr inbounds nuw i8, ptr %51, i64 %55
  %62 = load i8, ptr %61, align 1, !tbaa !38
  %63 = zext i8 %62 to i64
  br label %69

64:                                               ; preds = %3, %5, %10, %17, %20, %25, %34, %40, %43
  %65 = phi i32 [ 6, %3 ], [ 6, %43 ], [ 6, %20 ], [ 6, %10 ], [ 1, %25 ], [ 6, %17 ], [ 5, %5 ], [ 6, %40 ], [ 6, %34 ]
  %66 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %68, label %69

68:                                               ; preds = %64
  store i32 %65, ptr @nms_module_error, align 4, !tbaa !4
  br label %69

69:                                               ; preds = %50, %60, %64, %68
  %70 = phi i64 [ 0, %68 ], [ 0, %64 ], [ -1, %50 ], [ %63, %60 ]
  ret i64 %70
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i32 @nms_module_predicate(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #17 {
  %4 = alloca i32, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #24
  store i32 0, ptr %4, align 4, !tbaa !4
  %5 = call i32 @nms_predicate(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, i32 noundef %2, ptr noundef nonnull %4) #23
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !4
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i32, ptr %4, align 4, !tbaa !4
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  ret i32 %12
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i64 @nms_module_parse_f64(i64 noundef %0) local_unnamed_addr #9 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #24
  store i64 0, ptr %2, align 8, !tbaa !15
  %3 = call i32 @nms_parse_f64(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #23
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !4
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #24
  ret i64 %10
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i64 @nms_module_parse_i64(i64 noundef %0) local_unnamed_addr #17 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #24
  store i64 0, ptr %2, align 8, !tbaa !15
  %3 = call i32 @nms_parse_i64(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #23
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !4
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #24
  ret i64 %10
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_split(i64 noundef %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  store i64 0, ptr %3, align 8, !tbaa !15
  %4 = call fastcc range(i32 0, 7) i32 @split_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3, i32 noundef 0) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  ret i64 %11
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_array_literal(i32 noundef %0, i32 noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  store i64 0, ptr %5, align 8, !tbaa !15
  %6 = call i32 @nms_vm_array_literal(ptr noundef nonnull @nms_module_instance, i32 noundef %0, ptr noundef %2, ptr noundef %3, i32 noundef %1, ptr noundef nonnull %5) #23
  %7 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %8 = icmp eq i32 %7, 0
  %9 = icmp ne i32 %6, 0
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %12

11:                                               ; preds = %4
  store i32 %6, ptr @nms_module_error, align 4, !tbaa !4
  br label %12

12:                                               ; preds = %4, %11
  %13 = load i64, ptr %5, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  ret i64 %13
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_array_slice(i64 noundef %0, i64 noundef %1, i32 noundef %2, i64 noundef %3, i32 noundef %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp sgt i64 %0, -1
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %9 = icmp eq i32 %8, 0
  br i1 %7, label %10, label %26

10:                                               ; preds = %5
  br i1 %9, label %11, label %49

11:                                               ; preds = %10
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %13 = freeze i32 %12
  %14 = zext i32 %13 to i64
  %15 = add nsw i64 %0, -1
  %16 = icmp ult i64 %15, %14
  br i1 %16, label %17, label %49

17:                                               ; preds = %11
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %19 = icmp eq ptr %18, null
  br i1 %19, label %49, label %20

20:                                               ; preds = %17
  %21 = getelementptr %struct.NmsView, ptr %18, i64 %0
  %22 = getelementptr i8, ptr %21, i64 -16
  %23 = load ptr, ptr %22, align 8, !tbaa !24
  %24 = icmp eq ptr %23, null
  %25 = select i1 %24, i32 6, i32 1
  br label %49

26:                                               ; preds = %5
  br i1 %9, label %27, label %49

27:                                               ; preds = %26
  %28 = and i64 %0, 9223372036854775807
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %30 = freeze i32 %29
  %31 = zext i32 %30 to i64
  %32 = add nsw i64 %28, -1
  %33 = icmp ult i64 %32, %31
  br i1 %33, label %34, label %49

34:                                               ; preds = %27
  %35 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %36 = icmp eq ptr %35, null
  br i1 %36, label %49, label %37

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw %struct.NmsSlot, ptr %35, i64 %28
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 8
  %40 = load i64, ptr %39, align 8, !tbaa !19
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %49, label %42

42:                                               ; preds = %37
  %43 = and i64 %0, 4294967295
  %44 = getelementptr inbounds nuw %struct.NmsSlot, ptr %35, i64 %43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 28
  %46 = load i32, ptr %45, align 4, !tbaa !22
  %47 = add i32 %46, -2
  %48 = icmp ult i32 %47, 3
  br i1 %48, label %51, label %49

49:                                               ; preds = %42, %17, %11, %10, %20, %27, %26, %37, %34
  %50 = phi i32 [ 6, %34 ], [ 6, %37 ], [ 5, %26 ], [ 6, %27 ], [ %25, %20 ], [ 1, %42 ], [ 5, %10 ], [ 6, %11 ], [ 6, %17 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  br label %61

51:                                               ; preds = %42
  %52 = getelementptr inbounds nuw i8, ptr %44, i64 16
  %53 = load i32, ptr %52, align 8, !tbaa !33
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  store i64 0, ptr %6, align 8, !tbaa !15
  %54 = icmp eq i32 %2, 1
  %55 = trunc i64 %1 to i32
  %56 = select i1 %54, i32 %55, i32 0
  %57 = icmp eq i32 %4, 1
  %58 = trunc i64 %3 to i32
  %59 = select i1 %57, i32 %58, i32 %53
  %60 = call i32 @nms_vm_array_slice(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %56, i32 noundef %59, ptr noundef nonnull %6) #23
  br label %61

61:                                               ; preds = %49, %51
  %62 = phi i32 [ %60, %51 ], [ %50, %49 ]
  %63 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %64 = icmp eq i32 %63, 0
  %65 = icmp ne i32 %62, 0
  %66 = and i1 %65, %64
  br i1 %66, label %67, label %68

67:                                               ; preds = %61
  store i32 %62, ptr @nms_module_error, align 4, !tbaa !4
  br label %68

68:                                               ; preds = %61, %67
  %69 = load i64, ptr %6, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  ret i64 %69
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_array_create(i32 noundef %0) local_unnamed_addr #3 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #24
  store i64 0, ptr %2, align 8, !tbaa !15
  %3 = call fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr noundef nonnull @nms_module_instance, i32 noundef %0, i32 noundef 8, ptr noundef nonnull %2) #23
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !4
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #24
  ret i64 %10
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_split_values(i64 noundef %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  store i64 0, ptr %3, align 8, !tbaa !15
  %4 = call fastcc range(i32 0, 7) i32 @split_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3, i32 noundef 1) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  ret i64 %11
}

; Function Attrs: nounwind
define dso_local range(i32 0, 7) i32 @nms_module_array_append_value(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #3 {
  %4 = insertvalue [2 x i64] poison, i64 %1, 0
  %5 = zext i32 %2 to i64
  %6 = insertvalue [2 x i64] %4, i64 %5, 1
  %7 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef 0, [2 x i64] %6, i32 noundef 1) #23
  %8 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %9 = icmp eq i32 %8, 0
  %10 = icmp ne i32 %7, 0
  %11 = and i1 %10, %9
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  store i32 %7, ptr @nms_module_error, align 4, !tbaa !4
  br label %13

13:                                               ; preds = %3, %12
  ret i32 %7
}

; Function Attrs: nounwind
define dso_local range(i32 0, 8) i32 @nms_module_array_set_value(i64 noundef %0, i64 noundef %1, i64 noundef %2, i32 noundef %3) local_unnamed_addr #3 {
  %5 = icmp sgt i64 %0, -1
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %7 = icmp eq i32 %6, 0
  br i1 %5, label %8, label %24

8:                                                ; preds = %4
  br i1 %7, label %9, label %57

9:                                                ; preds = %8
  %10 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %11 = freeze i32 %10
  %12 = zext i32 %11 to i64
  %13 = add nsw i64 %0, -1
  %14 = icmp ult i64 %13, %12
  br i1 %14, label %15, label %57

15:                                               ; preds = %9
  %16 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %17 = icmp eq ptr %16, null
  br i1 %17, label %57, label %18

18:                                               ; preds = %15
  %19 = getelementptr %struct.NmsView, ptr %16, i64 %0
  %20 = getelementptr i8, ptr %19, i64 -16
  %21 = load ptr, ptr %20, align 8, !tbaa !24
  %22 = icmp eq ptr %21, null
  %23 = select i1 %22, i32 6, i32 1
  br label %57

24:                                               ; preds = %4
  br i1 %7, label %25, label %57

25:                                               ; preds = %24
  %26 = and i64 %0, 9223372036854775807
  %27 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %28 = freeze i32 %27
  %29 = zext i32 %28 to i64
  %30 = add nsw i64 %26, -1
  %31 = icmp ult i64 %30, %29
  br i1 %31, label %32, label %57

32:                                               ; preds = %25
  %33 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %34 = icmp eq ptr %33, null
  br i1 %34, label %57, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw %struct.NmsSlot, ptr %33, i64 %26
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %38 = load i64, ptr %37, align 8, !tbaa !19
  %39 = icmp eq i64 %38, 0
  br i1 %39, label %57, label %40

40:                                               ; preds = %35
  %41 = and i64 %0, 4294967295
  %42 = getelementptr inbounds nuw %struct.NmsSlot, ptr %33, i64 %41
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 28
  %44 = load i32, ptr %43, align 4, !tbaa !22
  %45 = add i32 %44, -2
  %46 = icmp ult i32 %45, 3
  br i1 %46, label %47, label %57

47:                                               ; preds = %40
  %48 = getelementptr inbounds nuw i8, ptr %42, i64 16
  %49 = load i32, ptr %48, align 8, !tbaa !33
  %50 = zext i32 %49 to i64
  %51 = icmp ult i64 %1, %50
  br i1 %51, label %52, label %57

52:                                               ; preds = %47
  %53 = insertvalue [2 x i64] poison, i64 %2, 0
  %54 = zext i32 %3 to i64
  %55 = insertvalue [2 x i64] %53, i64 %54, 1
  %56 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, [2 x i64] %55, i32 noundef 0) #23
  br label %57

57:                                               ; preds = %32, %35, %24, %25, %18, %8, %9, %15, %40, %47, %52
  %58 = phi i32 [ %56, %52 ], [ 7, %47 ], [ 6, %32 ], [ 6, %35 ], [ 5, %24 ], [ 6, %25 ], [ %23, %18 ], [ 1, %40 ], [ 5, %8 ], [ 6, %9 ], [ 6, %15 ]
  %59 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %60 = icmp eq i32 %59, 0
  %61 = icmp ne i32 %58, 0
  %62 = and i1 %61, %60
  br i1 %62, label %63, label %64

63:                                               ; preds = %57
  store i32 %58, ptr @nms_module_error, align 4, !tbaa !4
  br label %64

64:                                               ; preds = %57, %63
  ret i32 %58
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_module_array_get_value(i64 noundef %0, i64 noundef %1, ptr noundef writeonly captures(address_is_null) %2, ptr noundef writeonly captures(address_is_null) %3) local_unnamed_addr #9 {
  %5 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %5, i8 0, i64 16, i1 false)
  %6 = icmp ne ptr %2, null
  %7 = icmp ne ptr %3, null
  %8 = and i1 %6, %7
  br i1 %8, label %9, label %16

9:                                                ; preds = %4
  %10 = call i32 @nms_value_array_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %5) #23
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %16

12:                                               ; preds = %9
  %13 = load i64, ptr %5, align 8, !tbaa !112
  store i64 %13, ptr %2, align 8, !tbaa !15
  %14 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %15 = load i32, ptr %14, align 8, !tbaa !114
  store i32 %15, ptr %3, align 4, !tbaa !4
  br label %21

16:                                               ; preds = %4, %9
  %17 = phi i32 [ %10, %9 ], [ 6, %4 ]
  %18 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %20, label %21

20:                                               ; preds = %16
  store i32 %17, ptr @nms_module_error, align 4, !tbaa !4
  br label %21

21:                                               ; preds = %12, %16, %20
  %22 = phi i32 [ 0, %12 ], [ %17, %16 ], [ %17, %20 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  ret i32 %22
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i32 0, 7) i32 @nms_module_array_pop_value(i64 noundef %0, ptr noundef writeonly captures(address_is_null) %1, ptr noundef writeonly captures(address_is_null) %2) local_unnamed_addr #9 {
  %4 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %4, i8 0, i64 16, i1 false)
  %5 = icmp ne ptr %1, null
  %6 = icmp ne ptr %2, null
  %7 = and i1 %5, %6
  br i1 %7, label %8, label %15

8:                                                ; preds = %3
  %9 = call i32 @nms_value_array_pop(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %4) #23
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %15

11:                                               ; preds = %8
  %12 = load i64, ptr %4, align 8, !tbaa !112
  store i64 %12, ptr %1, align 8, !tbaa !15
  %13 = getelementptr inbounds nuw i8, ptr %4, i64 8
  %14 = load i32, ptr %13, align 8, !tbaa !114
  store i32 %14, ptr %2, align 4, !tbaa !4
  br label %20

15:                                               ; preds = %3, %8
  %16 = phi i32 [ %9, %8 ], [ 6, %3 ]
  %17 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %18 = icmp eq i32 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %15
  store i32 %16, ptr @nms_module_error, align 4, !tbaa !4
  br label %20

20:                                               ; preds = %11, %15, %19
  %21 = phi i32 [ 0, %11 ], [ %16, %15 ], [ %16, %19 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  ret i32 %21
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i64 @nms_module_array_get(i64 noundef %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  store i64 0, ptr %3, align 8, !tbaa !15
  %4 = call i32 @nms_string_array_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i32 @nms_module_array_length(i64 noundef %0) local_unnamed_addr #16 {
  %2 = icmp sgt i64 %0, -1
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %4 = icmp eq i32 %3, 0
  br i1 %2, label %5, label %21

5:                                                ; preds = %1
  br i1 %4, label %6, label %46

6:                                                ; preds = %5
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %8 = freeze i32 %7
  %9 = zext i32 %8 to i64
  %10 = add nsw i64 %0, -1
  %11 = icmp ult i64 %10, %9
  br i1 %11, label %12, label %46

12:                                               ; preds = %6
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %14 = icmp eq ptr %13, null
  br i1 %14, label %46, label %15

15:                                               ; preds = %12
  %16 = getelementptr %struct.NmsView, ptr %13, i64 %0
  %17 = getelementptr i8, ptr %16, i64 -16
  %18 = load ptr, ptr %17, align 8, !tbaa !24
  %19 = icmp eq ptr %18, null
  %20 = select i1 %19, i32 6, i32 1
  br label %46

21:                                               ; preds = %1
  br i1 %4, label %22, label %46

22:                                               ; preds = %21
  %23 = and i64 %0, 9223372036854775807
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %25 = freeze i32 %24
  %26 = zext i32 %25 to i64
  %27 = add nsw i64 %23, -1
  %28 = icmp ult i64 %27, %26
  br i1 %28, label %29, label %46

29:                                               ; preds = %22
  %30 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %31 = icmp eq ptr %30, null
  br i1 %31, label %46, label %32

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %30, i64 %23
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !19
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %46, label %37

37:                                               ; preds = %32
  %38 = and i64 %0, 4294967295
  %39 = getelementptr inbounds nuw %struct.NmsSlot, ptr %30, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 28
  %41 = load i32, ptr %40, align 4, !tbaa !22
  %42 = icmp eq i32 %41, 2
  br i1 %42, label %43, label %46

43:                                               ; preds = %37
  %44 = getelementptr inbounds nuw i8, ptr %39, i64 16
  %45 = load i32, ptr %44, align 8, !tbaa !33
  br label %51

46:                                               ; preds = %5, %6, %12, %15, %21, %22, %29, %32, %37
  %47 = phi i32 [ 5, %21 ], [ 1, %37 ], [ 6, %29 ], [ 6, %12 ], [ 6, %6 ], [ 5, %5 ], [ 6, %32 ], [ %20, %15 ], [ 6, %22 ]
  %48 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %49 = icmp eq i32 %48, 0
  br i1 %49, label %50, label %51

50:                                               ; preds = %46
  store i32 %47, ptr @nms_module_error, align 4, !tbaa !4
  br label %51

51:                                               ; preds = %43, %46, %50
  %52 = phi i32 [ %45, %43 ], [ 0, %46 ], [ 0, %50 ]
  ret i32 %52
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i32 @nms_module_array_value_length(i64 noundef %0) local_unnamed_addr #16 {
  %2 = icmp sgt i64 %0, -1
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %4 = icmp eq i32 %3, 0
  br i1 %2, label %5, label %21

5:                                                ; preds = %1
  br i1 %4, label %6, label %47

6:                                                ; preds = %5
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %8 = freeze i32 %7
  %9 = zext i32 %8 to i64
  %10 = add nsw i64 %0, -1
  %11 = icmp ult i64 %10, %9
  br i1 %11, label %12, label %47

12:                                               ; preds = %6
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %14 = icmp eq ptr %13, null
  br i1 %14, label %47, label %15

15:                                               ; preds = %12
  %16 = getelementptr %struct.NmsView, ptr %13, i64 %0
  %17 = getelementptr i8, ptr %16, i64 -16
  %18 = load ptr, ptr %17, align 8, !tbaa !24
  %19 = icmp eq ptr %18, null
  %20 = select i1 %19, i32 6, i32 1
  br label %47

21:                                               ; preds = %1
  br i1 %4, label %22, label %47

22:                                               ; preds = %21
  %23 = and i64 %0, 9223372036854775807
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %25 = freeze i32 %24
  %26 = zext i32 %25 to i64
  %27 = add nsw i64 %23, -1
  %28 = icmp ult i64 %27, %26
  br i1 %28, label %29, label %47

29:                                               ; preds = %22
  %30 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %31 = icmp eq ptr %30, null
  br i1 %31, label %47, label %32

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw %struct.NmsSlot, ptr %30, i64 %23
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !19
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %47, label %37

37:                                               ; preds = %32
  %38 = and i64 %0, 4294967295
  %39 = getelementptr inbounds nuw %struct.NmsSlot, ptr %30, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 28
  %41 = load i32, ptr %40, align 4, !tbaa !22
  %42 = add i32 %41, -2
  %43 = icmp ult i32 %42, 3
  br i1 %43, label %44, label %47

44:                                               ; preds = %37
  %45 = getelementptr inbounds nuw i8, ptr %39, i64 16
  %46 = load i32, ptr %45, align 8, !tbaa !33
  br label %52

47:                                               ; preds = %5, %6, %12, %15, %21, %22, %29, %32, %37
  %48 = phi i32 [ 5, %21 ], [ 1, %37 ], [ 6, %29 ], [ 6, %12 ], [ 6, %6 ], [ 5, %5 ], [ 6, %32 ], [ %20, %15 ], [ 6, %22 ]
  %49 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %50 = icmp eq i32 %49, 0
  br i1 %50, label %51, label %52

51:                                               ; preds = %47
  store i32 %48, ptr @nms_module_error, align 4, !tbaa !4
  br label %52

52:                                               ; preds = %44, %47, %51
  %53 = phi i32 [ %46, %44 ], [ 0, %47 ], [ 0, %51 ]
  ret i32 %53
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_replace(i64 noundef %0, i64 noundef %1, i64 noundef %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #24
  store i64 0, ptr %4, align 8, !tbaa !15
  %5 = call i32 @nms_replace_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef nonnull %4) #23
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !4
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i64, ptr %4, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  ret i64 %12
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_case(i64 noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  store i64 0, ptr %3, align 8, !tbaa !15
  %4 = call i32 @nms_case_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, ptr noundef nonnull %3) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  ret i64 %11
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_trim(i64 noundef %0) local_unnamed_addr #3 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #24
  store i64 0, ptr %2, align 8, !tbaa !15
  %3 = call i32 @nms_trim_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #23
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !4
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #24
  ret i64 %10
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_substr(i64 noundef %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #24
  store i64 0, ptr %4, align 8, !tbaa !15
  %5 = call i32 @nms_substr_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull %4) #23
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !4
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i64, ptr %4, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #24
  ret i64 %12
}

; Function Attrs: nounwind
define dso_local i64 @nms_module_concat(i64 noundef %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  store i64 0, ptr %3, align 8, !tbaa !15
  %4 = call i32 @nms_concat_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3) #23
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !4
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i64 0, 4294967296) i64 @nms_module_length(i64 noundef %0) local_unnamed_addr #16 {
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %4, label %45

4:                                                ; preds = %1
  %5 = icmp sgt i64 %0, -1
  br i1 %5, label %29, label %6

6:                                                ; preds = %4
  %7 = and i64 %0, 9223372036854775807
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %9 = freeze i32 %8
  %10 = zext i32 %9 to i64
  %11 = add nsw i64 %7, -1
  %12 = icmp ult i64 %11, %10
  br i1 %12, label %13, label %45

13:                                               ; preds = %6
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %15 = icmp eq ptr %14, null
  br i1 %15, label %45, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw %struct.NmsSlot, ptr %14, i64 %7
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 8
  %19 = load i64, ptr %18, align 8, !tbaa !19
  %20 = icmp eq i64 %19, 0
  br i1 %20, label %45, label %21

21:                                               ; preds = %16
  %22 = and i64 %0, 4294967295
  %23 = getelementptr inbounds nuw %struct.NmsSlot, ptr %14, i64 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 28
  %25 = load i32, ptr %24, align 4, !tbaa !22
  %26 = icmp eq i32 %25, 1
  br i1 %26, label %27, label %45

27:                                               ; preds = %21
  %28 = getelementptr inbounds nuw i8, ptr %23, i64 16
  br label %50

29:                                               ; preds = %4
  %30 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %31 = freeze i32 %30
  %32 = zext i32 %31 to i64
  %33 = add nsw i64 %0, -1
  %34 = icmp ult i64 %33, %32
  br i1 %34, label %35, label %45

35:                                               ; preds = %29
  %36 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %37 = icmp eq ptr %36, null
  br i1 %37, label %45, label %38

38:                                               ; preds = %35
  %39 = getelementptr %struct.NmsView, ptr %36, i64 %0
  %40 = getelementptr i8, ptr %39, i64 -16
  %41 = load ptr, ptr %40, align 8, !tbaa !24
  %42 = icmp eq ptr %41, null
  br i1 %42, label %45, label %43

43:                                               ; preds = %38
  %44 = getelementptr i8, ptr %39, i64 -8
  br label %50

45:                                               ; preds = %1, %6, %13, %16, %21, %29, %35, %38
  %46 = phi i32 [ 6, %6 ], [ 6, %38 ], [ 6, %16 ], [ 5, %1 ], [ 6, %29 ], [ 6, %35 ], [ 1, %21 ], [ 6, %13 ]
  %47 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %49, label %54

49:                                               ; preds = %45
  store i32 %46, ptr @nms_module_error, align 4, !tbaa !4
  br label %54

50:                                               ; preds = %43, %27
  %51 = phi ptr [ %28, %27 ], [ %44, %43 ]
  %52 = load i32, ptr %51, align 8, !tbaa !4
  %53 = zext i32 %52 to i64
  br label %54

54:                                               ; preds = %49, %45, %50
  %55 = phi i64 [ %53, %50 ], [ 0, %45 ], [ 0, %49 ]
  ret i64 %55
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local range(i64 -4294967295, 4294967296) i64 @nms_module_order(i64 noundef %0, i64 noundef %1) local_unnamed_addr #17 {
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !16
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %92

5:                                                ; preds = %2
  %6 = icmp sgt i64 %0, -1
  br i1 %6, label %31, label %7

7:                                                ; preds = %5
  %8 = and i64 %0, 9223372036854775807
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %10 = freeze i32 %9
  %11 = zext i32 %10 to i64
  %12 = add nsw i64 %8, -1
  %13 = icmp ult i64 %12, %11
  br i1 %13, label %14, label %92

14:                                               ; preds = %7
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %16 = icmp eq ptr %15, null
  br i1 %16, label %92, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw %struct.NmsSlot, ptr %15, i64 %8
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 8
  %20 = load i64, ptr %19, align 8, !tbaa !19
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %92, label %22

22:                                               ; preds = %17
  %23 = and i64 %0, 4294967295
  %24 = getelementptr inbounds nuw %struct.NmsSlot, ptr %15, i64 %23
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 28
  %26 = load i32, ptr %25, align 4, !tbaa !22
  %27 = icmp eq i32 %26, 1
  br i1 %27, label %28, label %92

28:                                               ; preds = %22
  %29 = load ptr, ptr %24, align 8, !tbaa !23
  %30 = getelementptr inbounds nuw i8, ptr %24, i64 16
  br label %47

31:                                               ; preds = %5
  %32 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %33 = freeze i32 %32
  %34 = zext i32 %33 to i64
  %35 = add nsw i64 %0, -1
  %36 = icmp ult i64 %35, %34
  br i1 %36, label %37, label %92

37:                                               ; preds = %31
  %38 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %39 = icmp eq ptr %38, null
  br i1 %39, label %92, label %40

40:                                               ; preds = %37
  %41 = getelementptr %struct.NmsView, ptr %38, i64 %0
  %42 = getelementptr i8, ptr %41, i64 -16
  %43 = load ptr, ptr %42, align 8, !tbaa !24
  %44 = icmp eq ptr %43, null
  br i1 %44, label %92, label %45

45:                                               ; preds = %40
  %46 = getelementptr i8, ptr %41, i64 -8
  br label %47

47:                                               ; preds = %28, %45
  %48 = phi ptr [ %43, %45 ], [ %29, %28 ]
  %49 = phi ptr [ %46, %45 ], [ %30, %28 ]
  %50 = load i32, ptr %49, align 8, !tbaa !4
  %51 = icmp sgt i64 %1, -1
  br i1 %51, label %76, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 9223372036854775807
  %54 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %55 = freeze i32 %54
  %56 = zext i32 %55 to i64
  %57 = add nsw i64 %53, -1
  %58 = icmp ult i64 %57, %56
  br i1 %58, label %59, label %92

59:                                               ; preds = %52
  %60 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !18
  %61 = icmp eq ptr %60, null
  br i1 %61, label %92, label %62

62:                                               ; preds = %59
  %63 = getelementptr inbounds nuw %struct.NmsSlot, ptr %60, i64 %53
  %64 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %65 = load i64, ptr %64, align 8, !tbaa !19
  %66 = icmp eq i64 %65, 0
  br i1 %66, label %92, label %67

67:                                               ; preds = %62
  %68 = and i64 %1, 4294967295
  %69 = getelementptr inbounds nuw %struct.NmsSlot, ptr %60, i64 %68
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 28
  %71 = load i32, ptr %70, align 4, !tbaa !22
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %73, label %92

73:                                               ; preds = %67
  %74 = load ptr, ptr %69, align 8, !tbaa !23
  %75 = getelementptr inbounds nuw i8, ptr %69, i64 16
  br label %97

76:                                               ; preds = %47
  %77 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %78 = freeze i32 %77
  %79 = zext i32 %78 to i64
  %80 = add nsw i64 %1, -1
  %81 = icmp ult i64 %80, %79
  br i1 %81, label %82, label %92

82:                                               ; preds = %76
  %83 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !12
  %84 = icmp eq ptr %83, null
  br i1 %84, label %92, label %85

85:                                               ; preds = %82
  %86 = getelementptr %struct.NmsView, ptr %83, i64 %1
  %87 = getelementptr i8, ptr %86, i64 -16
  %88 = load ptr, ptr %87, align 8, !tbaa !24
  %89 = icmp eq ptr %88, null
  br i1 %89, label %92, label %90

90:                                               ; preds = %85
  %91 = getelementptr i8, ptr %86, i64 -8
  br label %97

92:                                               ; preds = %7, %22, %14, %37, %31, %2, %17, %40, %85, %82, %76, %67, %62, %59, %52
  %93 = phi i32 [ 1, %67 ], [ 6, %52 ], [ 6, %85 ], [ 6, %62 ], [ 5, %2 ], [ 6, %76 ], [ 6, %82 ], [ 6, %31 ], [ 6, %59 ], [ 6, %40 ], [ 6, %7 ], [ 1, %22 ], [ 6, %14 ], [ 6, %17 ], [ 6, %37 ]
  %94 = load i32, ptr @nms_module_error, align 4, !tbaa !4
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %96, label %123

96:                                               ; preds = %92
  store i32 %93, ptr @nms_module_error, align 4, !tbaa !4
  br label %123

97:                                               ; preds = %90, %73
  %98 = phi ptr [ %88, %90 ], [ %74, %73 ]
  %99 = phi ptr [ %91, %90 ], [ %75, %73 ]
  %100 = load i32, ptr %99, align 8, !tbaa !4
  %101 = tail call i32 @llvm.umin.i32(i32 %50, i32 %100)
  %102 = icmp eq i32 %101, 0
  br i1 %102, label %115, label %103

103:                                              ; preds = %97
  %104 = zext i32 %101 to i64
  br label %108

105:                                              ; preds = %108
  %106 = add nuw nsw i64 %109, 1
  %107 = icmp eq i64 %106, %104
  br i1 %107, label %115, label %108, !llvm.loop !115

108:                                              ; preds = %103, %105
  %109 = phi i64 [ 0, %103 ], [ %106, %105 ]
  %110 = getelementptr inbounds nuw i8, ptr %48, i64 %109
  %111 = load i8, ptr %110, align 1, !tbaa !38
  %112 = getelementptr inbounds nuw i8, ptr %98, i64 %109
  %113 = load i8, ptr %112, align 1, !tbaa !38
  %114 = icmp eq i8 %111, %113
  br i1 %114, label %105, label %119

115:                                              ; preds = %105, %97
  %116 = zext i32 %50 to i64
  %117 = zext i32 %100 to i64
  %118 = sub nsw i64 %116, %117
  br label %123

119:                                              ; preds = %108
  %120 = zext i8 %111 to i64
  %121 = zext i8 %113 to i64
  %122 = sub nsw i64 %120, %121
  br label %123

123:                                              ; preds = %119, %115, %96, %92
  %124 = phi i64 [ 0, %96 ], [ 0, %92 ], [ %122, %119 ], [ %118, %115 ]
  ret i64 %124
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i64 @nms_module_live_objects() local_unnamed_addr #15 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8, !tbaa !50
  ret i64 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define dso_local i64 @nms_module_live_bytes() local_unnamed_addr #15 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !30
  ret i64 %1
}

; Function Attrs: nounwind
declare noalias ptr @malloc(i64 noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare void @free(ptr noundef) local_unnamed_addr #3

; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @nbp_shift(ptr noundef nonnull captures(none) %0, i32 noundef %1) unnamed_addr #18 {
  %3 = alloca %struct.NbpBig, align 4
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 512
  %5 = load i32, ptr %4, align 4, !tbaa !86
  %6 = icmp ne i32 %5, 0
  %7 = icmp ne i32 %1, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %59

9:                                                ; preds = %2
  %10 = lshr i32 %1, 5
  %11 = and i32 %1, 31
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %22, label %13

13:                                               ; preds = %9
  %14 = add i32 %5, -1
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds nuw i32, ptr %0, i64 %15
  %17 = load i32, ptr %16, align 4, !tbaa !4
  %18 = sub nuw nsw i32 32, %11
  %19 = lshr i32 %17, %18
  %20 = icmp ne i32 %19, 0
  %21 = zext i1 %20 to i32
  br label %22

22:                                               ; preds = %13, %9
  %23 = phi i32 [ 0, %9 ], [ %21, %13 ]
  %24 = icmp ugt i32 %1, 4095
  br i1 %24, label %59, label %25

25:                                               ; preds = %22
  %26 = add i32 %5, %10
  %27 = add i32 %26, %23
  %28 = icmp ugt i32 %27, 128
  br i1 %28, label %59, label %29

29:                                               ; preds = %25
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %3, i8 0, i64 512, i1 false)
  %30 = getelementptr inbounds nuw i8, ptr %3, i64 512
  store i32 %27, ptr %30, align 4, !tbaa !86
  %31 = zext nneg i32 %11 to i64
  %32 = zext i32 %5 to i64
  br label %34

33:                                               ; preds = %56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %0, ptr noundef nonnull align 4 dereferenceable(516) %3, i64 516, i1 false), !tbaa.struct !91
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #24
  br label %59

34:                                               ; preds = %29, %56
  %35 = phi i64 [ 0, %29 ], [ %57, %56 ]
  %36 = getelementptr inbounds nuw i32, ptr %0, i64 %35
  %37 = load i32, ptr %36, align 4, !tbaa !4
  %38 = zext i32 %37 to i64
  %39 = shl nuw nsw i64 %38, %31
  %40 = trunc i64 %39 to i32
  %41 = trunc nuw i64 %35 to i32
  %42 = add i32 %10, %41
  %43 = zext i32 %42 to i64
  %44 = getelementptr inbounds nuw i32, ptr %3, i64 %43
  %45 = load i32, ptr %44, align 4, !tbaa !4
  %46 = or i32 %45, %40
  store i32 %46, ptr %44, align 4, !tbaa !4
  %47 = lshr i64 %39, 32
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %56, label %49

49:                                               ; preds = %34
  %50 = trunc nuw nsw i64 %47 to i32
  %51 = add i32 %42, 1
  %52 = zext i32 %51 to i64
  %53 = getelementptr inbounds nuw i32, ptr %3, i64 %52
  %54 = load i32, ptr %53, align 4, !tbaa !4
  %55 = or i32 %54, %50
  store i32 %55, ptr %53, align 4, !tbaa !4
  br label %56

56:                                               ; preds = %49, %34
  %57 = add nuw nsw i64 %35, 1
  %58 = icmp eq i64 %57, %32
  br i1 %58, label %33, label %34, !llvm.loop !116

59:                                               ; preds = %33, %25, %22, %2
  %60 = phi i32 [ 1, %2 ], [ 1, %33 ], [ 0, %25 ], [ 0, %22 ]
  ret i32 %60
}

; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define internal fastcc range(i32 0, 2) i32 @nbp_rational(ptr noundef nonnull captures(none) dead_on_return %0, ptr noundef nonnull captures(none) dead_on_return %1, i32 noundef range(i32 0, 2) %2, ptr noundef nonnull writeonly captures(none) %3) unnamed_addr #19 {
  %5 = alloca %struct.NbpBig, align 4
  %6 = alloca %struct.NbpBig, align 4
  %7 = alloca %struct.NbpBig, align 4
  %8 = alloca %struct.NbpBig, align 4
  %9 = alloca %struct.NbpBig, align 4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 512
  %11 = load i32, ptr %10, align 4, !tbaa !86
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %21, label %13

13:                                               ; preds = %4
  %14 = add i32 %11, -1
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds nuw i32, ptr %0, i64 %15
  %17 = load i32, ptr %16, align 4, !tbaa !4
  %18 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %17, i1 false)
  %19 = shl i32 %11, 5
  %20 = sub i32 %19, %18
  br label %21

21:                                               ; preds = %4, %13
  %22 = phi i32 [ %20, %13 ], [ 0, %4 ]
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 512
  %24 = load i32, ptr %23, align 4, !tbaa !86
  %25 = icmp eq i32 %24, 0
  br i1 %25, label %34, label %26

26:                                               ; preds = %21
  %27 = add i32 %24, -1
  %28 = zext i32 %27 to i64
  %29 = getelementptr inbounds nuw i32, ptr %1, i64 %28
  %30 = load i32, ptr %29, align 4, !tbaa !4
  %31 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %30, i1 false)
  %32 = shl i32 %24, 5
  %33 = sub i32 %31, %32
  br label %34

34:                                               ; preds = %21, %26
  %35 = phi i32 [ %33, %26 ], [ 0, %21 ]
  %36 = add i32 %35, %22
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #24
  %37 = icmp slt i32 %36, 0
  %38 = select i1 %37, ptr %0, ptr %1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %38, i64 516, i1 false)
  %39 = tail call i32 @llvm.abs.i32(i32 %36, i1 true)
  %40 = getelementptr inbounds nuw i8, ptr %9, i64 512
  %41 = load i32, ptr %40, align 4, !tbaa !86
  %42 = icmp ne i32 %41, 0
  %43 = icmp ne i32 %36, 0
  %44 = and i1 %43, %42
  br i1 %44, label %45, label %95

45:                                               ; preds = %34
  %46 = lshr i32 %39, 5
  %47 = and i32 %39, 31
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %58, label %49

49:                                               ; preds = %45
  %50 = add i32 %41, -1
  %51 = zext i32 %50 to i64
  %52 = getelementptr inbounds nuw i32, ptr %9, i64 %51
  %53 = load i32, ptr %52, align 4, !tbaa !4
  %54 = sub nuw nsw i32 32, %47
  %55 = lshr i32 %53, %54
  %56 = icmp ne i32 %55, 0
  %57 = zext i1 %56 to i32
  br label %58

58:                                               ; preds = %49, %45
  %59 = phi i32 [ 0, %45 ], [ %57, %49 ]
  %60 = icmp samesign ugt i32 %39, 4095
  br i1 %60, label %450, label %61

61:                                               ; preds = %58
  %62 = add i32 %41, %46
  %63 = add i32 %62, %59
  %64 = icmp ugt i32 %63, 128
  br i1 %64, label %450, label %65

65:                                               ; preds = %61
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %8, i8 0, i64 512, i1 false)
  %66 = getelementptr inbounds nuw i8, ptr %8, i64 512
  store i32 %63, ptr %66, align 4, !tbaa !86
  %67 = zext nneg i32 %47 to i64
  %68 = zext i32 %41 to i64
  br label %70

69:                                               ; preds = %92
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %8, i64 516, i1 false), !tbaa.struct !91
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #24
  br label %95

70:                                               ; preds = %92, %65
  %71 = phi i64 [ 0, %65 ], [ %93, %92 ]
  %72 = getelementptr inbounds nuw i32, ptr %9, i64 %71
  %73 = load i32, ptr %72, align 4, !tbaa !4
  %74 = zext i32 %73 to i64
  %75 = shl nuw nsw i64 %74, %67
  %76 = trunc i64 %75 to i32
  %77 = trunc nuw i64 %71 to i32
  %78 = add i32 %46, %77
  %79 = zext i32 %78 to i64
  %80 = getelementptr inbounds nuw i32, ptr %8, i64 %79
  %81 = load i32, ptr %80, align 4, !tbaa !4
  %82 = or i32 %81, %76
  store i32 %82, ptr %80, align 4, !tbaa !4
  %83 = lshr i64 %75, 32
  %84 = icmp eq i64 %83, 0
  br i1 %84, label %92, label %85

85:                                               ; preds = %70
  %86 = trunc nuw nsw i64 %83 to i32
  %87 = add i32 %78, 1
  %88 = zext i32 %87 to i64
  %89 = getelementptr inbounds nuw i32, ptr %8, i64 %88
  %90 = load i32, ptr %89, align 4, !tbaa !4
  %91 = or i32 %90, %86
  store i32 %91, ptr %89, align 4, !tbaa !4
  br label %92

92:                                               ; preds = %85, %70
  %93 = add nuw nsw i64 %71, 1
  %94 = icmp eq i64 %93, %68
  br i1 %94, label %69, label %70, !llvm.loop !116

95:                                               ; preds = %69, %34
  %96 = load i32, ptr %40, align 4, !tbaa !86
  br i1 %37, label %97, label %115

97:                                               ; preds = %95
  %98 = icmp eq i32 %96, %24
  br i1 %98, label %99, label %101

99:                                               ; preds = %97
  %100 = zext i32 %24 to i64
  br label %103

101:                                              ; preds = %97
  %102 = icmp ugt i32 %96, %24
  br i1 %102, label %138, label %133

103:                                              ; preds = %106, %99
  %104 = phi i64 [ %100, %99 ], [ %107, %106 ]
  %105 = icmp eq i64 %104, 0
  br i1 %105, label %135, label %106

106:                                              ; preds = %103
  %107 = add nsw i64 %104, -1
  %108 = getelementptr inbounds nuw i32, ptr %9, i64 %107
  %109 = load i32, ptr %108, align 4, !tbaa !4
  %110 = getelementptr inbounds nuw i32, ptr %1, i64 %107
  %111 = load i32, ptr %110, align 4, !tbaa !4
  %112 = icmp eq i32 %109, %111
  br i1 %112, label %103, label %113, !llvm.loop !117

113:                                              ; preds = %106
  %114 = icmp ugt i32 %109, %111
  br i1 %114, label %135, label %133

115:                                              ; preds = %95
  %116 = icmp eq i32 %11, %96
  br i1 %116, label %117, label %119

117:                                              ; preds = %115
  %118 = zext i32 %11 to i64
  br label %121

119:                                              ; preds = %115
  %120 = icmp ugt i32 %11, %96
  br i1 %120, label %135, label %133

121:                                              ; preds = %124, %117
  %122 = phi i64 [ %118, %117 ], [ %125, %124 ]
  %123 = icmp eq i64 %122, 0
  br i1 %123, label %135, label %124

124:                                              ; preds = %121
  %125 = add nsw i64 %122, -1
  %126 = getelementptr inbounds nuw i32, ptr %0, i64 %125
  %127 = load i32, ptr %126, align 4, !tbaa !4
  %128 = getelementptr inbounds nuw i32, ptr %9, i64 %125
  %129 = load i32, ptr %128, align 4, !tbaa !4
  %130 = icmp eq i32 %127, %129
  br i1 %130, label %121, label %131, !llvm.loop !117

131:                                              ; preds = %124
  %132 = icmp ugt i32 %127, %129
  br i1 %132, label %135, label %133

133:                                              ; preds = %101, %113, %119, %131
  %134 = add nsw i32 %36, -1
  br label %135

135:                                              ; preds = %121, %103, %131, %119, %113, %133
  %136 = phi i32 [ %134, %133 ], [ %36, %119 ], [ %36, %103 ], [ %36, %131 ], [ %36, %113 ], [ %36, %121 ]
  %137 = icmp sgt i32 %136, 1023
  br i1 %137, label %448, label %138

138:                                              ; preds = %101, %135
  %139 = phi i32 [ %136, %135 ], [ %36, %101 ]
  %140 = icmp sgt i32 %139, -1023
  %141 = sub nsw i32 52, %139
  %142 = select i1 %140, i32 %141, i32 1074
  %143 = icmp slt i32 %142, 0
  %144 = select i1 %143, ptr %1, ptr %0
  %145 = tail call i32 @llvm.abs.i32(i32 %142, i1 true)
  %146 = getelementptr inbounds nuw i8, ptr %144, i64 512
  %147 = load i32, ptr %146, align 4, !tbaa !86
  %148 = icmp ne i32 %147, 0
  %149 = icmp ne i32 %142, 0
  %150 = and i1 %148, %149
  br i1 %150, label %151, label %202

151:                                              ; preds = %138
  %152 = lshr i32 %145, 5
  %153 = and i32 %145, 31
  %154 = icmp eq i32 %153, 0
  br i1 %154, label %164, label %155

155:                                              ; preds = %151
  %156 = add i32 %147, -1
  %157 = zext i32 %156 to i64
  %158 = getelementptr inbounds nuw i32, ptr %144, i64 %157
  %159 = load i32, ptr %158, align 4, !tbaa !4
  %160 = sub nuw nsw i32 32, %153
  %161 = lshr i32 %159, %160
  %162 = icmp ne i32 %161, 0
  %163 = zext i1 %162 to i32
  br label %164

164:                                              ; preds = %155, %151
  %165 = phi i32 [ 0, %151 ], [ %163, %155 ]
  %166 = icmp samesign ugt i32 %145, 4095
  br i1 %166, label %450, label %167

167:                                              ; preds = %164
  %168 = add i32 %152, %147
  %169 = add i32 %168, %165
  %170 = icmp ugt i32 %169, 128
  br i1 %170, label %450, label %171

171:                                              ; preds = %167
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %7, i8 0, i64 512, i1 false)
  %172 = getelementptr inbounds nuw i8, ptr %7, i64 512
  store i32 %169, ptr %172, align 4, !tbaa !86
  %173 = zext nneg i32 %153 to i64
  %174 = zext i32 %147 to i64
  br label %177

175:                                              ; preds = %199
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %144, ptr noundef nonnull align 4 dereferenceable(516) %7, i64 516, i1 false), !tbaa.struct !91
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #24
  %176 = load i32, ptr %10, align 4, !tbaa !86
  br label %202

177:                                              ; preds = %199, %171
  %178 = phi i64 [ 0, %171 ], [ %200, %199 ]
  %179 = getelementptr inbounds nuw i32, ptr %144, i64 %178
  %180 = load i32, ptr %179, align 4, !tbaa !4
  %181 = zext i32 %180 to i64
  %182 = shl nuw nsw i64 %181, %173
  %183 = trunc i64 %182 to i32
  %184 = trunc nuw i64 %178 to i32
  %185 = add i32 %152, %184
  %186 = zext i32 %185 to i64
  %187 = getelementptr inbounds nuw i32, ptr %7, i64 %186
  %188 = load i32, ptr %187, align 4, !tbaa !4
  %189 = or i32 %188, %183
  store i32 %189, ptr %187, align 4, !tbaa !4
  %190 = lshr i64 %182, 32
  %191 = icmp eq i64 %190, 0
  br i1 %191, label %199, label %192

192:                                              ; preds = %177
  %193 = trunc nuw nsw i64 %190 to i32
  %194 = add i32 %185, 1
  %195 = zext i32 %194 to i64
  %196 = getelementptr inbounds nuw i32, ptr %7, i64 %195
  %197 = load i32, ptr %196, align 4, !tbaa !4
  %198 = or i32 %197, %193
  store i32 %198, ptr %196, align 4, !tbaa !4
  br label %199

199:                                              ; preds = %192, %177
  %200 = add nuw nsw i64 %178, 1
  %201 = icmp eq i64 %200, %174
  br i1 %201, label %175, label %177, !llvm.loop !116

202:                                              ; preds = %175, %138
  %203 = phi i32 [ %176, %175 ], [ %11, %138 ]
  %204 = icmp eq i32 %203, 0
  br i1 %204, label %213, label %205

205:                                              ; preds = %202
  %206 = add i32 %203, -1
  %207 = zext i32 %206 to i64
  %208 = getelementptr inbounds nuw i32, ptr %0, i64 %207
  %209 = load i32, ptr %208, align 4, !tbaa !4
  %210 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %209, i1 false)
  %211 = shl i32 %203, 5
  %212 = sub i32 %211, %210
  br label %213

213:                                              ; preds = %202, %205
  %214 = phi i32 [ %212, %205 ], [ 0, %202 ]
  %215 = load i32, ptr %23, align 4, !tbaa !86
  %216 = icmp eq i32 %215, 0
  br i1 %216, label %225, label %217

217:                                              ; preds = %213
  %218 = add i32 %215, -1
  %219 = zext i32 %218 to i64
  %220 = getelementptr inbounds nuw i32, ptr %1, i64 %219
  %221 = load i32, ptr %220, align 4, !tbaa !4
  %222 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %221, i1 false)
  %223 = shl i32 %215, 5
  %224 = sub i32 %222, %223
  br label %225

225:                                              ; preds = %213, %217
  %226 = phi i32 [ %224, %217 ], [ 0, %213 ]
  %227 = add i32 %226, %214
  %228 = icmp sgt i32 %227, 63
  br i1 %228, label %450, label %229

229:                                              ; preds = %225
  %230 = icmp sgt i32 %227, -1
  br i1 %230, label %231, label %369

231:                                              ; preds = %229
  %232 = getelementptr inbounds nuw i8, ptr %6, i64 512
  %233 = zext nneg i32 %227 to i64
  br label %234

234:                                              ; preds = %231, %363
  %235 = phi i32 [ %203, %231 ], [ %364, %363 ]
  %236 = phi i32 [ %203, %231 ], [ %365, %363 ]
  %237 = phi i64 [ %233, %231 ], [ %367, %363 ]
  %238 = phi i64 [ 0, %231 ], [ %366, %363 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %1, i64 516, i1 false), !tbaa.struct !91
  %239 = load i32, ptr %40, align 4, !tbaa !86
  %240 = icmp ne i32 %239, 0
  %241 = icmp ne i64 %237, 0
  %242 = and i1 %241, %240
  br i1 %242, label %243, label %294

243:                                              ; preds = %234
  %244 = trunc nuw nsw i64 %237 to i32
  %245 = lshr i32 %244, 5
  %246 = and i32 %244, 31
  %247 = icmp eq i32 %246, 0
  br i1 %247, label %257, label %248

248:                                              ; preds = %243
  %249 = add i32 %239, -1
  %250 = zext i32 %249 to i64
  %251 = getelementptr inbounds nuw i32, ptr %9, i64 %250
  %252 = load i32, ptr %251, align 4, !tbaa !4
  %253 = sub nuw nsw i32 32, %246
  %254 = lshr i32 %252, %253
  %255 = icmp ne i32 %254, 0
  %256 = zext i1 %255 to i32
  br label %257

257:                                              ; preds = %248, %243
  %258 = phi i32 [ 0, %243 ], [ %256, %248 ]
  %259 = icmp samesign ugt i64 %237, 4095
  br i1 %259, label %450, label %260

260:                                              ; preds = %257
  %261 = add i32 %239, %245
  %262 = add i32 %261, %258
  %263 = icmp ugt i32 %262, 128
  br i1 %263, label %450, label %264

264:                                              ; preds = %260
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %6, i8 0, i64 512, i1 false)
  store i32 %262, ptr %232, align 4, !tbaa !86
  %265 = and i64 %237, 31
  %266 = zext i32 %239 to i64
  br label %269

267:                                              ; preds = %291
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %6, i64 516, i1 false), !tbaa.struct !91
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #24
  %268 = load i32, ptr %40, align 4, !tbaa !86
  br label %294

269:                                              ; preds = %291, %264
  %270 = phi i64 [ 0, %264 ], [ %292, %291 ]
  %271 = getelementptr inbounds nuw i32, ptr %9, i64 %270
  %272 = load i32, ptr %271, align 4, !tbaa !4
  %273 = zext i32 %272 to i64
  %274 = shl nuw nsw i64 %273, %265
  %275 = trunc i64 %274 to i32
  %276 = trunc nuw i64 %270 to i32
  %277 = add i32 %245, %276
  %278 = zext i32 %277 to i64
  %279 = getelementptr inbounds nuw i32, ptr %6, i64 %278
  %280 = load i32, ptr %279, align 4, !tbaa !4
  %281 = or i32 %280, %275
  store i32 %281, ptr %279, align 4, !tbaa !4
  %282 = lshr i64 %274, 32
  %283 = icmp eq i64 %282, 0
  br i1 %283, label %291, label %284

284:                                              ; preds = %269
  %285 = trunc nuw nsw i64 %282 to i32
  %286 = add i32 %277, 1
  %287 = zext i32 %286 to i64
  %288 = getelementptr inbounds nuw i32, ptr %6, i64 %287
  %289 = load i32, ptr %288, align 4, !tbaa !4
  %290 = or i32 %289, %285
  store i32 %290, ptr %288, align 4, !tbaa !4
  br label %291

291:                                              ; preds = %284, %269
  %292 = add nuw nsw i64 %270, 1
  %293 = icmp eq i64 %292, %266
  br i1 %293, label %267, label %269, !llvm.loop !116

294:                                              ; preds = %267, %234
  %295 = phi i32 [ %268, %267 ], [ %239, %234 ]
  %296 = icmp eq i32 %236, %295
  br i1 %296, label %297, label %299

297:                                              ; preds = %294
  %298 = zext i32 %236 to i64
  br label %301

299:                                              ; preds = %294
  %300 = icmp ugt i32 %236, %295
  br i1 %300, label %315, label %363

301:                                              ; preds = %304, %297
  %302 = phi i64 [ %298, %297 ], [ %305, %304 ]
  %303 = icmp eq i64 %302, 0
  br i1 %303, label %313, label %304

304:                                              ; preds = %301
  %305 = add nsw i64 %302, -1
  %306 = getelementptr inbounds nuw i32, ptr %0, i64 %305
  %307 = load i32, ptr %306, align 4, !tbaa !4
  %308 = getelementptr inbounds nuw i32, ptr %9, i64 %305
  %309 = load i32, ptr %308, align 4, !tbaa !4
  %310 = icmp eq i32 %307, %309
  br i1 %310, label %301, label %311, !llvm.loop !117

311:                                              ; preds = %304
  %312 = icmp ugt i32 %307, %309
  br i1 %312, label %313, label %363

313:                                              ; preds = %301, %311
  %314 = icmp eq i32 %236, 0
  br i1 %314, label %358, label %315

315:                                              ; preds = %299, %313
  %316 = zext i32 %295 to i64
  br label %335

317:                                              ; preds = %343
  %318 = icmp eq i32 %354, 0
  br i1 %318, label %358, label %319

319:                                              ; preds = %317
  %320 = add nsw i64 %355, -1
  %321 = and i64 %320, 4294967295
  %322 = getelementptr inbounds nuw i32, ptr %0, i64 %321
  %323 = load i32, ptr %322, align 4, !tbaa !4
  %324 = icmp eq i32 %323, 0
  br i1 %324, label %331, label %358

325:                                              ; preds = %331
  %326 = add nsw i64 %332, -1
  %327 = and i64 %326, 4294967295
  %328 = getelementptr inbounds nuw i32, ptr %0, i64 %327
  %329 = load i32, ptr %328, align 4, !tbaa !4
  %330 = icmp eq i32 %329, 0
  br i1 %330, label %331, label %358, !llvm.loop !118

331:                                              ; preds = %319, %325
  %332 = phi i64 [ %326, %325 ], [ %320, %319 ]
  %333 = trunc i64 %332 to i32
  store i32 %333, ptr %10, align 4, !tbaa !86
  %334 = icmp eq i32 %333, 0
  br i1 %334, label %357, label %325, !llvm.loop !118

335:                                              ; preds = %343, %315
  %336 = phi i64 [ 0, %315 ], [ %353, %343 ]
  %337 = phi i64 [ 0, %315 ], [ %352, %343 ]
  %338 = icmp samesign ult i64 %336, %316
  br i1 %338, label %339, label %343

339:                                              ; preds = %335
  %340 = getelementptr inbounds nuw i32, ptr %9, i64 %336
  %341 = load i32, ptr %340, align 4, !tbaa !4
  %342 = zext i32 %341 to i64
  br label %343

343:                                              ; preds = %339, %335
  %344 = phi i64 [ %342, %339 ], [ 0, %335 ]
  %345 = add nuw nsw i64 %344, %337
  %346 = getelementptr inbounds nuw i32, ptr %0, i64 %336
  %347 = load i32, ptr %346, align 4, !tbaa !4
  %348 = zext i32 %347 to i64
  %349 = trunc i64 %345 to i32
  %350 = sub i32 %347, %349
  store i32 %350, ptr %346, align 4, !tbaa !4
  %351 = icmp samesign ugt i64 %345, %348
  %352 = zext i1 %351 to i64
  %353 = add nuw nsw i64 %336, 1
  %354 = load i32, ptr %10, align 4, !tbaa !86
  %355 = zext i32 %354 to i64
  %356 = icmp samesign ult i64 %353, %355
  br i1 %356, label %335, label %317, !llvm.loop !119

357:                                              ; preds = %331
  br label %358, !llvm.loop !118

358:                                              ; preds = %325, %319, %357, %313, %317
  %359 = phi i32 [ 0, %317 ], [ %235, %313 ], [ 0, %357 ], [ %354, %319 ], [ %333, %325 ]
  %360 = phi i32 [ 0, %317 ], [ 0, %313 ], [ 0, %357 ], [ %354, %319 ], [ %333, %325 ]
  %361 = shl nuw i64 1, %237
  %362 = or i64 %361, %238
  br label %363

363:                                              ; preds = %299, %311, %358
  %364 = phi i32 [ %359, %358 ], [ %235, %311 ], [ %235, %299 ]
  %365 = phi i32 [ %360, %358 ], [ %236, %311 ], [ %236, %299 ]
  %366 = phi i64 [ %362, %358 ], [ %238, %311 ], [ %238, %299 ]
  %367 = add nsw i64 %237, -1
  %368 = icmp sgt i64 %237, 0
  br i1 %368, label %234, label %369, !llvm.loop !120

369:                                              ; preds = %363, %229
  %370 = phi i32 [ %203, %229 ], [ %364, %363 ]
  %371 = phi i64 [ 0, %229 ], [ %366, %363 ]
  %372 = icmp eq i32 %370, 0
  br i1 %372, label %402, label %373

373:                                              ; preds = %369
  %374 = add i32 %370, -1
  %375 = zext i32 %374 to i64
  %376 = getelementptr inbounds nuw i32, ptr %0, i64 %375
  %377 = load i32, ptr %376, align 4, !tbaa !4
  %378 = lshr i32 %377, 31
  %379 = add i32 %378, %370
  %380 = icmp ugt i32 %379, 128
  br i1 %380, label %450, label %381

381:                                              ; preds = %373
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %5, i8 0, i64 512, i1 false)
  %382 = getelementptr inbounds nuw i8, ptr %5, i64 512
  store i32 %379, ptr %382, align 4, !tbaa !86
  %383 = zext i32 %370 to i64
  br label %386

384:                                              ; preds = %400
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %0, ptr noundef nonnull align 4 dereferenceable(516) %5, i64 516, i1 false), !tbaa.struct !91
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #24
  %385 = load i32, ptr %10, align 4, !tbaa !86
  br label %402

386:                                              ; preds = %400, %381
  %387 = phi i64 [ 0, %381 ], [ %395, %400 ]
  %388 = getelementptr inbounds nuw i32, ptr %0, i64 %387
  %389 = load i32, ptr %388, align 4, !tbaa !4
  %390 = shl i32 %389, 1
  %391 = getelementptr inbounds nuw i32, ptr %5, i64 %387
  %392 = load i32, ptr %391, align 4, !tbaa !4
  %393 = or i32 %392, %390
  store i32 %393, ptr %391, align 4, !tbaa !4
  %394 = icmp sgt i32 %389, -1
  %395 = add nuw nsw i64 %387, 1
  br i1 %394, label %400, label %396

396:                                              ; preds = %386
  %397 = getelementptr inbounds nuw i32, ptr %5, i64 %395
  %398 = load i32, ptr %397, align 4, !tbaa !4
  %399 = or i32 %398, 1
  store i32 %399, ptr %397, align 4, !tbaa !4
  br label %400

400:                                              ; preds = %386, %396
  %401 = icmp eq i64 %395, %383
  br i1 %401, label %384, label %386, !llvm.loop !116

402:                                              ; preds = %369, %384
  %403 = phi i32 [ 0, %369 ], [ %385, %384 ]
  %404 = load i32, ptr %23, align 4, !tbaa !86
  %405 = icmp eq i32 %403, %404
  br i1 %405, label %406, label %408

406:                                              ; preds = %402
  %407 = zext i32 %403 to i64
  br label %410

408:                                              ; preds = %402
  %409 = icmp ugt i32 %403, %404
  br i1 %409, label %427, label %429

410:                                              ; preds = %413, %406
  %411 = phi i64 [ %407, %406 ], [ %414, %413 ]
  %412 = icmp eq i64 %411, 0
  br i1 %412, label %422, label %413

413:                                              ; preds = %410
  %414 = add nsw i64 %411, -1
  %415 = getelementptr inbounds nuw i32, ptr %0, i64 %414
  %416 = load i32, ptr %415, align 4, !tbaa !4
  %417 = getelementptr inbounds nuw i32, ptr %1, i64 %414
  %418 = load i32, ptr %417, align 4, !tbaa !4
  %419 = icmp eq i32 %416, %418
  br i1 %419, label %410, label %420, !llvm.loop !117

420:                                              ; preds = %413
  %421 = icmp ugt i32 %416, %418
  br i1 %421, label %427, label %429

422:                                              ; preds = %410
  %423 = icmp eq i32 %2, 0
  %424 = and i64 %371, 1
  %425 = icmp eq i64 %424, 0
  %426 = select i1 %423, i1 %425, i1 false
  br i1 %426, label %429, label %427

427:                                              ; preds = %420, %408, %422
  %428 = add i64 %371, 1
  br label %429

429:                                              ; preds = %408, %420, %422, %427
  %430 = phi i64 [ %428, %427 ], [ %371, %422 ], [ %371, %420 ], [ %371, %408 ]
  br i1 %140, label %431, label %446

431:                                              ; preds = %429
  %432 = icmp eq i64 %430, 9007199254740992
  %433 = zext i1 %432 to i32
  %434 = add nsw i32 %139, %433
  %435 = select i1 %432, i64 4503599627370496, i64 %430
  %436 = icmp sgt i32 %434, 1023
  br i1 %436, label %448, label %437

437:                                              ; preds = %431
  %438 = and i64 %435, -4503599627370496
  %439 = icmp eq i64 %438, 4503599627370496
  br i1 %439, label %440, label %450

440:                                              ; preds = %437
  %441 = add nsw i32 %434, 1023
  %442 = zext nneg i32 %441 to i64
  %443 = shl nuw nsw i64 %442, 52
  %444 = add nsw i64 %435, -4503599627370496
  %445 = or disjoint i64 %443, %444
  br label %448

446:                                              ; preds = %429
  %447 = icmp ugt i64 %430, 4503599627370496
  br i1 %447, label %450, label %448

448:                                              ; preds = %440, %446, %431, %135
  %449 = phi i64 [ 9218868437227405312, %431 ], [ 9218868437227405312, %135 ], [ %445, %440 ], [ %430, %446 ]
  store i64 %449, ptr %3, align 8, !tbaa !15
  br label %450

450:                                              ; preds = %257, %260, %448, %164, %167, %58, %61, %373, %446, %437, %225
  %451 = phi i32 [ 0, %167 ], [ 0, %373 ], [ 0, %58 ], [ 0, %225 ], [ 0, %164 ], [ 0, %446 ], [ 0, %61 ], [ 0, %437 ], [ 1, %448 ], [ 0, %260 ], [ 0, %257 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #24
  ret i32 %451
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #20

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.usub.sat.i32(i32, i32) #20

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #20

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #20

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #20

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.abs.i64(i64, i1 immarg) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #20

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #20

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.cttz.i32(i32, i1 immarg) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v16i32(<16 x i32>) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v4i32(<4 x i32>) #21

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nounwind "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #6 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nofree norecurse nosync nounwind memory(read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #9 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #11 = { nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #12 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #13 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #14 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #15 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #16 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #17 = { nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #18 = { inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #19 = { inlinehint nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #20 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #21 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #22 = { nobuiltin nounwind "no-builtins" }
attributes #23 = { nobuiltin "no-builtins" }
attributes #24 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.errno.tbaa = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 4}
!4 = !{!5, !5, i64 0}
!5 = !{!"int", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = !{!9, !10, i64 0}
!9 = !{!"", !10, i64 0, !5, i64 8, !5, i64 12, !10, i64 16, !10, i64 24, !10, i64 32, !5, i64 40, !5, i64 44, !11, i64 48, !11, i64 56, !5, i64 64, !5, i64 68, !5, i64 72, !5, i64 76, !5, i64 80}
!10 = !{!"any pointer", !6, i64 0}
!11 = !{!"long", !6, i64 0}
!12 = !{!9, !10, i64 16}
!13 = !{!9, !5, i64 64}
!14 = !{!10, !10, i64 0}
!15 = !{!11, !11, i64 0}
!16 = !{!9, !5, i64 80}
!17 = !{!9, !5, i64 68}
!18 = !{!9, !10, i64 24}
!19 = !{!20, !11, i64 8}
!20 = !{!"", !21, i64 0, !11, i64 8, !5, i64 16, !5, i64 20, !5, i64 24, !5, i64 28, !5, i64 32, !5, i64 36, !5, i64 40}
!21 = !{!"p1 omnipotent char", !10, i64 0}
!22 = !{!20, !5, i64 28}
!23 = !{!20, !21, i64 0}
!24 = !{!25, !21, i64 0}
!25 = !{!"", !21, i64 0, !5, i64 8}
!26 = !{!25, !5, i64 8}
!27 = !{!9, !5, i64 44}
!28 = !{!9, !10, i64 32}
!29 = !{!9, !5, i64 40}
!30 = !{!9, !11, i64 48}
!31 = !{!9, !5, i64 72}
!32 = !{!20, !5, i64 40}
!33 = !{!20, !5, i64 16}
!34 = !{!20, !5, i64 20}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.mustprogress"}
!37 = !{!20, !5, i64 24}
!38 = !{!6, !6, i64 0}
!39 = distinct !{!39, !36}
!40 = !{!9, !5, i64 12}
!41 = !{!9, !5, i64 8}
!42 = !{!43, !5, i64 4}
!43 = !{!"", !5, i64 0, !5, i64 4}
!44 = !{!20, !5, i64 32}
!45 = distinct !{!45, !36}
!46 = distinct !{!46, !36}
!47 = distinct !{!47, !36}
!48 = !{!20, !5, i64 36}
!49 = !{!9, !5, i64 76}
!50 = !{!9, !11, i64 56}
!51 = !{!43, !5, i64 0}
!52 = distinct !{!52, !36, !53}
!53 = !{!"llvm.loop.peeled.count", i32 1}
!54 = distinct !{!54, !36}
!55 = !{i64 0, i64 8, !15, i64 8, i64 4, !4}
!56 = distinct !{!56, !36}
!57 = distinct !{!57, !36}
!58 = !{!59, !59, i64 0}
!59 = !{!"double", !6, i64 0}
!60 = distinct !{!60, !36}
!61 = distinct !{!61, !36}
!62 = distinct !{!62, !36}
!63 = distinct !{!63, !36}
!64 = distinct !{!64, !36}
!65 = distinct !{!65, !36}
!66 = distinct !{!66, !36}
!67 = distinct !{!67, !36}
!68 = distinct !{!68, !36, !69, !70}
!69 = !{!"llvm.loop.isvectorized", i32 1}
!70 = !{!"llvm.loop.unroll.runtime.disable"}
!71 = !{!"branch_weights", i32 4, i32 28}
!72 = distinct !{!72, !36, !69, !70}
!73 = distinct !{!73, !36, !70, !69}
!74 = distinct !{!74, !36, !69, !70}
!75 = !{!"branch_weights", i32 8, i32 24}
!76 = distinct !{!76, !36, !69, !70}
!77 = distinct !{!77, !36, !70, !69}
!78 = distinct !{!78, !36, !69, !70}
!79 = distinct !{!79, !36, !70, !69}
!80 = distinct !{!80, !36, !69, !70}
!81 = distinct !{!81, !36, !69}
!82 = distinct !{!82, !36}
!83 = distinct !{!83, !36}
!84 = distinct !{!84, !36}
!85 = distinct !{!85, !36}
!86 = !{!87, !5, i64 512}
!87 = !{!"", !6, i64 0, !5, i64 512}
!88 = distinct !{!88, !36}
!89 = distinct !{!89, !36}
!90 = distinct !{!90, !36}
!91 = !{i64 0, i64 512, !38, i64 512, i64 4, !4}
!92 = distinct !{!92, !36}
!93 = distinct !{!93, !36}
!94 = distinct !{!94, !36}
!95 = distinct !{!95, !36}
!96 = distinct !{!96, !36}
!97 = distinct !{!97, !36}
!98 = distinct !{!98, !36}
!99 = distinct !{!99, !36}
!100 = distinct !{!100, !36}
!101 = distinct !{!101, !36}
!102 = distinct !{!102, !36}
!103 = distinct !{!103, !36}
!104 = distinct !{!104, !36}
!105 = distinct !{!105, !36}
!106 = distinct !{!106, !36}
!107 = distinct !{!107, !36}
!108 = distinct !{!108, !36}
!109 = distinct !{!109, !36}
!110 = distinct !{!110, !36}
!111 = distinct !{!111, !36}
!112 = !{!113, !11, i64 0}
!113 = !{!"", !11, i64 0, !5, i64 8}
!114 = !{!113, !5, i64 8}
!115 = distinct !{!115, !36}
!116 = distinct !{!116, !36}
!117 = distinct !{!117, !36}
!118 = distinct !{!118, !36}
!119 = distinct !{!119, !36}
!120 = distinct !{!120, !36}
