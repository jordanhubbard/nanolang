; ModuleID = 'src/nanoisa/managed_module.c'
source_filename = "src/nanoisa/managed_module.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.2.0"

%struct.NmsRuntime = type { ptr, i32, i32, ptr, ptr, ptr, i32, i32, i64, i64, i32, i32, i32, i32, i32 }
%struct.NbpBig = type { [128 x i32], i32 }
%struct.NmsValue = type { i64, i32 }

@.str = private unnamed_addr constant [5 x i8] c"true\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"false\00", align 1
@nms_module_error = internal unnamed_addr global i32 0, align 4
@nms_module_ready = internal unnamed_addr global i1 false, align 4
@nms_module_instance = internal global %struct.NmsRuntime zeroinitializer, align 8

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: write)
define void @nms_init(ptr nofree noundef writeonly captures(none) initializes((0, 84)) %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #0 {
  store ptr null, ptr %0, align 8, !tbaa !8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store <2 x i32> zeroinitializer, ptr %4, align 8, !tbaa !12
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store ptr %1, ptr %5, align 8, !tbaa !13
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 64
  store i32 %2, ptr %6, align 8, !tbaa !14
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store <2 x ptr> splat (ptr null), ptr %7, align 8, !tbaa !15
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store <2 x i32> zeroinitializer, ptr %8, align 8, !tbaa !12
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 48
  store <2 x i64> zeroinitializer, ptr %10, align 8, !tbaa !16
  store <4 x i32> zeroinitializer, ptr %9, align 4, !tbaa !12
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_view(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp ne ptr %0, null
  %5 = icmp ne ptr %2, null
  %6 = and i1 %4, %5
  br i1 %6, label %7, label %61

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !17
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %61

11:                                               ; preds = %7
  %12 = icmp sgt i64 %1, -1
  br i1 %12, label %39, label %13

13:                                               ; preds = %11
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %61, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %18 = load i32, ptr %17, align 4, !tbaa !18
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  br i1 %20, label %61, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %23 = load ptr, ptr %22, align 8, !tbaa !19
  %24 = icmp eq ptr %23, null
  br i1 %24, label %61, label %25

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw [48 x i8], ptr %23, i64 %14
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load i64, ptr %27, align 8, !tbaa !20
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %61, label %30

30:                                               ; preds = %25
  %31 = and i64 %1, 4294967295
  %32 = getelementptr inbounds nuw [48 x i8], ptr %23, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 28
  %34 = load i32, ptr %33, align 4, !tbaa !23
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %36, label %61

36:                                               ; preds = %30
  %37 = load ptr, ptr %32, align 8, !tbaa !24
  store ptr %37, ptr %2, align 8, !tbaa !25
  %38 = getelementptr inbounds nuw i8, ptr %32, i64 16
  br label %57

39:                                               ; preds = %11
  %40 = icmp eq i64 %1, 0
  br i1 %40, label %61, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %43 = load i32, ptr %42, align 8, !tbaa !14
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %1, %44
  br i1 %45, label %61, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %48 = load ptr, ptr %47, align 8, !tbaa !13
  %49 = icmp eq ptr %48, null
  br i1 %49, label %61, label %50

50:                                               ; preds = %46
  %51 = getelementptr [16 x i8], ptr %48, i64 %1
  %52 = getelementptr i8, ptr %51, i64 -16
  %53 = load ptr, ptr %52, align 8, !tbaa !25
  %54 = icmp eq ptr %53, null
  br i1 %54, label %61, label %55

55:                                               ; preds = %50
  store ptr %53, ptr %2, align 8, !tbaa !25
  %56 = getelementptr i8, ptr %51, i64 -8
  br label %57

57:                                               ; preds = %55, %36
  %58 = phi ptr [ %38, %36 ], [ %56, %55 ]
  %59 = load i32, ptr %58, align 8, !tbaa !12
  %60 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i32 %59, ptr %60, align 8, !tbaa !27
  br label %61

61:                                               ; preds = %57, %21, %25, %16, %13, %30, %50, %39, %41, %46, %7, %3
  %62 = phi i32 [ 6, %3 ], [ 6, %50 ], [ 6, %25 ], [ 5, %7 ], [ 6, %39 ], [ 6, %46 ], [ 6, %41 ], [ 6, %21 ], [ 1, %30 ], [ 6, %13 ], [ 6, %16 ], [ 0, %57 ]
  ret i32 %62
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_prepare_collection(ptr nofree noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %27, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !17
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %27

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %9 = load i32, ptr %8, align 4, !tbaa !28
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %27

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %13 = load i32, ptr %12, align 4, !tbaa !18
  %14 = zext i32 %13 to i64
  %15 = add nuw nsw i64 %14, 1
  %16 = mul nuw nsw i64 %15, 9
  %17 = add nuw nsw i64 %16, 3
  %18 = and i64 %17, 274877906940
  %19 = shl nuw nsw i64 %15, 2
  %20 = add nuw nsw i64 %18, %19
  %21 = tail call ptr @malloc(i64 noundef %20) #24
  %22 = icmp eq ptr %21, null
  br i1 %22, label %27, label %23

23:                                               ; preds = %11
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr %21, ptr %24, align 8, !tbaa !29
  %25 = load i32, ptr %12, align 4, !tbaa !18
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store i32 %25, ptr %26, align 8, !tbaa !30
  store i32 1, ptr %8, align 4, !tbaa !28
  br label %27

27:                                               ; preds = %23, %11, %7, %3, %1
  %28 = phi i32 [ 6, %1 ], [ 5, %3 ], [ 0, %7 ], [ 0, %23 ], [ 3, %11 ]
  ret i32 %28
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_string_array_create(ptr nofree noundef captures(address_is_null) %0, ptr nofree noundef writeonly captures(address_is_null) %1) local_unnamed_addr #3 {
  %3 = icmp ne ptr %0, null
  %4 = icmp ne ptr %1, null
  %5 = and i1 %3, %4
  br i1 %5, label %6, label %12

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !17
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 2, i64 noundef 0, ptr noundef %1) #25
  br label %12

12:                                               ; preds = %6, %2, %10
  %13 = phi i32 [ 6, %2 ], [ %11, %10 ], [ 5, %6 ]
  ret i32 %13
}

; Function Attrs: nounwind ssp
define internal fastcc range(i32 0, 4) i32 @publish_slot(ptr nofree noundef nonnull captures(none) %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef range(i32 1, 6) %4, i64 noundef range(i64 0, 68719476721) %5, ptr nofree noundef nonnull writeonly captures(none) %6) unnamed_addr #3 {
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %9 = load i64, ptr %8, align 8, !tbaa !31
  %10 = xor i64 %9, -1
  %11 = icmp ugt i64 %5, %10
  br i1 %11, label %122, label %12

12:                                               ; preds = %7
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %14 = load i32, ptr %13, align 4, !tbaa !18
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %16 = load i32, ptr %15, align 8, !tbaa !32
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %21, label %18

18:                                               ; preds = %12
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %20 = load ptr, ptr %19, align 8, !tbaa !19
  br label %105

21:                                               ; preds = %12
  %22 = icmp ugt i32 %14, -3
  br i1 %22, label %122, label %23

23:                                               ; preds = %21
  %24 = icmp eq i32 %14, 0
  %25 = tail call i32 @llvm.smax.i32(i32 %14, i32 -1)
  %26 = shl i32 %25, 1
  %27 = select i1 %24, i32 8, i32 %26
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %29 = load ptr, ptr %28, align 8, !tbaa !19
  %30 = icmp eq i32 %27, %14
  br i1 %30, label %105, label %31

31:                                               ; preds = %23
  %32 = zext i32 %27 to i64
  %33 = mul nuw nsw i64 %32, 48
  %34 = add nuw nsw i64 %33, 48
  %35 = tail call ptr @malloc(i64 noundef %34) #24
  %36 = icmp eq ptr %35, null
  br i1 %36, label %122, label %37

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %39 = load i32, ptr %38, align 4, !tbaa !28
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %51, label %41

41:                                               ; preds = %37
  %42 = or disjoint i64 %32, 1
  %43 = mul nuw nsw i64 %42, 9
  %44 = add nuw nsw i64 %43, 3
  %45 = and i64 %44, 137438953468
  %46 = shl nuw nsw i64 %42, 2
  %47 = add nuw nsw i64 %45, %46
  %48 = tail call ptr @malloc(i64 noundef %47) #24
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %41
  tail call void @free(ptr noundef nonnull %35) #26
  br label %122

51:                                               ; preds = %41, %37
  %52 = phi ptr [ %48, %41 ], [ null, %37 ]
  %53 = load ptr, ptr %28, align 8, !tbaa !19
  %54 = icmp eq ptr %53, null
  br label %58

55:                                               ; preds = %91
  %56 = load i32, ptr %38, align 4, !tbaa !28
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %100, label %94

58:                                               ; preds = %51, %91
  %59 = phi i64 [ 0, %51 ], [ %92, %91 ]
  br i1 %54, label %80, label %60

60:                                               ; preds = %58
  %61 = load i32, ptr %13, align 4, !tbaa !18
  %62 = zext i32 %61 to i64
  %63 = icmp samesign ugt i64 %59, %62
  br i1 %63, label %80, label %64

64:                                               ; preds = %60
  %65 = getelementptr inbounds nuw [48 x i8], ptr %53, i64 %59
  %66 = load ptr, ptr %65, align 8, !tbaa !24
  %67 = getelementptr inbounds nuw [48 x i8], ptr %35, i64 %59
  store ptr %66, ptr %67, align 8, !tbaa !24
  %68 = getelementptr inbounds nuw i8, ptr %65, i64 8
  %69 = load i64, ptr %68, align 8, !tbaa !20
  %70 = getelementptr inbounds nuw i8, ptr %67, i64 8
  store i64 %69, ptr %70, align 8, !tbaa !20
  %71 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %72 = getelementptr inbounds nuw i8, ptr %67, i64 16
  %73 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %74 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %75 = load <2 x i32>, ptr %73, align 8, !tbaa !12
  store <2 x i32> %75, ptr %74, align 8, !tbaa !12
  %76 = getelementptr inbounds nuw i8, ptr %65, i64 40
  %77 = load i32, ptr %76, align 8, !tbaa !33
  %78 = getelementptr inbounds nuw i8, ptr %67, i64 40
  store i32 %77, ptr %78, align 8, !tbaa !33
  %79 = load <4 x i32>, ptr %71, align 8, !tbaa !12
  store <4 x i32> %79, ptr %72, align 8, !tbaa !12
  br label %91

80:                                               ; preds = %60, %58
  %81 = getelementptr inbounds nuw [48 x i8], ptr %35, i64 %59
  store ptr null, ptr %81, align 8, !tbaa !24
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 8
  store i64 0, ptr %82, align 8, !tbaa !20
  %83 = getelementptr inbounds nuw i8, ptr %81, i64 16
  store i32 0, ptr %83, align 8, !tbaa !34
  %84 = getelementptr inbounds nuw i8, ptr %81, i64 24
  store <4 x i32> zeroinitializer, ptr %84, align 8, !tbaa !12
  %85 = getelementptr inbounds nuw i8, ptr %81, i64 40
  store i32 0, ptr %85, align 8, !tbaa !33
  %86 = icmp samesign ult i64 %59, %32
  %87 = trunc nuw i64 %59 to i32
  %88 = add i32 %87, 1
  %89 = select i1 %86, i32 %88, i32 0
  %90 = getelementptr inbounds nuw i8, ptr %81, i64 20
  store i32 %89, ptr %90, align 4, !tbaa !35
  br label %91

91:                                               ; preds = %64, %80
  %92 = add nuw nsw i64 %59, 1
  %93 = icmp eq i64 %59, %32
  br i1 %93, label %55, label %58, !llvm.loop !36

94:                                               ; preds = %55
  %95 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %96 = load ptr, ptr %95, align 8, !tbaa !29
  store ptr %52, ptr %95, align 8, !tbaa !29
  %97 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store i32 %27, ptr %97, align 8, !tbaa !30
  %98 = icmp eq ptr %96, null
  br i1 %98, label %100, label %99

99:                                               ; preds = %94
  tail call void @free(ptr noundef nonnull %96) #26
  br label %100

100:                                              ; preds = %99, %94, %55
  store ptr %35, ptr %28, align 8, !tbaa !19
  %101 = load i32, ptr %13, align 4, !tbaa !18
  %102 = add i32 %101, 1
  store i32 %102, ptr %15, align 8, !tbaa !32
  store i32 %27, ptr %13, align 4, !tbaa !18
  br i1 %54, label %105, label %103

103:                                              ; preds = %100
  tail call void @free(ptr noundef nonnull %53) #26
  %104 = load i32, ptr %15, align 8, !tbaa !32
  br label %105

105:                                              ; preds = %103, %100, %18, %23
  %106 = phi i32 [ %16, %18 ], [ 0, %23 ], [ %102, %100 ], [ %104, %103 ]
  %107 = phi ptr [ %20, %18 ], [ %29, %23 ], [ %35, %100 ], [ %35, %103 ]
  %108 = zext i32 %106 to i64
  %109 = getelementptr inbounds nuw [48 x i8], ptr %107, i64 %108
  %110 = getelementptr inbounds nuw i8, ptr %109, i64 20
  %111 = load i32, ptr %110, align 4, !tbaa !35
  store i32 %111, ptr %15, align 8, !tbaa !32
  store ptr %1, ptr %109, align 8, !tbaa !24
  %112 = getelementptr inbounds nuw i8, ptr %109, i64 16
  store i32 %2, ptr %112, align 8, !tbaa !34
  %113 = getelementptr inbounds nuw i8, ptr %109, i64 32
  store <2 x i32> zeroinitializer, ptr %113, align 8, !tbaa !12
  %114 = getelementptr inbounds nuw i8, ptr %109, i64 40
  store i32 0, ptr %114, align 8, !tbaa !33
  %115 = getelementptr inbounds nuw i8, ptr %109, i64 28
  store i32 %4, ptr %115, align 4, !tbaa !23
  %116 = getelementptr inbounds nuw i8, ptr %109, i64 24
  store i32 %3, ptr %116, align 8, !tbaa !38
  %117 = getelementptr inbounds nuw i8, ptr %109, i64 8
  store i64 1, ptr %117, align 8, !tbaa !20
  store i32 0, ptr %110, align 4, !tbaa !35
  %118 = load <2 x i64>, ptr %8, align 8, !tbaa !16
  %119 = insertelement <2 x i64> <i64 poison, i64 1>, i64 %5, i64 0
  %120 = add <2 x i64> %118, %119
  store <2 x i64> %120, ptr %8, align 8, !tbaa !16
  %121 = or disjoint i64 %108, -9223372036854775808
  store i64 %121, ptr %6, align 8, !tbaa !16
  br label %122

122:                                              ; preds = %21, %50, %31, %105, %7
  %123 = phi i32 [ 3, %7 ], [ 3, %21 ], [ 0, %105 ], [ 3, %50 ], [ 3, %31 ]
  ret i32 %123
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_string_array_append(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2) local_unnamed_addr #3 {
  %4 = icmp sgt i64 %1, -1
  %5 = icmp eq ptr %0, null
  br i1 %4, label %6, label %28

6:                                                ; preds = %3
  br i1 %5, label %231, label %7

7:                                                ; preds = %6
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !17
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %231

11:                                               ; preds = %7
  %12 = icmp eq i64 %1, 0
  br i1 %12, label %231, label %13

13:                                               ; preds = %11
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %15 = load i32, ptr %14, align 8, !tbaa !14
  %16 = zext i32 %15 to i64
  %17 = icmp samesign ugt i64 %1, %16
  br i1 %17, label %231, label %18

18:                                               ; preds = %13
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %20 = load ptr, ptr %19, align 8, !tbaa !13
  %21 = icmp eq ptr %20, null
  br i1 %21, label %231, label %22

22:                                               ; preds = %18
  %23 = getelementptr [16 x i8], ptr %20, i64 %1
  %24 = getelementptr i8, ptr %23, i64 -16
  %25 = load ptr, ptr %24, align 8, !tbaa !25
  %26 = icmp eq ptr %25, null
  %27 = select i1 %26, i32 6, i32 1
  br label %231

28:                                               ; preds = %3
  br i1 %5, label %231, label %29

29:                                               ; preds = %28
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %31 = load i32, ptr %30, align 8, !tbaa !17
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %33, label %231

33:                                               ; preds = %29
  %34 = and i64 %1, 9223372036854775807
  %35 = icmp eq i64 %34, 0
  br i1 %35, label %231, label %36

36:                                               ; preds = %33
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %38 = load i32, ptr %37, align 4, !tbaa !18
  %39 = freeze i32 %38
  %40 = zext i32 %39 to i64
  %41 = icmp samesign ugt i64 %34, %40
  br i1 %41, label %231, label %42

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %44 = load ptr, ptr %43, align 8, !tbaa !19
  %45 = icmp eq ptr %44, null
  br i1 %45, label %231, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw [48 x i8], ptr %44, i64 %34
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 8
  %49 = load i64, ptr %48, align 8, !tbaa !20
  %50 = icmp eq i64 %49, 0
  br i1 %50, label %231, label %51

51:                                               ; preds = %46
  %52 = and i64 %1, 4294967295
  %53 = getelementptr inbounds nuw [48 x i8], ptr %44, i64 %52
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 28
  %55 = load i32, ptr %54, align 4, !tbaa !23
  %56 = icmp eq i32 %55, 2
  br i1 %56, label %57, label %231

57:                                               ; preds = %51
  %58 = icmp sgt i64 %2, -1
  br i1 %58, label %74, label %59

59:                                               ; preds = %57
  %60 = and i64 %2, 9223372036854775807
  %61 = add nsw i64 %60, -1
  %62 = icmp ult i64 %61, %40
  br i1 %62, label %63, label %231

63:                                               ; preds = %59
  %64 = getelementptr inbounds nuw [48 x i8], ptr %44, i64 %60
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 8
  %66 = load i64, ptr %65, align 8, !tbaa !20
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %231, label %68

68:                                               ; preds = %63
  %69 = and i64 %2, 4294967295
  %70 = getelementptr inbounds nuw [48 x i8], ptr %44, i64 %69
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 28
  %72 = load i32, ptr %71, align 4, !tbaa !23
  %73 = icmp eq i32 %72, 1
  br i1 %73, label %90, label %231

74:                                               ; preds = %57
  %75 = icmp eq i64 %2, 0
  br i1 %75, label %231, label %76

76:                                               ; preds = %74
  %77 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %78 = load i32, ptr %77, align 8, !tbaa !14
  %79 = zext i32 %78 to i64
  %80 = icmp samesign ugt i64 %2, %79
  br i1 %80, label %231, label %81

81:                                               ; preds = %76
  %82 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %83 = load ptr, ptr %82, align 8, !tbaa !13
  %84 = icmp eq ptr %83, null
  br i1 %84, label %231, label %85

85:                                               ; preds = %81
  %86 = getelementptr [16 x i8], ptr %83, i64 %2
  %87 = getelementptr i8, ptr %86, i64 -16
  %88 = load ptr, ptr %87, align 8, !tbaa !25
  %89 = icmp eq ptr %88, null
  br i1 %89, label %231, label %90

90:                                               ; preds = %85, %68
  %91 = getelementptr inbounds nuw i8, ptr %53, i64 16
  %92 = load i32, ptr %91, align 8, !tbaa !34
  %93 = icmp eq i32 %92, -1
  br i1 %93, label %231, label %94

94:                                               ; preds = %90
  %95 = getelementptr inbounds nuw i8, ptr %53, i64 24
  %96 = load i32, ptr %95, align 8, !tbaa !38
  %97 = load ptr, ptr %53, align 8, !tbaa !24
  %98 = icmp eq i32 %92, %96
  br i1 %98, label %99, label %159

99:                                               ; preds = %94
  %100 = icmp eq i32 %92, 0
  %101 = shl i32 %92, 1
  %102 = icmp sgt i32 %92, -1
  %103 = select i1 %102, i32 %101, i32 -1
  %104 = select i1 %100, i32 4, i32 %103
  %105 = sub i32 %104, %92
  %106 = zext i32 %105 to i64
  %107 = shl nuw nsw i64 %106, 3
  %108 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %109 = load i64, ptr %108, align 8, !tbaa !31
  %110 = xor i64 %109, -1
  %111 = icmp ugt i64 %107, %110
  br i1 %111, label %231, label %112

112:                                              ; preds = %99
  %113 = zext i32 %104 to i64
  %114 = shl nuw nsw i64 %113, 3
  %115 = tail call ptr @malloc(i64 noundef %114) #24
  %116 = icmp eq ptr %115, null
  br i1 %116, label %231, label %117

117:                                              ; preds = %112
  %118 = load ptr, ptr %53, align 8, !tbaa !24
  %119 = load i32, ptr %91, align 8, !tbaa !34
  %120 = freeze i32 %119
  %121 = icmp eq i32 %120, 0
  br i1 %121, label %159, label %122

122:                                              ; preds = %117
  %123 = zext i32 %120 to i64
  %124 = shl nuw nsw i64 %123, 3
  %125 = add nsw i64 %124, -1
  %126 = urem i64 %125, 3
  %127 = add nuw nsw i64 %126, 1
  %128 = icmp ne i64 %127, 3
  %129 = select i1 %128, i64 %127, i64 0
  %130 = sub nsw i64 %124, %129
  br label %131

131:                                              ; preds = %131, %122
  %132 = phi i64 [ 0, %122 ], [ %145, %131 ]
  %133 = phi i64 [ 0, %122 ], [ %146, %131 ]
  %134 = getelementptr inbounds nuw i8, ptr %118, i64 %132
  %135 = load volatile i8, ptr %134, align 1, !tbaa !39
  %136 = getelementptr inbounds nuw i8, ptr %115, i64 %132
  store volatile i8 %135, ptr %136, align 1, !tbaa !39
  %137 = add nuw nsw i64 %132, 1
  %138 = getelementptr inbounds nuw i8, ptr %118, i64 %137
  %139 = load volatile i8, ptr %138, align 1, !tbaa !39
  %140 = getelementptr inbounds nuw i8, ptr %115, i64 %137
  store volatile i8 %139, ptr %140, align 1, !tbaa !39
  %141 = add nuw nsw i64 %132, 2
  %142 = getelementptr inbounds nuw i8, ptr %118, i64 %141
  %143 = load volatile i8, ptr %142, align 1, !tbaa !39
  %144 = getelementptr inbounds nuw i8, ptr %115, i64 %141
  store volatile i8 %143, ptr %144, align 1, !tbaa !39
  %145 = add nuw nsw i64 %132, 3
  %146 = add i64 %133, 3
  %147 = icmp eq i64 %146, %130
  br i1 %147, label %148, label %131, !llvm.loop !40

148:                                              ; preds = %131
  br i1 %128, label %149, label %159

149:                                              ; preds = %148
  tail call void @llvm.assume(i1 %128)
  br label %150

150:                                              ; preds = %150, %149
  %151 = phi i64 [ %156, %150 ], [ %145, %149 ]
  %152 = phi i64 [ %157, %150 ], [ 0, %149 ]
  %153 = getelementptr inbounds nuw i8, ptr %118, i64 %151
  %154 = load volatile i8, ptr %153, align 1, !tbaa !39
  %155 = getelementptr inbounds nuw i8, ptr %115, i64 %151
  store volatile i8 %154, ptr %155, align 1, !tbaa !39
  %156 = add nuw nsw i64 %151, 1
  %157 = add i64 %152, 1
  %158 = icmp eq i64 %157, %129
  br i1 %158, label %159, label %150, !llvm.loop !41

159:                                              ; preds = %148, %150, %117, %94
  %160 = phi i32 [ %96, %94 ], [ %104, %117 ], [ %104, %150 ], [ %104, %148 ]
  %161 = phi ptr [ %97, %94 ], [ %115, %117 ], [ %115, %150 ], [ %115, %148 ]
  %162 = load i32, ptr %30, align 8, !tbaa !17
  %163 = icmp eq i32 %162, 0
  br i1 %58, label %164, label %181

164:                                              ; preds = %159
  br i1 %163, label %165, label %205

165:                                              ; preds = %164
  %166 = icmp eq i64 %2, 0
  br i1 %166, label %205, label %167

167:                                              ; preds = %165
  %168 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %169 = load i32, ptr %168, align 8, !tbaa !14
  %170 = zext i32 %169 to i64
  %171 = icmp samesign ugt i64 %2, %170
  br i1 %171, label %205, label %172

172:                                              ; preds = %167
  %173 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %174 = load ptr, ptr %173, align 8, !tbaa !13
  %175 = icmp eq ptr %174, null
  br i1 %175, label %205, label %176

176:                                              ; preds = %172
  %177 = getelementptr [16 x i8], ptr %174, i64 %2
  %178 = getelementptr i8, ptr %177, i64 -16
  %179 = load ptr, ptr %178, align 8, !tbaa !25
  %180 = icmp eq ptr %179, null
  br i1 %180, label %205, label %212

181:                                              ; preds = %159
  br i1 %163, label %182, label %205

182:                                              ; preds = %181
  %183 = and i64 %2, 9223372036854775807
  %184 = icmp eq i64 %183, 0
  br i1 %184, label %205, label %185

185:                                              ; preds = %182
  %186 = load i32, ptr %37, align 4, !tbaa !18
  %187 = zext i32 %186 to i64
  %188 = icmp samesign ugt i64 %183, %187
  br i1 %188, label %205, label %189

189:                                              ; preds = %185
  %190 = load ptr, ptr %43, align 8, !tbaa !19
  %191 = icmp eq ptr %190, null
  br i1 %191, label %205, label %192

192:                                              ; preds = %189
  %193 = getelementptr inbounds nuw [48 x i8], ptr %190, i64 %183
  %194 = getelementptr inbounds nuw i8, ptr %193, i64 8
  %195 = load i64, ptr %194, align 8, !tbaa !20
  %196 = icmp eq i64 %195, 0
  br i1 %196, label %205, label %197

197:                                              ; preds = %192
  %198 = and i64 %2, 4294967295
  %199 = getelementptr inbounds nuw [48 x i8], ptr %190, i64 %198
  %200 = getelementptr inbounds nuw i8, ptr %199, i64 8
  %201 = load i64, ptr %200, align 8, !tbaa !20
  %202 = icmp eq i64 %201, -1
  br i1 %202, label %205, label %203

203:                                              ; preds = %197
  %204 = add nuw i64 %201, 1
  store i64 %204, ptr %200, align 8, !tbaa !20
  br label %212

205:                                              ; preds = %176, %167, %181, %192, %164, %165, %172, %197, %182, %185, %189
  %206 = phi i32 [ 6, %167 ], [ 6, %189 ], [ 6, %185 ], [ 6, %182 ], [ 3, %197 ], [ 6, %172 ], [ 6, %165 ], [ 5, %164 ], [ 6, %192 ], [ 5, %181 ], [ 6, %176 ]
  %207 = load ptr, ptr %53, align 8, !tbaa !24
  %208 = icmp eq ptr %161, %207
  %209 = icmp eq ptr %161, null
  %210 = or i1 %209, %208
  br i1 %210, label %231, label %211

211:                                              ; preds = %205
  tail call void @free(ptr noundef nonnull %161) #26
  br label %231

212:                                              ; preds = %203, %176
  %213 = load ptr, ptr %53, align 8, !tbaa !24
  %214 = icmp eq ptr %161, %213
  br i1 %214, label %226, label %215

215:                                              ; preds = %212
  %216 = load i32, ptr %95, align 8, !tbaa !38
  %217 = sub i32 %160, %216
  %218 = zext i32 %217 to i64
  %219 = shl nuw nsw i64 %218, 3
  %220 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %221 = load i64, ptr %220, align 8, !tbaa !31
  %222 = add i64 %219, %221
  store i64 %222, ptr %220, align 8, !tbaa !31
  %223 = icmp eq ptr %213, null
  br i1 %223, label %225, label %224

224:                                              ; preds = %215
  tail call void @free(ptr noundef nonnull %213) #26
  br label %225

225:                                              ; preds = %215, %224
  store ptr %161, ptr %53, align 8, !tbaa !24
  store i32 %160, ptr %95, align 8, !tbaa !38
  br label %226

226:                                              ; preds = %225, %212
  %227 = load i32, ptr %91, align 8, !tbaa !34
  %228 = add i32 %227, 1
  store i32 %228, ptr %91, align 8, !tbaa !34
  %229 = zext i32 %227 to i64
  %230 = getelementptr inbounds nuw [8 x i8], ptr %161, i64 %229
  store i64 %2, ptr %230, align 8, !tbaa !16
  br label %231

231:                                              ; preds = %59, %68, %76, %81, %74, %63, %85, %18, %11, %7, %13, %22, %6, %29, %46, %42, %36, %33, %28, %226, %205, %112, %99, %90, %211, %51
  %232 = phi i32 [ %206, %211 ], [ 1, %51 ], [ 6, %28 ], [ 3, %90 ], [ %206, %205 ], [ 0, %226 ], [ 3, %99 ], [ 3, %112 ], [ 6, %85 ], [ 6, %18 ], [ 6, %11 ], [ 5, %7 ], [ 6, %13 ], [ %27, %22 ], [ 6, %6 ], [ 5, %29 ], [ 6, %46 ], [ 6, %42 ], [ 6, %36 ], [ 6, %33 ], [ 6, %59 ], [ 1, %68 ], [ 6, %63 ], [ 6, %76 ], [ 6, %81 ], [ 6, %74 ]
  ret i32 %232
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_retain(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = icmp sgt i64 %1, -1
  %4 = icmp eq ptr %0, null
  br i1 %3, label %5, label %27

5:                                                ; preds = %2
  br i1 %4, label %57, label %6

6:                                                ; preds = %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !17
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %57

10:                                               ; preds = %6
  %11 = icmp eq i64 %1, 0
  br i1 %11, label %57, label %12

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %14 = load i32, ptr %13, align 8, !tbaa !14
  %15 = zext i32 %14 to i64
  %16 = icmp samesign ugt i64 %1, %15
  br i1 %16, label %57, label %17

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %19 = load ptr, ptr %18, align 8, !tbaa !13
  %20 = icmp eq ptr %19, null
  br i1 %20, label %57, label %21

21:                                               ; preds = %17
  %22 = getelementptr [16 x i8], ptr %19, i64 %1
  %23 = getelementptr i8, ptr %22, i64 -16
  %24 = load ptr, ptr %23, align 8, !tbaa !25
  %25 = icmp eq ptr %24, null
  %26 = select i1 %25, i32 6, i32 0
  br label %57

27:                                               ; preds = %2
  br i1 %4, label %57, label %28

28:                                               ; preds = %27
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %30 = load i32, ptr %29, align 8, !tbaa !17
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %32, label %57

32:                                               ; preds = %28
  %33 = and i64 %1, 9223372036854775807
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %57, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %37 = load i32, ptr %36, align 4, !tbaa !18
  %38 = zext i32 %37 to i64
  %39 = icmp samesign ugt i64 %33, %38
  br i1 %39, label %57, label %40

40:                                               ; preds = %35
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !19
  %43 = icmp eq ptr %42, null
  br i1 %43, label %57, label %44

44:                                               ; preds = %40
  %45 = getelementptr inbounds nuw [48 x i8], ptr %42, i64 %33
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 8
  %47 = load i64, ptr %46, align 8, !tbaa !20
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %57, label %49

49:                                               ; preds = %44
  %50 = and i64 %1, 4294967295
  %51 = getelementptr inbounds nuw [48 x i8], ptr %42, i64 %50
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 8
  %53 = load i64, ptr %52, align 8, !tbaa !20
  %54 = icmp eq i64 %53, -1
  br i1 %54, label %57, label %55

55:                                               ; preds = %49
  %56 = add nuw i64 %53, 1
  store i64 %56, ptr %52, align 8, !tbaa !20
  br label %57

57:                                               ; preds = %21, %32, %35, %40, %44, %28, %27, %55, %49, %17, %12, %10, %6, %5
  %58 = phi i32 [ 6, %12 ], [ 6, %5 ], [ %26, %21 ], [ 6, %27 ], [ 5, %6 ], [ 6, %10 ], [ 6, %17 ], [ 0, %55 ], [ 3, %49 ], [ 6, %32 ], [ 6, %35 ], [ 6, %40 ], [ 6, %44 ], [ 5, %28 ]
  ret i32 %58
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_string_array_get(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = icmp eq ptr %3, null
  br i1 %5, label %105, label %6

6:                                                ; preds = %4
  %7 = icmp sgt i64 %1, -1
  %8 = icmp eq ptr %0, null
  br i1 %7, label %9, label %31

9:                                                ; preds = %6
  br i1 %8, label %105, label %10

10:                                               ; preds = %9
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !17
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %105

14:                                               ; preds = %10
  %15 = icmp eq i64 %1, 0
  br i1 %15, label %105, label %16

16:                                               ; preds = %14
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %18 = load i32, ptr %17, align 8, !tbaa !14
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %1, %19
  br i1 %20, label %105, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %23 = load ptr, ptr %22, align 8, !tbaa !13
  %24 = icmp eq ptr %23, null
  br i1 %24, label %105, label %25

25:                                               ; preds = %21
  %26 = getelementptr [16 x i8], ptr %23, i64 %1
  %27 = getelementptr i8, ptr %26, i64 -16
  %28 = load ptr, ptr %27, align 8, !tbaa !25
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %105

31:                                               ; preds = %6
  br i1 %8, label %105, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %34 = load i32, ptr %33, align 8, !tbaa !17
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %105

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %105, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %41 = load i32, ptr %40, align 4, !tbaa !18
  %42 = freeze i32 %41
  %43 = zext i32 %42 to i64
  %44 = icmp samesign ugt i64 %37, %43
  br i1 %44, label %105, label %45

45:                                               ; preds = %39
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %47 = load ptr, ptr %46, align 8, !tbaa !19
  %48 = icmp eq ptr %47, null
  br i1 %48, label %105, label %49

49:                                               ; preds = %45
  %50 = getelementptr inbounds nuw [48 x i8], ptr %47, i64 %37
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 8
  %52 = load i64, ptr %51, align 8, !tbaa !20
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %105, label %54

54:                                               ; preds = %49
  %55 = and i64 %1, 4294967295
  %56 = getelementptr inbounds nuw [48 x i8], ptr %47, i64 %55
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 28
  %58 = load i32, ptr %57, align 4, !tbaa !23
  %59 = icmp eq i32 %58, 2
  br i1 %59, label %60, label %105

60:                                               ; preds = %54
  %61 = getelementptr inbounds nuw i8, ptr %56, i64 16
  %62 = load i32, ptr %61, align 8, !tbaa !34
  %63 = zext i32 %62 to i64
  %64 = icmp ult i64 %2, %63
  br i1 %64, label %66, label %65

65:                                               ; preds = %60
  store i64 0, ptr %3, align 8, !tbaa !16
  br label %105

66:                                               ; preds = %60
  %67 = load ptr, ptr %56, align 8, !tbaa !24
  %68 = getelementptr inbounds nuw [8 x i8], ptr %67, i64 %2
  %69 = load i64, ptr %68, align 8, !tbaa !16
  %70 = icmp sgt i64 %69, -1
  br i1 %70, label %71, label %87

71:                                               ; preds = %66
  %72 = icmp eq i64 %69, 0
  br i1 %72, label %105, label %73

73:                                               ; preds = %71
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %75 = load i32, ptr %74, align 8, !tbaa !14
  %76 = zext i32 %75 to i64
  %77 = icmp samesign ugt i64 %69, %76
  br i1 %77, label %105, label %78

78:                                               ; preds = %73
  %79 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %80 = load ptr, ptr %79, align 8, !tbaa !13
  %81 = icmp eq ptr %80, null
  br i1 %81, label %105, label %82

82:                                               ; preds = %78
  %83 = getelementptr [16 x i8], ptr %80, i64 %69
  %84 = getelementptr i8, ptr %83, i64 -16
  %85 = load ptr, ptr %84, align 8, !tbaa !25
  %86 = icmp eq ptr %85, null
  br i1 %86, label %105, label %104

87:                                               ; preds = %66
  %88 = and i64 %69, 9223372036854775807
  %89 = add nsw i64 %88, -1
  %90 = icmp ult i64 %89, %43
  br i1 %90, label %91, label %105

91:                                               ; preds = %87
  %92 = getelementptr inbounds nuw [48 x i8], ptr %47, i64 %88
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 8
  %94 = load i64, ptr %93, align 8, !tbaa !20
  %95 = icmp eq i64 %94, 0
  br i1 %95, label %105, label %96

96:                                               ; preds = %91
  %97 = and i64 %69, 4294967295
  %98 = getelementptr inbounds nuw [48 x i8], ptr %47, i64 %97
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 8
  %100 = load i64, ptr %99, align 8, !tbaa !20
  %101 = icmp eq i64 %100, -1
  br i1 %101, label %105, label %102

102:                                              ; preds = %96
  %103 = add nuw i64 %100, 1
  store i64 %103, ptr %99, align 8, !tbaa !20
  br label %104

104:                                              ; preds = %102, %82
  store i64 %69, ptr %3, align 8, !tbaa !16
  br label %105

105:                                              ; preds = %82, %87, %96, %78, %71, %91, %73, %21, %14, %10, %16, %25, %9, %32, %49, %45, %39, %36, %31, %54, %104, %65, %4
  %106 = phi i32 [ 6, %4 ], [ 1, %54 ], [ 0, %65 ], [ 0, %104 ], [ 6, %31 ], [ 6, %21 ], [ 6, %14 ], [ 5, %10 ], [ 6, %16 ], [ %30, %25 ], [ 6, %9 ], [ 5, %32 ], [ 6, %49 ], [ 6, %45 ], [ 6, %39 ], [ 6, %36 ], [ 6, %73 ], [ 6, %91 ], [ 6, %87 ], [ 3, %96 ], [ 6, %78 ], [ 6, %71 ], [ 6, %82 ]
  ret i32 %106
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_string_array_length(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %61, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %30

8:                                                ; preds = %5
  br i1 %7, label %61, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !17
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %61

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %61, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load i32, ptr %16, align 8, !tbaa !14
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %61, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %22 = load ptr, ptr %21, align 8, !tbaa !13
  %23 = icmp eq ptr %22, null
  br i1 %23, label %61, label %24

24:                                               ; preds = %20
  %25 = getelementptr [16 x i8], ptr %22, i64 %1
  %26 = getelementptr i8, ptr %25, i64 -16
  %27 = load ptr, ptr %26, align 8, !tbaa !25
  %28 = icmp eq ptr %27, null
  %29 = select i1 %28, i32 6, i32 1
  br label %61

30:                                               ; preds = %5
  br i1 %7, label %61, label %31

31:                                               ; preds = %30
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = load i32, ptr %32, align 8, !tbaa !17
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %61

35:                                               ; preds = %31
  %36 = and i64 %1, 9223372036854775807
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %61, label %38

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !18
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %36, %41
  br i1 %42, label %61, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %45 = load ptr, ptr %44, align 8, !tbaa !19
  %46 = icmp eq ptr %45, null
  br i1 %46, label %61, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw [48 x i8], ptr %45, i64 %36
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %50 = load i64, ptr %49, align 8, !tbaa !20
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %61, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 4294967295
  %54 = getelementptr inbounds nuw [48 x i8], ptr %45, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 28
  %56 = load i32, ptr %55, align 4, !tbaa !23
  %57 = icmp eq i32 %56, 2
  br i1 %57, label %58, label %61

58:                                               ; preds = %52
  %59 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %60 = load i32, ptr %59, align 8, !tbaa !34
  store i32 %60, ptr %2, align 4, !tbaa !12
  br label %61

61:                                               ; preds = %20, %13, %9, %15, %24, %8, %31, %47, %43, %38, %35, %30, %52, %58, %3
  %62 = phi i32 [ 6, %3 ], [ 1, %52 ], [ 0, %58 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %29, %24 ], [ 6, %8 ], [ 5, %31 ], [ 6, %47 ], [ 6, %43 ], [ 6, %38 ], [ 6, %35 ], [ 6, %30 ]
  ret i32 %62
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_create(ptr nofree noundef captures(address_is_null) %0, ptr nofree noundef captures(address) %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @create_parts(ptr noundef %0, ptr noundef %1, i64 noundef %2, ptr noundef null, i64 noundef 0, ptr noundef %3) #25
  ret i32 %5
}

; Function Attrs: nounwind ssp
define internal fastcc range(i32 0, 7) i32 @create_parts(ptr nofree noundef captures(address_is_null) %0, ptr nofree noundef captures(address) %1, i64 noundef %2, ptr nofree noundef captures(address) %3, i64 noundef range(i64 0, 4294967296) %4, ptr nofree noundef writeonly captures(address_is_null) %5) unnamed_addr #3 {
  %7 = icmp ne ptr %0, null
  %8 = icmp ne ptr %5, null
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %123

10:                                               ; preds = %6
  %11 = icmp eq ptr %1, null
  %12 = icmp ne i64 %2, 0
  %13 = and i1 %11, %12
  br i1 %13, label %123, label %14

14:                                               ; preds = %10
  %15 = icmp eq ptr %3, null
  %16 = icmp ne i64 %4, 0
  %17 = and i1 %15, %16
  br i1 %17, label %123, label %18

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %20 = load i32, ptr %19, align 8, !tbaa !17
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %123

22:                                               ; preds = %18
  %23 = icmp ugt i64 %2, 4294967295
  br i1 %23, label %123, label %24

24:                                               ; preds = %22
  %25 = add nuw nsw i64 %4, %2
  %26 = icmp samesign ugt i64 %25, 4294967295
  br i1 %26, label %123, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %29 = load i64, ptr %28, align 8, !tbaa !31
  %30 = xor i64 %29, -1
  %31 = icmp ugt i64 %25, %30
  br i1 %31, label %123, label %32

32:                                               ; preds = %27
  %33 = add nuw nsw i64 %25, 1
  %34 = tail call ptr @malloc(i64 noundef %33) #24
  %35 = icmp eq ptr %34, null
  br i1 %35, label %123, label %36

36:                                               ; preds = %32
  %37 = icmp eq i64 %2, 0
  br i1 %37, label %76, label %38

38:                                               ; preds = %36
  %39 = add nsw i64 %2, -1
  %40 = urem i64 %39, 3
  %41 = add nuw nsw i64 %40, 1
  %42 = icmp ne i64 %41, 3
  %43 = select i1 %42, i64 %41, i64 0
  %44 = icmp ult i64 %2, 3
  br i1 %44, label %65, label %45

45:                                               ; preds = %38
  %46 = sub nsw i64 %2, %43
  br label %47

47:                                               ; preds = %47, %45
  %48 = phi i64 [ 0, %45 ], [ %61, %47 ]
  %49 = phi i64 [ 0, %45 ], [ %62, %47 ]
  %50 = getelementptr inbounds nuw i8, ptr %1, i64 %48
  %51 = load volatile i8, ptr %50, align 1, !tbaa !39
  %52 = getelementptr inbounds nuw i8, ptr %34, i64 %48
  store volatile i8 %51, ptr %52, align 1, !tbaa !39
  %53 = add nuw nsw i64 %48, 1
  %54 = getelementptr inbounds nuw i8, ptr %1, i64 %53
  %55 = load volatile i8, ptr %54, align 1, !tbaa !39
  %56 = getelementptr inbounds nuw i8, ptr %34, i64 %53
  store volatile i8 %55, ptr %56, align 1, !tbaa !39
  %57 = add nuw nsw i64 %48, 2
  %58 = getelementptr inbounds nuw i8, ptr %1, i64 %57
  %59 = load volatile i8, ptr %58, align 1, !tbaa !39
  %60 = getelementptr inbounds nuw i8, ptr %34, i64 %57
  store volatile i8 %59, ptr %60, align 1, !tbaa !39
  %61 = add nuw nsw i64 %48, 3
  %62 = add i64 %49, 3
  %63 = icmp eq i64 %62, %46
  br i1 %63, label %64, label %47, !llvm.loop !40

64:                                               ; preds = %47
  br i1 %42, label %65, label %76

65:                                               ; preds = %64, %38
  %66 = phi i64 [ 0, %38 ], [ %61, %64 ]
  tail call void @llvm.assume(i1 %42)
  br label %67

67:                                               ; preds = %67, %65
  %68 = phi i64 [ %73, %67 ], [ %66, %65 ]
  %69 = phi i64 [ %74, %67 ], [ 0, %65 ]
  %70 = getelementptr inbounds nuw i8, ptr %1, i64 %68
  %71 = load volatile i8, ptr %70, align 1, !tbaa !39
  %72 = getelementptr inbounds nuw i8, ptr %34, i64 %68
  store volatile i8 %71, ptr %72, align 1, !tbaa !39
  %73 = add nuw nsw i64 %68, 1
  %74 = add i64 %69, 1
  %75 = icmp eq i64 %74, %43
  br i1 %75, label %76, label %67, !llvm.loop !43

76:                                               ; preds = %64, %67, %36
  %77 = getelementptr inbounds nuw i8, ptr %34, i64 %2
  %78 = icmp eq i64 %4, 0
  br i1 %78, label %117, label %79

79:                                               ; preds = %76
  %80 = add nsw i64 %4, -1
  %81 = urem i64 %80, 3
  %82 = add nuw nsw i64 %81, 1
  %83 = icmp ne i64 %82, 3
  %84 = select i1 %83, i64 %82, i64 0
  %85 = icmp samesign ult i64 %4, 3
  br i1 %85, label %106, label %86

86:                                               ; preds = %79
  %87 = sub nsw i64 %4, %84
  br label %88

88:                                               ; preds = %88, %86
  %89 = phi i64 [ 0, %86 ], [ %102, %88 ]
  %90 = phi i64 [ 0, %86 ], [ %103, %88 ]
  %91 = getelementptr inbounds nuw i8, ptr %3, i64 %89
  %92 = load volatile i8, ptr %91, align 1, !tbaa !39
  %93 = getelementptr inbounds nuw i8, ptr %77, i64 %89
  store volatile i8 %92, ptr %93, align 1, !tbaa !39
  %94 = add nuw nsw i64 %89, 1
  %95 = getelementptr inbounds nuw i8, ptr %3, i64 %94
  %96 = load volatile i8, ptr %95, align 1, !tbaa !39
  %97 = getelementptr inbounds nuw i8, ptr %77, i64 %94
  store volatile i8 %96, ptr %97, align 1, !tbaa !39
  %98 = add nuw nsw i64 %89, 2
  %99 = getelementptr inbounds nuw i8, ptr %3, i64 %98
  %100 = load volatile i8, ptr %99, align 1, !tbaa !39
  %101 = getelementptr inbounds nuw i8, ptr %77, i64 %98
  store volatile i8 %100, ptr %101, align 1, !tbaa !39
  %102 = add nuw nsw i64 %89, 3
  %103 = add i64 %90, 3
  %104 = icmp eq i64 %103, %87
  br i1 %104, label %105, label %88, !llvm.loop !40

105:                                              ; preds = %88
  br i1 %83, label %106, label %117

106:                                              ; preds = %105, %79
  %107 = phi i64 [ 0, %79 ], [ %102, %105 ]
  tail call void @llvm.assume(i1 %83)
  br label %108

108:                                              ; preds = %108, %106
  %109 = phi i64 [ %114, %108 ], [ %107, %106 ]
  %110 = phi i64 [ %115, %108 ], [ 0, %106 ]
  %111 = getelementptr inbounds nuw i8, ptr %3, i64 %109
  %112 = load volatile i8, ptr %111, align 1, !tbaa !39
  %113 = getelementptr inbounds nuw i8, ptr %77, i64 %109
  store volatile i8 %112, ptr %113, align 1, !tbaa !39
  %114 = add nuw nsw i64 %109, 1
  %115 = add i64 %110, 1
  %116 = icmp eq i64 %115, %84
  br i1 %116, label %117, label %108, !llvm.loop !44

117:                                              ; preds = %105, %108, %76
  %118 = getelementptr inbounds nuw i8, ptr %34, i64 %25
  store i8 0, ptr %118, align 1, !tbaa !39
  %119 = trunc nuw i64 %25 to i32
  %120 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %34, i32 noundef %119, i32 noundef 0, i32 noundef 1, i64 noundef %25, ptr noundef %5) #25
  %121 = icmp eq i32 %120, 0
  br i1 %121, label %123, label %122

122:                                              ; preds = %117
  tail call void @free(ptr noundef nonnull %34) #26
  br label %123

123:                                              ; preds = %27, %24, %117, %122, %32, %22, %18, %6, %10, %14
  %124 = phi i32 [ 3, %22 ], [ 6, %6 ], [ 5, %18 ], [ 6, %14 ], [ 6, %10 ], [ 3, %24 ], [ 3, %27 ], [ 3, %32 ], [ %120, %122 ], [ 0, %117 ]
  ret i32 %124
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_value_retain(ptr nofree noundef readonly captures(address_is_null) %0, [2 x i64] %1) local_unnamed_addr #4 {
  %3 = extractvalue [2 x i64] %1, 0
  %4 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %1) #25
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %64

6:                                                ; preds = %2
  %7 = extractvalue [2 x i64] %1, 1
  %8 = trunc i64 %7 to i32
  switch i32 %8, label %64 [
    i32 8, label %9
    i32 7, label %9
    i32 5, label %9
  ]

9:                                                ; preds = %6, %6, %6
  %10 = icmp sgt i64 %3, -1
  %11 = icmp eq ptr %0, null
  br i1 %10, label %12, label %34

12:                                               ; preds = %9
  br i1 %11, label %64, label %13

13:                                               ; preds = %12
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %15 = load i32, ptr %14, align 8, !tbaa !17
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %64

17:                                               ; preds = %13
  %18 = icmp eq i64 %3, 0
  br i1 %18, label %64, label %19

19:                                               ; preds = %17
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %21 = load i32, ptr %20, align 8, !tbaa !14
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %3, %22
  br i1 %23, label %64, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %26 = load ptr, ptr %25, align 8, !tbaa !13
  %27 = icmp eq ptr %26, null
  br i1 %27, label %64, label %28

28:                                               ; preds = %24
  %29 = getelementptr [16 x i8], ptr %26, i64 %3
  %30 = getelementptr i8, ptr %29, i64 -16
  %31 = load ptr, ptr %30, align 8, !tbaa !25
  %32 = icmp eq ptr %31, null
  %33 = select i1 %32, i32 6, i32 0
  br label %64

34:                                               ; preds = %9
  br i1 %11, label %64, label %35

35:                                               ; preds = %34
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %37 = load i32, ptr %36, align 8, !tbaa !17
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %39, label %64

39:                                               ; preds = %35
  %40 = and i64 %3, 9223372036854775807
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %64, label %42

42:                                               ; preds = %39
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %44 = load i32, ptr %43, align 4, !tbaa !18
  %45 = zext i32 %44 to i64
  %46 = icmp samesign ugt i64 %40, %45
  br i1 %46, label %64, label %47

47:                                               ; preds = %42
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %49 = load ptr, ptr %48, align 8, !tbaa !19
  %50 = icmp eq ptr %49, null
  br i1 %50, label %64, label %51

51:                                               ; preds = %47
  %52 = getelementptr inbounds nuw [48 x i8], ptr %49, i64 %40
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 8
  %54 = load i64, ptr %53, align 8, !tbaa !20
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %64, label %56

56:                                               ; preds = %51
  %57 = and i64 %3, 4294967295
  %58 = getelementptr inbounds nuw [48 x i8], ptr %49, i64 %57
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 8
  %60 = load i64, ptr %59, align 8, !tbaa !20
  %61 = icmp eq i64 %60, -1
  br i1 %61, label %64, label %62

62:                                               ; preds = %56
  %63 = add nuw i64 %60, 1
  store i64 %63, ptr %59, align 8, !tbaa !20
  br label %64

64:                                               ; preds = %6, %62, %56, %51, %47, %42, %39, %35, %34, %28, %24, %19, %17, %13, %12, %2
  %65 = phi i32 [ %4, %2 ], [ 0, %6 ], [ 6, %19 ], [ 6, %12 ], [ %33, %28 ], [ 6, %34 ], [ 5, %13 ], [ 6, %17 ], [ 6, %24 ], [ 0, %62 ], [ 3, %56 ], [ 6, %39 ], [ 6, %42 ], [ 6, %47 ], [ 6, %51 ], [ 5, %35 ]
  ret i32 %65
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, inaccessiblemem: none, target_mem: none)
define internal fastcc range(i32 0, 7) i32 @value_valid(ptr nofree noundef readonly captures(address_is_null) %0, [2 x i64] %1) unnamed_addr #5 {
  %3 = extractvalue [2 x i64] %1, 0
  %4 = extractvalue [2 x i64] %1, 1
  %5 = trunc i64 %4 to i32
  %6 = icmp eq ptr %0, null
  br i1 %6, label %160, label %7

7:                                                ; preds = %2
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !17
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %160

11:                                               ; preds = %7
  switch i32 %5, label %155 [
    i32 5, label %12
    i32 7, label %55
    i32 8, label %99
  ]

12:                                               ; preds = %11
  %13 = icmp sgt i64 %3, -1
  br i1 %13, label %38, label %14

14:                                               ; preds = %12
  %15 = and i64 %3, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %160, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %160, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !19
  %25 = icmp eq ptr %24, null
  br i1 %25, label %160, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %15
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !20
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %160, label %31

31:                                               ; preds = %26
  %32 = and i64 %3, 4294967295
  %33 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !23
  %36 = icmp ne i32 %35, 1
  %37 = zext i1 %36 to i32
  br label %160

38:                                               ; preds = %12
  %39 = icmp eq i64 %3, 0
  br i1 %39, label %160, label %40

40:                                               ; preds = %38
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %42 = load i32, ptr %41, align 8, !tbaa !14
  %43 = zext i32 %42 to i64
  %44 = icmp samesign ugt i64 %3, %43
  br i1 %44, label %160, label %45

45:                                               ; preds = %40
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %47 = load ptr, ptr %46, align 8, !tbaa !13
  %48 = icmp eq ptr %47, null
  br i1 %48, label %160, label %49

49:                                               ; preds = %45
  %50 = getelementptr [16 x i8], ptr %47, i64 %3
  %51 = getelementptr i8, ptr %50, i64 -16
  %52 = load ptr, ptr %51, align 8, !tbaa !25
  %53 = icmp eq ptr %52, null
  %54 = select i1 %53, i32 6, i32 0
  br label %160

55:                                               ; preds = %11
  %56 = icmp sgt i64 %3, -1
  br i1 %56, label %57, label %74

57:                                               ; preds = %55
  %58 = icmp eq i64 %3, 0
  br i1 %58, label %160, label %59

59:                                               ; preds = %57
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %61 = load i32, ptr %60, align 8, !tbaa !14
  %62 = zext i32 %61 to i64
  %63 = icmp samesign ugt i64 %3, %62
  br i1 %63, label %160, label %64

64:                                               ; preds = %59
  %65 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %66 = load ptr, ptr %65, align 8, !tbaa !13
  %67 = icmp eq ptr %66, null
  br i1 %67, label %160, label %68

68:                                               ; preds = %64
  %69 = getelementptr [16 x i8], ptr %66, i64 %3
  %70 = getelementptr i8, ptr %69, i64 -16
  %71 = load ptr, ptr %70, align 8, !tbaa !25
  %72 = icmp eq ptr %71, null
  %73 = select i1 %72, i32 6, i32 1
  br label %160

74:                                               ; preds = %55
  %75 = and i64 %3, 9223372036854775807
  %76 = icmp eq i64 %75, 0
  br i1 %76, label %160, label %77

77:                                               ; preds = %74
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %79 = load i32, ptr %78, align 4, !tbaa !18
  %80 = zext i32 %79 to i64
  %81 = icmp samesign ugt i64 %75, %80
  br i1 %81, label %160, label %82

82:                                               ; preds = %77
  %83 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %84 = load ptr, ptr %83, align 8, !tbaa !19
  %85 = icmp eq ptr %84, null
  br i1 %85, label %160, label %86

86:                                               ; preds = %82
  %87 = getelementptr inbounds nuw [48 x i8], ptr %84, i64 %75
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 8
  %89 = load i64, ptr %88, align 8, !tbaa !20
  %90 = icmp eq i64 %89, 0
  br i1 %90, label %160, label %91

91:                                               ; preds = %86
  %92 = and i64 %3, 4294967295
  %93 = getelementptr inbounds nuw [48 x i8], ptr %84, i64 %92
  %94 = getelementptr inbounds nuw i8, ptr %93, i64 28
  %95 = load i32, ptr %94, align 4, !tbaa !23
  %96 = add i32 %95, -5
  %97 = icmp ult i32 %96, -3
  %98 = zext i1 %97 to i32
  br label %160

99:                                               ; preds = %11
  %100 = and i64 %3, 9223372036854775807
  %101 = icmp slt i64 %3, 0
  %102 = icmp ne i64 %100, 0
  %103 = and i1 %101, %102
  br i1 %103, label %104, label %160

104:                                              ; preds = %99
  %105 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %106 = load i32, ptr %105, align 4, !tbaa !18
  %107 = zext i32 %106 to i64
  %108 = icmp samesign ugt i64 %100, %107
  br i1 %108, label %160, label %109

109:                                              ; preds = %104
  %110 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %111 = load ptr, ptr %110, align 8, !tbaa !19
  %112 = icmp eq ptr %111, null
  br i1 %112, label %160, label %113

113:                                              ; preds = %109
  %114 = getelementptr inbounds nuw [48 x i8], ptr %111, i64 %100
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 8
  %116 = load i64, ptr %115, align 8, !tbaa !20
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %160, label %118

118:                                              ; preds = %113
  %119 = and i64 %3, 4294967295
  %120 = getelementptr inbounds nuw [48 x i8], ptr %111, i64 %119
  %121 = getelementptr inbounds nuw i8, ptr %120, i64 28
  %122 = load i32, ptr %121, align 4, !tbaa !23
  %123 = icmp eq i32 %122, 5
  br i1 %123, label %124, label %160

124:                                              ; preds = %118
  %125 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %126 = load i32, ptr %125, align 4, !tbaa !45
  %127 = icmp eq i32 %126, 0
  br i1 %127, label %160, label %128

128:                                              ; preds = %124
  %129 = load ptr, ptr %0, align 8, !tbaa !8
  %130 = icmp eq ptr %129, null
  br i1 %130, label %160, label %131

131:                                              ; preds = %128
  %132 = getelementptr inbounds nuw i8, ptr %120, i64 40
  %133 = load i32, ptr %132, align 8, !tbaa !33
  %134 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %135 = load i32, ptr %134, align 8, !tbaa !46
  %136 = icmp ult i32 %133, %135
  br i1 %136, label %137, label %160

137:                                              ; preds = %131
  %138 = zext i32 %133 to i64
  %139 = getelementptr inbounds nuw [8 x i8], ptr %129, i64 %138
  %140 = getelementptr inbounds nuw i8, ptr %139, i64 4
  %141 = load i32, ptr %140, align 4, !tbaa !47
  %142 = getelementptr inbounds nuw i8, ptr %120, i64 16
  %143 = load i32, ptr %142, align 8, !tbaa !34
  %144 = icmp eq i32 %143, %141
  br i1 %144, label %145, label %160

145:                                              ; preds = %137
  %146 = getelementptr inbounds nuw i8, ptr %120, i64 24
  %147 = load i32, ptr %146, align 8, !tbaa !38
  %148 = icmp eq i32 %147, %141
  br i1 %148, label %149, label %160

149:                                              ; preds = %145
  %150 = icmp eq i32 %141, 0
  br i1 %150, label %160, label %151

151:                                              ; preds = %149
  %152 = load ptr, ptr %120, align 8, !tbaa !24
  %153 = icmp eq ptr %152, null
  %154 = select i1 %153, i32 6, i32 0
  br label %160

155:                                              ; preds = %11
  %156 = icmp ugt i32 %5, 4
  %157 = icmp ne i32 %5, 9
  %158 = and i1 %156, %157
  %159 = zext i1 %158 to i32
  br label %160

160:                                              ; preds = %49, %31, %151, %149, %145, %137, %131, %128, %124, %118, %113, %109, %104, %99, %91, %86, %82, %77, %74, %68, %64, %59, %57, %45, %40, %38, %26, %22, %17, %14, %7, %2, %155
  %161 = phi i32 [ 6, %2 ], [ 5, %7 ], [ 6, %113 ], [ %73, %68 ], [ %159, %155 ], [ 6, %14 ], [ 6, %109 ], [ 6, %26 ], [ 6, %17 ], [ 6, %38 ], [ 6, %45 ], [ 6, %40 ], [ 6, %22 ], [ %54, %49 ], [ %37, %31 ], [ 6, %57 ], [ %98, %91 ], [ 6, %74 ], [ 6, %77 ], [ 6, %82 ], [ 6, %86 ], [ 6, %59 ], [ 6, %64 ], [ %154, %151 ], [ 6, %124 ], [ 1, %118 ], [ 6, %131 ], [ 6, %128 ], [ 6, %145 ], [ 6, %137 ], [ 0, %149 ], [ 6, %99 ], [ 6, %104 ]
  ret i32 %161
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_value_release(ptr nofree noundef captures(address_is_null) %0, [2 x i64] %1) local_unnamed_addr #3 {
  %3 = extractvalue [2 x i64] %1, 0
  %4 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %1) #25
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %11

6:                                                ; preds = %2
  %7 = extractvalue [2 x i64] %1, 1
  %8 = trunc i64 %7 to i32
  switch i32 %8, label %11 [
    i32 8, label %9
    i32 7, label %9
    i32 5, label %9
  ]

9:                                                ; preds = %6, %6, %6
  %10 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %3) #25
  br label %11

11:                                               ; preds = %6, %9, %2
  %12 = phi i32 [ %4, %2 ], [ %10, %9 ], [ 0, %6 ]
  ret i32 %12
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_release(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = icmp sgt i64 %1, -1
  %4 = icmp eq ptr %0, null
  br i1 %3, label %5, label %27

5:                                                ; preds = %2
  br i1 %4, label %208, label %6

6:                                                ; preds = %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !17
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %208

10:                                               ; preds = %6
  %11 = icmp eq i64 %1, 0
  br i1 %11, label %208, label %12

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %14 = load i32, ptr %13, align 8, !tbaa !14
  %15 = zext i32 %14 to i64
  %16 = icmp samesign ugt i64 %1, %15
  br i1 %16, label %208, label %17

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %19 = load ptr, ptr %18, align 8, !tbaa !13
  %20 = icmp eq ptr %19, null
  br i1 %20, label %208, label %21

21:                                               ; preds = %17
  %22 = getelementptr [16 x i8], ptr %19, i64 %1
  %23 = getelementptr i8, ptr %22, i64 -16
  %24 = load ptr, ptr %23, align 8, !tbaa !25
  %25 = icmp eq ptr %24, null
  %26 = select i1 %25, i32 6, i32 0
  br label %208

27:                                               ; preds = %2
  br i1 %4, label %208, label %28

28:                                               ; preds = %27
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %30 = load i32, ptr %29, align 8, !tbaa !17
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %32, label %208

32:                                               ; preds = %28
  %33 = and i64 %1, 9223372036854775807
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %208, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %37 = load i32, ptr %36, align 4, !tbaa !18
  %38 = zext i32 %37 to i64
  %39 = icmp samesign ugt i64 %33, %38
  br i1 %39, label %208, label %40

40:                                               ; preds = %35
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !19
  %43 = icmp eq ptr %42, null
  br i1 %43, label %208, label %44

44:                                               ; preds = %40
  %45 = getelementptr inbounds nuw [48 x i8], ptr %42, i64 %33
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 8
  %47 = load i64, ptr %46, align 8, !tbaa !20
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %208, label %49

49:                                               ; preds = %44
  %50 = and i64 %1, 4294967295
  %51 = getelementptr inbounds nuw [48 x i8], ptr %42, i64 %50
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 8
  %53 = load i64, ptr %52, align 8, !tbaa !20
  %54 = add i64 %53, -1
  store i64 %54, ptr %52, align 8, !tbaa !20
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %56, label %208

56:                                               ; preds = %49
  %57 = trunc i64 %1 to i32
  %58 = getelementptr inbounds nuw i8, ptr %51, i64 20
  store i32 0, ptr %58, align 4, !tbaa !35
  %59 = icmp eq i32 %57, 0
  br i1 %59, label %208, label %60

60:                                               ; preds = %56
  %61 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %62 = getelementptr inbounds nuw i8, ptr %0, i64 72
  br label %63

63:                                               ; preds = %60, %202
  %64 = phi i32 [ %57, %60 ], [ %193, %202 ]
  %65 = phi i32 [ 0, %60 ], [ %194, %202 ]
  %66 = load ptr, ptr %41, align 8, !tbaa !19
  %67 = zext i32 %64 to i64
  %68 = getelementptr inbounds nuw [48 x i8], ptr %66, i64 %67
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 20
  %70 = load i32, ptr %69, align 4, !tbaa !35
  %71 = getelementptr inbounds nuw i8, ptr %68, i64 28
  %72 = load i32, ptr %71, align 4, !tbaa !23
  switch i32 %72, label %164 [
    i32 5, label %73
    i32 3, label %73
    i32 2, label %73
  ]

73:                                               ; preds = %63, %63, %63
  %74 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %75 = load i32, ptr %74, align 8, !tbaa !34
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %172, label %77

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw i8, ptr %68, i64 32
  %79 = zext i32 %75 to i64
  br label %80

80:                                               ; preds = %77, %159
  %81 = phi i64 [ 0, %77 ], [ %162, %159 ]
  %82 = phi i32 [ %70, %77 ], [ %161, %159 ]
  %83 = phi i32 [ %65, %77 ], [ %160, %159 ]
  switch i32 %72, label %114 [
    i32 4, label %84
    i32 2, label %110
  ]

84:                                               ; preds = %80
  %85 = load i32, ptr %78, align 8, !tbaa !49
  %86 = and i32 %85, -3
  %87 = icmp eq i32 %86, 1
  %88 = icmp eq i32 %85, 2
  %89 = icmp eq i32 %85, 4
  %90 = or i1 %88, %89
  %91 = zext i1 %90 to i32
  %92 = select i1 %87, i32 8, i32 %91
  %93 = icmp eq i32 %92, 0
  br i1 %93, label %159, label %94

94:                                               ; preds = %84
  %95 = zext nneg i32 %92 to i64
  %96 = mul nuw nsw i64 %81, %95
  %97 = load ptr, ptr %68, align 8, !tbaa !24
  %98 = getelementptr inbounds nuw i8, ptr %97, i64 %96
  br label %99

99:                                               ; preds = %99, %94
  %100 = phi i64 [ 0, %94 ], [ %108, %99 ]
  %101 = phi i64 [ 0, %94 ], [ %107, %99 ]
  %102 = getelementptr inbounds nuw i8, ptr %98, i64 %100
  %103 = load i8, ptr %102, align 1, !tbaa !39
  %104 = zext i8 %103 to i64
  %105 = shl nuw nsw i64 %100, 3
  %106 = shl nuw i64 %104, %105
  %107 = or i64 %106, %101
  %108 = add nuw nsw i64 %100, 1
  %109 = icmp eq i64 %108, %95
  br i1 %109, label %121, label %99, !llvm.loop !50

110:                                              ; preds = %80
  %111 = load ptr, ptr %68, align 8, !tbaa !24
  %112 = getelementptr inbounds nuw [8 x i8], ptr %111, i64 %81
  %113 = load i64, ptr %112, align 8, !tbaa !16
  br label %121

114:                                              ; preds = %80
  %115 = load ptr, ptr %68, align 8, !tbaa !24
  %116 = getelementptr inbounds nuw [16 x i8], ptr %115, i64 %81
  %117 = load i64, ptr %116, align 8, !tbaa !16
  %118 = getelementptr inbounds nuw i8, ptr %116, i64 8
  %119 = load i64, ptr %118, align 8
  %120 = trunc i64 %119 to i32
  br label %121

121:                                              ; preds = %99, %110, %114
  %122 = phi i64 [ %117, %114 ], [ %113, %110 ], [ %107, %99 ]
  %123 = phi i32 [ %120, %114 ], [ 5, %110 ], [ %85, %99 ]
  %124 = and i32 %123, -3
  %125 = icmp ne i32 %124, 5
  %126 = icmp ne i32 %123, 8
  %127 = and i1 %126, %125
  %128 = icmp sgt i64 %122, -1
  %129 = select i1 %127, i1 true, i1 %128
  br i1 %129, label %159, label %130

130:                                              ; preds = %121
  %131 = load i32, ptr %29, align 8, !tbaa !17
  %132 = icmp eq i32 %131, 0
  br i1 %132, label %133, label %145

133:                                              ; preds = %130
  %134 = and i64 %122, 9223372036854775807
  %135 = icmp eq i64 %134, 0
  br i1 %135, label %145, label %136

136:                                              ; preds = %133
  %137 = load i32, ptr %36, align 4, !tbaa !18
  %138 = zext i32 %137 to i64
  %139 = icmp samesign ugt i64 %134, %138
  br i1 %139, label %145, label %140

140:                                              ; preds = %136
  %141 = getelementptr inbounds nuw [48 x i8], ptr %66, i64 %134
  %142 = getelementptr inbounds nuw i8, ptr %141, i64 8
  %143 = load i64, ptr %142, align 8, !tbaa !20
  %144 = icmp eq i64 %143, 0
  br i1 %144, label %145, label %149

145:                                              ; preds = %130, %140, %133, %136
  %146 = phi i32 [ 6, %136 ], [ 6, %133 ], [ 6, %140 ], [ 5, %130 ]
  %147 = icmp eq i32 %83, 0
  %148 = select i1 %147, i32 %146, i32 %83
  br label %159

149:                                              ; preds = %140
  %150 = and i64 %122, 4294967295
  %151 = getelementptr inbounds nuw [48 x i8], ptr %66, i64 %150
  %152 = getelementptr inbounds nuw i8, ptr %151, i64 8
  %153 = load i64, ptr %152, align 8, !tbaa !20
  %154 = add i64 %153, -1
  store i64 %154, ptr %152, align 8, !tbaa !20
  %155 = icmp eq i64 %154, 0
  br i1 %155, label %156, label %159

156:                                              ; preds = %149
  %157 = trunc i64 %122 to i32
  %158 = getelementptr inbounds nuw i8, ptr %151, i64 20
  store i32 %82, ptr %158, align 4, !tbaa !35
  br label %159

159:                                              ; preds = %84, %145, %156, %149, %121
  %160 = phi i32 [ %83, %121 ], [ %148, %145 ], [ %83, %156 ], [ %83, %149 ], [ %83, %84 ]
  %161 = phi i32 [ %82, %121 ], [ %82, %145 ], [ %157, %156 ], [ %82, %149 ], [ %82, %84 ]
  %162 = add nuw nsw i64 %81, 1
  %163 = icmp eq i64 %162, %79
  br i1 %163, label %164, label %80, !llvm.loop !51

164:                                              ; preds = %159, %63
  %165 = phi i32 [ %65, %63 ], [ %160, %159 ]
  %166 = phi i32 [ %70, %63 ], [ %161, %159 ]
  %167 = icmp eq i32 %72, 1
  br i1 %167, label %168, label %172

168:                                              ; preds = %164
  %169 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %170 = load i32, ptr %169, align 8, !tbaa !34
  %171 = zext i32 %170 to i64
  br label %192

172:                                              ; preds = %73, %164
  %173 = phi i32 [ %166, %164 ], [ %70, %73 ]
  %174 = phi i32 [ %165, %164 ], [ %65, %73 ]
  %175 = getelementptr inbounds nuw i8, ptr %68, i64 24
  %176 = load i32, ptr %175, align 8, !tbaa !38
  switch i32 %72, label %187 [
    i32 2, label %188
    i32 4, label %177
  ]

177:                                              ; preds = %172
  %178 = getelementptr inbounds nuw i8, ptr %68, i64 32
  %179 = load i32, ptr %178, align 8, !tbaa !49
  %180 = and i32 %179, -3
  %181 = icmp eq i32 %180, 1
  %182 = icmp eq i32 %179, 2
  %183 = icmp eq i32 %179, 4
  %184 = or i1 %182, %183
  %185 = zext i1 %184 to i64
  %186 = select i1 %181, i64 8, i64 %185
  br label %188

187:                                              ; preds = %172
  br label %188

188:                                              ; preds = %172, %177, %187
  %189 = phi i64 [ 8, %172 ], [ %186, %177 ], [ 16, %187 ]
  %190 = zext i32 %176 to i64
  %191 = mul nuw nsw i64 %189, %190
  br label %192

192:                                              ; preds = %188, %168
  %193 = phi i32 [ %166, %168 ], [ %173, %188 ]
  %194 = phi i32 [ %165, %168 ], [ %174, %188 ]
  %195 = phi i64 [ %171, %168 ], [ %191, %188 ]
  %196 = load <2 x i64>, ptr %61, align 8, !tbaa !16
  %197 = insertelement <2 x i64> <i64 poison, i64 1>, i64 %195, i64 0
  %198 = sub <2 x i64> %196, %197
  store <2 x i64> %198, ptr %61, align 8, !tbaa !16
  %199 = load ptr, ptr %68, align 8, !tbaa !24
  %200 = icmp eq ptr %199, null
  br i1 %200, label %202, label %201

201:                                              ; preds = %192
  tail call void @free(ptr noundef nonnull %199) #26
  br label %202

202:                                              ; preds = %192, %201
  store ptr null, ptr %68, align 8, !tbaa !24
  %203 = getelementptr inbounds nuw i8, ptr %68, i64 16
  store i32 0, ptr %203, align 8, !tbaa !34
  %204 = getelementptr inbounds nuw i8, ptr %68, i64 24
  store <4 x i32> zeroinitializer, ptr %204, align 8, !tbaa !12
  %205 = getelementptr inbounds nuw i8, ptr %68, i64 40
  store i32 0, ptr %205, align 8, !tbaa !33
  %206 = load i32, ptr %62, align 8, !tbaa !32
  store i32 %206, ptr %69, align 4, !tbaa !35
  store i32 %64, ptr %62, align 8, !tbaa !32
  %207 = icmp eq i32 %193, 0
  br i1 %207, label %208, label %63, !llvm.loop !52

208:                                              ; preds = %202, %56, %21, %32, %35, %40, %44, %28, %27, %49, %17, %12, %10, %6, %5
  %209 = phi i32 [ 6, %12 ], [ 6, %5 ], [ %26, %21 ], [ 6, %27 ], [ 5, %6 ], [ 6, %10 ], [ 6, %17 ], [ 0, %49 ], [ 5, %28 ], [ 6, %32 ], [ 6, %35 ], [ 6, %40 ], [ 6, %44 ], [ 0, %56 ], [ %194, %202 ]
  ret i32 %209
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_vm_array_create(ptr nofree noundef captures(address_is_null) %0, i32 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = tail call fastcc i32 @vm_array_create_capacity(ptr noundef %0, i32 noundef %1, i32 noundef 8, ptr noundef %2) #25
  ret i32 %4
}

; Function Attrs: nounwind ssp
define internal fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr nofree noundef captures(address_is_null) %0, i32 noundef %1, i32 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) unnamed_addr #3 {
  %5 = alloca i64, align 8
  %6 = icmp ne ptr %0, null
  %7 = icmp ne ptr %3, null
  %8 = and i1 %6, %7
  br i1 %8, label %9, label %49

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !17
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %49

13:                                               ; preds = %9
  switch i32 %1, label %49 [
    i32 9, label %14
    i32 7, label %14
    i32 5, label %14
    i32 4, label %14
    i32 3, label %14
    i32 2, label %14
    i32 1, label %14
    i32 0, label %14
  ]

14:                                               ; preds = %13, %13, %13, %13, %13, %13, %13, %13
  %15 = and i32 %1, -3
  %16 = icmp eq i32 %15, 1
  %17 = icmp eq i32 %1, 2
  %18 = icmp eq i32 %1, 4
  %19 = or i1 %17, %18
  %20 = zext i1 %19 to i32
  %21 = select i1 %16, i32 8, i32 %20
  %22 = icmp eq i32 %21, 0
  %23 = select i1 %22, i32 3, i32 4
  %24 = select i1 %22, i32 16, i32 %21
  %25 = tail call i32 @llvm.umax.i32(i32 %2, i32 8)
  %26 = zext i32 %25 to i64
  %27 = zext nneg i32 %24 to i64
  %28 = mul nuw nsw i64 %27, %26
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %30 = load i64, ptr %29, align 8, !tbaa !31
  %31 = xor i64 %30, -1
  %32 = icmp ugt i64 %28, %31
  br i1 %32, label %49, label %33

33:                                               ; preds = %14
  %34 = tail call ptr @malloc(i64 noundef %28) #24
  %35 = icmp eq ptr %34, null
  br i1 %35, label %49, label %36

36:                                               ; preds = %33
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  store i64 0, ptr %5, align 8, !tbaa !16
  %37 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %34, i32 noundef 0, i32 noundef %25, i32 noundef %23, i64 noundef %28, ptr noundef %5) #25
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %40, label %39

39:                                               ; preds = %36
  tail call void @free(ptr noundef nonnull %34) #26
  br label %48

40:                                               ; preds = %36
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !19
  %43 = load i64, ptr %5, align 8, !tbaa !16
  %44 = and i64 %43, 4294967295
  %45 = getelementptr inbounds nuw [48 x i8], ptr %42, i64 %44
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  store i32 %1, ptr %46, align 8, !tbaa !49
  %47 = getelementptr inbounds nuw i8, ptr %45, i64 36
  store i32 1, ptr %47, align 4, !tbaa !53
  store i64 %43, ptr %3, align 8, !tbaa !16
  br label %48

48:                                               ; preds = %40, %39
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  br label %49

49:                                               ; preds = %14, %33, %48, %13, %9, %4
  %50 = phi i32 [ 6, %4 ], [ 1, %13 ], [ 5, %9 ], [ 3, %14 ], [ %37, %48 ], [ 3, %33 ]
  ret i32 %50
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_packed_array_create(ptr nofree noundef captures(address_is_null) %0, i32 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  %5 = icmp ne ptr %0, null
  %6 = icmp ne ptr %2, null
  %7 = and i1 %5, %6
  br i1 %7, label %8, label %26

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !17
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %26

12:                                               ; preds = %8
  %13 = add i32 %1, -1
  %14 = icmp ult i32 %13, 4
  br i1 %14, label %15, label %26

15:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #27
  store i64 0, ptr %4, align 8, !tbaa !16
  %16 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 4, i64 noundef 0, ptr noundef %4) #25
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %25

18:                                               ; preds = %15
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %20 = load ptr, ptr %19, align 8, !tbaa !19
  %21 = load i64, ptr %4, align 8, !tbaa !16
  %22 = and i64 %21, 4294967295
  %23 = getelementptr inbounds nuw [48 x i8], ptr %20, i64 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 32
  store i32 %1, ptr %24, align 8, !tbaa !49
  store i64 %21, ptr %2, align 8, !tbaa !16
  br label %25

25:                                               ; preds = %15, %18
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  br label %26

26:                                               ; preds = %12, %8, %3, %25
  %27 = phi i32 [ 6, %3 ], [ %16, %25 ], [ 5, %8 ], [ 1, %12 ]
  ret i32 %27
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(argmem: readwrite)
define range(i32 0, 7) i32 @nms_bind_records(ptr nofree noundef captures(address_is_null) %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #6 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %69, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %7 = load i32, ptr %6, align 8, !tbaa !17
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %69

9:                                                ; preds = %5
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %11 = load i32, ptr %10, align 4, !tbaa !54
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %69

13:                                               ; preds = %9
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %15 = load i32, ptr %14, align 4, !tbaa !45
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %69

17:                                               ; preds = %13
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = icmp eq i32 %19, 0
  br i1 %20, label %21, label %69

21:                                               ; preds = %17
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %23 = load i64, ptr %22, align 8, !tbaa !55
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %69

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %27 = load i64, ptr %26, align 8, !tbaa !31
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %29, label %69

29:                                               ; preds = %25
  %30 = icmp eq i32 %2, 0
  %31 = icmp ne ptr %1, null
  %32 = or i1 %31, %30
  br i1 %32, label %33, label %69

33:                                               ; preds = %29
  %34 = icmp ugt i32 %2, 256
  br i1 %34, label %69, label %35

35:                                               ; preds = %33
  br i1 %30, label %67, label %36

36:                                               ; preds = %35
  %37 = zext nneg i32 %2 to i64
  %38 = load i32, ptr %1, align 4, !tbaa !56
  %39 = icmp ugt i32 %38, 255
  br i1 %39, label %69, label %40

40:                                               ; preds = %36
  %41 = getelementptr inbounds nuw i8, ptr %1, i64 4
  %42 = load i32, ptr %41, align 4, !tbaa !47
  %43 = icmp ugt i32 %42, 65535
  br i1 %43, label %69, label %44

44:                                               ; preds = %40
  %45 = icmp eq i32 %2, 1
  br i1 %45, label %67, label %46

46:                                               ; preds = %44, %63
  %47 = phi i64 [ %65, %63 ], [ 1, %44 ]
  %48 = phi i32 [ %64, %63 ], [ %42, %44 ]
  %49 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %47
  %50 = load i32, ptr %49, align 4, !tbaa !56
  %51 = icmp ugt i32 %50, 255
  br i1 %51, label %69, label %52

52:                                               ; preds = %46
  %53 = getelementptr i8, ptr %49, i64 -8
  %54 = load i32, ptr %53, align 4, !tbaa !56
  %55 = icmp ugt i32 %50, %54
  br i1 %55, label %56, label %69

56:                                               ; preds = %52
  %57 = getelementptr inbounds nuw i8, ptr %49, i64 4
  %58 = load i32, ptr %57, align 4, !tbaa !47
  %59 = icmp ugt i32 %58, 65535
  %60 = sub i32 65536, %48
  %61 = icmp ugt i32 %58, %60
  %62 = select i1 %59, i1 true, i1 %61
  br i1 %62, label %69, label %63

63:                                               ; preds = %56
  %64 = add i32 %58, %48
  %65 = add nuw nsw i64 %47, 1
  %66 = icmp eq i64 %65, %37
  br i1 %66, label %67, label %46, !llvm.loop !57

67:                                               ; preds = %63, %44, %35
  store ptr %1, ptr %0, align 8, !tbaa !8
  %68 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i32 %2, ptr %68, align 8, !tbaa !46
  store i32 1, ptr %14, align 4, !tbaa !45
  br label %69

69:                                               ; preds = %56, %52, %46, %36, %40, %67, %33, %13, %17, %21, %25, %29, %9, %5, %3
  %70 = phi i32 [ 6, %3 ], [ 5, %5 ], [ 4, %9 ], [ 6, %13 ], [ 1, %33 ], [ 6, %29 ], [ 6, %25 ], [ 6, %21 ], [ 6, %17 ], [ 0, %67 ], [ 1, %36 ], [ 1, %40 ], [ 1, %46 ], [ 1, %52 ], [ 1, %56 ]
  ret i32 %70
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_record_create(ptr nofree noundef captures(address_is_null) %0, i32 noundef %1, ptr nofree noundef readonly captures(address_is_null) %2, i32 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp ne ptr %0, null
  %8 = icmp ne ptr %4, null
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %115

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !17
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %115

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %16 = load i32, ptr %15, align 4, !tbaa !45
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %115, label %18

18:                                               ; preds = %14
  %19 = load ptr, ptr %0, align 8, !tbaa !8
  %20 = icmp eq ptr %19, null
  br i1 %20, label %115, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %23 = load i32, ptr %22, align 8, !tbaa !46
  %24 = icmp ult i32 %1, %23
  br i1 %24, label %25, label %115

25:                                               ; preds = %21
  %26 = zext i32 %1 to i64
  %27 = getelementptr inbounds nuw [8 x i8], ptr %19, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 4
  %29 = load i32, ptr %28, align 4, !tbaa !47
  %30 = icmp eq i32 %3, %29
  br i1 %30, label %31, label %115

31:                                               ; preds = %25
  %32 = icmp eq i32 %3, 0
  %33 = icmp ne ptr %2, null
  %34 = or i1 %33, %32
  br i1 %34, label %35, label %115

35:                                               ; preds = %31
  %36 = zext i32 %3 to i64
  %37 = shl nuw nsw i64 %36, 4
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %39 = load i64, ptr %38, align 8, !tbaa !31
  %40 = xor i64 %39, -1
  %41 = icmp ugt i64 %37, %40
  br i1 %41, label %115, label %42

42:                                               ; preds = %35
  br i1 %32, label %75, label %46

43:                                               ; preds = %46
  %44 = add nuw nsw i64 %47, 1
  %45 = icmp eq i64 %44, %36
  br i1 %45, label %56, label %46, !llvm.loop !59

46:                                               ; preds = %42, %43
  %47 = phi i64 [ %44, %43 ], [ 0, %42 ]
  %48 = getelementptr inbounds nuw [16 x i8], ptr %2, i64 %47
  %49 = load i64, ptr %48, align 8
  %50 = insertvalue [2 x i64] poison, i64 %49, 0
  %51 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %52 = load i64, ptr %51, align 8
  %53 = insertvalue [2 x i64] %50, i64 %52, 1
  %54 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %53) #25
  %55 = icmp eq i32 %54, 0
  br i1 %55, label %43, label %115

56:                                               ; preds = %43
  %57 = tail call ptr @malloc(i64 noundef %37) #24
  %58 = icmp eq ptr %57, null
  br i1 %58, label %115, label %59

59:                                               ; preds = %56, %70
  %60 = phi i64 [ %71, %70 ], [ 0, %56 ]
  %61 = getelementptr inbounds nuw [16 x i8], ptr %57, i64 %60
  %62 = getelementptr inbounds nuw [16 x i8], ptr %2, i64 %60
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %61, ptr noundef nonnull align 8 dereferenceable(16) %62, i64 16, i1 false), !tbaa.struct !60
  %63 = load i64, ptr %61, align 8
  %64 = insertvalue [2 x i64] poison, i64 %63, 0
  %65 = getelementptr inbounds nuw i8, ptr %61, i64 8
  %66 = load i64, ptr %65, align 8
  %67 = insertvalue [2 x i64] %64, i64 %66, 1
  %68 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %67) #25
  %69 = icmp eq i32 %68, 0
  br i1 %69, label %70, label %73

70:                                               ; preds = %59
  %71 = add nuw nsw i64 %60, 1
  %72 = icmp eq i64 %71, %36
  br i1 %72, label %75, label %59, !llvm.loop !61

73:                                               ; preds = %59
  %74 = trunc nuw i64 %60 to i32
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  br label %79

75:                                               ; preds = %70, %42
  %76 = phi ptr [ null, %42 ], [ %57, %70 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  %77 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef %76, i32 noundef %3, i32 noundef %3, i32 noundef 5, i64 noundef %37, ptr noundef %6) #25
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %106, label %79

79:                                               ; preds = %73, %75
  %80 = phi i32 [ %68, %73 ], [ %77, %75 ]
  %81 = phi i32 [ %74, %73 ], [ %3, %75 ]
  %82 = phi ptr [ %57, %73 ], [ %76, %75 ]
  %83 = icmp eq i32 %81, 0
  br i1 %83, label %103, label %84

84:                                               ; preds = %79
  %85 = zext i32 %81 to i64
  br label %86

86:                                               ; preds = %84, %101
  %87 = phi i64 [ %85, %84 ], [ %88, %101 ]
  %88 = add nsw i64 %87, -1
  %89 = getelementptr inbounds nuw [16 x i8], ptr %82, i64 %88
  %90 = load i64, ptr %89, align 8
  %91 = insertvalue [2 x i64] poison, i64 %90, 0
  %92 = getelementptr inbounds nuw i8, ptr %89, i64 8
  %93 = load i64, ptr %92, align 8
  %94 = insertvalue [2 x i64] %91, i64 %93, 1
  %95 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %94) #25
  %96 = icmp eq i32 %95, 0
  br i1 %96, label %97, label %101

97:                                               ; preds = %86
  %98 = trunc i64 %93 to i32
  switch i32 %98, label %101 [
    i32 8, label %99
    i32 7, label %99
    i32 5, label %99
  ]

99:                                               ; preds = %97, %97, %97
  %100 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %90) #25
  br label %101

101:                                              ; preds = %86, %97, %99
  %102 = icmp eq i64 %88, 0
  br i1 %102, label %105, label %86, !llvm.loop !62

103:                                              ; preds = %79
  %104 = icmp eq ptr %82, null
  br i1 %104, label %113, label %105

105:                                              ; preds = %101, %103
  tail call void @free(ptr noundef nonnull %82) #26
  br label %113

106:                                              ; preds = %75
  %107 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %108 = load ptr, ptr %107, align 8, !tbaa !19
  %109 = load i64, ptr %6, align 8, !tbaa !16
  %110 = and i64 %109, 4294967295
  %111 = getelementptr inbounds nuw [48 x i8], ptr %108, i64 %110
  %112 = getelementptr inbounds nuw i8, ptr %111, i64 40
  store i32 %1, ptr %112, align 8, !tbaa !33
  store i64 %109, ptr %4, align 8, !tbaa !16
  br label %113

113:                                              ; preds = %105, %103, %106
  %114 = phi i32 [ %80, %105 ], [ %80, %103 ], [ 0, %106 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  br label %115

115:                                              ; preds = %46, %35, %56, %113, %31, %25, %14, %18, %21, %10, %5
  %116 = phi i32 [ 6, %5 ], [ 5, %10 ], [ 1, %14 ], [ 6, %31 ], [ 1, %25 ], [ 1, %21 ], [ 1, %18 ], [ 3, %56 ], [ 3, %35 ], [ %114, %113 ], [ %54, %46 ]
  ret i32 %116
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_record_identity(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #1 {
  %5 = icmp eq ptr %2, null
  %6 = icmp eq ptr %3, null
  %7 = or i1 %5, %6
  %8 = icmp eq ptr %0, null
  %9 = or i1 %8, %7
  br i1 %9, label %71, label %10

10:                                               ; preds = %4
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !17
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %71

14:                                               ; preds = %10
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp slt i64 %1, 0
  %17 = icmp ne i64 %15, 0
  %18 = and i1 %16, %17
  br i1 %18, label %19, label %71

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %21 = load i32, ptr %20, align 4, !tbaa !18
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %15, %22
  br i1 %23, label %71, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !19
  %27 = icmp eq ptr %26, null
  br i1 %27, label %71, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw [48 x i8], ptr %26, i64 %15
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !20
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %71, label %33

33:                                               ; preds = %28
  %34 = and i64 %1, 4294967295
  %35 = getelementptr inbounds nuw [48 x i8], ptr %26, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 28
  %37 = load i32, ptr %36, align 4, !tbaa !23
  %38 = icmp eq i32 %37, 5
  br i1 %38, label %39, label %71

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %41 = load i32, ptr %40, align 4, !tbaa !45
  %42 = icmp eq i32 %41, 0
  br i1 %42, label %71, label %43

43:                                               ; preds = %39
  %44 = load ptr, ptr %0, align 8, !tbaa !8
  %45 = icmp eq ptr %44, null
  br i1 %45, label %71, label %46

46:                                               ; preds = %43
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 40
  %48 = load i32, ptr %47, align 8, !tbaa !33
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %50 = load i32, ptr %49, align 8, !tbaa !46
  %51 = icmp ult i32 %48, %50
  br i1 %51, label %52, label %71

52:                                               ; preds = %46
  %53 = zext i32 %48 to i64
  %54 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 4
  %56 = load i32, ptr %55, align 4, !tbaa !47
  %57 = getelementptr inbounds nuw i8, ptr %35, i64 16
  %58 = load i32, ptr %57, align 8, !tbaa !34
  %59 = icmp eq i32 %58, %56
  br i1 %59, label %60, label %71

60:                                               ; preds = %52
  %61 = getelementptr inbounds nuw i8, ptr %35, i64 24
  %62 = load i32, ptr %61, align 8, !tbaa !38
  %63 = icmp eq i32 %62, %56
  br i1 %63, label %64, label %71

64:                                               ; preds = %60
  %65 = icmp eq i32 %56, 0
  br i1 %65, label %69, label %66

66:                                               ; preds = %64
  %67 = load ptr, ptr %35, align 8, !tbaa !24
  %68 = icmp eq ptr %67, null
  br i1 %68, label %71, label %69

69:                                               ; preds = %64, %66
  store i32 %48, ptr %2, align 4, !tbaa !12
  %70 = load i32, ptr %54, align 4, !tbaa !56
  store i32 %70, ptr %3, align 4, !tbaa !12
  br label %71

71:                                               ; preds = %66, %10, %28, %24, %19, %14, %52, %60, %43, %46, %33, %39, %69, %4
  %72 = phi i32 [ 6, %4 ], [ 0, %69 ], [ 6, %39 ], [ 6, %66 ], [ 5, %10 ], [ 6, %28 ], [ 6, %24 ], [ 6, %19 ], [ 6, %14 ], [ 6, %52 ], [ 6, %60 ], [ 6, %43 ], [ 6, %46 ], [ 1, %33 ]
  ret i32 %72
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 8) i32 @nms_record_get(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #4 {
  %5 = icmp eq ptr %3, null
  %6 = icmp eq ptr %0, null
  %7 = or i1 %6, %5
  br i1 %7, label %82, label %8

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !17
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %82

12:                                               ; preds = %8
  %13 = and i64 %1, 9223372036854775807
  %14 = icmp slt i64 %1, 0
  %15 = icmp ne i64 %13, 0
  %16 = and i1 %14, %15
  br i1 %16, label %17, label %82

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %13, %20
  br i1 %21, label %82, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !19
  %25 = icmp eq ptr %24, null
  br i1 %25, label %82, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %13
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !20
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %82, label %31

31:                                               ; preds = %26
  %32 = and i64 %1, 4294967295
  %33 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !23
  %36 = icmp eq i32 %35, 5
  br i1 %36, label %37, label %82

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %39 = load i32, ptr %38, align 4, !tbaa !45
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %82, label %41

41:                                               ; preds = %37
  %42 = load ptr, ptr %0, align 8, !tbaa !8
  %43 = icmp eq ptr %42, null
  br i1 %43, label %82, label %44

44:                                               ; preds = %41
  %45 = getelementptr inbounds nuw i8, ptr %33, i64 40
  %46 = load i32, ptr %45, align 8, !tbaa !33
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %48 = load i32, ptr %47, align 8, !tbaa !46
  %49 = icmp ult i32 %46, %48
  br i1 %49, label %50, label %82

50:                                               ; preds = %44
  %51 = zext i32 %46 to i64
  %52 = getelementptr inbounds nuw [8 x i8], ptr %42, i64 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 4
  %54 = load i32, ptr %53, align 4, !tbaa !47
  %55 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %56 = load i32, ptr %55, align 8, !tbaa !34
  %57 = icmp eq i32 %56, %54
  br i1 %57, label %58, label %82

58:                                               ; preds = %50
  %59 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %60 = load i32, ptr %59, align 8, !tbaa !38
  %61 = icmp eq i32 %60, %54
  br i1 %61, label %62, label %82

62:                                               ; preds = %58
  %63 = icmp eq i32 %54, 0
  br i1 %63, label %67, label %64

64:                                               ; preds = %62
  %65 = load ptr, ptr %33, align 8, !tbaa !24
  %66 = icmp eq ptr %65, null
  br i1 %66, label %82, label %67

67:                                               ; preds = %62, %64
  %68 = zext i32 %54 to i64
  %69 = icmp ult i64 %2, %68
  br i1 %69, label %70, label %82

70:                                               ; preds = %67
  %71 = load ptr, ptr %33, align 8, !tbaa !24
  %72 = getelementptr inbounds nuw [16 x i8], ptr %71, i64 %2
  %73 = load i64, ptr %72, align 8, !tbaa !16
  %74 = getelementptr inbounds nuw i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue [2 x i64] poison, i64 %73, 0
  %77 = insertvalue [2 x i64] %76, i64 %75, 1
  %78 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %77) #25
  %79 = icmp eq i32 %78, 0
  br i1 %79, label %80, label %82

80:                                               ; preds = %70
  store i64 %73, ptr %3, align 8, !tbaa !16
  %81 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i64 %75, ptr %81, align 8
  br label %82

82:                                               ; preds = %64, %8, %26, %22, %17, %12, %50, %58, %41, %44, %31, %37, %67, %80, %70, %4
  %83 = phi i32 [ 6, %4 ], [ 7, %67 ], [ %78, %70 ], [ 0, %80 ], [ 6, %37 ], [ 6, %64 ], [ 5, %8 ], [ 6, %26 ], [ 6, %22 ], [ 6, %17 ], [ 6, %12 ], [ 6, %50 ], [ 6, %58 ], [ 6, %41 ], [ 6, %44 ], [ 1, %31 ]
  ret i32 %83
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(read, inaccessiblemem: none, target_mem: none)
define internal fastcc [2 x i64] @slot_value(ptr nofree noundef readonly captures(none) %0, i32 noundef %1) unnamed_addr #7 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 28
  %4 = load i32, ptr %3, align 4, !tbaa !23
  switch i32 %4, label %41 [
    i32 4, label %5
    i32 2, label %36
  ]

5:                                                ; preds = %2
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %7 = load i32, ptr %6, align 8, !tbaa !49
  %8 = and i32 %7, -3
  %9 = icmp eq i32 %8, 1
  %10 = icmp eq i32 %7, 2
  %11 = icmp eq i32 %7, 4
  %12 = or i1 %10, %11
  %13 = zext i1 %12 to i32
  %14 = select i1 %9, i32 8, i32 %13
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %33, label %16

16:                                               ; preds = %5
  %17 = zext nneg i32 %14 to i64
  %18 = zext i32 %1 to i64
  %19 = mul nuw nsw i64 %17, %18
  %20 = load ptr, ptr %0, align 8, !tbaa !24
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 %19
  br label %22

22:                                               ; preds = %22, %16
  %23 = phi i64 [ 0, %16 ], [ %31, %22 ]
  %24 = phi i64 [ 0, %16 ], [ %30, %22 ]
  %25 = getelementptr inbounds nuw i8, ptr %21, i64 %23
  %26 = load i8, ptr %25, align 1, !tbaa !39
  %27 = zext i8 %26 to i64
  %28 = shl nuw nsw i64 %23, 3
  %29 = shl nuw i64 %27, %28
  %30 = or i64 %29, %24
  %31 = add nuw nsw i64 %23, 1
  %32 = icmp eq i64 %31, %17
  br i1 %32, label %33, label %22, !llvm.loop !50

33:                                               ; preds = %22, %5
  %34 = phi i64 [ 0, %5 ], [ %30, %22 ]
  %35 = zext i32 %7 to i64
  br label %48

36:                                               ; preds = %2
  %37 = load ptr, ptr %0, align 8, !tbaa !24
  %38 = zext i32 %1 to i64
  %39 = getelementptr inbounds nuw [8 x i8], ptr %37, i64 %38
  %40 = load i64, ptr %39, align 8, !tbaa !16
  br label %48

41:                                               ; preds = %2
  %42 = load ptr, ptr %0, align 8, !tbaa !24
  %43 = zext i32 %1 to i64
  %44 = getelementptr inbounds nuw [16 x i8], ptr %42, i64 %43
  %45 = load i64, ptr %44, align 8, !tbaa !16
  %46 = getelementptr inbounds nuw i8, ptr %44, i64 8
  %47 = load i64, ptr %46, align 8
  br label %48

48:                                               ; preds = %41, %36, %33
  %49 = phi i64 [ %34, %33 ], [ %40, %36 ], [ %45, %41 ]
  %50 = phi i64 [ %35, %33 ], [ 5, %36 ], [ %47, %41 ]
  %51 = insertvalue [2 x i64] poison, i64 %49, 0
  %52 = insertvalue [2 x i64] %51, i64 %50, 1
  ret [2 x i64] %52
}

; Function Attrs: nounwind ssp
define range(i32 0, 8) i32 @nms_record_set(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3) local_unnamed_addr #3 {
  %5 = extractvalue [2 x i64] %3, 0
  %6 = extractvalue [2 x i64] %3, 1
  %7 = icmp eq ptr %0, null
  br i1 %7, label %87, label %8

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !17
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %87

12:                                               ; preds = %8
  %13 = and i64 %1, 9223372036854775807
  %14 = icmp slt i64 %1, 0
  %15 = icmp ne i64 %13, 0
  %16 = and i1 %14, %15
  br i1 %16, label %17, label %87

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %13, %20
  br i1 %21, label %87, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !19
  %25 = icmp eq ptr %24, null
  br i1 %25, label %87, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %13
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !20
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %87, label %31

31:                                               ; preds = %26
  %32 = and i64 %1, 4294967295
  %33 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !23
  %36 = icmp eq i32 %35, 5
  br i1 %36, label %37, label %87

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %39 = load i32, ptr %38, align 4, !tbaa !45
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %87, label %41

41:                                               ; preds = %37
  %42 = load ptr, ptr %0, align 8, !tbaa !8
  %43 = icmp eq ptr %42, null
  br i1 %43, label %87, label %44

44:                                               ; preds = %41
  %45 = getelementptr inbounds nuw i8, ptr %33, i64 40
  %46 = load i32, ptr %45, align 8, !tbaa !33
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %48 = load i32, ptr %47, align 8, !tbaa !46
  %49 = icmp ult i32 %46, %48
  br i1 %49, label %50, label %87

50:                                               ; preds = %44
  %51 = zext i32 %46 to i64
  %52 = getelementptr inbounds nuw [8 x i8], ptr %42, i64 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 4
  %54 = load i32, ptr %53, align 4, !tbaa !47
  %55 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %56 = load i32, ptr %55, align 8, !tbaa !34
  %57 = icmp eq i32 %56, %54
  br i1 %57, label %58, label %87

58:                                               ; preds = %50
  %59 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %60 = load i32, ptr %59, align 8, !tbaa !38
  %61 = icmp eq i32 %60, %54
  br i1 %61, label %62, label %87

62:                                               ; preds = %58
  %63 = icmp eq i32 %54, 0
  br i1 %63, label %67, label %64

64:                                               ; preds = %62
  %65 = load ptr, ptr %33, align 8, !tbaa !24
  %66 = icmp eq ptr %65, null
  br i1 %66, label %87, label %67

67:                                               ; preds = %62, %64
  %68 = zext i32 %54 to i64
  %69 = icmp ult i64 %2, %68
  br i1 %69, label %70, label %87

70:                                               ; preds = %67
  %71 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %3) #25
  %72 = icmp eq i32 %71, 0
  br i1 %72, label %73, label %87

73:                                               ; preds = %70
  %74 = load ptr, ptr %33, align 8, !tbaa !24
  %75 = getelementptr inbounds nuw [16 x i8], ptr %74, i64 %2
  %76 = load i64, ptr %75, align 8, !tbaa !16
  %77 = getelementptr inbounds nuw i8, ptr %75, i64 8
  %78 = load i64, ptr %77, align 8
  store i64 %5, ptr %75, align 8, !tbaa !16
  store i64 %6, ptr %77, align 8
  %79 = insertvalue [2 x i64] poison, i64 %76, 0
  %80 = insertvalue [2 x i64] %79, i64 %78, 1
  %81 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %80) #25
  %82 = icmp eq i32 %81, 0
  br i1 %82, label %83, label %87

83:                                               ; preds = %73
  %84 = trunc i64 %78 to i32
  switch i32 %84, label %87 [
    i32 8, label %85
    i32 7, label %85
    i32 5, label %85
  ]

85:                                               ; preds = %83, %83, %83
  %86 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %76) #25
  br label %87

87:                                               ; preds = %64, %4, %8, %26, %22, %17, %12, %50, %58, %41, %44, %31, %37, %85, %83, %73, %67, %70
  %88 = phi i32 [ 0, %83 ], [ %71, %70 ], [ 7, %67 ], [ %81, %73 ], [ %86, %85 ], [ 6, %37 ], [ 6, %4 ], [ 5, %8 ], [ 6, %26 ], [ 6, %22 ], [ 6, %17 ], [ 6, %12 ], [ 6, %50 ], [ 6, %58 ], [ 6, %41 ], [ 6, %44 ], [ 1, %31 ], [ 6, %64 ]
  ret i32 %88
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_value_array_create(ptr nofree noundef captures(address_is_null) %0, ptr nofree noundef writeonly captures(address_is_null) %1) local_unnamed_addr #3 {
  %3 = icmp ne ptr %0, null
  %4 = icmp ne ptr %1, null
  %5 = and i1 %3, %4
  br i1 %5, label %6, label %12

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %8 = load i32, ptr %7, align 8, !tbaa !17
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 3, i64 noundef 0, ptr noundef %1) #25
  br label %12

12:                                               ; preds = %6, %2, %10
  %13 = phi i32 [ 6, %2 ], [ %11, %10 ], [ 5, %6 ]
  ret i32 %13
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_value_array_append(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, [2 x i64] %2) local_unnamed_addr #3 {
  %4 = tail call fastcc i32 @value_array_write(ptr noundef %0, i64 noundef %1, i64 noundef 0, [2 x i64] %2, i32 noundef 1) #25
  ret i32 %4
}

; Function Attrs: nounwind ssp
define internal fastcc range(i32 0, 7) i32 @value_array_write(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3, i32 noundef range(i32 0, 2) %4) unnamed_addr #3 {
  %6 = alloca double, align 8
  %7 = alloca i8, align 8
  %8 = alloca i8, align 1
  %9 = alloca i8, align 2
  %10 = alloca i8, align 1
  %11 = alloca i8, align 4
  %12 = alloca i8, align 1
  %13 = alloca i8, align 2
  %14 = alloca i8, align 1
  %15 = extractvalue [2 x i64] %3, 0
  %16 = extractvalue [2 x i64] %3, 1
  %17 = icmp sgt i64 %1, -1
  %18 = icmp eq ptr %0, null
  br i1 %17, label %19, label %41

19:                                               ; preds = %5
  br i1 %18, label %502, label %20

20:                                               ; preds = %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %22 = load i32, ptr %21, align 8, !tbaa !17
  %23 = icmp eq i32 %22, 0
  br i1 %23, label %24, label %502

24:                                               ; preds = %20
  %25 = icmp eq i64 %1, 0
  br i1 %25, label %502, label %26

26:                                               ; preds = %24
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %28 = load i32, ptr %27, align 8, !tbaa !14
  %29 = zext i32 %28 to i64
  %30 = icmp samesign ugt i64 %1, %29
  br i1 %30, label %502, label %31

31:                                               ; preds = %26
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %33 = load ptr, ptr %32, align 8, !tbaa !13
  %34 = icmp eq ptr %33, null
  br i1 %34, label %502, label %35

35:                                               ; preds = %31
  %36 = getelementptr [16 x i8], ptr %33, i64 %1
  %37 = getelementptr i8, ptr %36, i64 -16
  %38 = load ptr, ptr %37, align 8, !tbaa !25
  %39 = icmp eq ptr %38, null
  %40 = select i1 %39, i32 6, i32 1
  br label %502

41:                                               ; preds = %5
  br i1 %18, label %502, label %42

42:                                               ; preds = %41
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %44 = load i32, ptr %43, align 8, !tbaa !17
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %46, label %502

46:                                               ; preds = %42
  %47 = and i64 %1, 9223372036854775807
  %48 = icmp eq i64 %47, 0
  br i1 %48, label %502, label %49

49:                                               ; preds = %46
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %51 = load i32, ptr %50, align 4, !tbaa !18
  %52 = zext i32 %51 to i64
  %53 = icmp samesign ugt i64 %47, %52
  br i1 %53, label %502, label %54

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %56 = load ptr, ptr %55, align 8, !tbaa !19
  %57 = icmp eq ptr %56, null
  br i1 %57, label %502, label %58

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw [48 x i8], ptr %56, i64 %47
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 8
  %61 = load i64, ptr %60, align 8, !tbaa !20
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %502, label %63

63:                                               ; preds = %58
  %64 = and i64 %1, 4294967295
  %65 = getelementptr inbounds nuw [48 x i8], ptr %56, i64 %64
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 28
  %67 = load i32, ptr %66, align 4, !tbaa !23
  %68 = add i32 %67, -2
  %69 = icmp ult i32 %68, 3
  br i1 %69, label %70, label %502

70:                                               ; preds = %63
  %71 = icmp eq i32 %67, 4
  br i1 %71, label %72, label %350

72:                                               ; preds = %70
  call void @llvm.lifetime.start.p0(ptr nonnull %7)
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  call void @llvm.lifetime.start.p0(ptr nonnull %9)
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  call void @llvm.lifetime.start.p0(ptr nonnull %11)
  call void @llvm.lifetime.start.p0(ptr nonnull %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %13)
  call void @llvm.lifetime.start.p0(ptr nonnull %14)
  %73 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %74 = load i32, ptr %73, align 8, !tbaa !49
  %75 = trunc i64 %16 to i32
  %76 = icmp eq i32 %75, 2
  %77 = icmp ugt i64 %15, 255
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %348, label %79

79:                                               ; preds = %72
  %80 = icmp eq i32 %75, 4
  %81 = icmp ugt i64 %15, 1
  %82 = select i1 %80, i1 %81, i1 false
  br i1 %82, label %348, label %83

83:                                               ; preds = %79
  %84 = icmp eq i32 %74, %75
  %85 = add i32 %74, -1
  %86 = icmp ult i32 %85, 4
  %87 = and i1 %84, %86
  br i1 %87, label %88, label %103

88:                                               ; preds = %83
  %89 = trunc i64 %15 to i8
  %90 = lshr i64 %15, 8
  %91 = trunc i64 %90 to i8
  %92 = lshr i64 %15, 16
  %93 = trunc i64 %92 to i8
  %94 = lshr i64 %15, 24
  %95 = trunc i64 %94 to i8
  %96 = lshr i64 %15, 32
  %97 = trunc i64 %96 to i8
  %98 = lshr i64 %15, 40
  %99 = trunc i64 %98 to i8
  %100 = lshr i64 %15, 48
  %101 = trunc i64 %100 to i8
  %102 = lshr i64 %15, 56
  br label %148

103:                                              ; preds = %83
  %104 = icmp eq i32 %74, 1
  %105 = and i1 %76, %104
  br i1 %105, label %106, label %121

106:                                              ; preds = %103
  %107 = trunc i64 %15 to i8
  %108 = lshr i64 %15, 8
  %109 = trunc i64 %108 to i8
  %110 = lshr i64 %15, 16
  %111 = trunc i64 %110 to i8
  %112 = lshr i64 %15, 24
  %113 = trunc i64 %112 to i8
  %114 = lshr i64 %15, 32
  %115 = trunc i64 %114 to i8
  %116 = lshr i64 %15, 40
  %117 = trunc i64 %116 to i8
  %118 = lshr i64 %15, 48
  %119 = trunc i64 %118 to i8
  %120 = lshr i64 %15, 56
  br label %148

121:                                              ; preds = %103
  %122 = icmp eq i32 %74, 2
  %123 = icmp eq i32 %75, 1
  %124 = and i1 %123, %122
  br i1 %124, label %125, label %127

125:                                              ; preds = %121
  %126 = trunc i64 %15 to i8
  br label %148

127:                                              ; preds = %121
  %128 = icmp eq i32 %74, 3
  %129 = and i1 %123, %128
  br i1 %129, label %130, label %348

130:                                              ; preds = %127
  call void @llvm.lifetime.start.p0(ptr nonnull %6)
  %131 = sitofp i64 %15 to double
  store double %131, ptr %6, align 8, !tbaa !63
  %132 = load volatile i8, ptr %6, align 8, !tbaa !39
  store volatile i8 %132, ptr %7, align 8, !tbaa !39
  %133 = getelementptr inbounds nuw i8, ptr %6, i64 1
  %134 = load volatile i8, ptr %133, align 1, !tbaa !39
  store volatile i8 %134, ptr %8, align 1, !tbaa !39
  %135 = getelementptr inbounds nuw i8, ptr %6, i64 2
  %136 = load volatile i8, ptr %135, align 2, !tbaa !39
  store volatile i8 %136, ptr %9, align 2, !tbaa !39
  %137 = getelementptr inbounds nuw i8, ptr %6, i64 3
  %138 = load volatile i8, ptr %137, align 1, !tbaa !39
  store volatile i8 %138, ptr %10, align 1, !tbaa !39
  %139 = getelementptr inbounds nuw i8, ptr %6, i64 4
  %140 = load volatile i8, ptr %139, align 4, !tbaa !39
  store volatile i8 %140, ptr %11, align 4, !tbaa !39
  %141 = getelementptr inbounds nuw i8, ptr %6, i64 5
  %142 = load volatile i8, ptr %141, align 1, !tbaa !39
  store volatile i8 %142, ptr %12, align 1, !tbaa !39
  %143 = getelementptr inbounds nuw i8, ptr %6, i64 6
  %144 = load volatile i8, ptr %143, align 2, !tbaa !39
  store volatile i8 %144, ptr %13, align 2, !tbaa !39
  %145 = getelementptr inbounds nuw i8, ptr %6, i64 7
  %146 = load volatile i8, ptr %145, align 1, !tbaa !39
  store volatile i8 %146, ptr %14, align 1, !tbaa !39
  call void @llvm.lifetime.end.p0(ptr nonnull %6)
  %147 = zext i8 %146 to i64
  br label %148

148:                                              ; preds = %130, %125, %106, %88
  %149 = phi i64 [ %102, %88 ], [ %120, %106 ], [ 0, %125 ], [ %147, %130 ]
  %150 = phi i8 [ %101, %88 ], [ %119, %106 ], [ 0, %125 ], [ %144, %130 ]
  %151 = phi i8 [ %99, %88 ], [ %117, %106 ], [ 0, %125 ], [ %142, %130 ]
  %152 = phi i8 [ %97, %88 ], [ %115, %106 ], [ 0, %125 ], [ %140, %130 ]
  %153 = phi i8 [ %95, %88 ], [ %113, %106 ], [ 0, %125 ], [ %138, %130 ]
  %154 = phi i8 [ %93, %88 ], [ %111, %106 ], [ 0, %125 ], [ %136, %130 ]
  %155 = phi i8 [ %91, %88 ], [ %109, %106 ], [ 0, %125 ], [ %134, %130 ]
  %156 = phi i8 [ %89, %88 ], [ %107, %106 ], [ %126, %125 ], [ %132, %130 ]
  %157 = icmp eq i32 %4, 0
  %158 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %159 = load i32, ptr %158, align 8, !tbaa !34
  br i1 %157, label %160, label %163

160:                                              ; preds = %148
  %161 = zext i32 %159 to i64
  %162 = icmp ult i64 %2, %161
  br i1 %162, label %165, label %348

163:                                              ; preds = %148
  %164 = icmp eq i32 %159, -1
  br i1 %164, label %348, label %165

165:                                              ; preds = %163, %160
  %166 = and i32 %74, -3
  %167 = icmp eq i32 %166, 1
  %168 = icmp eq i32 %74, 2
  %169 = icmp eq i32 %74, 4
  %170 = or i1 %168, %169
  %171 = zext i1 %170 to i32
  %172 = select i1 %167, i32 8, i32 %171
  %173 = icmp eq i32 %172, 0
  br i1 %173, label %348, label %174

174:                                              ; preds = %165
  br i1 %157, label %313, label %175

175:                                              ; preds = %174
  %176 = getelementptr inbounds nuw i8, ptr %65, i64 24
  %177 = load i32, ptr %176, align 8, !tbaa !38
  %178 = icmp eq i32 %159, %177
  br i1 %178, label %181, label %179

179:                                              ; preds = %175
  %180 = zext i32 %159 to i64
  br label %266

181:                                              ; preds = %175
  %182 = getelementptr inbounds nuw i8, ptr %65, i64 36
  %183 = load i32, ptr %182, align 4, !tbaa !53
  %184 = icmp eq i32 %159, 0
  %185 = zext i32 %159 to i64
  %186 = shl nuw nsw i64 %185, 1
  %187 = select i1 %184, i64 4, i64 %186
  %188 = icmp eq i32 %183, 0
  br i1 %188, label %196, label %189

189:                                              ; preds = %181
  %190 = icmp samesign ugt i64 %187, %185
  br i1 %190, label %191, label %348

191:                                              ; preds = %189
  %192 = tail call range(i32 0, 33) i32 @llvm.cttz.i32(i32 %172, i1 true)
  %193 = lshr i32 -1, %192
  %194 = zext i32 %193 to i64
  %195 = icmp samesign ugt i64 %187, %194
  br i1 %195, label %348, label %198

196:                                              ; preds = %181
  %197 = tail call i64 @llvm.umin.i64(i64 %187, i64 4294967295)
  br label %198

198:                                              ; preds = %196, %191
  %199 = phi i64 [ %187, %191 ], [ %197, %196 ]
  %200 = trunc nuw i64 %199 to i32
  %201 = zext nneg i32 %172 to i64
  %202 = sub i32 %200, %159
  %203 = zext i32 %202 to i64
  %204 = mul nuw nsw i64 %203, %201
  %205 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %206 = load i64, ptr %205, align 8, !tbaa !31
  %207 = xor i64 %206, -1
  %208 = icmp ugt i64 %204, %207
  br i1 %208, label %348, label %209

209:                                              ; preds = %198
  %210 = mul nuw nsw i64 %199, %201
  %211 = tail call ptr @malloc(i64 noundef %210) #24
  %212 = icmp eq ptr %211, null
  br i1 %212, label %348, label %213

213:                                              ; preds = %209
  %214 = load ptr, ptr %65, align 8, !tbaa !24
  %215 = load i32, ptr %158, align 8, !tbaa !34
  %216 = icmp eq i32 %215, 0
  br i1 %216, label %260, label %217

217:                                              ; preds = %213
  %218 = zext i32 %215 to i64
  %219 = mul nuw nsw i64 %218, %201
  %220 = freeze i64 %219
  %221 = add i64 %220, -1
  %222 = urem i64 %221, 3
  %223 = add nuw nsw i64 %222, 1
  %224 = icmp ne i64 %223, 3
  %225 = select i1 %224, i64 %223, i64 0
  %226 = icmp ult i64 %221, 2
  br i1 %226, label %247, label %227

227:                                              ; preds = %217
  %228 = sub i64 %220, %225
  br label %229

229:                                              ; preds = %229, %227
  %230 = phi i64 [ 0, %227 ], [ %243, %229 ]
  %231 = phi i64 [ 0, %227 ], [ %244, %229 ]
  %232 = getelementptr inbounds nuw i8, ptr %214, i64 %230
  %233 = load volatile i8, ptr %232, align 1, !tbaa !39
  %234 = getelementptr inbounds nuw i8, ptr %211, i64 %230
  store volatile i8 %233, ptr %234, align 1, !tbaa !39
  %235 = add nuw nsw i64 %230, 1
  %236 = getelementptr inbounds nuw i8, ptr %214, i64 %235
  %237 = load volatile i8, ptr %236, align 1, !tbaa !39
  %238 = getelementptr inbounds nuw i8, ptr %211, i64 %235
  store volatile i8 %237, ptr %238, align 1, !tbaa !39
  %239 = add nuw nsw i64 %230, 2
  %240 = getelementptr inbounds nuw i8, ptr %214, i64 %239
  %241 = load volatile i8, ptr %240, align 1, !tbaa !39
  %242 = getelementptr inbounds nuw i8, ptr %211, i64 %239
  store volatile i8 %241, ptr %242, align 1, !tbaa !39
  %243 = add nuw nsw i64 %230, 3
  %244 = add i64 %231, 3
  %245 = icmp eq i64 %244, %228
  br i1 %245, label %246, label %229, !llvm.loop !40

246:                                              ; preds = %229
  br i1 %224, label %247, label %258

247:                                              ; preds = %246, %217
  %248 = phi i64 [ 0, %217 ], [ %243, %246 ]
  tail call void @llvm.assume(i1 %224)
  br label %249

249:                                              ; preds = %249, %247
  %250 = phi i64 [ %255, %249 ], [ %248, %247 ]
  %251 = phi i64 [ %256, %249 ], [ 0, %247 ]
  %252 = getelementptr inbounds nuw i8, ptr %214, i64 %250
  %253 = load volatile i8, ptr %252, align 1, !tbaa !39
  %254 = getelementptr inbounds nuw i8, ptr %211, i64 %250
  store volatile i8 %253, ptr %254, align 1, !tbaa !39
  %255 = add nuw nsw i64 %250, 1
  %256 = add i64 %251, 1
  %257 = icmp eq i64 %256, %225
  br i1 %257, label %258, label %249, !llvm.loop !65

258:                                              ; preds = %249, %246
  %259 = load ptr, ptr %65, align 8, !tbaa !24
  br label %260

260:                                              ; preds = %258, %213
  %261 = phi ptr [ %259, %258 ], [ %214, %213 ]
  store ptr %211, ptr %65, align 8, !tbaa !24
  store i32 %200, ptr %176, align 8, !tbaa !38
  %262 = load i64, ptr %205, align 8, !tbaa !31
  %263 = add i64 %262, %204
  store i64 %263, ptr %205, align 8, !tbaa !31
  %264 = icmp eq ptr %261, null
  br i1 %264, label %266, label %265

265:                                              ; preds = %260
  tail call void @free(ptr noundef nonnull %261) #26
  br label %266

266:                                              ; preds = %265, %260, %179
  %267 = phi i64 [ %180, %179 ], [ %185, %260 ], [ %185, %265 ]
  %268 = shl nuw i64 %149, 56
  %269 = zext i8 %150 to i64
  %270 = shl nuw nsw i64 %269, 48
  %271 = zext i8 %151 to i64
  %272 = shl nuw nsw i64 %271, 40
  %273 = zext i8 %152 to i64
  %274 = shl nuw nsw i64 %273, 32
  %275 = zext i8 %153 to i64
  %276 = shl nuw nsw i64 %275, 24
  %277 = zext i8 %154 to i64
  %278 = shl nuw nsw i64 %277, 16
  %279 = zext i8 %155 to i64
  %280 = shl nuw nsw i64 %279, 8
  %281 = zext i8 %156 to i64
  %282 = or disjoint i64 %280, %281
  %283 = or disjoint i64 %282, %278
  %284 = or disjoint i64 %283, %276
  %285 = or disjoint i64 %284, %274
  %286 = or disjoint i64 %285, %272
  %287 = or disjoint i64 %270, %268
  %288 = or i64 %287, %286
  %289 = load i32, ptr %73, align 8, !tbaa !49
  %290 = and i32 %289, -3
  %291 = icmp eq i32 %290, 1
  %292 = icmp eq i32 %289, 2
  %293 = icmp eq i32 %289, 4
  %294 = or i1 %292, %293
  %295 = zext i1 %294 to i32
  %296 = select i1 %291, i32 8, i32 %295
  %297 = zext nneg i32 %296 to i64
  %298 = mul nuw nsw i64 %267, %297
  %299 = icmp eq i32 %296, 0
  br i1 %299, label %310, label %300

300:                                              ; preds = %266, %300
  %301 = phi i64 [ %308, %300 ], [ 0, %266 ]
  %302 = shl nuw nsw i64 %301, 3
  %303 = lshr i64 %288, %302
  %304 = trunc i64 %303 to i8
  %305 = load ptr, ptr %65, align 8, !tbaa !24
  %306 = getelementptr inbounds nuw i8, ptr %305, i64 %298
  %307 = getelementptr inbounds nuw i8, ptr %306, i64 %301
  store i8 %304, ptr %307, align 1, !tbaa !39
  %308 = add nuw nsw i64 %301, 1
  %309 = icmp eq i64 %308, %297
  br i1 %309, label %310, label %300, !llvm.loop !66

310:                                              ; preds = %300, %266
  %311 = load i32, ptr %158, align 8, !tbaa !34
  %312 = add i32 %311, 1
  store i32 %312, ptr %158, align 8, !tbaa !34
  br label %348

313:                                              ; preds = %174
  %314 = shl nuw i64 %149, 56
  %315 = zext i8 %150 to i64
  %316 = shl nuw nsw i64 %315, 48
  %317 = zext i8 %151 to i64
  %318 = shl nuw nsw i64 %317, 40
  %319 = zext i8 %152 to i64
  %320 = shl nuw nsw i64 %319, 32
  %321 = zext i8 %153 to i64
  %322 = shl nuw nsw i64 %321, 24
  %323 = zext i8 %154 to i64
  %324 = shl nuw nsw i64 %323, 16
  %325 = zext i8 %155 to i64
  %326 = shl nuw nsw i64 %325, 8
  %327 = zext i8 %156 to i64
  %328 = or disjoint i64 %326, %327
  %329 = or disjoint i64 %328, %324
  %330 = or disjoint i64 %329, %322
  %331 = or disjoint i64 %330, %320
  %332 = or disjoint i64 %331, %318
  %333 = or disjoint i64 %316, %314
  %334 = or i64 %333, %332
  %335 = and i64 %2, 4294967295
  %336 = zext nneg i32 %172 to i64
  %337 = mul nuw nsw i64 %335, %336
  br label %338

338:                                              ; preds = %338, %313
  %339 = phi i64 [ %346, %338 ], [ 0, %313 ]
  %340 = shl nuw nsw i64 %339, 3
  %341 = lshr i64 %334, %340
  %342 = trunc i64 %341 to i8
  %343 = load ptr, ptr %65, align 8, !tbaa !24
  %344 = getelementptr inbounds nuw i8, ptr %343, i64 %337
  %345 = getelementptr inbounds nuw i8, ptr %344, i64 %339
  store i8 %342, ptr %345, align 1, !tbaa !39
  %346 = add nuw nsw i64 %339, 1
  %347 = icmp eq i64 %346, %336
  br i1 %347, label %348, label %338, !llvm.loop !66

348:                                              ; preds = %338, %72, %79, %127, %160, %163, %165, %189, %191, %198, %209, %310
  %349 = phi i32 [ 1, %127 ], [ 6, %160 ], [ 3, %163 ], [ 6, %165 ], [ 3, %189 ], [ 1, %79 ], [ 0, %310 ], [ 1, %72 ], [ 3, %198 ], [ 3, %209 ], [ 3, %191 ], [ 0, %338 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7)
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  br label %502

350:                                              ; preds = %70
  %351 = tail call fastcc i32 @value_valid(ptr noundef nonnull %0, [2 x i64] %3) #25
  %352 = icmp eq i32 %351, 0
  br i1 %352, label %353, label %502

353:                                              ; preds = %350
  %354 = icmp eq i32 %4, 0
  %355 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %356 = load i32, ptr %355, align 8, !tbaa !34
  br i1 %354, label %357, label %360

357:                                              ; preds = %353
  %358 = zext i32 %356 to i64
  %359 = icmp ult i64 %2, %358
  br i1 %359, label %362, label %502

360:                                              ; preds = %353
  %361 = icmp eq i32 %356, -1
  br i1 %361, label %502, label %366

362:                                              ; preds = %357
  %363 = trunc nuw i64 %2 to i32
  %364 = getelementptr inbounds nuw i8, ptr %65, i64 24
  %365 = load i32, ptr %364, align 8, !tbaa !38
  br label %387

366:                                              ; preds = %360
  %367 = getelementptr inbounds nuw i8, ptr %65, i64 24
  %368 = load i32, ptr %367, align 8, !tbaa !38
  %369 = icmp eq i32 %356, %368
  br i1 %369, label %370, label %387

370:                                              ; preds = %366
  %371 = getelementptr inbounds nuw i8, ptr %65, i64 36
  %372 = load i32, ptr %371, align 4, !tbaa !53
  %373 = icmp eq i32 %356, 0
  %374 = zext i32 %356 to i64
  %375 = shl nuw nsw i64 %374, 1
  %376 = select i1 %373, i64 4, i64 %375
  %377 = icmp eq i32 %372, 0
  br i1 %377, label %382, label %378

378:                                              ; preds = %370
  %379 = icmp samesign ule i64 %376, %374
  %380 = icmp samesign ugt i64 %376, 268435455
  %381 = select i1 %379, i1 true, i1 %380
  br i1 %381, label %502, label %384

382:                                              ; preds = %370
  %383 = tail call i64 @llvm.umin.i64(i64 %376, i64 4294967295)
  br label %384

384:                                              ; preds = %378, %382
  %385 = phi i64 [ %376, %378 ], [ %383, %382 ]
  %386 = trunc nuw i64 %385 to i32
  br label %387

387:                                              ; preds = %384, %362, %366
  %388 = phi i32 [ %365, %362 ], [ %356, %384 ], [ %368, %366 ]
  %389 = phi ptr [ %364, %362 ], [ %367, %384 ], [ %367, %366 ]
  %390 = phi i32 [ %363, %362 ], [ %356, %384 ], [ %356, %366 ]
  %391 = phi i32 [ %365, %362 ], [ %386, %384 ], [ %368, %366 ]
  %392 = zext i32 %391 to i64
  %393 = shl nuw nsw i64 %392, 4
  %394 = icmp eq i32 %67, 2
  %395 = zext i32 %388 to i64
  %396 = select i1 %394, i64 3, i64 4
  %397 = shl nuw nsw i64 %395, %396
  %398 = sub nsw i64 %393, %397
  %399 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %400 = load i64, ptr %399, align 8, !tbaa !31
  %401 = xor i64 %400, -1
  %402 = icmp ugt i64 %398, %401
  br i1 %402, label %502, label %403

403:                                              ; preds = %387
  %404 = load ptr, ptr %65, align 8, !tbaa !24
  %405 = icmp ne i32 %67, 2
  %406 = icmp eq i32 %391, %388
  %407 = and i1 %405, %406
  br i1 %407, label %468, label %408

408:                                              ; preds = %403
  %409 = tail call ptr @malloc(i64 noundef %393) #24
  %410 = icmp eq ptr %409, null
  br i1 %410, label %502, label %411

411:                                              ; preds = %408
  %412 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %413 = load i32, ptr %412, align 8, !tbaa !34
  %414 = icmp eq i32 %413, 0
  br i1 %414, label %468, label %415

415:                                              ; preds = %411
  %416 = getelementptr inbounds nuw i8, ptr %65, i64 32
  br label %417

417:                                              ; preds = %415, %460
  %418 = phi i64 [ 0, %415 ], [ %464, %460 ]
  %419 = getelementptr inbounds nuw [16 x i8], ptr %409, i64 %418
  %420 = load i32, ptr %66, align 4, !tbaa !23
  switch i32 %420, label %454 [
    i32 4, label %421
    i32 2, label %450
  ]

421:                                              ; preds = %417
  %422 = load i32, ptr %416, align 8, !tbaa !49
  %423 = and i32 %422, -3
  %424 = icmp eq i32 %423, 1
  %425 = icmp eq i32 %422, 2
  %426 = icmp eq i32 %422, 4
  %427 = or i1 %425, %426
  %428 = zext i1 %427 to i32
  %429 = select i1 %424, i32 8, i32 %428
  %430 = icmp eq i32 %429, 0
  br i1 %430, label %447, label %431

431:                                              ; preds = %421
  %432 = zext nneg i32 %429 to i64
  %433 = mul nuw nsw i64 %418, %432
  %434 = load ptr, ptr %65, align 8, !tbaa !24
  %435 = getelementptr inbounds nuw i8, ptr %434, i64 %433
  br label %436

436:                                              ; preds = %436, %431
  %437 = phi i64 [ 0, %431 ], [ %445, %436 ]
  %438 = phi i64 [ 0, %431 ], [ %444, %436 ]
  %439 = getelementptr inbounds nuw i8, ptr %435, i64 %437
  %440 = load i8, ptr %439, align 1, !tbaa !39
  %441 = zext i8 %440 to i64
  %442 = shl nuw nsw i64 %437, 3
  %443 = shl nuw i64 %441, %442
  %444 = or i64 %443, %438
  %445 = add nuw nsw i64 %437, 1
  %446 = icmp eq i64 %445, %432
  br i1 %446, label %447, label %436, !llvm.loop !50

447:                                              ; preds = %436, %421
  %448 = phi i64 [ 0, %421 ], [ %444, %436 ]
  %449 = zext i32 %422 to i64
  br label %460

450:                                              ; preds = %417
  %451 = load ptr, ptr %65, align 8, !tbaa !24
  %452 = getelementptr inbounds nuw [8 x i8], ptr %451, i64 %418
  %453 = load i64, ptr %452, align 8, !tbaa !16
  br label %460

454:                                              ; preds = %417
  %455 = load ptr, ptr %65, align 8, !tbaa !24
  %456 = getelementptr inbounds nuw [16 x i8], ptr %455, i64 %418
  %457 = load i64, ptr %456, align 8, !tbaa !16
  %458 = getelementptr inbounds nuw i8, ptr %456, i64 8
  %459 = load i64, ptr %458, align 8
  br label %460

460:                                              ; preds = %447, %450, %454
  %461 = phi i64 [ %448, %447 ], [ %453, %450 ], [ %457, %454 ]
  %462 = phi i64 [ %449, %447 ], [ 5, %450 ], [ %459, %454 ]
  store i64 %461, ptr %419, align 8, !tbaa !16
  %463 = getelementptr inbounds nuw i8, ptr %419, i64 8
  store i64 %462, ptr %463, align 8
  %464 = add nuw nsw i64 %418, 1
  %465 = load i32, ptr %412, align 8, !tbaa !34
  %466 = zext i32 %465 to i64
  %467 = icmp samesign ult i64 %464, %466
  br i1 %467, label %417, label %468, !llvm.loop !67

468:                                              ; preds = %460, %411, %403
  %469 = phi ptr [ %404, %403 ], [ %409, %411 ], [ %409, %460 ]
  %470 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %3) #25
  %471 = icmp eq i32 %470, 0
  br i1 %471, label %476, label %472

472:                                              ; preds = %468
  %473 = icmp eq ptr %469, null
  %474 = select i1 %407, i1 true, i1 %473
  br i1 %474, label %502, label %475

475:                                              ; preds = %472
  tail call void @free(ptr noundef nonnull %469) #26
  br label %502

476:                                              ; preds = %468
  br i1 %354, label %477, label %481

477:                                              ; preds = %476
  %478 = tail call fastcc [2 x i64] @slot_value(ptr noundef nonnull %65, i32 noundef %390) #25
  %479 = extractvalue [2 x i64] %478, 0
  %480 = extractvalue [2 x i64] %478, 1
  br label %481

481:                                              ; preds = %477, %476
  %482 = phi i64 [ 0, %476 ], [ %479, %477 ]
  %483 = phi i64 [ 0, %476 ], [ %480, %477 ]
  br i1 %407, label %490, label %484

484:                                              ; preds = %481
  %485 = load ptr, ptr %65, align 8, !tbaa !24
  store ptr %469, ptr %65, align 8, !tbaa !24
  store i32 %391, ptr %389, align 8, !tbaa !38
  store i32 3, ptr %66, align 4, !tbaa !23
  %486 = load i64, ptr %399, align 8, !tbaa !31
  %487 = add i64 %486, %398
  store i64 %487, ptr %399, align 8, !tbaa !31
  %488 = icmp eq ptr %485, null
  br i1 %488, label %490, label %489

489:                                              ; preds = %484
  tail call void @free(ptr noundef nonnull %485) #26
  br label %490

490:                                              ; preds = %489, %484, %481
  %491 = zext i32 %390 to i64
  %492 = getelementptr inbounds nuw [16 x i8], ptr %469, i64 %491
  store i64 %15, ptr %492, align 8, !tbaa !16
  %493 = getelementptr inbounds nuw i8, ptr %492, i64 8
  store i64 %16, ptr %493, align 8
  br i1 %354, label %498, label %494

494:                                              ; preds = %490
  %495 = getelementptr inbounds nuw i8, ptr %65, i64 16
  %496 = load i32, ptr %495, align 8, !tbaa !34
  %497 = add i32 %496, 1
  store i32 %497, ptr %495, align 8, !tbaa !34
  br label %502

498:                                              ; preds = %490
  %499 = insertvalue [2 x i64] poison, i64 %482, 0
  %500 = insertvalue [2 x i64] %499, i64 %483, 1
  %501 = tail call i32 @nms_value_release(ptr noundef nonnull %0, [2 x i64] %500) #25
  br label %502

502:                                              ; preds = %378, %31, %24, %20, %26, %35, %19, %42, %58, %54, %49, %46, %41, %408, %472, %498, %387, %494, %475, %348, %350, %357, %360, %63
  %503 = phi i32 [ 1, %63 ], [ %349, %348 ], [ %351, %350 ], [ 6, %357 ], [ %470, %475 ], [ 3, %360 ], [ 6, %41 ], [ 3, %387 ], [ 3, %408 ], [ %470, %472 ], [ 0, %494 ], [ %501, %498 ], [ 3, %378 ], [ 6, %31 ], [ 6, %24 ], [ 5, %20 ], [ 6, %26 ], [ %40, %35 ], [ 6, %19 ], [ 5, %42 ], [ 6, %58 ], [ 6, %54 ], [ 6, %49 ], [ 6, %46 ]
  ret i32 %503
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_value_array_set(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @value_array_write(ptr noundef %0, i64 noundef %1, i64 noundef %2, [2 x i64] %3, i32 noundef 0) #25
  ret i32 %5
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_value_array_get(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #8 {
  %5 = icmp eq ptr %3, null
  br i1 %5, label %117, label %6

6:                                                ; preds = %4
  %7 = icmp sgt i64 %1, -1
  %8 = icmp eq ptr %0, null
  br i1 %7, label %9, label %31

9:                                                ; preds = %6
  br i1 %8, label %117, label %10

10:                                               ; preds = %9
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !17
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %117

14:                                               ; preds = %10
  %15 = icmp eq i64 %1, 0
  br i1 %15, label %117, label %16

16:                                               ; preds = %14
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %18 = load i32, ptr %17, align 8, !tbaa !14
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %1, %19
  br i1 %20, label %117, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %23 = load ptr, ptr %22, align 8, !tbaa !13
  %24 = icmp eq ptr %23, null
  br i1 %24, label %117, label %25

25:                                               ; preds = %21
  %26 = getelementptr [16 x i8], ptr %23, i64 %1
  %27 = getelementptr i8, ptr %26, i64 -16
  %28 = load ptr, ptr %27, align 8, !tbaa !25
  %29 = icmp eq ptr %28, null
  %30 = select i1 %29, i32 6, i32 1
  br label %117

31:                                               ; preds = %6
  br i1 %8, label %117, label %32

32:                                               ; preds = %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %34 = load i32, ptr %33, align 8, !tbaa !17
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %36, label %117

36:                                               ; preds = %32
  %37 = and i64 %1, 9223372036854775807
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %117, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %41 = load i32, ptr %40, align 4, !tbaa !18
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %37, %42
  br i1 %43, label %117, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %46 = load ptr, ptr %45, align 8, !tbaa !19
  %47 = icmp eq ptr %46, null
  br i1 %47, label %117, label %48

48:                                               ; preds = %44
  %49 = getelementptr inbounds nuw [48 x i8], ptr %46, i64 %37
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 8
  %51 = load i64, ptr %50, align 8, !tbaa !20
  %52 = icmp eq i64 %51, 0
  br i1 %52, label %117, label %53

53:                                               ; preds = %48
  %54 = and i64 %1, 4294967295
  %55 = getelementptr inbounds nuw [48 x i8], ptr %46, i64 %54
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 28
  %57 = load i32, ptr %56, align 4, !tbaa !23
  %58 = add i32 %57, -2
  %59 = icmp ult i32 %58, 3
  br i1 %59, label %60, label %117

60:                                               ; preds = %53
  %61 = getelementptr inbounds nuw i8, ptr %55, i64 16
  %62 = load i32, ptr %61, align 8, !tbaa !34
  %63 = zext i32 %62 to i64
  %64 = icmp ult i64 %2, %63
  br i1 %64, label %67, label %65

65:                                               ; preds = %60
  store i64 0, ptr %3, align 8, !tbaa !16
  %66 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store <2 x i32> zeroinitializer, ptr %66, align 8
  br label %117

67:                                               ; preds = %60
  switch i32 %57, label %102 [
    i32 4, label %68
    i32 2, label %98
  ]

68:                                               ; preds = %67
  %69 = getelementptr inbounds nuw i8, ptr %55, i64 32
  %70 = load i32, ptr %69, align 8, !tbaa !49
  %71 = and i32 %70, -3
  %72 = icmp eq i32 %71, 1
  %73 = icmp eq i32 %70, 2
  %74 = icmp eq i32 %70, 4
  %75 = or i1 %73, %74
  %76 = zext i1 %75 to i32
  %77 = select i1 %72, i32 8, i32 %76
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %95, label %79

79:                                               ; preds = %68
  %80 = zext nneg i32 %77 to i64
  %81 = mul nuw nsw i64 %2, %80
  %82 = load ptr, ptr %55, align 8, !tbaa !24
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 %81
  br label %84

84:                                               ; preds = %84, %79
  %85 = phi i64 [ 0, %79 ], [ %93, %84 ]
  %86 = phi i64 [ 0, %79 ], [ %92, %84 ]
  %87 = getelementptr inbounds nuw i8, ptr %83, i64 %85
  %88 = load i8, ptr %87, align 1, !tbaa !39
  %89 = zext i8 %88 to i64
  %90 = shl nuw nsw i64 %85, 3
  %91 = shl nuw i64 %89, %90
  %92 = or i64 %91, %86
  %93 = add nuw nsw i64 %85, 1
  %94 = icmp eq i64 %93, %80
  br i1 %94, label %95, label %84, !llvm.loop !50

95:                                               ; preds = %84, %68
  %96 = phi i64 [ 0, %68 ], [ %92, %84 ]
  %97 = zext i32 %70 to i64
  br label %108

98:                                               ; preds = %67
  %99 = load ptr, ptr %55, align 8, !tbaa !24
  %100 = getelementptr inbounds nuw [8 x i8], ptr %99, i64 %2
  %101 = load i64, ptr %100, align 8, !tbaa !16
  br label %108

102:                                              ; preds = %67
  %103 = load ptr, ptr %55, align 8, !tbaa !24
  %104 = getelementptr inbounds nuw [16 x i8], ptr %103, i64 %2
  %105 = load i64, ptr %104, align 8, !tbaa !16
  %106 = getelementptr inbounds nuw i8, ptr %104, i64 8
  %107 = load i64, ptr %106, align 8
  br label %108

108:                                              ; preds = %95, %98, %102
  %109 = phi i64 [ %96, %95 ], [ %101, %98 ], [ %105, %102 ]
  %110 = phi i64 [ %97, %95 ], [ 5, %98 ], [ %107, %102 ]
  %111 = insertvalue [2 x i64] poison, i64 %109, 0
  %112 = insertvalue [2 x i64] %111, i64 %110, 1
  %113 = tail call i32 @nms_value_retain(ptr noundef nonnull %0, [2 x i64] %112) #25
  %114 = icmp eq i32 %113, 0
  br i1 %114, label %115, label %117

115:                                              ; preds = %108
  store i64 %109, ptr %3, align 8, !tbaa !16
  %116 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i64 %110, ptr %116, align 8
  br label %117

117:                                              ; preds = %21, %14, %10, %16, %25, %9, %32, %48, %44, %39, %36, %31, %53, %108, %115, %65, %4
  %118 = phi i32 [ 6, %4 ], [ 1, %53 ], [ 0, %65 ], [ 0, %115 ], [ %113, %108 ], [ 6, %21 ], [ 6, %14 ], [ 5, %10 ], [ 6, %16 ], [ %30, %25 ], [ 6, %9 ], [ 5, %32 ], [ 6, %48 ], [ 6, %44 ], [ 6, %39 ], [ 6, %36 ], [ 6, %31 ]
  ret i32 %118
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #9

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_value_array_pop(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #8 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %122, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %30

8:                                                ; preds = %5
  br i1 %7, label %122, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !17
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %122

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %122, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load i32, ptr %16, align 8, !tbaa !14
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %122, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %22 = load ptr, ptr %21, align 8, !tbaa !13
  %23 = icmp eq ptr %22, null
  br i1 %23, label %122, label %24

24:                                               ; preds = %20
  %25 = getelementptr [16 x i8], ptr %22, i64 %1
  %26 = getelementptr i8, ptr %25, i64 -16
  %27 = load ptr, ptr %26, align 8, !tbaa !25
  %28 = icmp eq ptr %27, null
  %29 = select i1 %28, i32 6, i32 1
  br label %122

30:                                               ; preds = %5
  br i1 %7, label %122, label %31

31:                                               ; preds = %30
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = load i32, ptr %32, align 8, !tbaa !17
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %122

35:                                               ; preds = %31
  %36 = and i64 %1, 9223372036854775807
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %122, label %38

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !18
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %36, %41
  br i1 %42, label %122, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %45 = load ptr, ptr %44, align 8, !tbaa !19
  %46 = icmp eq ptr %45, null
  br i1 %46, label %122, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw [48 x i8], ptr %45, i64 %36
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %50 = load i64, ptr %49, align 8, !tbaa !20
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %122, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 4294967295
  %54 = getelementptr inbounds nuw [48 x i8], ptr %45, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 28
  %56 = load i32, ptr %55, align 4, !tbaa !23
  %57 = add i32 %56, -2
  %58 = icmp ult i32 %57, 3
  br i1 %58, label %59, label %122

59:                                               ; preds = %52
  %60 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %61 = load i32, ptr %60, align 8, !tbaa !34
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %63, label %65

63:                                               ; preds = %59
  store i64 0, ptr %2, align 8, !tbaa !16
  %64 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store <2 x i32> zeroinitializer, ptr %64, align 8
  br label %122

65:                                               ; preds = %59
  %66 = add i32 %61, -1
  switch i32 %56, label %104 [
    i32 4, label %67
    i32 2, label %99
  ]

67:                                               ; preds = %65
  %68 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %69 = load i32, ptr %68, align 8, !tbaa !49
  %70 = and i32 %69, -3
  %71 = icmp eq i32 %70, 1
  %72 = icmp eq i32 %69, 2
  %73 = icmp eq i32 %69, 4
  %74 = or i1 %72, %73
  %75 = zext i1 %74 to i32
  %76 = select i1 %71, i32 8, i32 %75
  %77 = icmp eq i32 %76, 0
  br i1 %77, label %78, label %80

78:                                               ; preds = %67
  %79 = zext i32 %69 to i64
  store i32 %66, ptr %60, align 8, !tbaa !34
  br label %118

80:                                               ; preds = %67
  %81 = zext nneg i32 %76 to i64
  %82 = zext i32 %66 to i64
  %83 = mul nuw nsw i64 %81, %82
  %84 = load ptr, ptr %54, align 8, !tbaa !24
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 %83
  br label %86

86:                                               ; preds = %86, %80
  %87 = phi i64 [ 0, %80 ], [ %95, %86 ]
  %88 = phi i64 [ 0, %80 ], [ %94, %86 ]
  %89 = getelementptr inbounds nuw i8, ptr %85, i64 %87
  %90 = load i8, ptr %89, align 1, !tbaa !39
  %91 = zext i8 %90 to i64
  %92 = shl nuw nsw i64 %87, 3
  %93 = shl nuw i64 %91, %92
  %94 = or i64 %93, %88
  %95 = add nuw nsw i64 %87, 1
  %96 = icmp eq i64 %95, %81
  br i1 %96, label %97, label %86, !llvm.loop !50

97:                                               ; preds = %86
  %98 = zext i32 %69 to i64
  store i32 %66, ptr %60, align 8, !tbaa !34
  br label %111

99:                                               ; preds = %65
  %100 = load ptr, ptr %54, align 8, !tbaa !24
  %101 = zext i32 %66 to i64
  %102 = getelementptr inbounds nuw [8 x i8], ptr %100, i64 %101
  %103 = load i64, ptr %102, align 8, !tbaa !16
  store i32 %66, ptr %60, align 8, !tbaa !34
  store i64 0, ptr %102, align 8, !tbaa !16
  br label %118

104:                                              ; preds = %65
  %105 = load ptr, ptr %54, align 8, !tbaa !24
  %106 = zext i32 %66 to i64
  %107 = getelementptr inbounds nuw [16 x i8], ptr %105, i64 %106
  %108 = load i64, ptr %107, align 8, !tbaa !16
  %109 = getelementptr inbounds nuw i8, ptr %107, i64 8
  %110 = load i64, ptr %109, align 8
  store i32 %66, ptr %60, align 8, !tbaa !34
  store i64 0, ptr %107, align 8, !tbaa !16
  store <2 x i32> zeroinitializer, ptr %109, align 8
  br label %118

111:                                              ; preds = %97, %111
  %112 = phi i64 [ %116, %111 ], [ 0, %97 ]
  %113 = load ptr, ptr %54, align 8, !tbaa !24
  %114 = getelementptr inbounds nuw i8, ptr %113, i64 %83
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 %112
  store i8 0, ptr %115, align 1, !tbaa !39
  %116 = add nuw nsw i64 %112, 1
  %117 = icmp eq i64 %116, %81
  br i1 %117, label %118, label %111, !llvm.loop !66

118:                                              ; preds = %111, %78, %99, %104
  %119 = phi i64 [ 5, %99 ], [ %110, %104 ], [ %79, %78 ], [ %98, %111 ]
  %120 = phi i64 [ %103, %99 ], [ %108, %104 ], [ 0, %78 ], [ %94, %111 ]
  store i64 %120, ptr %2, align 8, !tbaa !16
  %121 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i64 %119, ptr %121, align 8
  br label %122

122:                                              ; preds = %20, %13, %9, %15, %24, %8, %31, %47, %43, %38, %35, %30, %52, %118, %63, %3
  %123 = phi i32 [ 6, %3 ], [ 1, %52 ], [ 0, %118 ], [ 0, %63 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %29, %24 ], [ 6, %8 ], [ 5, %31 ], [ 6, %47 ], [ 6, %43 ], [ 6, %38 ], [ 6, %35 ], [ 6, %30 ]
  ret i32 %123
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_value_array_length(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #1 {
  %4 = icmp eq ptr %2, null
  br i1 %4, label %62, label %5

5:                                                ; preds = %3
  %6 = icmp sgt i64 %1, -1
  %7 = icmp eq ptr %0, null
  br i1 %6, label %8, label %30

8:                                                ; preds = %5
  br i1 %7, label %62, label %9

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %11 = load i32, ptr %10, align 8, !tbaa !17
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %62

13:                                               ; preds = %9
  %14 = icmp eq i64 %1, 0
  br i1 %14, label %62, label %15

15:                                               ; preds = %13
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load i32, ptr %16, align 8, !tbaa !14
  %18 = zext i32 %17 to i64
  %19 = icmp samesign ugt i64 %1, %18
  br i1 %19, label %62, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %22 = load ptr, ptr %21, align 8, !tbaa !13
  %23 = icmp eq ptr %22, null
  br i1 %23, label %62, label %24

24:                                               ; preds = %20
  %25 = getelementptr [16 x i8], ptr %22, i64 %1
  %26 = getelementptr i8, ptr %25, i64 -16
  %27 = load ptr, ptr %26, align 8, !tbaa !25
  %28 = icmp eq ptr %27, null
  %29 = select i1 %28, i32 6, i32 1
  br label %62

30:                                               ; preds = %5
  br i1 %7, label %62, label %31

31:                                               ; preds = %30
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = load i32, ptr %32, align 8, !tbaa !17
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %62

35:                                               ; preds = %31
  %36 = and i64 %1, 9223372036854775807
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %62, label %38

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !18
  %41 = zext i32 %40 to i64
  %42 = icmp samesign ugt i64 %36, %41
  br i1 %42, label %62, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %45 = load ptr, ptr %44, align 8, !tbaa !19
  %46 = icmp eq ptr %45, null
  br i1 %46, label %62, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw [48 x i8], ptr %45, i64 %36
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %50 = load i64, ptr %49, align 8, !tbaa !20
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %62, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 4294967295
  %54 = getelementptr inbounds nuw [48 x i8], ptr %45, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 28
  %56 = load i32, ptr %55, align 4, !tbaa !23
  %57 = add i32 %56, -2
  %58 = icmp ult i32 %57, 3
  br i1 %58, label %59, label %62

59:                                               ; preds = %52
  %60 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %61 = load i32, ptr %60, align 8, !tbaa !34
  store i32 %61, ptr %2, align 4, !tbaa !12
  br label %62

62:                                               ; preds = %20, %13, %9, %15, %24, %8, %31, %47, %43, %38, %35, %30, %52, %59, %3
  %63 = phi i32 [ 6, %3 ], [ 1, %52 ], [ 0, %59 ], [ 6, %20 ], [ 6, %13 ], [ 5, %9 ], [ 6, %15 ], [ %29, %24 ], [ 6, %8 ], [ 5, %31 ], [ 6, %47 ], [ 6, %43 ], [ 6, %38 ], [ 6, %35 ], [ 6, %30 ]
  ret i32 %63
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_vm_array_literal(ptr nofree noundef captures(address_is_null) %0, i32 noundef %1, ptr nofree noundef readonly captures(address_is_null) %2, ptr nofree noundef readonly captures(address_is_null) %3, i32 noundef %4, ptr nofree noundef writeonly captures(address_is_null) %5) local_unnamed_addr #3 {
  %7 = alloca double, align 8
  %8 = alloca i8, align 8
  %9 = alloca i8, align 1
  %10 = alloca i8, align 2
  %11 = alloca i8, align 1
  %12 = alloca i8, align 4
  %13 = alloca i8, align 1
  %14 = alloca i8, align 2
  %15 = alloca i8, align 1
  %16 = alloca i64, align 8
  %17 = icmp eq ptr %0, null
  %18 = icmp eq ptr %5, null
  %19 = or i1 %17, %18
  %20 = icmp ugt i32 %4, 65535
  %21 = or i1 %20, %19
  br i1 %21, label %124, label %22

22:                                               ; preds = %6
  %23 = icmp eq i32 %4, 0
  br i1 %23, label %28, label %24

24:                                               ; preds = %22
  %25 = icmp ne ptr %2, null
  %26 = icmp ne ptr %3, null
  %27 = and i1 %25, %26
  br i1 %27, label %28, label %124

28:                                               ; preds = %24, %22
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %30 = load i32, ptr %29, align 8, !tbaa !17
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %32, label %124

32:                                               ; preds = %28
  switch i32 %1, label %124 [
    i32 9, label %33
    i32 7, label %33
    i32 5, label %33
    i32 4, label %33
    i32 3, label %33
    i32 2, label %33
    i32 1, label %33
    i32 0, label %33
  ]

33:                                               ; preds = %32, %32, %32, %32, %32, %32, %32, %32
  br i1 %23, label %98, label %34

34:                                               ; preds = %33
  %35 = and i32 %1, -3
  %36 = icmp ne i32 %35, 1
  %37 = icmp eq i32 %1, 2
  %38 = icmp eq i32 %1, 4
  %39 = or i1 %37, %38
  %40 = xor i1 %39, %36
  %41 = add nsw i32 %1, -1
  %42 = icmp ult i32 %41, 4
  %43 = icmp eq i32 %1, 1
  %44 = icmp eq i32 %1, 3
  %45 = zext nneg i32 %4 to i64
  %46 = getelementptr inbounds nuw i8, ptr %7, i64 1
  %47 = getelementptr inbounds nuw i8, ptr %7, i64 2
  %48 = getelementptr inbounds nuw i8, ptr %7, i64 3
  %49 = getelementptr inbounds nuw i8, ptr %7, i64 4
  %50 = getelementptr inbounds nuw i8, ptr %7, i64 5
  %51 = getelementptr inbounds nuw i8, ptr %7, i64 6
  %52 = getelementptr inbounds nuw i8, ptr %7, i64 7
  br label %53

53:                                               ; preds = %34, %95
  %54 = phi i64 [ 0, %34 ], [ %96, %95 ]
  %55 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %54
  %56 = load i64, ptr %55, align 8, !tbaa !16
  %57 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %54
  %58 = load i32, ptr %57, align 4, !tbaa !12
  call void @llvm.lifetime.start.p0(ptr nonnull %8)
  call void @llvm.lifetime.start.p0(ptr nonnull %9)
  call void @llvm.lifetime.start.p0(ptr nonnull %10)
  call void @llvm.lifetime.start.p0(ptr nonnull %11)
  call void @llvm.lifetime.start.p0(ptr nonnull %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %13)
  call void @llvm.lifetime.start.p0(ptr nonnull %14)
  call void @llvm.lifetime.start.p0(ptr nonnull %15)
  br i1 %40, label %89, label %59

59:                                               ; preds = %53
  %60 = icmp eq i32 %58, 2
  %61 = icmp ugt i64 %56, 255
  %62 = select i1 %60, i1 %61, i1 false
  br i1 %62, label %88, label %63

63:                                               ; preds = %59
  %64 = icmp eq i32 %58, 4
  %65 = icmp ugt i64 %56, 1
  %66 = select i1 %64, i1 %65, i1 false
  br i1 %66, label %88, label %67

67:                                               ; preds = %63
  %68 = icmp eq i32 %1, %58
  %69 = and i1 %42, %68
  %70 = and i1 %43, %60
  %71 = or i1 %69, %70
  br i1 %71, label %87, label %72

72:                                               ; preds = %67
  %73 = icmp eq i32 %58, 1
  %74 = and i1 %37, %73
  br i1 %74, label %87, label %75

75:                                               ; preds = %72
  %76 = and i1 %44, %73
  br i1 %76, label %77, label %88

77:                                               ; preds = %75
  call void @llvm.lifetime.start.p0(ptr nonnull %7)
  %78 = sitofp i64 %56 to double
  store double %78, ptr %7, align 8, !tbaa !63
  %79 = load volatile i8, ptr %7, align 8, !tbaa !39
  store volatile i8 %79, ptr %8, align 8, !tbaa !39
  %80 = load volatile i8, ptr %46, align 1, !tbaa !39
  store volatile i8 %80, ptr %9, align 1, !tbaa !39
  %81 = load volatile i8, ptr %47, align 2, !tbaa !39
  store volatile i8 %81, ptr %10, align 2, !tbaa !39
  %82 = load volatile i8, ptr %48, align 1, !tbaa !39
  store volatile i8 %82, ptr %11, align 1, !tbaa !39
  %83 = load volatile i8, ptr %49, align 4, !tbaa !39
  store volatile i8 %83, ptr %12, align 4, !tbaa !39
  %84 = load volatile i8, ptr %50, align 1, !tbaa !39
  store volatile i8 %84, ptr %13, align 1, !tbaa !39
  %85 = load volatile i8, ptr %51, align 2, !tbaa !39
  store volatile i8 %85, ptr %14, align 2, !tbaa !39
  %86 = load volatile i8, ptr %52, align 1, !tbaa !39
  store volatile i8 %86, ptr %15, align 1, !tbaa !39
  call void @llvm.lifetime.end.p0(ptr nonnull %7)
  br label %87

87:                                               ; preds = %72, %67, %77
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br label %95

88:                                               ; preds = %59, %63, %75
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br label %124

89:                                               ; preds = %53
  %90 = zext i32 %58 to i64
  %91 = insertvalue [2 x i64] poison, i64 %56, 0
  %92 = insertvalue [2 x i64] %91, i64 %90, 1
  %93 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %92) #25
  %94 = icmp eq i32 %93, 0
  call void @llvm.lifetime.end.p0(ptr nonnull %8)
  call void @llvm.lifetime.end.p0(ptr nonnull %9)
  call void @llvm.lifetime.end.p0(ptr nonnull %10)
  call void @llvm.lifetime.end.p0(ptr nonnull %11)
  call void @llvm.lifetime.end.p0(ptr nonnull %12)
  call void @llvm.lifetime.end.p0(ptr nonnull %13)
  call void @llvm.lifetime.end.p0(ptr nonnull %14)
  call void @llvm.lifetime.end.p0(ptr nonnull %15)
  br i1 %94, label %95, label %124

95:                                               ; preds = %87, %89
  %96 = add nuw nsw i64 %54, 1
  %97 = icmp eq i64 %96, %45
  br i1 %97, label %98, label %53, !llvm.loop !68

98:                                               ; preds = %95, %33
  call void @llvm.lifetime.start.p0(ptr nonnull %16) #27
  store i64 0, ptr %16, align 8, !tbaa !16
  %99 = call fastcc i32 @vm_array_create_capacity(ptr noundef %0, i32 noundef %1, i32 noundef %4, ptr noundef nonnull %16) #25
  %100 = icmp eq i32 %99, 0
  br i1 %100, label %101, label %122

101:                                              ; preds = %98
  %102 = load i64, ptr %16, align 8, !tbaa !16
  br i1 %23, label %121, label %103

103:                                              ; preds = %101
  %104 = zext nneg i32 %4 to i64
  br label %108

105:                                              ; preds = %108
  %106 = add nuw nsw i64 %109, 1
  %107 = icmp eq i64 %106, %104
  br i1 %107, label %121, label %108, !llvm.loop !69

108:                                              ; preds = %103, %105
  %109 = phi i64 [ 0, %103 ], [ %106, %105 ]
  %110 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %109
  %111 = load i64, ptr %110, align 8, !tbaa !16
  %112 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %109
  %113 = load i32, ptr %112, align 4, !tbaa !12
  %114 = insertvalue [2 x i64] poison, i64 %111, 0
  %115 = zext i32 %113 to i64
  %116 = insertvalue [2 x i64] %114, i64 %115, 1
  %117 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef %0, i64 noundef %102, i64 noundef 0, [2 x i64] %116, i32 noundef 1) #25
  %118 = icmp eq i32 %117, 0
  br i1 %118, label %105, label %119

119:                                              ; preds = %108
  %120 = call i32 @nms_release(ptr noundef %0, i64 noundef %102) #25
  br label %122

121:                                              ; preds = %105, %101
  store i64 %102, ptr %5, align 8, !tbaa !16
  br label %122

122:                                              ; preds = %119, %98, %121
  %123 = phi i32 [ %117, %119 ], [ 0, %121 ], [ %99, %98 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %16) #27
  br label %124

124:                                              ; preds = %89, %88, %32, %28, %6, %24, %122
  %125 = phi i32 [ 5, %28 ], [ 6, %6 ], [ %123, %122 ], [ 1, %32 ], [ 6, %24 ], [ 1, %88 ], [ %93, %89 ]
  ret i32 %125
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_vm_array_slice(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, i32 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp eq ptr %4, null
  br i1 %7, label %209, label %8

8:                                                ; preds = %5
  %9 = icmp sgt i64 %1, -1
  %10 = icmp eq ptr %0, null
  br i1 %9, label %11, label %33

11:                                               ; preds = %8
  br i1 %10, label %209, label %12

12:                                               ; preds = %11
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %14 = load i32, ptr %13, align 8, !tbaa !17
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %16, label %209

16:                                               ; preds = %12
  %17 = icmp eq i64 %1, 0
  br i1 %17, label %209, label %18

18:                                               ; preds = %16
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %20 = load i32, ptr %19, align 8, !tbaa !14
  %21 = zext i32 %20 to i64
  %22 = icmp samesign ugt i64 %1, %21
  br i1 %22, label %209, label %23

23:                                               ; preds = %18
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %25 = load ptr, ptr %24, align 8, !tbaa !13
  %26 = icmp eq ptr %25, null
  br i1 %26, label %209, label %27

27:                                               ; preds = %23
  %28 = getelementptr [16 x i8], ptr %25, i64 %1
  %29 = getelementptr i8, ptr %28, i64 -16
  %30 = load ptr, ptr %29, align 8, !tbaa !25
  %31 = icmp eq ptr %30, null
  %32 = select i1 %31, i32 6, i32 1
  br label %209

33:                                               ; preds = %8
  br i1 %10, label %209, label %34

34:                                               ; preds = %33
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %36 = load i32, ptr %35, align 8, !tbaa !17
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %38, label %209

38:                                               ; preds = %34
  %39 = and i64 %1, 9223372036854775807
  %40 = icmp eq i64 %39, 0
  br i1 %40, label %209, label %41

41:                                               ; preds = %38
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %43 = load i32, ptr %42, align 4, !tbaa !18
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %39, %44
  br i1 %45, label %209, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %48 = load ptr, ptr %47, align 8, !tbaa !19
  %49 = icmp eq ptr %48, null
  br i1 %49, label %209, label %50

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw [48 x i8], ptr %48, i64 %39
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 8
  %53 = load i64, ptr %52, align 8, !tbaa !20
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %209, label %55

55:                                               ; preds = %50
  %56 = and i64 %1, 4294967295
  %57 = getelementptr inbounds nuw [48 x i8], ptr %48, i64 %56
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 28
  %59 = load i32, ptr %58, align 4, !tbaa !23
  %60 = add i32 %59, -2
  %61 = icmp ult i32 %60, 3
  br i1 %61, label %62, label %209

62:                                               ; preds = %55
  %63 = getelementptr inbounds nuw i8, ptr %57, i64 16
  %64 = load i32, ptr %63, align 8, !tbaa !34
  %65 = icmp eq i32 %59, 2
  br i1 %65, label %69, label %66

66:                                               ; preds = %62
  %67 = getelementptr inbounds nuw i8, ptr %57, i64 32
  %68 = load i32, ptr %67, align 8, !tbaa !49
  br label %69

69:                                               ; preds = %62, %66
  %70 = phi i32 [ %68, %66 ], [ 5, %62 ]
  %71 = tail call i32 @llvm.umin.i32(i32 %2, i32 %64)
  %72 = tail call i32 @llvm.umin.i32(i32 %3, i32 %64)
  %73 = tail call i32 @llvm.usub.sat.i32(i32 %72, i32 %71)
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  %74 = call fastcc i32 @vm_array_create_capacity(ptr noundef nonnull %0, i32 noundef %70, i32 noundef %73, ptr noundef nonnull %6) #25
  %75 = icmp eq i32 %74, 0
  br i1 %75, label %76, label %207

76:                                               ; preds = %69
  %77 = load ptr, ptr %47, align 8, !tbaa !19
  %78 = getelementptr inbounds nuw [48 x i8], ptr %77, i64 %56
  %79 = load i64, ptr %6, align 8, !tbaa !16
  %80 = and i64 %79, 4294967295
  %81 = getelementptr inbounds nuw [48 x i8], ptr %77, i64 %80
  %82 = getelementptr inbounds nuw i8, ptr %78, i64 28
  %83 = load i32, ptr %82, align 4, !tbaa !23
  %84 = icmp eq i32 %83, 4
  %85 = icmp ult i32 %2, %72
  br i1 %84, label %90, label %86

86:                                               ; preds = %76
  br i1 %85, label %87, label %206

87:                                               ; preds = %86
  %88 = getelementptr inbounds nuw i8, ptr %78, i64 32
  %89 = zext i32 %73 to i64
  br label %150

90:                                               ; preds = %76
  br i1 %85, label %91, label %145

91:                                               ; preds = %90
  %92 = and i32 %70, -3
  %93 = icmp eq i32 %92, 1
  %94 = icmp eq i32 %70, 2
  %95 = icmp eq i32 %70, 4
  %96 = or i1 %94, %95
  %97 = zext i1 %96 to i64
  %98 = select i1 %93, i64 8, i64 %97
  %99 = load ptr, ptr %81, align 8, !tbaa !24
  %100 = load ptr, ptr %78, align 8, !tbaa !24
  %101 = zext i32 %71 to i64
  %102 = mul nuw nsw i64 %98, %101
  %103 = getelementptr inbounds nuw i8, ptr %100, i64 %102
  %104 = zext i32 %73 to i64
  %105 = mul nuw nsw i64 %98, %104
  %106 = icmp eq i64 %105, 0
  br i1 %106, label %145, label %107

107:                                              ; preds = %91
  %108 = add nsw i64 %105, -1
  %109 = urem i64 %108, 3
  %110 = add nuw nsw i64 %109, 1
  %111 = icmp ne i64 %110, 3
  %112 = select i1 %111, i64 %110, i64 0
  %113 = icmp samesign ult i64 %105, 3
  br i1 %113, label %134, label %114

114:                                              ; preds = %107
  %115 = sub nsw i64 %105, %112
  br label %116

116:                                              ; preds = %116, %114
  %117 = phi i64 [ 0, %114 ], [ %130, %116 ]
  %118 = phi i64 [ 0, %114 ], [ %131, %116 ]
  %119 = getelementptr inbounds nuw i8, ptr %103, i64 %117
  %120 = load volatile i8, ptr %119, align 1, !tbaa !39
  %121 = getelementptr inbounds nuw i8, ptr %99, i64 %117
  store volatile i8 %120, ptr %121, align 1, !tbaa !39
  %122 = add nuw nsw i64 %117, 1
  %123 = getelementptr inbounds nuw i8, ptr %103, i64 %122
  %124 = load volatile i8, ptr %123, align 1, !tbaa !39
  %125 = getelementptr inbounds nuw i8, ptr %99, i64 %122
  store volatile i8 %124, ptr %125, align 1, !tbaa !39
  %126 = add nuw nsw i64 %117, 2
  %127 = getelementptr inbounds nuw i8, ptr %103, i64 %126
  %128 = load volatile i8, ptr %127, align 1, !tbaa !39
  %129 = getelementptr inbounds nuw i8, ptr %99, i64 %126
  store volatile i8 %128, ptr %129, align 1, !tbaa !39
  %130 = add nuw nsw i64 %117, 3
  %131 = add i64 %118, 3
  %132 = icmp eq i64 %131, %115
  br i1 %132, label %133, label %116, !llvm.loop !40

133:                                              ; preds = %116
  br i1 %111, label %134, label %145

134:                                              ; preds = %133, %107
  %135 = phi i64 [ 0, %107 ], [ %130, %133 ]
  call void @llvm.assume(i1 %111)
  br label %136

136:                                              ; preds = %136, %134
  %137 = phi i64 [ %142, %136 ], [ %135, %134 ]
  %138 = phi i64 [ %143, %136 ], [ 0, %134 ]
  %139 = getelementptr inbounds nuw i8, ptr %103, i64 %137
  %140 = load volatile i8, ptr %139, align 1, !tbaa !39
  %141 = getelementptr inbounds nuw i8, ptr %99, i64 %137
  store volatile i8 %140, ptr %141, align 1, !tbaa !39
  %142 = add nuw nsw i64 %137, 1
  %143 = add i64 %138, 1
  %144 = icmp eq i64 %143, %112
  br i1 %144, label %145, label %136, !llvm.loop !70

145:                                              ; preds = %133, %136, %91, %90
  %146 = getelementptr inbounds nuw i8, ptr %81, i64 16
  store i32 %73, ptr %146, align 8, !tbaa !34
  br label %206

147:                                              ; preds = %197
  %148 = add nuw nsw i64 %151, 1
  %149 = icmp samesign ult i64 %148, %89
  br i1 %149, label %150, label %206, !llvm.loop !71

150:                                              ; preds = %87, %147
  %151 = phi i64 [ 0, %87 ], [ %148, %147 ]
  %152 = trunc nuw i64 %151 to i32
  %153 = add i32 %71, %152
  %154 = load i32, ptr %82, align 4, !tbaa !23
  switch i32 %154, label %190 [
    i32 4, label %155
    i32 2, label %185
  ]

155:                                              ; preds = %150
  %156 = load i32, ptr %88, align 8, !tbaa !49
  %157 = and i32 %156, -3
  %158 = icmp eq i32 %157, 1
  %159 = icmp eq i32 %156, 2
  %160 = icmp eq i32 %156, 4
  %161 = or i1 %159, %160
  %162 = zext i1 %161 to i32
  %163 = select i1 %158, i32 8, i32 %162
  %164 = icmp eq i32 %163, 0
  br i1 %164, label %182, label %165

165:                                              ; preds = %155
  %166 = zext nneg i32 %163 to i64
  %167 = zext i32 %153 to i64
  %168 = mul nuw nsw i64 %166, %167
  %169 = load ptr, ptr %78, align 8, !tbaa !24
  %170 = getelementptr inbounds nuw i8, ptr %169, i64 %168
  br label %171

171:                                              ; preds = %171, %165
  %172 = phi i64 [ 0, %165 ], [ %180, %171 ]
  %173 = phi i64 [ 0, %165 ], [ %179, %171 ]
  %174 = getelementptr inbounds nuw i8, ptr %170, i64 %172
  %175 = load i8, ptr %174, align 1, !tbaa !39
  %176 = zext i8 %175 to i64
  %177 = shl nuw nsw i64 %172, 3
  %178 = shl nuw i64 %176, %177
  %179 = or i64 %178, %173
  %180 = add nuw nsw i64 %172, 1
  %181 = icmp eq i64 %180, %166
  br i1 %181, label %182, label %171, !llvm.loop !50

182:                                              ; preds = %171, %155
  %183 = phi i64 [ 0, %155 ], [ %179, %171 ]
  %184 = zext i32 %156 to i64
  br label %197

185:                                              ; preds = %150
  %186 = load ptr, ptr %78, align 8, !tbaa !24
  %187 = zext i32 %153 to i64
  %188 = getelementptr inbounds nuw [8 x i8], ptr %186, i64 %187
  %189 = load i64, ptr %188, align 8, !tbaa !16
  br label %197

190:                                              ; preds = %150
  %191 = load ptr, ptr %78, align 8, !tbaa !24
  %192 = zext i32 %153 to i64
  %193 = getelementptr inbounds nuw [16 x i8], ptr %191, i64 %192
  %194 = load i64, ptr %193, align 8, !tbaa !16
  %195 = getelementptr inbounds nuw i8, ptr %193, i64 8
  %196 = load i64, ptr %195, align 8
  br label %197

197:                                              ; preds = %182, %185, %190
  %198 = phi i64 [ %183, %182 ], [ %189, %185 ], [ %194, %190 ]
  %199 = phi i64 [ %184, %182 ], [ 5, %185 ], [ %196, %190 ]
  %200 = insertvalue [2 x i64] poison, i64 %198, 0
  %201 = insertvalue [2 x i64] %200, i64 %199, 1
  %202 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %79, i64 noundef 0, [2 x i64] %201, i32 noundef 1) #25
  %203 = icmp eq i32 %202, 0
  br i1 %203, label %147, label %204

204:                                              ; preds = %197
  %205 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %79) #25
  br label %207

206:                                              ; preds = %147, %86, %145
  store i64 %79, ptr %4, align 8, !tbaa !16
  br label %207

207:                                              ; preds = %204, %206, %69
  %208 = phi i32 [ %74, %69 ], [ 0, %206 ], [ %202, %204 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  br label %209

209:                                              ; preds = %23, %16, %12, %18, %27, %11, %34, %50, %46, %41, %38, %33, %207, %55, %5
  %210 = phi i32 [ 6, %5 ], [ %208, %207 ], [ 1, %55 ], [ 6, %23 ], [ 6, %16 ], [ 5, %12 ], [ 6, %18 ], [ %32, %27 ], [ 6, %11 ], [ 5, %34 ], [ 6, %50 ], [ 6, %46 ], [ 6, %41 ], [ 6, %38 ], [ 6, %33 ]
  ret i32 %210
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_format_scalar(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca [32 x i8], align 1
  %6 = alloca [1100 x i8], align 1
  %7 = alloca [6 x i8], align 1
  %8 = alloca [20 x i8], align 1
  switch i32 %2, label %783 [
    i32 3, label %9
    i32 9, label %728
    i32 7, label %728
    i32 0, label %728
    i32 4, label %743
  ]

9:                                                ; preds = %4
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %12, label %11

11:                                               ; preds = %9
  store i8 45, ptr %5, align 1, !tbaa !39
  br label %12

12:                                               ; preds = %11, %9
  %13 = phi i32 [ 1, %11 ], [ 0, %9 ]
  %14 = lshr i64 %1, 52
  %15 = trunc nuw nsw i64 %14 to i32
  %16 = and i32 %15, 2047
  %17 = and i64 %1, 4503599627370495
  %18 = icmp eq i32 %16, 2047
  br i1 %18, label %19, label %63

19:                                               ; preds = %12
  %20 = icmp eq i64 %17, 0
  %21 = zext nneg i32 %13 to i64
  %22 = select i1 %20, i8 105, i8 110
  %23 = getelementptr inbounds nuw i8, ptr %5, i64 %21
  store i8 %22, ptr %23, align 1, !tbaa !39
  %24 = select i1 %20, i8 110, i8 97
  %25 = getelementptr inbounds nuw i8, ptr %23, i64 1
  store i8 %24, ptr %25, align 1, !tbaa !39
  %26 = select i1 %20, i8 102, i8 110
  %27 = add nuw nsw i64 %21, 3
  %28 = getelementptr inbounds nuw i8, ptr %23, i64 2
  store i8 %26, ptr %28, align 1, !tbaa !39
  %29 = trunc nuw nsw i64 %27 to i32
  %30 = icmp ne ptr %0, null
  %31 = icmp ne ptr %3, null
  %32 = and i1 %30, %31
  br i1 %32, label %33, label %726

33:                                               ; preds = %19
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %35 = load i32, ptr %34, align 8, !tbaa !17
  %36 = icmp eq i32 %35, 0
  br i1 %36, label %37, label %726

37:                                               ; preds = %33
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %39 = load i64, ptr %38, align 8, !tbaa !31
  %40 = xor i64 %39, -1
  %41 = icmp ugt i64 %27, %40
  br i1 %41, label %726, label %42

42:                                               ; preds = %37
  %43 = or disjoint i64 %21, 4
  %44 = tail call ptr @malloc(i64 noundef %43) #24
  %45 = icmp eq ptr %44, null
  br i1 %45, label %726, label %46

46:                                               ; preds = %42
  %47 = load volatile i8, ptr %5, align 1, !tbaa !39
  store volatile i8 %47, ptr %44, align 1, !tbaa !39
  %48 = getelementptr inbounds nuw i8, ptr %5, i64 1
  %49 = load volatile i8, ptr %48, align 1, !tbaa !39
  %50 = getelementptr inbounds nuw i8, ptr %44, i64 1
  store volatile i8 %49, ptr %50, align 1, !tbaa !39
  %51 = getelementptr inbounds nuw i8, ptr %5, i64 2
  %52 = load volatile i8, ptr %51, align 1, !tbaa !39
  %53 = getelementptr inbounds nuw i8, ptr %44, i64 2
  store volatile i8 %52, ptr %53, align 1, !tbaa !39
  br i1 %10, label %58, label %54

54:                                               ; preds = %46
  %55 = getelementptr inbounds nuw i8, ptr %5, i64 3
  %56 = load volatile i8, ptr %55, align 1, !tbaa !39
  %57 = getelementptr inbounds nuw i8, ptr %44, i64 3
  store volatile i8 %56, ptr %57, align 1, !tbaa !39
  br label %58

58:                                               ; preds = %54, %46
  %59 = getelementptr inbounds nuw i8, ptr %44, i64 %27
  store i8 0, ptr %59, align 1, !tbaa !39
  %60 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %44, i32 noundef %29, i32 noundef 0, i32 noundef 1, i64 noundef %27, ptr noundef %3) #25
  %61 = icmp eq i32 %60, 0
  br i1 %61, label %726, label %62

62:                                               ; preds = %58
  tail call void @free(ptr noundef nonnull %44) #26
  br label %726

63:                                               ; preds = %12
  %64 = icmp ne i32 %16, 0
  %65 = icmp ne i64 %17, 0
  %66 = or i1 %65, %64
  br i1 %66, label %99, label %67

67:                                               ; preds = %63
  %68 = add nuw nsw i32 %13, 1
  %69 = zext nneg i32 %13 to i64
  %70 = getelementptr inbounds nuw i8, ptr %5, i64 %69
  store i8 48, ptr %70, align 1, !tbaa !39
  %71 = zext nneg i32 %68 to i64
  %72 = icmp ne ptr %0, null
  %73 = icmp ne ptr %3, null
  %74 = and i1 %72, %73
  br i1 %74, label %75, label %726

75:                                               ; preds = %67
  %76 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %77 = load i32, ptr %76, align 8, !tbaa !17
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %79, label %726

79:                                               ; preds = %75
  %80 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %81 = load i64, ptr %80, align 8, !tbaa !31
  %82 = xor i64 %81, -1
  %83 = icmp ugt i64 %71, %82
  br i1 %83, label %726, label %84

84:                                               ; preds = %79
  %85 = add nuw nsw i64 %71, 1
  %86 = tail call ptr @malloc(i64 noundef %85) #24
  %87 = icmp eq ptr %86, null
  br i1 %87, label %726, label %88

88:                                               ; preds = %84
  %89 = load volatile i8, ptr %5, align 1, !tbaa !39
  store volatile i8 %89, ptr %86, align 1, !tbaa !39
  br i1 %10, label %94, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %5, i64 1
  %92 = load volatile i8, ptr %91, align 1, !tbaa !39
  %93 = getelementptr inbounds nuw i8, ptr %86, i64 1
  store volatile i8 %92, ptr %93, align 1, !tbaa !39
  br label %94

94:                                               ; preds = %90, %88
  %95 = getelementptr inbounds nuw i8, ptr %86, i64 %71
  store i8 0, ptr %95, align 1, !tbaa !39
  %96 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %86, i32 noundef %68, i32 noundef 0, i32 noundef 1, i64 noundef %71, ptr noundef %3) #25
  %97 = icmp eq i32 %96, 0
  br i1 %97, label %726, label %98

98:                                               ; preds = %94
  tail call void @free(ptr noundef nonnull %86) #26
  br label %726

99:                                               ; preds = %63
  %100 = or disjoint i64 %17, 4503599627370496
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  %101 = select i1 %64, i64 %100, i64 %17
  br label %102

102:                                              ; preds = %99, %102
  %103 = phi i32 [ %110, %102 ], [ 0, %99 ]
  %104 = phi i64 [ %106, %102 ], [ %101, %99 ]
  %105 = freeze i64 %104
  %106 = udiv i64 %105, 10
  %107 = mul i64 %106, 10
  %108 = sub i64 %105, %107
  %109 = trunc nuw nsw i64 %108 to i8
  %110 = add i32 %103, 1
  %111 = zext i32 %103 to i64
  %112 = getelementptr inbounds nuw i8, ptr %6, i64 %111
  store i8 %109, ptr %112, align 1, !tbaa !39
  %113 = icmp samesign ult i64 %104, 10
  br i1 %113, label %114, label %102, !llvm.loop !72

114:                                              ; preds = %102
  %115 = add nsw i32 %16, -1075
  %116 = select i1 %64, i32 %115, i32 -1074
  %117 = icmp slt i32 %116, 0
  %118 = tail call i32 @llvm.abs.i32(i32 %116, i1 true)
  %119 = select i1 %117, i32 5, i32 2
  %120 = icmp eq i32 %116, 0
  br i1 %120, label %154, label %121

121:                                              ; preds = %114, %150
  %122 = phi i32 [ %152, %150 ], [ 0, %114 ]
  %123 = phi i32 [ %151, %150 ], [ %110, %114 ]
  %124 = icmp eq i32 %123, 0
  br i1 %124, label %150, label %125

125:                                              ; preds = %121
  %126 = zext i32 %123 to i64
  br label %129

127:                                              ; preds = %129
  %128 = icmp samesign ult i32 %136, 10
  br i1 %128, label %150, label %144

129:                                              ; preds = %129, %125
  %130 = phi i64 [ 0, %125 ], [ %142, %129 ]
  %131 = phi i32 [ 0, %125 ], [ %138, %129 ]
  %132 = getelementptr inbounds nuw i8, ptr %6, i64 %130
  %133 = load i8, ptr %132, align 1, !tbaa !39
  %134 = zext i8 %133 to i32
  %135 = mul nuw nsw i32 %119, %134
  %136 = add nuw nsw i32 %135, %131
  %137 = freeze i32 %136
  %138 = udiv i32 %137, 10
  %139 = mul i32 %138, 10
  %140 = sub i32 %137, %139
  %141 = trunc nuw nsw i32 %140 to i8
  store i8 %141, ptr %132, align 1, !tbaa !39
  %142 = add nuw nsw i64 %130, 1
  %143 = icmp eq i64 %142, %126
  br i1 %143, label %127, label %129, !llvm.loop !73

144:                                              ; preds = %127
  %145 = icmp eq i32 %123, 1100
  br i1 %145, label %724, label %146

146:                                              ; preds = %144
  %147 = trunc i32 %138 to i8
  %148 = add i32 %123, 1
  %149 = getelementptr inbounds nuw i8, ptr %6, i64 %126
  store i8 %147, ptr %149, align 1, !tbaa !39
  br label %150

150:                                              ; preds = %146, %127, %121
  %151 = phi i32 [ %123, %127 ], [ %148, %146 ], [ 0, %121 ]
  %152 = add nuw i32 %122, 1
  %153 = icmp eq i32 %152, %118
  br i1 %153, label %154, label %121, !llvm.loop !74

154:                                              ; preds = %150, %114
  %155 = phi i32 [ %110, %114 ], [ %151, %150 ]
  %156 = add i32 %155, -1
  %157 = icmp eq i32 %155, 0
  br i1 %157, label %165, label %158

158:                                              ; preds = %154
  %159 = zext i32 %156 to i64
  %160 = getelementptr inbounds nuw i8, ptr %6, i64 %159
  %161 = load i8, ptr %160, align 1, !tbaa !39
  %162 = zext i8 %161 to i32
  %163 = mul nuw nsw i32 %162, 10
  %164 = icmp eq i32 %155, 1
  br i1 %164, label %165, label %168

165:                                              ; preds = %158, %154
  %166 = phi i32 [ %163, %158 ], [ 0, %154 ]
  %167 = mul nuw nsw i32 %166, 10
  br label %177

168:                                              ; preds = %158
  %169 = add i32 %155, -2
  %170 = zext i32 %169 to i64
  %171 = getelementptr inbounds nuw i8, ptr %6, i64 %170
  %172 = load i8, ptr %171, align 1, !tbaa !39
  %173 = zext i8 %172 to i32
  %174 = add nuw nsw i32 %163, %173
  %175 = mul nuw nsw i32 %174, 10
  %176 = icmp ugt i32 %155, 2
  br i1 %176, label %180, label %177

177:                                              ; preds = %168, %165
  %178 = phi i32 [ %167, %165 ], [ %175, %168 ]
  %179 = mul nuw nsw i32 %178, 10
  br label %189

180:                                              ; preds = %168
  %181 = add i32 %155, -3
  %182 = zext i32 %181 to i64
  %183 = getelementptr inbounds nuw i8, ptr %6, i64 %182
  %184 = load i8, ptr %183, align 1, !tbaa !39
  %185 = zext i8 %184 to i32
  %186 = add nuw nsw i32 %175, %185
  %187 = mul nuw nsw i32 %186, 10
  %188 = icmp eq i32 %155, 3
  br i1 %188, label %189, label %192

189:                                              ; preds = %180, %177
  %190 = phi i32 [ %179, %177 ], [ %187, %180 ]
  %191 = mul nuw nsw i32 %190, 10
  br label %201

192:                                              ; preds = %180
  %193 = add i32 %155, -4
  %194 = zext i32 %193 to i64
  %195 = getelementptr inbounds nuw i8, ptr %6, i64 %194
  %196 = load i8, ptr %195, align 1, !tbaa !39
  %197 = zext i8 %196 to i32
  %198 = add nuw nsw i32 %187, %197
  %199 = mul nuw nsw i32 %198, 10
  %200 = icmp ugt i32 %155, 4
  br i1 %200, label %204, label %201

201:                                              ; preds = %192, %189
  %202 = phi i32 [ %191, %189 ], [ %199, %192 ]
  %203 = mul nuw nsw i32 %202, 10
  br label %213

204:                                              ; preds = %192
  %205 = add i32 %155, -5
  %206 = zext i32 %205 to i64
  %207 = getelementptr inbounds nuw i8, ptr %6, i64 %206
  %208 = load i8, ptr %207, align 1, !tbaa !39
  %209 = zext i8 %208 to i32
  %210 = add nuw nsw i32 %199, %209
  %211 = mul nuw nsw i32 %210, 10
  %212 = icmp eq i32 %155, 5
  br i1 %212, label %213, label %217

213:                                              ; preds = %204, %201
  %214 = phi i32 [ %203, %201 ], [ %211, %204 ]
  %215 = tail call i32 @llvm.smin.i32(i32 %116, i32 0)
  %216 = add nsw i32 %156, %215
  br label %327

217:                                              ; preds = %204
  %218 = add i32 %155, -6
  %219 = zext i32 %218 to i64
  %220 = getelementptr inbounds nuw i8, ptr %6, i64 %219
  %221 = load i8, ptr %220, align 1, !tbaa !39
  %222 = zext i8 %221 to i32
  %223 = add nuw nsw i32 %211, %222
  %224 = tail call i32 @llvm.smin.i32(i32 %116, i32 0)
  %225 = add nsw i32 %156, %224
  %226 = icmp ugt i32 %155, 6
  br i1 %226, label %227, label %327

227:                                              ; preds = %217
  %228 = add i32 %155, -7
  %229 = zext i32 %228 to i64
  %230 = getelementptr inbounds nuw i8, ptr %6, i64 %229
  %231 = load i8, ptr %230, align 1, !tbaa !39
  %232 = icmp eq i32 %155, 7
  br i1 %232, label %300, label %233

233:                                              ; preds = %227
  %234 = icmp ult i32 %228, 8
  br i1 %234, label %294, label %235

235:                                              ; preds = %233
  %236 = icmp ult i32 %228, 64
  br i1 %236, label %276, label %237

237:                                              ; preds = %235
  %238 = and i64 %229, 56
  %239 = and i64 %229, 4294967232
  br label %240

240:                                              ; preds = %240, %237
  %241 = phi i64 [ 0, %237 ], [ %266, %240 ]
  %242 = phi <16 x i32> [ zeroinitializer, %237 ], [ %262, %240 ]
  %243 = phi <16 x i32> [ zeroinitializer, %237 ], [ %263, %240 ]
  %244 = phi <16 x i32> [ zeroinitializer, %237 ], [ %264, %240 ]
  %245 = phi <16 x i32> [ zeroinitializer, %237 ], [ %265, %240 ]
  %246 = getelementptr inbounds nuw i8, ptr %6, i64 %241
  %247 = getelementptr inbounds nuw i8, ptr %246, i64 16
  %248 = getelementptr inbounds nuw i8, ptr %246, i64 32
  %249 = getelementptr inbounds nuw i8, ptr %246, i64 48
  %250 = load <16 x i8>, ptr %246, align 1, !tbaa !39
  %251 = load <16 x i8>, ptr %247, align 1, !tbaa !39
  %252 = load <16 x i8>, ptr %248, align 1, !tbaa !39
  %253 = load <16 x i8>, ptr %249, align 1, !tbaa !39
  %254 = icmp ne <16 x i8> %250, zeroinitializer
  %255 = icmp ne <16 x i8> %251, zeroinitializer
  %256 = icmp ne <16 x i8> %252, zeroinitializer
  %257 = icmp ne <16 x i8> %253, zeroinitializer
  %258 = zext <16 x i1> %254 to <16 x i32>
  %259 = zext <16 x i1> %255 to <16 x i32>
  %260 = zext <16 x i1> %256 to <16 x i32>
  %261 = zext <16 x i1> %257 to <16 x i32>
  %262 = or <16 x i32> %242, %258
  %263 = or <16 x i32> %243, %259
  %264 = or <16 x i32> %244, %260
  %265 = or <16 x i32> %245, %261
  %266 = add nuw i64 %241, 64
  %267 = icmp eq i64 %266, %239
  br i1 %267, label %268, label %240, !llvm.loop !75

268:                                              ; preds = %240
  %269 = or <16 x i32> %263, %262
  %270 = or <16 x i32> %264, %269
  %271 = or <16 x i32> %265, %270
  %272 = tail call i32 @llvm.vector.reduce.or.v16i32(<16 x i32> %271)
  %273 = icmp eq i64 %239, %229
  br i1 %273, label %297, label %274

274:                                              ; preds = %268
  %275 = icmp eq i64 %238, 0
  br i1 %275, label %294, label %276, !prof !78

276:                                              ; preds = %235, %274
  %277 = phi i64 [ %239, %274 ], [ 0, %235 ]
  %278 = phi i32 [ %272, %274 ], [ 0, %235 ]
  %279 = and i64 %229, 4294967288
  %280 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %278, i64 0
  br label %281

281:                                              ; preds = %281, %276
  %282 = phi i64 [ %277, %276 ], [ %289, %281 ]
  %283 = phi <8 x i32> [ %280, %276 ], [ %288, %281 ]
  %284 = getelementptr inbounds nuw i8, ptr %6, i64 %282
  %285 = load <8 x i8>, ptr %284, align 1, !tbaa !39
  %286 = icmp ne <8 x i8> %285, zeroinitializer
  %287 = zext <8 x i1> %286 to <8 x i32>
  %288 = or <8 x i32> %283, %287
  %289 = add nuw i64 %282, 8
  %290 = icmp eq i64 %289, %279
  br i1 %290, label %291, label %281, !llvm.loop !79

291:                                              ; preds = %281
  %292 = tail call i32 @llvm.vector.reduce.or.v8i32(<8 x i32> %288)
  %293 = icmp eq i64 %279, %229
  br i1 %293, label %297, label %294

294:                                              ; preds = %233, %274, %291
  %295 = phi i64 [ 0, %233 ], [ %239, %274 ], [ %279, %291 ]
  %296 = phi i32 [ 0, %233 ], [ %272, %274 ], [ %292, %291 ]
  br label %303

297:                                              ; preds = %303, %291, %268
  %298 = phi i32 [ %292, %291 ], [ %272, %268 ], [ %310, %303 ]
  %299 = icmp eq i32 %298, 0
  br label %300

300:                                              ; preds = %297, %227
  %301 = phi i1 [ true, %227 ], [ %299, %297 ]
  %302 = icmp ugt i8 %231, 5
  br i1 %302, label %319, label %313

303:                                              ; preds = %294, %303
  %304 = phi i64 [ %311, %303 ], [ %295, %294 ]
  %305 = phi i32 [ %310, %303 ], [ %296, %294 ]
  %306 = getelementptr inbounds nuw i8, ptr %6, i64 %304
  %307 = load i8, ptr %306, align 1, !tbaa !39
  %308 = icmp ne i8 %307, 0
  %309 = zext i1 %308 to i32
  %310 = or i32 %305, %309
  %311 = add nuw nsw i64 %304, 1
  %312 = icmp eq i64 %311, %229
  br i1 %312, label %297, label %303, !llvm.loop !80

313:                                              ; preds = %300
  %314 = icmp eq i8 %231, 5
  br i1 %314, label %315, label %321

315:                                              ; preds = %313
  %316 = and i32 %222, 1
  %317 = icmp eq i32 %316, 0
  %318 = select i1 %301, i1 %317, i1 false
  br i1 %318, label %321, label %319

319:                                              ; preds = %315, %300
  %320 = add nuw nsw i32 %223, 1
  br label %321

321:                                              ; preds = %319, %315, %313
  %322 = phi i32 [ %320, %319 ], [ %223, %315 ], [ %223, %313 ]
  %323 = icmp eq i32 %322, 1000000
  %324 = add i32 %155, %224
  %325 = select i1 %323, i32 %324, i32 %225
  %326 = select i1 %323, i32 100000, i32 %322
  br label %327

327:                                              ; preds = %321, %217, %213
  %328 = phi i32 [ %325, %321 ], [ %225, %217 ], [ %216, %213 ]
  %329 = phi i32 [ %326, %321 ], [ %223, %217 ], [ %214, %213 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #27
  %330 = freeze i32 %329
  %331 = udiv i32 %330, 10
  %332 = mul i32 %331, 10
  %333 = sub i32 %330, %332
  %334 = trunc nuw nsw i32 %333 to i8
  %335 = or disjoint i8 %334, 48
  %336 = getelementptr inbounds nuw i8, ptr %7, i64 5
  store i8 %335, ptr %336, align 1, !tbaa !39
  %337 = urem i32 %331, 10
  %338 = trunc nuw nsw i32 %337 to i8
  %339 = or disjoint i8 %338, 48
  %340 = getelementptr inbounds nuw i8, ptr %7, i64 4
  store i8 %339, ptr %340, align 1, !tbaa !39
  %341 = udiv i32 %329, 100
  %342 = urem i32 %341, 10
  %343 = trunc nuw nsw i32 %342 to i8
  %344 = or disjoint i8 %343, 48
  %345 = getelementptr inbounds nuw i8, ptr %7, i64 3
  store i8 %344, ptr %345, align 1, !tbaa !39
  %346 = udiv i32 %329, 1000
  %347 = trunc nuw nsw i32 %346 to i16
  %348 = urem i16 %347, 10
  %349 = trunc nuw nsw i16 %348 to i8
  %350 = or disjoint i8 %349, 48
  %351 = getelementptr inbounds nuw i8, ptr %7, i64 2
  store i8 %350, ptr %351, align 1, !tbaa !39
  %352 = udiv i32 %329, 10000
  %353 = trunc nuw nsw i32 %352 to i16
  %354 = urem i16 %353, 10
  %355 = trunc nuw nsw i16 %354 to i8
  %356 = or disjoint i8 %355, 48
  %357 = getelementptr inbounds nuw i8, ptr %7, i64 1
  store i8 %356, ptr %357, align 1, !tbaa !39
  %358 = udiv i32 %329, 100000
  %359 = trunc nuw nsw i32 %358 to i16
  %360 = urem i16 %359, 10
  %361 = trunc nuw nsw i16 %360 to i8
  %362 = or disjoint i8 %361, 48
  store i8 %362, ptr %7, align 1, !tbaa !39
  %363 = icmp eq i32 %333, 0
  br i1 %363, label %364, label %372

364:                                              ; preds = %327
  %365 = icmp eq i32 %337, 0
  br i1 %365, label %366, label %372

366:                                              ; preds = %364
  %367 = icmp eq i32 %342, 0
  br i1 %367, label %368, label %372

368:                                              ; preds = %366
  %369 = icmp eq i16 %348, 0
  br i1 %369, label %370, label %372

370:                                              ; preds = %368
  %371 = icmp eq i16 %354, 0
  br i1 %371, label %380, label %372

372:                                              ; preds = %370, %368, %366, %364, %327
  %373 = phi i1 [ false, %327 ], [ false, %364 ], [ false, %366 ], [ false, %368 ], [ true, %370 ]
  %374 = phi i1 [ false, %327 ], [ false, %364 ], [ false, %366 ], [ true, %368 ], [ false, %370 ]
  %375 = phi i1 [ false, %327 ], [ false, %364 ], [ true, %366 ], [ false, %368 ], [ false, %370 ]
  %376 = phi i1 [ false, %327 ], [ true, %364 ], [ false, %366 ], [ false, %368 ], [ false, %370 ]
  %377 = phi i32 [ 6, %327 ], [ 5, %364 ], [ 4, %366 ], [ 3, %368 ], [ 2, %370 ]
  %378 = add i32 %328, -6
  %379 = icmp ult i32 %378, -10
  br i1 %379, label %387, label %445

380:                                              ; preds = %370
  %381 = add i32 %328, -6
  %382 = icmp ult i32 %381, -10
  br i1 %382, label %383, label %445

383:                                              ; preds = %380
  %384 = add nuw nsw i32 %13, 1
  %385 = zext nneg i32 %13 to i64
  %386 = getelementptr inbounds nuw i8, ptr %5, i64 %385
  store i8 %362, ptr %386, align 1, !tbaa !39
  br label %409

387:                                              ; preds = %372
  %388 = zext nneg i32 %13 to i64
  %389 = getelementptr inbounds nuw i8, ptr %5, i64 %388
  store i8 %362, ptr %389, align 1, !tbaa !39
  %390 = getelementptr inbounds nuw i8, ptr %389, i64 1
  store i8 46, ptr %390, align 1, !tbaa !39
  %391 = add nuw nsw i64 %388, 3
  %392 = getelementptr inbounds nuw i8, ptr %5, i64 %388
  %393 = getelementptr inbounds nuw i8, ptr %392, i64 2
  store i8 %356, ptr %393, align 1, !tbaa !39
  br i1 %373, label %406, label %394

394:                                              ; preds = %387
  %395 = or disjoint i64 %388, 4
  %396 = getelementptr inbounds nuw i8, ptr %5, i64 %391
  store i8 %350, ptr %396, align 1, !tbaa !39
  br i1 %374, label %406, label %397

397:                                              ; preds = %394
  %398 = add nuw nsw i64 %388, 5
  %399 = getelementptr inbounds nuw i8, ptr %5, i64 %395
  store i8 %344, ptr %399, align 1, !tbaa !39
  br i1 %375, label %406, label %400

400:                                              ; preds = %397
  %401 = or disjoint i64 %388, 6
  %402 = getelementptr inbounds nuw i8, ptr %5, i64 %398
  store i8 %339, ptr %402, align 1, !tbaa !39
  br i1 %376, label %406, label %403

403:                                              ; preds = %400
  %404 = add nuw nsw i64 %388, 7
  %405 = getelementptr inbounds nuw i8, ptr %5, i64 %401
  store i8 %335, ptr %405, align 1, !tbaa !39
  br label %406

406:                                              ; preds = %403, %400, %397, %394, %387
  %407 = phi i64 [ %391, %387 ], [ %395, %394 ], [ %398, %397 ], [ %401, %400 ], [ %404, %403 ]
  %408 = trunc nuw nsw i64 %407 to i32
  br label %409

409:                                              ; preds = %406, %383
  %410 = phi i32 [ %384, %383 ], [ %408, %406 ]
  %411 = add i32 %410, 1
  %412 = zext i32 %410 to i64
  %413 = getelementptr inbounds nuw i8, ptr %5, i64 %412
  store i8 101, ptr %413, align 1, !tbaa !39
  %414 = icmp slt i32 %328, 0
  %415 = select i1 %414, i8 45, i8 43
  %416 = add i32 %410, 2
  %417 = zext i32 %411 to i64
  %418 = getelementptr inbounds nuw i8, ptr %5, i64 %417
  store i8 %415, ptr %418, align 1, !tbaa !39
  %419 = tail call i32 @llvm.abs.i32(i32 %328, i1 true)
  %420 = icmp samesign ugt i32 %419, 99
  br i1 %420, label %421, label %428

421:                                              ; preds = %409
  %422 = udiv i32 %419, 100
  %423 = trunc i32 %422 to i8
  %424 = add i8 %423, 48
  %425 = add i32 %410, 3
  %426 = zext i32 %416 to i64
  %427 = getelementptr inbounds nuw i8, ptr %5, i64 %426
  store i8 %424, ptr %427, align 1, !tbaa !39
  br label %428

428:                                              ; preds = %421, %409
  %429 = phi i32 [ %425, %421 ], [ %416, %409 ]
  %430 = freeze i32 %419
  %431 = udiv i32 %430, 10
  %432 = urem i32 %431, 10
  %433 = trunc nuw nsw i32 %432 to i8
  %434 = or disjoint i8 %433, 48
  %435 = add i32 %429, 1
  %436 = zext i32 %429 to i64
  %437 = getelementptr inbounds nuw i8, ptr %5, i64 %436
  store i8 %434, ptr %437, align 1, !tbaa !39
  %438 = mul i32 %431, 10
  %439 = sub i32 %430, %438
  %440 = trunc nuw nsw i32 %439 to i8
  %441 = or disjoint i8 %440, 48
  %442 = add i32 %429, 2
  %443 = zext i32 %435 to i64
  %444 = getelementptr inbounds nuw i8, ptr %5, i64 %443
  store i8 %441, ptr %444, align 1, !tbaa !39
  br label %657

445:                                              ; preds = %380, %372
  %446 = phi i32 [ 1, %380 ], [ %377, %372 ]
  %447 = icmp slt i32 %328, 0
  br i1 %447, label %448, label %513

448:                                              ; preds = %445
  %449 = zext nneg i32 %13 to i64
  %450 = getelementptr inbounds nuw i8, ptr %5, i64 %449
  store i8 48, ptr %450, align 1, !tbaa !39
  %451 = or disjoint i32 %13, 2
  %452 = getelementptr inbounds nuw i8, ptr %450, i64 1
  store i8 46, ptr %452, align 1, !tbaa !39
  %453 = icmp eq i32 %328, -1
  br i1 %453, label %495, label %454

454:                                              ; preds = %448
  %455 = or disjoint i64 %449, 2
  %456 = add nuw nsw i32 %13, 1
  %457 = sub i32 %456, %328
  %458 = zext i32 %457 to i64
  %459 = add nsw i64 %458, -2
  %460 = sub nsw i64 %459, %449
  %461 = icmp ult i64 %460, 8
  br i1 %461, label %493, label %462

462:                                              ; preds = %454
  %463 = icmp ult i64 %460, 64
  br i1 %463, label %481, label %464

464:                                              ; preds = %462
  %465 = and i64 %460, 56
  %466 = and i64 %460, -64
  %467 = or disjoint i64 %455, %466
  %468 = getelementptr inbounds nuw i8, ptr %5, i64 %455
  br label %469

469:                                              ; preds = %469, %464
  %470 = phi i64 [ 0, %464 ], [ %475, %469 ]
  %471 = getelementptr inbounds nuw i8, ptr %468, i64 %470
  %472 = getelementptr inbounds nuw i8, ptr %471, i64 16
  %473 = getelementptr inbounds nuw i8, ptr %471, i64 32
  %474 = getelementptr inbounds nuw i8, ptr %471, i64 48
  store <16 x i8> splat (i8 48), ptr %471, align 1, !tbaa !39
  store <16 x i8> splat (i8 48), ptr %472, align 1, !tbaa !39
  store <16 x i8> splat (i8 48), ptr %473, align 1, !tbaa !39
  store <16 x i8> splat (i8 48), ptr %474, align 1, !tbaa !39
  %475 = add nuw i64 %470, 64
  %476 = icmp eq i64 %475, %466
  br i1 %476, label %477, label %469, !llvm.loop !81

477:                                              ; preds = %469
  %478 = icmp eq i64 %460, %466
  br i1 %478, label %495, label %479

479:                                              ; preds = %477
  %480 = icmp eq i64 %465, 0
  br i1 %480, label %493, label %481, !prof !78

481:                                              ; preds = %462, %479
  %482 = phi i64 [ %466, %479 ], [ 0, %462 ]
  %483 = and i64 %460, -8
  %484 = or disjoint i64 %455, %483
  %485 = getelementptr inbounds nuw i8, ptr %5, i64 %455
  br label %486

486:                                              ; preds = %486, %481
  %487 = phi i64 [ %482, %481 ], [ %489, %486 ]
  %488 = getelementptr inbounds nuw i8, ptr %485, i64 %487
  store <8 x i8> splat (i8 48), ptr %488, align 1, !tbaa !39
  %489 = add nuw i64 %487, 8
  %490 = icmp eq i64 %489, %483
  br i1 %490, label %491, label %486, !llvm.loop !82

491:                                              ; preds = %486
  %492 = icmp eq i64 %460, %483
  br i1 %492, label %495, label %493

493:                                              ; preds = %454, %479, %491
  %494 = phi i64 [ %455, %454 ], [ %467, %479 ], [ %484, %491 ]
  br label %498

495:                                              ; preds = %498, %477, %491, %448
  %496 = phi i32 [ %451, %448 ], [ %457, %477 ], [ %457, %491 ], [ %457, %498 ]
  %497 = zext nneg i32 %446 to i64
  br label %503

498:                                              ; preds = %493, %498
  %499 = phi i64 [ %500, %498 ], [ %494, %493 ]
  %500 = add nuw nsw i64 %499, 1
  %501 = getelementptr inbounds nuw i8, ptr %5, i64 %499
  store i8 48, ptr %501, align 1, !tbaa !39
  %502 = icmp eq i64 %500, %458
  br i1 %502, label %495, label %498, !llvm.loop !83

503:                                              ; preds = %495, %503
  %504 = phi i64 [ 0, %495 ], [ %511, %503 ]
  %505 = phi i32 [ %496, %495 ], [ %508, %503 ]
  %506 = getelementptr inbounds nuw i8, ptr %7, i64 %504
  %507 = load i8, ptr %506, align 1, !tbaa !39
  %508 = add i32 %505, 1
  %509 = zext i32 %505 to i64
  %510 = getelementptr inbounds nuw i8, ptr %5, i64 %509
  store i8 %507, ptr %510, align 1, !tbaa !39
  %511 = add nuw nsw i64 %504, 1
  %512 = icmp eq i64 %511, %497
  br i1 %512, label %657, label %503, !llvm.loop !84

513:                                              ; preds = %445
  %514 = add nuw nsw i32 %328, 1
  %515 = zext nneg i32 %514 to i64
  %516 = zext nneg i32 %13 to i64
  %517 = icmp ult i32 %328, 7
  br i1 %517, label %561, label %518

518:                                              ; preds = %513
  %519 = icmp ult i32 %328, 63
  br i1 %519, label %546, label %520

520:                                              ; preds = %518
  %521 = and i64 %515, 56
  %522 = and i64 %515, 2147483584
  %523 = or disjoint i64 %522, %516
  %524 = getelementptr i8, ptr %5, i64 %516
  br label %525

525:                                              ; preds = %525, %520
  %526 = phi i64 [ 0, %520 ], [ %539, %525 ]
  %527 = getelementptr inbounds nuw i8, ptr %7, i64 %526
  %528 = getelementptr inbounds nuw i8, ptr %527, i64 16
  %529 = getelementptr inbounds nuw i8, ptr %527, i64 32
  %530 = getelementptr inbounds nuw i8, ptr %527, i64 48
  %531 = load <16 x i8>, ptr %527, align 1, !tbaa !39
  %532 = load <16 x i8>, ptr %528, align 1, !tbaa !39
  %533 = load <16 x i8>, ptr %529, align 1, !tbaa !39
  %534 = load <16 x i8>, ptr %530, align 1, !tbaa !39
  %535 = getelementptr i8, ptr %524, i64 %526
  %536 = getelementptr inbounds nuw i8, ptr %535, i64 16
  %537 = getelementptr inbounds nuw i8, ptr %535, i64 32
  %538 = getelementptr inbounds nuw i8, ptr %535, i64 48
  store <16 x i8> %531, ptr %535, align 1, !tbaa !39
  store <16 x i8> %532, ptr %536, align 1, !tbaa !39
  store <16 x i8> %533, ptr %537, align 1, !tbaa !39
  store <16 x i8> %534, ptr %538, align 1, !tbaa !39
  %539 = add nuw i64 %526, 64
  %540 = icmp eq i64 %539, %522
  br i1 %540, label %541, label %525, !llvm.loop !85

541:                                              ; preds = %525
  %542 = add nsw i64 %523, -1
  %543 = icmp eq i64 %522, %515
  br i1 %543, label %564, label %544

544:                                              ; preds = %541
  %545 = icmp eq i64 %521, 0
  br i1 %545, label %561, label %546, !prof !78

546:                                              ; preds = %518, %544
  %547 = phi i64 [ %522, %544 ], [ 0, %518 ]
  %548 = and i64 %515, 2147483640
  %549 = or disjoint i64 %548, %516
  %550 = getelementptr i8, ptr %5, i64 %516
  br label %551

551:                                              ; preds = %551, %546
  %552 = phi i64 [ %547, %546 ], [ %556, %551 ]
  %553 = getelementptr inbounds nuw i8, ptr %7, i64 %552
  %554 = load <8 x i8>, ptr %553, align 1, !tbaa !39
  %555 = getelementptr i8, ptr %550, i64 %552
  store <8 x i8> %554, ptr %555, align 1, !tbaa !39
  %556 = add nuw i64 %552, 8
  %557 = icmp eq i64 %556, %548
  br i1 %557, label %558, label %551, !llvm.loop !86

558:                                              ; preds = %551
  %559 = add nsw i64 %549, -1
  %560 = icmp eq i64 %548, %515
  br i1 %560, label %564, label %561

561:                                              ; preds = %513, %544, %558
  %562 = phi i64 [ %516, %513 ], [ %523, %544 ], [ %549, %558 ]
  %563 = phi i64 [ 0, %513 ], [ %522, %544 ], [ %548, %558 ]
  br label %569

564:                                              ; preds = %569, %558, %541
  %565 = phi i64 [ %559, %558 ], [ %542, %541 ], [ %570, %569 ]
  %566 = phi i64 [ %549, %558 ], [ %523, %541 ], [ %574, %569 ]
  %567 = trunc nuw i64 %566 to i32
  %568 = icmp samesign ugt i32 %446, %514
  br i1 %568, label %578, label %657

569:                                              ; preds = %561, %569
  %570 = phi i64 [ %574, %569 ], [ %562, %561 ]
  %571 = phi i64 [ %576, %569 ], [ %563, %561 ]
  %572 = getelementptr inbounds nuw i8, ptr %7, i64 %571
  %573 = load i8, ptr %572, align 1, !tbaa !39
  %574 = add nuw nsw i64 %570, 1
  %575 = getelementptr inbounds nuw i8, ptr %5, i64 %570
  store i8 %573, ptr %575, align 1, !tbaa !39
  %576 = add nuw nsw i64 %571, 1
  %577 = icmp eq i64 %576, %515
  br i1 %577, label %564, label %569, !llvm.loop !87

578:                                              ; preds = %564
  %579 = trunc i64 %565 to i32
  %580 = getelementptr inbounds nuw i8, ptr %5, i64 %566
  store i8 46, ptr %580, align 1, !tbaa !39
  %581 = add i32 %579, 2
  %582 = add nsw i32 %446, -2
  %583 = sub i32 %582, %328
  %584 = zext i32 %583 to i64
  %585 = add nuw nsw i64 %584, 1
  %586 = icmp ult i32 %583, 7
  br i1 %586, label %643, label %587

587:                                              ; preds = %578
  %588 = add nsw i32 %446, -2
  %589 = sub i32 %588, %328
  %590 = sub i32 -3, %579
  %591 = icmp ult i32 %590, %589
  br i1 %591, label %643, label %592

592:                                              ; preds = %587
  %593 = icmp ult i32 %583, 63
  br i1 %593, label %624, label %594

594:                                              ; preds = %592
  %595 = and i64 %585, 56
  %596 = and i64 %585, 8589934528
  %597 = add nuw nsw i64 %596, %515
  %598 = trunc i64 %596 to i32
  %599 = add i32 %581, %598
  %600 = getelementptr i8, ptr %7, i64 %515
  br label %601

601:                                              ; preds = %601, %594
  %602 = phi i64 [ 0, %594 ], [ %618, %601 ]
  %603 = trunc i64 %602 to i32
  %604 = add i32 %581, %603
  %605 = getelementptr i8, ptr %600, i64 %602
  %606 = getelementptr inbounds nuw i8, ptr %605, i64 16
  %607 = getelementptr inbounds nuw i8, ptr %605, i64 32
  %608 = getelementptr inbounds nuw i8, ptr %605, i64 48
  %609 = load <16 x i8>, ptr %605, align 1, !tbaa !39
  %610 = load <16 x i8>, ptr %606, align 1, !tbaa !39
  %611 = load <16 x i8>, ptr %607, align 1, !tbaa !39
  %612 = load <16 x i8>, ptr %608, align 1, !tbaa !39
  %613 = zext i32 %604 to i64
  %614 = getelementptr inbounds nuw i8, ptr %5, i64 %613
  %615 = getelementptr inbounds nuw i8, ptr %614, i64 16
  %616 = getelementptr inbounds nuw i8, ptr %614, i64 32
  %617 = getelementptr inbounds nuw i8, ptr %614, i64 48
  store <16 x i8> %609, ptr %614, align 1, !tbaa !39
  store <16 x i8> %610, ptr %615, align 1, !tbaa !39
  store <16 x i8> %611, ptr %616, align 1, !tbaa !39
  store <16 x i8> %612, ptr %617, align 1, !tbaa !39
  %618 = add nuw i64 %602, 64
  %619 = icmp eq i64 %618, %596
  br i1 %619, label %620, label %601, !llvm.loop !88

620:                                              ; preds = %601
  %621 = icmp eq i64 %585, %596
  br i1 %621, label %657, label %622

622:                                              ; preds = %620
  %623 = icmp eq i64 %595, 0
  br i1 %623, label %643, label %624, !prof !78

624:                                              ; preds = %592, %622
  %625 = phi i64 [ %596, %622 ], [ 0, %592 ]
  %626 = and i64 %585, 8589934584
  %627 = add nuw nsw i64 %626, %515
  %628 = trunc i64 %626 to i32
  %629 = add i32 %581, %628
  %630 = getelementptr i8, ptr %7, i64 %515
  br label %631

631:                                              ; preds = %631, %624
  %632 = phi i64 [ %625, %624 ], [ %639, %631 ]
  %633 = trunc i64 %632 to i32
  %634 = add i32 %581, %633
  %635 = getelementptr i8, ptr %630, i64 %632
  %636 = load <8 x i8>, ptr %635, align 1, !tbaa !39
  %637 = zext i32 %634 to i64
  %638 = getelementptr inbounds nuw i8, ptr %5, i64 %637
  store <8 x i8> %636, ptr %638, align 1, !tbaa !39
  %639 = add nuw i64 %632, 8
  %640 = icmp eq i64 %639, %626
  br i1 %640, label %641, label %631, !llvm.loop !89

641:                                              ; preds = %631
  %642 = icmp eq i64 %585, %626
  br i1 %642, label %657, label %643

643:                                              ; preds = %587, %578, %622, %641
  %644 = phi i64 [ %515, %578 ], [ %515, %587 ], [ %597, %622 ], [ %627, %641 ]
  %645 = phi i32 [ %581, %578 ], [ %581, %587 ], [ %599, %622 ], [ %629, %641 ]
  br label %646

646:                                              ; preds = %643, %646
  %647 = phi i64 [ %653, %646 ], [ %644, %643 ]
  %648 = phi i32 [ %654, %646 ], [ %645, %643 ]
  %649 = getelementptr inbounds nuw i8, ptr %7, i64 %647
  %650 = load i8, ptr %649, align 1, !tbaa !39
  %651 = zext i32 %648 to i64
  %652 = getelementptr inbounds nuw i8, ptr %5, i64 %651
  store i8 %650, ptr %652, align 1, !tbaa !39
  %653 = add nuw nsw i64 %647, 1
  %654 = add i32 %648, 1
  %655 = trunc i64 %653 to i32
  %656 = icmp eq i32 %446, %655
  br i1 %656, label %657, label %646, !llvm.loop !90

657:                                              ; preds = %646, %503, %620, %641, %564, %428
  %658 = phi i32 [ %442, %428 ], [ %508, %503 ], [ %567, %564 ], [ %629, %641 ], [ %599, %620 ], [ %654, %646 ]
  %659 = freeze i32 %658
  %660 = zext i32 %659 to i64
  %661 = icmp ne ptr %0, null
  %662 = icmp ne ptr %3, null
  %663 = and i1 %661, %662
  br i1 %663, label %664, label %722

664:                                              ; preds = %657
  %665 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %666 = load i32, ptr %665, align 8, !tbaa !17
  %667 = icmp eq i32 %666, 0
  br i1 %667, label %668, label %722

668:                                              ; preds = %664
  %669 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %670 = load i64, ptr %669, align 8, !tbaa !31
  %671 = xor i64 %670, -1
  %672 = icmp ugt i64 %660, %671
  br i1 %672, label %722, label %673

673:                                              ; preds = %668
  %674 = add nuw nsw i64 %660, 1
  %675 = tail call ptr @malloc(i64 noundef %674) #24
  %676 = icmp eq ptr %675, null
  br i1 %676, label %722, label %677

677:                                              ; preds = %673
  %678 = icmp eq i32 %659, 0
  br i1 %678, label %717, label %679

679:                                              ; preds = %677
  %680 = add nsw i64 %660, -1
  %681 = urem i64 %680, 3
  %682 = add nuw nsw i64 %681, 1
  %683 = icmp ne i64 %682, 3
  %684 = select i1 %683, i64 %682, i64 0
  %685 = icmp ult i32 %659, 3
  br i1 %685, label %706, label %686

686:                                              ; preds = %679
  %687 = sub nsw i64 %660, %684
  br label %688

688:                                              ; preds = %688, %686
  %689 = phi i64 [ 0, %686 ], [ %702, %688 ]
  %690 = phi i64 [ 0, %686 ], [ %703, %688 ]
  %691 = getelementptr inbounds nuw i8, ptr %5, i64 %689
  %692 = load volatile i8, ptr %691, align 1, !tbaa !39
  %693 = getelementptr inbounds nuw i8, ptr %675, i64 %689
  store volatile i8 %692, ptr %693, align 1, !tbaa !39
  %694 = add nuw nsw i64 %689, 1
  %695 = getelementptr inbounds nuw i8, ptr %5, i64 %694
  %696 = load volatile i8, ptr %695, align 1, !tbaa !39
  %697 = getelementptr inbounds nuw i8, ptr %675, i64 %694
  store volatile i8 %696, ptr %697, align 1, !tbaa !39
  %698 = add nuw nsw i64 %689, 2
  %699 = getelementptr inbounds nuw i8, ptr %5, i64 %698
  %700 = load volatile i8, ptr %699, align 1, !tbaa !39
  %701 = getelementptr inbounds nuw i8, ptr %675, i64 %698
  store volatile i8 %700, ptr %701, align 1, !tbaa !39
  %702 = add nuw nsw i64 %689, 3
  %703 = add i64 %690, 3
  %704 = icmp eq i64 %703, %687
  br i1 %704, label %705, label %688, !llvm.loop !40

705:                                              ; preds = %688
  br i1 %683, label %706, label %717

706:                                              ; preds = %705, %679
  %707 = phi i64 [ 0, %679 ], [ %702, %705 ]
  tail call void @llvm.assume(i1 %683)
  br label %708

708:                                              ; preds = %708, %706
  %709 = phi i64 [ %714, %708 ], [ %707, %706 ]
  %710 = phi i64 [ %715, %708 ], [ 0, %706 ]
  %711 = getelementptr inbounds nuw i8, ptr %5, i64 %709
  %712 = load volatile i8, ptr %711, align 1, !tbaa !39
  %713 = getelementptr inbounds nuw i8, ptr %675, i64 %709
  store volatile i8 %712, ptr %713, align 1, !tbaa !39
  %714 = add nuw nsw i64 %709, 1
  %715 = add i64 %710, 1
  %716 = icmp eq i64 %715, %684
  br i1 %716, label %717, label %708, !llvm.loop !91

717:                                              ; preds = %705, %708, %677
  %718 = getelementptr inbounds nuw i8, ptr %675, i64 %660
  store i8 0, ptr %718, align 1, !tbaa !39
  %719 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %675, i32 noundef %659, i32 noundef 0, i32 noundef 1, i64 noundef %660, ptr noundef %3) #25
  %720 = icmp eq i32 %719, 0
  br i1 %720, label %722, label %721

721:                                              ; preds = %717
  tail call void @free(ptr noundef nonnull %675) #26
  br label %722

722:                                              ; preds = %721, %717, %673, %668, %664, %657
  %723 = phi i32 [ 3, %673 ], [ 6, %657 ], [ 5, %664 ], [ 0, %717 ], [ %719, %721 ], [ 3, %668 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #27
  br label %724

724:                                              ; preds = %144, %722
  %725 = phi i32 [ %723, %722 ], [ 6, %144 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  br label %726

726:                                              ; preds = %19, %33, %37, %42, %58, %62, %67, %75, %79, %84, %94, %98, %724
  %727 = phi i32 [ 3, %37 ], [ %725, %724 ], [ 3, %42 ], [ 6, %19 ], [ 5, %33 ], [ 0, %58 ], [ %60, %62 ], [ 3, %84 ], [ 6, %67 ], [ 5, %75 ], [ 0, %94 ], [ %96, %98 ], [ 3, %79 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  br label %885

728:                                              ; preds = %4, %4, %4
  %729 = icmp ne ptr %0, null
  %730 = icmp ne ptr %3, null
  %731 = and i1 %729, %730
  br i1 %731, label %732, label %885

732:                                              ; preds = %728
  %733 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %734 = load i32, ptr %733, align 8, !tbaa !17
  %735 = icmp eq i32 %734, 0
  br i1 %735, label %736, label %885

736:                                              ; preds = %732
  %737 = tail call dereferenceable_or_null(1) ptr @malloc(i64 noundef 1) #24
  %738 = icmp eq ptr %737, null
  br i1 %738, label %885, label %739

739:                                              ; preds = %736
  store i8 0, ptr %737, align 1, !tbaa !39
  %740 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %737, i32 noundef 0, i32 noundef 0, i32 noundef 1, i64 noundef 0, ptr noundef %3) #25
  %741 = icmp eq i32 %740, 0
  br i1 %741, label %885, label %742

742:                                              ; preds = %739
  tail call void @free(ptr noundef nonnull %737) #26
  br label %885

743:                                              ; preds = %4
  %744 = icmp eq i64 %1, 0
  %745 = select i1 %744, ptr @.str.1, ptr @.str
  %746 = select i1 %744, i64 5, i64 4
  %747 = icmp ne ptr %0, null
  %748 = icmp ne ptr %3, null
  %749 = and i1 %747, %748
  br i1 %749, label %750, label %885

750:                                              ; preds = %743
  %751 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %752 = load i32, ptr %751, align 8, !tbaa !17
  %753 = icmp eq i32 %752, 0
  br i1 %753, label %754, label %885

754:                                              ; preds = %750
  %755 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %756 = load i64, ptr %755, align 8, !tbaa !31
  %757 = xor i64 %756, -1
  %758 = icmp ugt i64 %746, %757
  br i1 %758, label %885, label %759

759:                                              ; preds = %754
  %760 = add nuw nsw i64 %746, 1
  %761 = tail call ptr @malloc(i64 noundef %760) #24
  %762 = icmp eq ptr %761, null
  br i1 %762, label %885, label %763

763:                                              ; preds = %759
  %764 = load volatile i8, ptr %745, align 1, !tbaa !39
  store volatile i8 %764, ptr %761, align 1, !tbaa !39
  %765 = select i1 %744, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 1), ptr getelementptr inbounds nuw (i8, ptr @.str, i64 1)
  %766 = load volatile i8, ptr %765, align 1, !tbaa !39
  %767 = getelementptr inbounds nuw i8, ptr %761, i64 1
  store volatile i8 %766, ptr %767, align 1, !tbaa !39
  %768 = select i1 %744, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 2), ptr getelementptr inbounds nuw (i8, ptr @.str, i64 2)
  %769 = load volatile i8, ptr %768, align 1, !tbaa !39
  %770 = getelementptr inbounds nuw i8, ptr %761, i64 2
  store volatile i8 %769, ptr %770, align 1, !tbaa !39
  %771 = select i1 %744, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 3), ptr getelementptr inbounds nuw (i8, ptr @.str, i64 3)
  %772 = load volatile i8, ptr %771, align 1, !tbaa !39
  %773 = getelementptr inbounds nuw i8, ptr %761, i64 3
  store volatile i8 %772, ptr %773, align 1, !tbaa !39
  br i1 %744, label %774, label %777

774:                                              ; preds = %763
  %775 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i64 4), align 1, !tbaa !39
  %776 = getelementptr inbounds nuw i8, ptr %761, i64 4
  store volatile i8 %775, ptr %776, align 1, !tbaa !39
  br label %777

777:                                              ; preds = %774, %763
  %778 = getelementptr inbounds nuw i8, ptr %761, i64 %746
  store i8 0, ptr %778, align 1, !tbaa !39
  %779 = trunc nuw nsw i64 %746 to i32
  %780 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %761, i32 noundef %779, i32 noundef 0, i32 noundef 1, i64 noundef %746, ptr noundef %3) #25
  %781 = icmp eq i32 %780, 0
  br i1 %781, label %885, label %782

782:                                              ; preds = %777
  tail call void @free(ptr noundef nonnull %761) #26
  br label %885

783:                                              ; preds = %4
  %784 = add i32 %2, -3
  %785 = icmp ult i32 %784, -2
  br i1 %785, label %885, label %786

786:                                              ; preds = %783
  %787 = icmp eq i32 %2, 1
  %788 = icmp slt i64 %1, 0
  %789 = and i1 %788, %787
  %790 = icmp eq i32 %2, 2
  %791 = and i64 %1, 255
  %792 = sub i64 0, %1
  %793 = select i1 %789, i64 %792, i64 %1
  %794 = select i1 %790, i64 %791, i64 %793
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #27
  br label %795

795:                                              ; preds = %795, %786
  %796 = phi i64 [ %794, %786 ], [ %799, %795 ]
  %797 = phi i32 [ 20, %786 ], [ %804, %795 ]
  %798 = freeze i64 %796
  %799 = udiv i64 %798, 10
  %800 = mul i64 %799, 10
  %801 = sub i64 %798, %800
  %802 = trunc nuw nsw i64 %801 to i8
  %803 = or disjoint i8 %802, 48
  %804 = add i32 %797, -1
  %805 = zext i32 %804 to i64
  %806 = getelementptr inbounds nuw i8, ptr %8, i64 %805
  store i8 %803, ptr %806, align 1, !tbaa !39
  %807 = icmp ult i64 %796, 10
  br i1 %807, label %808, label %795, !llvm.loop !92

808:                                              ; preds = %795
  br i1 %789, label %809, label %813

809:                                              ; preds = %808
  %810 = add i32 %797, -2
  %811 = zext i32 %810 to i64
  %812 = getelementptr inbounds nuw i8, ptr %8, i64 %811
  store i8 45, ptr %812, align 1, !tbaa !39
  br label %813

813:                                              ; preds = %809, %808
  %814 = phi i64 [ %811, %809 ], [ %805, %808 ]
  %815 = phi i32 [ %810, %809 ], [ %804, %808 ]
  %816 = freeze i64 %814
  %817 = getelementptr inbounds nuw i8, ptr %8, i64 %816
  %818 = sub nsw i64 20, %816
  %819 = icmp ne ptr %0, null
  %820 = icmp ne ptr %3, null
  %821 = and i1 %819, %820
  br i1 %821, label %822, label %883

822:                                              ; preds = %813
  %823 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %824 = load i32, ptr %823, align 8, !tbaa !17
  %825 = icmp eq i32 %824, 0
  br i1 %825, label %826, label %883

826:                                              ; preds = %822
  %827 = icmp ugt i64 %818, 4294967295
  br i1 %827, label %883, label %828

828:                                              ; preds = %826
  %829 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %830 = load i64, ptr %829, align 8, !tbaa !31
  %831 = xor i64 %830, -1
  %832 = icmp ugt i64 %818, %831
  br i1 %832, label %883, label %833

833:                                              ; preds = %828
  %834 = sub nsw i64 21, %816
  %835 = tail call ptr @malloc(i64 noundef %834) #24
  %836 = icmp eq ptr %835, null
  br i1 %836, label %883, label %837

837:                                              ; preds = %833
  %838 = icmp eq i32 %815, 20
  br i1 %838, label %877, label %839

839:                                              ; preds = %837
  %840 = sub nsw i64 19, %816
  %841 = urem i64 %840, 3
  %842 = add nuw nsw i64 %841, 1
  %843 = icmp ne i64 %842, 3
  %844 = select i1 %843, i64 %842, i64 0
  %845 = icmp ult i64 %840, 2
  br i1 %845, label %866, label %846

846:                                              ; preds = %839
  %847 = sub nsw i64 %818, %844
  br label %848

848:                                              ; preds = %848, %846
  %849 = phi i64 [ 0, %846 ], [ %862, %848 ]
  %850 = phi i64 [ 0, %846 ], [ %863, %848 ]
  %851 = getelementptr inbounds nuw i8, ptr %817, i64 %849
  %852 = load volatile i8, ptr %851, align 1, !tbaa !39
  %853 = getelementptr inbounds nuw i8, ptr %835, i64 %849
  store volatile i8 %852, ptr %853, align 1, !tbaa !39
  %854 = add nuw nsw i64 %849, 1
  %855 = getelementptr inbounds nuw i8, ptr %817, i64 %854
  %856 = load volatile i8, ptr %855, align 1, !tbaa !39
  %857 = getelementptr inbounds nuw i8, ptr %835, i64 %854
  store volatile i8 %856, ptr %857, align 1, !tbaa !39
  %858 = add nuw nsw i64 %849, 2
  %859 = getelementptr inbounds nuw i8, ptr %817, i64 %858
  %860 = load volatile i8, ptr %859, align 1, !tbaa !39
  %861 = getelementptr inbounds nuw i8, ptr %835, i64 %858
  store volatile i8 %860, ptr %861, align 1, !tbaa !39
  %862 = add nuw nsw i64 %849, 3
  %863 = add i64 %850, 3
  %864 = icmp eq i64 %863, %847
  br i1 %864, label %865, label %848, !llvm.loop !40

865:                                              ; preds = %848
  br i1 %843, label %866, label %877

866:                                              ; preds = %865, %839
  %867 = phi i64 [ 0, %839 ], [ %862, %865 ]
  tail call void @llvm.assume(i1 %843)
  br label %868

868:                                              ; preds = %868, %866
  %869 = phi i64 [ %874, %868 ], [ %867, %866 ]
  %870 = phi i64 [ %875, %868 ], [ 0, %866 ]
  %871 = getelementptr inbounds nuw i8, ptr %817, i64 %869
  %872 = load volatile i8, ptr %871, align 1, !tbaa !39
  %873 = getelementptr inbounds nuw i8, ptr %835, i64 %869
  store volatile i8 %872, ptr %873, align 1, !tbaa !39
  %874 = add nuw nsw i64 %869, 1
  %875 = add i64 %870, 1
  %876 = icmp eq i64 %875, %844
  br i1 %876, label %877, label %868, !llvm.loop !93

877:                                              ; preds = %865, %868, %837
  %878 = getelementptr inbounds nuw i8, ptr %835, i64 %818
  store i8 0, ptr %878, align 1, !tbaa !39
  %879 = trunc nuw nsw i64 %818 to i32
  %880 = tail call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %835, i32 noundef %879, i32 noundef 0, i32 noundef 1, i64 noundef %818, ptr noundef %3) #25
  %881 = icmp eq i32 %880, 0
  br i1 %881, label %883, label %882

882:                                              ; preds = %877
  tail call void @free(ptr noundef nonnull %835) #26
  br label %883

883:                                              ; preds = %813, %822, %826, %828, %833, %877, %882
  %884 = phi i32 [ 3, %826 ], [ 6, %813 ], [ 5, %822 ], [ 0, %877 ], [ %880, %882 ], [ 3, %833 ], [ 3, %828 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #27
  br label %885

885:                                              ; preds = %782, %777, %759, %754, %750, %743, %742, %739, %736, %732, %728, %783, %883, %726
  %886 = phi i32 [ %727, %726 ], [ 1, %783 ], [ %740, %742 ], [ %884, %883 ], [ 0, %739 ], [ 6, %728 ], [ 5, %732 ], [ 3, %736 ], [ 3, %759 ], [ 6, %743 ], [ 5, %750 ], [ 0, %777 ], [ %780, %782 ], [ 3, %754 ]
  ret i32 %886
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_parse_f64(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #8 {
  %4 = alloca %struct.NbpBig, align 4
  %5 = alloca %struct.NbpBig, align 4
  %6 = alloca i64, align 8
  %7 = alloca %struct.NbpBig, align 4
  %8 = alloca %struct.NbpBig, align 4
  %9 = icmp eq ptr %0, null
  br i1 %9, label %563, label %10

10:                                               ; preds = %3
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !17
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %563

14:                                               ; preds = %10
  %15 = icmp sgt i64 %1, -1
  br i1 %15, label %42, label %16

16:                                               ; preds = %14
  %17 = and i64 %1, 9223372036854775807
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %563, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %21 = load i32, ptr %20, align 4, !tbaa !18
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %17, %22
  br i1 %23, label %563, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !19
  %27 = icmp eq ptr %26, null
  br i1 %27, label %563, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw [48 x i8], ptr %26, i64 %17
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !20
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %563, label %33

33:                                               ; preds = %28
  %34 = and i64 %1, 4294967295
  %35 = getelementptr inbounds nuw [48 x i8], ptr %26, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 28
  %37 = load i32, ptr %36, align 4, !tbaa !23
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %563

39:                                               ; preds = %33
  %40 = load ptr, ptr %35, align 8, !tbaa !24
  %41 = getelementptr inbounds nuw i8, ptr %35, i64 16
  br label %60

42:                                               ; preds = %14
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %563, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %46 = load i32, ptr %45, align 8, !tbaa !14
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %563, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %51 = load ptr, ptr %50, align 8, !tbaa !13
  %52 = icmp eq ptr %51, null
  br i1 %52, label %563, label %53

53:                                               ; preds = %49
  %54 = getelementptr [16 x i8], ptr %51, i64 %1
  %55 = getelementptr i8, ptr %54, i64 -16
  %56 = load ptr, ptr %55, align 8, !tbaa !25
  %57 = icmp eq ptr %56, null
  br i1 %57, label %563, label %58

58:                                               ; preds = %53
  %59 = getelementptr i8, ptr %54, i64 -8
  br label %60

60:                                               ; preds = %58, %39
  %61 = phi ptr [ %56, %58 ], [ %40, %39 ]
  %62 = phi ptr [ %59, %58 ], [ %41, %39 ]
  %63 = load i32, ptr %62, align 8, !tbaa !12
  %64 = icmp eq ptr %2, null
  br i1 %64, label %563, label %65

65:                                               ; preds = %60
  %66 = icmp eq ptr %61, null
  %67 = icmp ne i32 %63, 0
  %68 = and i1 %66, %67
  br i1 %68, label %563, label %69

69:                                               ; preds = %65
  %70 = icmp eq i32 %63, 0
  br i1 %70, label %87, label %71

71:                                               ; preds = %69
  %72 = zext i32 %63 to i64
  br label %73

73:                                               ; preds = %77, %71
  %74 = phi i64 [ 0, %71 ], [ %78, %77 ]
  %75 = getelementptr inbounds nuw i8, ptr %61, i64 %74
  %76 = load i8, ptr %75, align 1, !tbaa !39
  switch i8 %76, label %85 [
    i8 32, label %77
    i8 9, label %77
    i8 10, label %77
    i8 13, label %77
    i8 11, label %77
    i8 12, label %77
    i8 45, label %80
    i8 43, label %80
  ]

77:                                               ; preds = %73, %73, %73, %73, %73, %73
  %78 = add nuw nsw i64 %74, 1
  %79 = icmp eq i64 %78, %72
  br i1 %79, label %87, label %73, !llvm.loop !94

80:                                               ; preds = %73, %73
  %81 = trunc nuw i64 %74 to i32
  %82 = icmp eq i8 %76, 45
  %83 = select i1 %82, i64 -9223372036854775808, i64 0
  %84 = add nuw i32 %81, 1
  br label %87

85:                                               ; preds = %73
  %86 = trunc nuw i64 %74 to i32
  br label %87

87:                                               ; preds = %77, %85, %80, %69
  %88 = phi i64 [ %83, %80 ], [ 0, %69 ], [ 0, %85 ], [ 0, %77 ]
  %89 = phi i32 [ %84, %80 ], [ 0, %69 ], [ %86, %85 ], [ %63, %77 ]
  %90 = icmp ugt i32 %89, %63
  %91 = sub i32 %63, %89
  %92 = icmp ult i32 %91, 3
  %93 = or i1 %90, %92
  br i1 %93, label %257, label %94

94:                                               ; preds = %87
  %95 = zext i32 %89 to i64
  %96 = getelementptr inbounds nuw i8, ptr %61, i64 %95
  %97 = load i8, ptr %96, align 1, !tbaa !39
  %98 = add i8 %97, -65
  %99 = icmp ult i8 %98, 26
  %100 = add nuw nsw i8 %97, 32
  %101 = select i1 %99, i8 %100, i8 %97
  switch i8 %101, label %263 [
    i8 105, label %102
    i8 110, label %124
  ]

102:                                              ; preds = %94
  %103 = add i32 %89, 1
  %104 = zext i32 %103 to i64
  %105 = getelementptr inbounds nuw i8, ptr %61, i64 %104
  %106 = load i8, ptr %105, align 1, !tbaa !39
  %107 = add i8 %106, -65
  %108 = icmp ult i8 %107, 26
  %109 = add nuw nsw i8 %106, 32
  %110 = select i1 %108, i8 %109, i8 %106
  %111 = icmp eq i8 %110, 110
  br i1 %111, label %112, label %263

112:                                              ; preds = %102
  %113 = add i32 %89, 2
  %114 = zext i32 %113 to i64
  %115 = getelementptr inbounds nuw i8, ptr %61, i64 %114
  %116 = load i8, ptr %115, align 1, !tbaa !39
  %117 = add i8 %116, -65
  %118 = icmp ult i8 %117, 26
  %119 = add nuw nsw i8 %116, 32
  %120 = select i1 %118, i8 %119, i8 %116
  %121 = icmp eq i8 %120, 102
  br i1 %121, label %122, label %263

122:                                              ; preds = %112
  %123 = or disjoint i64 %88, 9218868437227405312
  br label %561

124:                                              ; preds = %94
  %125 = add i32 %89, 1
  %126 = zext i32 %125 to i64
  %127 = getelementptr inbounds nuw i8, ptr %61, i64 %126
  %128 = load i8, ptr %127, align 1, !tbaa !39
  %129 = add i8 %128, -65
  %130 = icmp ult i8 %129, 26
  %131 = add nuw nsw i8 %128, 32
  %132 = select i1 %130, i8 %131, i8 %128
  %133 = icmp eq i8 %132, 97
  br i1 %133, label %134, label %263

134:                                              ; preds = %124
  %135 = add i32 %89, 2
  %136 = zext i32 %135 to i64
  %137 = getelementptr inbounds nuw i8, ptr %61, i64 %136
  %138 = load i8, ptr %137, align 1, !tbaa !39
  %139 = add i8 %138, -65
  %140 = icmp ult i8 %139, 26
  %141 = add nuw nsw i8 %138, 32
  %142 = select i1 %140, i8 %141, i8 %138
  %143 = icmp eq i8 %142, 110
  br i1 %143, label %144, label %263

144:                                              ; preds = %134
  %145 = add i32 %89, 3
  %146 = icmp ult i32 %145, %63
  br i1 %146, label %147, label %254

147:                                              ; preds = %144
  %148 = zext i32 %145 to i64
  %149 = getelementptr inbounds nuw i8, ptr %61, i64 %148
  %150 = load i8, ptr %149, align 1, !tbaa !39
  %151 = icmp eq i8 %150, 40
  br i1 %151, label %152, label %254

152:                                              ; preds = %147
  %153 = add i32 %89, 4
  %154 = icmp ult i32 %153, %63
  br i1 %154, label %155, label %178

155:                                              ; preds = %152
  %156 = add nuw nsw i64 %148, 1
  br label %157

157:                                              ; preds = %172, %155
  %158 = phi i64 [ %156, %155 ], [ %173, %172 ]
  %159 = getelementptr inbounds nuw i8, ptr %61, i64 %158
  %160 = load i8, ptr %159, align 1, !tbaa !39
  %161 = add i8 %160, -65
  %162 = icmp ult i8 %161, 26
  %163 = add nuw nsw i8 %160, 32
  %164 = select i1 %162, i8 %163, i8 %160
  %165 = add i8 %164, -97
  %166 = icmp ult i8 %165, 26
  br i1 %166, label %172, label %167

167:                                              ; preds = %157
  %168 = add i8 %164, -48
  %169 = icmp ult i8 %168, 10
  %170 = icmp eq i8 %164, 95
  %171 = or i1 %170, %169
  br i1 %171, label %172, label %176

172:                                              ; preds = %167, %157
  %173 = add nuw nsw i64 %158, 1
  %174 = trunc i64 %173 to i32
  %175 = icmp eq i32 %63, %174
  br i1 %175, label %254, label %157

176:                                              ; preds = %167
  %177 = trunc nuw i64 %158 to i32
  br label %178

178:                                              ; preds = %176, %152
  %179 = phi i32 [ %153, %152 ], [ %177, %176 ]
  %180 = icmp eq i32 %179, %63
  br i1 %180, label %254, label %181

181:                                              ; preds = %178
  %182 = zext i32 %179 to i64
  %183 = getelementptr inbounds nuw i8, ptr %61, i64 %182
  %184 = load i8, ptr %183, align 1, !tbaa !39
  %185 = icmp eq i8 %184, 41
  br i1 %185, label %186, label %254

186:                                              ; preds = %181
  %187 = sub i32 %179, %153
  %188 = icmp ugt i32 %187, 1
  br i1 %188, label %189, label %207

189:                                              ; preds = %186
  %190 = zext i32 %153 to i64
  %191 = getelementptr inbounds nuw i8, ptr %61, i64 %190
  %192 = load i8, ptr %191, align 1, !tbaa !39
  %193 = icmp eq i8 %192, 48
  br i1 %193, label %194, label %207

194:                                              ; preds = %189
  %195 = add i32 %89, 5
  %196 = zext i32 %195 to i64
  %197 = getelementptr inbounds nuw i8, ptr %61, i64 %196
  %198 = load i8, ptr %197, align 1, !tbaa !39
  %199 = add i8 %198, -65
  %200 = icmp ult i8 %199, 26
  %201 = add nuw nsw i8 %198, 32
  %202 = select i1 %200, i8 %201, i8 %198
  %203 = icmp eq i8 %202, 120
  %204 = add i32 %89, 6
  %205 = select i1 %203, i32 %204, i32 %153
  %206 = select i1 %203, i32 16, i32 8
  br label %207

207:                                              ; preds = %194, %189, %186
  %208 = phi i32 [ %153, %189 ], [ %153, %186 ], [ %205, %194 ]
  %209 = phi i32 [ 10, %189 ], [ 10, %186 ], [ %206, %194 ]
  %210 = icmp ult i32 %208, %179
  br i1 %210, label %211, label %254

211:                                              ; preds = %207
  %212 = zext nneg i32 %209 to i64
  %213 = zext i32 %208 to i64
  br label %214

214:                                              ; preds = %239, %211
  %215 = phi i64 [ %213, %211 ], [ %247, %239 ]
  %216 = phi i64 [ 0, %211 ], [ %246, %239 ]
  %217 = getelementptr inbounds nuw i8, ptr %61, i64 %215
  %218 = load i8, ptr %217, align 1, !tbaa !39
  %219 = add i8 %218, -48
  %220 = icmp ult i8 %219, 10
  br i1 %220, label %221, label %224

221:                                              ; preds = %214
  %222 = zext nneg i8 %218 to i32
  %223 = add nsw i32 %222, -48
  br label %234

224:                                              ; preds = %214
  %225 = add i8 %218, -65
  %226 = icmp ult i8 %225, 26
  %227 = add nuw nsw i8 %218, 32
  %228 = select i1 %226, i8 %227, i8 %218
  %229 = zext nneg i8 %228 to i32
  %230 = add i8 %228, -97
  %231 = icmp ult i8 %230, 6
  %232 = add nsw i32 %229, -87
  %233 = select i1 %231, i32 %232, i32 -1
  br label %234

234:                                              ; preds = %224, %221
  %235 = phi i32 [ %223, %221 ], [ %233, %224 ]
  %236 = icmp sgt i32 %235, -1
  %237 = icmp ult i32 %235, %209
  %238 = and i1 %236, %237
  br i1 %238, label %239, label %250

239:                                              ; preds = %234
  %240 = zext nneg i32 %235 to i64
  %241 = xor i64 %240, -1
  %242 = udiv i64 %241, %212
  %243 = icmp ugt i64 %216, %242
  %244 = mul i64 %216, %212
  %245 = add i64 %244, %240
  %246 = select i1 %243, i64 -1, i64 %245
  %247 = add nuw nsw i64 %215, 1
  %248 = trunc i64 %247 to i32
  %249 = icmp eq i32 %179, %248
  br i1 %249, label %250, label %214, !llvm.loop !95

250:                                              ; preds = %239, %234
  %251 = phi i64 [ 0, %234 ], [ %246, %239 ]
  %252 = and i64 %251, 2251799813685247
  %253 = or disjoint i64 %252, %88
  br label %254

254:                                              ; preds = %172, %250, %207, %181, %178, %147, %144
  %255 = phi i64 [ %88, %144 ], [ %88, %147 ], [ %88, %178 ], [ %88, %181 ], [ %88, %207 ], [ %253, %250 ], [ %88, %172 ]
  %256 = or disjoint i64 %255, 9221120237041090560
  br label %561

257:                                              ; preds = %87
  %258 = icmp ugt i32 %91, 2
  br i1 %258, label %259, label %307

259:                                              ; preds = %257
  %260 = zext i32 %89 to i64
  %261 = getelementptr inbounds nuw i8, ptr %61, i64 %260
  %262 = load i8, ptr %261, align 1, !tbaa !39
  br label %263

263:                                              ; preds = %259, %134, %124, %112, %102, %94
  %264 = phi i8 [ %262, %259 ], [ %97, %134 ], [ %97, %124 ], [ %97, %112 ], [ %97, %102 ], [ %97, %94 ]
  %265 = icmp eq i8 %264, 48
  br i1 %265, label %266, label %307

266:                                              ; preds = %263
  %267 = add i32 %89, 1
  %268 = zext i32 %267 to i64
  %269 = getelementptr inbounds nuw i8, ptr %61, i64 %268
  %270 = load i8, ptr %269, align 1, !tbaa !39
  %271 = add i8 %270, -65
  %272 = icmp ult i8 %271, 26
  %273 = add nuw nsw i8 %270, 32
  %274 = select i1 %272, i8 %273, i8 %270
  %275 = icmp eq i8 %274, 120
  br i1 %275, label %276, label %307

276:                                              ; preds = %266
  %277 = add i32 %89, 2
  %278 = zext i32 %277 to i64
  %279 = getelementptr inbounds nuw i8, ptr %61, i64 %278
  %280 = load i8, ptr %279, align 1, !tbaa !39
  %281 = add i8 %280, -48
  %282 = icmp ult i8 %281, 10
  br i1 %282, label %306, label %283

283:                                              ; preds = %276
  %284 = add i8 %280, -65
  %285 = icmp ult i8 %284, 26
  %286 = select i1 %285, i8 -65, i8 -97
  %287 = add i8 %286, %280
  %288 = icmp ult i8 %287, 6
  br i1 %288, label %306, label %289

289:                                              ; preds = %283
  %290 = icmp ne i32 %91, 3
  %291 = icmp eq i8 %280, 46
  %292 = and i1 %290, %291
  br i1 %292, label %293, label %307

293:                                              ; preds = %289
  %294 = add i32 %89, 3
  %295 = zext i32 %294 to i64
  %296 = getelementptr inbounds nuw i8, ptr %61, i64 %295
  %297 = load i8, ptr %296, align 1, !tbaa !39
  %298 = add i8 %297, -48
  %299 = icmp ult i8 %298, 10
  br i1 %299, label %306, label %300

300:                                              ; preds = %293
  %301 = add i8 %297, -65
  %302 = icmp ult i8 %301, 26
  %303 = select i1 %302, i8 -65, i8 -97
  %304 = add i8 %303, %297
  %305 = icmp ult i8 %304, 6
  br i1 %305, label %306, label %307

306:                                              ; preds = %300, %293, %283, %276
  br label %307

307:                                              ; preds = %306, %300, %289, %266, %263, %257
  %308 = phi i32 [ 32, %306 ], [ 800, %257 ], [ 800, %300 ], [ 800, %289 ], [ 800, %266 ], [ 800, %263 ]
  %309 = phi i32 [ 112, %306 ], [ 101, %257 ], [ 101, %300 ], [ 101, %289 ], [ 101, %266 ], [ 101, %263 ]
  %310 = phi i1 [ true, %306 ], [ false, %257 ], [ false, %300 ], [ false, %289 ], [ false, %266 ], [ false, %263 ]
  %311 = phi i32 [ 16, %306 ], [ 10, %257 ], [ 10, %300 ], [ 10, %289 ], [ 10, %266 ], [ 10, %263 ]
  %312 = phi i32 [ %277, %306 ], [ %89, %257 ], [ %89, %300 ], [ %89, %289 ], [ %89, %266 ], [ %89, %263 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %4, i8 0, i64 516, i1 false)
  %313 = icmp ult i32 %312, %63
  br i1 %313, label %314, label %555

314:                                              ; preds = %307
  %315 = getelementptr inbounds nuw i8, ptr %4, i64 512
  %316 = zext nneg i32 %311 to i64
  %317 = zext i32 %312 to i64
  br label %318

318:                                              ; preds = %399, %314
  %319 = phi i64 [ %317, %314 ], [ %407, %399 ]
  %320 = phi i64 [ 0, %314 ], [ %406, %399 ]
  %321 = phi i64 [ 0, %314 ], [ %405, %399 ]
  %322 = phi i32 [ 0, %314 ], [ %404, %399 ]
  %323 = phi i32 [ 0, %314 ], [ %403, %399 ]
  %324 = phi i32 [ 0, %314 ], [ %402, %399 ]
  %325 = phi i32 [ 0, %314 ], [ %401, %399 ]
  %326 = phi i32 [ 0, %314 ], [ %400, %399 ]
  %327 = getelementptr inbounds nuw i8, ptr %61, i64 %319
  %328 = load i8, ptr %327, align 1, !tbaa !39
  %329 = add i8 %328, -48
  %330 = icmp ult i8 %329, 10
  br i1 %330, label %331, label %334

331:                                              ; preds = %318
  %332 = zext nneg i8 %328 to i32
  %333 = add nsw i32 %332, -48
  br label %344

334:                                              ; preds = %318
  %335 = add i8 %328, -65
  %336 = icmp ult i8 %335, 26
  %337 = add nuw nsw i8 %328, 32
  %338 = select i1 %336, i8 %337, i8 %328
  %339 = zext nneg i8 %338 to i32
  %340 = add i8 %338, -97
  %341 = icmp ult i8 %340, 6
  %342 = add nsw i32 %339, -87
  %343 = select i1 %341, i32 %342, i32 -1
  br label %344

344:                                              ; preds = %334, %331
  %345 = phi i32 [ %333, %331 ], [ %343, %334 ]
  %346 = icmp sgt i32 %345, -1
  %347 = icmp ult i32 %345, %311
  %348 = and i1 %346, %347
  br i1 %348, label %349, label %395

349:                                              ; preds = %344
  %350 = zext nneg i32 %325 to i64
  %351 = add nsw i64 %321, %350
  %352 = icmp ne i32 %345, 0
  %353 = icmp ne i32 %323, 0
  %354 = select i1 %352, i1 true, i1 %353
  br i1 %354, label %355, label %399, !llvm.loop !96

355:                                              ; preds = %349
  %356 = icmp ult i32 %326, %308
  br i1 %356, label %357, label %391

357:                                              ; preds = %355
  %358 = zext nneg i32 %345 to i64
  %359 = load i32, ptr %315, align 4, !tbaa !97
  %360 = icmp eq i32 %359, 0
  br i1 %360, label %363, label %365

361:                                              ; preds = %365
  %362 = icmp eq i64 %374, 0
  br i1 %362, label %389, label %379

363:                                              ; preds = %357
  %364 = icmp eq i32 %345, 0
  br i1 %364, label %389, label %382

365:                                              ; preds = %357, %365
  %366 = phi i64 [ %375, %365 ], [ 0, %357 ]
  %367 = phi i64 [ %374, %365 ], [ %358, %357 ]
  %368 = getelementptr inbounds nuw [4 x i8], ptr %4, i64 %366
  %369 = load i32, ptr %368, align 4, !tbaa !12
  %370 = zext i32 %369 to i64
  %371 = mul nuw nsw i64 %370, %316
  %372 = add nuw nsw i64 %371, %367
  %373 = trunc i64 %372 to i32
  store i32 %373, ptr %368, align 4, !tbaa !12
  %374 = lshr i64 %372, 32
  %375 = add nuw nsw i64 %366, 1
  %376 = load i32, ptr %315, align 4, !tbaa !97
  %377 = zext i32 %376 to i64
  %378 = icmp samesign ult i64 %375, %377
  br i1 %378, label %365, label %361, !llvm.loop !99

379:                                              ; preds = %361
  %380 = icmp eq i32 %376, 128
  br i1 %380, label %381, label %382

381:                                              ; preds = %379
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  br label %563

382:                                              ; preds = %363, %379
  %383 = phi i64 [ %374, %379 ], [ %358, %363 ]
  %384 = phi i32 [ %376, %379 ], [ 0, %363 ]
  %385 = trunc nuw nsw i64 %383 to i32
  %386 = add i32 %384, 1
  store i32 %386, ptr %315, align 4, !tbaa !97
  %387 = zext i32 %384 to i64
  %388 = getelementptr inbounds nuw [4 x i8], ptr %4, i64 %387
  store i32 %385, ptr %388, align 4, !tbaa !12
  br label %389

389:                                              ; preds = %382, %363, %361
  %390 = add nuw nsw i32 %326, 1
  br label %399, !llvm.loop !96

391:                                              ; preds = %355
  %392 = add nsw i64 %320, 1
  %393 = zext i1 %352 to i32
  %394 = or i32 %322, %393
  br label %399, !llvm.loop !96

395:                                              ; preds = %344
  %396 = icmp ne i8 %328, 46
  %397 = icmp ne i32 %325, 0
  %398 = select i1 %396, i1 true, i1 %397
  br i1 %398, label %410, label %399, !llvm.loop !96

399:                                              ; preds = %395, %391, %389, %349
  %400 = phi i32 [ %326, %349 ], [ %390, %389 ], [ %326, %391 ], [ %326, %395 ]
  %401 = phi i32 [ %325, %349 ], [ %325, %389 ], [ %325, %391 ], [ 1, %395 ]
  %402 = phi i32 [ 1, %349 ], [ 1, %389 ], [ 1, %391 ], [ %324, %395 ]
  %403 = phi i32 [ 0, %349 ], [ 1, %389 ], [ 1, %391 ], [ %323, %395 ]
  %404 = phi i32 [ %322, %349 ], [ %322, %389 ], [ %394, %391 ], [ %322, %395 ]
  %405 = phi i64 [ %351, %349 ], [ %351, %389 ], [ %351, %391 ], [ %321, %395 ]
  %406 = phi i64 [ %320, %349 ], [ %320, %389 ], [ %392, %391 ], [ %320, %395 ]
  %407 = add nuw nsw i64 %319, 1
  %408 = trunc i64 %407 to i32
  %409 = icmp eq i32 %63, %408
  br i1 %409, label %412, label %318

410:                                              ; preds = %395
  %411 = trunc nuw i64 %319 to i32
  br label %412, !llvm.loop !96

412:                                              ; preds = %399, %410
  %413 = phi i32 [ %326, %410 ], [ %400, %399 ]
  %414 = phi i32 [ %324, %410 ], [ %402, %399 ]
  %415 = phi i32 [ %323, %410 ], [ %403, %399 ]
  %416 = phi i32 [ %322, %410 ], [ %404, %399 ]
  %417 = phi i64 [ %321, %410 ], [ %405, %399 ]
  %418 = phi i64 [ %320, %410 ], [ %406, %399 ]
  %419 = phi i32 [ %411, %410 ], [ %63, %399 ]
  %420 = icmp eq i32 %414, 0
  br i1 %420, label %555, label %421

421:                                              ; preds = %412
  %422 = icmp ult i32 %419, %63
  br i1 %422, label %423, label %477

423:                                              ; preds = %421
  %424 = zext i32 %419 to i64
  %425 = getelementptr inbounds nuw i8, ptr %61, i64 %424
  %426 = load i8, ptr %425, align 1, !tbaa !39
  %427 = add i8 %426, -65
  %428 = icmp ult i8 %427, 26
  %429 = add nuw nsw i8 %426, 32
  %430 = select i1 %428, i8 %429, i8 %426
  %431 = zext i8 %430 to i32
  %432 = icmp eq i32 %309, %431
  br i1 %432, label %433, label %477

433:                                              ; preds = %423
  %434 = add nuw i32 %419, 1
  %435 = icmp ult i32 %434, %63
  br i1 %435, label %436, label %443

436:                                              ; preds = %433
  %437 = zext i32 %434 to i64
  %438 = getelementptr inbounds nuw i8, ptr %61, i64 %437
  %439 = load i8, ptr %438, align 1, !tbaa !39
  switch i8 %439, label %443 [
    i8 43, label %440
    i8 45, label %440
  ]

440:                                              ; preds = %436, %436
  %441 = icmp ne i8 %439, 45
  %442 = add nuw i32 %419, 2
  br label %443

443:                                              ; preds = %440, %436, %433
  %444 = phi i32 [ %442, %440 ], [ %434, %436 ], [ %434, %433 ]
  %445 = phi i1 [ %441, %440 ], [ true, %436 ], [ true, %433 ]
  %446 = icmp ult i32 %444, %63
  br i1 %446, label %447, label %477

447:                                              ; preds = %443
  %448 = zext i32 %444 to i64
  %449 = getelementptr inbounds nuw i8, ptr %61, i64 %448
  %450 = load i8, ptr %449, align 1, !tbaa !39
  %451 = add i8 %450, -48
  %452 = icmp ult i8 %451, 10
  br i1 %452, label %453, label %477

453:                                              ; preds = %447, %468
  %454 = phi i64 [ %470, %468 ], [ %448, %447 ]
  %455 = phi i64 [ %469, %468 ], [ 0, %447 ]
  %456 = getelementptr inbounds nuw i8, ptr %61, i64 %454
  %457 = load i8, ptr %456, align 1, !tbaa !39
  %458 = add i8 %457, -48
  %459 = icmp ult i8 %458, 10
  br i1 %459, label %460, label %473

460:                                              ; preds = %453
  %461 = icmp slt i64 %455, 1099511627776
  br i1 %461, label %462, label %468

462:                                              ; preds = %460
  %463 = mul nsw i64 %455, 10
  %464 = and i8 %457, 15
  %465 = zext nneg i8 %464 to i64
  %466 = add nsw i64 %463, %465
  %467 = tail call i64 @llvm.smin.i64(i64 %466, i64 1099511627776)
  br label %468

468:                                              ; preds = %462, %460
  %469 = phi i64 [ %467, %462 ], [ %455, %460 ]
  %470 = add nuw nsw i64 %454, 1
  %471 = trunc i64 %470 to i32
  %472 = icmp eq i32 %63, %471
  br i1 %472, label %473, label %453, !llvm.loop !100

473:                                              ; preds = %468, %453
  %474 = phi i64 [ %469, %468 ], [ %455, %453 ]
  %475 = sub nsw i64 0, %474
  %476 = select i1 %445, i64 %474, i64 %475
  br label %477

477:                                              ; preds = %473, %447, %443, %423, %421
  %478 = phi i64 [ 0, %421 ], [ 0, %423 ], [ %476, %473 ], [ 0, %443 ], [ 0, %447 ]
  %479 = icmp eq i32 %415, 0
  br i1 %479, label %555, label %480

480:                                              ; preds = %477
  %481 = sub nsw i64 %418, %417
  %482 = select i1 %310, i64 2, i64 0
  %483 = shl i64 %481, %482
  %484 = add i64 %478, %483
  br i1 %310, label %485, label %496

485:                                              ; preds = %480
  %486 = load i32, ptr %315, align 4, !tbaa !97
  %487 = icmp eq i32 %486, 0
  br i1 %487, label %496, label %488

488:                                              ; preds = %485
  %489 = add i32 %486, -1
  %490 = zext i32 %489 to i64
  %491 = getelementptr inbounds nuw [4 x i8], ptr %4, i64 %490
  %492 = load i32, ptr %491, align 4, !tbaa !12
  %493 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %492, i1 false)
  %494 = shl i32 %486, 5
  %495 = sub i32 %494, %493
  br label %496

496:                                              ; preds = %488, %485, %480
  %497 = phi i64 [ 308, %480 ], [ 1023, %485 ], [ 1023, %488 ]
  %498 = phi i32 [ %413, %480 ], [ 0, %485 ], [ %495, %488 ]
  %499 = zext i32 %498 to i64
  %500 = add i64 %484, -1
  %501 = add i64 %500, %499
  %502 = icmp sgt i64 %501, %497
  br i1 %502, label %503, label %505

503:                                              ; preds = %496
  %504 = or disjoint i64 %88, 9218868437227405312
  br label %555

505:                                              ; preds = %496
  %506 = select i1 %310, i64 -1075, i64 -324
  %507 = icmp slt i64 %501, %506
  br i1 %507, label %555, label %508

508:                                              ; preds = %505
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  %509 = getelementptr inbounds nuw i8, ptr %5, i64 4
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(508) %509, i8 0, i64 508, i1 false)
  %510 = getelementptr inbounds nuw i8, ptr %5, i64 512
  store i32 1, ptr %510, align 4, !tbaa !97
  store i32 1, ptr %5, align 4, !tbaa !12
  %511 = icmp slt i64 %484, 0
  %512 = select i1 %511, ptr %5, ptr %4
  %513 = tail call i64 @llvm.abs.i64(i64 %484, i1 false)
  %514 = trunc i64 %513 to i32
  br i1 %310, label %519, label %515

515:                                              ; preds = %508
  %516 = icmp eq i32 %514, 0
  br i1 %516, label %551, label %517

517:                                              ; preds = %515
  %518 = select i1 %511, ptr %510, ptr %315
  br label %522

519:                                              ; preds = %508
  %520 = call fastcc i32 @nbp_shift(ptr noundef %512, i32 noundef %514) #25
  %521 = icmp eq i32 %520, 0
  br i1 %521, label %557, label %551

522:                                              ; preds = %548, %517
  %523 = phi i32 [ 0, %517 ], [ %549, %548 ]
  %524 = load i32, ptr %518, align 4, !tbaa !97
  %525 = icmp eq i32 %524, 0
  br i1 %525, label %548, label %528

526:                                              ; preds = %528
  %527 = icmp eq i64 %537, 0
  br i1 %527, label %548, label %542

528:                                              ; preds = %522, %528
  %529 = phi i64 [ %538, %528 ], [ 0, %522 ]
  %530 = phi i64 [ %537, %528 ], [ 0, %522 ]
  %531 = getelementptr inbounds nuw [4 x i8], ptr %512, i64 %529
  %532 = load i32, ptr %531, align 4, !tbaa !12
  %533 = zext i32 %532 to i64
  %534 = mul nuw nsw i64 %533, 10
  %535 = add nuw nsw i64 %534, %530
  %536 = trunc i64 %535 to i32
  store i32 %536, ptr %531, align 4, !tbaa !12
  %537 = lshr i64 %535, 32
  %538 = add nuw nsw i64 %529, 1
  %539 = load i32, ptr %518, align 4, !tbaa !97
  %540 = zext i32 %539 to i64
  %541 = icmp samesign ult i64 %538, %540
  br i1 %541, label %528, label %526, !llvm.loop !99

542:                                              ; preds = %526
  %543 = icmp eq i32 %539, 128
  br i1 %543, label %557, label %544

544:                                              ; preds = %542
  %545 = trunc nuw nsw i64 %537 to i32
  %546 = add i32 %539, 1
  store i32 %546, ptr %518, align 4, !tbaa !97
  %547 = getelementptr inbounds nuw [4 x i8], ptr %512, i64 %540
  store i32 %545, ptr %547, align 4, !tbaa !12
  br label %548

548:                                              ; preds = %544, %526, %522
  %549 = add nuw i32 %523, 1
  %550 = icmp eq i32 %549, %514
  br i1 %550, label %551, label %522, !llvm.loop !101

551:                                              ; preds = %548, %519, %515
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #27
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %7, ptr noundef nonnull align 4 dereferenceable(516) %4, i64 516, i1 false), !tbaa.struct !102
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #27
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %8, ptr noundef nonnull align 4 dereferenceable(516) %5, i64 516, i1 false), !tbaa.struct !102
  %552 = call fastcc i32 @nbp_rational(ptr noundef align 4 dead_on_return %7, ptr noundef align 4 dead_on_return %8, i32 noundef %416, ptr noundef %6) #25
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #27
  %553 = icmp eq i32 %552, 0
  br i1 %553, label %554, label %558

554:                                              ; preds = %551
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  br label %563

555:                                              ; preds = %505, %503, %477, %412, %307
  %556 = phi i64 [ %88, %505 ], [ 0, %412 ], [ %88, %477 ], [ %504, %503 ], [ 0, %307 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  br label %561

557:                                              ; preds = %542, %519
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  br label %563

558:                                              ; preds = %551
  %559 = load i64, ptr %6, align 8, !tbaa !16
  %560 = or i64 %559, %88
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  br label %561

561:                                              ; preds = %122, %254, %555, %558
  %562 = phi i64 [ %556, %555 ], [ %560, %558 ], [ %123, %122 ], [ %256, %254 ]
  store i64 %562, ptr %2, align 8, !tbaa !16
  br label %563

563:                                              ; preds = %19, %16, %33, %24, %44, %49, %42, %10, %28, %53, %3, %561, %60, %65, %554, %381, %557
  %564 = phi i32 [ 6, %557 ], [ 0, %561 ], [ 6, %60 ], [ 6, %65 ], [ 6, %554 ], [ 6, %381 ], [ 6, %19 ], [ 6, %16 ], [ 1, %33 ], [ 6, %24 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %10 ], [ 6, %28 ], [ 6, %53 ], [ 6, %3 ]
  ret i32 %564
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_parse_i64(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #10 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %115, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %7 = load i32, ptr %6, align 8, !tbaa !17
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %115

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %37, label %11

11:                                               ; preds = %9
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %115, label %14

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %16 = load i32, ptr %15, align 4, !tbaa !18
  %17 = zext i32 %16 to i64
  %18 = icmp samesign ugt i64 %12, %17
  br i1 %18, label %115, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !19
  %22 = icmp eq ptr %21, null
  br i1 %22, label %115, label %23

23:                                               ; preds = %19
  %24 = getelementptr inbounds nuw [48 x i8], ptr %21, i64 %12
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %26 = load i64, ptr %25, align 8, !tbaa !20
  %27 = icmp eq i64 %26, 0
  br i1 %27, label %115, label %28

28:                                               ; preds = %23
  %29 = and i64 %1, 4294967295
  %30 = getelementptr inbounds nuw [48 x i8], ptr %21, i64 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 28
  %32 = load i32, ptr %31, align 4, !tbaa !23
  %33 = icmp eq i32 %32, 1
  br i1 %33, label %34, label %115

34:                                               ; preds = %28
  %35 = load ptr, ptr %30, align 8, !tbaa !24
  %36 = getelementptr inbounds nuw i8, ptr %30, i64 16
  br label %55

37:                                               ; preds = %9
  %38 = icmp eq i64 %1, 0
  br i1 %38, label %115, label %39

39:                                               ; preds = %37
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %41 = load i32, ptr %40, align 8, !tbaa !14
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %1, %42
  br i1 %43, label %115, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %46 = load ptr, ptr %45, align 8, !tbaa !13
  %47 = icmp eq ptr %46, null
  br i1 %47, label %115, label %48

48:                                               ; preds = %44
  %49 = getelementptr [16 x i8], ptr %46, i64 %1
  %50 = getelementptr i8, ptr %49, i64 -16
  %51 = load ptr, ptr %50, align 8, !tbaa !25
  %52 = icmp eq ptr %51, null
  br i1 %52, label %115, label %53

53:                                               ; preds = %48
  %54 = getelementptr i8, ptr %49, i64 -8
  br label %55

55:                                               ; preds = %53, %34
  %56 = phi ptr [ %51, %53 ], [ %35, %34 ]
  %57 = phi ptr [ %54, %53 ], [ %36, %34 ]
  %58 = load i32, ptr %57, align 8, !tbaa !12
  %59 = icmp eq ptr %2, null
  br i1 %59, label %115, label %60

60:                                               ; preds = %55
  %61 = icmp eq i32 %58, 0
  br i1 %61, label %73, label %62

62:                                               ; preds = %60
  %63 = zext i32 %58 to i64
  br label %64

64:                                               ; preds = %62, %68
  %65 = phi i64 [ 0, %62 ], [ %69, %68 ]
  %66 = getelementptr inbounds nuw i8, ptr %56, i64 %65
  %67 = load i8, ptr %66, align 1, !tbaa !39
  switch i8 %67, label %71 [
    i8 32, label %68
    i8 13, label %68
    i8 12, label %68
    i8 11, label %68
    i8 10, label %68
    i8 9, label %68
  ]

68:                                               ; preds = %64, %64, %64, %64, %64, %64
  %69 = add nuw nsw i64 %65, 1
  %70 = icmp eq i64 %69, %63
  br i1 %70, label %84, label %64

71:                                               ; preds = %64
  %72 = trunc nuw i64 %65 to i32
  br label %73

73:                                               ; preds = %71, %60
  %74 = phi i32 [ 0, %60 ], [ %72, %71 ]
  %75 = icmp ult i32 %74, %58
  br i1 %75, label %76, label %84

76:                                               ; preds = %73
  %77 = zext i32 %74 to i64
  %78 = getelementptr inbounds nuw i8, ptr %56, i64 %77
  %79 = load i8, ptr %78, align 1, !tbaa !39
  switch i8 %79, label %84 [
    i8 45, label %80
    i8 43, label %80
  ]

80:                                               ; preds = %76, %76
  %81 = icmp ne i8 %79, 45
  %82 = add nuw i32 %74, 1
  %83 = select i1 %81, i64 9223372036854775807, i64 -9223372036854775808
  br label %84

84:                                               ; preds = %68, %80, %73, %76
  %85 = phi i32 [ %82, %80 ], [ %74, %73 ], [ %74, %76 ], [ %58, %68 ]
  %86 = phi i1 [ %81, %80 ], [ true, %73 ], [ true, %76 ], [ true, %68 ]
  %87 = phi i64 [ %83, %80 ], [ 9223372036854775807, %73 ], [ 9223372036854775807, %76 ], [ 9223372036854775807, %68 ]
  %88 = tail call i32 @llvm.umax.i32(i32 %85, i32 %58)
  %89 = zext i32 %88 to i64
  %90 = icmp ult i32 %85, %58
  br i1 %90, label %91, label %111

91:                                               ; preds = %84
  %92 = zext i32 %85 to i64
  br label %98

93:                                               ; preds = %105
  %94 = mul nuw nsw i64 %99, 10
  %95 = add nuw i64 %94, %107
  %96 = add nuw nsw i64 %100, 1
  %97 = icmp eq i64 %96, %89
  br i1 %97, label %111, label %98

98:                                               ; preds = %91, %93
  %99 = phi i64 [ 0, %91 ], [ %95, %93 ]
  %100 = phi i64 [ %92, %91 ], [ %96, %93 ]
  %101 = getelementptr inbounds nuw i8, ptr %56, i64 %100
  %102 = load i8, ptr %101, align 1, !tbaa !39
  %103 = add i8 %102, -58
  %104 = icmp ult i8 %103, -10
  br i1 %104, label %111, label %105

105:                                              ; preds = %98
  %106 = and i8 %102, 15
  %107 = zext nneg i8 %106 to i64
  %108 = sub nuw i64 %87, %107
  %109 = udiv i64 %108, 10
  %110 = icmp ugt i64 %99, %109
  br i1 %110, label %111, label %93

111:                                              ; preds = %93, %98, %105, %84
  %112 = phi i64 [ 0, %84 ], [ %95, %93 ], [ %87, %105 ], [ %99, %98 ]
  %113 = sub i64 0, %112
  %114 = select i1 %86, i64 %112, i64 %113
  store i64 %114, ptr %2, align 8, !tbaa !16
  br label %115

115:                                              ; preds = %14, %11, %28, %19, %39, %44, %37, %5, %23, %48, %3, %55, %111
  %116 = phi i32 [ 6, %55 ], [ 0, %111 ], [ 6, %14 ], [ 6, %11 ], [ 1, %28 ], [ 6, %19 ], [ 6, %39 ], [ 6, %44 ], [ 6, %37 ], [ 5, %5 ], [ 6, %23 ], [ 6, %48 ], [ 6, %3 ]
  ret i32 %116
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_case_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  store i64 0, ptr %5, align 8, !tbaa !16
  %6 = icmp ne ptr %3, null
  %7 = icmp ult i32 %2, 2
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %94

11:                                               ; preds = %4
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %13 = load i32, ptr %12, align 8, !tbaa !17
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %94

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %43, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %94, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %22 = load i32, ptr %21, align 4, !tbaa !18
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %94, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %27 = load ptr, ptr %26, align 8, !tbaa !19
  %28 = icmp eq ptr %27, null
  br i1 %28, label %94, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw [48 x i8], ptr %27, i64 %18
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load i64, ptr %31, align 8, !tbaa !20
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %94, label %34

34:                                               ; preds = %29
  %35 = and i64 %1, 4294967295
  %36 = getelementptr inbounds nuw [48 x i8], ptr %27, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 28
  %38 = load i32, ptr %37, align 4, !tbaa !23
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %40, label %94

40:                                               ; preds = %34
  %41 = load ptr, ptr %36, align 8, !tbaa !24
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 16
  br label %61

43:                                               ; preds = %15
  %44 = icmp eq i64 %1, 0
  br i1 %44, label %94, label %45

45:                                               ; preds = %43
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %47 = load i32, ptr %46, align 8, !tbaa !14
  %48 = zext i32 %47 to i64
  %49 = icmp samesign ugt i64 %1, %48
  br i1 %49, label %94, label %50

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !13
  %53 = icmp eq ptr %52, null
  br i1 %53, label %94, label %54

54:                                               ; preds = %50
  %55 = getelementptr [16 x i8], ptr %52, i64 %1
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load ptr, ptr %56, align 8, !tbaa !25
  %58 = icmp eq ptr %57, null
  br i1 %58, label %94, label %59

59:                                               ; preds = %54
  %60 = getelementptr i8, ptr %55, i64 -8
  br label %61

61:                                               ; preds = %40, %59
  %62 = phi ptr [ %57, %59 ], [ %41, %40 ]
  %63 = phi ptr [ %60, %59 ], [ %42, %40 ]
  %64 = load i32, ptr %63, align 8, !tbaa !12
  %65 = zext i32 %64 to i64
  %66 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %62, i64 noundef %65, ptr noundef null, i64 noundef 0, ptr noundef nonnull %5) #25
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %68, label %94

68:                                               ; preds = %61
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %70 = load ptr, ptr %69, align 8, !tbaa !19
  %71 = load i64, ptr %5, align 8, !tbaa !16
  %72 = and i64 %71, 4294967295
  %73 = getelementptr inbounds nuw [48 x i8], ptr %70, i64 %72
  %74 = getelementptr inbounds nuw i8, ptr %73, i64 16
  %75 = load i32, ptr %74, align 8, !tbaa !34
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %97, label %77

77:                                               ; preds = %68
  %78 = icmp eq i32 %2, 0
  %79 = select i1 %78, i8 -65, i8 -97
  %80 = select i1 %78, i8 32, i8 -32
  br label %81

81:                                               ; preds = %77, %81
  %82 = phi i64 [ 0, %77 ], [ %90, %81 ]
  %83 = load ptr, ptr %73, align 8, !tbaa !24
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 %82
  %85 = load i8, ptr %84, align 1, !tbaa !39
  %86 = add i8 %85, %79
  %87 = icmp ult i8 %86, 26
  %88 = select i1 %87, i8 %80, i8 0
  %89 = add i8 %85, %88
  store i8 %89, ptr %84, align 1, !tbaa !39
  %90 = add nuw nsw i64 %82, 1
  %91 = load i32, ptr %74, align 8, !tbaa !34
  %92 = zext i32 %91 to i64
  %93 = icmp samesign ult i64 %90, %92
  br i1 %93, label %81, label %97, !llvm.loop !103

94:                                               ; preds = %61, %20, %17, %34, %25, %45, %50, %43, %11, %29, %54, %4
  %95 = phi i32 [ %66, %61 ], [ 6, %20 ], [ 6, %17 ], [ 1, %34 ], [ 6, %25 ], [ 6, %45 ], [ 6, %50 ], [ 6, %43 ], [ 5, %11 ], [ 6, %29 ], [ 6, %54 ], [ 6, %4 ]
  %96 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #25
  br label %103

97:                                               ; preds = %81, %68
  %98 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %1) #25
  %99 = icmp eq i32 %98, 0
  br i1 %99, label %102, label %100

100:                                              ; preds = %97
  %101 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %71) #25
  br label %103

102:                                              ; preds = %97
  store i64 %71, ptr %3, align 8, !tbaa !16
  br label %103

103:                                              ; preds = %94, %102, %100
  %104 = phi i32 [ 0, %102 ], [ %98, %100 ], [ %95, %94 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  ret i32 %104
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_trim_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #3 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %55, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %7 = load i32, ptr %6, align 8, !tbaa !17
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %55

9:                                                ; preds = %5
  %10 = icmp sgt i64 %1, -1
  br i1 %10, label %37, label %11

11:                                               ; preds = %9
  %12 = and i64 %1, 9223372036854775807
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %55, label %14

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %16 = load i32, ptr %15, align 4, !tbaa !18
  %17 = zext i32 %16 to i64
  %18 = icmp samesign ugt i64 %12, %17
  br i1 %18, label %55, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !19
  %22 = icmp eq ptr %21, null
  br i1 %22, label %55, label %23

23:                                               ; preds = %19
  %24 = getelementptr inbounds nuw [48 x i8], ptr %21, i64 %12
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %26 = load i64, ptr %25, align 8, !tbaa !20
  %27 = icmp eq i64 %26, 0
  br i1 %27, label %55, label %28

28:                                               ; preds = %23
  %29 = and i64 %1, 4294967295
  %30 = getelementptr inbounds nuw [48 x i8], ptr %21, i64 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 28
  %32 = load i32, ptr %31, align 4, !tbaa !23
  %33 = icmp eq i32 %32, 1
  br i1 %33, label %34, label %55

34:                                               ; preds = %28
  %35 = load ptr, ptr %30, align 8, !tbaa !24
  %36 = getelementptr inbounds nuw i8, ptr %30, i64 16
  br label %58

37:                                               ; preds = %9
  %38 = icmp eq i64 %1, 0
  br i1 %38, label %55, label %39

39:                                               ; preds = %37
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %41 = load i32, ptr %40, align 8, !tbaa !14
  %42 = zext i32 %41 to i64
  %43 = icmp samesign ugt i64 %1, %42
  br i1 %43, label %55, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %46 = load ptr, ptr %45, align 8, !tbaa !13
  %47 = icmp eq ptr %46, null
  br i1 %47, label %55, label %48

48:                                               ; preds = %44
  %49 = getelementptr [16 x i8], ptr %46, i64 %1
  %50 = getelementptr i8, ptr %49, i64 -16
  %51 = load ptr, ptr %50, align 8, !tbaa !25
  %52 = icmp eq ptr %51, null
  br i1 %52, label %55, label %53

53:                                               ; preds = %48
  %54 = getelementptr i8, ptr %49, i64 -8
  br label %58

55:                                               ; preds = %3, %48, %23, %5, %37, %44, %39, %19, %28, %11, %14
  %56 = phi i32 [ 6, %14 ], [ 6, %11 ], [ 1, %28 ], [ 6, %19 ], [ 6, %39 ], [ 6, %44 ], [ 6, %37 ], [ 5, %5 ], [ 6, %23 ], [ 6, %48 ], [ 6, %3 ]
  %57 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %1) #25
  br label %93

58:                                               ; preds = %53, %34
  %59 = phi ptr [ %51, %53 ], [ %35, %34 ]
  %60 = phi ptr [ %54, %53 ], [ %36, %34 ]
  %61 = load i32, ptr %60, align 8, !tbaa !12
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %88, label %63

63:                                               ; preds = %58
  %64 = zext i32 %61 to i64
  br label %65

65:                                               ; preds = %63, %69
  %66 = phi i64 [ 0, %63 ], [ %70, %69 ]
  %67 = getelementptr inbounds nuw i8, ptr %59, i64 %66
  %68 = load i8, ptr %67, align 1, !tbaa !39
  switch i8 %68, label %72 [
    i8 32, label %69
    i8 10, label %69
    i8 9, label %69
    i8 13, label %69
  ]

69:                                               ; preds = %65, %65, %65, %65
  %70 = add nuw nsw i64 %66, 1
  %71 = icmp eq i64 %70, %64
  br i1 %71, label %88, label %65, !llvm.loop !104

72:                                               ; preds = %65
  %73 = trunc nuw i64 %66 to i32
  %74 = icmp ugt i32 %61, %73
  br i1 %74, label %75, label %88

75:                                               ; preds = %72
  %76 = zext i32 %61 to i64
  br label %77

77:                                               ; preds = %75, %83
  %78 = phi i64 [ %76, %75 ], [ %79, %83 ]
  %79 = add nsw i64 %78, -1
  %80 = and i64 %79, 4294967295
  %81 = getelementptr inbounds nuw i8, ptr %59, i64 %80
  %82 = load i8, ptr %81, align 1, !tbaa !39
  switch i8 %82, label %86 [
    i8 32, label %83
    i8 10, label %83
    i8 9, label %83
    i8 13, label %83
  ]

83:                                               ; preds = %77, %77, %77, %77
  %84 = trunc i64 %79 to i32
  %85 = icmp ult i32 %73, %84
  br i1 %85, label %77, label %88, !llvm.loop !105

86:                                               ; preds = %77
  %87 = trunc nuw i64 %78 to i32
  br label %88

88:                                               ; preds = %69, %83, %86, %58, %72
  %89 = phi i32 [ %73, %72 ], [ %73, %86 ], [ 0, %58 ], [ %73, %83 ], [ %61, %69 ]
  %90 = phi i32 [ %61, %72 ], [ %87, %86 ], [ 0, %58 ], [ %73, %83 ], [ %61, %69 ]
  %91 = sub i32 %90, %89
  %92 = tail call i32 @nms_substr_owned(ptr noundef nonnull %0, i64 noundef %1, i32 noundef %89, i32 noundef %91, ptr noundef %2) #25
  br label %93

93:                                               ; preds = %88, %55
  %94 = phi i32 [ %56, %55 ], [ %92, %88 ]
  ret i32 %94
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_substr_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i32 noundef %2, i32 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  %7 = icmp eq ptr %0, null
  br i1 %7, label %62, label %8

8:                                                ; preds = %5
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = load i32, ptr %9, align 8, !tbaa !17
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %62

12:                                               ; preds = %8
  %13 = icmp sgt i64 %1, -1
  br i1 %13, label %40, label %14

14:                                               ; preds = %12
  %15 = and i64 %1, 9223372036854775807
  %16 = icmp eq i64 %15, 0
  br i1 %16, label %62, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %19 = load i32, ptr %18, align 4, !tbaa !18
  %20 = zext i32 %19 to i64
  %21 = icmp samesign ugt i64 %15, %20
  br i1 %21, label %62, label %22

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !19
  %25 = icmp eq ptr %24, null
  br i1 %25, label %62, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %15
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %29 = load i64, ptr %28, align 8, !tbaa !20
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %62, label %31

31:                                               ; preds = %26
  %32 = and i64 %1, 4294967295
  %33 = getelementptr inbounds nuw [48 x i8], ptr %24, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 28
  %35 = load i32, ptr %34, align 4, !tbaa !23
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %37, label %62

37:                                               ; preds = %31
  %38 = load ptr, ptr %33, align 8, !tbaa !24
  %39 = getelementptr inbounds nuw i8, ptr %33, i64 16
  br label %58

40:                                               ; preds = %12
  %41 = icmp eq i64 %1, 0
  br i1 %41, label %62, label %42

42:                                               ; preds = %40
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %44 = load i32, ptr %43, align 8, !tbaa !14
  %45 = zext i32 %44 to i64
  %46 = icmp samesign ugt i64 %1, %45
  br i1 %46, label %62, label %47

47:                                               ; preds = %42
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %49 = load ptr, ptr %48, align 8, !tbaa !13
  %50 = icmp eq ptr %49, null
  br i1 %50, label %62, label %51

51:                                               ; preds = %47
  %52 = getelementptr [16 x i8], ptr %49, i64 %1
  %53 = getelementptr i8, ptr %52, i64 -16
  %54 = load ptr, ptr %53, align 8, !tbaa !25
  %55 = icmp eq ptr %54, null
  br i1 %55, label %62, label %56

56:                                               ; preds = %51
  %57 = getelementptr i8, ptr %52, i64 -8
  br label %58

58:                                               ; preds = %56, %37
  %59 = phi ptr [ %54, %56 ], [ %38, %37 ]
  %60 = phi ptr [ %57, %56 ], [ %39, %37 ]
  %61 = icmp eq ptr %4, null
  br i1 %61, label %62, label %65

62:                                               ; preds = %58, %5, %51, %26, %8, %40, %47, %42, %22, %31, %14, %17
  %63 = phi i32 [ 6, %58 ], [ 6, %17 ], [ 6, %14 ], [ 1, %31 ], [ 6, %22 ], [ 6, %42 ], [ 6, %47 ], [ 6, %40 ], [ 5, %8 ], [ 6, %26 ], [ 6, %51 ], [ 6, %5 ]
  %64 = tail call i32 @nms_release(ptr noundef %0, i64 noundef %1) #25
  br label %86

65:                                               ; preds = %58
  %66 = load i32, ptr %60, align 8, !tbaa !12
  %67 = icmp ult i32 %2, %66
  %68 = select i1 %67, i32 %2, i32 0
  %69 = sub nuw i32 %66, %2
  %70 = tail call i32 @llvm.umin.i32(i32 %3, i32 %69)
  %71 = select i1 %67, i32 %70, i32 0
  %72 = icmp eq i32 %71, 0
  %73 = zext i32 %68 to i64
  %74 = getelementptr inbounds nuw i8, ptr %59, i64 %73
  %75 = select i1 %72, ptr null, ptr %74
  %76 = zext i32 %71 to i64
  %77 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %75, i64 noundef %76, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #25
  %78 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %1) #25
  %79 = icmp eq i32 %77, 0
  br i1 %79, label %80, label %86

80:                                               ; preds = %65
  %81 = icmp eq i32 %78, 0
  %82 = load i64, ptr %6, align 8, !tbaa !16
  br i1 %81, label %85, label %83

83:                                               ; preds = %80
  %84 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %82) #25
  br label %86

85:                                               ; preds = %80
  store i64 %82, ptr %4, align 8, !tbaa !16
  br label %86

86:                                               ; preds = %62, %65, %85, %83
  %87 = phi i32 [ 0, %85 ], [ %78, %83 ], [ %77, %65 ], [ %63, %62 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  ret i32 %87
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_concat_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  store i64 0, ptr %5, align 8, !tbaa !16
  %6 = icmp eq ptr %0, null
  br i1 %6, label %115, label %7

7:                                                ; preds = %4
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !17
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %115

11:                                               ; preds = %7
  %12 = icmp sgt i64 %1, -1
  br i1 %12, label %39, label %13

13:                                               ; preds = %11
  %14 = and i64 %1, 9223372036854775807
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %115, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %18 = load i32, ptr %17, align 4, !tbaa !18
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  br i1 %20, label %115, label %21

21:                                               ; preds = %16
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %23 = load ptr, ptr %22, align 8, !tbaa !19
  %24 = icmp eq ptr %23, null
  br i1 %24, label %115, label %25

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw [48 x i8], ptr %23, i64 %14
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load i64, ptr %27, align 8, !tbaa !20
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %115, label %30

30:                                               ; preds = %25
  %31 = and i64 %1, 4294967295
  %32 = getelementptr inbounds nuw [48 x i8], ptr %23, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 28
  %34 = load i32, ptr %33, align 4, !tbaa !23
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %36, label %115

36:                                               ; preds = %30
  %37 = load ptr, ptr %32, align 8, !tbaa !24
  %38 = getelementptr inbounds nuw i8, ptr %32, i64 16
  br label %57

39:                                               ; preds = %11
  %40 = icmp eq i64 %1, 0
  br i1 %40, label %115, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %43 = load i32, ptr %42, align 8, !tbaa !14
  %44 = zext i32 %43 to i64
  %45 = icmp samesign ugt i64 %1, %44
  br i1 %45, label %115, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %48 = load ptr, ptr %47, align 8, !tbaa !13
  %49 = icmp eq ptr %48, null
  br i1 %49, label %115, label %50

50:                                               ; preds = %46
  %51 = getelementptr [16 x i8], ptr %48, i64 %1
  %52 = getelementptr i8, ptr %51, i64 -16
  %53 = load ptr, ptr %52, align 8, !tbaa !25
  %54 = icmp eq ptr %53, null
  br i1 %54, label %115, label %55

55:                                               ; preds = %50
  %56 = getelementptr i8, ptr %51, i64 -8
  br label %57

57:                                               ; preds = %55, %36
  %58 = phi ptr [ %53, %55 ], [ %37, %36 ]
  %59 = phi ptr [ %56, %55 ], [ %38, %36 ]
  %60 = load i32, ptr %59, align 8, !tbaa !12
  %61 = icmp sgt i64 %2, -1
  br i1 %61, label %88, label %62

62:                                               ; preds = %57
  %63 = and i64 %2, 9223372036854775807
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %115, label %65

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %67 = load i32, ptr %66, align 4, !tbaa !18
  %68 = zext i32 %67 to i64
  %69 = icmp samesign ugt i64 %63, %68
  br i1 %69, label %115, label %70

70:                                               ; preds = %65
  %71 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %72 = load ptr, ptr %71, align 8, !tbaa !19
  %73 = icmp eq ptr %72, null
  br i1 %73, label %115, label %74

74:                                               ; preds = %70
  %75 = getelementptr inbounds nuw [48 x i8], ptr %72, i64 %63
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 8
  %77 = load i64, ptr %76, align 8, !tbaa !20
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %115, label %79

79:                                               ; preds = %74
  %80 = and i64 %2, 4294967295
  %81 = getelementptr inbounds nuw [48 x i8], ptr %72, i64 %80
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 28
  %83 = load i32, ptr %82, align 4, !tbaa !23
  %84 = icmp eq i32 %83, 1
  br i1 %84, label %85, label %115

85:                                               ; preds = %79
  %86 = load ptr, ptr %81, align 8, !tbaa !24
  %87 = getelementptr inbounds nuw i8, ptr %81, i64 16
  br label %106

88:                                               ; preds = %57
  %89 = icmp eq i64 %2, 0
  br i1 %89, label %115, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %92 = load i32, ptr %91, align 8, !tbaa !14
  %93 = zext i32 %92 to i64
  %94 = icmp samesign ugt i64 %2, %93
  br i1 %94, label %115, label %95

95:                                               ; preds = %90
  %96 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %97 = load ptr, ptr %96, align 8, !tbaa !13
  %98 = icmp eq ptr %97, null
  br i1 %98, label %115, label %99

99:                                               ; preds = %95
  %100 = getelementptr [16 x i8], ptr %97, i64 %2
  %101 = getelementptr i8, ptr %100, i64 -16
  %102 = load ptr, ptr %101, align 8, !tbaa !25
  %103 = icmp eq ptr %102, null
  br i1 %103, label %115, label %104

104:                                              ; preds = %99
  %105 = getelementptr i8, ptr %100, i64 -8
  br label %106

106:                                              ; preds = %104, %85
  %107 = phi ptr [ %102, %104 ], [ %86, %85 ]
  %108 = phi ptr [ %105, %104 ], [ %87, %85 ]
  %109 = icmp eq ptr %3, null
  br i1 %109, label %115, label %110

110:                                              ; preds = %106
  %111 = load i32, ptr %108, align 8, !tbaa !12
  %112 = zext i32 %60 to i64
  %113 = zext i32 %111 to i64
  %114 = call fastcc i32 @create_parts(ptr noundef nonnull %0, ptr noundef %58, i64 noundef %112, ptr noundef %107, i64 noundef %113, ptr noundef nonnull %5) #25
  br label %115

115:                                              ; preds = %16, %13, %30, %21, %41, %46, %39, %7, %25, %50, %4, %65, %62, %79, %70, %90, %95, %88, %74, %99, %110, %106
  %116 = phi i32 [ 6, %106 ], [ %114, %110 ], [ 6, %65 ], [ 6, %62 ], [ 1, %79 ], [ 6, %70 ], [ 6, %90 ], [ 6, %95 ], [ 6, %88 ], [ 6, %4 ], [ 6, %74 ], [ 6, %99 ], [ 6, %16 ], [ 6, %13 ], [ 1, %30 ], [ 6, %21 ], [ 6, %41 ], [ 6, %46 ], [ 6, %39 ], [ 5, %7 ], [ 6, %25 ], [ 6, %50 ]
  %117 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #25
  %118 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #25
  %119 = icmp eq i32 %116, 0
  br i1 %119, label %120, label %129

120:                                              ; preds = %115
  %121 = icmp ne i32 %117, 0
  %122 = icmp ne i32 %118, 0
  %123 = select i1 %121, i1 true, i1 %122
  %124 = load i64, ptr %5, align 8, !tbaa !16
  br i1 %123, label %125, label %128

125:                                              ; preds = %120
  %126 = call i32 @nms_release(ptr noundef %0, i64 noundef %124) #25
  %127 = select i1 %121, i32 %117, i32 %118
  br label %129

128:                                              ; preds = %120
  store i64 %124, ptr %3, align 8, !tbaa !16
  br label %129

129:                                              ; preds = %115, %128, %125
  %130 = phi i32 [ 0, %128 ], [ %127, %125 ], [ %116, %115 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  ret i32 %130
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_collect(ptr nofree noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %51, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !17
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %51

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %9 = load i32, ptr %8, align 4, !tbaa !18
  %10 = icmp eq i32 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %12 = load ptr, ptr %11, align 8, !tbaa !19
  %13 = icmp eq ptr %12, null
  br i1 %10, label %14, label %24

14:                                               ; preds = %7
  br i1 %13, label %15, label %51

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %17 = load i64, ptr %16, align 8, !tbaa !55
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %51

19:                                               ; preds = %15
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %21 = load i64, ptr %20, align 8, !tbaa !31
  %22 = icmp eq i64 %21, 0
  %23 = select i1 %22, i32 0, i32 6
  br label %51

24:                                               ; preds = %7
  br i1 %13, label %51, label %25

25:                                               ; preds = %24
  %26 = zext i32 %9 to i64
  %27 = add nuw nsw i64 %26, 1
  %28 = shl nuw nsw i64 %27, 3
  %29 = tail call ptr @malloc(i64 noundef %28) #24
  %30 = tail call ptr @malloc(i64 noundef %27) #24
  %31 = shl nuw nsw i64 %27, 2
  %32 = tail call ptr @malloc(i64 noundef %31) #24
  %33 = icmp ne ptr %29, null
  %34 = icmp ne ptr %30, null
  %35 = select i1 %33, i1 %34, i1 false
  %36 = icmp ne ptr %32, null
  %37 = select i1 %35, i1 %36, i1 false
  br i1 %37, label %38, label %40

38:                                               ; preds = %25
  %39 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull %0, ptr noundef nonnull %29, ptr noundef nonnull %30, ptr noundef nonnull %32) #25
  br label %42

40:                                               ; preds = %25
  %41 = icmp eq ptr %32, null
  br i1 %41, label %44, label %42

42:                                               ; preds = %38, %40
  %43 = phi i32 [ %39, %38 ], [ 3, %40 ]
  tail call void @free(ptr noundef nonnull %32) #26
  br label %44

44:                                               ; preds = %40, %42
  %45 = phi i32 [ 3, %40 ], [ %43, %42 ]
  %46 = icmp eq ptr %30, null
  br i1 %46, label %48, label %47

47:                                               ; preds = %44
  tail call void @free(ptr noundef nonnull %30) #26
  br label %48

48:                                               ; preds = %44, %47
  %49 = icmp eq ptr %29, null
  br i1 %49, label %51, label %50

50:                                               ; preds = %48
  tail call void @free(ptr noundef nonnull %29) #26
  br label %51

51:                                               ; preds = %19, %24, %14, %15, %3, %1, %50, %48
  %52 = phi i32 [ %45, %50 ], [ 6, %24 ], [ %45, %48 ], [ 6, %1 ], [ %23, %19 ], [ 6, %14 ], [ 6, %15 ], [ 5, %3 ]
  ret i32 %52
}

; Function Attrs: nounwind ssp
define internal fastcc range(i32 0, 7) i32 @collect_with_workspace(ptr nofree noundef captures(address_is_null) %0, ptr nofree noundef captures(none) %1, ptr nofree noundef captures(none) %2, ptr nofree noundef captures(none) %3) unnamed_addr #3 {
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %6 = load i32, ptr %5, align 4, !tbaa !18
  %7 = zext i32 %6 to i64
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br label %12

12:                                               ; preds = %4, %139
  %13 = phi i64 [ 0, %4 ], [ %141, %139 ]
  %14 = phi i64 [ 0, %4 ], [ %140, %139 ]
  %15 = phi i64 [ 0, %4 ], [ %142, %139 ]
  %16 = load ptr, ptr %8, align 8, !tbaa !19
  %17 = getelementptr inbounds nuw [48 x i8], ptr %16, i64 %15
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 8
  %19 = load i64, ptr %18, align 8, !tbaa !20
  %20 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %15
  store i64 %19, ptr %20, align 8, !tbaa !16
  %21 = getelementptr inbounds nuw i8, ptr %2, i64 %15
  store i8 0, ptr %21, align 1, !tbaa !39
  %22 = load i64, ptr %18, align 8, !tbaa !20
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %39

24:                                               ; preds = %12
  %25 = getelementptr inbounds nuw i8, ptr %17, i64 28
  %26 = load i32, ptr %25, align 4, !tbaa !23
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %28, label %592

28:                                               ; preds = %24
  %29 = load ptr, ptr %17, align 8, !tbaa !24
  %30 = icmp eq ptr %29, null
  br i1 %30, label %31, label %592

31:                                               ; preds = %28
  %32 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %33 = load i32, ptr %32, align 8, !tbaa !34
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %592

35:                                               ; preds = %31
  %36 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %37 = load i32, ptr %36, align 8, !tbaa !38
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %139, label %592

39:                                               ; preds = %12
  %40 = icmp eq i64 %15, 0
  br i1 %40, label %592, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds nuw i8, ptr %17, i64 28
  %43 = load i32, ptr %42, align 4, !tbaa !23
  %44 = add i32 %43, -6
  %45 = icmp ult i32 %44, -5
  br i1 %45, label %592, label %46

46:                                               ; preds = %41
  %47 = icmp eq i32 %43, 1
  br i1 %47, label %48, label %55

48:                                               ; preds = %46
  %49 = load ptr, ptr %17, align 8, !tbaa !24
  %50 = icmp eq ptr %49, null
  br i1 %50, label %592, label %51

51:                                               ; preds = %48
  %52 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %53 = load i32, ptr %52, align 8, !tbaa !34
  %54 = zext i32 %53 to i64
  br label %132

55:                                               ; preds = %46
  %56 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %57 = load i32, ptr %56, align 8, !tbaa !34
  %58 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %59 = load i32, ptr %58, align 8, !tbaa !38
  %60 = icmp ugt i32 %57, %59
  br i1 %60, label %592, label %61

61:                                               ; preds = %55
  %62 = icmp eq i32 %59, 0
  br i1 %62, label %66, label %63

63:                                               ; preds = %61
  %64 = load ptr, ptr %17, align 8, !tbaa !24
  %65 = icmp eq ptr %64, null
  br i1 %65, label %592, label %66

66:                                               ; preds = %63, %61
  switch i32 %43, label %127 [
    i32 4, label %67
    i32 5, label %72
    i32 2, label %128
  ]

67:                                               ; preds = %66
  %68 = getelementptr inbounds nuw i8, ptr %17, i64 32
  %69 = load i32, ptr %68, align 8, !tbaa !49
  %70 = add i32 %69, -1
  %71 = icmp ult i32 %70, 4
  br i1 %71, label %119, label %592

72:                                               ; preds = %66
  %73 = load i32, ptr %9, align 8, !tbaa !17
  %74 = icmp eq i32 %73, 0
  br i1 %74, label %75, label %592

75:                                               ; preds = %72
  %76 = load i32, ptr %5, align 4, !tbaa !18
  %77 = zext i32 %76 to i64
  %78 = icmp samesign ugt i64 %15, %77
  br i1 %78, label %592, label %79

79:                                               ; preds = %75
  %80 = load ptr, ptr %8, align 8, !tbaa !19
  %81 = icmp eq ptr %80, null
  br i1 %81, label %592, label %82

82:                                               ; preds = %79
  %83 = getelementptr inbounds nuw [48 x i8], ptr %80, i64 %15
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 8
  %85 = load i64, ptr %84, align 8, !tbaa !20
  %86 = icmp eq i64 %85, 0
  br i1 %86, label %592, label %87

87:                                               ; preds = %82
  %88 = getelementptr inbounds nuw i8, ptr %83, i64 28
  %89 = load i32, ptr %88, align 4, !tbaa !23
  %90 = icmp eq i32 %89, 5
  br i1 %90, label %91, label %592

91:                                               ; preds = %87
  %92 = load i32, ptr %10, align 4, !tbaa !45
  %93 = icmp eq i32 %92, 0
  br i1 %93, label %592, label %94

94:                                               ; preds = %91
  %95 = load ptr, ptr %0, align 8, !tbaa !8
  %96 = icmp eq ptr %95, null
  br i1 %96, label %592, label %97

97:                                               ; preds = %94
  %98 = getelementptr inbounds nuw i8, ptr %83, i64 40
  %99 = load i32, ptr %98, align 8, !tbaa !33
  %100 = load i32, ptr %11, align 8, !tbaa !46
  %101 = icmp ult i32 %99, %100
  br i1 %101, label %102, label %592

102:                                              ; preds = %97
  %103 = zext i32 %99 to i64
  %104 = getelementptr inbounds nuw [8 x i8], ptr %95, i64 %103
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 4
  %106 = load i32, ptr %105, align 4, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %83, i64 16
  %108 = load i32, ptr %107, align 8, !tbaa !34
  %109 = icmp eq i32 %108, %106
  br i1 %109, label %110, label %592

110:                                              ; preds = %102
  %111 = getelementptr inbounds nuw i8, ptr %83, i64 24
  %112 = load i32, ptr %111, align 8, !tbaa !38
  %113 = icmp eq i32 %112, %106
  br i1 %113, label %114, label %592

114:                                              ; preds = %110
  %115 = icmp eq i32 %106, 0
  br i1 %115, label %127, label %116

116:                                              ; preds = %114
  %117 = load ptr, ptr %83, align 8, !tbaa !24
  %118 = icmp eq ptr %117, null
  br i1 %118, label %592, label %127

119:                                              ; preds = %67
  %120 = and i32 %69, 5
  %121 = icmp eq i32 %120, 1
  %122 = icmp eq i32 %69, 2
  %123 = icmp eq i32 %69, 4
  %124 = or i1 %122, %123
  %125 = zext i1 %124 to i64
  %126 = select i1 %121, i64 8, i64 %125
  br label %128

127:                                              ; preds = %116, %114, %66
  br label %128

128:                                              ; preds = %66, %119, %127
  %129 = phi i64 [ 8, %66 ], [ %126, %119 ], [ 16, %127 ]
  %130 = zext i32 %59 to i64
  %131 = mul nuw nsw i64 %129, %130
  br label %132

132:                                              ; preds = %128, %51
  %133 = phi i64 [ %54, %51 ], [ %131, %128 ]
  %134 = xor i64 %13, -1
  %135 = icmp ugt i64 %133, %134
  br i1 %135, label %592, label %136

136:                                              ; preds = %132
  %137 = add i64 %133, %13
  %138 = add i64 %14, 1
  br label %139

139:                                              ; preds = %35, %136
  %140 = phi i64 [ %138, %136 ], [ %14, %35 ]
  %141 = phi i64 [ %137, %136 ], [ %13, %35 ]
  %142 = add nuw nsw i64 %15, 1
  %143 = icmp eq i64 %15, %7
  br i1 %143, label %144, label %12, !llvm.loop !106

144:                                              ; preds = %139
  %145 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %146 = load i64, ptr %145, align 8, !tbaa !55
  %147 = icmp eq i64 %140, %146
  br i1 %147, label %148, label %592

148:                                              ; preds = %144
  %149 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %150 = load i64, ptr %149, align 8, !tbaa !31
  %151 = icmp eq i64 %141, %150
  br i1 %151, label %152, label %592

152:                                              ; preds = %148
  %153 = icmp eq i32 %6, 0
  br i1 %153, label %592, label %154

154:                                              ; preds = %152
  %155 = load ptr, ptr %8, align 8, !tbaa !19
  br label %156

156:                                              ; preds = %154, %234
  %157 = phi i64 [ 1, %154 ], [ %235, %234 ]
  %158 = getelementptr inbounds nuw [48 x i8], ptr %155, i64 %157
  %159 = getelementptr inbounds nuw i8, ptr %158, i64 28
  %160 = load i32, ptr %159, align 4, !tbaa !23
  switch i32 %160, label %234 [
    i32 5, label %161
    i32 3, label %161
    i32 2, label %161
  ]

161:                                              ; preds = %156, %156, %156
  %162 = getelementptr inbounds nuw i8, ptr %158, i64 16
  %163 = load i32, ptr %162, align 8, !tbaa !34
  %164 = icmp eq i32 %163, 0
  br i1 %164, label %234, label %165

165:                                              ; preds = %161
  %166 = getelementptr inbounds nuw i8, ptr %158, i64 32
  %167 = zext i32 %163 to i64
  br label %168

168:                                              ; preds = %165, %231
  %169 = phi i64 [ 0, %165 ], [ %232, %231 ]
  switch i32 %160, label %203 [
    i32 4, label %170
    i32 2, label %199
  ]

170:                                              ; preds = %168
  %171 = load i32, ptr %166, align 8, !tbaa !49
  %172 = and i32 %171, -3
  %173 = icmp eq i32 %172, 1
  %174 = icmp eq i32 %171, 2
  %175 = icmp eq i32 %171, 4
  %176 = or i1 %174, %175
  %177 = zext i1 %176 to i32
  %178 = select i1 %173, i32 8, i32 %177
  %179 = icmp eq i32 %178, 0
  br i1 %179, label %196, label %180

180:                                              ; preds = %170
  %181 = zext nneg i32 %178 to i64
  %182 = mul nuw nsw i64 %169, %181
  %183 = load ptr, ptr %158, align 8, !tbaa !24
  %184 = getelementptr inbounds nuw i8, ptr %183, i64 %182
  br label %185

185:                                              ; preds = %185, %180
  %186 = phi i64 [ 0, %180 ], [ %194, %185 ]
  %187 = phi i64 [ 0, %180 ], [ %193, %185 ]
  %188 = getelementptr inbounds nuw i8, ptr %184, i64 %186
  %189 = load i8, ptr %188, align 1, !tbaa !39
  %190 = zext i8 %189 to i64
  %191 = shl nuw nsw i64 %186, 3
  %192 = shl nuw i64 %190, %191
  %193 = or i64 %192, %187
  %194 = add nuw nsw i64 %186, 1
  %195 = icmp eq i64 %194, %181
  br i1 %195, label %196, label %185, !llvm.loop !50

196:                                              ; preds = %185, %170
  %197 = phi i64 [ 0, %170 ], [ %193, %185 ]
  %198 = zext i32 %171 to i64
  br label %209

199:                                              ; preds = %168
  %200 = load ptr, ptr %158, align 8, !tbaa !24
  %201 = getelementptr inbounds nuw [8 x i8], ptr %200, i64 %169
  %202 = load i64, ptr %201, align 8, !tbaa !16
  br label %209

203:                                              ; preds = %168
  %204 = load ptr, ptr %158, align 8, !tbaa !24
  %205 = getelementptr inbounds nuw [16 x i8], ptr %204, i64 %169
  %206 = load i64, ptr %205, align 8, !tbaa !16
  %207 = getelementptr inbounds nuw i8, ptr %205, i64 8
  %208 = load i64, ptr %207, align 8
  br label %209

209:                                              ; preds = %196, %199, %203
  %210 = phi i64 [ %197, %196 ], [ %202, %199 ], [ %206, %203 ]
  %211 = phi i64 [ %198, %196 ], [ 5, %199 ], [ %208, %203 ]
  %212 = insertvalue [2 x i64] poison, i64 %210, 0
  %213 = insertvalue [2 x i64] %212, i64 %211, 1
  %214 = tail call fastcc i32 @value_valid(ptr noundef %0, [2 x i64] %213) #25
  %215 = icmp eq i32 %214, 0
  br i1 %215, label %216, label %592

216:                                              ; preds = %209
  %217 = trunc i64 %211 to i32
  %218 = and i32 %217, -3
  %219 = icmp ne i32 %218, 5
  %220 = icmp ne i32 %217, 8
  %221 = and i1 %220, %219
  %222 = icmp sgt i64 %210, -1
  %223 = select i1 %221, i1 true, i1 %222
  br i1 %223, label %231, label %224

224:                                              ; preds = %216
  %225 = and i64 %210, 4294967295
  %226 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %225
  %227 = load i64, ptr %226, align 8, !tbaa !16
  %228 = icmp eq i64 %227, 0
  br i1 %228, label %592, label %229

229:                                              ; preds = %224
  %230 = add i64 %227, -1
  store i64 %230, ptr %226, align 8, !tbaa !16
  br label %231

231:                                              ; preds = %229, %216
  %232 = add nuw nsw i64 %169, 1
  %233 = icmp eq i64 %232, %167
  br i1 %233, label %234, label %168, !llvm.loop !107

234:                                              ; preds = %231, %161, %156
  %235 = add nuw nsw i64 %157, 1
  %236 = icmp eq i64 %157, %7
  br i1 %236, label %237, label %156, !llvm.loop !108

237:                                              ; preds = %234
  %238 = and i64 %7, 7
  %239 = icmp ult i32 %6, 8
  br i1 %239, label %244, label %240

240:                                              ; preds = %237
  %241 = and i64 %7, 4294967288
  br label %268

242:                                              ; preds = %357
  %243 = icmp eq i64 %238, 0
  br i1 %243, label %265, label %244

244:                                              ; preds = %242, %237
  %245 = phi i64 [ 1, %237 ], [ %359, %242 ]
  %246 = phi i64 [ 0, %237 ], [ %358, %242 ]
  %247 = icmp ne i64 %238, 0
  tail call void @llvm.assume(i1 %247)
  br label %248

248:                                              ; preds = %260, %244
  %249 = phi i64 [ %262, %260 ], [ %245, %244 ]
  %250 = phi i64 [ %261, %260 ], [ %246, %244 ]
  %251 = phi i64 [ %263, %260 ], [ 0, %244 ]
  %252 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %249
  %253 = load i64, ptr %252, align 8, !tbaa !16
  %254 = icmp eq i64 %253, 0
  br i1 %254, label %260, label %255

255:                                              ; preds = %248
  %256 = getelementptr inbounds nuw i8, ptr %2, i64 %249
  store i8 1, ptr %256, align 1, !tbaa !39
  %257 = trunc nuw i64 %249 to i32
  %258 = add i64 %250, 1
  %259 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %250
  store i32 %257, ptr %259, align 4, !tbaa !12
  br label %260

260:                                              ; preds = %255, %248
  %261 = phi i64 [ %258, %255 ], [ %250, %248 ]
  %262 = add nuw nsw i64 %249, 1
  %263 = add i64 %251, 1
  %264 = icmp eq i64 %263, %238
  br i1 %264, label %265, label %248, !llvm.loop !109

265:                                              ; preds = %260, %242
  %266 = phi i64 [ %358, %242 ], [ %261, %260 ]
  %267 = icmp eq i64 %266, 0
  br i1 %267, label %362, label %364

268:                                              ; preds = %357, %240
  %269 = phi i64 [ 1, %240 ], [ %359, %357 ]
  %270 = phi i64 [ 0, %240 ], [ %358, %357 ]
  %271 = phi i64 [ 0, %240 ], [ %360, %357 ]
  %272 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %269
  %273 = load i64, ptr %272, align 8, !tbaa !16
  %274 = icmp eq i64 %273, 0
  br i1 %274, label %280, label %275

275:                                              ; preds = %268
  %276 = getelementptr inbounds nuw i8, ptr %2, i64 %269
  store i8 1, ptr %276, align 1, !tbaa !39
  %277 = trunc nuw i64 %269 to i32
  %278 = add i64 %270, 1
  %279 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %270
  store i32 %277, ptr %279, align 4, !tbaa !12
  br label %280

280:                                              ; preds = %268, %275
  %281 = phi i64 [ %278, %275 ], [ %270, %268 ]
  %282 = add nuw nsw i64 %269, 1
  %283 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %282
  %284 = load i64, ptr %283, align 8, !tbaa !16
  %285 = icmp eq i64 %284, 0
  br i1 %285, label %291, label %286

286:                                              ; preds = %280
  %287 = getelementptr inbounds nuw i8, ptr %2, i64 %282
  store i8 1, ptr %287, align 1, !tbaa !39
  %288 = trunc nuw i64 %282 to i32
  %289 = add i64 %281, 1
  %290 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %281
  store i32 %288, ptr %290, align 4, !tbaa !12
  br label %291

291:                                              ; preds = %286, %280
  %292 = phi i64 [ %289, %286 ], [ %281, %280 ]
  %293 = add nuw nsw i64 %269, 2
  %294 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %293
  %295 = load i64, ptr %294, align 8, !tbaa !16
  %296 = icmp eq i64 %295, 0
  br i1 %296, label %302, label %297

297:                                              ; preds = %291
  %298 = getelementptr inbounds nuw i8, ptr %2, i64 %293
  store i8 1, ptr %298, align 1, !tbaa !39
  %299 = trunc nuw i64 %293 to i32
  %300 = add i64 %292, 1
  %301 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %292
  store i32 %299, ptr %301, align 4, !tbaa !12
  br label %302

302:                                              ; preds = %297, %291
  %303 = phi i64 [ %300, %297 ], [ %292, %291 ]
  %304 = add nuw nsw i64 %269, 3
  %305 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %304
  %306 = load i64, ptr %305, align 8, !tbaa !16
  %307 = icmp eq i64 %306, 0
  br i1 %307, label %313, label %308

308:                                              ; preds = %302
  %309 = getelementptr inbounds nuw i8, ptr %2, i64 %304
  store i8 1, ptr %309, align 1, !tbaa !39
  %310 = trunc nuw i64 %304 to i32
  %311 = add i64 %303, 1
  %312 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %303
  store i32 %310, ptr %312, align 4, !tbaa !12
  br label %313

313:                                              ; preds = %308, %302
  %314 = phi i64 [ %311, %308 ], [ %303, %302 ]
  %315 = add nuw nsw i64 %269, 4
  %316 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %315
  %317 = load i64, ptr %316, align 8, !tbaa !16
  %318 = icmp eq i64 %317, 0
  br i1 %318, label %324, label %319

319:                                              ; preds = %313
  %320 = getelementptr inbounds nuw i8, ptr %2, i64 %315
  store i8 1, ptr %320, align 1, !tbaa !39
  %321 = trunc nuw i64 %315 to i32
  %322 = add i64 %314, 1
  %323 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %314
  store i32 %321, ptr %323, align 4, !tbaa !12
  br label %324

324:                                              ; preds = %319, %313
  %325 = phi i64 [ %322, %319 ], [ %314, %313 ]
  %326 = add nuw nsw i64 %269, 5
  %327 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %326
  %328 = load i64, ptr %327, align 8, !tbaa !16
  %329 = icmp eq i64 %328, 0
  br i1 %329, label %335, label %330

330:                                              ; preds = %324
  %331 = getelementptr inbounds nuw i8, ptr %2, i64 %326
  store i8 1, ptr %331, align 1, !tbaa !39
  %332 = trunc nuw i64 %326 to i32
  %333 = add i64 %325, 1
  %334 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %325
  store i32 %332, ptr %334, align 4, !tbaa !12
  br label %335

335:                                              ; preds = %330, %324
  %336 = phi i64 [ %333, %330 ], [ %325, %324 ]
  %337 = add nuw nsw i64 %269, 6
  %338 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %337
  %339 = load i64, ptr %338, align 8, !tbaa !16
  %340 = icmp eq i64 %339, 0
  br i1 %340, label %346, label %341

341:                                              ; preds = %335
  %342 = getelementptr inbounds nuw i8, ptr %2, i64 %337
  store i8 1, ptr %342, align 1, !tbaa !39
  %343 = trunc nuw i64 %337 to i32
  %344 = add i64 %336, 1
  %345 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %336
  store i32 %343, ptr %345, align 4, !tbaa !12
  br label %346

346:                                              ; preds = %341, %335
  %347 = phi i64 [ %344, %341 ], [ %336, %335 ]
  %348 = add nuw nsw i64 %269, 7
  %349 = getelementptr inbounds nuw [8 x i8], ptr %1, i64 %348
  %350 = load i64, ptr %349, align 8, !tbaa !16
  %351 = icmp eq i64 %350, 0
  br i1 %351, label %357, label %352

352:                                              ; preds = %346
  %353 = getelementptr inbounds nuw i8, ptr %2, i64 %348
  store i8 1, ptr %353, align 1, !tbaa !39
  %354 = trunc nuw i64 %348 to i32
  %355 = add i64 %347, 1
  %356 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %347
  store i32 %354, ptr %356, align 4, !tbaa !12
  br label %357

357:                                              ; preds = %352, %346
  %358 = phi i64 [ %355, %352 ], [ %347, %346 ]
  %359 = add nuw nsw i64 %269, 8
  %360 = add i64 %271, 8
  %361 = icmp eq i64 %360, %241
  br i1 %361, label %242, label %268, !llvm.loop !110

362:                                              ; preds = %448, %265
  %363 = load ptr, ptr %8, align 8, !tbaa !19
  br label %453

364:                                              ; preds = %265, %448
  %365 = phi i64 [ %449, %448 ], [ %266, %265 ]
  %366 = phi i64 [ %368, %448 ], [ 0, %265 ]
  %367 = load ptr, ptr %8, align 8, !tbaa !19
  %368 = add nuw i64 %366, 1
  %369 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %366
  %370 = load i32, ptr %369, align 4, !tbaa !12
  %371 = zext i32 %370 to i64
  %372 = getelementptr inbounds nuw [48 x i8], ptr %367, i64 %371
  %373 = getelementptr inbounds nuw i8, ptr %372, i64 28
  %374 = load i32, ptr %373, align 4, !tbaa !23
  switch i32 %374, label %448 [
    i32 5, label %375
    i32 3, label %375
    i32 2, label %375
  ]

375:                                              ; preds = %364, %364, %364
  %376 = getelementptr inbounds nuw i8, ptr %372, i64 16
  %377 = load i32, ptr %376, align 8, !tbaa !34
  %378 = icmp eq i32 %377, 0
  br i1 %378, label %448, label %379

379:                                              ; preds = %375
  %380 = getelementptr inbounds nuw i8, ptr %372, i64 32
  br label %381

381:                                              ; preds = %379, %442
  %382 = phi i32 [ %377, %379 ], [ %443, %442 ]
  %383 = phi i64 [ 0, %379 ], [ %445, %442 ]
  %384 = phi i64 [ %365, %379 ], [ %444, %442 ]
  %385 = load i32, ptr %373, align 4, !tbaa !23
  switch i32 %385, label %416 [
    i32 4, label %386
    i32 2, label %412
  ]

386:                                              ; preds = %381
  %387 = load i32, ptr %380, align 8, !tbaa !49
  %388 = and i32 %387, -3
  %389 = icmp eq i32 %388, 1
  %390 = icmp eq i32 %387, 2
  %391 = icmp eq i32 %387, 4
  %392 = or i1 %390, %391
  %393 = zext i1 %392 to i32
  %394 = select i1 %389, i32 8, i32 %393
  %395 = icmp eq i32 %394, 0
  br i1 %395, label %442, label %396

396:                                              ; preds = %386
  %397 = zext nneg i32 %394 to i64
  %398 = mul nuw nsw i64 %383, %397
  %399 = load ptr, ptr %372, align 8, !tbaa !24
  %400 = getelementptr inbounds nuw i8, ptr %399, i64 %398
  br label %401

401:                                              ; preds = %401, %396
  %402 = phi i64 [ 0, %396 ], [ %410, %401 ]
  %403 = phi i64 [ 0, %396 ], [ %409, %401 ]
  %404 = getelementptr inbounds nuw i8, ptr %400, i64 %402
  %405 = load i8, ptr %404, align 1, !tbaa !39
  %406 = zext i8 %405 to i64
  %407 = shl nuw nsw i64 %402, 3
  %408 = shl nuw i64 %406, %407
  %409 = or i64 %408, %403
  %410 = add nuw nsw i64 %402, 1
  %411 = icmp eq i64 %410, %397
  br i1 %411, label %423, label %401, !llvm.loop !50

412:                                              ; preds = %381
  %413 = load ptr, ptr %372, align 8, !tbaa !24
  %414 = getelementptr inbounds nuw [8 x i8], ptr %413, i64 %383
  %415 = load i64, ptr %414, align 8, !tbaa !16
  br label %423

416:                                              ; preds = %381
  %417 = load ptr, ptr %372, align 8, !tbaa !24
  %418 = getelementptr inbounds nuw [16 x i8], ptr %417, i64 %383
  %419 = load i64, ptr %418, align 8, !tbaa !16
  %420 = getelementptr inbounds nuw i8, ptr %418, i64 8
  %421 = load i64, ptr %420, align 8
  %422 = trunc i64 %421 to i32
  br label %423

423:                                              ; preds = %401, %412, %416
  %424 = phi i64 [ %419, %416 ], [ %415, %412 ], [ %409, %401 ]
  %425 = phi i32 [ %422, %416 ], [ 5, %412 ], [ %387, %401 ]
  %426 = and i32 %425, -3
  %427 = icmp ne i32 %426, 5
  %428 = icmp ne i32 %425, 8
  %429 = and i1 %428, %427
  %430 = icmp sgt i64 %424, -1
  %431 = select i1 %429, i1 true, i1 %430
  br i1 %431, label %442, label %432

432:                                              ; preds = %423
  %433 = and i64 %424, 4294967295
  %434 = getelementptr inbounds nuw i8, ptr %2, i64 %433
  %435 = load i8, ptr %434, align 1, !tbaa !39
  %436 = icmp eq i8 %435, 0
  br i1 %436, label %437, label %442

437:                                              ; preds = %432
  %438 = trunc i64 %424 to i32
  store i8 1, ptr %434, align 1, !tbaa !39
  %439 = add i64 %384, 1
  %440 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %384
  store i32 %438, ptr %440, align 4, !tbaa !12
  %441 = load i32, ptr %376, align 8, !tbaa !34
  br label %442

442:                                              ; preds = %386, %432, %437, %423
  %443 = phi i32 [ %382, %423 ], [ %382, %432 ], [ %441, %437 ], [ %382, %386 ]
  %444 = phi i64 [ %384, %423 ], [ %384, %432 ], [ %439, %437 ], [ %384, %386 ]
  %445 = add nuw nsw i64 %383, 1
  %446 = zext i32 %443 to i64
  %447 = icmp samesign ult i64 %445, %446
  br i1 %447, label %381, label %448, !llvm.loop !111

448:                                              ; preds = %442, %375, %364
  %449 = phi i64 [ %365, %364 ], [ %365, %375 ], [ %444, %442 ]
  %450 = icmp ult i64 %368, %449
  br i1 %450, label %364, label %362

451:                                              ; preds = %534
  %452 = getelementptr inbounds nuw i8, ptr %0, i64 72
  br label %537

453:                                              ; preds = %362, %534
  %454 = phi i64 [ 1, %362 ], [ %535, %534 ]
  %455 = getelementptr inbounds nuw [48 x i8], ptr %363, i64 %454
  %456 = getelementptr inbounds nuw i8, ptr %2, i64 %454
  %457 = load i8, ptr %456, align 1, !tbaa !39
  %458 = icmp eq i8 %457, 0
  br i1 %458, label %459, label %534

459:                                              ; preds = %453
  %460 = getelementptr inbounds nuw i8, ptr %455, i64 8
  %461 = load i64, ptr %460, align 8, !tbaa !20
  %462 = icmp eq i64 %461, 0
  br i1 %462, label %534, label %463

463:                                              ; preds = %459
  %464 = getelementptr inbounds nuw i8, ptr %455, i64 28
  %465 = load i32, ptr %464, align 4, !tbaa !23
  switch i32 %465, label %534 [
    i32 5, label %466
    i32 3, label %466
    i32 2, label %466
  ]

466:                                              ; preds = %463, %463, %463
  %467 = getelementptr inbounds nuw i8, ptr %455, i64 16
  %468 = load i32, ptr %467, align 8, !tbaa !34
  %469 = icmp eq i32 %468, 0
  br i1 %469, label %534, label %470

470:                                              ; preds = %466
  %471 = getelementptr inbounds nuw i8, ptr %455, i64 32
  %472 = zext i32 %468 to i64
  br label %473

473:                                              ; preds = %470, %531
  %474 = phi i64 [ 0, %470 ], [ %532, %531 ]
  switch i32 %465, label %505 [
    i32 4, label %475
    i32 2, label %501
  ]

475:                                              ; preds = %473
  %476 = load i32, ptr %471, align 8, !tbaa !49
  %477 = and i32 %476, -3
  %478 = icmp eq i32 %477, 1
  %479 = icmp eq i32 %476, 2
  %480 = icmp eq i32 %476, 4
  %481 = or i1 %479, %480
  %482 = zext i1 %481 to i32
  %483 = select i1 %478, i32 8, i32 %482
  %484 = icmp eq i32 %483, 0
  br i1 %484, label %531, label %485

485:                                              ; preds = %475
  %486 = zext nneg i32 %483 to i64
  %487 = mul nuw nsw i64 %474, %486
  %488 = load ptr, ptr %455, align 8, !tbaa !24
  %489 = getelementptr inbounds nuw i8, ptr %488, i64 %487
  br label %490

490:                                              ; preds = %490, %485
  %491 = phi i64 [ 0, %485 ], [ %499, %490 ]
  %492 = phi i64 [ 0, %485 ], [ %498, %490 ]
  %493 = getelementptr inbounds nuw i8, ptr %489, i64 %491
  %494 = load i8, ptr %493, align 1, !tbaa !39
  %495 = zext i8 %494 to i64
  %496 = shl nuw nsw i64 %491, 3
  %497 = shl nuw i64 %495, %496
  %498 = or i64 %497, %492
  %499 = add nuw nsw i64 %491, 1
  %500 = icmp eq i64 %499, %486
  br i1 %500, label %512, label %490, !llvm.loop !50

501:                                              ; preds = %473
  %502 = load ptr, ptr %455, align 8, !tbaa !24
  %503 = getelementptr inbounds nuw [8 x i8], ptr %502, i64 %474
  %504 = load i64, ptr %503, align 8, !tbaa !16
  br label %512

505:                                              ; preds = %473
  %506 = load ptr, ptr %455, align 8, !tbaa !24
  %507 = getelementptr inbounds nuw [16 x i8], ptr %506, i64 %474
  %508 = load i64, ptr %507, align 8, !tbaa !16
  %509 = getelementptr inbounds nuw i8, ptr %507, i64 8
  %510 = load i64, ptr %509, align 8
  %511 = trunc i64 %510 to i32
  br label %512

512:                                              ; preds = %490, %501, %505
  %513 = phi i64 [ %508, %505 ], [ %504, %501 ], [ %498, %490 ]
  %514 = phi i32 [ %511, %505 ], [ 5, %501 ], [ %476, %490 ]
  %515 = and i32 %514, -3
  %516 = icmp ne i32 %515, 5
  %517 = icmp ne i32 %514, 8
  %518 = and i1 %517, %516
  %519 = icmp sgt i64 %513, -1
  %520 = select i1 %518, i1 true, i1 %519
  br i1 %520, label %531, label %521

521:                                              ; preds = %512
  %522 = and i64 %513, 4294967295
  %523 = getelementptr inbounds nuw i8, ptr %2, i64 %522
  %524 = load i8, ptr %523, align 1, !tbaa !39
  %525 = icmp eq i8 %524, 0
  br i1 %525, label %531, label %526

526:                                              ; preds = %521
  %527 = getelementptr inbounds nuw [48 x i8], ptr %363, i64 %522
  %528 = getelementptr inbounds nuw i8, ptr %527, i64 8
  %529 = load i64, ptr %528, align 8, !tbaa !20
  %530 = add i64 %529, -1
  store i64 %530, ptr %528, align 8, !tbaa !20
  br label %531

531:                                              ; preds = %475, %521, %526, %512
  %532 = add nuw nsw i64 %474, 1
  %533 = icmp eq i64 %532, %472
  br i1 %533, label %534, label %473, !llvm.loop !112

534:                                              ; preds = %531, %466, %463, %453, %459
  %535 = add nuw nsw i64 %454, 1
  %536 = icmp eq i64 %454, %7
  br i1 %536, label %451, label %453, !llvm.loop !113

537:                                              ; preds = %451, %589
  %538 = phi i64 [ 1, %451 ], [ %590, %589 ]
  %539 = load ptr, ptr %8, align 8, !tbaa !19
  %540 = getelementptr inbounds nuw [48 x i8], ptr %539, i64 %538
  %541 = getelementptr inbounds nuw i8, ptr %2, i64 %538
  %542 = load i8, ptr %541, align 1, !tbaa !39
  %543 = icmp eq i8 %542, 0
  br i1 %543, label %544, label %589

544:                                              ; preds = %537
  %545 = getelementptr inbounds nuw i8, ptr %540, i64 8
  %546 = load i64, ptr %545, align 8, !tbaa !20
  %547 = icmp eq i64 %546, 0
  br i1 %547, label %589, label %548

548:                                              ; preds = %544
  %549 = getelementptr inbounds nuw i8, ptr %540, i64 28
  %550 = load i32, ptr %549, align 4, !tbaa !23
  %551 = icmp eq i32 %550, 1
  br i1 %551, label %552, label %556

552:                                              ; preds = %548
  %553 = getelementptr inbounds nuw i8, ptr %540, i64 16
  %554 = load i32, ptr %553, align 8, !tbaa !34
  %555 = zext i32 %554 to i64
  br label %574

556:                                              ; preds = %548
  %557 = getelementptr inbounds nuw i8, ptr %540, i64 24
  %558 = load i32, ptr %557, align 8, !tbaa !38
  switch i32 %550, label %569 [
    i32 2, label %570
    i32 4, label %559
  ]

559:                                              ; preds = %556
  %560 = getelementptr inbounds nuw i8, ptr %540, i64 32
  %561 = load i32, ptr %560, align 8, !tbaa !49
  %562 = and i32 %561, -3
  %563 = icmp eq i32 %562, 1
  %564 = icmp eq i32 %561, 2
  %565 = icmp eq i32 %561, 4
  %566 = or i1 %564, %565
  %567 = zext i1 %566 to i64
  %568 = select i1 %563, i64 8, i64 %567
  br label %570

569:                                              ; preds = %556
  br label %570

570:                                              ; preds = %556, %559, %569
  %571 = phi i64 [ 8, %556 ], [ %568, %559 ], [ 16, %569 ]
  %572 = zext i32 %558 to i64
  %573 = mul nuw nsw i64 %571, %572
  br label %574

574:                                              ; preds = %570, %552
  %575 = phi i64 [ %555, %552 ], [ %573, %570 ]
  %576 = load <2 x i64>, ptr %149, align 8, !tbaa !16
  %577 = insertelement <2 x i64> <i64 poison, i64 1>, i64 %575, i64 0
  %578 = sub <2 x i64> %576, %577
  store <2 x i64> %578, ptr %149, align 8, !tbaa !16
  %579 = load ptr, ptr %540, align 8, !tbaa !24
  %580 = icmp eq ptr %579, null
  br i1 %580, label %582, label %581

581:                                              ; preds = %574
  tail call void @free(ptr noundef nonnull %579) #26
  br label %582

582:                                              ; preds = %574, %581
  store ptr null, ptr %540, align 8, !tbaa !24
  store i64 0, ptr %545, align 8, !tbaa !20
  %583 = getelementptr inbounds nuw i8, ptr %540, i64 16
  store i32 0, ptr %583, align 8, !tbaa !34
  %584 = getelementptr inbounds nuw i8, ptr %540, i64 24
  store <4 x i32> zeroinitializer, ptr %584, align 8, !tbaa !12
  %585 = getelementptr inbounds nuw i8, ptr %540, i64 40
  store i32 0, ptr %585, align 8, !tbaa !33
  %586 = load i32, ptr %452, align 8, !tbaa !32
  %587 = getelementptr inbounds nuw i8, ptr %540, i64 20
  store i32 %586, ptr %587, align 4, !tbaa !35
  %588 = trunc nuw i64 %538 to i32
  store i32 %588, ptr %452, align 8, !tbaa !32
  br label %589

589:                                              ; preds = %537, %544, %582
  %590 = add nuw nsw i64 %538, 1
  %591 = icmp eq i64 %538, %7
  br i1 %591, label %592, label %537, !llvm.loop !114

592:                                              ; preds = %67, %116, %72, %82, %79, %75, %102, %110, %94, %97, %87, %91, %63, %55, %48, %41, %28, %31, %35, %132, %39, %24, %224, %209, %589, %152, %148, %144
  %593 = phi i32 [ 0, %152 ], [ 6, %224 ], [ 6, %144 ], [ 6, %148 ], [ 0, %589 ], [ 6, %209 ], [ 6, %24 ], [ 6, %39 ], [ 6, %132 ], [ 6, %35 ], [ 6, %31 ], [ 6, %28 ], [ 6, %41 ], [ 6, %48 ], [ 6, %55 ], [ 6, %63 ], [ 6, %91 ], [ 6, %87 ], [ 6, %97 ], [ 6, %94 ], [ 6, %110 ], [ 6, %102 ], [ 6, %75 ], [ 6, %79 ], [ 6, %82 ], [ 6, %72 ], [ 6, %116 ], [ 6, %67 ]
  ret i32 %593
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_collect_prepared(ptr nofree noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %48, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !17
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %48

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %9 = load i32, ptr %8, align 4, !tbaa !18
  %10 = icmp eq i32 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %12 = load ptr, ptr %11, align 8, !tbaa !19
  %13 = icmp eq ptr %12, null
  br i1 %10, label %14, label %23

14:                                               ; preds = %7
  br i1 %13, label %15, label %48

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %17 = load i64, ptr %16, align 8, !tbaa !55
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %48

19:                                               ; preds = %15
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %21 = load i64, ptr %20, align 8, !tbaa !31
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %24, label %48

23:                                               ; preds = %7
  br i1 %13, label %48, label %24

24:                                               ; preds = %19, %23
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %26 = load i32, ptr %25, align 4, !tbaa !28
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %48, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %30 = load ptr, ptr %29, align 8, !tbaa !29
  %31 = icmp eq ptr %30, null
  br i1 %31, label %48, label %32

32:                                               ; preds = %28
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %34 = load i32, ptr %33, align 8, !tbaa !30
  %35 = icmp ult i32 %34, %9
  %36 = or i1 %35, %10
  %37 = select i1 %35, i32 6, i32 0
  br i1 %36, label %48, label %38

38:                                               ; preds = %32
  %39 = zext i32 %34 to i64
  %40 = add nuw nsw i64 %39, 1
  %41 = mul nuw nsw i64 %40, 9
  %42 = add nuw nsw i64 %41, 3
  %43 = and i64 %42, 274877906940
  %44 = shl nuw nsw i64 %40, 3
  %45 = getelementptr inbounds nuw i8, ptr %30, i64 %44
  %46 = getelementptr inbounds nuw i8, ptr %30, i64 %43
  %47 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull %0, ptr noundef nonnull %30, ptr noundef nonnull %45, ptr noundef nonnull %46) #25
  br label %48

48:                                               ; preds = %32, %23, %19, %14, %15, %3, %1, %24, %28, %38
  %49 = phi i32 [ 6, %24 ], [ 6, %23 ], [ %47, %38 ], [ %37, %32 ], [ 6, %28 ], [ 6, %1 ], [ 6, %19 ], [ 6, %14 ], [ 6, %15 ], [ 5, %3 ]
  ret i32 %49
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: readwrite)
define range(i32 0, 7) i32 @nms_begin(ptr nofree noundef captures(address_is_null) %0) local_unnamed_addr #11 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %12, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %5 = load i32, ptr %4, align 8, !tbaa !17
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %12

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %9 = load i32, ptr %8, align 4, !tbaa !54
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %7
  store i32 1, ptr %8, align 4, !tbaa !54
  br label %12

12:                                               ; preds = %7, %3, %1, %11
  %13 = phi i32 [ 6, %1 ], [ 5, %3 ], [ 0, %11 ], [ 4, %7 ]
  ret i32 %13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: readwrite)
define range(i64 0, 34359738368) i64 @nms_finish(ptr nofree noundef captures(address_is_null) %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #11 {
  %4 = icmp eq ptr %0, null
  br i1 %4, label %18, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %7 = load i32, ptr %6, align 4, !tbaa !54
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %18, label %9

9:                                                ; preds = %5
  store i32 0, ptr %6, align 4, !tbaa !54
  %10 = icmp ugt i32 %1, 7
  %11 = select i1 %10, i32 6, i32 %1
  %12 = zext nneg i32 %11 to i64
  %13 = shl nuw nsw i64 %12, 32
  %14 = icmp eq i32 %11, 0
  %15 = select i1 %14, i32 %2, i32 0
  %16 = zext i32 %15 to i64
  %17 = or disjoint i64 %13, %16
  br label %18

18:                                               ; preds = %3, %5, %9
  %19 = phi i64 [ %17, %9 ], [ 25769803776, %5 ], [ 25769803776, %3 ]
  ret i64 %19
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_dispose(ptr nofree noundef captures(address_is_null) %0) local_unnamed_addr #3 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %49, label %3

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %5 = load i32, ptr %4, align 4, !tbaa !54
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %49

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %9 = load i32, ptr %8, align 8, !tbaa !17
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %49

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %13 = load i32, ptr %12, align 4, !tbaa !18
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %17, label %15

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 24
  br label %31

17:                                               ; preds = %44, %11
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %19 = load ptr, ptr %18, align 8, !tbaa !19
  %20 = icmp eq ptr %19, null
  br i1 %20, label %22, label %21

21:                                               ; preds = %17
  tail call void @free(ptr noundef nonnull %19) #26
  br label %22

22:                                               ; preds = %17, %21
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %24 = load ptr, ptr %23, align 8, !tbaa !29
  %25 = icmp eq ptr %24, null
  br i1 %25, label %27, label %26

26:                                               ; preds = %22
  tail call void @free(ptr noundef nonnull %24) #26
  br label %27

27:                                               ; preds = %22, %26
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store <2 x i32> zeroinitializer, ptr %28, align 8, !tbaa !12
  store <2 x ptr> splat (ptr null), ptr %18, align 8, !tbaa !15
  store <2 x i32> zeroinitializer, ptr %12, align 4, !tbaa !12
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 48
  store <2 x i64> zeroinitializer, ptr %29, align 8, !tbaa !16
  store ptr null, ptr %0, align 8, !tbaa !8
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store <2 x i32> zeroinitializer, ptr %30, align 8, !tbaa !12
  store i32 1, ptr %8, align 8, !tbaa !17
  br label %49

31:                                               ; preds = %15, %44
  %32 = phi i32 [ %13, %15 ], [ %45, %44 ]
  %33 = phi i64 [ 1, %15 ], [ %46, %44 ]
  %34 = load ptr, ptr %16, align 8, !tbaa !19
  %35 = getelementptr inbounds nuw [48 x i8], ptr %34, i64 %33
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %37 = load i64, ptr %36, align 8, !tbaa !20
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %44, label %39

39:                                               ; preds = %31
  %40 = load ptr, ptr %35, align 8, !tbaa !24
  %41 = icmp eq ptr %40, null
  br i1 %41, label %44, label %42

42:                                               ; preds = %39
  tail call void @free(ptr noundef nonnull %40) #26
  %43 = load i32, ptr %12, align 4, !tbaa !18
  br label %44

44:                                               ; preds = %42, %39, %31
  %45 = phi i32 [ %43, %42 ], [ %32, %39 ], [ %32, %31 ]
  %46 = add nuw nsw i64 %33, 1
  %47 = zext i32 %45 to i64
  %48 = icmp samesign ult i64 %33, %47
  br i1 %48, label %31, label %17, !llvm.loop !115

49:                                               ; preds = %7, %3, %1, %27
  %50 = phi i32 [ 6, %1 ], [ 4, %3 ], [ 0, %27 ], [ 0, %7 ]
  ret i32 %50
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: read)
define range(i32 0, 2) i32 @nms_reserved_entry(ptr nofree noundef readonly captures(address_is_null) %0) local_unnamed_addr #12 {
  %2 = icmp eq ptr %0, null
  br i1 %2, label %180, label %3

3:                                                ; preds = %1
  %4 = load i8, ptr %0, align 1, !tbaa !39
  %5 = icmp eq i8 %4, 110
  br i1 %5, label %6, label %179

6:                                                ; preds = %3
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %8 = load i8, ptr %7, align 1, !tbaa !39
  %9 = icmp eq i8 %8, 97
  br i1 %9, label %10, label %62

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %12 = load i8, ptr %11, align 1, !tbaa !39
  %13 = icmp eq i8 %12, 110
  br i1 %13, label %14, label %62

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %16 = load i8, ptr %15, align 1, !tbaa !39
  %17 = icmp eq i8 %16, 111
  br i1 %17, label %18, label %62

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %20 = load i8, ptr %19, align 1, !tbaa !39
  %21 = icmp eq i8 %20, 95
  br i1 %21, label %22, label %62

22:                                               ; preds = %18
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 5
  %24 = load i8, ptr %23, align 1, !tbaa !39
  %25 = icmp eq i8 %24, 116
  br i1 %25, label %26, label %62

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 6
  %28 = load i8, ptr %27, align 1, !tbaa !39
  %29 = icmp eq i8 %28, 114
  br i1 %29, label %30, label %62

30:                                               ; preds = %26
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 7
  %32 = load i8, ptr %31, align 1, !tbaa !39
  %33 = icmp eq i8 %32, 121
  br i1 %33, label %34, label %62

34:                                               ; preds = %30
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %36 = load i8, ptr %35, align 1, !tbaa !39
  %37 = icmp eq i8 %36, 95
  br i1 %37, label %38, label %62

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %40 = load i8, ptr %39, align 1, !tbaa !39
  %41 = icmp eq i8 %40, 101
  br i1 %41, label %42, label %62

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 10
  %44 = load i8, ptr %43, align 1, !tbaa !39
  %45 = icmp eq i8 %44, 110
  br i1 %45, label %46, label %62

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 11
  %48 = load i8, ptr %47, align 1, !tbaa !39
  %49 = icmp eq i8 %48, 116
  br i1 %49, label %50, label %62

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %52 = load i8, ptr %51, align 1, !tbaa !39
  %53 = icmp eq i8 %52, 114
  br i1 %53, label %54, label %62

54:                                               ; preds = %50
  %55 = getelementptr inbounds nuw i8, ptr %0, i64 13
  %56 = load i8, ptr %55, align 1, !tbaa !39
  %57 = icmp eq i8 %56, 121
  br i1 %57, label %58, label %62

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw i8, ptr %0, i64 14
  %60 = load i8, ptr %59, align 1, !tbaa !39
  %61 = icmp eq i8 %60, 0
  br i1 %61, label %180, label %62

62:                                               ; preds = %58, %54, %50, %46, %42, %38, %34, %30, %26, %22, %18, %14, %10, %6
  %63 = load i8, ptr %0, align 1, !tbaa !39
  %64 = icmp eq i8 %63, 110
  br i1 %64, label %65, label %179

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %67 = load i8, ptr %66, align 1, !tbaa !39
  %68 = icmp eq i8 %67, 97
  br i1 %68, label %69, label %113

69:                                               ; preds = %65
  %70 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %71 = load i8, ptr %70, align 1, !tbaa !39
  %72 = icmp eq i8 %71, 110
  br i1 %72, label %73, label %113

73:                                               ; preds = %69
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %75 = load i8, ptr %74, align 1, !tbaa !39
  %76 = icmp eq i8 %75, 111
  br i1 %76, label %77, label %113

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %79 = load i8, ptr %78, align 1, !tbaa !39
  %80 = icmp eq i8 %79, 95
  br i1 %80, label %81, label %113

81:                                               ; preds = %77
  %82 = getelementptr inbounds nuw i8, ptr %0, i64 5
  %83 = load i8, ptr %82, align 1, !tbaa !39
  %84 = icmp eq i8 %83, 100
  br i1 %84, label %85, label %113

85:                                               ; preds = %81
  %86 = getelementptr inbounds nuw i8, ptr %0, i64 6
  %87 = load i8, ptr %86, align 1, !tbaa !39
  %88 = icmp eq i8 %87, 105
  br i1 %88, label %89, label %113

89:                                               ; preds = %85
  %90 = getelementptr inbounds nuw i8, ptr %0, i64 7
  %91 = load i8, ptr %90, align 1, !tbaa !39
  %92 = icmp eq i8 %91, 115
  br i1 %92, label %93, label %113

93:                                               ; preds = %89
  %94 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %95 = load i8, ptr %94, align 1, !tbaa !39
  %96 = icmp eq i8 %95, 112
  br i1 %96, label %97, label %113

97:                                               ; preds = %93
  %98 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %99 = load i8, ptr %98, align 1, !tbaa !39
  %100 = icmp eq i8 %99, 111
  br i1 %100, label %101, label %113

101:                                              ; preds = %97
  %102 = getelementptr inbounds nuw i8, ptr %0, i64 10
  %103 = load i8, ptr %102, align 1, !tbaa !39
  %104 = icmp eq i8 %103, 115
  br i1 %104, label %105, label %113

105:                                              ; preds = %101
  %106 = getelementptr inbounds nuw i8, ptr %0, i64 11
  %107 = load i8, ptr %106, align 1, !tbaa !39
  %108 = icmp eq i8 %107, 101
  br i1 %108, label %109, label %113

109:                                              ; preds = %105
  %110 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %111 = load i8, ptr %110, align 1, !tbaa !39
  %112 = icmp eq i8 %111, 0
  br i1 %112, label %180, label %113

113:                                              ; preds = %109, %105, %101, %97, %93, %89, %85, %81, %77, %73, %69, %65
  %114 = load i8, ptr %0, align 1, !tbaa !39
  %115 = icmp eq i8 %114, 110
  br i1 %115, label %116, label %179

116:                                              ; preds = %113
  %117 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %118 = load i8, ptr %117, align 1, !tbaa !39
  %119 = icmp eq i8 %118, 97
  br i1 %119, label %120, label %164

120:                                              ; preds = %116
  %121 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %122 = load i8, ptr %121, align 1, !tbaa !39
  %123 = icmp eq i8 %122, 110
  br i1 %123, label %124, label %164

124:                                              ; preds = %120
  %125 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %126 = load i8, ptr %125, align 1, !tbaa !39
  %127 = icmp eq i8 %126, 111
  br i1 %127, label %128, label %164

128:                                              ; preds = %124
  %129 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %130 = load i8, ptr %129, align 1, !tbaa !39
  %131 = icmp eq i8 %130, 95
  br i1 %131, label %132, label %164

132:                                              ; preds = %128
  %133 = getelementptr inbounds nuw i8, ptr %0, i64 5
  %134 = load i8, ptr %133, align 1, !tbaa !39
  %135 = icmp eq i8 %134, 114
  br i1 %135, label %136, label %164

136:                                              ; preds = %132
  %137 = getelementptr inbounds nuw i8, ptr %0, i64 6
  %138 = load i8, ptr %137, align 1, !tbaa !39
  %139 = icmp eq i8 %138, 117
  br i1 %139, label %140, label %164

140:                                              ; preds = %136
  %141 = getelementptr inbounds nuw i8, ptr %0, i64 7
  %142 = load i8, ptr %141, align 1, !tbaa !39
  %143 = icmp eq i8 %142, 110
  br i1 %143, label %144, label %164

144:                                              ; preds = %140
  %145 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %146 = load i8, ptr %145, align 1, !tbaa !39
  %147 = icmp eq i8 %146, 116
  br i1 %147, label %148, label %164

148:                                              ; preds = %144
  %149 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %150 = load i8, ptr %149, align 1, !tbaa !39
  %151 = icmp eq i8 %150, 105
  br i1 %151, label %152, label %164

152:                                              ; preds = %148
  %153 = getelementptr inbounds nuw i8, ptr %0, i64 10
  %154 = load i8, ptr %153, align 1, !tbaa !39
  %155 = icmp eq i8 %154, 109
  br i1 %155, label %156, label %164

156:                                              ; preds = %152
  %157 = getelementptr inbounds nuw i8, ptr %0, i64 11
  %158 = load i8, ptr %157, align 1, !tbaa !39
  %159 = icmp eq i8 %158, 101
  br i1 %159, label %160, label %164

160:                                              ; preds = %156
  %161 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %162 = load i8, ptr %161, align 1, !tbaa !39
  %163 = icmp eq i8 %162, 95
  br i1 %163, label %180, label %164

164:                                              ; preds = %160, %156, %152, %148, %144, %140, %136, %132, %128, %124, %120, %116
  %165 = load i8, ptr %0, align 1, !tbaa !39
  %166 = icmp eq i8 %165, 110
  br i1 %166, label %167, label %179

167:                                              ; preds = %164
  %168 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %169 = load i8, ptr %168, align 1, !tbaa !39
  %170 = icmp eq i8 %169, 109
  br i1 %170, label %171, label %179

171:                                              ; preds = %167
  %172 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %173 = load i8, ptr %172, align 1, !tbaa !39
  %174 = icmp eq i8 %173, 115
  br i1 %174, label %175, label %179

175:                                              ; preds = %171
  %176 = getelementptr inbounds nuw i8, ptr %0, i64 3
  %177 = load i8, ptr %176, align 1, !tbaa !39
  %178 = icmp eq i8 %177, 95
  br i1 %178, label %180, label %179

179:                                              ; preds = %62, %3, %113, %164, %167, %171, %175
  br label %180

180:                                              ; preds = %58, %109, %179, %160, %175, %1
  %181 = phi i32 [ 0, %1 ], [ 1, %58 ], [ 1, %160 ], [ 0, %179 ], [ 1, %109 ], [ 1, %175 ]
  ret i32 %181
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_split_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @split_owned(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef %3, i32 noundef 0) #25
  ret i32 %5
}

; Function Attrs: nounwind ssp
define internal fastcc range(i32 0, 7) i32 @split_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3, i32 noundef range(i32 0, 2) %4) unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %10) #27
  store i64 0, ptr %10, align 8, !tbaa !16
  %11 = icmp ne ptr %3, null
  %12 = icmp ne ptr %0, null
  %13 = and i1 %12, %11
  br i1 %13, label %14, label %265

14:                                               ; preds = %5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %16 = load i32, ptr %15, align 8, !tbaa !17
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %265

18:                                               ; preds = %14
  %19 = icmp sgt i64 %1, -1
  br i1 %19, label %46, label %20

20:                                               ; preds = %18
  %21 = and i64 %1, 9223372036854775807
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %265, label %23

23:                                               ; preds = %20
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %25 = load i32, ptr %24, align 4, !tbaa !18
  %26 = zext i32 %25 to i64
  %27 = icmp samesign ugt i64 %21, %26
  br i1 %27, label %265, label %28

28:                                               ; preds = %23
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %30 = load ptr, ptr %29, align 8, !tbaa !19
  %31 = icmp eq ptr %30, null
  br i1 %31, label %265, label %32

32:                                               ; preds = %28
  %33 = getelementptr inbounds nuw [48 x i8], ptr %30, i64 %21
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !20
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %265, label %37

37:                                               ; preds = %32
  %38 = and i64 %1, 4294967295
  %39 = getelementptr inbounds nuw [48 x i8], ptr %30, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 28
  %41 = load i32, ptr %40, align 4, !tbaa !23
  %42 = icmp eq i32 %41, 1
  br i1 %42, label %43, label %265

43:                                               ; preds = %37
  %44 = load ptr, ptr %39, align 8, !tbaa !24
  %45 = getelementptr inbounds nuw i8, ptr %39, i64 16
  br label %64

46:                                               ; preds = %18
  %47 = icmp eq i64 %1, 0
  br i1 %47, label %265, label %48

48:                                               ; preds = %46
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %50 = load i32, ptr %49, align 8, !tbaa !14
  %51 = zext i32 %50 to i64
  %52 = icmp samesign ugt i64 %1, %51
  br i1 %52, label %265, label %53

53:                                               ; preds = %48
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %55 = load ptr, ptr %54, align 8, !tbaa !13
  %56 = icmp eq ptr %55, null
  br i1 %56, label %265, label %57

57:                                               ; preds = %53
  %58 = getelementptr [16 x i8], ptr %55, i64 %1
  %59 = getelementptr i8, ptr %58, i64 -16
  %60 = load ptr, ptr %59, align 8, !tbaa !25
  %61 = icmp eq ptr %60, null
  br i1 %61, label %265, label %62

62:                                               ; preds = %57
  %63 = getelementptr i8, ptr %58, i64 -8
  br label %64

64:                                               ; preds = %62, %43
  %65 = phi ptr [ %60, %62 ], [ %44, %43 ]
  %66 = phi ptr [ %63, %62 ], [ %45, %43 ]
  %67 = load i32, ptr %66, align 8, !tbaa !12
  %68 = icmp sgt i64 %2, -1
  br i1 %68, label %95, label %69

69:                                               ; preds = %64
  %70 = and i64 %2, 9223372036854775807
  %71 = icmp eq i64 %70, 0
  br i1 %71, label %265, label %72

72:                                               ; preds = %69
  %73 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %74 = load i32, ptr %73, align 4, !tbaa !18
  %75 = zext i32 %74 to i64
  %76 = icmp samesign ugt i64 %70, %75
  br i1 %76, label %265, label %77

77:                                               ; preds = %72
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %79 = load ptr, ptr %78, align 8, !tbaa !19
  %80 = icmp eq ptr %79, null
  br i1 %80, label %265, label %81

81:                                               ; preds = %77
  %82 = getelementptr inbounds nuw [48 x i8], ptr %79, i64 %70
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 8
  %84 = load i64, ptr %83, align 8, !tbaa !20
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %265, label %86

86:                                               ; preds = %81
  %87 = and i64 %2, 4294967295
  %88 = getelementptr inbounds nuw [48 x i8], ptr %79, i64 %87
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 28
  %90 = load i32, ptr %89, align 4, !tbaa !23
  %91 = icmp eq i32 %90, 1
  br i1 %91, label %92, label %265

92:                                               ; preds = %86
  %93 = load ptr, ptr %88, align 8, !tbaa !24
  %94 = getelementptr inbounds nuw i8, ptr %88, i64 16
  br label %113

95:                                               ; preds = %64
  %96 = icmp eq i64 %2, 0
  br i1 %96, label %265, label %97

97:                                               ; preds = %95
  %98 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %99 = load i32, ptr %98, align 8, !tbaa !14
  %100 = zext i32 %99 to i64
  %101 = icmp samesign ugt i64 %2, %100
  br i1 %101, label %265, label %102

102:                                              ; preds = %97
  %103 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %104 = load ptr, ptr %103, align 8, !tbaa !13
  %105 = icmp eq ptr %104, null
  br i1 %105, label %265, label %106

106:                                              ; preds = %102
  %107 = getelementptr [16 x i8], ptr %104, i64 %2
  %108 = getelementptr i8, ptr %107, i64 -16
  %109 = load ptr, ptr %108, align 8, !tbaa !25
  %110 = icmp eq ptr %109, null
  br i1 %110, label %265, label %111

111:                                              ; preds = %106
  %112 = getelementptr i8, ptr %107, i64 -8
  br label %113

113:                                              ; preds = %111, %92
  %114 = phi ptr [ %109, %111 ], [ %93, %92 ]
  %115 = phi ptr [ %112, %111 ], [ %94, %92 ]
  %116 = load i32, ptr %115, align 8, !tbaa !12
  %117 = zext i32 %116 to i64
  %118 = icmp eq i32 %4, 0
  br i1 %118, label %138, label %119

119:                                              ; preds = %113
  %120 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %121 = load i64, ptr %120, align 8, !tbaa !31
  %122 = icmp ugt i64 %121, -129
  br i1 %122, label %265, label %123

123:                                              ; preds = %119
  %124 = tail call dereferenceable_or_null(128) ptr @malloc(i64 noundef 128) #24
  %125 = icmp eq ptr %124, null
  br i1 %125, label %265, label %126

126:                                              ; preds = %123
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  %127 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %124, i32 noundef 0, i32 noundef 8, i32 noundef 3, i64 noundef 128, ptr noundef %6) #25
  %128 = icmp eq i32 %127, 0
  br i1 %128, label %130, label %129

129:                                              ; preds = %126
  tail call void @free(ptr noundef nonnull %124) #26
  br label %137

130:                                              ; preds = %126
  %131 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %132 = load ptr, ptr %131, align 8, !tbaa !19
  %133 = load i64, ptr %6, align 8, !tbaa !16
  %134 = and i64 %133, 4294967295
  %135 = getelementptr inbounds nuw [48 x i8], ptr %132, i64 %134
  %136 = getelementptr inbounds nuw i8, ptr %135, i64 32
  store <2 x i32> <i32 5, i32 1>, ptr %136, align 8, !tbaa !12
  store i64 %133, ptr %10, align 8, !tbaa !16
  br label %137

137:                                              ; preds = %130, %129
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  br label %140

138:                                              ; preds = %113
  %139 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef null, i32 noundef 0, i32 noundef 0, i32 noundef 2, i64 noundef 0, ptr noundef nonnull %10) #25
  br label %140

140:                                              ; preds = %138, %137
  %141 = phi i32 [ %127, %137 ], [ %139, %138 ]
  %142 = icmp ne i32 %141, 0
  %143 = icmp ne i32 %116, 0
  %144 = select i1 %142, i1 true, i1 %143
  br i1 %144, label %189, label %145

145:                                              ; preds = %140
  %146 = icmp eq i32 %67, 0
  br i1 %146, label %265, label %147

147:                                              ; preds = %145
  %148 = load i64, ptr %10, align 8, !tbaa !16
  %149 = icmp eq ptr %65, null
  %150 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %151 = zext i32 %67 to i64
  br label %152

152:                                              ; preds = %147, %180
  %153 = phi i64 [ 0, %147 ], [ %185, %180 ]
  %154 = getelementptr inbounds nuw i8, ptr %65, i64 %153
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #27
  store i64 0, ptr %9, align 8, !tbaa !16
  br i1 %149, label %178, label %155

155:                                              ; preds = %152
  %156 = load i32, ptr %15, align 8, !tbaa !17
  %157 = icmp eq i32 %156, 0
  br i1 %157, label %158, label %178

158:                                              ; preds = %155
  %159 = load i64, ptr %150, align 8, !tbaa !31
  %160 = icmp eq i64 %159, -1
  br i1 %160, label %178, label %161

161:                                              ; preds = %158
  %162 = tail call dereferenceable_or_null(2) ptr @malloc(i64 noundef 2) #24
  %163 = icmp eq ptr %162, null
  br i1 %163, label %178, label %164

164:                                              ; preds = %161
  %165 = load volatile i8, ptr %154, align 1, !tbaa !39
  store volatile i8 %165, ptr %162, align 1, !tbaa !39
  %166 = getelementptr inbounds nuw i8, ptr %162, i64 1
  store i8 0, ptr %166, align 1, !tbaa !39
  %167 = call fastcc i32 @publish_slot(ptr noundef %0, ptr noundef nonnull %162, i32 noundef 1, i32 noundef 0, i32 noundef 1, i64 noundef 1, ptr noundef nonnull %9) #25
  %168 = icmp eq i32 %167, 0
  br i1 %168, label %170, label %169

169:                                              ; preds = %164
  tail call void @free(ptr noundef nonnull %162) #26
  br label %178

170:                                              ; preds = %164
  %171 = load i64, ptr %9, align 8, !tbaa !16
  br i1 %118, label %176, label %172

172:                                              ; preds = %170
  %173 = insertvalue [2 x i64] poison, i64 %171, 0
  %174 = insertvalue [2 x i64] %173, i64 5, 1
  %175 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %148, i64 noundef 0, [2 x i64] %174, i32 noundef 1) #25
  br label %180

176:                                              ; preds = %170
  %177 = tail call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %148, i64 noundef %171) #25
  br label %180

178:                                              ; preds = %158, %161, %155, %152, %169
  %179 = phi i32 [ %167, %169 ], [ 3, %158 ], [ 3, %161 ], [ 5, %155 ], [ 6, %152 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #27
  br label %265

180:                                              ; preds = %172, %176
  %181 = phi i32 [ %175, %172 ], [ %177, %176 ]
  %182 = tail call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %171) #25
  %183 = icmp eq i32 %181, 0
  %184 = select i1 %183, i32 %182, i32 %181
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #27
  %185 = add nuw nsw i64 %153, 1
  %186 = icmp samesign ult i64 %185, %151
  %187 = icmp eq i32 %184, 0
  %188 = select i1 %186, i1 %187, i1 false
  br i1 %188, label %152, label %265, !llvm.loop !116

189:                                              ; preds = %140
  %190 = icmp eq i32 %141, 0
  br i1 %190, label %191, label %265

191:                                              ; preds = %189
  %192 = icmp eq i32 %116, 0
  %193 = sub i32 %67, %116
  %194 = load i64, ptr %10, align 8
  br label %195

195:                                              ; preds = %191, %237
  %196 = phi i32 [ 0, %191 ], [ %242, %237 ]
  %197 = icmp ugt i32 %196, %67
  %198 = select i1 %192, i1 true, i1 %197
  %199 = sub i32 %67, %196
  %200 = icmp ult i32 %199, %116
  %201 = icmp ugt i32 %196, %193
  %202 = or i1 %200, %201
  %203 = select i1 %198, i1 true, i1 %202
  br i1 %203, label %244, label %204

204:                                              ; preds = %195, %218
  %205 = phi i32 [ %219, %218 ], [ %196, %195 ]
  %206 = zext i32 %205 to i64
  %207 = getelementptr inbounds nuw i8, ptr %65, i64 %206
  br label %211

208:                                              ; preds = %211
  %209 = add nuw nsw i64 %212, 1
  %210 = icmp eq i64 %209, %117
  br i1 %210, label %221, label %211, !llvm.loop !117

211:                                              ; preds = %208, %204
  %212 = phi i64 [ 0, %204 ], [ %209, %208 ]
  %213 = getelementptr inbounds nuw i8, ptr %207, i64 %212
  %214 = load i8, ptr %213, align 1, !tbaa !39
  %215 = getelementptr inbounds nuw i8, ptr %114, i64 %212
  %216 = load i8, ptr %215, align 1, !tbaa !39
  %217 = icmp eq i8 %214, %216
  br i1 %217, label %208, label %218

218:                                              ; preds = %211
  %219 = add i32 %205, 1
  %220 = icmp ugt i32 %219, %193
  br i1 %220, label %244, label %204, !llvm.loop !118

221:                                              ; preds = %208
  %222 = zext i32 %196 to i64
  %223 = getelementptr inbounds nuw i8, ptr %65, i64 %222
  %224 = sub i32 %205, %196
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #27
  store i64 0, ptr %8, align 8, !tbaa !16
  %225 = zext i32 %224 to i64
  %226 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %223, i64 noundef %225, ptr noundef null, i64 noundef 0, ptr noundef nonnull %8) #25
  %227 = icmp eq i32 %226, 0
  br i1 %227, label %229, label %228

228:                                              ; preds = %221
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #27
  br label %265

229:                                              ; preds = %221
  %230 = load i64, ptr %8, align 8, !tbaa !16
  br i1 %118, label %235, label %231

231:                                              ; preds = %229
  %232 = insertvalue [2 x i64] poison, i64 %230, 0
  %233 = insertvalue [2 x i64] %232, i64 5, 1
  %234 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %194, i64 noundef 0, [2 x i64] %233, i32 noundef 1) #25
  br label %237

235:                                              ; preds = %229
  %236 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %194, i64 noundef %230) #25
  br label %237

237:                                              ; preds = %231, %235
  %238 = phi i32 [ %234, %231 ], [ %236, %235 ]
  %239 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %230) #25
  %240 = icmp eq i32 %238, 0
  %241 = select i1 %240, i32 %239, i32 %238
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #27
  %242 = add i32 %205, %116
  %243 = icmp eq i32 %241, 0
  br i1 %243, label %195, label %265, !llvm.loop !119

244:                                              ; preds = %195, %218
  %245 = zext i32 %196 to i64
  %246 = getelementptr inbounds nuw i8, ptr %65, i64 %245
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #27
  store i64 0, ptr %7, align 8, !tbaa !16
  %247 = zext i32 %199 to i64
  %248 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %246, i64 noundef %247, ptr noundef null, i64 noundef 0, ptr noundef nonnull %7) #25
  %249 = icmp eq i32 %248, 0
  br i1 %249, label %250, label %263

250:                                              ; preds = %244
  %251 = load i64, ptr %7, align 8, !tbaa !16
  br i1 %118, label %256, label %252

252:                                              ; preds = %250
  %253 = insertvalue [2 x i64] poison, i64 %251, 0
  %254 = insertvalue [2 x i64] %253, i64 5, 1
  %255 = call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull %0, i64 noundef %194, i64 noundef 0, [2 x i64] %254, i32 noundef 1) #25
  br label %258

256:                                              ; preds = %250
  %257 = call i32 @nms_string_array_append(ptr noundef nonnull %0, i64 noundef %194, i64 noundef %251) #25
  br label %258

258:                                              ; preds = %256, %252
  %259 = phi i32 [ %255, %252 ], [ %257, %256 ]
  %260 = call i32 @nms_release(ptr noundef nonnull %0, i64 noundef %251) #25
  %261 = icmp eq i32 %259, 0
  %262 = select i1 %261, i32 %260, i32 %259
  br label %263

263:                                              ; preds = %244, %258
  %264 = phi i32 [ %262, %258 ], [ %248, %244 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #27
  br label %265

265:                                              ; preds = %180, %237, %178, %228, %145, %119, %123, %106, %81, %95, %102, %97, %77, %86, %69, %72, %5, %57, %32, %14, %46, %53, %48, %28, %37, %20, %23, %263, %189
  %266 = phi i32 [ 6, %5 ], [ %141, %189 ], [ 6, %32 ], [ %264, %263 ], [ 6, %57 ], [ 0, %145 ], [ 3, %123 ], [ 3, %119 ], [ 6, %72 ], [ 6, %69 ], [ 1, %86 ], [ 6, %77 ], [ 6, %97 ], [ 6, %102 ], [ 6, %95 ], [ %241, %237 ], [ 6, %81 ], [ 6, %106 ], [ 6, %23 ], [ 6, %20 ], [ 1, %37 ], [ 6, %28 ], [ 6, %48 ], [ 6, %53 ], [ 6, %46 ], [ 5, %14 ], [ %226, %228 ], [ %179, %178 ], [ %184, %180 ]
  %267 = freeze i32 %266
  %268 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #25
  %269 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #25
  %270 = icmp eq i32 %267, 0
  %271 = icmp eq i32 %268, 0
  %272 = select i1 %271, i32 %269, i32 %268
  %273 = select i1 %270, i32 %272, i32 %267
  %274 = icmp eq i32 %273, 0
  %275 = load i64, ptr %10, align 8, !tbaa !16
  br i1 %274, label %280, label %276

276:                                              ; preds = %265
  %277 = icmp eq i64 %275, 0
  br i1 %277, label %281, label %278

278:                                              ; preds = %276
  %279 = call i32 @nms_release(ptr noundef %0, i64 noundef %275) #25
  br label %281

280:                                              ; preds = %265
  store i64 %275, ptr %3, align 8, !tbaa !16
  br label %281

281:                                              ; preds = %276, %278, %280
  call void @llvm.lifetime.end.p0(ptr nonnull %10) #27
  ret i32 %273
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_split_values_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = tail call fastcc i32 @split_owned(ptr noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef %3, i32 noundef 1) #25
  ret i32 %5
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_replace_owned(ptr nofree noundef captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i64 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  %7 = icmp ne ptr %4, null
  %8 = icmp ne ptr %0, null
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %396

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %12 = load i32, ptr %11, align 8, !tbaa !17
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %396

14:                                               ; preds = %10
  %15 = icmp sgt i64 %1, -1
  br i1 %15, label %42, label %16

16:                                               ; preds = %14
  %17 = and i64 %1, 9223372036854775807
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %396, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %21 = load i32, ptr %20, align 4, !tbaa !18
  %22 = zext i32 %21 to i64
  %23 = icmp samesign ugt i64 %17, %22
  br i1 %23, label %396, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !19
  %27 = icmp eq ptr %26, null
  br i1 %27, label %396, label %28

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw [48 x i8], ptr %26, i64 %17
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !20
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %396, label %33

33:                                               ; preds = %28
  %34 = and i64 %1, 4294967295
  %35 = getelementptr inbounds nuw [48 x i8], ptr %26, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 28
  %37 = load i32, ptr %36, align 4, !tbaa !23
  %38 = icmp eq i32 %37, 1
  br i1 %38, label %39, label %396

39:                                               ; preds = %33
  %40 = load ptr, ptr %35, align 8, !tbaa !24
  %41 = getelementptr inbounds nuw i8, ptr %35, i64 16
  br label %60

42:                                               ; preds = %14
  %43 = icmp eq i64 %1, 0
  br i1 %43, label %396, label %44

44:                                               ; preds = %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %46 = load i32, ptr %45, align 8, !tbaa !14
  %47 = zext i32 %46 to i64
  %48 = icmp samesign ugt i64 %1, %47
  br i1 %48, label %396, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %51 = load ptr, ptr %50, align 8, !tbaa !13
  %52 = icmp eq ptr %51, null
  br i1 %52, label %396, label %53

53:                                               ; preds = %49
  %54 = getelementptr [16 x i8], ptr %51, i64 %1
  %55 = getelementptr i8, ptr %54, i64 -16
  %56 = load ptr, ptr %55, align 8, !tbaa !25
  %57 = icmp eq ptr %56, null
  br i1 %57, label %396, label %58

58:                                               ; preds = %53
  %59 = getelementptr i8, ptr %54, i64 -8
  br label %60

60:                                               ; preds = %58, %39
  %61 = phi ptr [ %56, %58 ], [ %40, %39 ]
  %62 = phi ptr [ %59, %58 ], [ %41, %39 ]
  %63 = load i32, ptr %62, align 8, !tbaa !12
  %64 = icmp sgt i64 %2, -1
  br i1 %64, label %91, label %65

65:                                               ; preds = %60
  %66 = and i64 %2, 9223372036854775807
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %396, label %68

68:                                               ; preds = %65
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %70 = load i32, ptr %69, align 4, !tbaa !18
  %71 = zext i32 %70 to i64
  %72 = icmp samesign ugt i64 %66, %71
  br i1 %72, label %396, label %73

73:                                               ; preds = %68
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %75 = load ptr, ptr %74, align 8, !tbaa !19
  %76 = icmp eq ptr %75, null
  br i1 %76, label %396, label %77

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw [48 x i8], ptr %75, i64 %66
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 8
  %80 = load i64, ptr %79, align 8, !tbaa !20
  %81 = icmp eq i64 %80, 0
  br i1 %81, label %396, label %82

82:                                               ; preds = %77
  %83 = and i64 %2, 4294967295
  %84 = getelementptr inbounds nuw [48 x i8], ptr %75, i64 %83
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 28
  %86 = load i32, ptr %85, align 4, !tbaa !23
  %87 = icmp eq i32 %86, 1
  br i1 %87, label %88, label %396

88:                                               ; preds = %82
  %89 = load ptr, ptr %84, align 8, !tbaa !24
  %90 = getelementptr inbounds nuw i8, ptr %84, i64 16
  br label %109

91:                                               ; preds = %60
  %92 = icmp eq i64 %2, 0
  br i1 %92, label %396, label %93

93:                                               ; preds = %91
  %94 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %95 = load i32, ptr %94, align 8, !tbaa !14
  %96 = zext i32 %95 to i64
  %97 = icmp samesign ugt i64 %2, %96
  br i1 %97, label %396, label %98

98:                                               ; preds = %93
  %99 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %100 = load ptr, ptr %99, align 8, !tbaa !13
  %101 = icmp eq ptr %100, null
  br i1 %101, label %396, label %102

102:                                              ; preds = %98
  %103 = getelementptr [16 x i8], ptr %100, i64 %2
  %104 = getelementptr i8, ptr %103, i64 -16
  %105 = load ptr, ptr %104, align 8, !tbaa !25
  %106 = icmp eq ptr %105, null
  br i1 %106, label %396, label %107

107:                                              ; preds = %102
  %108 = getelementptr i8, ptr %103, i64 -8
  br label %109

109:                                              ; preds = %107, %88
  %110 = phi ptr [ %105, %107 ], [ %89, %88 ]
  %111 = phi ptr [ %108, %107 ], [ %90, %88 ]
  %112 = load i32, ptr %111, align 8, !tbaa !12
  %113 = zext i32 %112 to i64
  %114 = icmp sgt i64 %3, -1
  br i1 %114, label %141, label %115

115:                                              ; preds = %109
  %116 = and i64 %3, 9223372036854775807
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %396, label %118

118:                                              ; preds = %115
  %119 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %120 = load i32, ptr %119, align 4, !tbaa !18
  %121 = zext i32 %120 to i64
  %122 = icmp samesign ugt i64 %116, %121
  br i1 %122, label %396, label %123

123:                                              ; preds = %118
  %124 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %125 = load ptr, ptr %124, align 8, !tbaa !19
  %126 = icmp eq ptr %125, null
  br i1 %126, label %396, label %127

127:                                              ; preds = %123
  %128 = getelementptr inbounds nuw [48 x i8], ptr %125, i64 %116
  %129 = getelementptr inbounds nuw i8, ptr %128, i64 8
  %130 = load i64, ptr %129, align 8, !tbaa !20
  %131 = icmp eq i64 %130, 0
  br i1 %131, label %396, label %132

132:                                              ; preds = %127
  %133 = and i64 %3, 4294967295
  %134 = getelementptr inbounds nuw [48 x i8], ptr %125, i64 %133
  %135 = getelementptr inbounds nuw i8, ptr %134, i64 28
  %136 = load i32, ptr %135, align 4, !tbaa !23
  %137 = icmp eq i32 %136, 1
  br i1 %137, label %138, label %396

138:                                              ; preds = %132
  %139 = load ptr, ptr %134, align 8, !tbaa !24
  %140 = getelementptr inbounds nuw i8, ptr %134, i64 16
  br label %159

141:                                              ; preds = %109
  %142 = icmp eq i64 %3, 0
  br i1 %142, label %396, label %143

143:                                              ; preds = %141
  %144 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %145 = load i32, ptr %144, align 8, !tbaa !14
  %146 = zext i32 %145 to i64
  %147 = icmp samesign ugt i64 %3, %146
  br i1 %147, label %396, label %148

148:                                              ; preds = %143
  %149 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %150 = load ptr, ptr %149, align 8, !tbaa !13
  %151 = icmp eq ptr %150, null
  br i1 %151, label %396, label %152

152:                                              ; preds = %148
  %153 = getelementptr [16 x i8], ptr %150, i64 %3
  %154 = getelementptr i8, ptr %153, i64 -16
  %155 = load ptr, ptr %154, align 8, !tbaa !25
  %156 = icmp eq ptr %155, null
  br i1 %156, label %396, label %157

157:                                              ; preds = %152
  %158 = getelementptr i8, ptr %153, i64 -8
  br label %159

159:                                              ; preds = %138, %157
  %160 = phi ptr [ %155, %157 ], [ %139, %138 ]
  %161 = phi ptr [ %158, %157 ], [ %140, %138 ]
  %162 = load i32, ptr %161, align 8, !tbaa !12
  %163 = freeze i32 %162
  %164 = icmp eq i32 %112, 0
  br i1 %164, label %169, label %165

165:                                              ; preds = %159
  %166 = icmp ult i32 %63, %112
  br i1 %166, label %205, label %167

167:                                              ; preds = %165
  %168 = sub nuw i32 %63, %112
  br label %172

169:                                              ; preds = %159
  %170 = zext i32 %63 to i64
  %171 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef %61, i64 noundef %170, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #25
  br label %396

172:                                              ; preds = %167, %193
  %173 = phi i64 [ 0, %167 ], [ %194, %193 ]
  %174 = phi i32 [ 0, %167 ], [ %195, %193 ]
  %175 = icmp ugt i32 %174, %168
  br i1 %175, label %200, label %176

176:                                              ; preds = %172, %190
  %177 = phi i32 [ %191, %190 ], [ %174, %172 ]
  %178 = zext i32 %177 to i64
  %179 = getelementptr inbounds nuw i8, ptr %61, i64 %178
  br label %183

180:                                              ; preds = %183
  %181 = add nuw nsw i64 %184, 1
  %182 = icmp eq i64 %181, %113
  br i1 %182, label %193, label %183, !llvm.loop !117

183:                                              ; preds = %180, %176
  %184 = phi i64 [ 0, %176 ], [ %181, %180 ]
  %185 = getelementptr inbounds nuw i8, ptr %179, i64 %184
  %186 = load i8, ptr %185, align 1, !tbaa !39
  %187 = getelementptr inbounds nuw i8, ptr %110, i64 %184
  %188 = load i8, ptr %187, align 1, !tbaa !39
  %189 = icmp eq i8 %186, %188
  br i1 %189, label %180, label %190

190:                                              ; preds = %183
  %191 = add nuw i32 %177, 1
  %192 = icmp ult i32 %177, %168
  br i1 %192, label %176, label %200, !llvm.loop !118

193:                                              ; preds = %180
  %194 = add i64 %173, 1
  %195 = add i32 %177, %112
  %196 = icmp ugt i32 %195, %63
  %197 = sub nuw i32 %63, %195
  %198 = icmp ult i32 %197, %112
  %199 = select i1 %196, i1 true, i1 %198
  br i1 %199, label %200, label %172, !llvm.loop !120

200:                                              ; preds = %172, %193, %190
  %201 = phi i64 [ %173, %190 ], [ %194, %193 ], [ %173, %172 ]
  %202 = udiv i32 %63, %112
  %203 = zext i32 %202 to i64
  %204 = icmp ugt i64 %201, %203
  br i1 %204, label %396, label %205

205:                                              ; preds = %165, %200
  %206 = phi i64 [ %201, %200 ], [ 0, %165 ]
  %207 = trunc nuw i64 %206 to i32
  %208 = mul i32 %112, %207
  %209 = sub i32 %63, %208
  %210 = icmp eq i32 %163, 0
  br i1 %210, label %216, label %211

211:                                              ; preds = %205
  %212 = xor i32 %209, -1
  %213 = udiv i32 %212, %163
  %214 = zext i32 %213 to i64
  %215 = icmp samesign ugt i64 %206, %214
  br i1 %215, label %396, label %216

216:                                              ; preds = %211, %205
  %217 = mul i32 %163, %207
  %218 = add i32 %209, %217
  %219 = zext i32 %218 to i64
  %220 = add nuw nsw i64 %219, 1
  %221 = tail call ptr @malloc(i64 noundef %220) #24
  %222 = icmp eq ptr %221, null
  br i1 %222, label %396, label %223

223:                                              ; preds = %216
  br i1 %166, label %344, label %224

224:                                              ; preds = %223
  %225 = sub nuw i32 %63, %112
  %226 = zext i32 %163 to i64
  %227 = add nsw i64 %226, -1
  %228 = urem i64 %227, 3
  %229 = add nuw nsw i64 %228, 1
  %230 = icmp ne i64 %229, 3
  %231 = select i1 %230, i64 %229, i64 0
  %232 = icmp ult i32 %163, 3
  %233 = sub nsw i64 %226, %231
  br label %234

234:                                              ; preds = %224, %337
  %235 = phi i32 [ %63, %224 ], [ %341, %337 ]
  %236 = phi i32 [ 0, %224 ], [ %338, %337 ]
  %237 = phi i32 [ 0, %224 ], [ %339, %337 ]
  %238 = icmp ugt i32 %237, %225
  br i1 %238, label %344, label %239

239:                                              ; preds = %234, %253
  %240 = phi i32 [ %254, %253 ], [ %237, %234 ]
  %241 = zext i32 %240 to i64
  %242 = getelementptr inbounds nuw i8, ptr %61, i64 %241
  br label %246

243:                                              ; preds = %246
  %244 = add nuw nsw i64 %247, 1
  %245 = icmp eq i64 %244, %113
  br i1 %245, label %256, label %246, !llvm.loop !117

246:                                              ; preds = %243, %239
  %247 = phi i64 [ 0, %239 ], [ %244, %243 ]
  %248 = getelementptr inbounds nuw i8, ptr %242, i64 %247
  %249 = load i8, ptr %248, align 1, !tbaa !39
  %250 = getelementptr inbounds nuw i8, ptr %110, i64 %247
  %251 = load i8, ptr %250, align 1, !tbaa !39
  %252 = icmp eq i8 %249, %251
  br i1 %252, label %243, label %253

253:                                              ; preds = %246
  %254 = add nuw i32 %240, 1
  %255 = icmp ult i32 %240, %225
  br i1 %255, label %239, label %344, !llvm.loop !118

256:                                              ; preds = %243
  %257 = sub i32 %240, %237
  %258 = freeze i32 %257
  %259 = zext i32 %236 to i64
  %260 = getelementptr inbounds nuw i8, ptr %221, i64 %259
  %261 = zext i32 %237 to i64
  %262 = getelementptr inbounds nuw i8, ptr %61, i64 %261
  %263 = icmp eq i32 %240, %237
  br i1 %263, label %303, label %264

264:                                              ; preds = %256
  %265 = zext i32 %258 to i64
  %266 = add nsw i64 %265, -1
  %267 = urem i64 %266, 3
  %268 = add nuw nsw i64 %267, 1
  %269 = icmp ne i64 %268, 3
  %270 = select i1 %269, i64 %268, i64 0
  %271 = icmp ult i32 %258, 3
  br i1 %271, label %292, label %272

272:                                              ; preds = %264
  %273 = sub nsw i64 %265, %270
  br label %274

274:                                              ; preds = %274, %272
  %275 = phi i64 [ 0, %272 ], [ %288, %274 ]
  %276 = phi i64 [ 0, %272 ], [ %289, %274 ]
  %277 = getelementptr inbounds nuw i8, ptr %262, i64 %275
  %278 = load volatile i8, ptr %277, align 1, !tbaa !39
  %279 = getelementptr inbounds nuw i8, ptr %260, i64 %275
  store volatile i8 %278, ptr %279, align 1, !tbaa !39
  %280 = add nuw nsw i64 %275, 1
  %281 = getelementptr inbounds nuw i8, ptr %262, i64 %280
  %282 = load volatile i8, ptr %281, align 1, !tbaa !39
  %283 = getelementptr inbounds nuw i8, ptr %260, i64 %280
  store volatile i8 %282, ptr %283, align 1, !tbaa !39
  %284 = add nuw nsw i64 %275, 2
  %285 = getelementptr inbounds nuw i8, ptr %262, i64 %284
  %286 = load volatile i8, ptr %285, align 1, !tbaa !39
  %287 = getelementptr inbounds nuw i8, ptr %260, i64 %284
  store volatile i8 %286, ptr %287, align 1, !tbaa !39
  %288 = add nuw nsw i64 %275, 3
  %289 = add i64 %276, 3
  %290 = icmp eq i64 %289, %273
  br i1 %290, label %291, label %274, !llvm.loop !40

291:                                              ; preds = %274
  br i1 %269, label %292, label %303

292:                                              ; preds = %291, %264
  %293 = phi i64 [ 0, %264 ], [ %288, %291 ]
  tail call void @llvm.assume(i1 %269)
  br label %294

294:                                              ; preds = %294, %292
  %295 = phi i64 [ %300, %294 ], [ %293, %292 ]
  %296 = phi i64 [ %301, %294 ], [ 0, %292 ]
  %297 = getelementptr inbounds nuw i8, ptr %262, i64 %295
  %298 = load volatile i8, ptr %297, align 1, !tbaa !39
  %299 = getelementptr inbounds nuw i8, ptr %260, i64 %295
  store volatile i8 %298, ptr %299, align 1, !tbaa !39
  %300 = add nuw nsw i64 %295, 1
  %301 = add i64 %296, 1
  %302 = icmp eq i64 %301, %270
  br i1 %302, label %303, label %294, !llvm.loop !121

303:                                              ; preds = %291, %294, %256
  %304 = add i32 %258, %236
  %305 = zext i32 %304 to i64
  %306 = getelementptr inbounds nuw i8, ptr %221, i64 %305
  br i1 %210, label %337, label %307

307:                                              ; preds = %303
  br i1 %232, label %326, label %308

308:                                              ; preds = %307, %308
  %309 = phi i64 [ %322, %308 ], [ 0, %307 ]
  %310 = phi i64 [ %323, %308 ], [ 0, %307 ]
  %311 = getelementptr inbounds nuw i8, ptr %160, i64 %309
  %312 = load volatile i8, ptr %311, align 1, !tbaa !39
  %313 = getelementptr inbounds nuw i8, ptr %306, i64 %309
  store volatile i8 %312, ptr %313, align 1, !tbaa !39
  %314 = add nuw nsw i64 %309, 1
  %315 = getelementptr inbounds nuw i8, ptr %160, i64 %314
  %316 = load volatile i8, ptr %315, align 1, !tbaa !39
  %317 = getelementptr inbounds nuw i8, ptr %306, i64 %314
  store volatile i8 %316, ptr %317, align 1, !tbaa !39
  %318 = add nuw nsw i64 %309, 2
  %319 = getelementptr inbounds nuw i8, ptr %160, i64 %318
  %320 = load volatile i8, ptr %319, align 1, !tbaa !39
  %321 = getelementptr inbounds nuw i8, ptr %306, i64 %318
  store volatile i8 %320, ptr %321, align 1, !tbaa !39
  %322 = add nuw nsw i64 %309, 3
  %323 = add i64 %310, 3
  %324 = icmp eq i64 %323, %233
  br i1 %324, label %325, label %308, !llvm.loop !40

325:                                              ; preds = %308
  br i1 %230, label %326, label %337

326:                                              ; preds = %325, %307
  %327 = phi i64 [ 0, %307 ], [ %322, %325 ]
  tail call void @llvm.assume(i1 %230)
  br label %328

328:                                              ; preds = %328, %326
  %329 = phi i64 [ %334, %328 ], [ %327, %326 ]
  %330 = phi i64 [ %335, %328 ], [ 0, %326 ]
  %331 = getelementptr inbounds nuw i8, ptr %160, i64 %329
  %332 = load volatile i8, ptr %331, align 1, !tbaa !39
  %333 = getelementptr inbounds nuw i8, ptr %306, i64 %329
  store volatile i8 %332, ptr %333, align 1, !tbaa !39
  %334 = add nuw nsw i64 %329, 1
  %335 = add i64 %330, 1
  %336 = icmp eq i64 %335, %231
  br i1 %336, label %337, label %328, !llvm.loop !122

337:                                              ; preds = %325, %328, %303
  %338 = add i32 %304, %163
  %339 = add i32 %240, %112
  %340 = icmp ugt i32 %339, %63
  %341 = sub i32 %63, %339
  %342 = icmp ult i32 %341, %112
  %343 = or i1 %340, %342
  br i1 %343, label %344, label %234, !llvm.loop !123

344:                                              ; preds = %234, %337, %253, %223
  %345 = phi i32 [ %237, %253 ], [ 0, %223 ], [ %237, %234 ], [ %339, %337 ]
  %346 = phi i32 [ %236, %253 ], [ 0, %223 ], [ %236, %234 ], [ %338, %337 ]
  %347 = phi i32 [ %235, %253 ], [ %63, %223 ], [ %235, %234 ], [ %341, %337 ]
  %348 = zext i32 %346 to i64
  %349 = getelementptr inbounds nuw i8, ptr %221, i64 %348
  %350 = zext i32 %345 to i64
  %351 = getelementptr inbounds nuw i8, ptr %61, i64 %350
  %352 = icmp eq i32 %63, %345
  br i1 %352, label %393, label %353

353:                                              ; preds = %344
  %354 = freeze i32 %347
  %355 = zext i32 %354 to i64
  %356 = add nsw i64 %355, -1
  %357 = urem i64 %356, 3
  %358 = add nuw nsw i64 %357, 1
  %359 = icmp ne i64 %358, 3
  %360 = select i1 %359, i64 %358, i64 0
  %361 = icmp ult i64 %356, 2
  br i1 %361, label %382, label %362

362:                                              ; preds = %353
  %363 = sub nsw i64 %355, %360
  br label %364

364:                                              ; preds = %364, %362
  %365 = phi i64 [ 0, %362 ], [ %378, %364 ]
  %366 = phi i64 [ 0, %362 ], [ %379, %364 ]
  %367 = getelementptr inbounds nuw i8, ptr %351, i64 %365
  %368 = load volatile i8, ptr %367, align 1, !tbaa !39
  %369 = getelementptr inbounds nuw i8, ptr %349, i64 %365
  store volatile i8 %368, ptr %369, align 1, !tbaa !39
  %370 = add nuw nsw i64 %365, 1
  %371 = getelementptr inbounds nuw i8, ptr %351, i64 %370
  %372 = load volatile i8, ptr %371, align 1, !tbaa !39
  %373 = getelementptr inbounds nuw i8, ptr %349, i64 %370
  store volatile i8 %372, ptr %373, align 1, !tbaa !39
  %374 = add nuw nsw i64 %365, 2
  %375 = getelementptr inbounds nuw i8, ptr %351, i64 %374
  %376 = load volatile i8, ptr %375, align 1, !tbaa !39
  %377 = getelementptr inbounds nuw i8, ptr %349, i64 %374
  store volatile i8 %376, ptr %377, align 1, !tbaa !39
  %378 = add nuw nsw i64 %365, 3
  %379 = add i64 %366, 3
  %380 = icmp eq i64 %379, %363
  br i1 %380, label %381, label %364, !llvm.loop !40

381:                                              ; preds = %364
  br i1 %359, label %382, label %393

382:                                              ; preds = %381, %353
  %383 = phi i64 [ 0, %353 ], [ %378, %381 ]
  tail call void @llvm.assume(i1 %359)
  br label %384

384:                                              ; preds = %384, %382
  %385 = phi i64 [ %390, %384 ], [ %383, %382 ]
  %386 = phi i64 [ %391, %384 ], [ 0, %382 ]
  %387 = getelementptr inbounds nuw i8, ptr %351, i64 %385
  %388 = load volatile i8, ptr %387, align 1, !tbaa !39
  %389 = getelementptr inbounds nuw i8, ptr %349, i64 %385
  store volatile i8 %388, ptr %389, align 1, !tbaa !39
  %390 = add nuw nsw i64 %385, 1
  %391 = add i64 %386, 1
  %392 = icmp eq i64 %391, %360
  br i1 %392, label %393, label %384, !llvm.loop !124

393:                                              ; preds = %381, %384, %344
  %394 = getelementptr inbounds nuw i8, ptr %221, i64 %219
  store i8 0, ptr %394, align 1, !tbaa !39
  %395 = call fastcc range(i32 0, 7) i32 @create_parts(ptr noundef nonnull %0, ptr noundef nonnull %221, i64 noundef %219, ptr noundef null, i64 noundef 0, ptr noundef nonnull %6) #25
  call void @free(ptr noundef nonnull %221) #26
  br label %396

396:                                              ; preds = %118, %115, %132, %123, %143, %148, %141, %127, %152, %102, %77, %91, %98, %93, %73, %82, %65, %68, %5, %53, %28, %10, %42, %49, %44, %24, %33, %16, %19, %216, %211, %200, %169, %393
  %397 = phi i32 [ %395, %393 ], [ %171, %169 ], [ 3, %216 ], [ 6, %200 ], [ 3, %211 ], [ 6, %118 ], [ 6, %115 ], [ 1, %132 ], [ 6, %123 ], [ 6, %143 ], [ 6, %148 ], [ 6, %141 ], [ 6, %53 ], [ 6, %127 ], [ 6, %152 ], [ 6, %68 ], [ 6, %65 ], [ 1, %82 ], [ 6, %73 ], [ 6, %93 ], [ 6, %98 ], [ 6, %91 ], [ 6, %5 ], [ 6, %77 ], [ 6, %102 ], [ 6, %19 ], [ 6, %16 ], [ 1, %33 ], [ 6, %24 ], [ 6, %44 ], [ 6, %49 ], [ 6, %42 ], [ 5, %10 ], [ 6, %28 ]
  %398 = call i32 @nms_release(ptr noundef %0, i64 noundef %1) #25
  %399 = call i32 @nms_release(ptr noundef %0, i64 noundef %2) #25
  %400 = call i32 @nms_release(ptr noundef %0, i64 noundef %3) #25
  %401 = icmp eq i32 %397, 0
  br i1 %401, label %402, label %414

402:                                              ; preds = %396
  %403 = icmp ne i32 %398, 0
  %404 = icmp ne i32 %399, 0
  %405 = select i1 %403, i1 true, i1 %404
  %406 = icmp ne i32 %400, 0
  %407 = select i1 %405, i1 true, i1 %406
  %408 = load i64, ptr %6, align 8, !tbaa !16
  br i1 %407, label %409, label %413

409:                                              ; preds = %402
  %410 = call i32 @nms_release(ptr noundef %0, i64 noundef %408) #25
  %411 = select i1 %404, i32 %399, i32 %400
  %412 = select i1 %403, i32 %398, i32 %411
  br label %414

413:                                              ; preds = %402
  store i64 %408, ptr %4, align 8, !tbaa !16
  br label %414

414:                                              ; preds = %396, %413, %409
  %415 = phi i32 [ 0, %413 ], [ %412, %409 ], [ %397, %396 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  ret i32 %415
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_char_at(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i32 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4) local_unnamed_addr #1 {
  %6 = icmp ne ptr %4, null
  %7 = icmp ult i32 %3, 2
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %77

11:                                               ; preds = %5
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %13 = load i32, ptr %12, align 8, !tbaa !17
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %77

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %43, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %77, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %22 = load i32, ptr %21, align 4, !tbaa !18
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %77, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %27 = load ptr, ptr %26, align 8, !tbaa !19
  %28 = icmp eq ptr %27, null
  br i1 %28, label %77, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw [48 x i8], ptr %27, i64 %18
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load i64, ptr %31, align 8, !tbaa !20
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %77, label %34

34:                                               ; preds = %29
  %35 = and i64 %1, 4294967295
  %36 = getelementptr inbounds nuw [48 x i8], ptr %27, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 28
  %38 = load i32, ptr %37, align 4, !tbaa !23
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %40, label %77

40:                                               ; preds = %34
  %41 = load ptr, ptr %36, align 8, !tbaa !24
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 16
  br label %61

43:                                               ; preds = %15
  %44 = icmp eq i64 %1, 0
  br i1 %44, label %77, label %45

45:                                               ; preds = %43
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %47 = load i32, ptr %46, align 8, !tbaa !14
  %48 = zext i32 %47 to i64
  %49 = icmp samesign ugt i64 %1, %48
  br i1 %49, label %77, label %50

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !13
  %53 = icmp eq ptr %52, null
  br i1 %53, label %77, label %54

54:                                               ; preds = %50
  %55 = getelementptr [16 x i8], ptr %52, i64 %1
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load ptr, ptr %56, align 8, !tbaa !25
  %58 = icmp eq ptr %57, null
  br i1 %58, label %77, label %59

59:                                               ; preds = %54
  %60 = getelementptr i8, ptr %55, i64 -8
  br label %61

61:                                               ; preds = %59, %40
  %62 = phi ptr [ %57, %59 ], [ %41, %40 ]
  %63 = phi ptr [ %60, %59 ], [ %42, %40 ]
  %64 = load i32, ptr %63, align 8, !tbaa !12
  %65 = icmp eq i32 %3, 0
  %66 = select i1 %65, i64 0, i64 %2
  %67 = icmp sgt i64 %66, -1
  %68 = zext i32 %64 to i64
  %69 = icmp samesign ult i64 %66, %68
  %70 = select i1 %67, i1 %69, i1 false
  br i1 %70, label %71, label %75

71:                                               ; preds = %61
  %72 = getelementptr inbounds nuw i8, ptr %62, i64 %66
  %73 = load i8, ptr %72, align 1, !tbaa !39
  %74 = zext i8 %73 to i64
  br label %75

75:                                               ; preds = %61, %71
  %76 = phi i64 [ %74, %71 ], [ -1, %61 ]
  store i64 %76, ptr %4, align 8, !tbaa !16
  br label %77

77:                                               ; preds = %20, %17, %34, %25, %45, %50, %43, %11, %29, %54, %75, %5
  %78 = phi i32 [ 6, %5 ], [ 0, %75 ], [ 6, %20 ], [ 6, %17 ], [ 1, %34 ], [ 6, %25 ], [ 6, %45 ], [ 6, %50 ], [ 6, %43 ], [ 5, %11 ], [ 6, %29 ], [ 6, %54 ]
  ret i32 %78
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_predicate(ptr nofree noundef readonly captures(address_is_null) %0, i64 noundef %1, i64 noundef %2, i32 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4) local_unnamed_addr #10 {
  %6 = icmp ne ptr %4, null
  %7 = icmp ult i32 %3, 3
  %8 = and i1 %7, %6
  %9 = icmp ne ptr %0, null
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %166

11:                                               ; preds = %5
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %13 = load i32, ptr %12, align 8, !tbaa !17
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %166

15:                                               ; preds = %11
  %16 = icmp sgt i64 %1, -1
  br i1 %16, label %43, label %17

17:                                               ; preds = %15
  %18 = and i64 %1, 9223372036854775807
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %166, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %22 = load i32, ptr %21, align 4, !tbaa !18
  %23 = zext i32 %22 to i64
  %24 = icmp samesign ugt i64 %18, %23
  br i1 %24, label %166, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %27 = load ptr, ptr %26, align 8, !tbaa !19
  %28 = icmp eq ptr %27, null
  br i1 %28, label %166, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw [48 x i8], ptr %27, i64 %18
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load i64, ptr %31, align 8, !tbaa !20
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %166, label %34

34:                                               ; preds = %29
  %35 = and i64 %1, 4294967295
  %36 = getelementptr inbounds nuw [48 x i8], ptr %27, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 28
  %38 = load i32, ptr %37, align 4, !tbaa !23
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %40, label %166

40:                                               ; preds = %34
  %41 = load ptr, ptr %36, align 8, !tbaa !24
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 16
  br label %61

43:                                               ; preds = %15
  %44 = icmp eq i64 %1, 0
  br i1 %44, label %166, label %45

45:                                               ; preds = %43
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %47 = load i32, ptr %46, align 8, !tbaa !14
  %48 = zext i32 %47 to i64
  %49 = icmp samesign ugt i64 %1, %48
  br i1 %49, label %166, label %50

50:                                               ; preds = %45
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !13
  %53 = icmp eq ptr %52, null
  br i1 %53, label %166, label %54

54:                                               ; preds = %50
  %55 = getelementptr [16 x i8], ptr %52, i64 %1
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load ptr, ptr %56, align 8, !tbaa !25
  %58 = icmp eq ptr %57, null
  br i1 %58, label %166, label %59

59:                                               ; preds = %54
  %60 = getelementptr i8, ptr %55, i64 -8
  br label %61

61:                                               ; preds = %59, %40
  %62 = phi ptr [ %57, %59 ], [ %41, %40 ]
  %63 = phi ptr [ %60, %59 ], [ %42, %40 ]
  %64 = load i32, ptr %63, align 8, !tbaa !12
  %65 = icmp sgt i64 %2, -1
  br i1 %65, label %92, label %66

66:                                               ; preds = %61
  %67 = and i64 %2, 9223372036854775807
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %166, label %69

69:                                               ; preds = %66
  %70 = getelementptr inbounds nuw i8, ptr %0, i64 68
  %71 = load i32, ptr %70, align 4, !tbaa !18
  %72 = zext i32 %71 to i64
  %73 = icmp samesign ugt i64 %67, %72
  br i1 %73, label %166, label %74

74:                                               ; preds = %69
  %75 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %76 = load ptr, ptr %75, align 8, !tbaa !19
  %77 = icmp eq ptr %76, null
  br i1 %77, label %166, label %78

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw [48 x i8], ptr %76, i64 %67
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 8
  %81 = load i64, ptr %80, align 8, !tbaa !20
  %82 = icmp eq i64 %81, 0
  br i1 %82, label %166, label %83

83:                                               ; preds = %78
  %84 = and i64 %2, 4294967295
  %85 = getelementptr inbounds nuw [48 x i8], ptr %76, i64 %84
  %86 = getelementptr inbounds nuw i8, ptr %85, i64 28
  %87 = load i32, ptr %86, align 4, !tbaa !23
  %88 = icmp eq i32 %87, 1
  br i1 %88, label %89, label %166

89:                                               ; preds = %83
  %90 = load ptr, ptr %85, align 8, !tbaa !24
  %91 = getelementptr inbounds nuw i8, ptr %85, i64 16
  br label %110

92:                                               ; preds = %61
  %93 = icmp eq i64 %2, 0
  br i1 %93, label %166, label %94

94:                                               ; preds = %92
  %95 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %96 = load i32, ptr %95, align 8, !tbaa !14
  %97 = zext i32 %96 to i64
  %98 = icmp samesign ugt i64 %2, %97
  br i1 %98, label %166, label %99

99:                                               ; preds = %94
  %100 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %101 = load ptr, ptr %100, align 8, !tbaa !13
  %102 = icmp eq ptr %101, null
  br i1 %102, label %166, label %103

103:                                              ; preds = %99
  %104 = getelementptr [16 x i8], ptr %101, i64 %2
  %105 = getelementptr i8, ptr %104, i64 -16
  %106 = load ptr, ptr %105, align 8, !tbaa !25
  %107 = icmp eq ptr %106, null
  br i1 %107, label %166, label %108

108:                                              ; preds = %103
  %109 = getelementptr i8, ptr %104, i64 -8
  br label %110

110:                                              ; preds = %108, %89
  %111 = phi ptr [ %106, %108 ], [ %90, %89 ]
  %112 = phi ptr [ %109, %108 ], [ %91, %89 ]
  %113 = load i32, ptr %112, align 8, !tbaa !12
  %114 = icmp eq i32 %113, 0
  br i1 %114, label %164, label %115

115:                                              ; preds = %110
  %116 = icmp ugt i32 %113, %64
  br i1 %116, label %164, label %117

117:                                              ; preds = %115
  %118 = sub nuw i32 %64, %113
  switch i32 %3, label %119 [
    i32 1, label %121
    i32 2, label %133
  ]

119:                                              ; preds = %117
  %120 = zext i32 %113 to i64
  br label %147

121:                                              ; preds = %117
  %122 = zext i32 %113 to i64
  br label %126

123:                                              ; preds = %126
  %124 = add nuw nsw i64 %127, 1
  %125 = icmp eq i64 %124, %122
  br i1 %125, label %164, label %126, !llvm.loop !117

126:                                              ; preds = %123, %121
  %127 = phi i64 [ 0, %121 ], [ %124, %123 ]
  %128 = getelementptr inbounds nuw i8, ptr %62, i64 %127
  %129 = load i8, ptr %128, align 1, !tbaa !39
  %130 = getelementptr inbounds nuw i8, ptr %111, i64 %127
  %131 = load i8, ptr %130, align 1, !tbaa !39
  %132 = icmp eq i8 %129, %131
  br i1 %132, label %123, label %164

133:                                              ; preds = %117
  %134 = zext i32 %118 to i64
  %135 = getelementptr inbounds nuw i8, ptr %62, i64 %134
  %136 = zext i32 %113 to i64
  br label %140

137:                                              ; preds = %140
  %138 = add nuw nsw i64 %141, 1
  %139 = icmp eq i64 %138, %136
  br i1 %139, label %164, label %140, !llvm.loop !117

140:                                              ; preds = %137, %133
  %141 = phi i64 [ 0, %133 ], [ %138, %137 ]
  %142 = getelementptr inbounds nuw i8, ptr %135, i64 %141
  %143 = load i8, ptr %142, align 1, !tbaa !39
  %144 = getelementptr inbounds nuw i8, ptr %111, i64 %141
  %145 = load i8, ptr %144, align 1, !tbaa !39
  %146 = icmp eq i8 %143, %145
  br i1 %146, label %137, label %164

147:                                              ; preds = %119, %161
  %148 = phi i32 [ 0, %119 ], [ %162, %161 ]
  %149 = zext i32 %148 to i64
  %150 = getelementptr inbounds nuw i8, ptr %62, i64 %149
  br label %154

151:                                              ; preds = %154
  %152 = add nuw nsw i64 %155, 1
  %153 = icmp eq i64 %152, %120
  br i1 %153, label %164, label %154, !llvm.loop !117

154:                                              ; preds = %151, %147
  %155 = phi i64 [ 0, %147 ], [ %152, %151 ]
  %156 = getelementptr inbounds nuw i8, ptr %150, i64 %155
  %157 = load i8, ptr %156, align 1, !tbaa !39
  %158 = getelementptr inbounds nuw i8, ptr %111, i64 %155
  %159 = load i8, ptr %158, align 1, !tbaa !39
  %160 = icmp eq i8 %157, %159
  br i1 %160, label %151, label %161

161:                                              ; preds = %154
  %162 = add i32 %148, 1
  %163 = icmp ugt i32 %162, %118
  br i1 %163, label %164, label %147, !llvm.loop !125

164:                                              ; preds = %140, %137, %126, %123, %161, %151, %110, %115
  %165 = phi i32 [ 0, %115 ], [ 1, %110 ], [ 1, %151 ], [ 0, %161 ], [ 1, %123 ], [ 0, %126 ], [ 0, %140 ], [ 1, %137 ]
  store i32 %165, ptr %4, align 4, !tbaa !12
  br label %166

166:                                              ; preds = %69, %66, %83, %74, %94, %99, %92, %78, %103, %20, %17, %34, %25, %45, %50, %43, %11, %29, %54, %164, %5
  %167 = phi i32 [ 6, %5 ], [ 0, %164 ], [ 6, %103 ], [ 6, %20 ], [ 6, %17 ], [ 1, %34 ], [ 6, %25 ], [ 6, %45 ], [ 6, %50 ], [ 6, %43 ], [ 5, %11 ], [ 6, %29 ], [ 6, %54 ], [ 6, %69 ], [ 6, %66 ], [ 1, %83 ], [ 6, %74 ], [ 6, %94 ], [ 6, %99 ], [ 6, %92 ], [ 6, %78 ]
  ret i32 %167
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define void @nms_module_fail(i32 noundef %0) local_unnamed_addr #13 {
  %2 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %3 = icmp eq i32 %2, 0
  %4 = icmp ne i32 %0, 0
  %5 = and i1 %4, %3
  br i1 %5, label %6, label %9

6:                                                ; preds = %1
  %7 = icmp ult i32 %0, 8
  %8 = select i1 %7, i32 %0, i32 6
  store i32 %8, ptr @nms_module_error, align 4, !tbaa !12
  br label %9

9:                                                ; preds = %6, %1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none)
define i32 @nms_module_status() local_unnamed_addr #14 {
  %1 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  ret i32 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define range(i32 0, 6) i32 @nms_module_begin(ptr noundef %0, i32 noundef %1) local_unnamed_addr #13 {
  %3 = load i1, ptr @nms_module_ready, align 4
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !12
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !14
  store <2 x ptr> splat (ptr null), ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !15
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !12
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !12
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !16
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  store i1 true, ptr @nms_module_ready, align 4
  br label %11

5:                                                ; preds = %2
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %12

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %4, %8
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  store i32 0, ptr @nms_module_error, align 4, !tbaa !12
  br label %12

12:                                               ; preds = %5, %8, %11
  %13 = phi i32 [ 0, %11 ], [ 5, %5 ], [ 4, %8 ]
  ret i32 %13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define range(i64 0, -9223372036854775808) i64 @nms_module_finish(i32 noundef %0) local_unnamed_addr #13 {
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %14, label %4

4:                                                ; preds = %1
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %6 = icmp ugt i32 %5, 7
  %7 = select i1 %6, i32 6, i32 %5
  %8 = zext nneg i32 %7 to i64
  %9 = shl nuw nsw i64 %8, 32
  %10 = icmp eq i32 %7, 0
  %11 = select i1 %10, i32 %0, i32 0
  %12 = zext i32 %11 to i64
  %13 = or disjoint i64 %9, %12
  br label %14

14:                                               ; preds = %1, %4
  %15 = phi i64 [ %13, %4 ], [ 25769803776, %1 ]
  ret i64 %15
}

; Function Attrs: nounwind ssp
define range(i32 0, 6) i32 @nms_module_graph_begin(ptr noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = load i1, ptr @nms_module_ready, align 4
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !12
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !14
  store <2 x ptr> splat (ptr null), ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !15
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !12
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !16
  store i1 true, ptr @nms_module_ready, align 4
  store <4 x i32> <i32 0, i32 0, i32 1, i32 0>, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !12
  store i32 0, ptr @nms_module_error, align 4, !tbaa !12
  br label %14

5:                                                ; preds = %2
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %31

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %31

11:                                               ; preds = %8
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !28
  %13 = icmp eq i32 %12, 0
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  store i32 0, ptr @nms_module_error, align 4, !tbaa !12
  br i1 %13, label %14, label %31

14:                                               ; preds = %4, %11
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !18
  %16 = zext i32 %15 to i64
  %17 = add nuw nsw i64 %16, 1
  %18 = mul nuw nsw i64 %17, 9
  %19 = add nuw nsw i64 %18, 3
  %20 = and i64 %19, 274877906940
  %21 = shl nuw nsw i64 %17, 2
  %22 = add nuw nsw i64 %20, %21
  %23 = tail call ptr @malloc(i64 noundef %22) #24
  %24 = icmp eq ptr %23, null
  br i1 %24, label %27, label %25

25:                                               ; preds = %14
  store ptr %23, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !29
  %26 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !18
  store i32 %26, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !30
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !28
  br label %31

27:                                               ; preds = %14
  %28 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %29 = icmp eq i32 %28, 0
  br i1 %29, label %30, label %31

30:                                               ; preds = %27
  store i32 3, ptr @nms_module_error, align 4, !tbaa !12
  br label %31

31:                                               ; preds = %11, %25, %8, %5, %30, %27
  %32 = phi i32 [ 3, %30 ], [ 5, %5 ], [ 3, %27 ], [ 4, %8 ], [ 0, %25 ], [ 0, %11 ]
  ret i32 %32
}

; Function Attrs: nounwind ssp
define range(i64 1, 4294967304) i64 @nms_module_record_begin(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3) local_unnamed_addr #3 {
  %5 = load i1, ptr @nms_module_ready, align 4
  br i1 %5, label %7, label %6

6:                                                ; preds = %4
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !12
  store ptr %0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  store i32 %1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !14
  store <2 x ptr> splat (ptr null), ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !15
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !12
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !16
  store <4 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !12
  store i1 true, ptr @nms_module_ready, align 4
  br label %19

7:                                                ; preds = %4
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %86

10:                                               ; preds = %7
  %11 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %86

13:                                               ; preds = %10
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %15 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %16 = icmp eq ptr %14, %0
  %17 = icmp eq i32 %15, %1
  %18 = select i1 %16, i1 %17, i1 false
  br i1 %18, label %19, label %86

19:                                               ; preds = %6, %13
  %20 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 12), align 4, !tbaa !45
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %70

22:                                               ; preds = %19
  %23 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !18
  %24 = icmp eq i32 %23, 0
  %25 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8
  %26 = icmp eq i64 %25, 0
  %27 = select i1 %24, i1 %26, i1 false
  %28 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8
  %29 = icmp eq i64 %28, 0
  %30 = select i1 %27, i1 %29, i1 false
  br i1 %30, label %31, label %86

31:                                               ; preds = %22
  %32 = icmp eq i32 %3, 0
  %33 = icmp ne ptr %2, null
  %34 = or i1 %33, %32
  br i1 %34, label %35, label %86

35:                                               ; preds = %31
  %36 = icmp ugt i32 %3, 256
  br i1 %36, label %86, label %37

37:                                               ; preds = %35
  br i1 %32, label %69, label %38

38:                                               ; preds = %37
  %39 = zext nneg i32 %3 to i64
  %40 = load i32, ptr %2, align 4, !tbaa !56
  %41 = icmp ugt i32 %40, 255
  br i1 %41, label %86, label %42

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %44 = load i32, ptr %43, align 4, !tbaa !47
  %45 = icmp ugt i32 %44, 65535
  br i1 %45, label %86, label %46

46:                                               ; preds = %42
  %47 = icmp eq i32 %3, 1
  br i1 %47, label %69, label %48

48:                                               ; preds = %46, %65
  %49 = phi i64 [ %67, %65 ], [ 1, %46 ]
  %50 = phi i32 [ %66, %65 ], [ %44, %46 ]
  %51 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %49
  %52 = load i32, ptr %51, align 4, !tbaa !56
  %53 = icmp ugt i32 %52, 255
  br i1 %53, label %86, label %54

54:                                               ; preds = %48
  %55 = getelementptr i8, ptr %51, i64 -8
  %56 = load i32, ptr %55, align 4, !tbaa !56
  %57 = icmp ugt i32 %52, %56
  br i1 %57, label %58, label %86

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw i8, ptr %51, i64 4
  %60 = load i32, ptr %59, align 4, !tbaa !47
  %61 = icmp ugt i32 %60, 65535
  %62 = sub i32 65536, %50
  %63 = icmp ugt i32 %60, %62
  %64 = select i1 %61, i1 true, i1 %63
  br i1 %64, label %86, label %65

65:                                               ; preds = %58
  %66 = add i32 %60, %50
  %67 = add nuw nsw i64 %49, 1
  %68 = icmp eq i64 %67, %39
  br i1 %68, label %69, label %48, !llvm.loop !57

69:                                               ; preds = %65, %37, %46
  store ptr %2, ptr @nms_module_instance, align 8, !tbaa !8
  store i32 %3, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !46
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 12), align 4, !tbaa !45
  br label %76

70:                                               ; preds = %19
  %71 = load ptr, ptr @nms_module_instance, align 8, !tbaa !8
  %72 = icmp eq ptr %71, %2
  %73 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8
  %74 = icmp eq i32 %73, %3
  %75 = select i1 %72, i1 %74, i1 false
  br i1 %75, label %76, label %86

76:                                               ; preds = %69, %70
  store i32 1, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  store i32 0, ptr @nms_module_error, align 4, !tbaa !12
  %77 = tail call i32 @nms_prepare_collection(ptr noundef nonnull @nms_module_instance) #25
  %78 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %79 = icmp eq i32 %78, 0
  %80 = icmp ne i32 %77, 0
  %81 = and i1 %80, %79
  br i1 %81, label %82, label %83

82:                                               ; preds = %76
  store i32 %77, ptr @nms_module_error, align 4, !tbaa !12
  br label %83

83:                                               ; preds = %76, %82
  %84 = zext nneg i32 %77 to i64
  %85 = or disjoint i64 %84, 4294967296
  br label %86

86:                                               ; preds = %48, %54, %58, %38, %22, %31, %35, %42, %83, %70, %13, %10, %7
  %87 = phi i64 [ 6, %13 ], [ 5, %7 ], [ 4, %10 ], [ %85, %83 ], [ 6, %70 ], [ 1, %38 ], [ 6, %22 ], [ 1, %35 ], [ 1, %42 ], [ 6, %31 ], [ 1, %58 ], [ 1, %54 ], [ 1, %48 ]
  ret i64 %87
}

; Function Attrs: nounwind ssp
define i32 @nms_module_graph_collect() local_unnamed_addr #3 {
  %1 = load i1, ptr @nms_module_ready, align 4
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4
  %3 = icmp ne i32 %2, 0
  %4 = select i1 %1, i1 %3, i1 false
  br i1 %4, label %5, label %49

5:                                                ; preds = %0
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %42

8:                                                ; preds = %5
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !18
  %10 = icmp eq i32 %9, 0
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %12 = icmp eq ptr %11, null
  br i1 %10, label %13, label %20

13:                                               ; preds = %8
  %14 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8
  %15 = icmp eq i64 %14, 0
  %16 = select i1 %12, i1 %15, i1 false
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8
  %18 = icmp eq i64 %17, 0
  %19 = select i1 %16, i1 %18, i1 false
  br i1 %19, label %21, label %42

20:                                               ; preds = %8
  br i1 %12, label %42, label %21

21:                                               ; preds = %13, %20
  %22 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !28
  %23 = icmp eq i32 %22, 0
  br i1 %23, label %42, label %24

24:                                               ; preds = %21
  %25 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !29
  %26 = icmp eq ptr %25, null
  br i1 %26, label %42, label %27

27:                                               ; preds = %24
  %28 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !30
  %29 = icmp ult i32 %28, %9
  %30 = or i1 %10, %29
  %31 = select i1 %29, i32 6, i32 0
  br i1 %30, label %42, label %32

32:                                               ; preds = %27
  %33 = zext i32 %28 to i64
  %34 = add nuw nsw i64 %33, 1
  %35 = mul nuw nsw i64 %34, 9
  %36 = add nuw nsw i64 %35, 3
  %37 = and i64 %36, 274877906940
  %38 = shl nuw nsw i64 %34, 3
  %39 = getelementptr inbounds nuw i8, ptr %25, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %25, i64 %37
  %41 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull @nms_module_instance, ptr noundef nonnull %25, ptr noundef nonnull %39, ptr noundef nonnull %40) #25
  br label %42

42:                                               ; preds = %5, %13, %20, %21, %24, %27, %32
  %43 = phi i32 [ 6, %21 ], [ 6, %20 ], [ %41, %32 ], [ %31, %27 ], [ 6, %24 ], [ 5, %5 ], [ 6, %13 ]
  %44 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %45 = icmp eq i32 %44, 0
  %46 = icmp ne i32 %43, 0
  %47 = and i1 %46, %45
  br i1 %47, label %48, label %49

48:                                               ; preds = %42
  store i32 %43, ptr @nms_module_error, align 4, !tbaa !12
  br label %49

49:                                               ; preds = %48, %42, %0
  %50 = phi i32 [ 6, %0 ], [ %44, %42 ], [ %43, %48 ]
  ret i32 %50
}

; Function Attrs: nounwind ssp
define range(i64 0, -9223372036854775808) i64 @nms_module_graph_finish(i32 noundef %0) local_unnamed_addr #3 {
  %2 = load i1, ptr @nms_module_ready, align 4
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4
  %4 = icmp ne i32 %3, 0
  %5 = select i1 %2, i1 %4, i1 false
  br i1 %5, label %6, label %67

6:                                                ; preds = %1
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 44), align 4, !tbaa !28
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %49, label %9

9:                                                ; preds = %6
  %10 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %43

12:                                               ; preds = %9
  %13 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4, !tbaa !18
  %14 = icmp eq i32 %13, 0
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %16 = icmp eq ptr %15, null
  br i1 %14, label %17, label %24

17:                                               ; preds = %12
  %18 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8
  %19 = icmp eq i64 %18, 0
  %20 = select i1 %16, i1 %19, i1 false
  %21 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8
  %22 = icmp eq i64 %21, 0
  %23 = select i1 %20, i1 %22, i1 false
  br i1 %23, label %25, label %43

24:                                               ; preds = %12
  br i1 %16, label %43, label %25

25:                                               ; preds = %17, %24
  %26 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !29
  %27 = icmp eq ptr %26, null
  br i1 %27, label %43, label %28

28:                                               ; preds = %25
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !30
  %30 = icmp ult i32 %29, %13
  %31 = or i1 %14, %30
  %32 = select i1 %30, i32 6, i32 0
  br i1 %31, label %43, label %33

33:                                               ; preds = %28
  %34 = zext i32 %29 to i64
  %35 = add nuw nsw i64 %34, 1
  %36 = mul nuw nsw i64 %35, 9
  %37 = add nuw nsw i64 %36, 3
  %38 = and i64 %37, 274877906940
  %39 = shl nuw nsw i64 %35, 3
  %40 = getelementptr inbounds nuw i8, ptr %26, i64 %39
  %41 = getelementptr inbounds nuw i8, ptr %26, i64 %38
  %42 = tail call fastcc i32 @collect_with_workspace(ptr noundef nonnull @nms_module_instance, ptr noundef nonnull %26, ptr noundef nonnull %40, ptr noundef nonnull %41) #25
  br label %43

43:                                               ; preds = %9, %17, %24, %25, %28, %33
  %44 = phi i32 [ 6, %17 ], [ 6, %24 ], [ %42, %33 ], [ %32, %28 ], [ 6, %25 ], [ 5, %9 ]
  %45 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %46 = icmp eq i32 %45, 0
  %47 = icmp ne i32 %44, 0
  %48 = and i1 %47, %46
  br i1 %48, label %52, label %54

49:                                               ; preds = %6
  %50 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %52, label %54

52:                                               ; preds = %49, %43
  %53 = phi i32 [ %44, %43 ], [ 6, %49 ]
  store i32 %53, ptr @nms_module_error, align 4, !tbaa !12
  br label %54

54:                                               ; preds = %52, %49, %43
  %55 = phi i32 [ %45, %43 ], [ %50, %49 ], [ %53, %52 ]
  %56 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %67, label %58

58:                                               ; preds = %54
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  %59 = icmp ugt i32 %55, 7
  %60 = select i1 %59, i32 6, i32 %55
  %61 = zext nneg i32 %60 to i64
  %62 = shl nuw nsw i64 %61, 32
  %63 = icmp eq i32 %60, 0
  %64 = select i1 %63, i32 %0, i32 0
  %65 = zext i32 %64 to i64
  %66 = or disjoint i64 %62, %65
  br label %67

67:                                               ; preds = %58, %54, %1
  %68 = phi i64 [ 25769803776, %1 ], [ %66, %58 ], [ 25769803776, %54 ]
  ret i64 %68
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none)
define i32 @nms_module_active() local_unnamed_addr #14 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 76), align 4, !tbaa !54
  ret i32 %1
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_module_dispose() local_unnamed_addr #3 {
  %1 = load i1, ptr @nms_module_ready, align 4
  br i1 %1, label %3, label %2

2:                                                ; preds = %0
  store ptr null, ptr @nms_module_instance, align 8, !tbaa !8
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !12
  store <2 x ptr> splat (ptr null), ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !15
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 32), align 8, !tbaa !29
  store <2 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 40), align 8, !tbaa !12
  store <2 x i64> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !16
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  store <4 x i32> zeroinitializer, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8, !tbaa !12
  store i1 true, ptr @nms_module_ready, align 4
  br label %3

3:                                                ; preds = %2, %0
  %4 = tail call i32 @nms_dispose(ptr noundef nonnull @nms_module_instance) #25
  ret i32 %4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_module_retain(i64 noundef %0, i32 noundef %1) local_unnamed_addr #4 {
  switch i32 %1, label %54 [
    i32 8, label %3
    i32 7, label %3
    i32 5, label %3
  ]

3:                                                ; preds = %2, %2, %2
  %4 = icmp sgt i64 %0, -1
  %5 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %6 = icmp eq i32 %5, 0
  br i1 %4, label %7, label %23

7:                                                ; preds = %3
  br i1 %6, label %8, label %47

8:                                                ; preds = %7
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %10 = freeze i32 %9
  %11 = zext i32 %10 to i64
  %12 = add nsw i64 %0, -1
  %13 = icmp ult i64 %12, %11
  br i1 %13, label %14, label %47

14:                                               ; preds = %8
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %16 = icmp eq ptr %15, null
  br i1 %16, label %47, label %17

17:                                               ; preds = %14
  %18 = getelementptr [16 x i8], ptr %15, i64 %0
  %19 = getelementptr i8, ptr %18, i64 -16
  %20 = load ptr, ptr %19, align 8, !tbaa !25
  %21 = icmp eq ptr %20, null
  %22 = select i1 %21, i32 6, i32 0
  br label %47

23:                                               ; preds = %3
  br i1 %6, label %24, label %47

24:                                               ; preds = %23
  %25 = and i64 %0, 9223372036854775807
  %26 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %27 = freeze i32 %26
  %28 = zext i32 %27 to i64
  %29 = add nsw i64 %25, -1
  %30 = icmp ult i64 %29, %28
  br i1 %30, label %31, label %47

31:                                               ; preds = %24
  %32 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %33 = icmp eq ptr %32, null
  br i1 %33, label %47, label %34

34:                                               ; preds = %31
  %35 = getelementptr inbounds nuw [48 x i8], ptr %32, i64 %25
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %37 = load i64, ptr %36, align 8, !tbaa !20
  %38 = icmp eq i64 %37, 0
  br i1 %38, label %47, label %39

39:                                               ; preds = %34
  %40 = and i64 %0, 4294967295
  %41 = getelementptr inbounds nuw [48 x i8], ptr %32, i64 %40
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 8
  %43 = load i64, ptr %42, align 8, !tbaa !20
  %44 = icmp eq i64 %43, -1
  br i1 %44, label %47, label %45

45:                                               ; preds = %39
  %46 = add nuw i64 %43, 1
  store i64 %46, ptr %42, align 8, !tbaa !20
  br label %54

47:                                               ; preds = %39, %34, %31, %24, %23, %17, %14, %8, %7
  %48 = phi i32 [ 3, %39 ], [ 6, %24 ], [ 6, %34 ], [ %22, %17 ], [ 5, %23 ], [ 5, %7 ], [ 6, %8 ], [ 6, %14 ], [ 6, %31 ]
  %49 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %50 = icmp eq i32 %49, 0
  %51 = icmp ne i32 %48, 0
  %52 = and i1 %51, %50
  br i1 %52, label %53, label %54

53:                                               ; preds = %47
  store i32 %48, ptr @nms_module_error, align 4, !tbaa !12
  br label %54

54:                                               ; preds = %45, %2, %47, %53
  %55 = phi i32 [ %48, %53 ], [ %48, %47 ], [ 0, %2 ], [ 0, %45 ]
  ret i32 %55
}

; Function Attrs: nounwind ssp
define void @nms_module_release(i64 noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  switch i32 %1, label %10 [
    i32 8, label %3
    i32 7, label %3
    i32 5, label %3
  ]

3:                                                ; preds = %2, %2, %2
  %4 = tail call i32 @nms_release(ptr noundef nonnull @nms_module_instance, i64 noundef %0) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %3
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %9, %3, %2
  ret void
}

; Function Attrs: nounwind ssp
define i64 @nms_module_record_literal(i32 noundef %0, i32 noundef %1, ptr nofree noundef readonly captures(address_is_null) %2, ptr nofree noundef readonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca [256 x %struct.NmsValue], align 8
  %6 = alloca i64, align 8
  %7 = icmp ugt i32 %1, 256
  br i1 %7, label %8, label %12

8:                                                ; preds = %4
  %9 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %111

11:                                               ; preds = %8
  store i32 1, ptr @nms_module_error, align 4, !tbaa !12
  br label %111

12:                                               ; preds = %4
  %13 = icmp eq i32 %1, 0
  br i1 %13, label %14, label %15

14:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  br label %49

15:                                               ; preds = %12
  %16 = icmp ne ptr %2, null
  %17 = icmp ne ptr %3, null
  %18 = and i1 %16, %17
  br i1 %18, label %23, label %19

19:                                               ; preds = %15
  %20 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %111

22:                                               ; preds = %19
  store i32 6, ptr @nms_module_error, align 4, !tbaa !12
  br label %111

23:                                               ; preds = %15
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  %24 = zext nneg i32 %1 to i64
  %25 = add nsw i64 %24, -1
  %26 = urem i64 %25, 6
  %27 = add nuw nsw i64 %26, 1
  %28 = icmp ne i64 %27, 6
  %29 = select i1 %28, i64 %27, i64 0
  %30 = icmp ult i32 %1, 6
  br i1 %30, label %34, label %31

31:                                               ; preds = %23
  %32 = sub nsw i64 %24, %29
  br label %58

33:                                               ; preds = %58
  br i1 %28, label %34, label %49

34:                                               ; preds = %33, %23
  %35 = phi i64 [ 0, %23 ], [ %108, %33 ]
  tail call void @llvm.assume(i1 %28)
  br label %36

36:                                               ; preds = %36, %34
  %37 = phi i64 [ %35, %34 ], [ %46, %36 ]
  %38 = phi i64 [ 0, %34 ], [ %47, %36 ]
  %39 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %37
  %40 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %37
  %41 = load i64, ptr %40, align 8, !tbaa !16
  %42 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %37
  %43 = load i32, ptr %42, align 4, !tbaa !12
  store i64 %41, ptr %39, align 8, !tbaa !16
  %44 = getelementptr inbounds nuw i8, ptr %39, i64 8
  store i32 %43, ptr %44, align 8, !tbaa !12
  %45 = getelementptr inbounds nuw i8, ptr %39, i64 12
  store i32 0, ptr %45, align 4
  %46 = add nuw nsw i64 %37, 1
  %47 = add i64 %38, 1
  %48 = icmp eq i64 %47, %29
  br i1 %48, label %49, label %36, !llvm.loop !126

49:                                               ; preds = %33, %36, %14
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  %50 = call i32 @nms_record_create(ptr noundef nonnull @nms_module_instance, i32 noundef %0, ptr noundef nonnull %5, i32 noundef %1, ptr noundef nonnull %6) #25
  %51 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %52 = icmp eq i32 %51, 0
  %53 = icmp ne i32 %50, 0
  %54 = and i1 %53, %52
  br i1 %54, label %55, label %56

55:                                               ; preds = %49
  store i32 %50, ptr @nms_module_error, align 4, !tbaa !12
  br label %56

56:                                               ; preds = %49, %55
  %57 = load i64, ptr %6, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  br label %111

58:                                               ; preds = %58, %31
  %59 = phi i64 [ 0, %31 ], [ %108, %58 ]
  %60 = phi i64 [ 0, %31 ], [ %109, %58 ]
  %61 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %59
  %62 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %59
  %63 = load i64, ptr %62, align 8, !tbaa !16
  %64 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %59
  %65 = load i32, ptr %64, align 4, !tbaa !12
  store i64 %63, ptr %61, align 8, !tbaa !16
  %66 = getelementptr inbounds nuw i8, ptr %61, i64 8
  store i32 %65, ptr %66, align 8, !tbaa !12
  %67 = getelementptr inbounds nuw i8, ptr %61, i64 12
  store i32 0, ptr %67, align 4
  %68 = or disjoint i64 %59, 1
  %69 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %68
  %70 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %68
  %71 = load i64, ptr %70, align 8, !tbaa !16
  %72 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %68
  %73 = load i32, ptr %72, align 4, !tbaa !12
  store i64 %71, ptr %69, align 8, !tbaa !16
  %74 = getelementptr inbounds nuw i8, ptr %69, i64 8
  store i32 %73, ptr %74, align 8, !tbaa !12
  %75 = getelementptr inbounds nuw i8, ptr %69, i64 12
  store i32 0, ptr %75, align 4
  %76 = add nuw nsw i64 %59, 2
  %77 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %76
  %78 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %76
  %79 = load i64, ptr %78, align 8, !tbaa !16
  %80 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %76
  %81 = load i32, ptr %80, align 4, !tbaa !12
  store i64 %79, ptr %77, align 8, !tbaa !16
  %82 = getelementptr inbounds nuw i8, ptr %77, i64 8
  store i32 %81, ptr %82, align 8, !tbaa !12
  %83 = getelementptr inbounds nuw i8, ptr %77, i64 12
  store i32 0, ptr %83, align 4
  %84 = add nuw nsw i64 %59, 3
  %85 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %84
  %86 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %84
  %87 = load i64, ptr %86, align 8, !tbaa !16
  %88 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %84
  %89 = load i32, ptr %88, align 4, !tbaa !12
  store i64 %87, ptr %85, align 8, !tbaa !16
  %90 = getelementptr inbounds nuw i8, ptr %85, i64 8
  store i32 %89, ptr %90, align 8, !tbaa !12
  %91 = getelementptr inbounds nuw i8, ptr %85, i64 12
  store i32 0, ptr %91, align 4
  %92 = add nuw nsw i64 %59, 4
  %93 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %92
  %94 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %92
  %95 = load i64, ptr %94, align 8, !tbaa !16
  %96 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %92
  %97 = load i32, ptr %96, align 4, !tbaa !12
  store i64 %95, ptr %93, align 8, !tbaa !16
  %98 = getelementptr inbounds nuw i8, ptr %93, i64 8
  store i32 %97, ptr %98, align 8, !tbaa !12
  %99 = getelementptr inbounds nuw i8, ptr %93, i64 12
  store i32 0, ptr %99, align 4
  %100 = add nuw nsw i64 %59, 5
  %101 = getelementptr inbounds nuw [16 x i8], ptr %5, i64 %100
  %102 = getelementptr inbounds nuw [8 x i8], ptr %2, i64 %100
  %103 = load i64, ptr %102, align 8, !tbaa !16
  %104 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %100
  %105 = load i32, ptr %104, align 4, !tbaa !12
  store i64 %103, ptr %101, align 8, !tbaa !16
  %106 = getelementptr inbounds nuw i8, ptr %101, i64 8
  store i32 %105, ptr %106, align 8, !tbaa !12
  %107 = getelementptr inbounds nuw i8, ptr %101, i64 12
  store i32 0, ptr %107, align 4
  %108 = add nuw nsw i64 %59, 6
  %109 = add i64 %60, 6
  %110 = icmp eq i64 %109, %32
  br i1 %110, label %33, label %58, !llvm.loop !127

111:                                              ; preds = %22, %19, %11, %8, %56
  %112 = phi i64 [ 0, %11 ], [ %57, %56 ], [ 0, %8 ], [ 0, %19 ], [ 0, %22 ]
  ret i64 %112
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 8) i32 @nms_module_record_get_value(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, ptr nofree noundef writeonly captures(address_is_null) %4, ptr nofree noundef writeonly captures(address_is_null) %5) local_unnamed_addr #4 {
  %7 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %7, i8 0, i64 16, i1 false)
  %8 = icmp ne ptr %4, null
  %9 = icmp ne ptr %5, null
  %10 = and i1 %8, %9
  br i1 %10, label %11, label %22

11:                                               ; preds = %6
  %12 = tail call fastcc i32 @nms_module_record_receiver(i64 noundef %0, i32 noundef %1, i32 noundef %3) #25
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %14, label %22

14:                                               ; preds = %11
  %15 = zext i32 %2 to i64
  %16 = call i32 @nms_record_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %15, ptr noundef nonnull %7) #25
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %22

18:                                               ; preds = %14
  %19 = load i64, ptr %7, align 8, !tbaa !128
  store i64 %19, ptr %4, align 8, !tbaa !16
  %20 = getelementptr inbounds nuw i8, ptr %7, i64 8
  %21 = load i32, ptr %20, align 8, !tbaa !130
  store i32 %21, ptr %5, align 4, !tbaa !12
  br label %27

22:                                               ; preds = %6, %11, %14
  %23 = phi i32 [ %16, %14 ], [ %12, %11 ], [ 6, %6 ]
  %24 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %25 = icmp eq i32 %24, 0
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  store i32 %23, ptr @nms_module_error, align 4, !tbaa !12
  br label %27

27:                                               ; preds = %18, %22, %26
  %28 = phi i32 [ 0, %18 ], [ %23, %22 ], [ %23, %26 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #27
  ret i32 %28
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, inaccessiblemem: none, target_mem: none)
define internal fastcc range(i32 0, 8) i32 @nms_module_record_receiver(i64 noundef %0, i32 noundef %1, i32 noundef %2) unnamed_addr #5 {
  %4 = icmp ugt i32 %2, 1
  br i1 %4, label %71, label %5

5:                                                ; preds = %3
  %6 = icmp eq i32 %1, 8
  br i1 %6, label %10, label %7

7:                                                ; preds = %5
  %8 = icmp eq i32 %2, 0
  %9 = select i1 %8, i32 1, i32 7
  br label %71

10:                                               ; preds = %5
  %11 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %13, label %65

13:                                               ; preds = %10
  %14 = and i64 %0, 9223372036854775807
  %15 = icmp sgt i64 %0, -1
  %16 = icmp eq i64 %14, 0
  %17 = or i1 %15, %16
  %18 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %19 = zext i32 %18 to i64
  %20 = icmp samesign ugt i64 %14, %19
  %21 = select i1 %17, i1 true, i1 %20
  br i1 %21, label %65, label %22

22:                                               ; preds = %13
  %23 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %24 = icmp eq ptr %23, null
  br i1 %24, label %65, label %25

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw [48 x i8], ptr %23, i64 %14
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load i64, ptr %27, align 8, !tbaa !20
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %65, label %30

30:                                               ; preds = %25
  %31 = and i64 %0, 4294967295
  %32 = getelementptr inbounds nuw [48 x i8], ptr %23, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 28
  %34 = load i32, ptr %33, align 4, !tbaa !23
  %35 = icmp eq i32 %34, 5
  br i1 %35, label %36, label %65

36:                                               ; preds = %30
  %37 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 12), align 4, !tbaa !45
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %65, label %39

39:                                               ; preds = %36
  %40 = load ptr, ptr @nms_module_instance, align 8, !tbaa !8
  %41 = icmp eq ptr %40, null
  br i1 %41, label %65, label %42

42:                                               ; preds = %39
  %43 = getelementptr inbounds nuw i8, ptr %32, i64 40
  %44 = load i32, ptr %43, align 8, !tbaa !33
  %45 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 8), align 8, !tbaa !46
  %46 = icmp ult i32 %44, %45
  br i1 %46, label %47, label %65

47:                                               ; preds = %42
  %48 = zext i32 %44 to i64
  %49 = getelementptr inbounds nuw [8 x i8], ptr %40, i64 %48
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 4
  %51 = load i32, ptr %50, align 4, !tbaa !47
  %52 = getelementptr inbounds nuw i8, ptr %32, i64 16
  %53 = load i32, ptr %52, align 8, !tbaa !34
  %54 = icmp eq i32 %53, %51
  br i1 %54, label %55, label %65

55:                                               ; preds = %47
  %56 = getelementptr inbounds nuw i8, ptr %32, i64 24
  %57 = load i32, ptr %56, align 8, !tbaa !38
  %58 = icmp eq i32 %57, %51
  br i1 %58, label %59, label %65

59:                                               ; preds = %55
  %60 = icmp eq i32 %51, 0
  br i1 %60, label %64, label %61

61:                                               ; preds = %59
  %62 = load ptr, ptr %32, align 8, !tbaa !24
  %63 = icmp eq ptr %62, null
  br i1 %63, label %65, label %64

64:                                               ; preds = %61, %59
  br label %65

65:                                               ; preds = %10, %13, %22, %25, %30, %36, %39, %42, %47, %55, %61, %64
  %66 = phi i1 [ true, %30 ], [ false, %64 ], [ false, %36 ], [ false, %61 ], [ false, %10 ], [ false, %25 ], [ false, %22 ], [ false, %42 ], [ false, %13 ], [ false, %47 ], [ false, %55 ], [ false, %39 ]
  %67 = phi i32 [ 1, %30 ], [ 0, %64 ], [ 6, %36 ], [ 6, %61 ], [ 5, %10 ], [ 6, %25 ], [ 6, %22 ], [ 6, %42 ], [ 6, %13 ], [ 6, %47 ], [ 6, %55 ], [ 6, %39 ]
  %68 = icmp ne i32 %2, 0
  %69 = and i1 %68, %66
  %70 = select i1 %69, i32 7, i32 %67
  br label %71

71:                                               ; preds = %3, %65, %7
  %72 = phi i32 [ %70, %65 ], [ %9, %7 ], [ 6, %3 ]
  ret i32 %72
}

; Function Attrs: nounwind ssp
define range(i32 0, 8) i32 @nms_module_record_set_value(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i64 noundef %4, i32 noundef %5) local_unnamed_addr #3 {
  %7 = tail call fastcc i32 @nms_module_record_receiver(i64 noundef %0, i32 noundef %1, i32 noundef %3) #25
  %8 = icmp eq i32 %7, 0
  br i1 %8, label %9, label %15

9:                                                ; preds = %6
  %10 = zext i32 %2 to i64
  %11 = insertvalue [2 x i64] poison, i64 %4, 0
  %12 = zext i32 %5 to i64
  %13 = insertvalue [2 x i64] %11, i64 %12, 1
  %14 = tail call i32 @nms_record_set(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %10, [2 x i64] %13) #25
  br label %15

15:                                               ; preds = %9, %6
  %16 = phi i32 [ %14, %9 ], [ %7, %6 ]
  %17 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %18 = icmp eq i32 %17, 0
  %19 = icmp ne i32 %16, 0
  %20 = and i1 %19, %18
  br i1 %20, label %21, label %22

21:                                               ; preds = %15
  store i32 %16, ptr @nms_module_error, align 4, !tbaa !12
  br label %22

22:                                               ; preds = %15, %21
  ret i32 %16
}

; Function Attrs: nounwind ssp
define i64 @nms_module_format_scalar(i64 noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  store i64 0, ptr %3, align 8, !tbaa !16
  %4 = call i32 @nms_format_scalar(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, ptr noundef nonnull %3) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define range(i64 -1, 256) i64 @nms_module_char_at(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #15 {
  %4 = icmp ult i32 %2, 2
  br i1 %4, label %5, label %64

5:                                                ; preds = %3
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %64

8:                                                ; preds = %5
  %9 = icmp sgt i64 %0, -1
  br i1 %9, label %34, label %10

10:                                               ; preds = %8
  %11 = and i64 %0, 9223372036854775807
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %13 = freeze i32 %12
  %14 = zext i32 %13 to i64
  %15 = add nsw i64 %11, -1
  %16 = icmp ult i64 %15, %14
  br i1 %16, label %17, label %64

17:                                               ; preds = %10
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %19 = icmp eq ptr %18, null
  br i1 %19, label %64, label %20

20:                                               ; preds = %17
  %21 = getelementptr inbounds nuw [48 x i8], ptr %18, i64 %11
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 8
  %23 = load i64, ptr %22, align 8, !tbaa !20
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %64, label %25

25:                                               ; preds = %20
  %26 = and i64 %0, 4294967295
  %27 = getelementptr inbounds nuw [48 x i8], ptr %18, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 28
  %29 = load i32, ptr %28, align 4, !tbaa !23
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %31, label %64

31:                                               ; preds = %25
  %32 = load ptr, ptr %27, align 8, !tbaa !24
  %33 = getelementptr inbounds nuw i8, ptr %27, i64 16
  br label %50

34:                                               ; preds = %8
  %35 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %36 = freeze i32 %35
  %37 = zext i32 %36 to i64
  %38 = add nsw i64 %0, -1
  %39 = icmp ult i64 %38, %37
  br i1 %39, label %40, label %64

40:                                               ; preds = %34
  %41 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %42 = icmp eq ptr %41, null
  br i1 %42, label %64, label %43

43:                                               ; preds = %40
  %44 = getelementptr [16 x i8], ptr %41, i64 %0
  %45 = getelementptr i8, ptr %44, i64 -16
  %46 = load ptr, ptr %45, align 8, !tbaa !25
  %47 = icmp eq ptr %46, null
  br i1 %47, label %64, label %48

48:                                               ; preds = %43
  %49 = getelementptr i8, ptr %44, i64 -8
  br label %50

50:                                               ; preds = %48, %31
  %51 = phi ptr [ %46, %48 ], [ %32, %31 ]
  %52 = phi ptr [ %49, %48 ], [ %33, %31 ]
  %53 = load i32, ptr %52, align 8, !tbaa !12
  %54 = icmp eq i32 %2, 0
  %55 = select i1 %54, i64 0, i64 %1
  %56 = icmp sgt i64 %55, -1
  %57 = zext i32 %53 to i64
  %58 = icmp samesign ult i64 %55, %57
  %59 = select i1 %56, i1 %58, i1 false
  br i1 %59, label %60, label %69

60:                                               ; preds = %50
  %61 = getelementptr inbounds nuw i8, ptr %51, i64 %55
  %62 = load i8, ptr %61, align 1, !tbaa !39
  %63 = zext i8 %62 to i64
  br label %69

64:                                               ; preds = %3, %5, %10, %17, %20, %25, %34, %40, %43
  %65 = phi i32 [ 6, %3 ], [ 6, %43 ], [ 6, %20 ], [ 6, %10 ], [ 1, %25 ], [ 6, %17 ], [ 5, %5 ], [ 6, %40 ], [ 6, %34 ]
  %66 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %68, label %69

68:                                               ; preds = %64
  store i32 %65, ptr @nms_module_error, align 4, !tbaa !12
  br label %69

69:                                               ; preds = %50, %60, %64, %68
  %70 = phi i64 [ 0, %68 ], [ 0, %64 ], [ -1, %50 ], [ %63, %60 ]
  ret i64 %70
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define i32 @nms_module_predicate(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #16 {
  %4 = alloca i32, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #27
  store i32 0, ptr %4, align 4, !tbaa !12
  %5 = call i32 @nms_predicate(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, i32 noundef %2, ptr noundef nonnull %4) #25
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !12
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i32, ptr %4, align 4, !tbaa !12
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  ret i32 %12
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define i64 @nms_module_parse_f64(i64 noundef %0) local_unnamed_addr #8 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #27
  store i64 0, ptr %2, align 8, !tbaa !16
  %3 = call i32 @nms_parse_f64(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #25
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !12
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #27
  ret i64 %10
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define i64 @nms_module_parse_i64(i64 noundef %0) local_unnamed_addr #16 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #27
  store i64 0, ptr %2, align 8, !tbaa !16
  %3 = call i32 @nms_parse_i64(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #25
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !12
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #27
  ret i64 %10
}

; Function Attrs: nounwind ssp
define i64 @nms_module_split(i64 noundef %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  store i64 0, ptr %3, align 8, !tbaa !16
  %4 = call fastcc range(i32 0, 7) i32 @split_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3, i32 noundef 0) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  ret i64 %11
}

; Function Attrs: nounwind ssp
define i64 @nms_module_array_literal(i32 noundef %0, i32 noundef %1, ptr nofree noundef readonly captures(address_is_null) %2, ptr nofree noundef readonly captures(address_is_null) %3) local_unnamed_addr #3 {
  %5 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  store i64 0, ptr %5, align 8, !tbaa !16
  %6 = call i32 @nms_vm_array_literal(ptr noundef nonnull @nms_module_instance, i32 noundef %0, ptr noundef %2, ptr noundef %3, i32 noundef %1, ptr noundef nonnull %5) #25
  %7 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %8 = icmp eq i32 %7, 0
  %9 = icmp ne i32 %6, 0
  %10 = and i1 %9, %8
  br i1 %10, label %11, label %12

11:                                               ; preds = %4
  store i32 %6, ptr @nms_module_error, align 4, !tbaa !12
  br label %12

12:                                               ; preds = %4, %11
  %13 = load i64, ptr %5, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  ret i64 %13
}

; Function Attrs: nounwind ssp
define i64 @nms_module_array_slice(i64 noundef %0, i64 noundef %1, i32 noundef %2, i64 noundef %3, i32 noundef %4) local_unnamed_addr #3 {
  %6 = alloca i64, align 8
  %7 = icmp sgt i64 %0, -1
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %9 = icmp eq i32 %8, 0
  br i1 %7, label %10, label %26

10:                                               ; preds = %5
  br i1 %9, label %11, label %49

11:                                               ; preds = %10
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %13 = freeze i32 %12
  %14 = zext i32 %13 to i64
  %15 = add nsw i64 %0, -1
  %16 = icmp ult i64 %15, %14
  br i1 %16, label %17, label %49

17:                                               ; preds = %11
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %19 = icmp eq ptr %18, null
  br i1 %19, label %49, label %20

20:                                               ; preds = %17
  %21 = getelementptr [16 x i8], ptr %18, i64 %0
  %22 = getelementptr i8, ptr %21, i64 -16
  %23 = load ptr, ptr %22, align 8, !tbaa !25
  %24 = icmp eq ptr %23, null
  %25 = select i1 %24, i32 6, i32 1
  br label %49

26:                                               ; preds = %5
  br i1 %9, label %27, label %49

27:                                               ; preds = %26
  %28 = and i64 %0, 9223372036854775807
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %30 = freeze i32 %29
  %31 = zext i32 %30 to i64
  %32 = add nsw i64 %28, -1
  %33 = icmp ult i64 %32, %31
  br i1 %33, label %34, label %49

34:                                               ; preds = %27
  %35 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %36 = icmp eq ptr %35, null
  br i1 %36, label %49, label %37

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw [48 x i8], ptr %35, i64 %28
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 8
  %40 = load i64, ptr %39, align 8, !tbaa !20
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %49, label %42

42:                                               ; preds = %37
  %43 = and i64 %0, 4294967295
  %44 = getelementptr inbounds nuw [48 x i8], ptr %35, i64 %43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 28
  %46 = load i32, ptr %45, align 4, !tbaa !23
  %47 = add i32 %46, -2
  %48 = icmp ult i32 %47, 3
  br i1 %48, label %51, label %49

49:                                               ; preds = %42, %17, %11, %10, %20, %27, %26, %37, %34
  %50 = phi i32 [ 6, %34 ], [ 6, %37 ], [ 5, %26 ], [ 6, %27 ], [ %25, %20 ], [ 1, %42 ], [ 5, %10 ], [ 6, %11 ], [ 6, %17 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  br label %61

51:                                               ; preds = %42
  %52 = getelementptr inbounds nuw i8, ptr %44, i64 16
  %53 = load i32, ptr %52, align 8, !tbaa !34
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  store i64 0, ptr %6, align 8, !tbaa !16
  %54 = icmp eq i32 %2, 1
  %55 = trunc i64 %1 to i32
  %56 = select i1 %54, i32 %55, i32 0
  %57 = icmp eq i32 %4, 1
  %58 = trunc i64 %3 to i32
  %59 = select i1 %57, i32 %58, i32 %53
  %60 = call i32 @nms_vm_array_slice(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %56, i32 noundef %59, ptr noundef nonnull %6) #25
  br label %61

61:                                               ; preds = %49, %51
  %62 = phi i32 [ %60, %51 ], [ %50, %49 ]
  %63 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %64 = icmp eq i32 %63, 0
  %65 = icmp ne i32 %62, 0
  %66 = and i1 %65, %64
  br i1 %66, label %67, label %68

67:                                               ; preds = %61
  store i32 %62, ptr @nms_module_error, align 4, !tbaa !12
  br label %68

68:                                               ; preds = %61, %67
  %69 = load i64, ptr %6, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  ret i64 %69
}

; Function Attrs: nounwind ssp
define i64 @nms_module_array_create(i32 noundef %0) local_unnamed_addr #3 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #27
  store i64 0, ptr %2, align 8, !tbaa !16
  %3 = call fastcc range(i32 0, 7) i32 @vm_array_create_capacity(ptr noundef nonnull @nms_module_instance, i32 noundef %0, i32 noundef 8, ptr noundef nonnull %2) #25
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !12
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #27
  ret i64 %10
}

; Function Attrs: nounwind ssp
define i64 @nms_module_split_values(i64 noundef %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  store i64 0, ptr %3, align 8, !tbaa !16
  %4 = call fastcc range(i32 0, 7) i32 @split_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3, i32 noundef 1) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  ret i64 %11
}

; Function Attrs: nounwind ssp
define range(i32 0, 7) i32 @nms_module_array_append_value(i64 noundef %0, i64 noundef %1, i32 noundef %2) local_unnamed_addr #3 {
  %4 = insertvalue [2 x i64] poison, i64 %1, 0
  %5 = zext i32 %2 to i64
  %6 = insertvalue [2 x i64] %4, i64 %5, 1
  %7 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef 0, [2 x i64] %6, i32 noundef 1) #25
  %8 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %9 = icmp eq i32 %8, 0
  %10 = icmp ne i32 %7, 0
  %11 = and i1 %10, %9
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  store i32 %7, ptr @nms_module_error, align 4, !tbaa !12
  br label %13

13:                                               ; preds = %3, %12
  ret i32 %7
}

; Function Attrs: nounwind ssp
define range(i32 0, 8) i32 @nms_module_array_set_value(i64 noundef %0, i64 noundef %1, i64 noundef %2, i32 noundef %3) local_unnamed_addr #3 {
  %5 = icmp sgt i64 %0, -1
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %7 = icmp eq i32 %6, 0
  br i1 %5, label %8, label %24

8:                                                ; preds = %4
  br i1 %7, label %9, label %57

9:                                                ; preds = %8
  %10 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %11 = freeze i32 %10
  %12 = zext i32 %11 to i64
  %13 = add nsw i64 %0, -1
  %14 = icmp ult i64 %13, %12
  br i1 %14, label %15, label %57

15:                                               ; preds = %9
  %16 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %17 = icmp eq ptr %16, null
  br i1 %17, label %57, label %18

18:                                               ; preds = %15
  %19 = getelementptr [16 x i8], ptr %16, i64 %0
  %20 = getelementptr i8, ptr %19, i64 -16
  %21 = load ptr, ptr %20, align 8, !tbaa !25
  %22 = icmp eq ptr %21, null
  %23 = select i1 %22, i32 6, i32 1
  br label %57

24:                                               ; preds = %4
  br i1 %7, label %25, label %57

25:                                               ; preds = %24
  %26 = and i64 %0, 9223372036854775807
  %27 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %28 = freeze i32 %27
  %29 = zext i32 %28 to i64
  %30 = add nsw i64 %26, -1
  %31 = icmp ult i64 %30, %29
  br i1 %31, label %32, label %57

32:                                               ; preds = %25
  %33 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %34 = icmp eq ptr %33, null
  br i1 %34, label %57, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw [48 x i8], ptr %33, i64 %26
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %38 = load i64, ptr %37, align 8, !tbaa !20
  %39 = icmp eq i64 %38, 0
  br i1 %39, label %57, label %40

40:                                               ; preds = %35
  %41 = and i64 %0, 4294967295
  %42 = getelementptr inbounds nuw [48 x i8], ptr %33, i64 %41
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 28
  %44 = load i32, ptr %43, align 4, !tbaa !23
  %45 = add i32 %44, -2
  %46 = icmp ult i32 %45, 3
  br i1 %46, label %47, label %57

47:                                               ; preds = %40
  %48 = getelementptr inbounds nuw i8, ptr %42, i64 16
  %49 = load i32, ptr %48, align 8, !tbaa !34
  %50 = zext i32 %49 to i64
  %51 = icmp ult i64 %1, %50
  br i1 %51, label %52, label %57

52:                                               ; preds = %47
  %53 = insertvalue [2 x i64] poison, i64 %2, 0
  %54 = zext i32 %3 to i64
  %55 = insertvalue [2 x i64] %53, i64 %54, 1
  %56 = tail call fastcc range(i32 0, 7) i32 @value_array_write(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, [2 x i64] %55, i32 noundef 0) #25
  br label %57

57:                                               ; preds = %32, %35, %24, %25, %18, %8, %9, %15, %40, %47, %52
  %58 = phi i32 [ %56, %52 ], [ 7, %47 ], [ 6, %32 ], [ 6, %35 ], [ 5, %24 ], [ 6, %25 ], [ %23, %18 ], [ 1, %40 ], [ 5, %8 ], [ 6, %9 ], [ 6, %15 ]
  %59 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %60 = icmp eq i32 %59, 0
  %61 = icmp ne i32 %58, 0
  %62 = and i1 %61, %60
  br i1 %62, label %63, label %64

63:                                               ; preds = %57
  store i32 %58, ptr @nms_module_error, align 4, !tbaa !12
  br label %64

64:                                               ; preds = %57, %63
  ret i32 %58
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_module_array_get_value(i64 noundef %0, i64 noundef %1, ptr nofree noundef writeonly captures(address_is_null) %2, ptr nofree noundef writeonly captures(address_is_null) %3) local_unnamed_addr #8 {
  %5 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %5, i8 0, i64 16, i1 false)
  %6 = icmp ne ptr %2, null
  %7 = icmp ne ptr %3, null
  %8 = and i1 %6, %7
  br i1 %8, label %9, label %16

9:                                                ; preds = %4
  %10 = call i32 @nms_value_array_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %5) #25
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %12, label %16

12:                                               ; preds = %9
  %13 = load i64, ptr %5, align 8, !tbaa !128
  store i64 %13, ptr %2, align 8, !tbaa !16
  %14 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %15 = load i32, ptr %14, align 8, !tbaa !130
  store i32 %15, ptr %3, align 4, !tbaa !12
  br label %21

16:                                               ; preds = %4, %9
  %17 = phi i32 [ %10, %9 ], [ 6, %4 ]
  %18 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %20, label %21

20:                                               ; preds = %16
  store i32 %17, ptr @nms_module_error, align 4, !tbaa !12
  br label %21

21:                                               ; preds = %12, %16, %20
  %22 = phi i32 [ 0, %12 ], [ %17, %16 ], [ %17, %20 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  ret i32 %22
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define range(i32 0, 7) i32 @nms_module_array_pop_value(i64 noundef %0, ptr nofree noundef writeonly captures(address_is_null) %1, ptr nofree noundef writeonly captures(address_is_null) %2) local_unnamed_addr #8 {
  %4 = alloca %struct.NmsValue, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %4, i8 0, i64 16, i1 false)
  %5 = icmp ne ptr %1, null
  %6 = icmp ne ptr %2, null
  %7 = and i1 %5, %6
  br i1 %7, label %8, label %15

8:                                                ; preds = %3
  %9 = call i32 @nms_value_array_pop(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %4) #25
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %15

11:                                               ; preds = %8
  %12 = load i64, ptr %4, align 8, !tbaa !128
  store i64 %12, ptr %1, align 8, !tbaa !16
  %13 = getelementptr inbounds nuw i8, ptr %4, i64 8
  %14 = load i32, ptr %13, align 8, !tbaa !130
  store i32 %14, ptr %2, align 4, !tbaa !12
  br label %20

15:                                               ; preds = %3, %8
  %16 = phi i32 [ %9, %8 ], [ 6, %3 ]
  %17 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %18 = icmp eq i32 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %15
  store i32 %16, ptr @nms_module_error, align 4, !tbaa !12
  br label %20

20:                                               ; preds = %11, %15, %19
  %21 = phi i32 [ 0, %11 ], [ %16, %15 ], [ %16, %19 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  ret i32 %21
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define i64 @nms_module_array_get(i64 noundef %0, i64 noundef %1) local_unnamed_addr #4 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  store i64 0, ptr %3, align 8, !tbaa !16
  %4 = call i32 @nms_string_array_get(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define i32 @nms_module_array_length(i64 noundef %0) local_unnamed_addr #15 {
  %2 = icmp sgt i64 %0, -1
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %4 = icmp eq i32 %3, 0
  br i1 %2, label %5, label %21

5:                                                ; preds = %1
  br i1 %4, label %6, label %46

6:                                                ; preds = %5
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %8 = freeze i32 %7
  %9 = zext i32 %8 to i64
  %10 = add nsw i64 %0, -1
  %11 = icmp ult i64 %10, %9
  br i1 %11, label %12, label %46

12:                                               ; preds = %6
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %14 = icmp eq ptr %13, null
  br i1 %14, label %46, label %15

15:                                               ; preds = %12
  %16 = getelementptr [16 x i8], ptr %13, i64 %0
  %17 = getelementptr i8, ptr %16, i64 -16
  %18 = load ptr, ptr %17, align 8, !tbaa !25
  %19 = icmp eq ptr %18, null
  %20 = select i1 %19, i32 6, i32 1
  br label %46

21:                                               ; preds = %1
  br i1 %4, label %22, label %46

22:                                               ; preds = %21
  %23 = and i64 %0, 9223372036854775807
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %25 = freeze i32 %24
  %26 = zext i32 %25 to i64
  %27 = add nsw i64 %23, -1
  %28 = icmp ult i64 %27, %26
  br i1 %28, label %29, label %46

29:                                               ; preds = %22
  %30 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %31 = icmp eq ptr %30, null
  br i1 %31, label %46, label %32

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw [48 x i8], ptr %30, i64 %23
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !20
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %46, label %37

37:                                               ; preds = %32
  %38 = and i64 %0, 4294967295
  %39 = getelementptr inbounds nuw [48 x i8], ptr %30, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 28
  %41 = load i32, ptr %40, align 4, !tbaa !23
  %42 = icmp eq i32 %41, 2
  br i1 %42, label %43, label %46

43:                                               ; preds = %37
  %44 = getelementptr inbounds nuw i8, ptr %39, i64 16
  %45 = load i32, ptr %44, align 8, !tbaa !34
  br label %51

46:                                               ; preds = %5, %6, %12, %15, %21, %22, %29, %32, %37
  %47 = phi i32 [ 5, %21 ], [ 1, %37 ], [ 6, %29 ], [ 6, %12 ], [ 6, %6 ], [ 5, %5 ], [ 6, %32 ], [ %20, %15 ], [ 6, %22 ]
  %48 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %49 = icmp eq i32 %48, 0
  br i1 %49, label %50, label %51

50:                                               ; preds = %46
  store i32 %47, ptr @nms_module_error, align 4, !tbaa !12
  br label %51

51:                                               ; preds = %43, %46, %50
  %52 = phi i32 [ %45, %43 ], [ 0, %46 ], [ 0, %50 ]
  ret i32 %52
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define i32 @nms_module_array_value_length(i64 noundef %0) local_unnamed_addr #15 {
  %2 = icmp sgt i64 %0, -1
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %4 = icmp eq i32 %3, 0
  br i1 %2, label %5, label %21

5:                                                ; preds = %1
  br i1 %4, label %6, label %47

6:                                                ; preds = %5
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %8 = freeze i32 %7
  %9 = zext i32 %8 to i64
  %10 = add nsw i64 %0, -1
  %11 = icmp ult i64 %10, %9
  br i1 %11, label %12, label %47

12:                                               ; preds = %6
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %14 = icmp eq ptr %13, null
  br i1 %14, label %47, label %15

15:                                               ; preds = %12
  %16 = getelementptr [16 x i8], ptr %13, i64 %0
  %17 = getelementptr i8, ptr %16, i64 -16
  %18 = load ptr, ptr %17, align 8, !tbaa !25
  %19 = icmp eq ptr %18, null
  %20 = select i1 %19, i32 6, i32 1
  br label %47

21:                                               ; preds = %1
  br i1 %4, label %22, label %47

22:                                               ; preds = %21
  %23 = and i64 %0, 9223372036854775807
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %25 = freeze i32 %24
  %26 = zext i32 %25 to i64
  %27 = add nsw i64 %23, -1
  %28 = icmp ult i64 %27, %26
  br i1 %28, label %29, label %47

29:                                               ; preds = %22
  %30 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %31 = icmp eq ptr %30, null
  br i1 %31, label %47, label %32

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw [48 x i8], ptr %30, i64 %23
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !20
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %47, label %37

37:                                               ; preds = %32
  %38 = and i64 %0, 4294967295
  %39 = getelementptr inbounds nuw [48 x i8], ptr %30, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 28
  %41 = load i32, ptr %40, align 4, !tbaa !23
  %42 = add i32 %41, -2
  %43 = icmp ult i32 %42, 3
  br i1 %43, label %44, label %47

44:                                               ; preds = %37
  %45 = getelementptr inbounds nuw i8, ptr %39, i64 16
  %46 = load i32, ptr %45, align 8, !tbaa !34
  br label %52

47:                                               ; preds = %5, %6, %12, %15, %21, %22, %29, %32, %37
  %48 = phi i32 [ 5, %21 ], [ 1, %37 ], [ 6, %29 ], [ 6, %12 ], [ 6, %6 ], [ 5, %5 ], [ 6, %32 ], [ %20, %15 ], [ 6, %22 ]
  %49 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %50 = icmp eq i32 %49, 0
  br i1 %50, label %51, label %52

51:                                               ; preds = %47
  store i32 %48, ptr @nms_module_error, align 4, !tbaa !12
  br label %52

52:                                               ; preds = %44, %47, %51
  %53 = phi i32 [ %46, %44 ], [ 0, %47 ], [ 0, %51 ]
  ret i32 %53
}

; Function Attrs: nounwind ssp
define i64 @nms_module_replace(i64 noundef %0, i64 noundef %1, i64 noundef %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #27
  store i64 0, ptr %4, align 8, !tbaa !16
  %5 = call i32 @nms_replace_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, i64 noundef %2, ptr noundef nonnull %4) #25
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !12
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i64, ptr %4, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  ret i64 %12
}

; Function Attrs: nounwind ssp
define i64 @nms_module_case(i64 noundef %0, i32 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  store i64 0, ptr %3, align 8, !tbaa !16
  %4 = call i32 @nms_case_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, ptr noundef nonnull %3) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  ret i64 %11
}

; Function Attrs: nounwind ssp
define i64 @nms_module_trim(i64 noundef %0) local_unnamed_addr #3 {
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #27
  store i64 0, ptr %2, align 8, !tbaa !16
  %3 = call i32 @nms_trim_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, ptr noundef nonnull %2) #25
  %4 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %5 = icmp eq i32 %4, 0
  %6 = icmp ne i32 %3, 0
  %7 = and i1 %6, %5
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  store i32 %3, ptr @nms_module_error, align 4, !tbaa !12
  br label %9

9:                                                ; preds = %1, %8
  %10 = load i64, ptr %2, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #27
  ret i64 %10
}

; Function Attrs: nounwind ssp
define i64 @nms_module_substr(i64 noundef %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #3 {
  %4 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #27
  store i64 0, ptr %4, align 8, !tbaa !16
  %5 = call i32 @nms_substr_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull %4) #25
  %6 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %7 = icmp eq i32 %6, 0
  %8 = icmp ne i32 %5, 0
  %9 = and i1 %8, %7
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i32 %5, ptr @nms_module_error, align 4, !tbaa !12
  br label %11

11:                                               ; preds = %3, %10
  %12 = load i64, ptr %4, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #27
  ret i64 %12
}

; Function Attrs: nounwind ssp
define i64 @nms_module_concat(i64 noundef %0, i64 noundef %1) local_unnamed_addr #3 {
  %3 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  store i64 0, ptr %3, align 8, !tbaa !16
  %4 = call i32 @nms_concat_owned(ptr noundef nonnull @nms_module_instance, i64 noundef %0, i64 noundef %1, ptr noundef nonnull %3) #25
  %5 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %6 = icmp eq i32 %5, 0
  %7 = icmp ne i32 %4, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  store i32 %4, ptr @nms_module_error, align 4, !tbaa !12
  br label %10

10:                                               ; preds = %2, %9
  %11 = load i64, ptr %3, align 8, !tbaa !16
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  ret i64 %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define range(i64 0, 4294967296) i64 @nms_module_length(i64 noundef %0) local_unnamed_addr #15 {
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %4, label %45

4:                                                ; preds = %1
  %5 = icmp sgt i64 %0, -1
  br i1 %5, label %29, label %6

6:                                                ; preds = %4
  %7 = and i64 %0, 9223372036854775807
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %9 = freeze i32 %8
  %10 = zext i32 %9 to i64
  %11 = add nsw i64 %7, -1
  %12 = icmp ult i64 %11, %10
  br i1 %12, label %13, label %45

13:                                               ; preds = %6
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %15 = icmp eq ptr %14, null
  br i1 %15, label %45, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw [48 x i8], ptr %14, i64 %7
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 8
  %19 = load i64, ptr %18, align 8, !tbaa !20
  %20 = icmp eq i64 %19, 0
  br i1 %20, label %45, label %21

21:                                               ; preds = %16
  %22 = and i64 %0, 4294967295
  %23 = getelementptr inbounds nuw [48 x i8], ptr %14, i64 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 28
  %25 = load i32, ptr %24, align 4, !tbaa !23
  %26 = icmp eq i32 %25, 1
  br i1 %26, label %27, label %45

27:                                               ; preds = %21
  %28 = getelementptr inbounds nuw i8, ptr %23, i64 16
  br label %50

29:                                               ; preds = %4
  %30 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %31 = freeze i32 %30
  %32 = zext i32 %31 to i64
  %33 = add nsw i64 %0, -1
  %34 = icmp ult i64 %33, %32
  br i1 %34, label %35, label %45

35:                                               ; preds = %29
  %36 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %37 = icmp eq ptr %36, null
  br i1 %37, label %45, label %38

38:                                               ; preds = %35
  %39 = getelementptr [16 x i8], ptr %36, i64 %0
  %40 = getelementptr i8, ptr %39, i64 -16
  %41 = load ptr, ptr %40, align 8, !tbaa !25
  %42 = icmp eq ptr %41, null
  br i1 %42, label %45, label %43

43:                                               ; preds = %38
  %44 = getelementptr i8, ptr %39, i64 -8
  br label %50

45:                                               ; preds = %1, %6, %13, %16, %21, %29, %35, %38
  %46 = phi i32 [ 6, %6 ], [ 6, %38 ], [ 6, %16 ], [ 5, %1 ], [ 6, %29 ], [ 6, %35 ], [ 1, %21 ], [ 6, %13 ]
  %47 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %49, label %54

49:                                               ; preds = %45
  store i32 %46, ptr @nms_module_error, align 4, !tbaa !12
  br label %54

50:                                               ; preds = %43, %27
  %51 = phi ptr [ %28, %27 ], [ %44, %43 ]
  %52 = load i32, ptr %51, align 8, !tbaa !12
  %53 = zext i32 %52 to i64
  br label %54

54:                                               ; preds = %49, %45, %50
  %55 = phi i64 [ %53, %50 ], [ 0, %45 ], [ 0, %49 ]
  ret i64 %55
}

; Function Attrs: nofree norecurse nosync nounwind ssp memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define range(i64 -4294967295, 4294967296) i64 @nms_module_order(i64 noundef %0, i64 noundef %1) local_unnamed_addr #16 {
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 80), align 8, !tbaa !17
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %92

5:                                                ; preds = %2
  %6 = icmp sgt i64 %0, -1
  br i1 %6, label %31, label %7

7:                                                ; preds = %5
  %8 = and i64 %0, 9223372036854775807
  %9 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %10 = freeze i32 %9
  %11 = zext i32 %10 to i64
  %12 = add nsw i64 %8, -1
  %13 = icmp ult i64 %12, %11
  br i1 %13, label %14, label %92

14:                                               ; preds = %7
  %15 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %16 = icmp eq ptr %15, null
  br i1 %16, label %92, label %17

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw [48 x i8], ptr %15, i64 %8
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 8
  %20 = load i64, ptr %19, align 8, !tbaa !20
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %92, label %22

22:                                               ; preds = %17
  %23 = and i64 %0, 4294967295
  %24 = getelementptr inbounds nuw [48 x i8], ptr %15, i64 %23
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 28
  %26 = load i32, ptr %25, align 4, !tbaa !23
  %27 = icmp eq i32 %26, 1
  br i1 %27, label %28, label %92

28:                                               ; preds = %22
  %29 = load ptr, ptr %24, align 8, !tbaa !24
  %30 = getelementptr inbounds nuw i8, ptr %24, i64 16
  br label %47

31:                                               ; preds = %5
  %32 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %33 = freeze i32 %32
  %34 = zext i32 %33 to i64
  %35 = add nsw i64 %0, -1
  %36 = icmp ult i64 %35, %34
  br i1 %36, label %37, label %92

37:                                               ; preds = %31
  %38 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %39 = icmp eq ptr %38, null
  br i1 %39, label %92, label %40

40:                                               ; preds = %37
  %41 = getelementptr [16 x i8], ptr %38, i64 %0
  %42 = getelementptr i8, ptr %41, i64 -16
  %43 = load ptr, ptr %42, align 8, !tbaa !25
  %44 = icmp eq ptr %43, null
  br i1 %44, label %92, label %45

45:                                               ; preds = %40
  %46 = getelementptr i8, ptr %41, i64 -8
  br label %47

47:                                               ; preds = %28, %45
  %48 = phi ptr [ %43, %45 ], [ %29, %28 ]
  %49 = phi ptr [ %46, %45 ], [ %30, %28 ]
  %50 = load i32, ptr %49, align 8, !tbaa !12
  %51 = icmp sgt i64 %1, -1
  br i1 %51, label %76, label %52

52:                                               ; preds = %47
  %53 = and i64 %1, 9223372036854775807
  %54 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 68), align 4
  %55 = freeze i32 %54
  %56 = zext i32 %55 to i64
  %57 = add nsw i64 %53, -1
  %58 = icmp ult i64 %57, %56
  br i1 %58, label %59, label %92

59:                                               ; preds = %52
  %60 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 24), align 8, !tbaa !19
  %61 = icmp eq ptr %60, null
  br i1 %61, label %92, label %62

62:                                               ; preds = %59
  %63 = getelementptr inbounds nuw [48 x i8], ptr %60, i64 %53
  %64 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %65 = load i64, ptr %64, align 8, !tbaa !20
  %66 = icmp eq i64 %65, 0
  br i1 %66, label %92, label %67

67:                                               ; preds = %62
  %68 = and i64 %1, 4294967295
  %69 = getelementptr inbounds nuw [48 x i8], ptr %60, i64 %68
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 28
  %71 = load i32, ptr %70, align 4, !tbaa !23
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %73, label %92

73:                                               ; preds = %67
  %74 = load ptr, ptr %69, align 8, !tbaa !24
  %75 = getelementptr inbounds nuw i8, ptr %69, i64 16
  br label %97

76:                                               ; preds = %47
  %77 = load i32, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 64), align 8
  %78 = freeze i32 %77
  %79 = zext i32 %78 to i64
  %80 = add nsw i64 %1, -1
  %81 = icmp ult i64 %80, %79
  br i1 %81, label %82, label %92

82:                                               ; preds = %76
  %83 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 16), align 8, !tbaa !13
  %84 = icmp eq ptr %83, null
  br i1 %84, label %92, label %85

85:                                               ; preds = %82
  %86 = getelementptr [16 x i8], ptr %83, i64 %1
  %87 = getelementptr i8, ptr %86, i64 -16
  %88 = load ptr, ptr %87, align 8, !tbaa !25
  %89 = icmp eq ptr %88, null
  br i1 %89, label %92, label %90

90:                                               ; preds = %85
  %91 = getelementptr i8, ptr %86, i64 -8
  br label %97

92:                                               ; preds = %7, %22, %14, %37, %31, %2, %17, %40, %85, %82, %76, %67, %62, %59, %52
  %93 = phi i32 [ 1, %67 ], [ 6, %52 ], [ 6, %85 ], [ 6, %62 ], [ 5, %2 ], [ 6, %76 ], [ 6, %82 ], [ 6, %31 ], [ 6, %59 ], [ 6, %40 ], [ 6, %7 ], [ 1, %22 ], [ 6, %14 ], [ 6, %17 ], [ 6, %37 ]
  %94 = load i32, ptr @nms_module_error, align 4, !tbaa !12
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %96, label %123

96:                                               ; preds = %92
  store i32 %93, ptr @nms_module_error, align 4, !tbaa !12
  br label %123

97:                                               ; preds = %90, %73
  %98 = phi ptr [ %88, %90 ], [ %74, %73 ]
  %99 = phi ptr [ %91, %90 ], [ %75, %73 ]
  %100 = load i32, ptr %99, align 8, !tbaa !12
  %101 = tail call i32 @llvm.umin.i32(i32 %50, i32 %100)
  %102 = icmp eq i32 %101, 0
  br i1 %102, label %115, label %103

103:                                              ; preds = %97
  %104 = zext i32 %101 to i64
  br label %108

105:                                              ; preds = %108
  %106 = add nuw nsw i64 %109, 1
  %107 = icmp eq i64 %106, %104
  br i1 %107, label %115, label %108, !llvm.loop !131

108:                                              ; preds = %103, %105
  %109 = phi i64 [ 0, %103 ], [ %106, %105 ]
  %110 = getelementptr inbounds nuw i8, ptr %48, i64 %109
  %111 = load i8, ptr %110, align 1, !tbaa !39
  %112 = getelementptr inbounds nuw i8, ptr %98, i64 %109
  %113 = load i8, ptr %112, align 1, !tbaa !39
  %114 = icmp eq i8 %111, %113
  br i1 %114, label %105, label %119

115:                                              ; preds = %105, %97
  %116 = zext i32 %50 to i64
  %117 = zext i32 %100 to i64
  %118 = sub nsw i64 %116, %117
  br label %123

119:                                              ; preds = %108
  %120 = zext i8 %111 to i64
  %121 = zext i8 %113 to i64
  %122 = sub nsw i64 %120, %121
  br label %123

123:                                              ; preds = %119, %115, %96, %92
  %124 = phi i64 [ 0, %96 ], [ 0, %92 ], [ %122, %119 ], [ %118, %115 ]
  ret i64 %124
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none)
define i64 @nms_module_live_objects() local_unnamed_addr #14 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 56), align 8, !tbaa !55
  ret i64 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none)
define i64 @nms_module_live_bytes() local_unnamed_addr #14 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @nms_module_instance, i64 48), align 8, !tbaa !31
  ret i64 %1
}

; Function Attrs: allocsize(0)
declare ptr @malloc(i64 noundef) local_unnamed_addr #17

declare void @free(ptr noundef) local_unnamed_addr #18

; Function Attrs: inlinehint nofree norecurse nosync nounwind ssp memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @nbp_shift(ptr nofree noundef nonnull captures(none) %0, i32 noundef %1) unnamed_addr #19 {
  %3 = alloca %struct.NbpBig, align 4
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 512
  %5 = load i32, ptr %4, align 4, !tbaa !97
  %6 = icmp ne i32 %5, 0
  %7 = icmp ne i32 %1, 0
  %8 = and i1 %7, %6
  br i1 %8, label %9, label %251

9:                                                ; preds = %2
  %10 = lshr i32 %1, 5
  %11 = and i32 %1, 31
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %22, label %13

13:                                               ; preds = %9
  %14 = add i32 %5, -1
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %15
  %17 = load i32, ptr %16, align 4, !tbaa !12
  %18 = sub nuw nsw i32 32, %11
  %19 = lshr i32 %17, %18
  %20 = icmp ne i32 %19, 0
  %21 = zext i1 %20 to i32
  br label %22

22:                                               ; preds = %13, %9
  %23 = phi i32 [ 0, %9 ], [ %21, %13 ]
  %24 = icmp ugt i32 %1, 4095
  br i1 %24, label %251, label %25

25:                                               ; preds = %22
  %26 = add i32 %5, %10
  %27 = add i32 %26, %23
  %28 = icmp ugt i32 %27, 128
  br i1 %28, label %251, label %29

29:                                               ; preds = %25
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %3, i8 0, i64 512, i1 false)
  %30 = getelementptr inbounds nuw i8, ptr %3, i64 512
  store i32 %27, ptr %30, align 4, !tbaa !97
  %31 = zext nneg i32 %11 to i64
  %32 = zext i32 %5 to i64
  %33 = and i64 %32, 7
  %34 = icmp ult i32 %5, 8
  br i1 %34, label %39, label %35

35:                                               ; preds = %29
  %36 = and i64 %32, 4294967288
  br label %70

37:                                               ; preds = %247
  %38 = icmp eq i64 %33, 0
  br i1 %38, label %69, label %39

39:                                               ; preds = %37, %29
  %40 = phi i64 [ 0, %29 ], [ %248, %37 ]
  %41 = icmp ne i64 %33, 0
  tail call void @llvm.assume(i1 %41)
  br label %42

42:                                               ; preds = %65, %39
  %43 = phi i64 [ %40, %39 ], [ %66, %65 ]
  %44 = phi i64 [ 0, %39 ], [ %67, %65 ]
  %45 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %43
  %46 = load i32, ptr %45, align 4, !tbaa !12
  %47 = zext i32 %46 to i64
  %48 = shl nuw nsw i64 %47, %31
  %49 = trunc i64 %48 to i32
  %50 = trunc nuw i64 %43 to i32
  %51 = add i32 %10, %50
  %52 = zext i32 %51 to i64
  %53 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %52
  %54 = load i32, ptr %53, align 4, !tbaa !12
  %55 = or i32 %54, %49
  store i32 %55, ptr %53, align 4, !tbaa !12
  %56 = lshr i64 %48, 32
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %65, label %58

58:                                               ; preds = %42
  %59 = trunc nuw nsw i64 %56 to i32
  %60 = add i32 %51, 1
  %61 = zext i32 %60 to i64
  %62 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %61
  %63 = load i32, ptr %62, align 4, !tbaa !12
  %64 = or i32 %63, %59
  store i32 %64, ptr %62, align 4, !tbaa !12
  br label %65

65:                                               ; preds = %58, %42
  %66 = add nuw nsw i64 %43, 1
  %67 = add i64 %44, 1
  %68 = icmp eq i64 %67, %33
  br i1 %68, label %69, label %42, !llvm.loop !132

69:                                               ; preds = %65, %37
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %0, ptr noundef nonnull align 4 dereferenceable(516) %3, i64 516, i1 false), !tbaa.struct !102
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #27
  br label %251

70:                                               ; preds = %247, %35
  %71 = phi i64 [ 0, %35 ], [ %248, %247 ]
  %72 = phi i64 [ 0, %35 ], [ %249, %247 ]
  %73 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %71
  %74 = load i32, ptr %73, align 4, !tbaa !12
  %75 = zext i32 %74 to i64
  %76 = shl nuw nsw i64 %75, %31
  %77 = trunc i64 %76 to i32
  %78 = trunc nuw i64 %71 to i32
  %79 = add i32 %10, %78
  %80 = zext i32 %79 to i64
  %81 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %80
  %82 = load i32, ptr %81, align 4, !tbaa !12
  %83 = or i32 %82, %77
  store i32 %83, ptr %81, align 4, !tbaa !12
  %84 = lshr i64 %76, 32
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %93, label %86

86:                                               ; preds = %70
  %87 = trunc nuw nsw i64 %84 to i32
  %88 = add i32 %79, 1
  %89 = zext i32 %88 to i64
  %90 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %89
  %91 = load i32, ptr %90, align 4, !tbaa !12
  %92 = or i32 %91, %87
  store i32 %92, ptr %90, align 4, !tbaa !12
  br label %93

93:                                               ; preds = %86, %70
  %94 = or disjoint i64 %71, 1
  %95 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %94
  %96 = load i32, ptr %95, align 4, !tbaa !12
  %97 = zext i32 %96 to i64
  %98 = shl nuw nsw i64 %97, %31
  %99 = trunc i64 %98 to i32
  %100 = trunc nuw i64 %94 to i32
  %101 = add i32 %10, %100
  %102 = zext i32 %101 to i64
  %103 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %102
  %104 = load i32, ptr %103, align 4, !tbaa !12
  %105 = or i32 %104, %99
  store i32 %105, ptr %103, align 4, !tbaa !12
  %106 = lshr i64 %98, 32
  %107 = icmp eq i64 %106, 0
  br i1 %107, label %115, label %108

108:                                              ; preds = %93
  %109 = trunc nuw nsw i64 %106 to i32
  %110 = add i32 %101, 1
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %111
  %113 = load i32, ptr %112, align 4, !tbaa !12
  %114 = or i32 %113, %109
  store i32 %114, ptr %112, align 4, !tbaa !12
  br label %115

115:                                              ; preds = %108, %93
  %116 = or disjoint i64 %71, 2
  %117 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %116
  %118 = load i32, ptr %117, align 4, !tbaa !12
  %119 = zext i32 %118 to i64
  %120 = shl nuw nsw i64 %119, %31
  %121 = trunc i64 %120 to i32
  %122 = trunc nuw i64 %116 to i32
  %123 = add i32 %10, %122
  %124 = zext i32 %123 to i64
  %125 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %124
  %126 = load i32, ptr %125, align 4, !tbaa !12
  %127 = or i32 %126, %121
  store i32 %127, ptr %125, align 4, !tbaa !12
  %128 = lshr i64 %120, 32
  %129 = icmp eq i64 %128, 0
  br i1 %129, label %137, label %130

130:                                              ; preds = %115
  %131 = trunc nuw nsw i64 %128 to i32
  %132 = add i32 %123, 1
  %133 = zext i32 %132 to i64
  %134 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %133
  %135 = load i32, ptr %134, align 4, !tbaa !12
  %136 = or i32 %135, %131
  store i32 %136, ptr %134, align 4, !tbaa !12
  br label %137

137:                                              ; preds = %130, %115
  %138 = or disjoint i64 %71, 3
  %139 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %138
  %140 = load i32, ptr %139, align 4, !tbaa !12
  %141 = zext i32 %140 to i64
  %142 = shl nuw nsw i64 %141, %31
  %143 = trunc i64 %142 to i32
  %144 = trunc nuw i64 %138 to i32
  %145 = add i32 %10, %144
  %146 = zext i32 %145 to i64
  %147 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %146
  %148 = load i32, ptr %147, align 4, !tbaa !12
  %149 = or i32 %148, %143
  store i32 %149, ptr %147, align 4, !tbaa !12
  %150 = lshr i64 %142, 32
  %151 = icmp eq i64 %150, 0
  br i1 %151, label %159, label %152

152:                                              ; preds = %137
  %153 = trunc nuw nsw i64 %150 to i32
  %154 = add i32 %145, 1
  %155 = zext i32 %154 to i64
  %156 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %155
  %157 = load i32, ptr %156, align 4, !tbaa !12
  %158 = or i32 %157, %153
  store i32 %158, ptr %156, align 4, !tbaa !12
  br label %159

159:                                              ; preds = %152, %137
  %160 = or disjoint i64 %71, 4
  %161 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %160
  %162 = load i32, ptr %161, align 4, !tbaa !12
  %163 = zext i32 %162 to i64
  %164 = shl nuw nsw i64 %163, %31
  %165 = trunc i64 %164 to i32
  %166 = trunc nuw i64 %160 to i32
  %167 = add i32 %10, %166
  %168 = zext i32 %167 to i64
  %169 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %168
  %170 = load i32, ptr %169, align 4, !tbaa !12
  %171 = or i32 %170, %165
  store i32 %171, ptr %169, align 4, !tbaa !12
  %172 = lshr i64 %164, 32
  %173 = icmp eq i64 %172, 0
  br i1 %173, label %181, label %174

174:                                              ; preds = %159
  %175 = trunc nuw nsw i64 %172 to i32
  %176 = add i32 %167, 1
  %177 = zext i32 %176 to i64
  %178 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %177
  %179 = load i32, ptr %178, align 4, !tbaa !12
  %180 = or i32 %179, %175
  store i32 %180, ptr %178, align 4, !tbaa !12
  br label %181

181:                                              ; preds = %174, %159
  %182 = or disjoint i64 %71, 5
  %183 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %182
  %184 = load i32, ptr %183, align 4, !tbaa !12
  %185 = zext i32 %184 to i64
  %186 = shl nuw nsw i64 %185, %31
  %187 = trunc i64 %186 to i32
  %188 = trunc nuw i64 %182 to i32
  %189 = add i32 %10, %188
  %190 = zext i32 %189 to i64
  %191 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %190
  %192 = load i32, ptr %191, align 4, !tbaa !12
  %193 = or i32 %192, %187
  store i32 %193, ptr %191, align 4, !tbaa !12
  %194 = lshr i64 %186, 32
  %195 = icmp eq i64 %194, 0
  br i1 %195, label %203, label %196

196:                                              ; preds = %181
  %197 = trunc nuw nsw i64 %194 to i32
  %198 = add i32 %189, 1
  %199 = zext i32 %198 to i64
  %200 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %199
  %201 = load i32, ptr %200, align 4, !tbaa !12
  %202 = or i32 %201, %197
  store i32 %202, ptr %200, align 4, !tbaa !12
  br label %203

203:                                              ; preds = %196, %181
  %204 = or disjoint i64 %71, 6
  %205 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %204
  %206 = load i32, ptr %205, align 4, !tbaa !12
  %207 = zext i32 %206 to i64
  %208 = shl nuw nsw i64 %207, %31
  %209 = trunc i64 %208 to i32
  %210 = trunc nuw i64 %204 to i32
  %211 = add i32 %10, %210
  %212 = zext i32 %211 to i64
  %213 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %212
  %214 = load i32, ptr %213, align 4, !tbaa !12
  %215 = or i32 %214, %209
  store i32 %215, ptr %213, align 4, !tbaa !12
  %216 = lshr i64 %208, 32
  %217 = icmp eq i64 %216, 0
  br i1 %217, label %225, label %218

218:                                              ; preds = %203
  %219 = trunc nuw nsw i64 %216 to i32
  %220 = add i32 %211, 1
  %221 = zext i32 %220 to i64
  %222 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %221
  %223 = load i32, ptr %222, align 4, !tbaa !12
  %224 = or i32 %223, %219
  store i32 %224, ptr %222, align 4, !tbaa !12
  br label %225

225:                                              ; preds = %218, %203
  %226 = or disjoint i64 %71, 7
  %227 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %226
  %228 = load i32, ptr %227, align 4, !tbaa !12
  %229 = zext i32 %228 to i64
  %230 = shl nuw nsw i64 %229, %31
  %231 = trunc i64 %230 to i32
  %232 = trunc nuw i64 %226 to i32
  %233 = add i32 %10, %232
  %234 = zext i32 %233 to i64
  %235 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %234
  %236 = load i32, ptr %235, align 4, !tbaa !12
  %237 = or i32 %236, %231
  store i32 %237, ptr %235, align 4, !tbaa !12
  %238 = lshr i64 %230, 32
  %239 = icmp eq i64 %238, 0
  br i1 %239, label %247, label %240

240:                                              ; preds = %225
  %241 = trunc nuw nsw i64 %238 to i32
  %242 = add i32 %233, 1
  %243 = zext i32 %242 to i64
  %244 = getelementptr inbounds nuw [4 x i8], ptr %3, i64 %243
  %245 = load i32, ptr %244, align 4, !tbaa !12
  %246 = or i32 %245, %241
  store i32 %246, ptr %244, align 4, !tbaa !12
  br label %247

247:                                              ; preds = %240, %225
  %248 = add nuw nsw i64 %71, 8
  %249 = add i64 %72, 8
  %250 = icmp eq i64 %249, %36
  br i1 %250, label %37, label %70, !llvm.loop !133

251:                                              ; preds = %69, %25, %22, %2
  %252 = phi i32 [ 1, %2 ], [ 1, %69 ], [ 0, %25 ], [ 0, %22 ]
  ret i32 %252
}

; Function Attrs: inlinehint nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc range(i32 0, 2) i32 @nbp_rational(ptr nofree noundef nonnull align 4 captures(none) dead_on_return %0, ptr nofree noundef nonnull align 4 captures(none) dead_on_return %1, i32 noundef range(i32 0, 2) %2, ptr nofree noundef nonnull writeonly captures(none) %3) unnamed_addr #20 {
  %5 = alloca %struct.NbpBig, align 4
  %6 = alloca %struct.NbpBig, align 4
  %7 = alloca %struct.NbpBig, align 4
  %8 = alloca %struct.NbpBig, align 4
  %9 = alloca %struct.NbpBig, align 4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 512
  %11 = load i32, ptr %10, align 4, !tbaa !97
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %21, label %13

13:                                               ; preds = %4
  %14 = add i32 %11, -1
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %15
  %17 = load i32, ptr %16, align 4, !tbaa !12
  %18 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %17, i1 false)
  %19 = shl i32 %11, 5
  %20 = sub i32 %19, %18
  br label %21

21:                                               ; preds = %4, %13
  %22 = phi i32 [ %20, %13 ], [ 0, %4 ]
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 512
  %24 = load i32, ptr %23, align 4, !tbaa !97
  %25 = icmp eq i32 %24, 0
  br i1 %25, label %34, label %26

26:                                               ; preds = %21
  %27 = add i32 %24, -1
  %28 = zext i32 %27 to i64
  %29 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %28
  %30 = load i32, ptr %29, align 4, !tbaa !12
  %31 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %30, i1 false)
  %32 = shl i32 %24, 5
  %33 = sub i32 %31, %32
  br label %34

34:                                               ; preds = %21, %26
  %35 = phi i32 [ %33, %26 ], [ 0, %21 ]
  %36 = add i32 %35, %22
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #27
  %37 = icmp slt i32 %36, 0
  %38 = select i1 %37, ptr %0, ptr %1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %38, i64 516, i1 false)
  %39 = tail call i32 @llvm.abs.i32(i32 %36, i1 true)
  %40 = getelementptr inbounds nuw i8, ptr %9, i64 512
  %41 = load i32, ptr %40, align 4, !tbaa !97
  %42 = icmp ne i32 %41, 0
  %43 = icmp ne i32 %36, 0
  %44 = and i1 %43, %42
  br i1 %44, label %45, label %287

45:                                               ; preds = %34
  %46 = lshr i32 %39, 5
  %47 = and i32 %39, 31
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %58, label %49

49:                                               ; preds = %45
  %50 = add i32 %41, -1
  %51 = zext i32 %50 to i64
  %52 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %51
  %53 = load i32, ptr %52, align 4, !tbaa !12
  %54 = sub nuw nsw i32 32, %47
  %55 = lshr i32 %53, %54
  %56 = icmp ne i32 %55, 0
  %57 = zext i1 %56 to i32
  br label %58

58:                                               ; preds = %49, %45
  %59 = phi i32 [ 0, %45 ], [ %57, %49 ]
  %60 = icmp samesign ugt i32 %39, 4095
  br i1 %60, label %1152, label %61

61:                                               ; preds = %58
  %62 = add i32 %41, %46
  %63 = add i32 %62, %59
  %64 = icmp ugt i32 %63, 128
  br i1 %64, label %1152, label %65

65:                                               ; preds = %61
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %8, i8 0, i64 512, i1 false)
  %66 = getelementptr inbounds nuw i8, ptr %8, i64 512
  store i32 %63, ptr %66, align 4, !tbaa !97
  %67 = zext nneg i32 %47 to i64
  %68 = zext i32 %41 to i64
  %69 = and i64 %68, 7
  %70 = icmp ult i32 %41, 8
  br i1 %70, label %75, label %71

71:                                               ; preds = %65
  %72 = and i64 %68, 4294967288
  br label %106

73:                                               ; preds = %283
  %74 = icmp eq i64 %69, 0
  br i1 %74, label %105, label %75

75:                                               ; preds = %73, %65
  %76 = phi i64 [ 0, %65 ], [ %284, %73 ]
  %77 = icmp ne i64 %69, 0
  tail call void @llvm.assume(i1 %77)
  br label %78

78:                                               ; preds = %101, %75
  %79 = phi i64 [ %76, %75 ], [ %102, %101 ]
  %80 = phi i64 [ 0, %75 ], [ %103, %101 ]
  %81 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %79
  %82 = load i32, ptr %81, align 4, !tbaa !12
  %83 = zext i32 %82 to i64
  %84 = shl nuw nsw i64 %83, %67
  %85 = trunc i64 %84 to i32
  %86 = trunc nuw i64 %79 to i32
  %87 = add i32 %46, %86
  %88 = zext i32 %87 to i64
  %89 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %88
  %90 = load i32, ptr %89, align 4, !tbaa !12
  %91 = or i32 %90, %85
  store i32 %91, ptr %89, align 4, !tbaa !12
  %92 = lshr i64 %84, 32
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %101, label %94

94:                                               ; preds = %78
  %95 = trunc nuw nsw i64 %92 to i32
  %96 = add i32 %87, 1
  %97 = zext i32 %96 to i64
  %98 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %97
  %99 = load i32, ptr %98, align 4, !tbaa !12
  %100 = or i32 %99, %95
  store i32 %100, ptr %98, align 4, !tbaa !12
  br label %101

101:                                              ; preds = %94, %78
  %102 = add nuw nsw i64 %79, 1
  %103 = add i64 %80, 1
  %104 = icmp eq i64 %103, %69
  br i1 %104, label %105, label %78, !llvm.loop !134

105:                                              ; preds = %101, %73
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %8, i64 516, i1 false), !tbaa.struct !102
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #27
  br label %287

106:                                              ; preds = %283, %71
  %107 = phi i64 [ 0, %71 ], [ %284, %283 ]
  %108 = phi i64 [ 0, %71 ], [ %285, %283 ]
  %109 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %107
  %110 = load i32, ptr %109, align 4, !tbaa !12
  %111 = zext i32 %110 to i64
  %112 = shl nuw nsw i64 %111, %67
  %113 = trunc i64 %112 to i32
  %114 = trunc nuw i64 %107 to i32
  %115 = add i32 %46, %114
  %116 = zext i32 %115 to i64
  %117 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %116
  %118 = load i32, ptr %117, align 4, !tbaa !12
  %119 = or i32 %118, %113
  store i32 %119, ptr %117, align 4, !tbaa !12
  %120 = lshr i64 %112, 32
  %121 = icmp eq i64 %120, 0
  br i1 %121, label %129, label %122

122:                                              ; preds = %106
  %123 = trunc nuw nsw i64 %120 to i32
  %124 = add i32 %115, 1
  %125 = zext i32 %124 to i64
  %126 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %125
  %127 = load i32, ptr %126, align 4, !tbaa !12
  %128 = or i32 %127, %123
  store i32 %128, ptr %126, align 4, !tbaa !12
  br label %129

129:                                              ; preds = %122, %106
  %130 = or disjoint i64 %107, 1
  %131 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %130
  %132 = load i32, ptr %131, align 4, !tbaa !12
  %133 = zext i32 %132 to i64
  %134 = shl nuw nsw i64 %133, %67
  %135 = trunc i64 %134 to i32
  %136 = trunc nuw i64 %130 to i32
  %137 = add i32 %46, %136
  %138 = zext i32 %137 to i64
  %139 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %138
  %140 = load i32, ptr %139, align 4, !tbaa !12
  %141 = or i32 %140, %135
  store i32 %141, ptr %139, align 4, !tbaa !12
  %142 = lshr i64 %134, 32
  %143 = icmp eq i64 %142, 0
  br i1 %143, label %151, label %144

144:                                              ; preds = %129
  %145 = trunc nuw nsw i64 %142 to i32
  %146 = add i32 %137, 1
  %147 = zext i32 %146 to i64
  %148 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %147
  %149 = load i32, ptr %148, align 4, !tbaa !12
  %150 = or i32 %149, %145
  store i32 %150, ptr %148, align 4, !tbaa !12
  br label %151

151:                                              ; preds = %144, %129
  %152 = or disjoint i64 %107, 2
  %153 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %152
  %154 = load i32, ptr %153, align 4, !tbaa !12
  %155 = zext i32 %154 to i64
  %156 = shl nuw nsw i64 %155, %67
  %157 = trunc i64 %156 to i32
  %158 = trunc nuw i64 %152 to i32
  %159 = add i32 %46, %158
  %160 = zext i32 %159 to i64
  %161 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %160
  %162 = load i32, ptr %161, align 4, !tbaa !12
  %163 = or i32 %162, %157
  store i32 %163, ptr %161, align 4, !tbaa !12
  %164 = lshr i64 %156, 32
  %165 = icmp eq i64 %164, 0
  br i1 %165, label %173, label %166

166:                                              ; preds = %151
  %167 = trunc nuw nsw i64 %164 to i32
  %168 = add i32 %159, 1
  %169 = zext i32 %168 to i64
  %170 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %169
  %171 = load i32, ptr %170, align 4, !tbaa !12
  %172 = or i32 %171, %167
  store i32 %172, ptr %170, align 4, !tbaa !12
  br label %173

173:                                              ; preds = %166, %151
  %174 = or disjoint i64 %107, 3
  %175 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %174
  %176 = load i32, ptr %175, align 4, !tbaa !12
  %177 = zext i32 %176 to i64
  %178 = shl nuw nsw i64 %177, %67
  %179 = trunc i64 %178 to i32
  %180 = trunc nuw i64 %174 to i32
  %181 = add i32 %46, %180
  %182 = zext i32 %181 to i64
  %183 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %182
  %184 = load i32, ptr %183, align 4, !tbaa !12
  %185 = or i32 %184, %179
  store i32 %185, ptr %183, align 4, !tbaa !12
  %186 = lshr i64 %178, 32
  %187 = icmp eq i64 %186, 0
  br i1 %187, label %195, label %188

188:                                              ; preds = %173
  %189 = trunc nuw nsw i64 %186 to i32
  %190 = add i32 %181, 1
  %191 = zext i32 %190 to i64
  %192 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %191
  %193 = load i32, ptr %192, align 4, !tbaa !12
  %194 = or i32 %193, %189
  store i32 %194, ptr %192, align 4, !tbaa !12
  br label %195

195:                                              ; preds = %188, %173
  %196 = or disjoint i64 %107, 4
  %197 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %196
  %198 = load i32, ptr %197, align 4, !tbaa !12
  %199 = zext i32 %198 to i64
  %200 = shl nuw nsw i64 %199, %67
  %201 = trunc i64 %200 to i32
  %202 = trunc nuw i64 %196 to i32
  %203 = add i32 %46, %202
  %204 = zext i32 %203 to i64
  %205 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %204
  %206 = load i32, ptr %205, align 4, !tbaa !12
  %207 = or i32 %206, %201
  store i32 %207, ptr %205, align 4, !tbaa !12
  %208 = lshr i64 %200, 32
  %209 = icmp eq i64 %208, 0
  br i1 %209, label %217, label %210

210:                                              ; preds = %195
  %211 = trunc nuw nsw i64 %208 to i32
  %212 = add i32 %203, 1
  %213 = zext i32 %212 to i64
  %214 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %213
  %215 = load i32, ptr %214, align 4, !tbaa !12
  %216 = or i32 %215, %211
  store i32 %216, ptr %214, align 4, !tbaa !12
  br label %217

217:                                              ; preds = %210, %195
  %218 = or disjoint i64 %107, 5
  %219 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %218
  %220 = load i32, ptr %219, align 4, !tbaa !12
  %221 = zext i32 %220 to i64
  %222 = shl nuw nsw i64 %221, %67
  %223 = trunc i64 %222 to i32
  %224 = trunc nuw i64 %218 to i32
  %225 = add i32 %46, %224
  %226 = zext i32 %225 to i64
  %227 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %226
  %228 = load i32, ptr %227, align 4, !tbaa !12
  %229 = or i32 %228, %223
  store i32 %229, ptr %227, align 4, !tbaa !12
  %230 = lshr i64 %222, 32
  %231 = icmp eq i64 %230, 0
  br i1 %231, label %239, label %232

232:                                              ; preds = %217
  %233 = trunc nuw nsw i64 %230 to i32
  %234 = add i32 %225, 1
  %235 = zext i32 %234 to i64
  %236 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %235
  %237 = load i32, ptr %236, align 4, !tbaa !12
  %238 = or i32 %237, %233
  store i32 %238, ptr %236, align 4, !tbaa !12
  br label %239

239:                                              ; preds = %232, %217
  %240 = or disjoint i64 %107, 6
  %241 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %240
  %242 = load i32, ptr %241, align 4, !tbaa !12
  %243 = zext i32 %242 to i64
  %244 = shl nuw nsw i64 %243, %67
  %245 = trunc i64 %244 to i32
  %246 = trunc nuw i64 %240 to i32
  %247 = add i32 %46, %246
  %248 = zext i32 %247 to i64
  %249 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %248
  %250 = load i32, ptr %249, align 4, !tbaa !12
  %251 = or i32 %250, %245
  store i32 %251, ptr %249, align 4, !tbaa !12
  %252 = lshr i64 %244, 32
  %253 = icmp eq i64 %252, 0
  br i1 %253, label %261, label %254

254:                                              ; preds = %239
  %255 = trunc nuw nsw i64 %252 to i32
  %256 = add i32 %247, 1
  %257 = zext i32 %256 to i64
  %258 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %257
  %259 = load i32, ptr %258, align 4, !tbaa !12
  %260 = or i32 %259, %255
  store i32 %260, ptr %258, align 4, !tbaa !12
  br label %261

261:                                              ; preds = %254, %239
  %262 = or disjoint i64 %107, 7
  %263 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %262
  %264 = load i32, ptr %263, align 4, !tbaa !12
  %265 = zext i32 %264 to i64
  %266 = shl nuw nsw i64 %265, %67
  %267 = trunc i64 %266 to i32
  %268 = trunc nuw i64 %262 to i32
  %269 = add i32 %46, %268
  %270 = zext i32 %269 to i64
  %271 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %270
  %272 = load i32, ptr %271, align 4, !tbaa !12
  %273 = or i32 %272, %267
  store i32 %273, ptr %271, align 4, !tbaa !12
  %274 = lshr i64 %266, 32
  %275 = icmp eq i64 %274, 0
  br i1 %275, label %283, label %276

276:                                              ; preds = %261
  %277 = trunc nuw nsw i64 %274 to i32
  %278 = add i32 %269, 1
  %279 = zext i32 %278 to i64
  %280 = getelementptr inbounds nuw [4 x i8], ptr %8, i64 %279
  %281 = load i32, ptr %280, align 4, !tbaa !12
  %282 = or i32 %281, %277
  store i32 %282, ptr %280, align 4, !tbaa !12
  br label %283

283:                                              ; preds = %276, %261
  %284 = add nuw nsw i64 %107, 8
  %285 = add i64 %108, 8
  %286 = icmp eq i64 %285, %72
  br i1 %286, label %73, label %106, !llvm.loop !133

287:                                              ; preds = %105, %34
  %288 = load i32, ptr %40, align 4, !tbaa !97
  br i1 %37, label %289, label %309

289:                                              ; preds = %287
  %290 = icmp eq i32 %288, %24
  br i1 %290, label %291, label %295

291:                                              ; preds = %289
  %292 = icmp eq i32 %24, 0
  br i1 %292, label %331, label %293

293:                                              ; preds = %291
  %294 = zext i32 %24 to i64
  br label %299

295:                                              ; preds = %289
  %296 = icmp ugt i32 %288, %24
  br i1 %296, label %334, label %329

297:                                              ; preds = %299
  %298 = icmp eq i64 %301, 0
  br i1 %298, label %331, label %299, !llvm.loop !135

299:                                              ; preds = %293, %297
  %300 = phi i64 [ %294, %293 ], [ %301, %297 ]
  %301 = add nsw i64 %300, -1
  %302 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %301
  %303 = load i32, ptr %302, align 4, !tbaa !12
  %304 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %301
  %305 = load i32, ptr %304, align 4, !tbaa !12
  %306 = icmp eq i32 %303, %305
  br i1 %306, label %297, label %307, !llvm.loop !135

307:                                              ; preds = %299
  %308 = icmp ugt i32 %303, %305
  br i1 %308, label %331, label %329

309:                                              ; preds = %287
  %310 = icmp eq i32 %11, %288
  br i1 %310, label %311, label %315

311:                                              ; preds = %309
  %312 = icmp eq i32 %11, 0
  br i1 %312, label %331, label %313

313:                                              ; preds = %311
  %314 = zext i32 %11 to i64
  br label %319

315:                                              ; preds = %309
  %316 = icmp ugt i32 %11, %288
  br i1 %316, label %331, label %329

317:                                              ; preds = %319
  %318 = icmp eq i64 %321, 0
  br i1 %318, label %331, label %319, !llvm.loop !135

319:                                              ; preds = %313, %317
  %320 = phi i64 [ %314, %313 ], [ %321, %317 ]
  %321 = add nsw i64 %320, -1
  %322 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %321
  %323 = load i32, ptr %322, align 4, !tbaa !12
  %324 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %321
  %325 = load i32, ptr %324, align 4, !tbaa !12
  %326 = icmp eq i32 %323, %325
  br i1 %326, label %317, label %327, !llvm.loop !135

327:                                              ; preds = %319
  %328 = icmp ugt i32 %323, %325
  br i1 %328, label %331, label %329

329:                                              ; preds = %295, %307, %315, %327
  %330 = add nsw i32 %36, -1
  br label %331

331:                                              ; preds = %317, %297, %311, %291, %327, %315, %307, %329
  %332 = phi i32 [ %330, %329 ], [ %36, %315 ], [ %36, %291 ], [ %36, %327 ], [ %36, %307 ], [ %36, %311 ], [ %36, %297 ], [ %36, %317 ]
  %333 = icmp sgt i32 %332, 1023
  br i1 %333, label %1150, label %334

334:                                              ; preds = %295, %331
  %335 = phi i32 [ %332, %331 ], [ %36, %295 ]
  %336 = icmp sgt i32 %335, -1023
  %337 = sub nsw i32 52, %335
  %338 = select i1 %336, i32 %337, i32 1074
  %339 = icmp slt i32 %338, 0
  %340 = select i1 %339, ptr %1, ptr %0
  %341 = tail call i32 @llvm.abs.i32(i32 %338, i1 true)
  %342 = getelementptr inbounds nuw i8, ptr %340, i64 512
  %343 = load i32, ptr %342, align 4, !tbaa !97
  %344 = icmp ne i32 %343, 0
  %345 = icmp ne i32 %338, 0
  %346 = and i1 %344, %345
  br i1 %346, label %347, label %590

347:                                              ; preds = %334
  %348 = lshr i32 %341, 5
  %349 = and i32 %341, 31
  %350 = icmp eq i32 %349, 0
  br i1 %350, label %360, label %351

351:                                              ; preds = %347
  %352 = add i32 %343, -1
  %353 = zext i32 %352 to i64
  %354 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %353
  %355 = load i32, ptr %354, align 4, !tbaa !12
  %356 = sub nuw nsw i32 32, %349
  %357 = lshr i32 %355, %356
  %358 = icmp ne i32 %357, 0
  %359 = zext i1 %358 to i32
  br label %360

360:                                              ; preds = %351, %347
  %361 = phi i32 [ 0, %347 ], [ %359, %351 ]
  %362 = icmp samesign ugt i32 %341, 4095
  br i1 %362, label %1152, label %363

363:                                              ; preds = %360
  %364 = add i32 %348, %343
  %365 = add i32 %364, %361
  %366 = icmp ugt i32 %365, 128
  br i1 %366, label %1152, label %367

367:                                              ; preds = %363
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %7, i8 0, i64 512, i1 false)
  %368 = getelementptr inbounds nuw i8, ptr %7, i64 512
  store i32 %365, ptr %368, align 4, !tbaa !97
  %369 = zext nneg i32 %349 to i64
  %370 = zext i32 %343 to i64
  %371 = and i64 %370, 7
  %372 = icmp ult i32 %343, 8
  br i1 %372, label %377, label %373

373:                                              ; preds = %367
  %374 = and i64 %370, 4294967288
  br label %409

375:                                              ; preds = %586
  %376 = icmp eq i64 %371, 0
  br i1 %376, label %407, label %377

377:                                              ; preds = %375, %367
  %378 = phi i64 [ 0, %367 ], [ %587, %375 ]
  %379 = icmp ne i64 %371, 0
  tail call void @llvm.assume(i1 %379)
  br label %380

380:                                              ; preds = %403, %377
  %381 = phi i64 [ %378, %377 ], [ %404, %403 ]
  %382 = phi i64 [ 0, %377 ], [ %405, %403 ]
  %383 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %381
  %384 = load i32, ptr %383, align 4, !tbaa !12
  %385 = zext i32 %384 to i64
  %386 = shl nuw nsw i64 %385, %369
  %387 = trunc i64 %386 to i32
  %388 = trunc nuw i64 %381 to i32
  %389 = add i32 %348, %388
  %390 = zext i32 %389 to i64
  %391 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %390
  %392 = load i32, ptr %391, align 4, !tbaa !12
  %393 = or i32 %392, %387
  store i32 %393, ptr %391, align 4, !tbaa !12
  %394 = lshr i64 %386, 32
  %395 = icmp eq i64 %394, 0
  br i1 %395, label %403, label %396

396:                                              ; preds = %380
  %397 = trunc nuw nsw i64 %394 to i32
  %398 = add i32 %389, 1
  %399 = zext i32 %398 to i64
  %400 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %399
  %401 = load i32, ptr %400, align 4, !tbaa !12
  %402 = or i32 %401, %397
  store i32 %402, ptr %400, align 4, !tbaa !12
  br label %403

403:                                              ; preds = %396, %380
  %404 = add nuw nsw i64 %381, 1
  %405 = add i64 %382, 1
  %406 = icmp eq i64 %405, %371
  br i1 %406, label %407, label %380, !llvm.loop !136

407:                                              ; preds = %403, %375
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %340, ptr noundef nonnull align 4 dereferenceable(516) %7, i64 516, i1 false), !tbaa.struct !102
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #27
  %408 = load i32, ptr %10, align 4, !tbaa !97
  br label %590

409:                                              ; preds = %586, %373
  %410 = phi i64 [ 0, %373 ], [ %587, %586 ]
  %411 = phi i64 [ 0, %373 ], [ %588, %586 ]
  %412 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %410
  %413 = load i32, ptr %412, align 4, !tbaa !12
  %414 = zext i32 %413 to i64
  %415 = shl nuw nsw i64 %414, %369
  %416 = trunc i64 %415 to i32
  %417 = trunc nuw i64 %410 to i32
  %418 = add i32 %348, %417
  %419 = zext i32 %418 to i64
  %420 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %419
  %421 = load i32, ptr %420, align 4, !tbaa !12
  %422 = or i32 %421, %416
  store i32 %422, ptr %420, align 4, !tbaa !12
  %423 = lshr i64 %415, 32
  %424 = icmp eq i64 %423, 0
  br i1 %424, label %432, label %425

425:                                              ; preds = %409
  %426 = trunc nuw nsw i64 %423 to i32
  %427 = add i32 %418, 1
  %428 = zext i32 %427 to i64
  %429 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %428
  %430 = load i32, ptr %429, align 4, !tbaa !12
  %431 = or i32 %430, %426
  store i32 %431, ptr %429, align 4, !tbaa !12
  br label %432

432:                                              ; preds = %425, %409
  %433 = or disjoint i64 %410, 1
  %434 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %433
  %435 = load i32, ptr %434, align 4, !tbaa !12
  %436 = zext i32 %435 to i64
  %437 = shl nuw nsw i64 %436, %369
  %438 = trunc i64 %437 to i32
  %439 = trunc nuw i64 %433 to i32
  %440 = add i32 %348, %439
  %441 = zext i32 %440 to i64
  %442 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %441
  %443 = load i32, ptr %442, align 4, !tbaa !12
  %444 = or i32 %443, %438
  store i32 %444, ptr %442, align 4, !tbaa !12
  %445 = lshr i64 %437, 32
  %446 = icmp eq i64 %445, 0
  br i1 %446, label %454, label %447

447:                                              ; preds = %432
  %448 = trunc nuw nsw i64 %445 to i32
  %449 = add i32 %440, 1
  %450 = zext i32 %449 to i64
  %451 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %450
  %452 = load i32, ptr %451, align 4, !tbaa !12
  %453 = or i32 %452, %448
  store i32 %453, ptr %451, align 4, !tbaa !12
  br label %454

454:                                              ; preds = %447, %432
  %455 = or disjoint i64 %410, 2
  %456 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %455
  %457 = load i32, ptr %456, align 4, !tbaa !12
  %458 = zext i32 %457 to i64
  %459 = shl nuw nsw i64 %458, %369
  %460 = trunc i64 %459 to i32
  %461 = trunc nuw i64 %455 to i32
  %462 = add i32 %348, %461
  %463 = zext i32 %462 to i64
  %464 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %463
  %465 = load i32, ptr %464, align 4, !tbaa !12
  %466 = or i32 %465, %460
  store i32 %466, ptr %464, align 4, !tbaa !12
  %467 = lshr i64 %459, 32
  %468 = icmp eq i64 %467, 0
  br i1 %468, label %476, label %469

469:                                              ; preds = %454
  %470 = trunc nuw nsw i64 %467 to i32
  %471 = add i32 %462, 1
  %472 = zext i32 %471 to i64
  %473 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %472
  %474 = load i32, ptr %473, align 4, !tbaa !12
  %475 = or i32 %474, %470
  store i32 %475, ptr %473, align 4, !tbaa !12
  br label %476

476:                                              ; preds = %469, %454
  %477 = or disjoint i64 %410, 3
  %478 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %477
  %479 = load i32, ptr %478, align 4, !tbaa !12
  %480 = zext i32 %479 to i64
  %481 = shl nuw nsw i64 %480, %369
  %482 = trunc i64 %481 to i32
  %483 = trunc nuw i64 %477 to i32
  %484 = add i32 %348, %483
  %485 = zext i32 %484 to i64
  %486 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %485
  %487 = load i32, ptr %486, align 4, !tbaa !12
  %488 = or i32 %487, %482
  store i32 %488, ptr %486, align 4, !tbaa !12
  %489 = lshr i64 %481, 32
  %490 = icmp eq i64 %489, 0
  br i1 %490, label %498, label %491

491:                                              ; preds = %476
  %492 = trunc nuw nsw i64 %489 to i32
  %493 = add i32 %484, 1
  %494 = zext i32 %493 to i64
  %495 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %494
  %496 = load i32, ptr %495, align 4, !tbaa !12
  %497 = or i32 %496, %492
  store i32 %497, ptr %495, align 4, !tbaa !12
  br label %498

498:                                              ; preds = %491, %476
  %499 = or disjoint i64 %410, 4
  %500 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %499
  %501 = load i32, ptr %500, align 4, !tbaa !12
  %502 = zext i32 %501 to i64
  %503 = shl nuw nsw i64 %502, %369
  %504 = trunc i64 %503 to i32
  %505 = trunc nuw i64 %499 to i32
  %506 = add i32 %348, %505
  %507 = zext i32 %506 to i64
  %508 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %507
  %509 = load i32, ptr %508, align 4, !tbaa !12
  %510 = or i32 %509, %504
  store i32 %510, ptr %508, align 4, !tbaa !12
  %511 = lshr i64 %503, 32
  %512 = icmp eq i64 %511, 0
  br i1 %512, label %520, label %513

513:                                              ; preds = %498
  %514 = trunc nuw nsw i64 %511 to i32
  %515 = add i32 %506, 1
  %516 = zext i32 %515 to i64
  %517 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %516
  %518 = load i32, ptr %517, align 4, !tbaa !12
  %519 = or i32 %518, %514
  store i32 %519, ptr %517, align 4, !tbaa !12
  br label %520

520:                                              ; preds = %513, %498
  %521 = or disjoint i64 %410, 5
  %522 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %521
  %523 = load i32, ptr %522, align 4, !tbaa !12
  %524 = zext i32 %523 to i64
  %525 = shl nuw nsw i64 %524, %369
  %526 = trunc i64 %525 to i32
  %527 = trunc nuw i64 %521 to i32
  %528 = add i32 %348, %527
  %529 = zext i32 %528 to i64
  %530 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %529
  %531 = load i32, ptr %530, align 4, !tbaa !12
  %532 = or i32 %531, %526
  store i32 %532, ptr %530, align 4, !tbaa !12
  %533 = lshr i64 %525, 32
  %534 = icmp eq i64 %533, 0
  br i1 %534, label %542, label %535

535:                                              ; preds = %520
  %536 = trunc nuw nsw i64 %533 to i32
  %537 = add i32 %528, 1
  %538 = zext i32 %537 to i64
  %539 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %538
  %540 = load i32, ptr %539, align 4, !tbaa !12
  %541 = or i32 %540, %536
  store i32 %541, ptr %539, align 4, !tbaa !12
  br label %542

542:                                              ; preds = %535, %520
  %543 = or disjoint i64 %410, 6
  %544 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %543
  %545 = load i32, ptr %544, align 4, !tbaa !12
  %546 = zext i32 %545 to i64
  %547 = shl nuw nsw i64 %546, %369
  %548 = trunc i64 %547 to i32
  %549 = trunc nuw i64 %543 to i32
  %550 = add i32 %348, %549
  %551 = zext i32 %550 to i64
  %552 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %551
  %553 = load i32, ptr %552, align 4, !tbaa !12
  %554 = or i32 %553, %548
  store i32 %554, ptr %552, align 4, !tbaa !12
  %555 = lshr i64 %547, 32
  %556 = icmp eq i64 %555, 0
  br i1 %556, label %564, label %557

557:                                              ; preds = %542
  %558 = trunc nuw nsw i64 %555 to i32
  %559 = add i32 %550, 1
  %560 = zext i32 %559 to i64
  %561 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %560
  %562 = load i32, ptr %561, align 4, !tbaa !12
  %563 = or i32 %562, %558
  store i32 %563, ptr %561, align 4, !tbaa !12
  br label %564

564:                                              ; preds = %557, %542
  %565 = or disjoint i64 %410, 7
  %566 = getelementptr inbounds nuw [4 x i8], ptr %340, i64 %565
  %567 = load i32, ptr %566, align 4, !tbaa !12
  %568 = zext i32 %567 to i64
  %569 = shl nuw nsw i64 %568, %369
  %570 = trunc i64 %569 to i32
  %571 = trunc nuw i64 %565 to i32
  %572 = add i32 %348, %571
  %573 = zext i32 %572 to i64
  %574 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %573
  %575 = load i32, ptr %574, align 4, !tbaa !12
  %576 = or i32 %575, %570
  store i32 %576, ptr %574, align 4, !tbaa !12
  %577 = lshr i64 %569, 32
  %578 = icmp eq i64 %577, 0
  br i1 %578, label %586, label %579

579:                                              ; preds = %564
  %580 = trunc nuw nsw i64 %577 to i32
  %581 = add i32 %572, 1
  %582 = zext i32 %581 to i64
  %583 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 %582
  %584 = load i32, ptr %583, align 4, !tbaa !12
  %585 = or i32 %584, %580
  store i32 %585, ptr %583, align 4, !tbaa !12
  br label %586

586:                                              ; preds = %579, %564
  %587 = add nuw nsw i64 %410, 8
  %588 = add i64 %411, 8
  %589 = icmp eq i64 %588, %374
  br i1 %589, label %375, label %409, !llvm.loop !133

590:                                              ; preds = %407, %334
  %591 = phi i32 [ %408, %407 ], [ %11, %334 ]
  %592 = icmp eq i32 %591, 0
  br i1 %592, label %601, label %593

593:                                              ; preds = %590
  %594 = add i32 %591, -1
  %595 = zext i32 %594 to i64
  %596 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %595
  %597 = load i32, ptr %596, align 4, !tbaa !12
  %598 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %597, i1 false)
  %599 = shl i32 %591, 5
  %600 = sub i32 %599, %598
  br label %601

601:                                              ; preds = %590, %593
  %602 = phi i32 [ %600, %593 ], [ 0, %590 ]
  %603 = load i32, ptr %23, align 4, !tbaa !97
  %604 = icmp eq i32 %603, 0
  br i1 %604, label %613, label %605

605:                                              ; preds = %601
  %606 = add i32 %603, -1
  %607 = zext i32 %606 to i64
  %608 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %607
  %609 = load i32, ptr %608, align 4, !tbaa !12
  %610 = tail call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %609, i1 false)
  %611 = shl i32 %603, 5
  %612 = sub i32 %610, %611
  br label %613

613:                                              ; preds = %601, %605
  %614 = phi i32 [ %612, %605 ], [ 0, %601 ]
  %615 = add i32 %614, %602
  %616 = icmp sgt i32 %615, 63
  br i1 %616, label %1152, label %617

617:                                              ; preds = %613
  %618 = icmp sgt i32 %615, -1
  br i1 %618, label %619, label %949

619:                                              ; preds = %617
  %620 = getelementptr inbounds nuw i8, ptr %6, i64 512
  %621 = zext nneg i32 %615 to i64
  br label %622

622:                                              ; preds = %619, %943
  %623 = phi i32 [ %591, %619 ], [ %944, %943 ]
  %624 = phi i32 [ %591, %619 ], [ %945, %943 ]
  %625 = phi i64 [ %621, %619 ], [ %947, %943 ]
  %626 = phi i64 [ 0, %619 ], [ %946, %943 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %1, i64 516, i1 false), !tbaa.struct !102
  %627 = load i32, ptr %40, align 4, !tbaa !97
  %628 = icmp ne i32 %627, 0
  %629 = icmp ne i64 %625, 0
  %630 = and i1 %629, %628
  br i1 %630, label %631, label %874

631:                                              ; preds = %622
  %632 = trunc nuw nsw i64 %625 to i32
  %633 = lshr i32 %632, 5
  %634 = and i32 %632, 31
  %635 = icmp eq i32 %634, 0
  br i1 %635, label %645, label %636

636:                                              ; preds = %631
  %637 = add i32 %627, -1
  %638 = zext i32 %637 to i64
  %639 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %638
  %640 = load i32, ptr %639, align 4, !tbaa !12
  %641 = sub nuw nsw i32 32, %634
  %642 = lshr i32 %640, %641
  %643 = icmp ne i32 %642, 0
  %644 = zext i1 %643 to i32
  br label %645

645:                                              ; preds = %636, %631
  %646 = phi i32 [ 0, %631 ], [ %644, %636 ]
  %647 = icmp samesign ugt i64 %625, 4095
  br i1 %647, label %1152, label %648

648:                                              ; preds = %645
  %649 = add i32 %627, %633
  %650 = add i32 %649, %646
  %651 = icmp ugt i32 %650, 128
  br i1 %651, label %1152, label %652

652:                                              ; preds = %648
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %6, i8 0, i64 512, i1 false)
  store i32 %650, ptr %620, align 4, !tbaa !97
  %653 = and i64 %625, 31
  %654 = zext i32 %627 to i64
  %655 = and i64 %654, 7
  %656 = icmp ult i32 %627, 8
  br i1 %656, label %661, label %657

657:                                              ; preds = %652
  %658 = and i64 %654, 4294967288
  br label %693

659:                                              ; preds = %870
  %660 = icmp eq i64 %655, 0
  br i1 %660, label %691, label %661

661:                                              ; preds = %659, %652
  %662 = phi i64 [ 0, %652 ], [ %871, %659 ]
  %663 = icmp ne i64 %655, 0
  tail call void @llvm.assume(i1 %663)
  br label %664

664:                                              ; preds = %687, %661
  %665 = phi i64 [ %662, %661 ], [ %688, %687 ]
  %666 = phi i64 [ 0, %661 ], [ %689, %687 ]
  %667 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %665
  %668 = load i32, ptr %667, align 4, !tbaa !12
  %669 = zext i32 %668 to i64
  %670 = shl nuw nsw i64 %669, %653
  %671 = trunc i64 %670 to i32
  %672 = trunc nuw i64 %665 to i32
  %673 = add i32 %633, %672
  %674 = zext i32 %673 to i64
  %675 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %674
  %676 = load i32, ptr %675, align 4, !tbaa !12
  %677 = or i32 %676, %671
  store i32 %677, ptr %675, align 4, !tbaa !12
  %678 = lshr i64 %670, 32
  %679 = icmp eq i64 %678, 0
  br i1 %679, label %687, label %680

680:                                              ; preds = %664
  %681 = trunc nuw nsw i64 %678 to i32
  %682 = add i32 %673, 1
  %683 = zext i32 %682 to i64
  %684 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %683
  %685 = load i32, ptr %684, align 4, !tbaa !12
  %686 = or i32 %685, %681
  store i32 %686, ptr %684, align 4, !tbaa !12
  br label %687

687:                                              ; preds = %680, %664
  %688 = add nuw nsw i64 %665, 1
  %689 = add i64 %666, 1
  %690 = icmp eq i64 %689, %655
  br i1 %690, label %691, label %664, !llvm.loop !137

691:                                              ; preds = %687, %659
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %9, ptr noundef nonnull align 4 dereferenceable(516) %6, i64 516, i1 false), !tbaa.struct !102
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #27
  %692 = load i32, ptr %40, align 4, !tbaa !97
  br label %874

693:                                              ; preds = %870, %657
  %694 = phi i64 [ 0, %657 ], [ %871, %870 ]
  %695 = phi i64 [ 0, %657 ], [ %872, %870 ]
  %696 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %694
  %697 = load i32, ptr %696, align 4, !tbaa !12
  %698 = zext i32 %697 to i64
  %699 = shl nuw nsw i64 %698, %653
  %700 = trunc i64 %699 to i32
  %701 = trunc nuw i64 %694 to i32
  %702 = add i32 %633, %701
  %703 = zext i32 %702 to i64
  %704 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %703
  %705 = load i32, ptr %704, align 4, !tbaa !12
  %706 = or i32 %705, %700
  store i32 %706, ptr %704, align 4, !tbaa !12
  %707 = lshr i64 %699, 32
  %708 = icmp eq i64 %707, 0
  br i1 %708, label %716, label %709

709:                                              ; preds = %693
  %710 = trunc nuw nsw i64 %707 to i32
  %711 = add i32 %702, 1
  %712 = zext i32 %711 to i64
  %713 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %712
  %714 = load i32, ptr %713, align 4, !tbaa !12
  %715 = or i32 %714, %710
  store i32 %715, ptr %713, align 4, !tbaa !12
  br label %716

716:                                              ; preds = %709, %693
  %717 = or disjoint i64 %694, 1
  %718 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %717
  %719 = load i32, ptr %718, align 4, !tbaa !12
  %720 = zext i32 %719 to i64
  %721 = shl nuw nsw i64 %720, %653
  %722 = trunc i64 %721 to i32
  %723 = trunc nuw i64 %717 to i32
  %724 = add i32 %633, %723
  %725 = zext i32 %724 to i64
  %726 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %725
  %727 = load i32, ptr %726, align 4, !tbaa !12
  %728 = or i32 %727, %722
  store i32 %728, ptr %726, align 4, !tbaa !12
  %729 = lshr i64 %721, 32
  %730 = icmp eq i64 %729, 0
  br i1 %730, label %738, label %731

731:                                              ; preds = %716
  %732 = trunc nuw nsw i64 %729 to i32
  %733 = add i32 %724, 1
  %734 = zext i32 %733 to i64
  %735 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %734
  %736 = load i32, ptr %735, align 4, !tbaa !12
  %737 = or i32 %736, %732
  store i32 %737, ptr %735, align 4, !tbaa !12
  br label %738

738:                                              ; preds = %731, %716
  %739 = or disjoint i64 %694, 2
  %740 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %739
  %741 = load i32, ptr %740, align 4, !tbaa !12
  %742 = zext i32 %741 to i64
  %743 = shl nuw nsw i64 %742, %653
  %744 = trunc i64 %743 to i32
  %745 = trunc nuw i64 %739 to i32
  %746 = add i32 %633, %745
  %747 = zext i32 %746 to i64
  %748 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %747
  %749 = load i32, ptr %748, align 4, !tbaa !12
  %750 = or i32 %749, %744
  store i32 %750, ptr %748, align 4, !tbaa !12
  %751 = lshr i64 %743, 32
  %752 = icmp eq i64 %751, 0
  br i1 %752, label %760, label %753

753:                                              ; preds = %738
  %754 = trunc nuw nsw i64 %751 to i32
  %755 = add i32 %746, 1
  %756 = zext i32 %755 to i64
  %757 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %756
  %758 = load i32, ptr %757, align 4, !tbaa !12
  %759 = or i32 %758, %754
  store i32 %759, ptr %757, align 4, !tbaa !12
  br label %760

760:                                              ; preds = %753, %738
  %761 = or disjoint i64 %694, 3
  %762 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %761
  %763 = load i32, ptr %762, align 4, !tbaa !12
  %764 = zext i32 %763 to i64
  %765 = shl nuw nsw i64 %764, %653
  %766 = trunc i64 %765 to i32
  %767 = trunc nuw i64 %761 to i32
  %768 = add i32 %633, %767
  %769 = zext i32 %768 to i64
  %770 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %769
  %771 = load i32, ptr %770, align 4, !tbaa !12
  %772 = or i32 %771, %766
  store i32 %772, ptr %770, align 4, !tbaa !12
  %773 = lshr i64 %765, 32
  %774 = icmp eq i64 %773, 0
  br i1 %774, label %782, label %775

775:                                              ; preds = %760
  %776 = trunc nuw nsw i64 %773 to i32
  %777 = add i32 %768, 1
  %778 = zext i32 %777 to i64
  %779 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %778
  %780 = load i32, ptr %779, align 4, !tbaa !12
  %781 = or i32 %780, %776
  store i32 %781, ptr %779, align 4, !tbaa !12
  br label %782

782:                                              ; preds = %775, %760
  %783 = or disjoint i64 %694, 4
  %784 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %783
  %785 = load i32, ptr %784, align 4, !tbaa !12
  %786 = zext i32 %785 to i64
  %787 = shl nuw nsw i64 %786, %653
  %788 = trunc i64 %787 to i32
  %789 = trunc nuw i64 %783 to i32
  %790 = add i32 %633, %789
  %791 = zext i32 %790 to i64
  %792 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %791
  %793 = load i32, ptr %792, align 4, !tbaa !12
  %794 = or i32 %793, %788
  store i32 %794, ptr %792, align 4, !tbaa !12
  %795 = lshr i64 %787, 32
  %796 = icmp eq i64 %795, 0
  br i1 %796, label %804, label %797

797:                                              ; preds = %782
  %798 = trunc nuw nsw i64 %795 to i32
  %799 = add i32 %790, 1
  %800 = zext i32 %799 to i64
  %801 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %800
  %802 = load i32, ptr %801, align 4, !tbaa !12
  %803 = or i32 %802, %798
  store i32 %803, ptr %801, align 4, !tbaa !12
  br label %804

804:                                              ; preds = %797, %782
  %805 = or disjoint i64 %694, 5
  %806 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %805
  %807 = load i32, ptr %806, align 4, !tbaa !12
  %808 = zext i32 %807 to i64
  %809 = shl nuw nsw i64 %808, %653
  %810 = trunc i64 %809 to i32
  %811 = trunc nuw i64 %805 to i32
  %812 = add i32 %633, %811
  %813 = zext i32 %812 to i64
  %814 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %813
  %815 = load i32, ptr %814, align 4, !tbaa !12
  %816 = or i32 %815, %810
  store i32 %816, ptr %814, align 4, !tbaa !12
  %817 = lshr i64 %809, 32
  %818 = icmp eq i64 %817, 0
  br i1 %818, label %826, label %819

819:                                              ; preds = %804
  %820 = trunc nuw nsw i64 %817 to i32
  %821 = add i32 %812, 1
  %822 = zext i32 %821 to i64
  %823 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %822
  %824 = load i32, ptr %823, align 4, !tbaa !12
  %825 = or i32 %824, %820
  store i32 %825, ptr %823, align 4, !tbaa !12
  br label %826

826:                                              ; preds = %819, %804
  %827 = or disjoint i64 %694, 6
  %828 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %827
  %829 = load i32, ptr %828, align 4, !tbaa !12
  %830 = zext i32 %829 to i64
  %831 = shl nuw nsw i64 %830, %653
  %832 = trunc i64 %831 to i32
  %833 = trunc nuw i64 %827 to i32
  %834 = add i32 %633, %833
  %835 = zext i32 %834 to i64
  %836 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %835
  %837 = load i32, ptr %836, align 4, !tbaa !12
  %838 = or i32 %837, %832
  store i32 %838, ptr %836, align 4, !tbaa !12
  %839 = lshr i64 %831, 32
  %840 = icmp eq i64 %839, 0
  br i1 %840, label %848, label %841

841:                                              ; preds = %826
  %842 = trunc nuw nsw i64 %839 to i32
  %843 = add i32 %834, 1
  %844 = zext i32 %843 to i64
  %845 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %844
  %846 = load i32, ptr %845, align 4, !tbaa !12
  %847 = or i32 %846, %842
  store i32 %847, ptr %845, align 4, !tbaa !12
  br label %848

848:                                              ; preds = %841, %826
  %849 = or disjoint i64 %694, 7
  %850 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %849
  %851 = load i32, ptr %850, align 4, !tbaa !12
  %852 = zext i32 %851 to i64
  %853 = shl nuw nsw i64 %852, %653
  %854 = trunc i64 %853 to i32
  %855 = trunc nuw i64 %849 to i32
  %856 = add i32 %633, %855
  %857 = zext i32 %856 to i64
  %858 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %857
  %859 = load i32, ptr %858, align 4, !tbaa !12
  %860 = or i32 %859, %854
  store i32 %860, ptr %858, align 4, !tbaa !12
  %861 = lshr i64 %853, 32
  %862 = icmp eq i64 %861, 0
  br i1 %862, label %870, label %863

863:                                              ; preds = %848
  %864 = trunc nuw nsw i64 %861 to i32
  %865 = add i32 %856, 1
  %866 = zext i32 %865 to i64
  %867 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 %866
  %868 = load i32, ptr %867, align 4, !tbaa !12
  %869 = or i32 %868, %864
  store i32 %869, ptr %867, align 4, !tbaa !12
  br label %870

870:                                              ; preds = %863, %848
  %871 = add nuw nsw i64 %694, 8
  %872 = add i64 %695, 8
  %873 = icmp eq i64 %872, %658
  br i1 %873, label %659, label %693, !llvm.loop !133

874:                                              ; preds = %691, %622
  %875 = phi i32 [ %692, %691 ], [ %627, %622 ]
  %876 = icmp eq i32 %624, %875
  br i1 %876, label %877, label %881

877:                                              ; preds = %874
  %878 = icmp eq i32 %624, 0
  br i1 %878, label %938, label %879

879:                                              ; preds = %877
  %880 = zext i32 %624 to i64
  br label %885

881:                                              ; preds = %874
  %882 = icmp ugt i32 %624, %875
  br i1 %882, label %895, label %943

883:                                              ; preds = %885
  %884 = icmp eq i64 %887, 0
  br i1 %884, label %895, label %885, !llvm.loop !135

885:                                              ; preds = %879, %883
  %886 = phi i64 [ %880, %879 ], [ %887, %883 ]
  %887 = add nsw i64 %886, -1
  %888 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %887
  %889 = load i32, ptr %888, align 4, !tbaa !12
  %890 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %887
  %891 = load i32, ptr %890, align 4, !tbaa !12
  %892 = icmp eq i32 %889, %891
  br i1 %892, label %883, label %893, !llvm.loop !135

893:                                              ; preds = %885
  %894 = icmp ugt i32 %889, %891
  br i1 %894, label %895, label %943

895:                                              ; preds = %893, %883, %881
  %896 = zext i32 %875 to i64
  br label %915

897:                                              ; preds = %923
  %898 = icmp eq i32 %934, 0
  br i1 %898, label %938, label %899

899:                                              ; preds = %897
  %900 = add nsw i64 %935, -1
  %901 = and i64 %900, 4294967295
  %902 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %901
  %903 = load i32, ptr %902, align 4, !tbaa !12
  %904 = icmp eq i32 %903, 0
  br i1 %904, label %911, label %938

905:                                              ; preds = %911
  %906 = add nsw i64 %912, -1
  %907 = and i64 %906, 4294967295
  %908 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %907
  %909 = load i32, ptr %908, align 4, !tbaa !12
  %910 = icmp eq i32 %909, 0
  br i1 %910, label %911, label %938, !llvm.loop !138

911:                                              ; preds = %899, %905
  %912 = phi i64 [ %906, %905 ], [ %900, %899 ]
  %913 = trunc i64 %912 to i32
  store i32 %913, ptr %10, align 4, !tbaa !97
  %914 = icmp eq i32 %913, 0
  br i1 %914, label %937, label %905, !llvm.loop !138

915:                                              ; preds = %923, %895
  %916 = phi i64 [ 0, %895 ], [ %933, %923 ]
  %917 = phi i64 [ 0, %895 ], [ %932, %923 ]
  %918 = icmp samesign ult i64 %916, %896
  br i1 %918, label %919, label %923

919:                                              ; preds = %915
  %920 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 %916
  %921 = load i32, ptr %920, align 4, !tbaa !12
  %922 = zext i32 %921 to i64
  br label %923

923:                                              ; preds = %919, %915
  %924 = phi i64 [ %922, %919 ], [ 0, %915 ]
  %925 = add nuw nsw i64 %924, %917
  %926 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %916
  %927 = load i32, ptr %926, align 4, !tbaa !12
  %928 = zext i32 %927 to i64
  %929 = trunc i64 %925 to i32
  %930 = sub i32 %927, %929
  store i32 %930, ptr %926, align 4, !tbaa !12
  %931 = icmp samesign ugt i64 %925, %928
  %932 = zext i1 %931 to i64
  %933 = add nuw nsw i64 %916, 1
  %934 = load i32, ptr %10, align 4, !tbaa !97
  %935 = zext i32 %934 to i64
  %936 = icmp samesign ult i64 %933, %935
  br i1 %936, label %915, label %897, !llvm.loop !139

937:                                              ; preds = %911
  br label %938, !llvm.loop !138

938:                                              ; preds = %905, %877, %899, %937, %897
  %939 = phi i32 [ 0, %897 ], [ %934, %899 ], [ %623, %877 ], [ 0, %937 ], [ %913, %905 ]
  %940 = phi i32 [ 0, %897 ], [ %934, %899 ], [ 0, %877 ], [ 0, %937 ], [ %913, %905 ]
  %941 = shl nuw i64 1, %625
  %942 = or i64 %941, %626
  br label %943

943:                                              ; preds = %881, %893, %938
  %944 = phi i32 [ %939, %938 ], [ %623, %893 ], [ %623, %881 ]
  %945 = phi i32 [ %940, %938 ], [ %624, %893 ], [ %624, %881 ]
  %946 = phi i64 [ %942, %938 ], [ %626, %893 ], [ %626, %881 ]
  %947 = add nsw i64 %625, -1
  %948 = icmp sgt i64 %625, 0
  br i1 %948, label %622, label %949, !llvm.loop !140

949:                                              ; preds = %943, %617
  %950 = phi i32 [ %591, %617 ], [ %944, %943 ]
  %951 = phi i64 [ 0, %617 ], [ %946, %943 ]
  %952 = icmp eq i32 %950, 0
  br i1 %952, label %1102, label %953

953:                                              ; preds = %949
  %954 = add i32 %950, -1
  %955 = zext i32 %954 to i64
  %956 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %955
  %957 = load i32, ptr %956, align 4, !tbaa !12
  %958 = lshr i32 %957, 31
  %959 = add i32 %958, %950
  %960 = icmp ugt i32 %959, 128
  br i1 %960, label %1152, label %961

961:                                              ; preds = %953
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #27
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %5, i8 0, i64 512, i1 false)
  %962 = getelementptr inbounds nuw i8, ptr %5, i64 512
  store i32 %959, ptr %962, align 4, !tbaa !97
  %963 = zext i32 %950 to i64
  %964 = and i64 %963, 7
  %965 = icmp ult i32 %950, 8
  br i1 %965, label %970, label %966

966:                                              ; preds = %961
  %967 = and i64 %963, 4294967288
  br label %993

968:                                              ; preds = %1099
  %969 = icmp eq i64 %964, 0
  br i1 %969, label %991, label %970

970:                                              ; preds = %968, %961
  %971 = phi i64 [ 0, %961 ], [ %1094, %968 ]
  %972 = icmp ne i64 %964, 0
  tail call void @llvm.assume(i1 %972)
  br label %973

973:                                              ; preds = %988, %970
  %974 = phi i64 [ %971, %970 ], [ %983, %988 ]
  %975 = phi i64 [ 0, %970 ], [ %989, %988 ]
  %976 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %974
  %977 = load i32, ptr %976, align 4, !tbaa !12
  %978 = shl i32 %977, 1
  %979 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %974
  %980 = load i32, ptr %979, align 4, !tbaa !12
  %981 = or i32 %980, %978
  store i32 %981, ptr %979, align 4, !tbaa !12
  %982 = icmp sgt i32 %977, -1
  %983 = add nuw nsw i64 %974, 1
  br i1 %982, label %988, label %984

984:                                              ; preds = %973
  %985 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %983
  %986 = load i32, ptr %985, align 4, !tbaa !12
  %987 = or i32 %986, 1
  store i32 %987, ptr %985, align 4, !tbaa !12
  br label %988

988:                                              ; preds = %984, %973
  %989 = add i64 %975, 1
  %990 = icmp eq i64 %989, %964
  br i1 %990, label %991, label %973, !llvm.loop !141

991:                                              ; preds = %988, %968
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(516) %0, ptr noundef nonnull align 4 dereferenceable(516) %5, i64 516, i1 false), !tbaa.struct !102
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #27
  %992 = load i32, ptr %10, align 4, !tbaa !97
  br label %1102

993:                                              ; preds = %1099, %966
  %994 = phi i64 [ 0, %966 ], [ %1094, %1099 ]
  %995 = phi i64 [ 0, %966 ], [ %1100, %1099 ]
  %996 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %994
  %997 = load i32, ptr %996, align 4, !tbaa !12
  %998 = shl i32 %997, 1
  %999 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %994
  %1000 = load i32, ptr %999, align 4, !tbaa !12
  %1001 = or i32 %1000, %998
  store i32 %1001, ptr %999, align 4, !tbaa !12
  %1002 = icmp sgt i32 %997, -1
  %1003 = or disjoint i64 %994, 1
  br i1 %1002, label %1008, label %1004

1004:                                             ; preds = %993
  %1005 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1003
  %1006 = load i32, ptr %1005, align 4, !tbaa !12
  %1007 = or i32 %1006, 1
  store i32 %1007, ptr %1005, align 4, !tbaa !12
  br label %1008

1008:                                             ; preds = %993, %1004
  %1009 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1003
  %1010 = load i32, ptr %1009, align 4, !tbaa !12
  %1011 = shl i32 %1010, 1
  %1012 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1003
  %1013 = load i32, ptr %1012, align 4, !tbaa !12
  %1014 = or i32 %1013, %1011
  store i32 %1014, ptr %1012, align 4, !tbaa !12
  %1015 = icmp sgt i32 %1010, -1
  %1016 = or disjoint i64 %994, 2
  br i1 %1015, label %1021, label %1017

1017:                                             ; preds = %1008
  %1018 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1016
  %1019 = load i32, ptr %1018, align 4, !tbaa !12
  %1020 = or i32 %1019, 1
  store i32 %1020, ptr %1018, align 4, !tbaa !12
  br label %1021

1021:                                             ; preds = %1017, %1008
  %1022 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1016
  %1023 = load i32, ptr %1022, align 4, !tbaa !12
  %1024 = shl i32 %1023, 1
  %1025 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1016
  %1026 = load i32, ptr %1025, align 4, !tbaa !12
  %1027 = or i32 %1026, %1024
  store i32 %1027, ptr %1025, align 4, !tbaa !12
  %1028 = icmp sgt i32 %1023, -1
  %1029 = or disjoint i64 %994, 3
  br i1 %1028, label %1034, label %1030

1030:                                             ; preds = %1021
  %1031 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1029
  %1032 = load i32, ptr %1031, align 4, !tbaa !12
  %1033 = or i32 %1032, 1
  store i32 %1033, ptr %1031, align 4, !tbaa !12
  br label %1034

1034:                                             ; preds = %1030, %1021
  %1035 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1029
  %1036 = load i32, ptr %1035, align 4, !tbaa !12
  %1037 = shl i32 %1036, 1
  %1038 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1029
  %1039 = load i32, ptr %1038, align 4, !tbaa !12
  %1040 = or i32 %1039, %1037
  store i32 %1040, ptr %1038, align 4, !tbaa !12
  %1041 = icmp sgt i32 %1036, -1
  %1042 = or disjoint i64 %994, 4
  br i1 %1041, label %1047, label %1043

1043:                                             ; preds = %1034
  %1044 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1042
  %1045 = load i32, ptr %1044, align 4, !tbaa !12
  %1046 = or i32 %1045, 1
  store i32 %1046, ptr %1044, align 4, !tbaa !12
  br label %1047

1047:                                             ; preds = %1043, %1034
  %1048 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1042
  %1049 = load i32, ptr %1048, align 4, !tbaa !12
  %1050 = shl i32 %1049, 1
  %1051 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1042
  %1052 = load i32, ptr %1051, align 4, !tbaa !12
  %1053 = or i32 %1052, %1050
  store i32 %1053, ptr %1051, align 4, !tbaa !12
  %1054 = icmp sgt i32 %1049, -1
  %1055 = or disjoint i64 %994, 5
  br i1 %1054, label %1060, label %1056

1056:                                             ; preds = %1047
  %1057 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1055
  %1058 = load i32, ptr %1057, align 4, !tbaa !12
  %1059 = or i32 %1058, 1
  store i32 %1059, ptr %1057, align 4, !tbaa !12
  br label %1060

1060:                                             ; preds = %1056, %1047
  %1061 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1055
  %1062 = load i32, ptr %1061, align 4, !tbaa !12
  %1063 = shl i32 %1062, 1
  %1064 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1055
  %1065 = load i32, ptr %1064, align 4, !tbaa !12
  %1066 = or i32 %1065, %1063
  store i32 %1066, ptr %1064, align 4, !tbaa !12
  %1067 = icmp sgt i32 %1062, -1
  %1068 = or disjoint i64 %994, 6
  br i1 %1067, label %1073, label %1069

1069:                                             ; preds = %1060
  %1070 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1068
  %1071 = load i32, ptr %1070, align 4, !tbaa !12
  %1072 = or i32 %1071, 1
  store i32 %1072, ptr %1070, align 4, !tbaa !12
  br label %1073

1073:                                             ; preds = %1069, %1060
  %1074 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1068
  %1075 = load i32, ptr %1074, align 4, !tbaa !12
  %1076 = shl i32 %1075, 1
  %1077 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1068
  %1078 = load i32, ptr %1077, align 4, !tbaa !12
  %1079 = or i32 %1078, %1076
  store i32 %1079, ptr %1077, align 4, !tbaa !12
  %1080 = icmp sgt i32 %1075, -1
  %1081 = or disjoint i64 %994, 7
  br i1 %1080, label %1086, label %1082

1082:                                             ; preds = %1073
  %1083 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1081
  %1084 = load i32, ptr %1083, align 4, !tbaa !12
  %1085 = or i32 %1084, 1
  store i32 %1085, ptr %1083, align 4, !tbaa !12
  br label %1086

1086:                                             ; preds = %1082, %1073
  %1087 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1081
  %1088 = load i32, ptr %1087, align 4, !tbaa !12
  %1089 = shl i32 %1088, 1
  %1090 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1081
  %1091 = load i32, ptr %1090, align 4, !tbaa !12
  %1092 = or i32 %1091, %1089
  store i32 %1092, ptr %1090, align 4, !tbaa !12
  %1093 = icmp sgt i32 %1088, -1
  %1094 = add nuw nsw i64 %994, 8
  br i1 %1093, label %1099, label %1095

1095:                                             ; preds = %1086
  %1096 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %1094
  %1097 = load i32, ptr %1096, align 4, !tbaa !12
  %1098 = or i32 %1097, 1
  store i32 %1098, ptr %1096, align 4, !tbaa !12
  br label %1099

1099:                                             ; preds = %1095, %1086
  %1100 = add i64 %995, 8
  %1101 = icmp eq i64 %1100, %967
  br i1 %1101, label %968, label %993, !llvm.loop !133

1102:                                             ; preds = %949, %991
  %1103 = phi i32 [ 0, %949 ], [ %992, %991 ]
  %1104 = load i32, ptr %23, align 4, !tbaa !97
  %1105 = icmp eq i32 %1103, %1104
  br i1 %1105, label %1106, label %1110

1106:                                             ; preds = %1102
  %1107 = icmp eq i32 %1103, 0
  br i1 %1107, label %1124, label %1108

1108:                                             ; preds = %1106
  %1109 = zext i32 %1103 to i64
  br label %1114

1110:                                             ; preds = %1102
  %1111 = icmp ugt i32 %1103, %1104
  br i1 %1111, label %1129, label %1131

1112:                                             ; preds = %1114
  %1113 = icmp eq i64 %1116, 0
  br i1 %1113, label %1124, label %1114, !llvm.loop !135

1114:                                             ; preds = %1108, %1112
  %1115 = phi i64 [ %1109, %1108 ], [ %1116, %1112 ]
  %1116 = add nsw i64 %1115, -1
  %1117 = getelementptr inbounds nuw [4 x i8], ptr %0, i64 %1116
  %1118 = load i32, ptr %1117, align 4, !tbaa !12
  %1119 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %1116
  %1120 = load i32, ptr %1119, align 4, !tbaa !12
  %1121 = icmp eq i32 %1118, %1120
  br i1 %1121, label %1112, label %1122, !llvm.loop !135

1122:                                             ; preds = %1114
  %1123 = icmp ugt i32 %1118, %1120
  br i1 %1123, label %1129, label %1131

1124:                                             ; preds = %1112, %1106
  %1125 = icmp eq i32 %2, 0
  %1126 = and i64 %951, 1
  %1127 = icmp eq i64 %1126, 0
  %1128 = select i1 %1125, i1 %1127, i1 false
  br i1 %1128, label %1131, label %1129

1129:                                             ; preds = %1122, %1110, %1124
  %1130 = add i64 %951, 1
  br label %1131

1131:                                             ; preds = %1110, %1122, %1124, %1129
  %1132 = phi i64 [ %1130, %1129 ], [ %951, %1124 ], [ %951, %1122 ], [ %951, %1110 ]
  br i1 %336, label %1133, label %1148

1133:                                             ; preds = %1131
  %1134 = icmp eq i64 %1132, 9007199254740992
  %1135 = zext i1 %1134 to i32
  %1136 = add nsw i32 %335, %1135
  %1137 = select i1 %1134, i64 4503599627370496, i64 %1132
  %1138 = icmp sgt i32 %1136, 1023
  br i1 %1138, label %1150, label %1139

1139:                                             ; preds = %1133
  %1140 = and i64 %1137, -4503599627370496
  %1141 = icmp eq i64 %1140, 4503599627370496
  br i1 %1141, label %1142, label %1152

1142:                                             ; preds = %1139
  %1143 = add nsw i32 %1136, 1023
  %1144 = zext nneg i32 %1143 to i64
  %1145 = shl nuw nsw i64 %1144, 52
  %1146 = add nsw i64 %1137, -4503599627370496
  %1147 = or disjoint i64 %1145, %1146
  br label %1150

1148:                                             ; preds = %1131
  %1149 = icmp ugt i64 %1132, 4503599627370496
  br i1 %1149, label %1152, label %1150

1150:                                             ; preds = %1142, %1148, %1133, %331
  %1151 = phi i64 [ 9218868437227405312, %1133 ], [ 9218868437227405312, %331 ], [ %1147, %1142 ], [ %1132, %1148 ]
  store i64 %1151, ptr %3, align 8, !tbaa !16
  br label %1152

1152:                                             ; preds = %645, %648, %1150, %360, %363, %58, %61, %953, %1148, %1139, %613
  %1153 = phi i32 [ 0, %363 ], [ 0, %953 ], [ 0, %58 ], [ 0, %613 ], [ 0, %360 ], [ 0, %1148 ], [ 0, %61 ], [ 0, %1139 ], [ 1, %1150 ], [ 0, %648 ], [ 0, %645 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #27
  ret i32 %1153
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.usub.sat.i32(i32, i32) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #22

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.abs.i64(i64, i1 immarg) #22

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.cttz.i32(i32, i1 immarg) #22

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #22

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #23

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v16i32(<16 x i32>) #21

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v8i32(<8 x i32>) #21

attributes #0 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: write) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nounwind ssp "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #6 = { nofree norecurse nosync nounwind ssp memory(argmem: readwrite) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #7 = { nofree norecurse nosync nounwind ssp memory(read, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #8 = { nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #10 = { nofree norecurse nosync nounwind ssp memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #11 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: readwrite) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #12 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(argmem: read) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #13 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #14 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #15 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #16 = { nofree norecurse nosync nounwind ssp memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #17 = { allocsize(0) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #18 = { "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #19 = { inlinehint nofree norecurse nosync nounwind ssp memory(argmem: readwrite) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #20 = { inlinehint nofree norecurse nosync nounwind ssp memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="non-leaf-no-reserve" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a" "tune-cpu"="apple-m5" }
attributes #21 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #22 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #23 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #24 = { nobuiltin nounwind allocsize(0) "no-builtins" }
attributes #25 = { nobuiltin "no-builtins" }
attributes #26 = { nobuiltin nounwind "no-builtins" }
attributes #27 = { nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.errno.tbaa = !{!3}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 26, i32 2]}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"frame-pointer", i32 4}
!3 = !{!4, !5, i64 0}
!4 = !{!"__libc_errno", !5, i64 0}
!5 = !{!"int", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = !{!9, !10, i64 0}
!9 = !{!"", !10, i64 0, !5, i64 8, !5, i64 12, !10, i64 16, !10, i64 24, !10, i64 32, !5, i64 40, !5, i64 44, !11, i64 48, !11, i64 56, !5, i64 64, !5, i64 68, !5, i64 72, !5, i64 76, !5, i64 80}
!10 = !{!"any pointer", !6, i64 0}
!11 = !{!"long long", !6, i64 0}
!12 = !{!5, !5, i64 0}
!13 = !{!9, !10, i64 16}
!14 = !{!9, !5, i64 64}
!15 = !{!10, !10, i64 0}
!16 = !{!11, !11, i64 0}
!17 = !{!9, !5, i64 80}
!18 = !{!9, !5, i64 68}
!19 = !{!9, !10, i64 24}
!20 = !{!21, !11, i64 8}
!21 = !{!"", !22, i64 0, !11, i64 8, !5, i64 16, !5, i64 20, !5, i64 24, !5, i64 28, !5, i64 32, !5, i64 36, !5, i64 40}
!22 = !{!"p1 omnipotent char", !10, i64 0}
!23 = !{!21, !5, i64 28}
!24 = !{!21, !22, i64 0}
!25 = !{!26, !22, i64 0}
!26 = !{!"", !22, i64 0, !5, i64 8}
!27 = !{!26, !5, i64 8}
!28 = !{!9, !5, i64 44}
!29 = !{!9, !10, i64 32}
!30 = !{!9, !5, i64 40}
!31 = !{!9, !11, i64 48}
!32 = !{!9, !5, i64 72}
!33 = !{!21, !5, i64 40}
!34 = !{!21, !5, i64 16}
!35 = !{!21, !5, i64 20}
!36 = distinct !{!36, !37}
!37 = !{!"llvm.loop.mustprogress"}
!38 = !{!21, !5, i64 24}
!39 = !{!6, !6, i64 0}
!40 = distinct !{!40, !37}
!41 = distinct !{!41, !42}
!42 = !{!"llvm.loop.unroll.disable"}
!43 = distinct !{!43, !42}
!44 = distinct !{!44, !42}
!45 = !{!9, !5, i64 12}
!46 = !{!9, !5, i64 8}
!47 = !{!48, !5, i64 4}
!48 = !{!"", !5, i64 0, !5, i64 4}
!49 = !{!21, !5, i64 32}
!50 = distinct !{!50, !37}
!51 = distinct !{!51, !37}
!52 = distinct !{!52, !37}
!53 = !{!21, !5, i64 36}
!54 = !{!9, !5, i64 76}
!55 = !{!9, !11, i64 56}
!56 = !{!48, !5, i64 0}
!57 = distinct !{!57, !37, !58}
!58 = !{!"llvm.loop.peeled.count", i32 1}
!59 = distinct !{!59, !37}
!60 = !{i64 0, i64 8, !16, i64 8, i64 4, !12}
!61 = distinct !{!61, !37}
!62 = distinct !{!62, !37}
!63 = !{!64, !64, i64 0}
!64 = !{!"double", !6, i64 0}
!65 = distinct !{!65, !42}
!66 = distinct !{!66, !37}
!67 = distinct !{!67, !37}
!68 = distinct !{!68, !37}
!69 = distinct !{!69, !37}
!70 = distinct !{!70, !42}
!71 = distinct !{!71, !37}
!72 = distinct !{!72, !37}
!73 = distinct !{!73, !37}
!74 = distinct !{!74, !37}
!75 = distinct !{!75, !37, !76, !77}
!76 = !{!"llvm.loop.isvectorized", i32 1}
!77 = !{!"llvm.loop.unroll.runtime.disable"}
!78 = !{!"branch_weights", i32 8, i32 56}
!79 = distinct !{!79, !37, !76, !77}
!80 = distinct !{!80, !37, !77, !76}
!81 = distinct !{!81, !37, !76, !77}
!82 = distinct !{!82, !37, !76, !77}
!83 = distinct !{!83, !37, !77, !76}
!84 = distinct !{!84, !37, !76}
!85 = distinct !{!85, !37, !76, !77}
!86 = distinct !{!86, !37, !76, !77}
!87 = distinct !{!87, !37, !77, !76}
!88 = distinct !{!88, !37, !76, !77}
!89 = distinct !{!89, !37, !76, !77}
!90 = distinct !{!90, !37, !76}
!91 = distinct !{!91, !42}
!92 = distinct !{!92, !37}
!93 = distinct !{!93, !42}
!94 = distinct !{!94, !37}
!95 = distinct !{!95, !37}
!96 = distinct !{!96, !37}
!97 = !{!98, !5, i64 512}
!98 = !{!"", !6, i64 0, !5, i64 512}
!99 = distinct !{!99, !37}
!100 = distinct !{!100, !37}
!101 = distinct !{!101, !37}
!102 = !{i64 0, i64 512, !39, i64 512, i64 4, !12}
!103 = distinct !{!103, !37}
!104 = distinct !{!104, !37}
!105 = distinct !{!105, !37}
!106 = distinct !{!106, !37}
!107 = distinct !{!107, !37}
!108 = distinct !{!108, !37}
!109 = distinct !{!109, !42}
!110 = distinct !{!110, !37}
!111 = distinct !{!111, !37}
!112 = distinct !{!112, !37}
!113 = distinct !{!113, !37}
!114 = distinct !{!114, !37}
!115 = distinct !{!115, !37}
!116 = distinct !{!116, !37}
!117 = distinct !{!117, !37}
!118 = distinct !{!118, !37}
!119 = distinct !{!119, !37}
!120 = distinct !{!120, !37}
!121 = distinct !{!121, !42}
!122 = distinct !{!122, !42}
!123 = distinct !{!123, !37}
!124 = distinct !{!124, !42}
!125 = distinct !{!125, !37}
!126 = distinct !{!126, !42}
!127 = distinct !{!127, !37}
!128 = !{!129, !11, i64 0}
!129 = !{!"", !11, i64 0, !5, i64 8}
!130 = !{!129, !5, i64 8}
!131 = distinct !{!131, !37}
!132 = distinct !{!132, !42}
!133 = distinct !{!133, !37}
!134 = distinct !{!134, !42}
!135 = distinct !{!135, !37}
!136 = distinct !{!136, !42}
!137 = distinct !{!137, !42}
!138 = distinct !{!138, !37}
!139 = distinct !{!139, !37}
!140 = distinct !{!140, !37}
!141 = distinct !{!141, !42}
