#include <stdio.h>
#include "runtime.h"
int main(int argc,char **argv) {(void)argv; return fputs(argc>1 ? nms_runtime_ir_wasm32 : nms_runtime_ir_native,stdout)<0;}
