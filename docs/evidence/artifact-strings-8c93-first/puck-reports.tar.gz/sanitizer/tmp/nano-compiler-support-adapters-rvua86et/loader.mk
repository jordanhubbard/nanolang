.PHONY: artifact-loader-controls
artifact-loader-controls:
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /Users/jkh/nanolang-qualification/artifact-strings-8c93-puck/sanitizer/source/tests/nanovm/test_loader_fork_admission.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /Users/jkh/nanolang-qualification/artifact-strings-8c93-puck/sanitizer/tmp/nano-compiler-support-adapters-rvua86et/loader-controls
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /Users/jkh/nanolang-qualification/artifact-strings-8c93-puck/sanitizer/source/tests/native_sdk_probe.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /Users/jkh/nanolang-qualification/artifact-strings-8c93-puck/sanitizer/tmp/nano-compiler-support-adapters-rvua86et/sdk-probe
