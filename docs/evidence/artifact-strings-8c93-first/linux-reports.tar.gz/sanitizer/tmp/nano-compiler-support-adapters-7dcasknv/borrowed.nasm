.import "/home/jkh/nanolang-qualification/artifact-strings-8c93-linux/sanitizer/tmp/nano-compiler-support-adapters-7dcasknv/borrowed.so" "nlc_runtime_root" string
.import_kind 0 artifact
.import "/home/jkh/nanolang-qualification/artifact-strings-8c93-linux/sanitizer/tmp/nano-compiler-support-adapters-7dcasknv/borrowed.so" "nlc_module_artifact" string string
.import_kind 1 artifact
.import "/home/jkh/nanolang-qualification/artifact-strings-8c93-linux/sanitizer/tmp/nano-compiler-support-adapters-7dcasknv/borrowed.so" "nl_fs_join_path" string string string
.import_kind 2 artifact
.string left "left"
.string right "right"
.string later "later"
.string zero "zero-1"
.string one "one-left"
.string two "two-left:right"
.entry main
.function main 0 3 0 int 1
CALL_EXTERN 0
STORE_LOCAL 0
CALL_EXTERN 0
POP
PUSH_STR left
CALL_EXTERN 1
STORE_LOCAL 1
PUSH_STR later
CALL_EXTERN 1
POP
PUSH_STR left
PUSH_STR right
CALL_EXTERN 2
STORE_LOCAL 2
PUSH_STR later
PUSH_STR later
CALL_EXTERN 2
POP
LOAD_LOCAL 0
PUSH_STR zero
EQ
ASSERT
LOAD_LOCAL 1
PUSH_STR one
EQ
ASSERT
LOAD_LOCAL 2
PUSH_STR two
EQ
ASSERT
PUSH_I64 0
RET
.end
