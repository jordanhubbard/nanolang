.import "/home/jkh/nanolang-qualification/artifact-strings-8c93-linux/sanitizer/tmp/nano-compiler-support-adapters-chutedl6/provider.so" "nlc_native_array_abi" int
.import_kind 0 artifact
.import "/home/jkh/nanolang-qualification/artifact-strings-8c93-linux/sanitizer/tmp/nano-compiler-support-adapters-chutedl6/provider.so" "nlc_runtime_root" string
.import_kind 1 artifact
.string first "root-1"
.entry main
.function main 0 1 0 int 1
CALL_EXTERN 0
PUSH_I64 47
I64_EQ
ASSERT
CALL_EXTERN 1
STORE_LOCAL 0
CALL_EXTERN 1
POP
LOAD_LOCAL 0
PUSH_STR first
EQ
ASSERT
PUSH_I64 0
RET
.end
