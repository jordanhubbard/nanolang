.PHONY: artifact-loader-controls
artifact-loader-controls:
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /home/jkh/nanolang-qualification/artifact-strings-8c93-linux/ordinary/source/tests/nanovm/test_loader_fork_admission.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /home/jkh/nanolang-qualification/artifact-strings-8c93-linux/ordinary/tmp/nano-compiler-support-adapters-0dhqgseh/loader-controls
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /home/jkh/nanolang-qualification/artifact-strings-8c93-linux/ordinary/source/tests/native_sdk_probe.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /home/jkh/nanolang-qualification/artifact-strings-8c93-linux/ordinary/tmp/nano-compiler-support-adapters-0dhqgseh/sdk-probe
