.PHONY: artifact-borrowed-controls
artifact-borrowed-controls:
	$(CC) $(CFLAGS) -D_GNU_SOURCE /home/jkh/nanolang-qualification/artifact-strings-8c93-linux/ordinary/source/tests/nanovm/test_artifact_borrowed_strings.c $(filter-out $(OBJ_DIR)/nanovm/vm_ffi.o,$(NANOVM_OBJECTS)) $(NANOISA_OBJECTS) $(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(LDFLAGS) $(EXPORT_DYNAMIC_LDFLAGS) -o /home/jkh/nanolang-qualification/artifact-strings-8c93-linux/ordinary/tmp/nano-compiler-support-adapters-9xq1w92j/borrowed-controls
