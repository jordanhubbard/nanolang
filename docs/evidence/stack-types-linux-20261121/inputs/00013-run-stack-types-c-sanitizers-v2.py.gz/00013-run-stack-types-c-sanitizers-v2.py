from pathlib import Path
import os,shlex,subprocess,json,time
root=Path.cwd();out=root/'.test_output/stack-types-c-sanitizers-v2';out.mkdir(exist_ok=False)
text=(root/'.test_output/stack-types-linux-final-v2.log').read_text().replace('\\\n',' ')
# My exact Make command is retained in the earlier build terminal if unchanged.
commands=[]
for file in ['stack-types-reference-build.log','stack-types-linux-third.log','stack-types-linux-final.log']:
 for line in (root/'.test_output'/file).read_text().replace('\\\n',' ').splitlines():
  if line.startswith('/usr/bin/cc ') and 'tests/nvm2c_stack_types_reference.c ' in line:commands.append(shlex.split(line))
assert commands
args=commands[-1];args=[a for a in args if a not in ['obj/nanovm/vm_decode.o','obj/nanoisa/isa.o']]
args[args.index('-o')+1]=str(out/'reference');args+=['src/nanovm/vm_decode.c','src/nanoisa/isa.c','-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
record=dict(build_argv=args,limits=['I instrument the actual verifier_types.c (included unchanged), vm_decode.c and isa.c providers plus my wrapper. Other linked providers retain their ordinary instrumentation and are not represented as a full-provider sanitizer qualification. I preserve the original corpus, flags, assertions and timeouts.'],steps=[])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
save();r=subprocess.run(args,cwd=root,capture_output=True,timeout=600);(out/'build.stdout').write_bytes(r.stdout);(out/'build.stderr').write_bytes(r.stderr);record['build_returncode']=r.returncode;save();assert r.returncode==0
work=root/'.test_output/stack-types-ys_fy0_g';manifest=json.loads((work/'manifest.json').read_text());expected=(work/'actual-c.reports').read_text().splitlines();reports=[];traces=[];env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin')
for i in range(0,len(expected),64):
 argv=[str(out/'reference'),'--trace',*[str(work/f'case-{j}.bin') for j in range(i,min(len(expected),i+64))]];start=time.monotonic();r=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=600);record['steps'].append(dict(first_case=i,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-start));save();reports+=r.stdout.decode().splitlines();traces+=r.stderr.decode().splitlines();(out/'reports').write_text('\n'.join(reports)+'\n');(out/'stderr').write_text('\n'.join(traces)+'\n');assert r.returncode==0,(i,r.stderr[-2000:]);assert reports==expected[:len(reports)]
record.update(reports=len(reports),status='passed');save();print(json.dumps(dict(reports=len(reports),cases=len(manifest['cases']),status='passed')))
