from pathlib import Path
import os,sys,json,subprocess,hashlib,gzip,re
root=Path.cwd();out=root/'docs/evidence/stack-types-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False);sha=lambda data:hashlib.sha256(data).hexdigest();paths={Path(__file__).resolve()}
controller=root/'.test_output/stack-types-qualified-stage1';state=json.loads((controller/'manifest.json').read_text());assert state['returncode']==0 and state['original_bootstrap_guards_unchanged'];stdout=(controller/'stdout').read_text();matches=re.findall(r'I retain shallow type-walk products at (/[^\n]+)',stdout);assert len(matches)==1;qualified=Path(matches[0]);cohort=json.loads((qualified/'manifest.json').read_text());assert len(cohort['routes'])==5 and len(cohort['cases'])==10287
for p in (root/'.test_output').glob('stack-types-*'):
 if p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file())
 elif p.is_file():paths.add(p)
for name in ['run-stack-types-qualified-stage1.py','run-stack-types-c-sanitizers.py','run-stack-types-c-sanitizers-v2.py','probe-stack-type-globals.py','probe-stack-type-globals.log','generate-stack-type-rules.py','stack-type-rules.nano']:
 p=root/'.test_output'/name
 if p.is_file():paths.add(p)
for folder in ['src','src_nano','modules','std','stdlib','include','scripts','tests','spec']:
 for name in subprocess.check_output(['git','ls-files',folder],cwd=root,text=True).splitlines():
  p=root/name
  if p.is_file():paths.add(p)
for name in ['src_nano/nvm2c/stack_types.nano','tests/nvm2c_stack_types_driver.nano','tests/nvm2c_stack_types_reference.c','tests/test_nanolang_translator_stack_types.py','Makefile.gnu','docs/NANOLANG_NANOISA_C_TRANSLATOR.md','obj/nvm2c_stack_types_reference','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nanoisa','bin/nano_aot_runtime.o','bin/nano_as_capture.so']:
 paths.add(root/name)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
for path in b.manifest['hosts']:paths.add(Path(path))
source_map={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths if p.is_relative_to(root) and str(p.relative_to(root)).startswith(('src/','src_nano/','modules/','std/','stdlib/','include/','scripts/','tests/','spec/'))}
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),qualified_work=str(qualified),qualified_provider=state,source_hashes=source_map,limits=['I qualify the complete Linux five-route corpus using the genuine guarded bdffa4ccc native Stage1. Earlier development-provider gates and rejected new-fixture forms remain separate. I compare successful-allocation type behavior, not complete height/metadata/ownership/origin/private-resource admission. The actual C observer uses existing private budget counters only to prove worklist test coverage. Original temporary files deleted by test/build helpers are not represented as retained. Darwin is explicitly deferred while the peer owns the observed c908523c3 run; no new Darwin gate is claimed.'])
entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();entries.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=entries;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for entry in entries:
 packed=(out/entry['artifact']).read_bytes();assert sha(packed)==entry['compressed_sha256'] and sha(gzip.decompress(packed))==entry['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum((out/p).stat().st_size for p in seen.values()),qualified_work=str(qualified),source_files=len(source_map),provider_sha256=state['source_compiler_sha256'])))
