from pathlib import Path
import yaml
schema=yaml.safe_load(Path('spec/nanoisa.yaml').read_text());codes={x['name']:x['code'] for x in schema['legacy_opcodes']}
groups=[]
def add(names,args,result,pushes=1):groups.append((names.split(),args,result,pushes))
for name,tag in [('PUSH_VOID',0),('PUSH_I64',1),('PUSH_U8',2),('PUSH_F64',3),('PUSH_BOOL',4),('PUSH_STR',5)]:add(name,[],tag)
add('I64_ADD I64_SUB I64_MUL I64_DIV_S I64_REM_S I64_DIV_U I64_REM_U I64_AND I64_OR I64_XOR I64_SHL I64_SHR_S I64_SHR_U',[1,1],1)
add('I64_NEG I64_INVERT',[1],1)
add('I64_ADD_CARRY I64_SUB_BORROW',[1,1,1],1,2)
add('I64_MUL_WIDE_S I64_MUL_WIDE_U',[1,1],1,2)
add('F64_FROM_BITS',[1],3);add('F64_TO_BITS',[3],1)
add('F64_ADD F64_SUB F64_MUL F64_DIV',[3,3],3);add('F64_NEG',[3],3)
add('I64_EQ I64_NE I64_LT_S I64_LE_S I64_GT_S I64_GE_S I64_LT_U I64_LE_U I64_GT_U I64_GE_U',[1,1],4)
add('F64_EQ F64_NE F64_LT F64_LE F64_GT F64_GE',[3,3],4)
add('BOOL_AND BOOL_OR',[4,4],4);add('BOOL_NOT',[4],4)
add('MEM_LOAD8 MEM_LOAD16 MEM_LOAD32 MEM_LOAD64',[1],1)
add('MEM_STORE8 MEM_STORE16 MEM_STORE32 MEM_STORE64',[1,1],255,0)
add('ARR_NEW ARR_LITERAL HM_KEYS HM_VALUES ARR_SLICE STR_SPLIT',[],7)
add('HM_NEW',[],13);add('STRUCT_NEW STRUCT_LITERAL',[],8);add('UNION_CONSTRUCT',[],10);add('TUPLE_NEW',[],12);add('CLOSURE_NEW',[],15);add('FUNCREF',[],11);add('OPAQUE_NULL',[],14)
add('STR_CONCAT STR_SUBSTR STR_TRIM STR_TO_LOWER STR_TO_UPPER STR_REPLACE STR_FROM_INT STR_FROM_FLOAT CAST_STRING',[],5)
add('STR_LEN STR_CHAR_AT CAST_INT ARR_LEN HM_LEN AGG_TAG UNION_TAG ENUM_VAL',[],1)
add('STR_EQ STR_CONTAINS STR_STARTS_WITH STR_ENDS_WITH CAST_BOOL TYPE_CHECK OPAQUE_VALID HM_HAS',[],4)
add('CAST_U8',[1],2);add('CAST_FLOAT',[],3)
def condition(values):
 if len(values)==1:return f'(== opcode {values[0]})'
 mid=len(values)//2;return f'(or {condition(values[:mid])} {condition(values[mid:])})'
lines=['pub fn rule(opcode: int) -> Rule {']
for names,args,result,pushes in groups:
 values=[codes[name] for name in names]
 lines += ['    # '+', '.join(names),f'    if {condition(values)} {{ return (typed {args} {result} {pushes}) }}']
lines+=['    return Rule { typed: false, required: [], result: 255, produces: 0 }','}','shadow rule {','    assert (== (rule 32).required [1, 1])','    assert (== (rule 32).result 1)','    assert (== (rule 240).produces 2)','    assert (not (rule 255).typed)','}']
# I test array contents directly; array equality is outside my admitted source subset.
lines[lines.index('    assert (== (rule 32).required [1, 1])')]='    assert (== (array_length (rule 32).required) 2)\n    assert (== (at (rule 32).required 0) 1)'
Path('.test_output/stack-type-rules.nano').write_text('\n'.join(lines)+'\n')
print({name:codes[name] for name in ['NOP','HALT','CALL','TAIL_CALL','RET','JMP','JMP_TRUE','JMP_FALSE','MATCH_TAG','HANDLER_PUSH','EFFECT_RESUME','FILE_RESULT_BRANCH','CAST_U8']})
