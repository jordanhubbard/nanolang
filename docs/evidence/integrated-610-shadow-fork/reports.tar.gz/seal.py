from pathlib import Path
import json, hashlib, shutil, stat, re, tarfile, gzip, io
r=Path('/home/jkh/nanolang-qualification/integrated-610-full-typecheck')
d=Path('/home/jkh/Src/nanolang-evaluator-record-name-storage/docs/evidence/integrated-610-shadow-fork');d.mkdir(parents=True,exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
a=r/'artifacts'; retained={}
roots=set()
for p in r.glob('*.log'):
 roots.update(re.findall(r'I retain generated compiler products at: (\S+)',p.read_text(errors='replace')))
for root in roots:
 for p in Path(root).rglob('*'):
  if p.is_file():
   b=p.read_bytes(); k=h(b); dest=a/k
   if not dest.exists():shutil.copyfile(p,dest)
   assert h(dest.read_bytes())==k
   retained[str(p)]={'sha256':k,'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode)}
(r/'retained-native-products.json').write_text(json.dumps(retained,indent=2)+'\n')
shutil.copyfile(__file__,r/'seal.py')
files=sorted(p for p in r.rglob('*') if p.is_file() and not any(x in p.relative_to(r).parts for x in ('artifacts','temporary')) and not p.name.endswith('-sample'))
m={str(p.relative_to(r)):{'sha256':h(p.read_bytes()),'bytes':p.stat().st_size} for p in files}
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
z=gzip.compress(b.getvalue(),mtime=0);(d/'reports.tar.gz').write_bytes(z)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z))) as t:assert {x.name:{'sha256':h(t.extractfile(x).read()),'bytes':x.size} for x in t.getmembers()}==m
cas={p.name:{'bytes':p.stat().st_size} for p in a.iterdir() if p.is_file()}
for k in cas:assert h((a/k).read_bytes())==k
(d/'checks.json').write_text(json.dumps({'reports':m,'cas':cas,'report_root':str(r),'bundle_sha256':h(z),'terminals':{p.name:json.loads(p.read_text()) for p in r.glob('*-terminal.json')},'selection_results':{p.name:json.loads(p.read_text()) for p in r.glob('*-selection-validation.json')},'attribution':json.loads((r/'attribution.json').read_text()),'retained_native_files':len(retained)},sort_keys=True,indent=2)+'\n')
print(json.dumps({'reports':len(m),'cas':len(cas),'retained_native_files':len(retained),'cas_bytes':sum(v['bytes'] for v in cas.values())}))
