import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();worker='integrated-record-names-full-typecheck'
# This bounded gate proves preparation only; it cannot produce a passing worker result.
report.mkdir(parents=True,exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text())
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','write','inventory','run')]
assert len(selected)==4
for node in selected:
 if node.name=='run':
  matches=[item for item in node.body if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets)]
  assert len(matches)==1
  matches[0].value=ast.parse("1200 if label == 'fresh-cseed-build' else 180",mode='eval').body
module=ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[]));exec(compile(module,str(base),'exec'))
(report/'effective-supervisor.py').write_text(ast.unparse(module)+'\n');shutil.copyfile(__file__,report/'driver.py');shutil.copyfile(base,report/'base-supervisor.py')
scope=json.loads((root/'.qualification-scope.json').read_text());pin=scope['pin']
files=list(scope['files']);assert len(files)>3000
assert all(sha(root/p)==h for p,h in scope['files'].items())
def source():return {p:sha(root/p) for p in files}
paths={name:shutil.which(name) for name in ('make','cc','gcc','ld','ar','nm','python3','perl','pkg-config','ps')}
paths.update(driver_python=sys.executable,driver=__file__,base_supervisor=str(base),planner=str(root/'scripts/ci_sanitizer_partitions.py'),scope=str(root/'.qualification-scope.json'))
for name in ('cc1','collect2','libasan.so','libubsan.so','libgcc_s.so.1'):
 path=subprocess.check_output(['gcc',('-print-prog-name=' if name in ('cc1','collect2') else '-print-file-name=')+name],text=True).strip()
 if Path(path).is_file():paths[name]=path
assert all(paths.values())
def tools():return {name:{'path':str(Path(path).resolve()),'sha256':sha(path)} for name,path in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['NANO_SHADOW_TIMEOUT_SECONDS']='60'
os.environ.pop('NANOLANG_COMPILER',None);os.environ.pop('UBSAN_OPTIONS',None);os.environ.pop('LSAN_OPTIONS',None)

os.environ['NANO_SHADOW_TIMING']='1'
os.environ['NANO_CFLAGS']='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
os.environ['NANO_VERBOSE_BUILD']='1'
for key in ('CFLAGS','CPPFLAGS','LDFLAGS','NANOC','NANO_VM','NANO_NVM2C','NANO_AOT_RUNTIME','LD_PRELOAD'):
 os.environ.pop(key,None)
temporary=report/'temporary';temporary.mkdir();os.environ['TMPDIR']=str(temporary)
os.environ['NANOLANG_SDK_ROOT']=str(root)
sample=root/'src_nano/typecheck_driver.nano'
fragment=report/'providers.mk'
fragment.write_text("include Makefile.gnu\n.PHONY: qualified-cseed\nqualified-cseed: CFLAGS += $(SANITIZE_FLAGS)\nqualified-cseed: LDFLAGS += $(SANITIZE_FLAGS)\nqualified-cseed: $(COMPILER)\n\t@printf '%s\\n' '$(COMPILER_OBJECTS)' > "+str(report/'providers.txt')+"\n\t@printf '%s\\n' '$(CFLAGS)' > "+str(report/'cflags.txt')+"\n\t@printf '%s\\n' '$(LDFLAGS)' > "+str(report/'ldflags.txt')+"\n")
paths['build_fragment']=str(fragment)
assert not (root/'obj').exists() and not (root/'bin/nanoc_c').exists()
run('fresh-cseed-build',[paths['make'],'-f',str(fragment),'-j2','CC=/usr/bin/gcc','qualified-cseed'])
assert (root/'bin/nanoc').resolve()==root/'bin/nanoc_c'
run('fresh-cseed-symbols',[paths['nm'],'-u',str(root/'bin/nanoc_c')])
symbols=(report/'fresh-cseed-symbols.log').read_text()
assert '__asan_' in symbols and '__ubsan_' in symbols
providers=[root/p for p in shlex.split((report/'providers.txt').read_text())]
provider_before={str(p):sha(p) for p in providers};write('providers-before.json',provider_before)
paths.update(compiler=str(root/'bin/nanoc'),compiler_cseed=str(root/'bin/nanoc_c'),assembler_capture=str(root/'bin/nano_as_capture.so'),sample=str(sample))
for p in providers:paths['provider:'+str(p)]=str(p)
original=Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-reports/original-stage2-typecheck.log')
write('attribution.json',{'scope':'integrated fresh complete C provider build, full original typecheck invocation, default imported shadows and60s deadline; no selection overlay; standalone component only','source':pin,'compiler_sha256':sha(root/'bin/nanoc_c'),'original_log_sha256':sha(original),'expected_completed_shadows':604,'shadow_bound':60,'build_outer_bound':1200,'diagnostic_outer_bound':180,'original_perl_alarm':600,'deviations':['NANO_SHADOW_TIMING=1','private output path','stricter180s owned-descendant supervisor'],'comparison_limit':'integrated compiler ownership and Nano resource fixes; no sole-cause attribution to name storage','environment':{k:os.environ.get(k) for k in ('ASAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS','NANO_SHADOW_TIMING','NANO_CFLAGS','NANO_VERBOSE_BUILD')}})
cmd=[paths['perl'],'-e','alarm 600; exec @ARGV; die "I cannot execute the requested command: $!\n"','bin/nanoc','src_nano/typecheck_driver.nano','-o',str(report/'sample')]
try:
 run('original-typecheck',cmd)
 passed_log=(report/'original-typecheck.log').read_text(errors='replace')
 ends=[json.loads(line.split('NANO_SHADOW_TIMING ',1)[1]) for line in passed_log.splitlines() if line.startswith('NANO_SHADOW_TIMING ') and '"phase":"shadow_end"' in line]
 assert len(ends)==604 and all(v['status']==0 for v in ends)
 assert len([line for line in passed_log.splitlines() if line.startswith('NANO_SHADOW_TIMING ') and '"phase":"module_init_start"' in line])==20
 write('full-selection-validation.json',{'pass':True,'completed_shadows':len(ends),'source':pin,'full_ci_preparation_pass':False})
finally:
 provider_after={str(p):sha(p) for p in providers};write('providers-after.json',provider_after)
 assert provider_before==provider_after
 log_path=report/'original-typecheck.log'
 if log_path.exists():
  log=log_path.read_text(errors='replace')
  records=[];malformed=[]
  for line in log.splitlines():
   if 'NANO_SHADOW_TIMING ' not in line:continue
   text=line.split('NANO_SHADOW_TIMING ',1)[1]
   try:records.append(json.loads(text))
   except json.JSONDecodeError:malformed.append(line)
  labels=re.findall(r'Testing (.*?)\.\.\.',log)
  starts={};completed=[]
  for record in records:
   key=(record['source'],record['item'],record['ordinal'])
   if record['phase']=='shadow_start':starts[key]=record
   elif record['phase']=='shadow_end':
    first=starts.pop(key,None)
    if first:
     elapsed=record['wall_sec']-first['wall_sec']+(record['wall_nsec']-first['wall_nsec'])/1e9
     completed.append({'source':key[0],'item':key[1],'ordinal':key[2],'seconds':elapsed,'status':record['status']})
  write('timing-attribution.json',{'records':records,'malformed_records':malformed,'loaded_module_counts':re.findall(r'Loaded (\d+) module',log),'completed_shadows':completed,'unfinished_shadows':list(starts.values()),'labels':labels,'scope':'source/item/ordinal authoritative; buffered stdout labels retained without ordinal joins; complete component result is separate validation file'})
  write('retained-diagnostic-products.json',inventory([report]))
