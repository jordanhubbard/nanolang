/*
 * NanoISA Text Assembler
 *
 * Converts text assembly (.nasm) to NVM binary modules.
 *
 * Assembly format:
 *   .string greeting "hello" ; add a named constant to the string pool
 *   .symbol type Point 0      ; name an existing type/layout index
 *   .symbol field x 0         ; name an existing field index
 *   .function main 0 2 0 int 1 ; name arity locals upvalues result-tag result-count
 *   label:
 *     PUSH_I64 42
 *     PUSH_I64 10
 *     ADD
 *     PRINT
 *     HALT
 *   .end
 */

#ifndef NANOISA_ASSEMBLER_H
#define NANOISA_ASSEMBLER_H

#include "nvm_format.h"

/* Assembler error codes */
typedef enum {
    ASM_OK = 0,
    ASM_ERR_SYNTAX,         /* Syntax error in assembly text */
    ASM_ERR_UNKNOWN_OPCODE, /* Unknown instruction mnemonic */
    ASM_ERR_BAD_OPERAND,    /* Invalid operand value or type */
    ASM_ERR_UNDEFINED_LABEL,/* Jump to undefined label */
    ASM_ERR_DUPLICATE_LABEL,/* Label defined more than once */
    ASM_ERR_NO_FUNCTION,    /* Instruction outside .function/.end */
    ASM_ERR_VERIFY,         /* Assembled module failed bytecode verification */
    ASM_ERR_MEMORY,         /* Allocation failure */
    ASM_ERR_IO,             /* File I/O error */
    ASM_ERR_UNDEFINED_SYMBOL, /* Symbolic operand has no declaration */
    ASM_ERR_DUPLICATE_SYMBOL  /* Symbol declared more than once */
} AsmError;

/* Assembler result */
typedef struct {
    AsmError error;
    uint32_t line;       /* Line number where error occurred (1-based) */
    char message[256];   /* Human-readable error message */
} AsmResult;

/* Assemble text source into an NVM module and verify it.
 * Returns a new NvmModule on success (caller frees with nvm_module_free).
 * On error, returns NULL and fills result with error info. A module that
 * assembles but fails verification is an error: nothing should be able to
 * hand the VM bytecode the verifier would reject. */
NvmModule *asm_assemble(const char *source, AsmResult *result);

/* Assemble without the verification pass.
 * For tooling that legitimately assembles a *fragment* rather than a runnable
 * program -- an opcode-encoding coverage sweep, say, where a lone `DUP` has an
 * empty stack by construction and could never verify. Use asm_assemble for
 * anything whose output will be executed. */
NvmModule *asm_assemble_unverified(const char *source, AsmResult *result);

/* Assemble from a file path.
 * Returns a new NvmModule on success, NULL on error. */
NvmModule *asm_assemble_file(const char *path, AsmResult *result);

#endif /* NANOISA_ASSEMBLER_H */
