from pathlib import Path
import subprocess,json,posixpath,gzip,hashlib
pin='736b098dd';base='docs/evidence/gas246-identified-x86-20261121';out=Path(__file__).resolve().parent
manifest=json.loads(subprocess.check_output(['git','show',pin+':'+base+'/manifest.json']))
assert manifest['producer_commit']=='0419b4d237f0dc16b5b67555aa51883f32d9b68e'
sha=lambda raw:hashlib.sha256(raw).hexdigest();checked={};semantic={}
with (out/'cat-file.stderr').open('wb') as err:
 p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
 try:
  for row in manifest['files']:
   name=posixpath.normpath(base+'/'+row['artifact']);assert name.startswith('docs/evidence/')
   expected={key:row[key] for key in ['sha256','bytes','compressed_sha256','compressed_bytes']}
   if name in checked:assert checked[name]==expected;continue
   p.stdin.write((pin+':'+name+'\n').encode());p.stdin.flush();header=p.stdout.readline().decode().split();assert len(header)==3 and header[1]=='blob',header
   size=int(header[2]);packed=p.stdout.read(size);assert len(packed)==size and p.stdout.read(1)==b'\n'
   assert len(packed)==row['compressed_bytes'] and sha(packed)==row['compressed_sha256'],row['path']
   raw=gzip.decompress(packed);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path'];checked[name]=expected
   if row['path'] in ['build.json','witness/results.json','baseline-gas.sum','fixed-gas.sum','input-scrub-fixed.c','input-scrub-before.c','as-after','as-before','bin/as']:
    semantic[row['path']]=dict(sha256=sha(raw),bytes=len(raw))
    if row['path'].endswith('.sum'):semantic[row['path']]['outcomes']=[line for line in raw.decode().splitlines() if line.startswith(('PASS:','FAIL:','XFAIL:','XPASS:','KFAIL:','KPASS:','UNSUPPORTED:','UNRESOLVED:','ERROR:'))]
    if row['path'].endswith('.json'):semantic[row['path']]['data']=json.loads(raw)
 finally:
  p.stdin.close();assert p.wait(timeout=30)==0
assert semantic['baseline-gas.sum']['outcomes']==semantic['fixed-gas.sum']['outcomes'];rows=semantic['fixed-gas.sum']['outcomes'];assert len(rows)==2095 and sum(r.startswith('PASS:') for r in rows)==2091 and sum(r.startswith('UNSUPPORTED:') for r in rows)==4
assert semantic['input-scrub-fixed.c']['sha256']=='6ffe0ed82d02c8f92198b4c2b5200a8093b7eea0a07a96bf951eecabf021b036'
assert semantic['input-scrub-before.c']['sha256']=='40e7e14b5845e3f48b3be1cde0ea0b073f3e787864bdeb9d06dea9b545acfa07'
b=semantic['build.json']['data'];assert b['completed'] and b['assembler_sha256']==semantic['bin/as']['sha256']==semantic['as-after']['sha256'] and b['fixed_source_sha256']==semantic['input-scrub-fixed.c']['sha256']
w=semantic['witness/results.json']['data'];assert len(w)==8 and all(r['original_source_identity']==r['expected'] for r in w)
record=dict(status='passed',receipt_pin=subprocess.check_output(['git','rev-parse',pin],text=True).strip(),producer=manifest['producer_commit'],files=len(manifest['files']),unique_payloads=len(checked),passes=2091,unsupported=4,identical_outcomes=2095,witnesses=8,selected_assembler_sha256=semantic['bin/as']['sha256'],original_assembler_sha256=semantic['as-before']['sha256'],repaired_source_sha256=semantic['input-scrub-fixed.c']['sha256'],limits=['I independently verify Git-retained raw/compressed archive bytes and semantic same-run identity/outcome records. I do not run these x86_64 products on this ARM64 host or claim NanoLang capture/user-guide/product admission.'])
(out/'peer-archive-independent-audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
