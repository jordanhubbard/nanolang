from pathlib import Path
import os,sys,json,subprocess,hashlib,gzip,stat
root=Path.cwd();work=root/'.test_output/linked-module-verifier-20261121';state=json.loads((work/'linux/manifest.json').read_text());san=json.loads((work/'linked-reference-sanitizers/manifest.json').read_text());ordinary_san=json.loads((work/'unlinked-reference-sanitizers/manifest.json').read_text());linked=json.loads((work/'linux/linked-products/manifest.json').read_text());ordinary=json.loads((work/'linux/unlinked-products/manifest.json').read_text());assert state['status']==san['status']==ordinary_san['status']=='passed' and state['source_and_tool_guards_unchanged'] and state['provider_guards_unchanged']
sha=lambda raw:hashlib.sha256(raw).hexdigest();expected=state['source_hashes'];assert all(sha((root/name).read_bytes())==value for name,value in expected.items());pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=root/'docs/evidence/linked-module-verifier-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False)
paths=set()
for path in work.rglob('*'):
 if path.is_file() and not any(part in ['module-cache','cache'] for part in path.relative_to(work).parts):paths.add(path)
paths.update(root/name for name in expected)
for name in [*state['tools'],'obj/fixture_identifier_lexer','docs/ROADMAP.md','docs/NANOLANG_NANOISA_C_TRANSLATOR.md']:
 p=root/name
 if p.is_file():paths.add(p)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(name) for name in b.manifest['hosts'])
record=dict(implementation=pin,issue=1142,source_hashes=expected,verification=dict(linked=linked,ordinary_regression=ordinary),qualified_provider=state['provider'],limits=['I qualify ordinary linked-root and complete present-node flat-graph checks against actual public V2 load/declaration/linked-verification APIs, preserving root-first/source-order load failure priority and exact ordinary messages/depths. Whole-graph checking additionally calls the same public C API on each present node in order; it does not discover imports or grant host authority. Root-only complete=true does not certify every target body. Private layout profiles defer during preparation and full affine/owned/private admission remains required. Four independent private deferrals retain distinct actual C outcomes. Two legacy in-memory target signatures wider than V2 representation remain counted apart. I retain the first three-route preflight terminal with one handwritten expected-message mismatch, its full source/native/VM/sanitized products and exact reports; implementations already agreed, and only the expected diagnostic was corrected. Expanded native controls and final five-route qualification add service/owned/private/loader/target-body boundaries and six fresh original producer targets. The full existing7132-case/two-mode/five-route ordinary regression retains original expectations and boundaries after the preparation/context refactor. Actual verifier/type/decoder/ISA/module/reverse-converter ASan/UBSan and emitted-product sanitizers do not instrument every linked provider. Build caches are omitted; actual generated inputs/products/command stdout/stderr, source, tools and original provider guards are retained. This is Linux-only while Puck retains its Darwin capture reservation. I change no executable selector, compiler admission, limits, original frozen root or source producer. Pure C emission and final-source paired bootstrap/full5.1 acceptance remain open.'])
files=[];seen={}
for i,path in enumerate(sorted(paths)):
 raw=path.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{path.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(path),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(path.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=files;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==e['compressed_sha256'] and len(raw)==e['bytes'] and sha(raw)==e['sha256']
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/name).read_bytes())==value for name,value in expected.items())
print(json.dumps(dict(files=len(files),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/name).stat().st_size for name in seen.values()),unique_artifacts=len(seen),source_files=len(expected))))
