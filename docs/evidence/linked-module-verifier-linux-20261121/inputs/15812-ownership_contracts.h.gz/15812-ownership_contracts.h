#ifndef NANOISA_OWNERSHIP_CONTRACTS_H
#define NANOISA_OWNERSHIP_CONTRACTS_H
#include "nvm_format.h"
#include "nvm_format_v2.h"

#define NVM_OWNERSHIP_VERSION 1u
#define NVM_OWNERSHIP_PATH_VERSION 2u
#define NVM_OWNERSHIP_EXTENSION_VERSION 3u
#define NVM_OWNERSHIP_EXTENSION_UNION_VARIANTS 1u
#define NVM_OWNERSHIP_EXTENSION_ARRAY_FIELDS 2u
#define NVM_OWNERSHIP_EXTENSION_REVISION_1 1u
#define NVM_OWNERSHIP_EXTENSION_GLOBALS 3u
#define NVM_OWNERSHIP_EXTENSION_EFFECTS 4u
#define NVM_OWNERSHIP_EXTENSION_MAP_FIELDS 5u
#define NVM_OWNERSHIP_EFFECT_ARRAY_REVISION 2u
#define NVM_OWNERSHIP_EFFECT_CONSTRUCTOR_REVISION 3u
#define NVM_OWNERSHIP_MAX_ARRAY_CONSTRUCTORS 32768u
#define NVM_OWNERSHIP_MAX_EFFECT_TYPES 256u
#define NVM_OWNERSHIP_MAX_EFFECTS 256u
#define NVM_OWNERSHIP_MAX_EFFECT_PARAMETERS 256u
#define NVM_OWNERSHIP_MAX_GLOBALS 256u
#define NVM_OWNERSHIP_MAX_EXTENSIONS 4u
#define NVM_OWNED_MAX_FUNCTIONS 8u
#define NVM_OWNERSHIP_MAX_PATHS 256u
#define NVM_OWNERSHIP_MAX_PATH_DEPTH 32u
#define NVM_LAYOUT_COMPLETE 1u
#define NVM_LAYOUT_RESOURCE 2u
#define NVM_OWNERSHIP_MAX_UNIONS 256u
#define NVM_OWNERSHIP_MAX_VARIANTS 256u

typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    bool mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;
/* I encode ARRAY layout as an element-table index. Other descriptors retain
 * their scalar NO_INDEX or exact nominal layout. ARRAY rows point backward. */
typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[NVM_OWNERSHIP_MAX_EFFECT_TYPES];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[NVM_OWNERSHIP_MAX_EFFECT_PARAMETERS];
} NvmOwnershipEffect;

/* I validate the whole payload before publishing one exact operation signature.
 * Keys match the runtime's string identity. Missing keys and malformed metadata
 * leave *out unchanged. These value-transfer declarations grant no handler,
 * suspension, resumption or executable ownership authority by themselves. */
NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);
/* I return the complete checked element table; revision 1 has zero entries.
 * Failure leaves output unchanged. These facts grant no execution authority. */
NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);
/* I return an exact element-table index for a revision-3 empty constructor.
 * A checked function-relative site without a binding yields NO_INDEX.
 * I validate every declaration before publishing; failure preserves *out. */
NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);

/* I validate the entire contract before publishing global declarations. Slots
 * are dense and indexed by their row number. NULL/zero requests only the count;
 * otherwise capacity must fit every row. All outputs remain unchanged on error.
 * Missing metadata or a missing GLOBALS extension describes zero global slots.
 * Declarations grant neither initialization nor executable storage authority. */
NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);

/* I validate declarations, not instruction lifetimes. Resource/reference
 * declarations set requires_verifier; executable consumers must refuse them
 * unless the shared executable ownership verifier admits their exact subset. */
NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            bool *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;
/* I query only after validating the complete declaration payload. With no
 * payload I return UNKNOWN (the caller separately resolves a retained index).
 * With a payload I also check its index. Failure leaves *out unchanged. This
 * declaration classification supplies no instruction-flow or storage admission. */
NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);
/* I validate once, then publish exactly count declaration classifications.
 * A present payload must have that exact count; absent metadata yields UNKNOWN.
 * The caller supplies count entries (or NULL for zero). Every failure leaves
 * the entire output unchanged; layout resolution remains a separate duty. */
NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);

/* I read immutable numeric paths without allocating. Layout/authority checks
 * remain the verifier's responsibility; this reader checks transport shape.
 * I leave outputs unchanged on failure. */
NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);
/* I return one exact concrete-union variant slice from the version-3
 * UNION_VARIANTS extension. Zero-flag unions retain scalar-only payloads.
 * COMPLETE unions may carry exact earlier complete record/union layouts;
 * RESOURCE propagates through every owned child. These declarations require
 * executable verification; selected-payload transfers remain a separate gate.
 * Union ordinals follow retained UNION layout order. Failure leaves *out
 * unchanged. This declaration query alone grants no executable authority. */
NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
#endif
