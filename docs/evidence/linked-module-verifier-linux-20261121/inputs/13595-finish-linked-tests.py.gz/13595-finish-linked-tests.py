from pathlib import Path
p=Path('tests/test_nanolang_translator_linked_module_verifier.py');s=p.read_text().replace('from tests.nanolang_translator_routes import build_routes','from tests.nanolang_translator_routes import build_routes, checked, source_compiler_command').replace('from tests.test_nanolang_translator_stack_heights import ins','from tests.test_nanolang_translator_stack_heights import ins, OPS').replace('from tests.test_nanolang_translator_service_modules import corpus as service_corpus','from tests.test_nanolang_translator_service_modules import corpus as service_corpus\nfrom tests.test_nanolang_translator_module import corpus as core_corpus')
s=s.replace('0:function[0] stack underflow at offset 0: need 1, have 0','0:function[0] stack underflow at offset 0 (POP needs 1, has 0)')
s=s.replace("for op in ('OWN_MOVE_LOCAL','OWN_STORE_LOCAL','OWN_PACK','OWN_UNPACK_LOCAL','REGION_BEGIN','REGION_END','BORROW_LOCAL_SHARED'):","for op,item in OPS.items():\n        if not (11 <= item['code'] <= 14 or 22 <= item['code'] <= 31): continue")
s=s.replace("if name.startswith('valid-'):","if name.endswith('-valid'):")
s=s.replace("    for raw in (b'',", "    for name,data,_ in core_corpus()[1]:\n        add('private-root-'+name,data,[(True,target)],private=True)\n        add('private-target-'+name,empty,[(True,data)],private=True)\n    for raw in (b'',")
s=s.replace('with self.subTest(route=route,case=case[0],mode=mode): self.assertEqual(value,want)', '''with self.subTest(route=route,case=case[0],mode=mode):
                            if case[4]: self.assertEqual(value.split('|')[-1],'A')
                            else: self.assertEqual(value,want)''')
s=s.replace("            (directory/'manifest.json').write_text",'''            producers=[([ROOT/'bin/nano_virt'],[])]
            source=source_compiler_command()
            if source: producers.append((source,['--emit-nvm']))
            products=[]
            for i,(producer,flags) in enumerate(producers):
                for original in ['examples/language/nl_functions_basic.nano','examples/language/nl_control_if_while.nano','examples/cross_backend/hello_cross_backend.nano']:
                    path=directory/f'original-{i}-{Path(original).stem}.nvm'
                    checked([*producer,ROOT/original,*flags,'-o',path],build=True)
                    raw=path.read_bytes();entry=struct.unpack_from('<I',raw,28)[0]
                    self.assertNotEqual(entry,NONE)
                    root=assembled([ins('CALL_MODULE',0,entry,0,1)+ins('RET')],returns=[[1]])
                    linked=directory/f'original-{i}-{Path(original).stem}.bin'
                    linked.write_bytes(carrier(root,[(True,raw)]));products.append(linked)
            for graph,mode in [(False,'linked'),(True,'graph')]:
                expected=reports([oracle],products,graph)
                self.assertTrue(all(value.startswith('-1|1:' if graph else '1:') for value in expected))
                (directory/f'original-{mode}-reference.txt').write_text('\\n'.join(expected)+'\\n')
                for route,command in routes:
                    actual=reports(command,products,graph)
                    (directory/f'original-{mode}-{route}.txt').write_text('\\n'.join(actual)+'\\n')
                    self.assertEqual(actual,expected,(mode,route))
            (directory/'manifest.json').write_text''')
s=s.replace('routes=[r for r,_ in routes],reports=counts,inputs=',"routes=[r for r,_ in routes],reports=counts,original_products=len(products),excluded_nonexpressible_legacy_contexts=2,explicit_private_deferrals=sum(c[4] for c in cases),independent_expectations={mode:sum(c[col] is not None for c in cases) for mode,col in [('linked',2),('graph',3)]},inputs=")
p.write_text(s)
s=p.read_text().replace("                for route,command in routes:\n                    actual=reports(command,paths,graph)","                baseline=None\n                for route,command in routes:\n                    actual=reports(command,paths,graph)")
s=s.replace("                counts[mode]=", "                    if baseline is None: baseline=actual\n                    else: self.assertEqual(actual,baseline,route)\n                counts[mode]=")
s=s.replace("    add('root-bad-target-bad'", "    add('root-good-empty-result-target',empty,[(True,assembled(returns=[[1]]))],want='1:1:0',graph='1|0:I require a body for function[0] with 1 declared result(s).')\n    add('root-bad-target-bad'")
s=s.replace("        if name.endswith('-valid'):\n            add", "        if name.endswith('-valid'):\n            add('root-service-'+name,data,[(False,b'')],want='0:I refuse service contracts before mixed execution selection',graph='0|0:I refuse service contracts before mixed execution selection')\n            add")
p.write_text(s)
