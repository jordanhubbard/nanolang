	.text










	.data
	.globl	snapshot_payload
snapshot_payload:
	.byte	42

