nano_module_dependencies: \
  /home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-de8svnju/foreign/payload.S
