# 1 "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-7vy54c4z/foreign/payload.S"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 398 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-7vy54c4z/foreign/payload.S" 2
.include "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-7vy54c4z/foreign/macro.s"
.data
.globl snapshot_payload
snapshot_payload:
emit "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-7vy54c4z/foreign/payload.bin"
