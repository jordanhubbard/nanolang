nano_module_dependencies: /home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-m4mxx52e/foreign/payload.s
