.include "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano=native-timing-juqk23_m/foreign/macro.s"
.data
.globl snapshot_payload
snapshot_payload:
emit "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano=native-timing-juqk23_m/foreign/payload.bin"
