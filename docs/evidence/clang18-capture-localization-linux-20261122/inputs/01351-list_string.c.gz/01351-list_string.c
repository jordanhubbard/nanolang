#define _POSIX_C_SOURCE 200809L
#include "list_string.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "list_capacity.h"

#define INITIAL_CAPACITY 8
#define GROWTH_FACTOR 2

/* Helper: Ensure the list has enough capacity */
static void ensure_capacity(List_string *list, int min_capacity) {
    int new_capacity = nl_list_grown_capacity(list->capacity, min_capacity, sizeof(*list->data));
    if (new_capacity == list->capacity) return;
    
    char **new_data = realloc(list->data, sizeof(char*) * new_capacity);
    if (!new_data) {
        fprintf(stderr, "Error: Failed to allocate memory for list\n");
        exit(1);
    }
    
    list->data = new_data;
    list->capacity = new_capacity;
}

/* Create a new empty list */
List_string* list_string_new(void) {
    return list_string_with_capacity(INITIAL_CAPACITY);
}

/* Create a new list with specified initial capacity */
List_string* list_string_with_capacity(int capacity) {
    nl_list_validate_capacity(capacity, sizeof(*((List_string *)0)->data));
    List_string *list = malloc(sizeof(List_string));
    if (!list) {
        fprintf(stderr, "Error: Failed to allocate memory for list\n");
        exit(1);
    }
    
    list->data = capacity ? malloc(sizeof(*list->data) * (size_t)capacity) : NULL;
    if (capacity && !list->data) {
        fprintf(stderr, "Error: Failed to allocate memory for list data\n");
        exit(1);
    }
    
    list->length = 0;
    list->capacity = capacity;
    
    return list;
}

/* I copy before publishing a value, retaining the existing fail-fast API. */
static char *copy_string(const char *value) {
    char *copy = value ? strdup(value) : NULL;
    if (!copy) {
        fprintf(stderr, "I could not copy the list string.\n");
        exit(1);
    }
    return copy;
}

/* Append an element to the end of the list */
void list_string_push(List_string *list, const char *value) {
    ensure_capacity(list, nl_list_next_length(list->length));
    list->data[list->length] = copy_string(value);
    list->length++;
}

/* Remove and return the last element */
char* list_string_pop(List_string *list) {
    if (list->length == 0) {
        fprintf(stderr, "Error: Cannot pop from empty list\n");
        exit(1);
    }
    
    list->length--;
    return list->data[list->length];
}

/* Insert an element at the specified index */
void list_string_insert(List_string *list, int index, const char *value) {
    if (index < 0 || index > list->length) {
        fprintf(stderr, "Error: Index %d out of bounds for list of length %d\n", 
                index, list->length);
        exit(1);
    }
    
    ensure_capacity(list, nl_list_next_length(list->length));
    char *copy = copy_string(value);
    
    /* Shift elements to the right */
    memmove(&list->data[index + 1], &list->data[index], 
            sizeof(char*) * (list->length - index));
    
    list->data[index] = copy;
    list->length++;
}

/* Remove and return the element at the specified index */
char* list_string_remove(List_string *list, int index) {
    if (index < 0 || index >= list->length) {
        fprintf(stderr, "Error: Index %d out of bounds for list of length %d\n", 
                index, list->length);
        exit(1);
    }
    
    char *value = list->data[index];
    
    /* Shift elements to the left */
    memmove(&list->data[index], &list->data[index + 1], 
            sizeof(char*) * (list->length - index - 1));
    
    list->length--;
    return value;
}

/* Set the value at the specified index */
void list_string_set(List_string *list, int index, const char *value) {
    if (index < 0 || index >= list->length) {
        fprintf(stderr, "Error: Index %d out of bounds for list of length %d\n", 
                index, list->length);
        exit(1);
    }
    
    char *copy = copy_string(value); /* The input may alias the old string. */
    free(list->data[index]);
    list->data[index] = copy;
}

/* Get the value at the specified index */
char* list_string_get(List_string *list, int index) {
    if (index < 0 || index >= list->length) {
        fprintf(stderr, "Error: Index %d out of bounds for list of length %d\n", 
                index, list->length);
        exit(1);
    }
    
    return list->data[index];
}

/* Clear all elements from the list */
void list_string_clear(List_string *list) {
    for (int i = 0; i < list->length; i++) {
        free(list->data[i]);
    }
    list->length = 0;
}

/* Get the current length of the list */
int list_string_length(List_string *list) {
    return list->length;
}

/* Get the current capacity of the list */
int list_string_capacity(List_string *list) {
    return list->capacity;
}

/* Check if the list is empty */
bool list_string_is_empty(List_string *list) {
    return list->length == 0;
}

/* Free the list and all its resources */
void list_string_free(List_string *list) {
    if (list) {
        for (int i = 0; i < list->length; i++) {
            free(list->data[i]);
        }
        free(list->data);
        free(list);
    }
}
