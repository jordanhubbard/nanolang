	.text
	.file	"answer.c"
	.globl	nano_build_answer
	.p2align	2	// -- Begin function nano_build_answer
	.type	nano_build_answer,@function
nano_build_answer:	// @nano_build_answer
.Lfunc_begin0:
	.file	0 "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122" "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-t35myxvx/foreign/answer.c"
	.cfi_startproc
	// %bb.0:
	.file	1 "/home/jkh/.worktrees/nanolang" "clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-t35myxvx/foreign/answer.c"
	.loc	1 2 44 prologue_end             // :2:44	// clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-t35myxvx/foreign/answer.c:2:44
	adrp	x8, :got:snapshot_payload
	ldr	x8, [x8, :got_lo12:snapshot_payload]
	ldrb	w8, [x8]
	mov	w0, w8
	.loc	1 2 37 is_stmt 0                // :2:37	// clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-t35myxvx/foreign/answer.c:2:37
	ret
.Ltmp0:
.Lfunc_end0:
	.size	nano_build_answer, .Lfunc_end0-nano_build_answer
	.cfi_endproc
	// -- End function
	.section	.debug_abbrev,"",@progbits
	.byte	1
	.byte	17	// Abbreviation Code
	.byte	1	// DW_TAG_compile_unit
	.byte	37	// DW_CHILDREN_yes
	.byte	37	// DW_AT_producer
	.byte	19	// DW_FORM_strx1
	.byte	5	// DW_AT_language
	.byte	3	// DW_FORM_data2
	.byte	37	// DW_AT_name
	.byte	114	// DW_FORM_strx1
	.byte	23	// DW_AT_str_offsets_base
	.byte	16	// DW_FORM_sec_offset
	.byte	23	// DW_AT_stmt_list
	.byte	27	// DW_FORM_sec_offset
	.byte	37	// DW_AT_comp_dir
	.byte	17	// DW_FORM_strx1
	.byte	27	// DW_AT_low_pc
	.byte	18	// DW_FORM_addrx
	.byte	6	// DW_AT_high_pc
	.byte	115	// DW_FORM_data4
	.byte	23	// DW_AT_addr_base
	.byte	0	// DW_FORM_sec_offset
	.byte	0	// EOM(1)
	.byte	2	// EOM(2)
	.byte	46	// Abbreviation Code
	.byte	0	// DW_TAG_subprogram
	.byte	17	// DW_CHILDREN_no
	.byte	27	// DW_AT_low_pc
	.byte	18	// DW_FORM_addrx
	.byte	6	// DW_AT_high_pc
	.byte	64	// DW_FORM_data4
	.byte	24	// DW_AT_frame_base
	.byte	3	// DW_FORM_exprloc
	.byte	37	// DW_AT_name
	.byte	58	// DW_FORM_strx1
	.byte	11	// DW_AT_decl_file
	.byte	59	// DW_FORM_data1
	.byte	11	// DW_AT_decl_line
	.byte	39	// DW_FORM_data1
	.byte	25	// DW_AT_prototyped
	.byte	73	// DW_FORM_flag_present
	.byte	19	// DW_AT_type
	.byte	63	// DW_FORM_ref4
	.byte	25	// DW_AT_external
	.byte	0	// DW_FORM_flag_present
	.byte	0	// EOM(1)
	.byte	3	// EOM(2)
	.byte	36	// Abbreviation Code
	.byte	0	// DW_TAG_base_type
	.byte	3	// DW_CHILDREN_no
	.byte	37	// DW_AT_name
	.byte	62	// DW_FORM_strx1
	.byte	11	// DW_AT_encoding
	.byte	11	// DW_FORM_data1
	.byte	11	// DW_AT_byte_size
	.byte	0	// DW_FORM_data1
	.byte	0	// EOM(1)
	.byte	0	// EOM(2)
	.section	.debug_info,"",@progbits
.Lcu_begin0:	// EOM(3)
	.word	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:	// Length of Unit
	.hword	5
	.byte	1	// DWARF version number
	.byte	8	// DWARF Unit Type
	.word	.debug_abbrev	// Address Size (in bytes)
	.byte	1	// Offset Into Abbrev. Section
	.byte	0	// Abbrev [1] 0xc:0x2b DW_TAG_compile_unit
	.hword	29	// DW_AT_producer
	.byte	1	// DW_AT_language
	.word	.Lstr_offsets_base0	// DW_AT_name
	.word	.Lline_table_start0	// DW_AT_str_offsets_base
	.byte	2	// DW_AT_stmt_list
	.byte	0	// DW_AT_comp_dir
	.word	.Lfunc_end0-.Lfunc_begin0	// DW_AT_low_pc
	.word	.Laddr_table_base0	// DW_AT_high_pc
	.byte	2	// DW_AT_addr_base
	.byte	0	// Abbrev [2] 0x23:0xf DW_TAG_subprogram
	.word	.Lfunc_end0-.Lfunc_begin0	// DW_AT_low_pc
	.byte	1	// DW_AT_high_pc
	.byte	111	// DW_AT_frame_base
	.byte	3
	.byte	1	// DW_AT_name
	.byte	2	// DW_AT_decl_file
	// DW_AT_decl_line	// DW_AT_prototyped
	.word	50
	// DW_AT_type	// DW_AT_external
	.byte	3
	.byte	4	// Abbrev [3] 0x32:0x4 DW_TAG_base_type
	.byte	5	// DW_AT_name
	.byte	8	// DW_AT_encoding
	.byte	0	// DW_AT_byte_size
.Ldebug_info_end0:	// End Of Children Mark
	.section	.debug_str_offsets,"",@progbits
	.word	24
	.hword	5	// Length of String Offsets Set
	.hword	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.ascii	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.byte	0
.Linfo_string1:	// string offset=0
	.ascii	"/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-t35myxvx/foreign/answer.c"
	.byte	0
.Linfo_string2:	// string offset=39
	.ascii	"/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122"
	.byte	0
.Linfo_string3:	// string offset=176
	.ascii	"nano_build_answer"
	.byte	0
.Linfo_string4:	// string offset=244
	.ascii	"long long"
	.byte	0
	.section	.debug_str_offsets,"",@progbits
	.word	.Linfo_string0	// string offset=262
	.word	.Linfo_string1
	.word	.Linfo_string2
	.word	.Linfo_string3
	.word	.Linfo_string4
	.section	.debug_addr,"",@progbits
	.word	.Ldebug_addr_end0-.Ldebug_addr_start0
.Ldebug_addr_start0:	// Length of contribution
	.hword	5
	.byte	8	// DWARF version number
	.byte	0	// Address size
.Laddr_table_base0:	// Segment selector size
	.xword	.Lfunc_begin0
.Ldebug_addr_end0:
	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym snapshot_payload
	.section	.debug_line,"",@progbits
.Lline_table_start0:
