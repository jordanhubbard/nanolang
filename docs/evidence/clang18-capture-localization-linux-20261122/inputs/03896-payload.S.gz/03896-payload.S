.include "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano=native-timing-4x60syc8/foreign/macro.s"
.data
.globl snapshot_payload
snapshot_payload:
emit "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano=native-timing-4x60syc8/foreign/payload.bin"
