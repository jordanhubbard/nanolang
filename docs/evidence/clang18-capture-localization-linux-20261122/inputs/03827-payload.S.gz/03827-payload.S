.data
.globl snapshot_payload
snapshot_payload:
.include "selected.s"
.text
