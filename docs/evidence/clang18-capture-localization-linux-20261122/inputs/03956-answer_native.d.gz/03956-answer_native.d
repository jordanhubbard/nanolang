nano_module_dependencies: \
  /home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano=native-timing-juqk23_m/foreign/answer.c
