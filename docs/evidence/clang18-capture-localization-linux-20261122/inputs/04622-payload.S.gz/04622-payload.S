.include "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-j325pztp/foreign/macro.s"
.data
.globl snapshot_payload
snapshot_payload:
emit "/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-j325pztp/foreign/payload.bin"
