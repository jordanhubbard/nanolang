nano_module_dependencies: /home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano=native-timing-6d6887lj/foreign/payload.s
