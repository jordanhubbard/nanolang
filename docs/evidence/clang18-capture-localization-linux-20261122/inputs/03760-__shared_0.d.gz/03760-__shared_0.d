nano_module_dependencies: \
  /home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/private-observation/fixtures/nano-as-search-ebqx_66p/foreign/payload.S
