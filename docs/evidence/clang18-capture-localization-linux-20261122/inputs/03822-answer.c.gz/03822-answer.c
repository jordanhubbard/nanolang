#include "selection.h"
extern const unsigned char snapshot_payload[];
long long nano_build_answer(void) { return ADJUST + (snapshot_payload[0]-48)*10 + snapshot_payload[1]-48; }
