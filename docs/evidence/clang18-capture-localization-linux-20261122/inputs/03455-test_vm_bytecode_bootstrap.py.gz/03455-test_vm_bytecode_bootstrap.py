#!/usr/bin/env python3
"""I compare two full compiler generations executed by NanoVM on one source pin."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from tests.bootstrap_native_guard import retained_input_names

ROOT = Path(os.environ.get('NANOLANG_BOOTSTRAP_ROOT', Path(__file__).resolve().parents[1])).resolve()


class VMBytecodeBootstrap(unittest.TestCase):
    def test_full_compiler_fixed_point(self):
        budget = int(os.environ.get('NANOLANG_BOOTSTRAP_STAGE_TIMEOUT', '1800'))
        self.assertGreater(budget, 0)
        selected = os.environ.get('NANOLANG_BOOTSTRAP_EVIDENCE')
        evidence = Path(selected).resolve() if selected else Path(tempfile.mkdtemp(prefix='nanolang-vm-bootstrap-'))
        if selected:
            evidence.mkdir(parents=True, exist_ok=True)
            self.assertEqual(list(evidence.iterdir()), [], 'I require a fresh evidence directory.')
        print(f'I retain my bootstrap evidence at {evidence}', flush=True)
        env = os.environ.copy()
        capture_helper = ROOT / 'bin/nano_as_capture.so' if sys.platform.startswith('linux') else None
        if capture_helper:
            env['NANO_AS_CAPTURE_HELPER'] = str(capture_helper)
        native_marker = evidence / 'unexpected-native-compiler'
        guarded_cc = evidence / 'guard-native-compiler'
        probe_log = evidence / 'host-cache-probes.log'
        compiler_command = shlex.split(env.get('NANO_CC') or env.get('CC') or 'cc')
        self.assertTrue(compiler_command)
        retained_inputs = evidence / 'retained-host-inputs.json'
        host_metadata = {}
        native_sources = []
        module_build_roots = []
        for name in ('compiler_support', 'nanoisa', 'std'):
            module_root = ROOT / 'modules' / name
            metadata = json.loads((module_root / 'module.json').read_text())
            host_metadata[name] = metadata
            native_sources.extend(str((module_root / source).resolve())
                                  for key in ('c_sources', 'shared_c_sources')
                                  for source in metadata.get(key, []))
            module_build_roots.append(str(module_root / '.build'))
        guard_config = {'compiler': compiler_command, 'native_sources': native_sources,
                        'retained_host_inputs': str(retained_inputs),
                        'module_build_roots': module_build_roots,
                        'native_marker': str(native_marker), 'probe_log': str(probe_log)}
        guarded_cc.write_text('#!' + sys.executable + '\nconfig = ' + repr(guard_config) + '\n' +
                              (ROOT / 'tests/bootstrap_native_guard.py').read_text() + '\nmain(config)\n')
        guarded_cc.chmod(0o755)
        env['CC'] = str(guarded_cc)
        env['NANO_CC'] = str(guarded_cc)
        env.pop('NANOLANG_BOOTSTRAP_NO_CC', None)
        manifest = {'root': str(ROOT), 'stages': {}, 'stage_timeout_seconds': budget,
                    'boundary': 'I execute VM-generation shadows as bytecode and reject NanoLang-generated C compilation. Declared native host artifacts retain their existing build and cache-validation paths; the product still contains its separate legacy C backend.'}

        def save():
            (evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

        def git(*args):
            return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

        def digest(path):
            return hashlib.sha256(Path(path).read_bytes()).hexdigest()

        def run(label, argv):
            started = time.monotonic()
            with (evidence / f'{label}.log').open('wb') as log:
                process = subprocess.Popen([str(a) for a in argv], cwd=ROOT, env=env,
                                           stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    code = process.wait(timeout=budget)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                    manifest['stages'][label] = {'argv': [str(a) for a in argv], 'timeout': True,
                                                 'elapsed_seconds': time.monotonic() - started}
                    save()
                    self.fail(f'I exceeded the diagnostic stage budget: {label}; see {evidence}.')
            manifest['stages'][label] = {'argv': [str(a) for a in argv], 'exit_code': code,
                                         'elapsed_seconds': time.monotonic() - started}
            save()
            self.assertEqual(code, 0, f'{label}: see {evidence / (label + ".log")}')

        def imports(path, label):
            dump = subprocess.check_output([ROOT / 'bin/nanoisa', 'dump', path], cwd=ROOT, text=True)
            (evidence / f'{label}.nasm').write_text(dump)
            libraries = sorted({shlex.split(line)[1] for line in dump.splitlines()
                                if line.startswith('.import ') and shlex.split(line)[1]})
            self.assertTrue(all(Path(p).is_absolute() for p in libraries))
            return {p: digest(p) for p in libraries}

        self.assertEqual(git('status', '--porcelain'), '', 'I require a clean pinned compiler source.')
        manifest['source_commit'] = git('rev-parse', 'HEAD')
        manifest['helper_sha256'] = digest(capture_helper) if capture_helper else None
        manifest['labels'] = {'seed': 'C-seed NanoVirt output, a different lowering implementation',
                              'stage1': 'VM execution of seed compiling the same source',
                              'stage2': 'VM execution of stage1 compiling the same source',
                              'comparison': 'raw stage1 versus stage2; no normalization'}
        save()
        source = 'src_nano/nanoc_v06.nano'
        seed, first, second = [evidence / f'{name}.nvm' for name in ('seed', 'stage1', 'stage2')]
        run('seed', [ROOT / 'bin/nano_virt', source, '--emit-nvm', '--strip-debug', '-o', seed])
        run('seed-verify', [ROOT / 'bin/nano_vm', '--verify-only', seed])
        hosts = imports(seed, 'seed')
        manifest['host_libraries'] = hosts
        retained = {}
        for library in hosts:
            path = Path(library)
            self.assertTrue(path.parent.name.startswith('.nano-gen-'))
            name = path.name.removeprefix('lib').split('.')[0]
            self.assertIn(name, host_metadata)
            metadata = host_metadata[name]
            retained[str(path.parent.parent)] = retained_input_names(name, metadata)
        retained_inputs.write_text(json.dumps(retained, indent=2) + '\n')
        manifest['retained_host_inputs'] = retained
        save()
        # I retain the seed's compiler identity and immutable artifact cache.
        # Changing CC here would request new host-library builds before shadows.
        env['NANOLANG_BOOTSTRAP_NO_CC'] = '1'
        env['NANO_VM'] = str(ROOT / 'bin/nano_vm')
        for label, compiler, output in [('stage1', seed, first), ('stage2', first, second)]:
            run(label, [ROOT / 'bin/nano_vm', compiler, '--', source, '--emit-nvm', '-o', output])
            run(label + '-verify', [ROOT / 'bin/nano_vm', '--verify-only', output])
            self.assertEqual(imports(output, label), hosts, 'I preserve the exact pinned host closure.')
            manifest['stages'][label]['sha256'] = digest(output)
            manifest['stages'][label]['bytes'] = output.stat().st_size
            save()
        self.assertEqual(first.read_bytes(), second.read_bytes(), 'My compiler generations must match raw bytes.')
        manifest['raw_stage1_stage2_equal'] = True
        save()
        hello = evidence / 'hello.nano'
        hello.write_text('fn main() -> int { assert (== (+ 19 23) 42) return 0 }\n'
                         'shadow main { assert (== (main) 0) }\n')
        product = evidence / 'hello.nvm'
        run('hello-compile', [ROOT / 'bin/nano_vm', second, '--', hello, '--emit-nvm', '-o', product])
        run('hello-verify', [ROOT / 'bin/nano_vm', '--verify-only', product])
        run('hello-execute', [ROOT / 'bin/nano_vm', product])
        self.assertEqual({p: digest(p) for p in hosts}, hosts)
        if capture_helper:
            self.assertEqual(digest(capture_helper), manifest['helper_sha256'])
        self.assertEqual(git('rev-parse', 'HEAD'), manifest['source_commit'])
        self.assertEqual(git('status', '--porcelain'), '')
        self.assertFalse(native_marker.exists(), 'I invoked native code generation during VM generations.')
        manifest['vm_generations_nanolang_codegen_calls'] = 0
        host_calls = probe_log.read_text().splitlines() if probe_log.exists() else []
        manifest['host_cache_probe_calls'] = host_calls.count('host-cache-probe')
        manifest['native_host_artifact_calls'] = host_calls.count('native-host-artifact')
        manifest['complete'] = True
        save()


if __name__ == '__main__':
    unittest.main(verbosity=2)
