from pathlib import Path
import os,sys,json,time,hashlib,subprocess,tempfile,traceback
from unittest.mock import patch
import unittest
root=Path('/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122');out=Path(__file__).resolve().parent
assert Path.cwd()==root
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=dict(pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),root=str(root),status='preparing',methods=['test_equals_path_post_capture_reads','test_recovery_parent_allows_slow_capture'],limits=['I execute only the two original methods with unchanged source, assertions and per-command deadlines. I retain TemporaryDirectory fixtures through an external cleanup-only observer; actual fixture prefixes and native operations remain unchanged. cc/clang select the installed supported Clang18; the queried native GNU assembler remains2.42. I edit no production capture/test source or admission. This observation grants no Clang21 or general admission.'])
assert record['pin']=='0419b4d237f0dc16b5b67555aa51883f32d9b68e'
names=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],text=True).splitlines();record['source_hashes']={n:sha(root/n) for n in names if (root/n).is_file()}
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def guards():
 assert {n:sha(root/n) for n in record['source_hashes']}==record['source_hashes']
 if record.get('tools'):assert {n:sha(n) for n in record['tools']}==record['tools']
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==record['pin']
tools=out/'tools';tools.mkdir(exist_ok=False)
for name in ['cc','clang']:(tools/name).symlink_to('/usr/bin/clang-18')
env=dict(os.environ,PATH=str(tools)+':/usr/bin:/bin',CC=str(tools/'cc'),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='10')
for name in ['NANO_CC','NANO_CAPTURE_TIMEOUT_MS','NANO_TRACE_BUILD','NANO_TEST_SLOW_RECOVERY','COMPILER_PATH','NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANOLANG_TRANSLATOR_SOURCE_MODULE']:env.pop(name,None)
for name in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']:
 if name in env:raise RuntimeError('I require the unchanged ordinary sanitizer environment.')
os.environ.clear();os.environ.update(env)
record['environment']={n:env.get(n) for n in ['PATH','CC','NANOLANG_ROOT','NANO_AS_CAPTURE_HELPER','NANO_SHADOW_TIMEOUT_SECONDS','NANO_CAPTURE_TIMEOUT_MS','COMPILER_PATH']}
try:
 save();guards()
 identities={}
 for label,args in [('cc-version',[str(tools/'cc'),'--version']),('clang-version',[str(tools/'clang'),'--version']),('assembler-query',[str(tools/'cc'),'-print-prog-name=as'])]:
  done=subprocess.run(args,capture_output=True,timeout=30,env=env);(out/(label+'.stdout')).write_bytes(done.stdout);(out/(label+'.stderr')).write_bytes(done.stderr);assert done.returncode==0;identities[label]=done.stdout.decode()
 assert identities['cc-version'].startswith('Ubuntu clang version 18.1.3 (1ubuntu1)\n') and identities['clang-version']==identities['cc-version']
 import shutil
 assembler=Path(shutil.which(identities['assembler-query'].strip())).resolve(strict=True)
 done=subprocess.run([assembler,'--version'],capture_output=True,timeout=30,env=env);assert done.returncode==0 and done.stdout.splitlines()[0].endswith(b') 2.42');(out/'assembler-version.stdout').write_bytes(done.stdout);(out/'assembler-version.stderr').write_bytes(done.stderr)
 record['identities']=identities;record['assembler']=str(assembler);record['assembler_version']=done.stdout.decode();record['tools']={str(p):sha(p) for p in [Path('/usr/bin/clang-18').resolve(strict=True),assembler]};save()
 start=time.monotonic();args=['make','CC='+str(tools/'cc'),'obj/test_module_generation_probe','bin/nano_as_capture.so']
 with (out/'build.stdout').open('wb') as a,(out/'build.stderr').open('wb') as b:done=subprocess.run(args,stdout=a,stderr=b,timeout=600,env=env)
 record['build']=dict(argv=args,returncode=done.returncode,seconds=time.monotonic()-start);save();assert done.returncode==0
 record['tools'].update({str(root/n):sha(root/n) for n in ['obj/test_module_generation_probe','bin/nano_as_capture.so']});guards()
 fixtures=out/'fixtures';fixtures.mkdir();tempfile.tempdir=str(fixtures)
 original_temporary=tempfile.TemporaryDirectory
 class RetainedDirectory(original_temporary):
  def cleanup(self):self._finalizer.detach()
 command_dir=out/'commands';command_dir.mkdir();commands=[];original_run=subprocess.run
 def recorded_run(*args,**kwargs):
  number=len(commands);item=dict(argv=list(map(str,args[0] if args else kwargs['args'])),cwd=str(kwargs.get('cwd',root)),timeout=kwargs.get('timeout'),environment={n:(kwargs.get('env') or os.environ).get(n) for n in ['PATH','CC','NANO_CC','NANO_BUILD_CACHE','NANO_AS_CAPTURE_HELPER','NANO_TEST_SLOW_RECOVERY','NANO_CAPTURE_TIMEOUT_MS','NANO_TRACE_BUILD','NANO_SHADOW_TIMEOUT_SECONDS','COMPILER_PATH']});commands.append(item)
  (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');start=time.monotonic()
  try:
   done=original_run(*args,**kwargs);item['returncode']=done.returncode
   for label in ['stdout','stderr']:
    data=getattr(done,label);item[label+'_present']=data is not None
    if data is not None:(command_dir/f'{number:05d}.{label}').write_bytes(data.encode() if isinstance(data,str) else data)
   return done
  except BaseException as error:
   item['error']=repr(error)
   if isinstance(error,subprocess.TimeoutExpired):
    for label,data in [('stdout',error.output),('stderr',error.stderr)]:
     if data is not None:(command_dir/f'{number:05d}.{label}').write_bytes(data.encode() if isinstance(data,str) else data)
   raise
  finally:
   item['seconds']=time.monotonic()-start;(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 record['status']='running-original-methods';save()
 start=time.monotonic()
 with patch.object(tempfile,'TemporaryDirectory',RetainedDirectory),patch.object(subprocess,'run',recorded_run):
  suite=unittest.defaultTestLoader.loadTestsFromNames(['tests.test_source_snapshots.SourceSnapshots.'+name for name in record['methods']]);assert suite.countTestCases()==2
  with (out/'original-methods.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 record['tests']=dict(discovered=2,ran=result.testsRun,failures=[dict(case=case.id(),traceback=tb) for case,tb in result.failures],errors=[dict(case=case.id(),traceback=tb) for case,tb in result.errors],skipped=[(case.id(),reason) for case,reason in result.skipped],seconds=time.monotonic()-start,successful=result.wasSuccessful())
 record['status']='terminal-pass' if result.wasSuccessful() else 'terminal-failure';guards();record['source_and_tool_guards_unchanged']=True
except BaseException as error:
 record.update(status='observer-failure',error=repr(error));(out/'exception').write_text(traceback.format_exc());raise
finally:save()
print(json.dumps({k:v for k,v in record.items() if k not in ['source_hashes','tests','tools','identities']}));sys.exit(0 if record['status']=='terminal-pass' else 1)
