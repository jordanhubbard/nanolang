nano_module_dependencies: /home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/resume/fixtures/nano=native-timing-xagg3x89/foreign/payload.s
