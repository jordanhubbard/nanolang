from pathlib import Path
from tests.test_nanolang_translator_affine_state import corpus
import subprocess,json,sys
out=Path(sys.argv[1]);out.mkdir(exist_ok=False);cases=corpus(False);paths=[]
for i,(name,data,want) in enumerate(cases):
 p=out/f'{i}.bin';p.write_bytes(data);paths.append(p)
rows={}
for role,exe in [('actual-c','obj/nvm2c_affine_state_reference'),('native','.test_output/affine-state-20261122/preflight/driver-final')]:
 reports=[]
 for start in range(0,len(paths),16):
  p=subprocess.run([exe,*map(str,paths[start:start+16])],capture_output=True,timeout=600);(out/f'{role}-{start}.stdout').write_bytes(p.stdout);(out/f'{role}-{start}.stderr').write_bytes(p.stderr);assert p.returncode==0,(role,start,p.returncode,p.stderr[-500:]);reports+=p.stdout.decode().splitlines()
 assert len(reports)==len(cases);rows[role]=reports;(out/(role+'.reports')).write_text('\n'.join(reports)+'\n')
errors=[]
for i,((name,_,want),got) in enumerate(zip(cases,rows['actual-c'])):
 if 'carrier' in want:
  if got!=want['carrier']:errors.append((name,'carrier',got))
 else:
  steps=got.split('|')
  for j,value_ in want.items():
   if steps[j][0]!=str(int(value_)):errors.append((name,j,value_,steps[j][:200]))
diff=[(i,cases[i][0]) for i,(a,b) in enumerate(zip(rows['actual-c'],rows['native'])) if a!=b];(out/'result.json').write_text(json.dumps(dict(cases=len(cases),expectation_errors=errors,differences=diff),indent=2)+'\n');print('cases',len(cases),'expectation errors',errors[:8],'differences',diff[:8]);assert not errors and not diff
