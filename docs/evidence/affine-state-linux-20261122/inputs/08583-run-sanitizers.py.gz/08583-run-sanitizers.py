from pathlib import Path
import sys,os,json,subprocess,time,shlex
root=Path.cwd();products=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
record=dict(status='running',steps=[],environment={k:os.environ.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},limits=['I instrument the actual affine-state implementation plus ownership/retained-layout/reference/layout-cursor/ISA providers and oracle/original unit. Other linked providers retain ordinary instrumentation; this is not all-provider or private-profile qualification. Darwin instrumentation does not establish LeakSanitizer support. All original comparisons/allocator-failure assertions remain intact.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,args,timeout=600):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,timeout=timeout);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);record['steps'].append(dict(name=name,argv=list(map(str,args)),returncode=p.returncode,seconds=time.monotonic()-start));save();assert p.returncode==0,(name,p.returncode,p.stderr[-1000:]);return p.stdout.decode().splitlines()
text=subprocess.check_output(['make','-Bn','CC=/usr/bin/cc','obj/nvm2c_affine_state_reference'],text=True);(out/'reference-dry-run').write_text(text)
args=next(shlex.split(l) for l in text.replace('\\\n',' ').splitlines() if l.startswith('/usr/bin/cc ') and 'tests/nvm2c_affine_state_reference.c' in shlex.split(l))
providers={f'obj/nanoisa/{name}.o':f'src/nanoisa/{name}.c' for name in ['ownership_contracts','retained_layouts','reference_places','nvm_v2_layouts','nvm_v2_cursor','isa']}
flags=['-O1','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
args=[a for a in args if a not in providers];args[args.index('-o')+1]=str(out/'reference');args += [*providers.values(),*flags]
run('build-reference',args)
args_unit=list(args);args_unit[args_unit.index('tests/nvm2c_affine_state_reference.c')]='tests/nanoisa/test_affine_state.c';args_unit[args_unit.index('-o')+1]=str(out/'original');args_unit+=['src/nanoisa/affine_state.c'];run('build-original',args_unit);record['original']=run('original',[out/'original'])
state_object=out/'state-allocation.o';run('build-allocation-state',['/usr/bin/cc','-std=c99','-D_GNU_SOURCE','-Isrc','-Isrc/nanoisa',*flags,'-Dmalloc=affine_test_malloc','-Dcalloc=affine_test_calloc','-c','src/nanoisa/affine_state.c','-o',state_object])
args_alloc=[a for a in args_unit if a!='src/nanoisa/affine_state.c'];args_alloc[args_alloc.index('-o')+1]=str(out/'original-allocation');args_alloc+=['-DAFFINE_ALLOCATION_TEST',str(state_object)];run('build-original-allocation',args_alloc);record['original_allocation']=run('original-allocation',[out/'original-allocation'])
m=json.loads((products/'manifest.json').read_text());paths=[products/e['file'] for e in m['inputs']];reports=[]
for offset in range(0,len(paths),16):reports+=run(f'cases-{offset:05d}',[out/'reference',*paths[offset:offset+16]])
assert reports==(products/'actual-c.reports').read_text().splitlines();record.update(status='passed',cases=len(reports));save();print(json.dumps(dict(status=record['status'],cases=len(reports),original=record['original'],original_allocation=record['original_allocation'])))
