#define main retained_original_main
#include "../../../tests/nanoisa/test_affine_state.c"
#undef main
int main(void) {
    NvmModule *m=fixture();NvmAffineState *s=nvm_affine_state_create(m,0,8);CHECK(s);
    make_pair(s);CHECK(nvm_affine_region_begin(s));uint16_t path=0;
    CHECK(nvm_affine_borrow(s,0,5,&path,1,NVM_REFERENCE_EXCLUSIVE));
    NvmAffineState *copy=nvm_affine_state_clone(s);CHECK(copy);path=1;
    uint16_t left[]={0,0},right[]={1,0};
    CHECK(!nvm_affine_owner_access(s,5,left,2,false));
    CHECK(nvm_affine_owner_access(s,5,right,2,false));
    CHECK(nvm_affine_state_equal(s,copy));
    nvm_affine_state_free(copy);nvm_affine_state_free(s);nvm_module_free(m);
    printf("I passed %u actual C path-copy checks.\n",checks);return 0;
}
