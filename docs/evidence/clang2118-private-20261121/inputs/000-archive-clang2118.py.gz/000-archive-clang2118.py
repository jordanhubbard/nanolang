from pathlib import Path
import gzip,hashlib,json
root=Path('.test_output');dest=Path('docs/evidence/clang2118-private-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
current=root/'clang2118-equals-44940350023/source-capture-tools-linux/as246-candidate'
r=json.loads((current/'result.json').read_text());t=json.loads((current/'tests.json').read_text())
assert r['clang_2118_observation_passed'] and r['checkout_sources_restored'] and not r['private_candidate_qualification_passed']
assert t['discovered']==t['ran']==8 and t['errors']==t['failures']==0 and not t['skipped']
assert len(r['clang_native_equals_comparisons'])==9 and sum(x['cases'] for x in r['clang_native_equals_comparisons'])==36
for item in r['clang_native_equals_comparisons']:
 x=json.loads((current/(item['label']+'.stdout')).read_text());assert len(x['cases'])==4
 assert all(not c['published_unit_aliases'] and c['retained_native_object_identical'] and c['cold_reuse_record'] and c['warm_reuse_record'] for c in x['cases'])
paths={Path(__file__),Path('scripts/ci_qualify_as246.py'),Path('.github/workflows/source-capture-toolchain-diagnostic.yml')}
for pattern in ('clang2118-equals-44940350023','clang2118-equals-44938993437'):
 paths.update(p for p in (root/pattern).rglob('*') if p.is_file())
files=[];seen={};sha=lambda b:hashlib.sha256(b).hexdigest()
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw);out=seen.get(digest,dest/'inputs'/f'{i:03d}-{p.name}.gz');seen[digest]=out;packed=gzip.compress(raw,mtime=0);out.write_bytes(packed)
 files.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=digest,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
manifest=dict(commit=r['source_pin'],run=44940350023,previous_setup_refusal=44938993437,files=files)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for item in files:
 packed=(dest/item['artifact']).read_bytes();assert sha(packed)==item['compressed_sha256'] and sha(gzip.decompress(packed))==item['sha256']
print(len(files),sum(x['bytes'] for x in files),sum(p.stat().st_size for p in seen.values()))
