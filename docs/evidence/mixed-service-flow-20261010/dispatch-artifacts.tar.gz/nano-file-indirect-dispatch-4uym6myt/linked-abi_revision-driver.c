#include "src/nanoisa/nvm2c_file_indirect_private.h"
#include <stdio.h>
#include <string.h>
int g_argc;char **g_argv;
static unsigned opens,closes;
FILE *file_runtime_tmpfile(void){opens++;return tmpfile();}
int file_runtime_fclose(FILE *f){closes++;return fclose(f);}
size_t file_runtime_fread(void *p,size_t n,size_t c,FILE *f){return fread(p,n,c,f);}
size_t file_runtime_fwrite(const void *p,size_t n,size_t c,FILE *f){return fwrite(p,n,c,f);}
int file_runtime_fseek(FILE *f,long o,int w){return fseek(f,o,w);}
int file_runtime_ferror(FILE *f){return ferror(f);}
int main(void){NvmFileIndirectOptions options={1,100000};NvmFileRuntimeView out,old;memset(&out,0xa5,sizeof out);old=out;(void)old;NvmFileIndirectExecutionReport r=nvm_file_native_indirect_execute(&options,&out);return !(r.runtime.status==NVM_FILE_RUNTIME_UNRESOLVED && !r.runtime.acquired && !r.instructions_started && !memcmp(&out,&old,sizeof out) && r.revision==1 && r.instruction_limit==100000 && !r.fuel_exhausted && !opens && !closes);}
