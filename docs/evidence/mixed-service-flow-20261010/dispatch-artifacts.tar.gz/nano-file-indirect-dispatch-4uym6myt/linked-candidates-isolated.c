#include "src/nanoisa/nvm2c_file_indirect_private.h"
#include "src/nanoisa/nvm_v2_sections.h"
#include <limits.h>
#include <string.h>
#ifndef NVM_FILE_INDIRECT_NATIVE_PRIVATE
#error I require private indirect File providers
#endif
#if NVM_FILE_INDIRECT_NATIVE_ABI != 1u
#error I require indirect native ABI revision 1
#endif
#define NF_TRY(expr) do { NvmFileRuntimeStatus nf_status_=(expr); if(nf_status_!=NVM_FILE_RUNTIME_OK)return nf_status_; } while(0)
static NvmFileRuntimeStatus nf_bad(NvmFileRuntime *c){return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_STATE);}
static int64_t nf_bits(uint64_t x){int64_t y;memcpy(&y,&x,sizeof y);return y;}
static bool nf_scalar(const NvmFileRuntimeView *v,uint8_t tag){
 return v->initialized && !v->owning && !v->formal && !v->type.mode &&
 v->type.category==NVM_FILE_CATEGORY_UNKNOWN && v->type.tag==tag &&
 v->type.global_index==NVM_V2_NO_INDEX && v->type.catalog_ordinal==NVM_V2_NO_INDEX &&
 v->fields==(tag==TAG_VOID?0:1) && (tag!=TAG_BOOL || v->values[0]==0 || v->values[0]==1);
}
static NvmFileIndirectExecutionReport nf_refused(NvmFileRuntimeStatus status,const NvmFileIndirectOptions *options){
NvmFileIndirectExecutionReport r={0};r.revision=1u;r.instruction_limit=options?options->instruction_limit:0;
r.runtime.status=status;r.runtime.function=r.runtime.instruction=NVM_V2_NO_INDEX;return r;}
static const uint8_t nf_module[]={
78,86,77,2,1,0,2,0,130,3,0,0,84,11,0,0,0,0,0,0,40,0,0,0,
11,0,0,0,0,0,0,0,0,0,0,0,26,110,201,226,1,0,0,0,0,0,0,0,
48,1,0,0,0,0,0,0,4,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,
52,1,0,0,0,0,0,0,24,6,0,0,0,0,0,0,3,0,0,0,0,0,0,0,
76,7,0,0,0,0,0,0,88,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,
164,7,0,0,0,0,0,0,48,1,0,0,0,0,0,0,5,0,0,0,0,0,0,0,
212,8,0,0,0,0,0,0,196,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,
152,9,0,0,0,0,0,0,80,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,
232,9,0,0,0,0,0,0,4,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,
236,9,0,0,0,0,0,0,84,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,
64,10,0,0,0,0,0,0,4,0,0,0,0,0,0,0,13,0,0,0,0,0,0,0,
68,10,0,0,0,0,0,0,152,0,0,0,0,0,0,0,14,0,0,0,0,0,0,0,
220,10,0,0,0,0,0,0,120,0,0,0,0,0,0,0,0,0,0,0,35,0,0,0,
5,0,0,0,4,0,0,0,109,97,105,110,5,0,0,0,23,0,0,0,110,115,105,58,
110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,0,5,0,0,0,
28,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,
116,101,109,35,116,101,109,112,5,0,0,0,34,0,0,0,110,115,105,58,110,97,110,111,
108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,119,114,105,116,101,95,98,121,
116,101,0,0,5,0,0,0,30,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,114,101,119,105,110,100,0,0,5,0,0,0,
33,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,
116,101,109,35,114,101,97,100,95,98,121,116,101,0,0,0,5,0,0,0,29,0,0,0,
110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,
99,108,111,115,101,0,0,0,5,0,0,0,28,0,0,0,110,115,105,58,110,97,110,111,
108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,70,105,108,101,5,0,0,0,
33,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,
116,101,109,35,70,105,108,101,69,114,114,111,114,0,0,0,5,0,0,0,40,0,0,0,
110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,
70,105,108,101,69,114,114,111,114,46,115,116,97,116,117,115,5,0,0,0,44,0,0,0,
110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,
70,105,108,101,69,114,114,111,114,46,104,111,115,116,95,101,114,114,110,111,5,0,0,0,
47,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,
116,101,109,35,70,105,108,101,69,114,114,111,114,46,99,108,101,97,110,117,112,95,101,114,
114,110,111,0,5,0,0,0,39,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,70,105,108,101,69,114,114,111,114,46,98,121,
116,101,115,0,5,0,0,0,37,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,70,105,108,101,69,114,114,111,114,46,101,111,
102,0,0,0,5,0,0,0,42,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,70,105,108,101,69,114,114,111,114,46,99,111,
110,115,117,109,101,100,0,0,5,0,0,0,48,0,0,0,110,115,105,58,110,97,110,111,
108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,70,105,108,101,69,114,114,111,
114,46,99,108,101,97,110,117,112,95,102,97,105,108,101,100,5,0,0,0,32,0,0,0,
110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,
82,101,97,100,66,121,116,101,5,0,0,0,38,0,0,0,110,115,105,58,110,97,110,111,
108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,82,101,97,100,66,121,116,101,
46,118,97,108,117,101,0,0,5,0,0,0,36,0,0,0,110,115,105,58,110,97,110,111,
108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,82,101,97,100,66,121,116,101,
46,101,111,102,5,0,0,0,34,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,79,112,101,110,82,101,115,117,108,116,0,0,
5,0,0,0,37,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,79,112,101,110,82,101,115,117,108,116,46,79,107,0,0,0,
5,0,0,0,40,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,79,112,101,110,82,101,115,117,108,116,46,69,114,114,111,114,
5,0,0,0,35,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,87,114,105,116,101,82,101,115,117,108,116,0,5,0,0,0,
38,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,
116,101,109,35,87,114,105,116,101,82,101,115,117,108,116,46,79,107,0,0,5,0,0,0,
41,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,101,115,121,115,
116,101,109,35,87,114,105,116,101,82,101,115,117,108,116,46,69,114,114,111,114,0,0,0,
5,0,0,0,38,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,80,111,115,105,116,105,111,110,82,101,115,117,108,116,0,0,
5,0,0,0,41,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,80,111,115,105,116,105,111,110,82,101,115,117,108,116,46,79,
107,0,0,0,5,0,0,0,44,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,80,111,115,105,116,105,111,110,82,101,115,117,
108,116,46,69,114,114,111,114,5,0,0,0,34,0,0,0,110,115,105,58,110,97,110,111,
108,97,110,103,47,102,105,108,101,115,121,115,116,101,109,35,82,101,97,100,82,101,115,117,
108,116,0,0,5,0,0,0,37,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,82,101,97,100,82,101,115,117,108,116,46,79,
107,0,0,0,5,0,0,0,40,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,82,101,97,100,82,101,115,117,108,116,46,69,
114,114,111,114,5,0,0,0,35,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,
47,102,105,108,101,115,121,115,116,101,109,35,67,108,111,115,101,82,101,115,117,108,116,0,
5,0,0,0,38,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,67,108,111,115,101,82,101,115,117,108,116,46,79,107,0,0,
5,0,0,0,41,0,0,0,110,115,105,58,110,97,110,111,108,97,110,103,47,102,105,108,
101,115,121,115,116,101,109,35,67,108,111,115,101,82,101,115,117,108,116,46,69,114,114,111,
114,0,0,0,5,0,0,0,6,0,0,0,104,101,108,112,101,114,0,0,8,0,0,0,
0,0,1,0,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,
11,0,0,0,11,0,0,0,2,0,1,0,1,11,0,0,1,0,0,0,0,0,1,0,
11,0,0,0,0,0,1,0,10,0,0,0,2,0,1,0,8,1,0,0,10,0,0,0,
1,0,1,0,8,0,0,0,10,0,0,0,9,0,0,0,1,0,0,0,255,255,255,255,
0,0,0,0,7,0,0,0,0,0,7,0,8,0,0,0,1,0,0,0,255,255,255,255,
9,0,0,0,1,0,0,0,255,255,255,255,10,0,0,0,1,0,0,0,255,255,255,255,
11,0,0,0,1,0,0,0,255,255,255,255,12,0,0,0,4,0,0,0,255,255,255,255,
13,0,0,0,4,0,0,0,255,255,255,255,14,0,0,0,4,0,0,0,255,255,255,255,
15,0,0,0,0,0,2,0,16,0,0,0,1,0,0,0,255,255,255,255,17,0,0,0,
4,0,0,0,255,255,255,255,18,0,0,0,2,0,2,0,19,0,0,0,8,0,0,0,
1,0,0,0,20,0,0,0,8,0,0,0,2,0,0,0,21,0,0,0,2,0,2,0,
22,0,0,0,1,0,0,0,255,255,255,255,23,0,0,0,8,0,0,0,2,0,0,0,
24,0,0,0,2,0,2,0,25,0,0,0,0,0,0,0,255,255,255,255,26,0,0,0,
8,0,0,0,2,0,0,0,27,0,0,0,2,0,2,0,28,0,0,0,8,0,0,0,
3,0,0,0,29,0,0,0,8,0,0,0,2,0,0,0,30,0,0,0,2,0,2,0,
31,0,0,0,0,0,0,0,255,255,255,255,32,0,0,0,8,0,0,0,2,0,0,0,
33,0,0,0,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
31,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,34,0,0,0,1,0,0,0,
31,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,
34,0,0,0,1,0,0,0,35,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,
1,0,0,0,0,0,0,0,34,0,0,0,2,0,0,0,45,0,0,0,0,0,0,0,
4,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,34,0,0,0,3,0,0,0,
49,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,
34,0,0,0,4,0,0,0,61,0,0,0,0,0,0,0,19,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,59,5,0,0,0,59,3,0,0,0,17,0,0,1,41,0,
0,0,0,0,0,0,16,0,0,59,4,0,0,0,61,16,0,0,61,1,42,0,0,0,
0,0,0,0,61,16,0,0,61,16,0,0,16,1,0,60,1,0,1,0,61,3,1,58,
11,0,0,0,250,1,0,0,0,61,250,2,0,0,0,61,0,0,0,0,5,0,0,0,
1,0,0,0,2,0,0,0,5,0,0,0,3,0,0,0,1,0,0,0,3,0,0,0,
6,0,0,0,3,0,0,0,1,0,0,0,4,0,0,0,7,0,0,0,3,0,0,0,
1,0,0,0,5,0,0,0,7,0,0,0,3,0,0,0,1,0,0,0,6,0,0,0,
7,0,0,0,3,0,0,0,0,0,0,0,1,0,0,0,9,0,0,0,0,3,1,1,
3,1,1,1,1,0,0,0,6,0,0,0,2,0,0,0,1,0,0,0,255,255,255,255,
11,0,0,0,255,255,255,255,10,0,0,0,4,0,0,0,1,0,1,0,1,0,0,0,
255,255,255,255,1,0,0,0,255,255,255,255,1,0,1,0,1,0,0,0,255,255,255,255,
1,0,0,0,255,255,255,255,1,0,1,0,11,0,0,0,255,255,255,255,11,0,0,0,
255,255,255,255,2,0,2,0,1,0,0,0,255,255,255,255,1,0,0,0,255,255,255,255,
11,0,0,0,255,255,255,255,0,0,0,0,11,0,0,0,255,255,255,255,2,0,1,0,
5,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,
1,0,0,0,2,0,0,0,2,0,0,0,3,0,0,0,3,0,0,0,4,0,0,0,
4,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,2,0,0,0,2,0,0,0,
3,0,0,0,3,0,0,0,4,0,0,0,4,0,0,0,5,0,0,0,5,0,0,0,
6,0,0,0,6,0,0,0,7,0,0,0,7,0,0,0,8,0,0,0,
};
static bool nf_agrees_0_0(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,0,&in) || !nvm_file_indirect_hosted_variant_count(p,0,0,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,0,&component) || component!=0)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(59))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=1)return false;
if(in.decoded.operand_types[0]!=3 || (uint64_t)in.decoded.operands[0].u32!=UINT64_C(5))return false;
if(!nvm_file_indirect_hosted_variant(p,0,0,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(5))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(64))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(384))return false;
if((uint64_t)(variant.body.obligation.kind)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.site)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.target)!=UINT64_C(5))return false;
if((uint64_t)(variant.body.obligation.checks)!=UINT64_C(448))return false;
if((uint64_t)(variant.body.obligation.required_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.acquired_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.parameters)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.owned_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.borrowed_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result_count)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.outcomes[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.outcomes[1])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.tag)!=UINT64_C(11))return false;
if((uint64_t)(variant.body.obligation.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.category)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,0,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,0,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,0,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_0_1(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,1,&in) || !nvm_file_indirect_hosted_variant_count(p,0,1,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,1,&component) || component!=1)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(5))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(59))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=2)return false;
if(in.decoded.operand_types[0]!=3 || (uint64_t)in.decoded.operands[0].u32!=UINT64_C(3))return false;
if(in.call_references[0]!=65535)return false;
if(!nvm_file_indirect_hosted_variant(p,0,1,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(5))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(64))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(384))return false;
if((uint64_t)(variant.body.obligation.kind)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.site)!=UINT64_C(5))return false;
if((uint64_t)(variant.body.obligation.target)!=UINT64_C(3))return false;
if((uint64_t)(variant.body.obligation.checks)!=UINT64_C(448))return false;
if((uint64_t)(variant.body.obligation.required_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.acquired_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.parameters)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.owned_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.borrowed_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result_count)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.outcomes[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.outcomes[1])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.tag)!=UINT64_C(11))return false;
if((uint64_t)(variant.body.obligation.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.category)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,1,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_input_stack(p,0,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,1,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_0_2(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,2,&in) || !nvm_file_indirect_hosted_variant_count(p,0,2,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,2,&component) || component!=2)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(10))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(17))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(3))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=3)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_variant(p,0,2,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,2,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,2,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_input_stack(p,0,2,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,2,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_0_3(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,3,&in) || !nvm_file_indirect_hosted_variant_count(p,0,3,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,3,&component) || component!=3)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(13))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(9))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=4)return false;
if(in.decoded.operand_types[0]!=5 || (uint64_t)in.decoded.operands[0].i64!=UINT64_C(41))return false;
if(!nvm_file_indirect_hosted_variant(p,0,3,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,3,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,3,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,3,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_0_4(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,4,&in) || !nvm_file_indirect_hosted_variant_count(p,0,4,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,4,&component) || component!=4)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(22))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(16))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(3))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=5)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_variant(p,0,4,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,4,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,4,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_input_stack(p,0,4,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,4,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_0_5(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,5,&in) || !nvm_file_indirect_hosted_variant_count(p,0,5,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,5,&component) || component!=5)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(25))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(59))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=6)return false;
if(in.decoded.operand_types[0]!=3 || (uint64_t)in.decoded.operands[0].u32!=UINT64_C(4))return false;
if(in.call_references[0]!=65535)return false;
if(in.call_references[1]!=65535)return false;
if(!nvm_file_indirect_hosted_variant(p,0,5,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(5))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(64))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(384))return false;
if((uint64_t)(variant.body.obligation.kind)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.site)!=UINT64_C(25))return false;
if((uint64_t)(variant.body.obligation.target)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.obligation.checks)!=UINT64_C(448))return false;
if((uint64_t)(variant.body.obligation.required_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.acquired_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.parameters)!=UINT64_C(2))return false;
if((uint64_t)(variant.body.obligation.owned_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.borrowed_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result_count)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.outcomes[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.outcomes[1])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.category)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,5,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,5,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_input_stack(p,0,5,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,0,5,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,5,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_0_6(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,0,6,&in) || !nvm_file_indirect_hosted_variant_count(p,0,6,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,0,6,&component) || component!=6)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(30))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,0,6,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,6,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,0,6,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(10))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(value.type.category)!=UINT64_C(2))return false;
if((uint64_t)(value.initialized)!=UINT64_C(0))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_input_stack(p,0,6,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,0,6,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_1_0(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,1,0,&in) || !nvm_file_indirect_hosted_variant_count(p,1,0,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,1,0,&component) || component!=0)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(16))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(3))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=1)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_variant(p,1,0,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,1,0,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,1,0,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_1_1(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,1,1,&in) || !nvm_file_indirect_hosted_variant_count(p,1,1,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,1,1,&component) || component!=1)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(3))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,1,1,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,1,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,1,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,1,1,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_2_0(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,2,0,&in) || !nvm_file_indirect_hosted_variant_count(p,2,0,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,2,0,&component) || component!=0)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(9))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=1)return false;
if(in.decoded.operand_types[0]!=5 || (uint64_t)in.decoded.operands[0].i64!=UINT64_C(42))return false;
if(!nvm_file_indirect_hosted_variant(p,2,0,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,2,0,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,2,0,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_2_1(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,2,1,&in) || !nvm_file_indirect_hosted_variant_count(p,2,1,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,2,1,&component) || component!=1)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(9))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,2,1,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,2,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,2,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,2,1,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_3_0(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,3,0,&in) || !nvm_file_indirect_hosted_variant_count(p,3,0,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,3,0,&component) || component!=0)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(16))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(3))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=1)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_variant(p,3,0,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,3,0,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,3,0,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_3_1(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,3,1,&in) || !nvm_file_indirect_hosted_variant_count(p,3,1,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,3,1,&component) || component!=1)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(3))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,3,1,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,3,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,3,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,3,1,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_4_0(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,4,0,&in) || !nvm_file_indirect_hosted_variant_count(p,4,0,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,4,0,&component) || component!=0)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(16))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(3))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=1)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_variant(p,4,0,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,0,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,0,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,4,0,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_4_1(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,4,1,&in) || !nvm_file_indirect_hosted_variant_count(p,4,1,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,4,1,&component) || component!=1)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(3))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(16))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(3))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=2)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_variant(p,4,1,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,1,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,4,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,4,1,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_4_2(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,4,2,&in) || !nvm_file_indirect_hosted_variant_count(p,4,2,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,4,2,&component) || component!=2)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(6))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(60))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(2))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=3)return false;
if(in.decoded.operand_types[0]!=2 || (uint64_t)in.decoded.operands[0].u16!=UINT64_C(1))return false;
if(in.decoded.operand_types[1]!=2 || (uint64_t)in.decoded.operands[1].u16!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_variant(p,4,2,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(2))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(5))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(64))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(384))return false;
if((uint64_t)(variant.body.obligation.kind)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.site)!=UINT64_C(6))return false;
if((uint64_t)(variant.body.obligation.target)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.checks)!=UINT64_C(448))return false;
if((uint64_t)(variant.body.obligation.required_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.acquired_rights)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.parameters)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.owned_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.borrowed_inputs)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result_count)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.outcomes[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.outcomes[1])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.obligation.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.obligation.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(variant.body.obligation.result.category)!=UINT64_C(0))return false;
{NvmFileIndirectFlowCall call;if(!nvm_file_indirect_hosted_call(p,4,2,0,&call))return false;
if((uint64_t)(call.function)!=UINT64_C(4))return false;
if((uint64_t)(call.pc)!=UINT64_C(6))return false;
if((uint64_t)(call.candidates)!=UINT64_C(7))return false;
if((uint64_t)(call.checked_candidates)!=UINT64_C(6))return false;
if((uint64_t)(call.common.kind)!=UINT64_C(1))return false;
if((uint64_t)(call.common.site)!=UINT64_C(6))return false;
if((uint64_t)(call.common.target)!=UINT64_C(4294967295))return false;
if((uint64_t)(call.common.checks)!=UINT64_C(448))return false;
if((uint64_t)(call.common.required_rights)!=UINT64_C(0))return false;
if((uint64_t)(call.common.acquired_rights)!=UINT64_C(0))return false;
if((uint64_t)(call.common.parameters)!=UINT64_C(1))return false;
if((uint64_t)(call.common.owned_inputs)!=UINT64_C(0))return false;
if((uint64_t)(call.common.borrowed_inputs)!=UINT64_C(0))return false;
if((uint64_t)(call.common.result_count)!=UINT64_C(1))return false;
if((uint64_t)(call.common.outcomes[0])!=UINT64_C(0))return false;
if((uint64_t)(call.common.outcomes[1])!=UINT64_C(0))return false;
if((uint64_t)(call.common.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(call.common.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(call.common.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(call.common.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(call.common.result.category)!=UINT64_C(0))return false;
}
if(!nvm_file_indirect_hosted_input_local(p,4,2,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,2,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,4,2,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,4,2,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,4,2,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_4_3(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,4,3,&in) || !nvm_file_indirect_hosted_variant_count(p,4,3,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,4,3,&component) || component!=3)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(11))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,4,3,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(2))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,3,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_local(p,4,3,0,1,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_input_stack(p,4,3,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(1))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,4,3,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_5_0(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,5,0,&in) || !nvm_file_indirect_hosted_variant_count(p,5,0,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,5,0,&component) || component!=0)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(3))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(2))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=1)return false;
if(in.decoded.operand_types[0]!=1 || (uint64_t)in.decoded.operands[0].u8!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_variant(p,5,0,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,5,0,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_5_1(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,5,1,&in) || !nvm_file_indirect_hosted_variant_count(p,5,1,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,5,1,&component) || component!=1)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(2))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(58))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(2))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=2)return false;
if(in.successors[1]!=4)return false;
if(in.decoded.operand_types[0]!=4 || (uint64_t)in.decoded.operands[0].i32!=UINT64_C(11))return false;
if(!nvm_file_indirect_hosted_variant(p,5,1,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(3))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(0))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_stack(p,5,1,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(4))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,5,1,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_5_2(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,5,2,&in) || !nvm_file_indirect_hosted_variant_count(p,5,2,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,5,2,&component) || component!=2)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(7))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(250))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=3)return false;
if(in.decoded.operand_types[0]!=3 || (uint64_t)in.decoded.operands[0].u32!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_variant(p,5,2,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,5,2,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_5_3(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,5,3,&in) || !nvm_file_indirect_hosted_variant_count(p,5,3,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,5,3,&component) || component!=3)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(12))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,5,3,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_stack(p,5,3,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,5,3,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_5_4(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,5,4,&in) || !nvm_file_indirect_hosted_variant_count(p,5,4,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,5,4,&component) || component!=4)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(13))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(250))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(1))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(5))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(1))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(in.successors[0]!=5)return false;
if(in.decoded.operand_types[0]!=3 || (uint64_t)in.decoded.operands[0].u32!=UINT64_C(2))return false;
if(!nvm_file_indirect_hosted_variant(p,5,4,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(1))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,5,4,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees_5_5(const NvmFileIndirectHostedPlan *p){
NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
NvmFileFlowValue value;NvmFileFlowReference reference;
uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;
(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;
if(!nvm_file_indirect_hosted_instruction(p,5,5,&in) || !nvm_file_indirect_hosted_variant_count(p,5,5,&count) || count!=1 || !nvm_file_indirect_hosted_component(p,5,5,&component) || component!=5)return false;
if((uint64_t)(in.byte_offset)!=UINT64_C(18))return false;
if((uint64_t)(in.decoded.opcode)!=UINT64_C(61))return false;
if((uint64_t)(in.decoded.operand_count)!=UINT64_C(0))return false;
if((uint64_t)(in.decoded.byte_length)!=UINT64_C(1))return false;
if((uint64_t)(in.successor_count)!=UINT64_C(0))return false;
if((uint64_t)(in.catalog_ordinal)!=UINT64_C(4294967295))return false;
if(!nvm_file_indirect_hosted_variant(p,5,5,0,&variant))return false;
if((uint64_t)(variant.input.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.input.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.input.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.locals)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.output.regions)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.owners)!=UINT64_C(0))return false;
if((uint64_t)(variant.output.references)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_mask)!=UINT64_C(0))return false;
if((uint64_t)(variant.edge_variants[0])!=UINT64_C(255))return false;
if((uint64_t)(variant.edge_variants[1])!=UINT64_C(255))return false;
if((uint64_t)(variant.body.reachable)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.exit_checked)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.refinement)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.has_obligation)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.input_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.output_stack)!=UINT64_C(1))return false;
if((uint64_t)(variant.body.cleanup_local)!=UINT64_C(65535))return false;
if((uint64_t)(variant.body.cleanup)!=UINT64_C(4))return false;
if((uint64_t)(variant.body.discharged_checks)!=UINT64_C(0))return false;
if((uint64_t)(variant.body.pending_checks)!=UINT64_C(128))return false;
if(!nvm_file_indirect_hosted_input_stack(p,5,5,0,0,&value))return false;
if((uint64_t)(value.type.tag)!=UINT64_C(11))return false;
if((uint64_t)(value.type.mode)!=UINT64_C(0))return false;
if((uint64_t)(value.type.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(value.type.category)!=UINT64_C(0))return false;
if((uint64_t)(value.initialized)!=UINT64_C(1))return false;
if((uint64_t)(value.owner)!=UINT64_C(0))return false;
if((uint64_t)(value.arm)!=UINT64_C(0))return false;
for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){
if(!nvm_file_indirect_hosted_input_reference(p,5,5,0,n,&reference))return false;
switch(n){
default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}
return true;}
static bool nf_agrees(const NvmFileIndirectHostedPlan *p){
NvmFileIndirectHostedStartup s;NvmFileIndirectHostedFunction f;NvmFileFlowDeclaration l;
NvmFileNominalLayout t;uint32_t ordinal;uint8_t byte;
(void)l;
if(!nvm_file_indirect_hosted_startup(p,&s))return false;
if((uint64_t)(s.revision)!=UINT64_C(1))return false;
if((uint64_t)(s.entry)!=UINT64_C(0))return false;
if((uint64_t)(s.initializer)!=UINT64_C(4294967295))return false;
if((uint64_t)(s.functions)!=UINT64_C(6))return false;
if((uint64_t)(s.features)!=UINT64_C(898))return false;
if((uint64_t)(s.vm_value_slots)!=UINT64_C(13))return false;
if((uint64_t)(s.native_value_slots)!=UINT64_C(17))return false;
if((uint64_t)(s.frames)!=UINT64_C(3))return false;
if((uint64_t)(s.reference_slots)!=UINT64_C(768))return false;
if((uint64_t)(s.region_slots)!=UINT64_C(768))return false;
if((uint64_t)(s.input_bytes)!=UINT64_C(2900))return false;
if((uint64_t)(s.allocation_bound)!=UINT64_C(33626109))return false;
if((uint64_t)(s.query_storage_peak)!=UINT64_C(7425632))return false;
if((uint64_t)(s.retained_bound)!=UINT64_C(7467044))return false;
if((uint64_t)(s.runtime_admitted)!=UINT64_C(0))return false;
if(s.input_bytes!=sizeof nf_module)return false;
for(size_t n=0;n<sizeof nf_module;n++)if(!nvm_file_indirect_hosted_bytes(p,n,&byte,1) || byte!=nf_module[n])return false;
if(!nvm_file_indirect_hosted_type(p,0,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(1))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(0))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(0))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(0))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(3))return false;
if((uint64_t)(t.category)!=UINT64_C(1))return false;
if(!nvm_file_indirect_hosted_type(p,1,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(2))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(1))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(1))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(0))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(1))return false;
if((uint64_t)(t.category)!=UINT64_C(4))return false;
if(!nvm_file_indirect_hosted_type(p,2,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(3))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(2))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(2))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(0))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(1))return false;
if((uint64_t)(t.category)!=UINT64_C(4))return false;
if(!nvm_file_indirect_hosted_type(p,3,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(4))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(0))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(2))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(3))return false;
if((uint64_t)(t.category)!=UINT64_C(2))return false;
if(!nvm_file_indirect_hosted_type(p,4,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(5))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(4))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(1))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(2))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(1))return false;
if((uint64_t)(t.category)!=UINT64_C(3))return false;
if(!nvm_file_indirect_hosted_type(p,5,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(6))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(5))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(2))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(2))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(1))return false;
if((uint64_t)(t.category)!=UINT64_C(3))return false;
if(!nvm_file_indirect_hosted_type(p,6,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(7))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(6))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(2))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(1))return false;
if((uint64_t)(t.category)!=UINT64_C(3))return false;
if(!nvm_file_indirect_hosted_type(p,7,&t))return false;
if((uint64_t)(t.global_index)!=UINT64_C(8))return false;
if((uint64_t)(t.catalog_ordinal)!=UINT64_C(7))return false;
if((uint64_t)(t.source_ordinal)!=UINT64_C(4))return false;
if((uint64_t)(t.layout_kind)!=UINT64_C(2))return false;
if((uint64_t)(t.ownership_flags)!=UINT64_C(1))return false;
if((uint64_t)(t.category)!=UINT64_C(3))return false;
if(!nvm_file_indirect_hosted_import(p,0,&ordinal) || ordinal!=0)return false;
if(!nvm_file_indirect_hosted_import(p,1,&ordinal) || ordinal!=1)return false;
if(!nvm_file_indirect_hosted_import(p,2,&ordinal) || ordinal!=2)return false;
if(!nvm_file_indirect_hosted_import(p,3,&ordinal) || ordinal!=3)return false;
if(!nvm_file_indirect_hosted_import(p,4,&ordinal) || ordinal!=4)return false;
if(!nvm_file_indirect_hosted_function_order(p,0,&ordinal) || ordinal!=1 || !nvm_file_indirect_hosted_function(p,0,&f))return false;
if((uint64_t)(f.code.code_offset)!=UINT64_C(0))return false;
if((uint64_t)(f.code.code_length)!=UINT64_C(31))return false;
if((uint64_t)(f.code.instruction_count)!=UINT64_C(7))return false;
if((uint64_t)(f.code.declaration.parameters)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.locals)!=UINT64_C(2))return false;
if((uint64_t)(f.code.declaration.result_count)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.category)!=UINT64_C(0))return false;
if((uint64_t)(f.declared_stack)!=UINT64_C(0))return false;
if((uint64_t)(f.operand_peak)!=UINT64_C(2))return false;
if((uint64_t)(f.locals)!=UINT64_C(2))return false;
if((uint64_t)(f.staging_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.frames)!=UINT64_C(3))return false;
if((uint64_t)(f.frame_owner_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_reference_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_region_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.reference_slots)!=UINT64_C(768))return false;
if((uint64_t)(f.region_slots)!=UINT64_C(768))return false;
if((uint64_t)(f.vm_value_slots)!=UINT64_C(13))return false;
if((uint64_t)(f.native_value_slots)!=UINT64_C(17))return false;
if((uint64_t)(f.entry_variant)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,0,0,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(11))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.category)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,0,1,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(10))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(3))return false;
if((uint64_t)(l.category)!=UINT64_C(2))return false;
if(!nf_agrees_0_0(p))return false;
if(!nf_agrees_0_1(p))return false;
if(!nf_agrees_0_2(p))return false;
if(!nf_agrees_0_3(p))return false;
if(!nf_agrees_0_4(p))return false;
if(!nf_agrees_0_5(p))return false;
if(!nf_agrees_0_6(p))return false;
if(!nvm_file_indirect_hosted_function_order(p,1,&ordinal) || ordinal!=2 || !nvm_file_indirect_hosted_function(p,1,&f))return false;
if((uint64_t)(f.code.code_offset)!=UINT64_C(31))return false;
if((uint64_t)(f.code.code_length)!=UINT64_C(4))return false;
if((uint64_t)(f.code.instruction_count)!=UINT64_C(2))return false;
if((uint64_t)(f.code.declaration.parameters)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.locals)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result_count)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.category)!=UINT64_C(0))return false;
if((uint64_t)(f.declared_stack)!=UINT64_C(0))return false;
if((uint64_t)(f.operand_peak)!=UINT64_C(1))return false;
if((uint64_t)(f.locals)!=UINT64_C(1))return false;
if((uint64_t)(f.staging_slots)!=UINT64_C(1))return false;
if((uint64_t)(f.frames)!=UINT64_C(1))return false;
if((uint64_t)(f.frame_owner_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_reference_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_region_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.reference_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.region_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.vm_value_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.native_value_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.entry_variant)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,1,0,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(1))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.category)!=UINT64_C(0))return false;
if(!nf_agrees_1_0(p))return false;
if(!nf_agrees_1_1(p))return false;
if(!nvm_file_indirect_hosted_function_order(p,2,&ordinal) || ordinal!=3 || !nvm_file_indirect_hosted_function(p,2,&f))return false;
if((uint64_t)(f.code.code_offset)!=UINT64_C(35))return false;
if((uint64_t)(f.code.code_length)!=UINT64_C(10))return false;
if((uint64_t)(f.code.instruction_count)!=UINT64_C(2))return false;
if((uint64_t)(f.code.declaration.parameters)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.locals)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result_count)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.category)!=UINT64_C(0))return false;
if((uint64_t)(f.declared_stack)!=UINT64_C(0))return false;
if((uint64_t)(f.operand_peak)!=UINT64_C(1))return false;
if((uint64_t)(f.locals)!=UINT64_C(1))return false;
if((uint64_t)(f.staging_slots)!=UINT64_C(1))return false;
if((uint64_t)(f.frames)!=UINT64_C(1))return false;
if((uint64_t)(f.frame_owner_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_reference_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_region_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.reference_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.region_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.vm_value_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.native_value_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.entry_variant)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,2,0,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(1))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.category)!=UINT64_C(0))return false;
if(!nf_agrees_2_0(p))return false;
if(!nf_agrees_2_1(p))return false;
if(!nvm_file_indirect_hosted_function_order(p,3,&ordinal) || ordinal!=4 || !nvm_file_indirect_hosted_function(p,3,&f))return false;
if((uint64_t)(f.code.code_offset)!=UINT64_C(45))return false;
if((uint64_t)(f.code.code_length)!=UINT64_C(4))return false;
if((uint64_t)(f.code.instruction_count)!=UINT64_C(2))return false;
if((uint64_t)(f.code.declaration.parameters)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.locals)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result_count)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.tag)!=UINT64_C(11))return false;
if((uint64_t)(f.code.declaration.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.category)!=UINT64_C(0))return false;
if((uint64_t)(f.declared_stack)!=UINT64_C(0))return false;
if((uint64_t)(f.operand_peak)!=UINT64_C(1))return false;
if((uint64_t)(f.locals)!=UINT64_C(1))return false;
if((uint64_t)(f.staging_slots)!=UINT64_C(1))return false;
if((uint64_t)(f.frames)!=UINT64_C(1))return false;
if((uint64_t)(f.frame_owner_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_reference_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_region_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.reference_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.region_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.vm_value_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.native_value_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.entry_variant)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,3,0,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(11))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.category)!=UINT64_C(0))return false;
if(!nf_agrees_3_0(p))return false;
if(!nf_agrees_3_1(p))return false;
if(!nvm_file_indirect_hosted_function_order(p,4,&ordinal) || ordinal!=5 || !nvm_file_indirect_hosted_function(p,4,&f))return false;
if((uint64_t)(f.code.code_offset)!=UINT64_C(49))return false;
if((uint64_t)(f.code.code_length)!=UINT64_C(12))return false;
if((uint64_t)(f.code.instruction_count)!=UINT64_C(4))return false;
if((uint64_t)(f.code.declaration.parameters)!=UINT64_C(2))return false;
if((uint64_t)(f.code.declaration.locals)!=UINT64_C(2))return false;
if((uint64_t)(f.code.declaration.result_count)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.tag)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.category)!=UINT64_C(0))return false;
if((uint64_t)(f.declared_stack)!=UINT64_C(0))return false;
if((uint64_t)(f.operand_peak)!=UINT64_C(2))return false;
if((uint64_t)(f.locals)!=UINT64_C(2))return false;
if((uint64_t)(f.staging_slots)!=UINT64_C(3))return false;
if((uint64_t)(f.frames)!=UINT64_C(2))return false;
if((uint64_t)(f.frame_owner_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_reference_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_region_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.reference_slots)!=UINT64_C(512))return false;
if((uint64_t)(f.region_slots)!=UINT64_C(512))return false;
if((uint64_t)(f.vm_value_slots)!=UINT64_C(8))return false;
if((uint64_t)(f.native_value_slots)!=UINT64_C(10))return false;
if((uint64_t)(f.entry_variant)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,4,0,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(1))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.category)!=UINT64_C(0))return false;
if(!nvm_file_indirect_hosted_local(p,4,1,&l))return false;
if((uint64_t)(l.tag)!=UINT64_C(11))return false;
if((uint64_t)(l.mode)!=UINT64_C(0))return false;
if((uint64_t)(l.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(l.category)!=UINT64_C(0))return false;
if(!nf_agrees_4_0(p))return false;
if(!nf_agrees_4_1(p))return false;
if(!nf_agrees_4_2(p))return false;
if(!nf_agrees_4_3(p))return false;
if(!nvm_file_indirect_hosted_function_order(p,5,&ordinal) || ordinal!=0 || !nvm_file_indirect_hosted_function(p,5,&f))return false;
if((uint64_t)(f.code.code_offset)!=UINT64_C(61))return false;
if((uint64_t)(f.code.code_length)!=UINT64_C(19))return false;
if((uint64_t)(f.code.instruction_count)!=UINT64_C(6))return false;
if((uint64_t)(f.code.declaration.parameters)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.locals)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result_count)!=UINT64_C(1))return false;
if((uint64_t)(f.code.declaration.result.tag)!=UINT64_C(11))return false;
if((uint64_t)(f.code.declaration.result.mode)!=UINT64_C(0))return false;
if((uint64_t)(f.code.declaration.result.global_index)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.catalog_ordinal)!=UINT64_C(4294967295))return false;
if((uint64_t)(f.code.declaration.result.category)!=UINT64_C(0))return false;
if((uint64_t)(f.declared_stack)!=UINT64_C(0))return false;
if((uint64_t)(f.operand_peak)!=UINT64_C(1))return false;
if((uint64_t)(f.locals)!=UINT64_C(0))return false;
if((uint64_t)(f.staging_slots)!=UINT64_C(1))return false;
if((uint64_t)(f.frames)!=UINT64_C(1))return false;
if((uint64_t)(f.frame_owner_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_reference_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.frame_region_peak)!=UINT64_C(0))return false;
if((uint64_t)(f.reference_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.region_slots)!=UINT64_C(256))return false;
if((uint64_t)(f.vm_value_slots)!=UINT64_C(2))return false;
if((uint64_t)(f.native_value_slots)!=UINT64_C(2))return false;
if((uint64_t)(f.entry_variant)!=UINT64_C(0))return false;
if(!nf_agrees_5_0(p))return false;
if(!nf_agrees_5_1(p))return false;
if(!nf_agrees_5_2(p))return false;
if(!nf_agrees_5_3(p))return false;
if(!nf_agrees_5_4(p))return false;
if(!nf_agrees_5_5(p))return false;
return true;}
static NvmFileRuntimeStatus nf_function_0(NvmFileRuntime *);
static NvmFileRuntimeStatus nf_function_1(NvmFileRuntime *);
static NvmFileRuntimeStatus nf_function_2(NvmFileRuntime *);
static NvmFileRuntimeStatus nf_function_3(NvmFileRuntime *);
static NvmFileRuntimeStatus nf_function_4(NvmFileRuntime *);
static NvmFileRuntimeStatus nf_function_5(NvmFileRuntime *);
static NvmFileRuntimeStatus nf_function_0(NvmFileRuntime *c){
NvmFileIndirectFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;
NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;
uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];
uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;
(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;
(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;
if(0)goto nf_label_0;
if(0)goto nf_label_1;
if(0)goto nf_label_2;
if(0)goto nf_label_3;
if(0)goto nf_label_4;
if(0)goto nf_label_5;
if(0)goto nf_label_6;
goto nf_label_0;
nf_label_0:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=0 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,0,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
NF_TRY(nvm_file_runtime_frame_call(c));
NF_TRY(nf_function_5(c));
goto nf_label_1;
nf_label_1:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=1 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,1,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
NF_TRY(nvm_file_runtime_frame_call(c));
NF_TRY(nf_function_3(c));
goto nf_label_2;
nf_label_2:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=2 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,2,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
NF_TRY(nvm_file_runtime_frame_store(c));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_3;
nf_label_3:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=3 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,3,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);
NF_TRY(nvm_file_runtime_scalar(c,dst,1,nf_bits(UINT64_C(41))));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_4;
nf_label_4:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=4 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,4,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_local(c,0,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);
if(!value.initialized || value.formal || value.owning!=0)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);
NF_TRY(nvm_file_runtime_copy(c,src,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_5;
nf_label_5:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=5 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,5,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
NF_TRY(nvm_file_runtime_frame_call(c));
NF_TRY(nf_function_4(c));
goto nf_label_6;
nf_label_6:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=0 || current.frame.instruction!=6 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),0,6,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
}
static NvmFileRuntimeStatus nf_function_1(NvmFileRuntime *c){
NvmFileIndirectFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;
NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;
uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];
uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;
(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;
(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;
if(0)goto nf_label_0;
if(0)goto nf_label_1;
goto nf_label_0;
nf_label_0:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=1 || current.frame.instruction!=0 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),1,0,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_local(c,0,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);
if(!value.initialized || value.formal || value.owning!=0)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);
NF_TRY(nvm_file_runtime_copy(c,src,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_1;
nf_label_1:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=1 || current.frame.instruction!=1 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),1,1,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
}
static NvmFileRuntimeStatus nf_function_2(NvmFileRuntime *c){
NvmFileIndirectFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;
NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;
uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];
uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;
(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;
(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;
if(0)goto nf_label_0;
if(0)goto nf_label_1;
goto nf_label_0;
nf_label_0:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=2 || current.frame.instruction!=0 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),2,0,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);
NF_TRY(nvm_file_runtime_scalar(c,dst,1,nf_bits(UINT64_C(42))));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_1;
nf_label_1:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=2 || current.frame.instruction!=1 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),2,1,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
}
static NvmFileRuntimeStatus nf_function_3(NvmFileRuntime *c){
NvmFileIndirectFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;
NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;
uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];
uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;
(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;
(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;
if(0)goto nf_label_0;
if(0)goto nf_label_1;
goto nf_label_0;
nf_label_0:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=3 || current.frame.instruction!=0 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),3,0,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_local(c,0,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);
if(!value.initialized || value.formal || value.owning!=0)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);
NF_TRY(nvm_file_runtime_copy(c,src,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_1;
nf_label_1:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=3 || current.frame.instruction!=1 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),3,1,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
}
static NvmFileRuntimeStatus nf_function_4(NvmFileRuntime *c){
NvmFileIndirectFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;
NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;
uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];
uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;
(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;
(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;
if(0)goto nf_label_0;
if(0)goto nf_label_1;
if(0)goto nf_label_2;
if(0)goto nf_label_3;
goto nf_label_0;
nf_label_0:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=4 || current.frame.instruction!=0 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),4,0,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_local(c,0,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);
if(!value.initialized || value.formal || value.owning!=0)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);
NF_TRY(nvm_file_runtime_copy(c,src,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_1;
nf_label_1:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=4 || current.frame.instruction!=1 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),4,1,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_local(c,1,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);
if(!value.initialized || value.formal || value.owning!=0)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);
NF_TRY(nvm_file_runtime_copy(c,src,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_2;
nf_label_2:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=4 || current.frame.instruction!=2 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),4,2,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
NF_TRY(nvm_file_runtime_frame_call(c));
if(!nvm_file_runtime_indirect_frame_view(c,&current))return nf_bad(c);
switch(current.frame.function){
case 1:NF_TRY(nf_function_1(c));break;
case 2:NF_TRY(nf_function_2(c));break;
default:return nf_bad(c);
}
goto nf_label_3;
nf_label_3:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=4 || current.frame.instruction!=3 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),4,3,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
}
static NvmFileRuntimeStatus nf_function_5(NvmFileRuntime *c){
NvmFileIndirectFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;
NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;
uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];
uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;
(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;
(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;
if(0)goto nf_label_0;
if(0)goto nf_label_1;
if(0)goto nf_label_2;
if(0)goto nf_label_3;
if(0)goto nf_label_4;
if(0)goto nf_label_5;
goto nf_label_0;
nf_label_0:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=5 || current.frame.instruction!=0 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),5,0,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);
NF_TRY(nvm_file_runtime_scalar(c,dst,4,nf_bits(UINT64_C(1))));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_1;
nf_label_1:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=5 || current.frame.instruction!=1 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),5,1,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);
if(!nf_scalar(&value,TAG_BOOL))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);
NF_TRY(nvm_file_runtime_drop(c,src));
edge=(value.values[0]!=0)==0;
NF_TRY(nvm_file_runtime_frame_next(c,edge));
if(edge)goto nf_label_4;
goto nf_label_2;
nf_label_2:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=5 || current.frame.instruction!=2 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),5,2,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);
NF_TRY(nvm_file_runtime_indirect_funcref(c,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_3;
nf_label_3:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=5 || current.frame.instruction!=3 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),5,3,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
nf_label_4:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=5 || current.frame.instruction!=4 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),5,4,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);
NF_TRY(nvm_file_runtime_indirect_funcref(c,dst));
NF_TRY(nvm_file_runtime_frame_next(c,0));
goto nf_label_5;
nf_label_5:
if(!nvm_file_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=5 || current.frame.instruction!=5 || !nvm_file_indirect_hosted_variant(nvm_file_runtime_indirect_plan(c),5,5,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);
f=current.frame;(void)f;NF_TRY(nvm_file_runtime_indirect_enter(c));
return nvm_file_runtime_frame_return(c);
}
NvmFileIndirectExecutionReport nvm_file_native_indirect_execute(const NvmFileIndirectOptions *options,NvmFileRuntimeView *out){
if(!out || !options || options->revision!=NVM_FILE_INDIRECT_RUNTIME_REVISION || options->instruction_limit>NVM_FILE_INDIRECT_FUEL_MAX)return nf_refused(NVM_FILE_RUNTIME_INVALID,options);
if(!nvm_file_runtime_indirect_native_abi(1u,sizeof(NvmFileIndirectOptions),sizeof(NvmFileIndirectExecutionReport),sizeof(NvmFileIndirectFrameView),sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeView)))return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED,options);
NvmFileRuntime *c=NULL;uint32_t root;
NvmFileRuntimeStatus status=nvm_file_runtime_indirect_create(nf_module,sizeof nf_module,NVM_FILE_RUNTIME_NATIVE,options,&c);
if(status!=NVM_FILE_RUNTIME_OK)return nf_refused(status,options);
if(!nf_agrees(nvm_file_runtime_indirect_plan(c))){(void)nvm_file_runtime_indirect_destroy(&c,NULL);return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED,options);}
status=nvm_file_runtime_begin(c);
(void)nf_bits;(void)nf_scalar;
(void)nf_function_0;
(void)nf_function_1;
(void)nf_function_2;
(void)nf_function_3;
(void)nf_function_4;
(void)nf_function_5;
if(status==NVM_FILE_RUNTIME_OK && (!nvm_file_runtime_current_root(c,&root) || root!=0))status=nf_bad(c);
if(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);
if(status==NVM_FILE_RUNTIME_OK)status=nf_function_0(c);
if(status==NVM_FILE_RUNTIME_OK && nvm_file_runtime_current_root(c,&root))status=nf_bad(c);
if(status!=NVM_FILE_RUNTIME_OK)(void)nvm_file_runtime_fail(c,status);
return nvm_file_runtime_indirect_destroy(&c,out);
}
#undef NF_TRY
