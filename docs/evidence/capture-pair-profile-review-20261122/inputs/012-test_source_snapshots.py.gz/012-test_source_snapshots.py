import subprocess,sys,unittest
class SourceSnapshots(unittest.TestCase):
 def test_timeout(self):
  subprocess.run([sys.executable,"-c","import os,time,pathlib;data=bytes([114, 101, 116, 97, 105, 110, 101, 100, 45, 112, 97, 114, 116, 105, 97, 108]);os.write(1,data);pathlib.Path('/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/capture-pair-review-20261122/818d0126b-partial-proof/root/emitted.bin').write_bytes(data);time.sleep(5)"],capture_output=True,timeout=0.2)
