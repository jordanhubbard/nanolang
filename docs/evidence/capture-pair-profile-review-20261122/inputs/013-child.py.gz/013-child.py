
import hashlib,json,os,resource,shutil,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
config=json.loads(Path(sys.argv[1]).read_text());root=Path(config['root']);out=Path(config['output'])
sys.path.insert(0,str(root));os.chdir(root)
native_run=subprocess.run;records=[];fixtures=[]
def cpu():
 r=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime
def observe(argv,**kwargs):
 start=time.monotonic();before=cpu()
 result=native_run(argv,**kwargs)
 records.append({'argv':list(map(str,argv)),'parent_timeout':kwargs.get('timeout'),
  'wall_seconds':time.monotonic()-start,'child_cpu_seconds':cpu()-before,
  'returncode':result.returncode,'stdout':result.stdout.decode(errors='replace') if isinstance(result.stdout,bytes) else result.stdout,
  'stderr':result.stderr.decode(errors='replace') if isinstance(result.stderr,bytes) else result.stderr})
 return result
def retain(self):
 self._finalizer.detach();fixtures.append(self.name)
suite=unittest.defaultTestLoader.loadTestsFromName(config['method']);discovered=suite.countTestCases()
start=time.monotonic();before=cpu()
with (out/'unittest.log').open('w') as log,patch('subprocess.run',side_effect=observe),patch.object(tempfile.TemporaryDirectory,'cleanup',retain):
 result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
elapsed=time.monotonic()-start;used=cpu()-before
for name in fixtures:
 path=Path(name)
 if path.is_dir():shutil.copytree(path,out/'fixtures'/path.name,symlinks=True)
(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
report={'discovered':discovered,'ran':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
 'skipped':[(case.id(),reason) for case,reason in result.skipped], 'wall_seconds':elapsed,'child_cpu_seconds':used,
 'original_method':config['method'],'imported_source':str(sys.modules['tests.test_source_snapshots'].__file__),
 'fixture_paths':fixtures,'scope':'I preserve original assertions and subprocess deadlines. Cleanup-only observation retains original temporary fixture paths.'}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if discovered==result.testsRun==1 and result.wasSuccessful() and not result.skipped else 1)
