from pathlib import Path
import ast,subprocess,json,time,sys
base=Path.cwd()/'.test_output/capture-pair-review-20261122';summary=[]
for version,script in [('919b001b5','/tmp/nanolang-ci-profile-capture-pair-review.py'),('818d0126b','/tmp/nanolang-ci-profile-capture-pair-818-review.py')]:
 tree=ast.parse(Path(script).read_text());child=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CHILD' for t in n.targets))
 case=base/(version+'-partial-proof');root=case/'root';out=case/'observation';(root/'tests').mkdir(parents=True);out.mkdir();(root/'tests/__init__.py').write_text('')
 payload=bytes([114,101,116,97,105,110,101,100,45,112,97,114,116,105,97,108]);emitted=root/'emitted.bin'
 producer='import os,time,pathlib;data=bytes('+repr(list(payload))+');os.write(1,data);pathlib.Path('+repr(str(emitted))+').write_bytes(data);time.sleep(5)'
 (root/'tests/test_source_snapshots.py').write_text('import subprocess,sys,unittest\nclass SourceSnapshots(unittest.TestCase):\n def test_timeout(self):\n  subprocess.run([sys.executable,"-c",'+repr(producer)+'],capture_output=True,timeout=0.2)\n')

 config=case/'config.json';config.write_text(json.dumps(dict(root=str(root),output=str(out),method='tests.test_source_snapshots.SourceSnapshots.test_timeout')))
 (case/'child.py').write_text(child);started=time.monotonic();result=subprocess.run([sys.executable,'-c',child,str(config)],cwd=root,capture_output=True,timeout=10);(case/'parent.stdout').write_bytes(result.stdout);(case/'parent.stderr').write_bytes(result.stderr)
 report=json.loads((out/'result.json').read_text());commands=json.loads((out/'commands.json').read_text());events=[json.loads(line) for line in (out/'commands.jsonl').read_text().splitlines()] if (out/'commands.jsonl').exists() else []
 summary.append(dict(version=version,returncode=result.returncode,seconds=time.monotonic()-started,report=report,command_records=commands,event_count=len(events),stdout_emission_proved=emitted.read_bytes()==payload,partial_stdout_fields_present=any('stdout' in item for item in commands),scope='I execute the exact observer CHILD with a synthetic Python timeout, not a native qualification or original-method rerun.'))
 assert result.returncode==1 and report['errors']==1 and emitted.read_bytes()==payload
 assert not any('stdout' in item or 'stderr' in item for item in commands)
(base/'timeout-retention.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps([{k:v for k,v in s.items() if k not in ['report','command_records']} for s in summary],indent=2))
