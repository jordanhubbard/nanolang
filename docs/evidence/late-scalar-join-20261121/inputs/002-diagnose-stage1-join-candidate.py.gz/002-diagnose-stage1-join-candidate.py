from pathlib import Path
import subprocess,json,hashlib
from tests.native_process import run_captured
R=Path.cwd();D=R/'.test_output/stage1-join-candidate';D.mkdir(exist_ok=True)
p=R/'src/nanoisa/nvm2c.c';s=p.read_text();old='nvm2c_fail(b, "I require stable scalar join facts before shape emission"); return 0;';new='nvm2c_fail(b, "I require stable scalar join facts before shape emission (function %u, target %zu, slot %d, plan 0x%x, actual 0x%x, prior 0x%x, incoming 0x%x)", idx, target, i, plan->tags[i], tags, join->slots[i].scalar_tags, stack[i].scalar_tags); return 0;';assert s.count(old)==1
source=D/'nvm2c.c'
text=s.replace(old,new)
check='                if (facts->final) {\n                    nvm2c_fail(b, "I require stable scalar join facts before shape emission'
replacement='                if (facts->final && !(join->slots[i].kind == NVM2C_VK_VALUE &&\n                        stack[i].kind == NVM2C_VK_VALUE &&\n                        join->slots[i].scalar_tags == tags && stack[i].scalar_tags == tags)) {\n                    nvm2c_fail(b, "I require stable scalar join facts before shape emission'
assert text.count(check)==1
text=text.replace(check,replacement)
anchor='    if (plan && plan->count != sp) {'
trace='    if (idx == 497 && target == 649 && sp > 3) fprintf(stderr, "join-trace final=%d set=%d plan=%x incoming=%x prior=%x\\n", facts->final, join->set, plan ? plan->tags[3] : 0, stack[3].scalar_tags, join->set ? join->slots[3].scalar_tags : 0);\n'
assert text.count(anchor)==1
text=text.replace(anchor,trace+anchor)
a='        if (tags != b->local_scalar_tags[at]) {'
b='        if (facts->final && callee == 497 && tags != b->local_scalar_tags[at]) fprintf(stderr, "parameter-trace caller=%u offset=%zu parameter=%u prior=%x incoming=%x kind=%u\\n", idx, b->classify_offset, i-1, b->local_scalar_tags[at], arg.scalar_tags, arg.kind);\n'
assert text.count(a)==1
source.write_text(text.replace(a,b+a))
commands=[['cc','-Wall','-Wextra','-Werror','-std=c99','-g','-O1','-Isrc','-Isrc/nanoisa','-D_GNU_SOURCE','-c',str(source),'-o',str(D/'nvm2c.o')]]
inputs=subprocess.check_output(['make','-sf','Makefile.gnu','--eval=print-diag-inputs:;@echo $(NVM2C_MAIN_OBJECT) $(NANOISA_OBJECTS) $(NANOISA_UTF8) $(FILE_CLI_OBJECT) $(FILE_PUBLIC_LIBRARY) lib/libnano_socket_runtime.a lib/libnano_services_runtime.a lib/libnano_websocket_runtime.a','print-diag-inputs'],text=True).split()
commands.append(['cc','-o',str(D/'nvm2c'),*[str(D/'nvm2c.o') if x=='obj/nanoisa/nvm2c.o' else x for x in inputs],'-lm','-lcrypto','-lffi','-rdynamic'])
commands.append([str(D/'nvm2c'),'.test_output/service-v2-bootstrap-darwin-retained/nanoc_stage1.nvm','-o',str(D/'stage1.c')])
records=[]
for i,c in enumerate(commands):
 r=run_captured(c,build=True,cwd=R,timeout=600);(D/f'{i}.stdout').write_bytes(r.stdout);(D/f'{i}.stderr').write_bytes(r.stderr);records.append(dict(argv=c,returncode=r.returncode));print(i,r.returncode,r.stderr[-1500:].decode(errors='replace'),flush=True)
 if i<2:assert r.returncode==0
(D/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
