from pathlib import Path
import gzip,hashlib,json,subprocess
B=Path('.test_output');D=Path('docs/evidence/late-scalar-join-20261121');(D/'inputs').mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
for host in ('linux','darwin'):
 log=(B/f'stage1-join-original-{host}.log').read_text();assert '=== 2458 passed, 0 failed ===' in log;assert '3890 passed, 0 failed' in log and '505 passed, 0 failed' in log;assert '\nFAILED' not in log and '\nERROR:' not in log
 log=(B/f'stage1-join-optional-{host}.log').read_text();assert 'Ran 22 tests' in log and '\nOK\n' in log
 log=(B/f'stage1-join-candidate-regression-{host}.log').read_text();assert 'Ran 1 test' in log and '\nOK\n' in log
fixture=Path('tests/nanoisa/fixtures/compiler_stage1_late_scalar_joins.nvm.gz');assert sha(gzip.decompress(fixture.read_bytes()))=='f3b0f758884a6baeec8052c1f946d3ff6bb9a7947fdbf3c308a719098e624d8f'
for name in ('stage1-join-candidate','stage1-join-candidate-darwin-retained'):
 steps=json.loads((B/name/'commands.json').read_text());assert [r['returncode'] for r in steps]==[0,0,0]
old=B/'stage1-join-original-provider.c';old.write_bytes(subprocess.check_output(['git','show','c6b138b80:src/nanoisa/nvm2c.c']))
paths={fixture,Path('src/nanoisa/nvm2c.c'),Path('Makefile.gnu'),Path('tests/test_native_late_scalar_joins.py'),Path(__file__)}
for pattern in ('stage1-join-*','diagnose-stage1-join*'):
 for p in B.glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(f for f in p.rglob('*') if f.is_file())
# I retain input bytes again here so this witness does not depend on another receipt.
paths.add(B/'service-v2-bootstrap-darwin-retained/nanoc_stage1.nvm')
files=[];existing={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);digest=sha(raw);dest=existing.get(digest,D/'inputs'/f'{i:03d}-{p.name}.gz');existing[digest]=dest;dest.write_bytes(packed);files.append(dict(path=str(p),artifact=str(dest.relative_to(D)),sha256=sha(raw),bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(D/'manifest.json').write_text(json.dumps(dict(base_commit='c6b138b80',fixture_sha256=sha(gzip.decompress(fixture.read_bytes())),files=files),indent=2)+'\n')
for r in files:
 data=(D/r['artifact']).read_bytes();assert sha(data)==r['compressed_sha256'] and sha(gzip.decompress(data))==r['sha256']
print(len(files),'files',sum(r['bytes'] for r in files),'raw',sum(p.stat().st_size for p in existing.values()),'compressed unique')
