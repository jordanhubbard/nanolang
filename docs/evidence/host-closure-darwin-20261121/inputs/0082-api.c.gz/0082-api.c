const char *path_basename(const char *s) { (void)s; return "darwin-external-provider-ok"; }
