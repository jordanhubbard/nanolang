#include "/Users/jkh/.worktrees/nanolang/host-closure-20261121/src/nanoisa/host_artifact_digest.h"
int main(int argc,char **argv) { char digest[65]; if(argc!=2||!nano_host_digest_file(argv[1],digest)) return 1; puts(digest); return 0; }
