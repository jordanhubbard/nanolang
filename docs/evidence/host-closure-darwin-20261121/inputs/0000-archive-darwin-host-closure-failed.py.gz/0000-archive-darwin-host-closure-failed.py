from pathlib import Path
import json,gzip,hashlib,sys
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');out=root/'.test_output/preserved-darwin-host-closure-failed-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False);state=json.loads((root/'.test_output/darwin-host-closure/manifest.json').read_text());assert state['status']=='failed' and state['original_bootstrap_guards_unchanged'] and state['host_inputs_unchanged'];paths={Path(__file__).resolve(),root/'.test_output/run-darwin-host-closure.py',root/'.test_output/launch.json',root/'.test_output/transport.json',root/'.test_output/darwin-host-closure-controller.stdout',root/'.test_output/darwin-host-closure-controller.stderr'}
paths.update(p for p in (root/'.test_output/darwin-host-closure').rglob('*') if p.is_file());paths.update(p for p in Path(state['external']).rglob('*') if p.is_file())
for path,digest in state['host_inputs'].items():
 p=Path(path);assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;paths.add(p)
for directory in (root/'.test_output').glob('host-artifact-deployment-*'):
 if directory.is_dir():paths.update(p for p in directory.rglob('*') if p.is_file())
sha=lambda b:hashlib.sha256(b).hexdigest();seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw)
 if h not in seen:
  artifact=f'inputs/{i:04d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=artifact
 packed=(out/seen[h]).read_bytes();entries.append(dict(path=str(p),artifact=seen[h],bytes=len(raw),sha256=h,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
(out/'manifest.json').write_text(json.dumps(dict(state=state,files=entries),indent=2)+'\n')
for e in entries:
 packed=(out/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(files=len(entries),compressed_bytes=sum((out/p).stat().st_size for p in seen.values()))))
