.import "/Users/jkh/.worktrees/nanolang/host-closure-20261121/.test_output/host-artifact-deployment-r4leu6ul/same provider.dylib" "path_basename" string string
.import_kind 0 artifact
.string input "ignored"
.entry main
.function main 0 0 0 int 1
PUSH_STR input
CALL_EXTERN 0
PRINTLN
PUSH_I64 0
RET
.end
