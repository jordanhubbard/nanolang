#include <stdio.h>
int main(void) { puts("NANOLANG_HOST_V1:not-a-dependency"); return 0; }
