from pathlib import Path
import json,gzip,hashlib,subprocess,sys
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');state=json.loads((root/'.test_output/darwin-host-closure/manifest.json').read_text());controls=json.loads((root/'.test_output/darwin-host-closure-controls-v2/manifest.json').read_text());assert controls['status']=='passed' and controls['original_bootstrap_guards_unchanged'] and controls['host_inputs_unchanged'];out=root/'.test_output/preserved-darwin-host-final-20261121';(out/'qualification-inputs').mkdir(parents=True,exist_ok=False);paths={Path(__file__).resolve()}
for name in ['darwin-host-closure','darwin-host-native-diagnosis','darwin-host-native-wrapper','darwin-host-system-trace','darwin-native-launch-matrix','darwin-native-stdio-matrix','darwin-host-closure-controls','darwin-host-closure-controls-v2','host-closure-cli']:
 paths.update(p for p in (root/'.test_output'/name).rglob('*') if p.is_file())
for name in ['run-darwin-host-closure.py','run-host-closure-cli-v2.py','diagnose-darwin-host-native.py','diagnose-darwin-host-native-wrapper.py','interpose-darwin-native-system.py','probe-darwin-native-launch-matrix.py','probe-darwin-native-stdio-matrix.py','qualify-darwin-host-controls.py','qualify-darwin-host-controls-v2.py','launch.json','transport.json','darwin-host-uninstall.json','host-closure-paired-source-map.json','host-closure-cli.stdout','host-closure-cli.stderr','host-closure-provider-cleanup.stdout','host-closure-provider-cleanup.stderr','darwin-host-closure-controller.stdout','darwin-host-closure-controller.stderr']:
 p=root/'.test_output'/name
 if p.is_file():paths.add(p)
paths.update(p for p in Path(state['external']).rglob('*') if p.is_file())
for directory in (root/'.test_output').glob('host-artifact-deployment-*'):
 if directory.is_dir():paths.update(p for p in directory.rglob('*') if p.is_file())
for path,digest in state['host_inputs'].items():
 p=Path(path);assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;paths.update(q for q in p.parent.rglob('*') if q.is_file())
for name in ['src','src_nano','modules','include','scripts','tests','Makefile.gnu']:
 for file in subprocess.check_output(['git','ls-files',name],cwd=root,text=True).splitlines():
  p=root/file
  if p.is_file():paths.add(p)
for p in (root/'bin').iterdir():
 if p.is_file():paths.add(p)
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');paths.add(frozen/'bin/nanoc_stage1.nvm');paths.add(frozen/'bin/nanoc_bootstrap.json');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));sha=lambda x:hashlib.sha256(x).hexdigest();seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw)
 if h not in seen:
  artifact=f'qualification-inputs/{i:04d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=artifact
 packed=(out/seen[h]).read_bytes();entries.append(dict(path=str(p),artifact=seen[h],bytes=len(raw),sha256=h,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
manifest=dict(pin=state['pin'],initial_failure=state,corrected_controls=controls,paired_source_files=len(json.loads((root/'.test_output/host-closure-paired-source-map.json').read_text())['files']),files=entries,limits=['I preserve the original failed archive separately and do not mutate its manifest. An eight-cell direct-cc/NanoLang stdio-location matrix demonstrates a collector-induced refusal under the source-denial policy. Corrected pipe collection retains exact compiler selection, product commands, all source denials and original deadlines. I qualify deployment at this source pin using the actual older qualified raw Stage1 and exact host bytes; no new raw bootstrap/final release is claimed. Temporary products deleted by their original tests are not retained.'])
(out/'qualification-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for e in entries:
 packed=(out/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum((out/p).stat().st_size for p in seen.values()),paired_source_files=manifest['paired_source_files'])))
