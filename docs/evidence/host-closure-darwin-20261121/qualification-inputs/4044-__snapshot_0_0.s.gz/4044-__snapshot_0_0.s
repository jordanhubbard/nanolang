	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nanoisa_load_bytes             ; -- Begin function nanoisa_load_bytes
	.p2align	2
_nanoisa_load_bytes:                    ; @nanoisa_load_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #640
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #336
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #16]
	str	w1, [sp, #348]
	str	x2, [x8]
	ldr	x0, [x8]
	bl	_clear_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str@PAGE
	add	x3, x3, l_.str@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_2:
	ldr	w8, [sp, #348]
	subs	w8, w8, #32
	b.hs	LBB0_4
	b	LBB0_3
LBB0_3:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	w8, [sp, #348]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.1@PAGE
	add	x3, x3, l_.str.1@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_4:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #78
	b.ne	LBB0_7
	b	LBB0_5
LBB0_5:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrb	w8, [x8, #1]
	subs	w8, w8, #86
	b.ne	LBB0_7
	b	LBB0_6
LBB0_6:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrb	w8, [x8, #2]
	subs	w8, w8, #77
	b.eq	LBB0_8
	b	LBB0_7
LBB0_7:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.2@PAGE
	add	x3, x3, l_.str.2@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_8:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrb	w8, [x8, #3]
	subs	w8, w8, #2
	b.ne	LBB0_26
	b	LBB0_9
LBB0_9:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	w8, [sp, #348]
	mov	x1, x8
	add	x2, sp, #88
	bl	_nvm_v2_module_deserialize
	str	w0, [sp, #84]
	ldr	w8, [sp, #84]
	cbz	w8, LBB0_11
	b	LBB0_10
LBB0_10:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #84]
	bl	_nvm_v2_result_name
	mov	x8, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.3@PAGE
	add	x3, x3, l_.str.3@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_11:
	add	x1, sp, #72
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #72]
	add	x0, sp, #88
	bl	_nvm_v2_to_nvm_module
	str	w0, [sp, #84]
	ldr	w8, [sp, #84]
	cbnz	w8, LBB0_13
	b	LBB0_12
LBB0_12:
	ldr	x8, [sp, #72]
	cbnz	x8, LBB0_14
	b	LBB0_13
LBB0_13:
	add	x0, sp, #88
	bl	_nvm_v2_module_free
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #84]
	bl	_nvm_v2_result_name
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.4@PAGE
	add	x3, x3, l_.str.4@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_14:
	ldr	w8, [sp, #168]
	cbz	w8, LBB0_16
	b	LBB0_15
LBB0_15:
	ldr	w8, [sp, #168]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB0_17
LBB0_16:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB0_17
LBB0_17:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	mov	x1, #2                          ; =0x2
	bl	_calloc
	str	x0, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB0_19
	b	LBB0_18
LBB0_18:
	add	x0, sp, #88
	bl	_nvm_v2_module_free
	ldr	x0, [sp, #72]
	bl	_nvm_module_free
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	w1, #5                          ; =0x5
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.5@PAGE
	add	x3, x3, l_.str.5@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_19:
	str	wzr, [sp, #60]
	b	LBB0_20
LBB0_20:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	w9, [sp, #168]
	subs	w8, w8, w9
	b.hs	LBB0_23
	b	LBB0_21
LBB0_21:                                ;   in Loop: Header=BB0_20 Depth=1
	ldr	x8, [sp, #160]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w8, [x8, #28]
	ldr	x9, [sp, #64]
	ldr	w10, [sp, #60]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB0_22
LBB0_22:                                ;   in Loop: Header=BB0_20 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB0_20
LBB0_23:
	ldr	x0, [sp, #72]
	ldr	x1, [sp, #64]
	ldr	w2, [sp, #168]
	add	x8, sp, #375
	bl	_nvm_verify_declared_max_stacks
	ldr	x0, [sp, #64]
	bl	_free
	ldrb	w8, [sp, #375]
	tbnz	w8, #0, LBB0_25
	b	LBB0_24
LBB0_24:
	add	x0, sp, #88
	bl	_nvm_v2_module_free
	ldr	x0, [sp, #72]
	bl	_nvm_module_free
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	add	x8, sp, #375
	add	x8, x8, #1
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.6@PAGE
	add	x3, x3, l_.str.6@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_25:
	add	x0, sp, #88
	bl	_nvm_v2_module_free
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]
	str	x8, [x9, #24]
	b	LBB0_29
LBB0_26:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrb	w8, [x8, #3]
	subs	w8, w8, #1
	b.ne	LBB0_28
	b	LBB0_27
LBB0_27:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.7@PAGE
	add	x3, x3, l_.str.7@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_28:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x8, [x8, #16]
	ldrb	w10, [x8, #3]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.8@PAGE
	add	x3, x3, l_.str.8@PAGEOFF
	bl	_set_error
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	b	LBB0_29
LBB0_29:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB0_31
	b	LBB0_30
LBB0_30:
	bl	___stack_chk_fail
LBB0_31:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	sp, sp, #640
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function clear_error
_clear_error:                           ; @clear_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #264                        ; =0x108
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB1_2
LBB1_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function set_error
_set_error:                             ; @set_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	w2, [sp, #16]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	b	LBB2_3
LBB2_2:
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	str	w8, [x9]
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-8]
	str	w8, [x9, #4]
	mov	x9, sp
	add	x8, x29, #16
	str	x8, [x9]
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	ldr	x4, [sp, #8]
	ldr	x5, [sp]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___vsnprintf_chk
	b	LBB2_3
LBB2_3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_save_bytes             ; -- Begin function nanoisa_save_bytes
	.p2align	2
_nanoisa_save_bytes:                    ; @nanoisa_save_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	ldur	x0, [x29, #-48]
	bl	_clear_error
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB3_3
	b	LBB3_2
LBB3_2:
	ldur	x0, [x29, #-48]
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.9@PAGE
	add	x3, x3, l_.str.9@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_13
LBB3_3:
	ldur	x8, [x29, #-40]
	str	wzr, [x8]
	ldur	x0, [x29, #-32]
	add	x1, sp, #72
	bl	_nvm_v2_from_nvm_module
	str	w0, [sp, #68]
	ldr	w8, [sp, #68]
	cbz	w8, LBB3_5
	b	LBB3_4
LBB3_4:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #68]
	bl	_nvm_v2_result_name
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #5                          ; =0x5
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.10@PAGE
	add	x3, x3, l_.str.10@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_13
LBB3_5:
	add	x3, sp, #56
	mov	x2, #0                          ; =0x0
	str	xzr, [sp, #56]
	add	x0, sp, #72
	mov	x1, #0                          ; =0x0
	bl	_nvm_v2_module_serialize
	str	w0, [sp, #68]
	ldr	w8, [sp, #68]
	cbnz	w8, LBB3_7
	b	LBB3_6
LBB3_6:
	ldr	x8, [sp, #56]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB3_8
	b	LBB3_7
LBB3_7:
	add	x0, sp, #72
	bl	_nvm_v2_module_free
	ldur	x0, [x29, #-48]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.11@PAGE
	add	x3, x3, l_.str.11@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_13
LBB3_8:
	ldr	x0, [sp, #56]
	bl	_malloc
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB3_10
	b	LBB3_9
LBB3_9:
	add	x0, sp, #72
	bl	_nvm_v2_module_free
	ldur	x0, [x29, #-48]
	mov	w1, #5                          ; =0x5
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.12@PAGE
	add	x3, x3, l_.str.12@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_13
LBB3_10:
	add	x3, sp, #40
	str	xzr, [sp, #40]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #56]
	add	x0, sp, #72
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_v2_module_serialize
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	str	w8, [sp, #68]
	bl	_nvm_v2_module_free
	ldr	w8, [sp, #68]
	cbz	w8, LBB3_12
	b	LBB3_11
LBB3_11:
	ldr	x0, [sp, #48]
	bl	_free
	ldur	x8, [x29, #-48]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #68]
	bl	_nvm_v2_result_name
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.13@PAGE
	add	x3, x3, l_.str.13@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_13
LBB3_12:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-40]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9]
	ldr	x8, [sp, #48]
	stur	x8, [x29, #-24]
	b	LBB3_13
LBB3_13:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_load_file              ; -- Begin function nanoisa_load_file
	.p2align	2
_nanoisa_load_file:                     ; @nanoisa_load_file
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-24]
	bl	_clear_error
	ldur	x8, [x29, #-16]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	cbnz	w8, LBB4_3
	b	LBB4_2
LBB4_2:
	ldur	x0, [x29, #-24]
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.14@PAGE
	add	x3, x3, l_.str.14@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_3:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.15@PAGE
	add	x1, x1, l_.str.15@PAGEOFF
	bl	_fopen
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB4_5
	b	LBB4_4
LBB4_4:
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.16@PAGE
	add	x3, x3, l_.str.16@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_5:
	ldur	x0, [x29, #-32]
	mov	x1, #0                          ; =0x0
	mov	w2, #2                          ; =0x2
	bl	_fseek
	cbz	w0, LBB4_7
	b	LBB4_6
LBB4_6:
	ldur	x0, [x29, #-32]
	bl	_fclose
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.17@PAGE
	add	x3, x3, l_.str.17@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_7:
	ldur	x0, [x29, #-32]
	bl	_ftell
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	subs	x8, x8, #0
	b.le	LBB4_9
	b	LBB4_8
LBB4_8:
	ldr	x8, [sp, #40]
	mov	x9, #104857600                  ; =0x6400000
	subs	x8, x8, x9
	b.ls	LBB4_10
	b	LBB4_9
LBB4_9:
	ldur	x0, [x29, #-32]
	bl	_fclose
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.18@PAGE
	add	x3, x3, l_.str.18@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_10:
	ldur	x0, [x29, #-32]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_fseek
	cbz	w0, LBB4_12
	b	LBB4_11
LBB4_11:
	ldur	x0, [x29, #-32]
	bl	_fclose
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.17@PAGE
	add	x3, x3, l_.str.17@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_12:
	ldr	x0, [sp, #40]
	bl	_malloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB4_14
	b	LBB4_13
LBB4_13:
	ldur	x0, [x29, #-32]
	bl	_fclose
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #5                          ; =0x5
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.19@PAGE
	add	x3, x3, l_.str.19@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_14:
	ldr	x0, [sp, #32]
	ldr	x2, [sp, #40]
	ldur	x3, [x29, #-32]
	mov	x1, #1                          ; =0x1
	bl	_fread
	str	x0, [sp, #24]
	ldur	x0, [x29, #-32]
	bl	_fclose
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.eq	LBB4_16
	b	LBB4_15
LBB4_15:
	ldr	x0, [sp, #32]
	bl	_free
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.20@PAGE
	add	x3, x3, l_.str.20@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_17
LBB4_16:
	ldr	x0, [sp, #32]
	ldr	x8, [sp, #40]
	mov	x1, x8
	ldur	x2, [x29, #-24]
	bl	_nanoisa_load_bytes
	str	x0, [sp, #16]
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB4_17
LBB4_17:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_save_bytes_v1          ; -- Begin function nanoisa_save_bytes_v1
	.p2align	2
_nanoisa_save_bytes_v1:                 ; @nanoisa_save_bytes_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_clear_error
	ldur	x8, [x29, #-16]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB5_3
	b	LBB5_2
LBB5_2:
	ldr	x0, [sp, #16]
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.9@PAGE
	add	x3, x3, l_.str.9@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_8
LBB5_3:
	ldr	x8, [sp, #24]
	str	wzr, [x8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #368]
	cbz	w8, LBB5_5
	b	LBB5_4
LBB5_4:
	ldr	x0, [sp, #16]
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.21@PAGE
	add	x3, x3, l_.str.21@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_8
LBB5_5:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	bl	_nvm_serialize
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB5_7
	b	LBB5_6
LBB5_6:
	ldr	x0, [sp, #16]
	mov	w1, #5                          ; =0x5
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.22@PAGE
	add	x3, x3, l_.str.22@PAGEOFF
	bl	_set_error
	b	LBB5_7
LBB5_7:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB5_8
LBB5_8:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_save_file              ; -- Begin function nanoisa_save_file
	.p2align	2
_nanoisa_save_file:                     ; @nanoisa_save_file
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x0, [x29, #-32]
	bl	_clear_error
	ldur	x8, [x29, #-24]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldur	x8, [x29, #-24]
	ldrsb	w8, [x8]
	cbnz	w8, LBB6_3
	b	LBB6_2
LBB6_2:
	ldur	x0, [x29, #-32]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #24]                   ; 4-byte Folded Spill
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.14@PAGE
	add	x3, x3, l_.str.14@PAGEOFF
	bl	_set_error
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB6_14
LBB6_3:
	sub	x1, x29, #36
	stur	wzr, [x29, #-36]
	ldur	x0, [x29, #-16]
	ldur	x2, [x29, #-32]
	bl	_nanoisa_save_bytes
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_8
	b	LBB6_4
LBB6_4:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB6_6
	b	LBB6_5
LBB6_5:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB6_7
LBB6_6:
	mov	w8, #5                          ; =0x5
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB6_7
LBB6_7:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB6_14
LBB6_8:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.23@PAGE
	add	x1, x1, l_.str.23@PAGEOFF
	bl	_fopen
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB6_10
	b	LBB6_9
LBB6_9:
	ldr	x0, [sp, #48]
	bl	_free
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.24@PAGE
	add	x3, x3, l_.str.24@PAGEOFF
	bl	_set_error
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB6_14
LBB6_10:
	ldr	x0, [sp, #48]
	ldur	w8, [x29, #-36]
	mov	x2, x8
	ldr	x3, [sp, #40]
	mov	x1, #1                          ; =0x1
	bl	_fwrite
	str	x0, [sp, #32]
	ldr	x0, [sp, #40]
	bl	_fclose
	str	w0, [sp, #28]
	ldr	x0, [sp, #48]
	bl	_free
	ldr	x8, [sp, #32]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB6_12
	b	LBB6_11
LBB6_11:
	ldr	w8, [sp, #28]
	cbz	w8, LBB6_13
	b	LBB6_12
LBB6_12:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	mov	x9, sp
	str	x8, [x9]
	mov	w1, #2                          ; =0x2
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.25@PAGE
	add	x3, x3, l_.str.25@PAGEOFF
	bl	_set_error
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB6_14
LBB6_13:
	stur	wzr, [x29, #-4]
	b	LBB6_14
LBB6_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_assemble_text          ; -- Begin function nanoisa_assemble_text
	.p2align	2
_nanoisa_assemble_text:                 ; @nanoisa_assemble_text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x0, [sp, #24]
	bl	_clear_error
	ldr	x8, [sp, #32]
	cbnz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x0, [sp, #24]
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.26@PAGE
	add	x3, x3, l_.str.26@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	b	LBB7_3
LBB7_2:
	add	x0, sp, #48
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x1, #264                        ; =0x108
	bl	_bzero
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #32]
	bl	_asm_assemble
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]
	bl	_map_assembly_result
	str	x0, [sp, #40]
	b	LBB7_3
LBB7_3:
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB7_5
	b	LBB7_4
LBB7_4:
	bl	___stack_chk_fail
LBB7_5:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_assembly_result
_map_assembly_result:                   ; @map_assembly_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB8_5
	b	LBB8_1
LBB8_1:
	ldur	x8, [x29, #-16]
	ldr	w10, [x8]
	mov	w9, #4                          ; =0x4
	mov	w8, #5                          ; =0x5
	subs	w10, w10, #8
	csel	w8, w8, w9, eq
	stur	w8, [x29, #-28]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	w8, [x29, #-28]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #4]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8, #8]
	cbz	w8, LBB8_3
	b	LBB8_2
LBB8_2:
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_3:
	adrp	x8, l_.str.56@PAGE
	add	x8, x8, l_.str.56@PAGEOFF
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_4:
	ldr	w2, [sp, #32]                   ; 4-byte Folded Reload
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x3, l_.str.55@PAGE
	add	x3, x3, l_.str.55@PAGEOFF
	bl	_set_error
	b	LBB8_5
LBB8_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_assemble_file          ; -- Begin function nanoisa_assemble_file
	.p2align	2
_nanoisa_assemble_file:                 ; @nanoisa_assemble_file
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x0, [sp, #24]
	bl	_clear_error
	ldr	x8, [sp, #32]
	cbz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #32]
	ldrsb	w8, [x8]
	cbnz	w8, LBB9_3
	b	LBB9_2
LBB9_2:
	ldr	x0, [sp, #24]
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.27@PAGE
	add	x3, x3, l_.str.27@PAGEOFF
	bl	_set_error
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	b	LBB9_4
LBB9_3:
	add	x0, sp, #48
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x1, #264                        ; =0x108
	bl	_bzero
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #32]
	bl	_asm_assemble_file
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]
	bl	_map_assembly_result
	str	x0, [sp, #40]
	b	LBB9_4
LBB9_4:
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB9_6
	b	LBB9_5
LBB9_5:
	bl	___stack_chk_fail
LBB9_6:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_print                  ; -- Begin function nanoisa_print
	.p2align	2
_nanoisa_print:                         ; @nanoisa_print
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	LBB10_3
LBB10_2:
	ldr	x0, [sp]
	mov	w1, #1                          ; =0x1
	bl	_disasm_module_styled
	str	x0, [sp, #8]
	b	LBB10_3
LBB10_3:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nanoisa_pretty_print           ; -- Begin function nanoisa_pretty_print
	.p2align	2
_nanoisa_pretty_print:                  ; @nanoisa_pretty_print
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB11_2
	b	LBB11_1
LBB11_1:
	ldur	x0, [x29, #-32]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB11_3
	b	LBB11_2
LBB11_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB11_32
LBB11_3:
	sub	x0, x29, #40
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-40]
	sub	x1, x29, #48
	stur	xzr, [x29, #-48]
	bl	_open_memstream
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB11_5
	b	LBB11_4
LBB11_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB11_32
LBB11_5:
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.28@PAGE
	add	x1, x1, l_.str.28@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.29@PAGE
	add	x1, x1, l_.str.29@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.30@PAGE
	add	x1, x1, l_.str.30@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.31@PAGE
	add	x1, x1, l_.str.31@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.32@PAGE
	add	x1, x1, l_.str.32@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #248]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.33@PAGE
	add	x1, x1, l_.str.33@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #384]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.34@PAGE
	add	x1, x1, l_.str.34@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.35@PAGE
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_fprintf
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #224]
	subs	w8, w8, #0
	b.ls	LBB11_11
	b	LBB11_6
LBB11_6:
	stur	wzr, [x29, #-60]
	b	LBB11_7
LBB11_7:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-60]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #224]
	subs	w8, w8, w9
	b.hs	LBB11_10
	b	LBB11_8
LBB11_8:                                ;   in Loop: Header=BB11_7 Depth=1
	ldur	x8, [x29, #-32]
	add	x10, x8, #32
	ldur	w8, [x29, #-60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-136]                ; 8-byte Folded Spill
	ldur	w8, [x29, #-60]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-144]                ; 8-byte Folded Spill
	ldur	x8, [x29, #-72]
	ldr	w0, [x8]
	bl	_section_name
	ldur	x12, [x29, #-144]               ; 8-byte Folded Reload
	mov	x11, x0
	ldur	x0, [x29, #-136]                ; 8-byte Folded Reload
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #4]
	mov	x10, x8
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x12, [x9]
	str	x11, [x9, #8]
	str	x10, [x9, #16]
	str	x8, [x9, #24]
	adrp	x1, l_.str.36@PAGE
	add	x1, x1, l_.str.36@PAGEOFF
	bl	_fprintf
	b	LBB11_9
LBB11_9:                                ;   in Loop: Header=BB11_7 Depth=1
	ldur	w8, [x29, #-60]
	add	w8, w8, #1
	stur	w8, [x29, #-60]
	b	LBB11_7
LBB11_10:
	b	LBB11_12
LBB11_11:
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-160]                ; 8-byte Folded Spill
	ldur	x0, [x29, #-32]
	bl	_logical_string_size
	mov	x2, x0
	ldur	x0, [x29, #-160]                ; 8-byte Folded Reload
	adrp	x1, l_.str.37@PAGE
	add	x1, x1, l_.str.37@PAGEOFF
	bl	_print_logical_section
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w2, [x8, #288]
	adrp	x1, l_.str.38@PAGE
	add	x1, x1, l_.str.38@PAGEOFF
	bl	_print_logical_section
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #272]
	mov	w9, #20                         ; =0x14
	mul	w2, w8, w9
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_print_logical_section
	ldur	x0, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #384]
	mov	w9, #12                         ; =0xc
	mul	w2, w8, w9
	adrp	x1, l_.str.40@PAGE
	add	x1, x1, l_.str.40@PAGEOFF
	bl	_print_logical_section
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-152]                ; 8-byte Folded Spill
	ldur	x0, [x29, #-32]
	bl	_logical_import_size
	mov	x2, x0
	ldur	x0, [x29, #-152]                ; 8-byte Folded Reload
	adrp	x1, l_.str.41@PAGE
	add	x1, x1, l_.str.41@PAGEOFF
	bl	_print_logical_section
	b	LBB11_12
LBB11_12:
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.42@PAGE
	add	x1, x1, l_.str.42@PAGEOFF
	bl	_fprintf
	stur	wzr, [x29, #-76]
	b	LBB11_13
LBB11_13:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-76]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB11_19
	b	LBB11_14
LBB11_14:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-88]
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-88]
	ldr	w1, [x8]
	bl	_nvm_get_string
	stur	x0, [x29, #-96]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	ldur	w8, [x29, #-76]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-96]
	cbz	x8, LBB11_16
	b	LBB11_15
LBB11_15:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	x8, [x29, #-96]
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	b	LBB11_17
LBB11_16:                               ;   in Loop: Header=BB11_13 Depth=1
	adrp	x8, l_.str.44@PAGE
	add	x8, x8, l_.str.44@PAGEOFF
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	b	LBB11_17
LBB11_17:                               ;   in Loop: Header=BB11_13 Depth=1
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-88]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #132]                  ; 4-byte Folded Spill
	ldur	x8, [x29, #-88]
	ldrh	w8, [x8, #16]
	str	w8, [sp, #136]                  ; 4-byte Folded Spill
	ldur	x8, [x29, #-88]
	ldrh	w8, [x8, #18]
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	ldur	x8, [x29, #-88]
	ldrb	w0, [x8, #20]
	bl	_isa_tag_name
	ldr	x17, [sp, #168]                 ; 8-byte Folded Reload
	ldr	x13, [sp, #120]                 ; 8-byte Folded Reload
	ldr	w16, [sp, #132]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #136]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #140]                 ; 4-byte Folded Reload
	mov	x11, x0
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
	ldur	x8, [x29, #-88]
	ldrb	w12, [x8, #21]
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #8]
	mov	x10, x8
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x9, [sp, #144]                  ; 8-byte Folded Spill
	str	x17, [x9]
	str	x13, [x9, #8]
                                        ; implicit-def: $x13
	mov	x13, x16
	str	x13, [x9, #16]
                                        ; implicit-def: $x13
	mov	x13, x15
	str	x13, [x9, #24]
                                        ; implicit-def: $x13
	mov	x13, x14
	str	x13, [x9, #32]
	str	x11, [x9, #40]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x9, #48]
	str	x10, [x9, #56]
	str	x8, [x9, #64]
	adrp	x1, l_.str.43@PAGE
	add	x1, x1, l_.str.43@PAGEOFF
	bl	_fprintf
	b	LBB11_18
LBB11_18:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	w8, [x29, #-76]
	add	w8, w8, #1
	stur	w8, [x29, #-76]
	b	LBB11_13
LBB11_19:
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.45@PAGE
	add	x1, x1, l_.str.45@PAGEOFF
	bl	_fprintf
	stur	wzr, [x29, #-100]
	b	LBB11_20
LBB11_20:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-100]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB11_29
	b	LBB11_21
LBB11_21:                               ;   in Loop: Header=BB11_20 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-100]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-112]
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-112]
	ldr	w1, [x8]
	bl	_nvm_get_string
	stur	x0, [x29, #-120]
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-112]
	ldr	w1, [x8, #4]
	bl	_nvm_get_string
	stur	x0, [x29, #-128]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	ldur	w8, [x29, #-100]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-120]
	cbz	x8, LBB11_23
	b	LBB11_22
LBB11_22:                               ;   in Loop: Header=BB11_20 Depth=1
	ldur	x8, [x29, #-120]
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	b	LBB11_24
LBB11_23:                               ;   in Loop: Header=BB11_20 Depth=1
	adrp	x8, l_.str.47@PAGE
	add	x8, x8, l_.str.47@PAGEOFF
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	b	LBB11_24
LBB11_24:                               ;   in Loop: Header=BB11_20 Depth=1
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-128]
	cbz	x8, LBB11_26
	b	LBB11_25
LBB11_25:                               ;   in Loop: Header=BB11_20 Depth=1
	ldur	x8, [x29, #-128]
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	b	LBB11_27
LBB11_26:                               ;   in Loop: Header=BB11_20 Depth=1
	adrp	x8, l_.str.44@PAGE
	add	x8, x8, l_.str.44@PAGEOFF
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	b	LBB11_27
LBB11_27:                               ;   in Loop: Header=BB11_20 Depth=1
	ldr	x0, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x12, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x13, [sp, #112]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-112]
	ldrh	w11, [x9, #8]
	ldur	x9, [x29, #-112]
	ldrb	w10, [x9, #10]
	mov	x9, sp
	str	x13, [x9]
	str	x12, [x9, #8]
	str	x8, [x9, #16]
                                        ; implicit-def: $x8
	mov	x8, x11
	str	x8, [x9, #24]
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9, #32]
	adrp	x1, l_.str.46@PAGE
	add	x1, x1, l_.str.46@PAGEOFF
	bl	_fprintf
	b	LBB11_28
LBB11_28:                               ;   in Loop: Header=BB11_20 Depth=1
	ldur	w8, [x29, #-100]
	add	w8, w8, #1
	stur	w8, [x29, #-100]
	b	LBB11_20
LBB11_29:
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.48@PAGE
	add	x1, x1, l_.str.48@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-56]
	bl	_disasm_module_to_file
	ldur	x0, [x29, #-56]
	bl	_fclose
	cbz	w0, LBB11_31
	b	LBB11_30
LBB11_30:
	ldur	x0, [x29, #-40]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB11_32
LBB11_31:
	ldur	x8, [x29, #-40]
	stur	x8, [x29, #-24]
	b	LBB11_32
LBB11_32:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function section_name
_section_name:                          ; @section_name
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	subs	x8, x8, #10
	b.hi	LBB12_13
; %bb.1:
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	adrp	x10, lJTI12_0@PAGE
	add	x10, x10, lJTI12_0@PAGEOFF
Ltmp1:
	adr	x8, Ltmp1
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB12_2:
	adrp	x8, l_.str.38@PAGE
	add	x8, x8, l_.str.38@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_3:
	adrp	x8, l_.str.37@PAGE
	add	x8, x8, l_.str.37@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_4:
	adrp	x8, l_.str.39@PAGE
	add	x8, x8, l_.str.39@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_5:
	adrp	x8, l_.str.57@PAGE
	add	x8, x8, l_.str.57@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_6:
	adrp	x8, l_.str.58@PAGE
	add	x8, x8, l_.str.58@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_7:
	adrp	x8, l_.str.59@PAGE
	add	x8, x8, l_.str.59@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_8:
	adrp	x8, l_.str.60@PAGE
	add	x8, x8, l_.str.60@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_9:
	adrp	x8, l_.str.41@PAGE
	add	x8, x8, l_.str.41@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_10:
	adrp	x8, l_.str.40@PAGE
	add	x8, x8, l_.str.40@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_11:
	adrp	x8, l_.str.61@PAGE
	add	x8, x8, l_.str.61@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_12:
	adrp	x8, l_.str.62@PAGE
	add	x8, x8, l_.str.62@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_13:
	adrp	x8, l_.str.63@PAGE
	add	x8, x8, l_.str.63@PAGEOFF
	str	x8, [sp, #24]
	b	LBB12_14
LBB12_14:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI12_0:
	.long	LBB12_2-Ltmp1
	.long	LBB12_3-Ltmp1
	.long	LBB12_4-Ltmp1
	.long	LBB12_5-Ltmp1
	.long	LBB12_6-Ltmp1
	.long	LBB12_7-Ltmp1
	.long	LBB12_8-Ltmp1
	.long	LBB12_9-Ltmp1
	.long	LBB12_10-Ltmp1
	.long	LBB12_11-Ltmp1
	.long	LBB12_12-Ltmp1
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_logical_section
_print_logical_section:                 ; @print_logical_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	w8, [x29, #-20]
	subs	w8, w8, #0
	b.ls	LBB13_2
	b	LBB13_1
LBB13_1:
	ldur	x0, [x29, #-8]
	ldur	x10, [x29, #-16]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	adrp	x1, l_.str.64@PAGE
	add	x1, x1, l_.str.64@PAGEOFF
	bl	_fprintf
	b	LBB13_2
LBB13_2:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function logical_string_size
_logical_string_size:                   ; @logical_string_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	wzr, [sp, #4]
	str	wzr, [sp]
	b	LBB14_1
LBB14_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB14_4
	b	LBB14_2
LBB14_2:                                ;   in Loop: Header=BB14_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #240]
	ldr	w9, [sp]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	add	w9, w8, #4
	ldr	w8, [sp, #4]
	add	w8, w8, w9
	str	w8, [sp, #4]
	b	LBB14_3
LBB14_3:                                ;   in Loop: Header=BB14_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB14_1
LBB14_4:
	ldr	w0, [sp, #4]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function logical_import_size
_logical_import_size:                   ; @logical_import_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	wzr, [sp, #4]
	str	wzr, [sp]
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB15_4
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x10, [x8, #400]
	ldr	w8, [sp]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	add	w9, w8, #11
	ldr	w8, [sp, #4]
	add	w8, w8, w9
	str	w8, [sp, #4]
	b	LBB15_3
LBB15_3:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB15_1
LBB15_4:
	ldr	w0, [sp, #4]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nanoisa_load_print          ; -- Begin function nl_nanoisa_load_print
	.p2align	2
_nl_nanoisa_load_print:                 ; @nl_nanoisa_load_print
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	ldr	x0, [sp, #32]
	add	x1, sp, #48
	bl	_nanoisa_load_file
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB16_2
	b	LBB16_1
LBB16_1:
	mov	x0, #0                          ; =0x0
	add	x1, sp, #48
	bl	_store_output
	str	x0, [sp, #40]
	b	LBB16_3
LBB16_2:
	ldr	x0, [sp, #24]
	bl	_nanoisa_print
	str	x0, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_nvm_module_free
	ldr	x0, [sp, #16]
	add	x1, sp, #48
	bl	_store_output
	str	x0, [sp, #40]
	b	LBB16_3
LBB16_3:
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB16_5
	b	LBB16_4
LBB16_4:
	bl	___stack_chk_fail
LBB16_5:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function store_output
_store_output:                          ; @store_output
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	adrp	x8, _last_output@PAGE
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x0, [x8, _last_output@PAGEOFF]
	bl	_free
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	str	x8, [x9, _last_output@PAGEOFF]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB17_2
	b	LBB17_1
LBB17_1:
	adrp	x8, _last_error@PAGE
	strb	wzr, [x8, _last_error@PAGEOFF]
	adrp	x8, _last_output@PAGE
	ldr	x8, [x8, _last_output@PAGEOFF]
	stur	x8, [x29, #-8]
	b	LBB17_7
LBB17_2:
	ldr	x8, [sp, #24]
	cbz	x8, LBB17_5
	b	LBB17_3
LBB17_3:
	ldr	x8, [sp, #24]
	ldrsb	w8, [x8, #8]
	cbz	w8, LBB17_5
	b	LBB17_4
LBB17_4:
	ldr	x8, [sp, #24]
	add	x8, x8, #8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB17_6
LBB17_5:
	adrp	x8, l_.str.65@PAGE
	add	x8, x8, l_.str.65@PAGEOFF
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB17_6
LBB17_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x0, _last_error@PAGE
	add	x0, x0, _last_error@PAGEOFF
	mov	x3, #256                        ; =0x100
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.55@PAGE
	add	x4, x4, l_.str.55@PAGEOFF
	bl	___snprintf_chk
	adrp	x8, l_.str.47@PAGE
	add	x8, x8, l_.str.47@PAGEOFF
	stur	x8, [x29, #-8]
	b	LBB17_7
LBB17_7:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nanoisa_load_pretty         ; -- Begin function nl_nanoisa_load_pretty
	.p2align	2
_nl_nanoisa_load_pretty:                ; @nl_nanoisa_load_pretty
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	ldr	x0, [sp, #32]
	add	x1, sp, #48
	bl	_nanoisa_load_file
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB18_2
	b	LBB18_1
LBB18_1:
	mov	x0, #0                          ; =0x0
	add	x1, sp, #48
	bl	_store_output
	str	x0, [sp, #40]
	b	LBB18_3
LBB18_2:
	ldr	x0, [sp, #24]
	bl	_nanoisa_pretty_print
	str	x0, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_nvm_module_free
	ldr	x0, [sp, #16]
	add	x1, sp, #48
	bl	_store_output
	str	x0, [sp, #40]
	b	LBB18_3
LBB18_3:
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB18_5
	b	LBB18_4
LBB18_4:
	bl	___stack_chk_fail
LBB18_5:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nanoisa_assemble_save       ; -- Begin function nl_nanoisa_assemble_save
	.p2align	2
_nl_nanoisa_assemble_save:              ; @nl_nanoisa_assemble_save
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x0, [sp, #32]
	add	x1, sp, #48
	bl	_nanoisa_assemble_file
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB19_2
	b	LBB19_1
LBB19_1:
	mov	x0, #0                          ; =0x0
	add	x1, sp, #48
	bl	_store_output
	ldr	w8, [sp, #48]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #40]
	b	LBB19_6
LBB19_2:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	x2, sp, #48
	bl	_nanoisa_save_file
	str	w0, [sp, #12]
	ldr	x0, [sp, #16]
	bl	_nvm_module_free
	ldr	w8, [sp, #12]
	cbz	w8, LBB19_4
	b	LBB19_3
LBB19_3:
	mov	x0, #0                          ; =0x0
	add	x1, sp, #48
	bl	_store_output
	b	LBB19_5
LBB19_4:
	adrp	x8, _last_error@PAGE
	strb	wzr, [x8, _last_error@PAGEOFF]
	b	LBB19_5
LBB19_5:
	ldrsw	x8, [sp, #12]
	str	x8, [sp, #40]
	b	LBB19_6
LBB19_6:
	ldr	x8, [sp, #40]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB19_8
	b	LBB19_7
LBB19_7:
	bl	___stack_chk_fail
LBB19_8:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nanoisa_assemble_text_save  ; -- Begin function nl_nanoisa_assemble_text_save
	.p2align	2
_nl_nanoisa_assemble_text_save:         ; @nl_nanoisa_assemble_text_save
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #720
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #168]
	str	x1, [sp, #160]
	add	x0, sp, #448
	bl	_clear_error
	ldr	x8, [sp, #160]
	cbz	x8, LBB20_2
	b	LBB20_1
LBB20_1:
	ldr	x8, [sp, #160]
	ldrb	w8, [x8]
	cbnz	w8, LBB20_3
	b	LBB20_2
LBB20_2:
	add	x0, sp, #448
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.49@PAGE
	add	x3, x3, l_.str.49@PAGEOFF
	bl	_set_error
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	mov	x0, #0                          ; =0x0
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_3:
	ldr	x0, [sp, #168]
	add	x1, sp, #448
	bl	_nanoisa_assemble_text
	str	x0, [sp, #152]
	ldr	x8, [sp, #152]
	cbnz	x8, LBB20_5
	b	LBB20_4
LBB20_4:
	mov	x0, #0                          ; =0x0
	add	x1, sp, #448
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_5:
	ldr	x0, [sp, #152]
	add	x8, sp, #191
	bl	_nvm_verify
	ldrb	w8, [sp, #191]
	tbnz	w8, #0, LBB20_7
	b	LBB20_6
LBB20_6:
	add	x8, sp, #191
	add	x8, x8, #1
	mov	x9, sp
	str	x8, [x9]
	add	x0, sp, #448
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	mov	w1, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.50@PAGE
	add	x3, x3, l_.str.50@PAGEOFF
	bl	_set_error
	ldr	x0, [sp, #152]
	bl	_nvm_module_free
	ldr	x1, [sp, #80]                   ; 8-byte Folded Reload
	mov	x0, #0                          ; =0x0
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_7:
	add	x1, sp, #148
	str	wzr, [sp, #148]
	ldr	x0, [sp, #152]
	add	x2, sp, #448
	bl	_nanoisa_save_bytes
	str	x0, [sp, #136]
	ldr	x0, [sp, #152]
	bl	_nvm_module_free
	ldr	x8, [sp, #136]
	cbnz	x8, LBB20_9
	b	LBB20_8
LBB20_8:
	mov	x0, #0                          ; =0x0
	add	x1, sp, #448
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_9:
	ldr	x0, [sp, #160]
	bl	_strlen
	str	x0, [sp, #128]
	ldr	x8, [sp, #128]
	adds	x8, x8, #13
	b.ls	LBB20_11
	b	LBB20_10
LBB20_10:
	ldr	x0, [sp, #136]
	bl	_free
	add	x0, sp, #448
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.51@PAGE
	add	x3, x3, l_.str.51@PAGEOFF
	bl	_set_error
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	mov	x0, #0                          ; =0x0
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_11:
	ldr	x8, [sp, #128]
	add	x0, x8, #12
	bl	_malloc
	str	x0, [sp, #120]
	ldr	x8, [sp, #120]
	cbnz	x8, LBB20_13
	b	LBB20_12
LBB20_12:
	ldr	x0, [sp, #136]
	bl	_free
	add	x0, sp, #448
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	mov	w1, #5                          ; =0x5
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.52@PAGE
	add	x3, x3, l_.str.52@PAGEOFF
	bl	_set_error
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	mov	x0, #0                          ; =0x0
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_13:
	ldr	x0, [sp, #120]
	ldr	x1, [sp, #160]
	ldr	x2, [sp, #128]
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #56]                   ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #120]
	ldr	x9, [sp, #128]
	add	x0, x8, x9
	adrp	x1, l_.str.53@PAGE
	add	x1, x1, l_.str.53@PAGEOFF
	mov	x2, #12                         ; =0xc
	bl	___memcpy_chk
	ldr	x0, [sp, #120]
	bl	_mkstemp
	str	w0, [sp, #116]
	ldr	w8, [sp, #116]
	tbz	w8, #31, LBB20_15
	b	LBB20_14
LBB20_14:
	bl	___error
	ldr	w8, [x0]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB20_16
LBB20_15:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB20_16
LBB20_16:
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [sp, #112]
	ldr	w8, [sp, #116]
	tbnz	w8, #31, LBB20_40
	b	LBB20_17
LBB20_17:
	str	xzr, [sp, #104]
	b	LBB20_18
LBB20_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #104]
	ldr	w9, [sp, #148]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB20_28
	b	LBB20_19
LBB20_19:                               ;   in Loop: Header=BB20_18 Depth=1
	ldr	w0, [sp, #116]
	ldr	x8, [sp, #136]
	ldr	x9, [sp, #104]
	add	x1, x8, x9
	ldr	w8, [sp, #148]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #104]
	subs	x2, x8, x9
	bl	_write
	str	x0, [sp, #96]
	ldr	x8, [sp, #96]
	tbz	x8, #63, LBB20_22
	b	LBB20_20
LBB20_20:                               ;   in Loop: Header=BB20_18 Depth=1
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #4
	b.ne	LBB20_22
	b	LBB20_21
LBB20_21:                               ;   in Loop: Header=BB20_18 Depth=1
	b	LBB20_18
LBB20_22:                               ;   in Loop: Header=BB20_18 Depth=1
	ldr	x8, [sp, #96]
	subs	x8, x8, #0
	b.gt	LBB20_27
	b	LBB20_23
LBB20_23:
	ldr	x8, [sp, #96]
	tbz	x8, #63, LBB20_25
	b	LBB20_24
LBB20_24:
	bl	___error
	ldr	w8, [x0]
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB20_26
LBB20_25:
	mov	w8, #5                          ; =0x5
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB20_26
LBB20_26:
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	str	w8, [sp, #112]
	b	LBB20_28
LBB20_27:                               ;   in Loop: Header=BB20_18 Depth=1
	ldr	x9, [sp, #96]
	ldr	x8, [sp, #104]
	add	x8, x8, x9
	str	x8, [sp, #104]
	b	LBB20_18
LBB20_28:
	ldr	w8, [sp, #112]
	cbnz	w8, LBB20_31
	b	LBB20_29
LBB20_29:
	ldr	w0, [sp, #116]
	bl	_fsync
	cbz	w0, LBB20_31
	b	LBB20_30
LBB20_30:
	bl	___error
	ldr	w8, [x0]
	str	w8, [sp, #112]
	b	LBB20_31
LBB20_31:
	ldr	w0, [sp, #116]
	bl	_close
	cbz	w0, LBB20_34
	b	LBB20_32
LBB20_32:
	ldr	w8, [sp, #112]
	cbnz	w8, LBB20_34
	b	LBB20_33
LBB20_33:
	bl	___error
	ldr	w8, [x0]
	str	w8, [sp, #112]
	b	LBB20_34
LBB20_34:
	ldr	w8, [sp, #112]
	cbnz	w8, LBB20_37
	b	LBB20_35
LBB20_35:
	ldr	x0, [sp, #120]
	ldr	x1, [sp, #160]
	bl	_rename
	cbz	w0, LBB20_37
	b	LBB20_36
LBB20_36:
	bl	___error
	ldr	w8, [x0]
	str	w8, [sp, #112]
	b	LBB20_37
LBB20_37:
	ldr	w8, [sp, #112]
	cbz	w8, LBB20_39
	b	LBB20_38
LBB20_38:
	ldr	x0, [sp, #120]
	bl	_unlink
	b	LBB20_39
LBB20_39:
	b	LBB20_40
LBB20_40:
	ldr	x0, [sp, #120]
	bl	_free
	ldr	x0, [sp, #136]
	bl	_free
	ldr	w8, [sp, #112]
	cbz	w8, LBB20_42
	b	LBB20_41
LBB20_41:
	ldr	x8, [sp, #160]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #112]
	bl	_strerror
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	x8, sp
	str	x9, [x8]
	str	x0, [x8, #8]
	add	x0, sp, #448
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.54@PAGE
	add	x3, x3, l_.str.54@PAGEOFF
	bl	_set_error
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x0, #0                          ; =0x0
	bl	_store_output
	ldr	w8, [sp, #448]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #176]
	b	LBB20_43
LBB20_42:
	adrp	x8, _last_error@PAGE
	strb	wzr, [x8, _last_error@PAGEOFF]
	str	xzr, [sp, #176]
	b	LBB20_43
LBB20_43:
	ldr	x8, [sp, #176]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB20_45
	b	LBB20_44
LBB20_44:
	bl	___stack_chk_fail
LBB20_45:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	sp, sp, #720
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nanoisa_last_error          ; -- Begin function nl_nanoisa_last_error
	.p2align	2
_nl_nanoisa_last_error:                 ; @nl_nanoisa_last_error
	.cfi_startproc
; %bb.0:
	adrp	x0, _last_error@PAGE
	add	x0, x0, _last_error@PAGEOFF
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nanoisa_array_publication   ; -- Begin function nl_nanoisa_array_publication
	.p2align	2
_nl_nanoisa_array_publication:          ; @nl_nanoisa_array_publication
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1552
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB22_2
	b	LBB22_1
LBB22_1:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #88]
	b	LBB22_27
LBB22_2:
	ldr	x0, [sp, #80]
	mov	x1, #1                          ; =0x1
	movk	x1, #256, lsl #16
	bl	_strnlen
	mov	x8, #16777216                   ; =0x1000000
	subs	x8, x0, x8
	b.ls	LBB22_4
	b	LBB22_3
LBB22_3:
	str	xzr, [sp, #88]
	b	LBB22_27
LBB22_4:
	add	x0, sp, #1280
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x1, #264                        ; =0x108
	bl	_bzero
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #80]
	bl	_asm_assemble_unverified
	str	x0, [sp, #72]
	ldr	x8, [sp, #72]
	cbnz	x8, LBB22_6
	b	LBB22_5
LBB22_5:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #88]
	b	LBB22_27
LBB22_6:
	ldr	x0, [sp, #72]
	bl	_nvm_record_map_route
	str	w0, [sp, #68]
	ldr	w0, [sp, #68]
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB22_16
	b	LBB22_7
LBB22_7:
	ldr	x0, [sp, #72]
	add	x8, sp, #1076
	bl	_nvm_record_map_publication
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #56]
	ldr	w8, [sp, #1076]
	subs	w8, w8, #1
	b.eq	LBB22_9
	b	LBB22_8
LBB22_8:
	ldr	w8, [sp, #1076]
	subs	w8, w8, #3
	b.ne	LBB22_10
	b	LBB22_9
LBB22_9:
	str	xzr, [sp, #56]
	b	LBB22_15
LBB22_10:
	ldr	w8, [sp, #1076]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbnz	w8, LBB22_12
	b	LBB22_11
LBB22_11:
	ldr	x0, [sp, #72]
	add	x8, sp, #819
	bl	_nvm_verify
	ldrb	w8, [sp, #819]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB22_12
LBB22_12:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB22_14
	b	LBB22_13
LBB22_13:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #56]
	b	LBB22_14
LBB22_14:
	b	LBB22_15
LBB22_15:
	ldr	x0, [sp, #72]
	bl	_nvm_module_free
	ldr	x8, [sp, #56]
	str	x8, [sp, #88]
	b	LBB22_27
LBB22_16:
	ldr	x0, [sp, #72]
	bl	_nvm_record_array_candidate
	tbnz	w0, #0, LBB22_18
	b	LBB22_17
LBB22_17:
	ldr	x0, [sp, #72]
	add	x8, sp, #562
	bl	_nvm_verify
	ldrb	w8, [sp, #562]
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	csetm	w9, eq
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	str	x8, [sp, #48]
	ldr	x0, [sp, #72]
	bl	_nvm_module_free
	ldr	x8, [sp, #48]
	str	x8, [sp, #88]
	b	LBB22_27
LBB22_18:
	add	x1, sp, #40
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	ldr	x0, [sp, #72]
	add	x8, sp, #356
	bl	_nvm_record_array_admit
	ldr	x0, [sp, #40]
	bl	_nvm_record_array_execution_free
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #32]
	ldr	w8, [sp, #356]
	subs	w8, w8, #1
	b.eq	LBB22_20
	b	LBB22_19
LBB22_19:
	ldr	w8, [sp, #356]
	subs	w8, w8, #3
	b.ne	LBB22_21
	b	LBB22_20
LBB22_20:
	str	xzr, [sp, #32]
	b	LBB22_26
LBB22_21:
	ldr	w8, [sp, #356]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	w8, LBB22_23
	b	LBB22_22
LBB22_22:
	ldr	x0, [sp, #72]
	add	x8, sp, #99
	bl	_nvm_verify
	ldrb	w8, [sp, #99]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB22_23
LBB22_23:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB22_25
	b	LBB22_24
LBB22_24:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #32]
	b	LBB22_25
LBB22_25:
	b	LBB22_26
LBB22_26:
	ldr	x0, [sp, #72]
	bl	_nvm_module_free
	ldr	x8, [sp, #32]
	str	x8, [sp, #88]
	b	LBB22_27
LBB22_27:
	ldr	x8, [sp, #88]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB22_29
	b	LBB22_28
LBB22_28:
	bl	___stack_chk_fail
LBB22_29:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #1552
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_record_map_selected
_nvm_record_map_selected:               ; @nvm_record_map_selected
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB23_3
	b	LBB23_1
LBB23_1:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB23_3
	b	LBB23_2
LBB23_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB23_3
LBB23_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"NVM data is null"

l_.str.1:                               ; @.str.1
	.asciz	"NVM data is truncated: %u bytes"

l_.str.2:                               ; @.str.2
	.asciz	"Invalid NVM magic"

l_.str.3:                               ; @.str.3
	.asciz	"Invalid NVM v2 module: %s"

l_.str.4:                               ; @.str.4
	.asciz	"NVM v2 module is not expressible as v1: %s"

l_.str.5:                               ; @.str.5
	.asciz	"I could not allocate declared stack depths"

l_.str.6:                               ; @.str.6
	.asciz	"NVM v2 module does not verify: %s"

l_.str.7:                               ; @.str.7
	.asciz	"module was built for NanoISA v1 (NVM\\x01); rebuild it with nanoc 4.0 or later"

l_.str.8:                               ; @.str.8
	.asciz	"Unknown NVM container version %u"

l_.str.9:                               ; @.str.9
	.asciz	"Module and output size are required"

l_.str.10:                              ; @.str.10
	.asciz	"Could not convert module to v2: %s"

l_.str.11:                              ; @.str.11
	.asciz	"Could not size v2 module"

l_.str.12:                              ; @.str.12
	.asciz	"Out of memory"

l_.str.13:                              ; @.str.13
	.asciz	"Could not serialize v2 module: %s"

l_.str.14:                              ; @.str.14
	.asciz	"NVM path is empty"

l_.str.15:                              ; @.str.15
	.asciz	"rb"

l_.str.16:                              ; @.str.16
	.asciz	"Cannot open '%s'"

l_.str.17:                              ; @.str.17
	.asciz	"Cannot seek '%s'"

l_.str.18:                              ; @.str.18
	.asciz	"Invalid NVM file size for '%s'"

l_.str.19:                              ; @.str.19
	.asciz	"Out of memory reading '%s'"

l_.str.20:                              ; @.str.20
	.asciz	"Short read from '%s'"

l_.str.21:                              ; @.str.21
	.asciz	"I require v2 output to preserve advisory metadata"

l_.str.22:                              ; @.str.22
	.asciz	"Could not serialize NVM module"

l_.str.23:                              ; @.str.23
	.asciz	"wb"

l_.str.24:                              ; @.str.24
	.asciz	"Cannot write '%s'"

l_.str.25:                              ; @.str.25
	.asciz	"Short write to '%s'"

l_.str.26:                              ; @.str.26
	.asciz	"Assembly source is null"

l_.str.27:                              ; @.str.27
	.asciz	"Assembly path is empty"

l_.str.28:                              ; @.str.28
	.asciz	"NVM module\n"

l_.str.29:                              ; @.str.29
	.asciz	"  magic: NVM\\x01\n"

l_.str.30:                              ; @.str.30
	.asciz	"  version: %u\n"

l_.str.31:                              ; @.str.31
	.asciz	"  flags: 0x%08x\n"

l_.str.32:                              ; @.str.32
	.asciz	"  entry: %u\n"

l_.str.33:                              ; @.str.33
	.asciz	"  strings: %u\n"

l_.str.34:                              ; @.str.34
	.asciz	"  debug entries: %u\n\n"

l_.str.35:                              ; @.str.35
	.asciz	"Sections\n"

l_.str.36:                              ; @.str.36
	.asciz	"  [%u] %-12s offset=0x%08x size=%u\n"

l_.str.37:                              ; @.str.37
	.asciz	"strings"

l_.str.38:                              ; @.str.38
	.asciz	"code"

l_.str.39:                              ; @.str.39
	.asciz	"functions"

l_.str.40:                              ; @.str.40
	.asciz	"debug"

l_.str.41:                              ; @.str.41
	.asciz	"imports"

l_.str.42:                              ; @.str.42
	.asciz	"\nFunctions\n"

l_.str.43:                              ; @.str.43
	.asciz	"  [%u] %s arity=%u locals=%u upvalues=%u result=%s/%u code=0x%08x+%u\n"

l_.str.44:                              ; @.str.44
	.asciz	"???"

l_.str.45:                              ; @.str.45
	.asciz	"\nImports\n"

l_.str.46:                              ; @.str.46
	.asciz	"  [%u] %s.%s params=%u return=%u\n"

l_.str.47:                              ; @.str.47
	.space	1

l_.str.48:                              ; @.str.48
	.asciz	"\nAssembly\n"

.zerofill __DATA,__bss,_last_error,256,0 ; @last_error
l_.str.49:                              ; @.str.49
	.asciz	"I need a module output path."

l_.str.50:                              ; @.str.50
	.asciz	"I cannot verify the module: %s"

l_.str.51:                              ; @.str.51
	.asciz	"I cannot represent that output path."

l_.str.52:                              ; @.str.52
	.asciz	"I cannot allocate an output path."

l_.str.53:                              ; @.str.53
	.asciz	".tmp.XXXXXX"

l_.str.54:                              ; @.str.54
	.asciz	"I cannot publish '%s': %s"

l_.str.55:                              ; @.str.55
	.asciz	"%s"

l_.str.56:                              ; @.str.56
	.asciz	"NanoISA assembly failed"

l_.str.57:                              ; @.str.57
	.asciz	"structs"

l_.str.58:                              ; @.str.58
	.asciz	"enums"

l_.str.59:                              ; @.str.59
	.asciz	"unions"

l_.str.60:                              ; @.str.60
	.asciz	"globals"

l_.str.61:                              ; @.str.61
	.asciz	"metadata"

l_.str.62:                              ; @.str.62
	.asciz	"module_refs"

l_.str.63:                              ; @.str.63
	.asciz	"unknown"

l_.str.64:                              ; @.str.64
	.asciz	"  [logical] %-12s offset=unserialized size=%u\n"

.zerofill __DATA,__bss,_last_output,8,3 ; @last_output
l_.str.65:                              ; @.str.65
	.asciz	"NanoISA operation failed"

.subsections_via_symbols
