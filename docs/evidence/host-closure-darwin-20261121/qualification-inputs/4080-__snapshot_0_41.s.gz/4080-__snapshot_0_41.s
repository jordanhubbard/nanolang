	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_vm_gc_maybe_collect            ; -- Begin function vm_gc_maybe_collect
	.p2align	2
_vm_gc_maybe_collect:                   ; @vm_gc_maybe_collect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_4
	b	LBB0_1
LBB0_1:
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB0_4
	b	LBB0_2
LBB0_2:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #72]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.lo	LBB0_4
	b	LBB0_3
LBB0_3:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #64]
	cbnz	x8, LBB0_5
	b	LBB0_4
LBB0_4:
	b	LBB0_8
LBB0_5:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #64]
	ldur	x8, [x29, #-8]
	ldr	w1, [x8, #76]
	bl	_cycle_schedule
	str	x0, [sp, #8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	str	x8, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.lo	LBB0_7
	b	LBB0_6
LBB0_6:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.lo	LBB0_8
	b	LBB0_7
LBB0_7:
	ldur	x0, [x29, #-8]
	bl	_vm_gc_collect_cycles
	b	LBB0_8
LBB0_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function cycle_schedule
_cycle_schedule:                        ; @cycle_schedule
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	ldr	x8, [sp, #8]
	cbz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #8]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldr	q0, [x8, x9]
	str	q0, [sp, #16]
	b	LBB1_2
LBB1_2:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_gc_collect_cycles           ; -- Begin function vm_gc_collect_cycles
	.p2align	2
_vm_gc_collect_cycles:                  ; @vm_gc_collect_cycles
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB2_3
	b	LBB2_1
LBB2_1:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #72]
	cbz	w8, LBB2_3
	b	LBB2_2
LBB2_2:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #88]
	tbz	w8, #0, LBB2_4
	b	LBB2_3
LBB2_3:
	stur	xzr, [x29, #-24]
	b	LBB2_63
LBB2_4:
	ldur	x9, [x29, #-32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #88]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #72]
	stur	w8, [x29, #-44]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #76]
	stur	w8, [x29, #-48]
	ldur	x8, [x29, #-32]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #64]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #72]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #76]
	stur	xzr, [x29, #-56]
	stur	wzr, [x29, #-60]
	stur	wzr, [x29, #-64]
	b	LBB2_5
LBB2_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB2_15
	b	LBB2_6
LBB2_6:                                 ;   in Loop: Header=BB2_5 Depth=1
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-64]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	stur	x0, [x29, #-80]
	stur	x1, [x29, #-72]
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	bl	_header_of
	stur	x0, [x29, #-88]
	ldur	x8, [x29, #-88]
	cbnz	x8, LBB2_8
	b	LBB2_7
LBB2_7:                                 ;   in Loop: Header=BB2_5 Depth=1
	b	LBB2_14
LBB2_8:                                 ;   in Loop: Header=BB2_5 Depth=1
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #3
	b.ne	LBB2_11
	b	LBB2_9
LBB2_9:                                 ;   in Loop: Header=BB2_5 Depth=1
	ldur	x8, [x29, #-88]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB2_11
	b	LBB2_10
LBB2_10:                                ;   in Loop: Header=BB2_5 Depth=1
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-64]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-40]
	ldur	w10, [x29, #-60]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	stur	w11, [x29, #-60]
	str	x8, [x9, x10, lsl #3]
	b	LBB2_14
LBB2_11:                                ;   in Loop: Header=BB2_5 Depth=1
	ldur	x8, [x29, #-88]
	strb	wzr, [x8, #6]
	ldur	x8, [x29, #-88]
	ldr	w8, [x8]
	cbnz	w8, LBB2_13
	b	LBB2_12
LBB2_12:                                ;   in Loop: Header=BB2_5 Depth=1
	ldur	x9, [x29, #-88]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x8, x8, #1
	stur	x8, [x29, #-56]
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-80]
	ldur	x2, [x29, #-72]
	bl	_vm_release
	b	LBB2_13
LBB2_13:                                ;   in Loop: Header=BB2_5 Depth=1
	b	LBB2_14
LBB2_14:                                ;   in Loop: Header=BB2_5 Depth=1
	ldur	w8, [x29, #-64]
	add	w8, w8, #1
	stur	w8, [x29, #-64]
	b	LBB2_5
LBB2_15:
	stur	wzr, [x29, #-92]
	b	LBB2_16
LBB2_16:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-92]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB2_19
	b	LBB2_17
LBB2_17:                                ;   in Loop: Header=BB2_16 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-92]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-112]
	stur	x1, [x29, #-104]
	ldur	x1, [x29, #-112]
	ldur	x2, [x29, #-104]
	bl	_mark_gray
	b	LBB2_18
LBB2_18:                                ;   in Loop: Header=BB2_16 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB2_16
LBB2_19:
	stur	wzr, [x29, #-116]
	b	LBB2_20
LBB2_20:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-116]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB2_23
	b	LBB2_21
LBB2_21:                                ;   in Loop: Header=BB2_20 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-116]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-136]
	stur	x1, [x29, #-128]
	ldur	x1, [x29, #-136]
	ldur	x2, [x29, #-128]
	bl	_scan
	b	LBB2_22
LBB2_22:                                ;   in Loop: Header=BB2_20 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB2_20
LBB2_23:
	stur	wzr, [x29, #-140]
	b	LBB2_24
LBB2_24:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-140]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #72]
	subs	w8, w8, w9
	b.hs	LBB2_31
	b	LBB2_25
LBB2_25:                                ;   in Loop: Header=BB2_24 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	ldur	w9, [x29, #-140]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	stur	x0, [x29, #-160]
	stur	x1, [x29, #-152]
	ldur	x0, [x29, #-160]
	ldur	x1, [x29, #-152]
	bl	_header_of
	str	x0, [sp, #168]
	ldr	x8, [sp, #168]
	cbz	x8, LBB2_29
	b	LBB2_26
LBB2_26:                                ;   in Loop: Header=BB2_24 Depth=1
	ldr	x8, [sp, #168]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #1
	b.eq	LBB2_28
	b	LBB2_27
LBB2_27:                                ;   in Loop: Header=BB2_24 Depth=1
	ldr	x8, [sp, #168]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #2
	b.ne	LBB2_29
	b	LBB2_28
LBB2_28:                                ;   in Loop: Header=BB2_24 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-160]
	ldur	x2, [x29, #-152]
	bl	_scan_black
	b	LBB2_29
LBB2_29:                                ;   in Loop: Header=BB2_24 Depth=1
	b	LBB2_30
LBB2_30:                                ;   in Loop: Header=BB2_24 Depth=1
	ldur	w8, [x29, #-140]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	b	LBB2_24
LBB2_31:
	str	wzr, [sp, #164]
	b	LBB2_32
LBB2_32:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #164]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #72]
	subs	w8, w8, w9
	b.hs	LBB2_37
	b	LBB2_33
LBB2_33:                                ;   in Loop: Header=BB2_32 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	ldr	w9, [sp, #164]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #152]
	ldr	x8, [sp, #152]
	cbz	x8, LBB2_35
	b	LBB2_34
LBB2_34:                                ;   in Loop: Header=BB2_32 Depth=1
	ldr	x8, [sp, #152]
	ldr	w10, [x8]
	mov	w9, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
	subs	w10, w10, #0
	csel	w8, w8, w9, hi
	ldr	x9, [sp, #152]
	strb	w8, [x9, #5]
	b	LBB2_35
LBB2_35:                                ;   in Loop: Header=BB2_32 Depth=1
	b	LBB2_36
LBB2_36:                                ;   in Loop: Header=BB2_32 Depth=1
	ldr	w8, [sp, #164]
	add	w8, w8, #1
	str	w8, [sp, #164]
	b	LBB2_32
LBB2_37:
	str	wzr, [sp, #148]
	b	LBB2_38
LBB2_38:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #148]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB2_43
	b	LBB2_39
LBB2_39:                                ;   in Loop: Header=BB2_38 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #148]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #136]
	ldr	x8, [sp, #136]
	cbz	x8, LBB2_41
	b	LBB2_40
LBB2_40:                                ;   in Loop: Header=BB2_38 Depth=1
	ldr	x8, [sp, #136]
	strb	wzr, [x8, #6]
	b	LBB2_41
LBB2_41:                                ;   in Loop: Header=BB2_38 Depth=1
	b	LBB2_42
LBB2_42:                                ;   in Loop: Header=BB2_38 Depth=1
	ldr	w8, [sp, #148]
	add	w8, w8, #1
	str	w8, [sp, #148]
	b	LBB2_38
LBB2_43:
	str	xzr, [sp, #120]
	str	xzr, [sp, #128]
	str	wzr, [sp, #116]
	b	LBB2_44
LBB2_44:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #116]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB2_47
	b	LBB2_45
LBB2_45:                                ;   in Loop: Header=BB2_44 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #116]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #96]
	str	x1, [sp, #104]
	ldr	x1, [sp, #96]
	ldr	x2, [sp, #104]
	add	x3, sp, #120
	bl	_collect_white
	b	LBB2_46
LBB2_46:                                ;   in Loop: Header=BB2_44 Depth=1
	ldr	w8, [sp, #116]
	add	w8, w8, #1
	str	w8, [sp, #116]
	b	LBB2_44
LBB2_47:
	str	wzr, [sp, #92]
	b	LBB2_48
LBB2_48:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #92]
	ldr	w9, [sp, #128]
	subs	w8, w8, w9
	b.hs	LBB2_51
	b	LBB2_49
LBB2_49:                                ;   in Loop: Header=BB2_48 Depth=1
	ldr	x8, [sp, #120]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #80]
	str	xzr, [sp, #64]
	str	xzr, [sp, #72]
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #4]
	strb	w8, [sp, #64]
	ldr	x8, [sp, #120]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #72]
	ldr	x9, [sp, #80]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x8, x8, #1
	stur	x8, [x29, #-56]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #64]
	ldr	x2, [sp, #72]
	bl	_vm_release
	b	LBB2_50
LBB2_50:                                ;   in Loop: Header=BB2_48 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB2_48
LBB2_51:
	ldr	x0, [sp, #120]
	bl	_free
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	cbnz	x8, LBB2_56
	b	LBB2_52
LBB2_52:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	cbz	x8, LBB2_56
	b	LBB2_53
LBB2_53:
	ldur	x0, [x29, #-40]
	mov	x1, #528                        ; =0x210
	bl	_realloc
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbz	x8, LBB2_55
	b	LBB2_54
LBB2_54:
	ldr	x8, [sp, #56]
	stur	x8, [x29, #-40]
	mov	w8, #64                         ; =0x40
	stur	w8, [x29, #-48]
	b	LBB2_55
LBB2_55:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-32]
	str	x8, [x9, #64]
	ldur	w8, [x29, #-48]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #76]
	b	LBB2_57
LBB2_56:
	ldur	x0, [x29, #-40]
	bl	_free
	b	LBB2_57
LBB2_57:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	cbz	x8, LBB2_62
	b	LBB2_58
LBB2_58:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB2_60
	b	LBB2_59
LBB2_59:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB2_61
LBB2_60:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB2_61
LBB2_61:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #48]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	str	x8, [sp, #32]
	ldr	x8, [sp, #48]
	mov	x9, #4                          ; =0x4
	udiv	x8, x8, x9
	str	x8, [sp, #40]
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #64]
	ldur	x8, [x29, #-32]
	ldr	w1, [x8, #76]
	ldr	x2, [sp, #32]
	ldr	x3, [sp, #40]
	bl	_cycle_schedule_store
	b	LBB2_62
LBB2_62:
	ldur	x10, [x29, #-56]
	ldur	x9, [x29, #-32]
	ldr	x8, [x9, #80]
	add	x8, x8, x10
	str	x8, [x9, #80]
	ldur	x8, [x29, #-32]
	strb	wzr, [x8, #88]
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-24]
	b	LBB2_63
LBB2_63:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_gc_note_suspect             ; -- Begin function vm_gc_note_suspect
	.p2align	2
_vm_gc_note_suspect:                    ; @vm_gc_note_suspect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	stur	x0, [x29, #-24]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldurb	w0, [x29, #-16]
	bl	_can_hold_children
	tbnz	w0, #0, LBB3_3
	b	LBB3_2
LBB3_2:
	b	LBB3_23
LBB3_3:
	ldurb	w8, [x29, #-16]
	subs	w8, w8, #7
	b.ne	LBB3_6
	b	LBB3_4
LBB3_4:
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB3_6
	b	LBB3_5
LBB3_5:
	b	LBB3_23
LBB3_6:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #3
	b.ne	LBB3_9
	b	LBB3_7
LBB3_7:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB3_9
	b	LBB3_8
LBB3_8:
	b	LBB3_23
LBB3_9:
	ldur	x9, [x29, #-32]
	mov	w8, #3                          ; =0x3
	strb	w8, [x9, #5]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB3_11
	b	LBB3_10
LBB3_10:
	b	LBB3_23
LBB3_11:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #72]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #76]
	subs	w8, w8, w9
	b.ne	LBB3_22
	b	LBB3_12
LBB3_12:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #76]
	cbz	w8, LBB3_14
	b	LBB3_13
LBB3_13:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #76]
	lsl	w8, w8, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB3_15
LBB3_14:
	mov	w8, #64                         ; =0x40
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB3_15
LBB3_15:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #3
	str	x8, [sp, #32]
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #76]
	subs	w8, w8, w9
	b.ls	LBB3_18
	b	LBB3_16
LBB3_16:
	ldr	x8, [sp, #32]
	mov	x9, #8                          ; =0x8
	udiv	x8, x8, x9
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB3_18
	b	LBB3_17
LBB3_17:
	ldr	x8, [sp, #32]
	adds	x8, x8, #17
	b.ls	LBB3_19
	b	LBB3_18
LBB3_18:
	b	LBB3_23
LBB3_19:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #64]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #76]
	bl	_cycle_schedule
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #64]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #3
	add	x1, x8, #16
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB3_21
	b	LBB3_20
LBB3_20:
	b	LBB3_23
LBB3_21:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #64]
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #76]
	ldr	x0, [sp, #8]
	ldur	w1, [x29, #-36]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #24]
	bl	_cycle_schedule_store
	b	LBB3_22
LBB3_22:
	ldur	x8, [x29, #-8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	ldur	x12, [x29, #-24]
	ldr	w10, [x12, #72]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #72]
	str	x8, [x9, x10, lsl #3]
	ldur	x9, [x29, #-32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #6]
	ldur	x0, [x29, #-24]
	bl	_vm_gc_maybe_collect
	b	LBB3_23
LBB3_23:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function header_of
_header_of:                             ; @header_of
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_val_is_heap_obj
	tbz	w0, #0, LBB4_3
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #24]
	cbz	x8, LBB4_3
	b	LBB4_2
LBB4_2:
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB4_4
LBB4_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB4_4
LBB4_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function can_hold_children
_can_hold_children:                     ; @can_hold_children
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	ldrb	w8, [sp, #14]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	subs	w8, w8, #7
	subs	w8, w8, #1
	b.ls	LBB5_4
	b	LBB5_1
LBB5_1:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB5_4
	b	LBB5_2
LBB5_2:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #12
	subs	w8, w8, #1
	b.ls	LBB5_4
	b	LBB5_3
LBB5_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.ne	LBB5_5
	b	LBB5_4
LBB5_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB5_6
LBB5_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB5_6
LBB5_6:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function cycle_schedule_store
_cycle_schedule_store:                  ; @cycle_schedule_store
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	add	x1, sp, #16
	str	x2, [sp, #16]
	str	x3, [sp, #24]
	str	x0, [sp, #8]
	str	w8, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #3
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function value_from_obj
_value_from_obj:                        ; @value_from_obj
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	ldr	x8, [sp, #8]
	str	x8, [sp]
	ldr	x8, [sp]
	ldrb	w8, [x8, #4]
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_gray
_mark_gray:                             ; @mark_gray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_header_of
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB8_2
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #1
	b.ne	LBB8_3
	b	LBB8_2
LBB8_2:
	b	LBB8_4
LBB8_3:
	ldr	x9, [sp]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #5]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	adrp	x3, _mark_gray_child@PAGE
	add	x3, x3, _mark_gray_child@PAGEOFF
	mov	x4, #0                          ; =0x0
	bl	_for_each_child
	b	LBB8_4
LBB8_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan
_scan:                                  ; @scan
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_header_of
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #1
	b.eq	LBB9_3
	b	LBB9_2
LBB9_2:
	b	LBB9_6
LBB9_3:
	ldr	x8, [sp]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB9_5
	b	LBB9_4
LBB9_4:
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_scan_black
	b	LBB9_6
LBB9_5:
	ldr	x9, [sp]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #5]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	adrp	x3, _scan_child@PAGE
	add	x3, x3, _scan_child@PAGEOFF
	mov	x4, #0                          ; =0x0
	bl	_for_each_child
	b	LBB9_6
LBB9_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan_black
_scan_black:                            ; @scan_black
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_header_of
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	b	LBB10_3
LBB10_2:
	ldr	x8, [sp]
	strb	wzr, [x8, #5]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	adrp	x3, _scan_black_child@PAGE
	add	x3, x3, _scan_black_child@PAGEOFF
	mov	x4, #0                          ; =0x0
	bl	_for_each_child
	b	LBB10_3
LBB10_3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_white
_collect_white:                         ; @collect_white
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB11_3
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #2
	b.ne	LBB11_3
	b	LBB11_2
LBB11_2:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB11_4
	b	LBB11_3
LBB11_3:
	b	LBB11_6
LBB11_4:
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #5]
	ldr	x0, [sp, #24]
	ldr	x4, [sp, #16]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	adrp	x3, _collect_white_slot@PAGE
	add	x3, x3, _collect_white_slot@PAGEOFF
	bl	_for_each_child_slot
	ldr	x0, [sp, #16]
	ldur	x1, [x29, #-8]
	bl	_dead_push
	tbnz	w0, #0, LBB11_6
	b	LBB11_5
LBB11_5:
	ldr	x9, [sp, #8]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #5]
	b	LBB11_6
LBB11_6:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_gc_cycle_buffer_free        ; -- Begin function vm_gc_cycle_buffer_free
	.p2align	2
_vm_gc_cycle_buffer_free:               ; @vm_gc_cycle_buffer_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	b	LBB12_3
LBB12_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #64]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #64]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #72]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #76]
	b	LBB12_3
LBB12_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_is_heap_obj
_val_is_heap_obj:                       ; @val_is_heap_obj
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #5
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_1
LBB13_1:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #6
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_2
LBB13_2:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #7
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_3
LBB13_3:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_4
LBB13_4:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_5
LBB13_5:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #12
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_6
LBB13_6:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #13
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB13_8
	b	LBB13_7
LBB13_7:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #15
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_8
LBB13_8:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function for_each_child
_for_each_child:                        ; @for_each_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x1, [x8]
	str	x2, [x8, #8]
	stur	x0, [x29, #-24]
	stur	x3, [x29, #-32]
	stur	x4, [x29, #-40]
	ldurb	w8, [x29, #-16]
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	subs	w8, w8, #7
	b.eq	LBB14_6
	b	LBB14_1
LBB14_1:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB14_14
	b	LBB14_2
LBB14_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB14_29
	b	LBB14_3
LBB14_3:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #12
	b.eq	LBB14_36
	b	LBB14_4
LBB14_4:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB14_43
	b	LBB14_5
LBB14_5:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.eq	LBB14_53
	b	LBB14_60
LBB14_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB14_8
	b	LBB14_7
LBB14_7:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB14_9
	b	LBB14_8
LBB14_8:
	b	LBB14_61
LBB14_9:
	stur	wzr, [x29, #-52]
	b	LBB14_10
LBB14_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB14_13
	b	LBB14_11
LBB14_11:                               ;   in Loop: Header=BB14_10 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB14_12
LBB14_12:                               ;   in Loop: Header=BB14_10 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB14_10
LBB14_13:
	b	LBB14_61
LBB14_14:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbnz	x8, LBB14_16
	b	LBB14_15
LBB14_15:
	b	LBB14_61
LBB14_16:
	stur	wzr, [x29, #-68]
	b	LBB14_17
LBB14_17:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB14_20
	b	LBB14_18
LBB14_18:                               ;   in Loop: Header=BB14_17 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-68]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB14_19
LBB14_19:                               ;   in Loop: Header=BB14_17 Depth=1
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB14_17
LBB14_20:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	cbz	x8, LBB14_28
	b	LBB14_21
LBB14_21:
	stur	wzr, [x29, #-72]
	b	LBB14_22
LBB14_22:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-72]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB14_27
	b	LBB14_23
LBB14_23:                               ;   in Loop: Header=BB14_22 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB14_25
	b	LBB14_24
LBB14_24:                               ;   in Loop: Header=BB14_22 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_val_string
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	mov	x9, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	stur	x9, [x29, #-88]
	stur	x1, [x29, #-80]
	ldur	x3, [x29, #-40]
	ldur	x1, [x29, #-88]
	ldur	x2, [x29, #-80]
	blr	x8
	b	LBB14_25
LBB14_25:                               ;   in Loop: Header=BB14_22 Depth=1
	b	LBB14_26
LBB14_26:                               ;   in Loop: Header=BB14_22 Depth=1
	ldur	w8, [x29, #-72]
	add	w8, w8, #1
	stur	w8, [x29, #-72]
	b	LBB14_22
LBB14_27:
	b	LBB14_28
LBB14_28:
	b	LBB14_61
LBB14_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #96]
	ldr	x8, [sp, #96]
	cbnz	x8, LBB14_31
	b	LBB14_30
LBB14_30:
	b	LBB14_61
LBB14_31:
	str	wzr, [sp, #92]
	b	LBB14_32
LBB14_32:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #96]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.hs	LBB14_35
	b	LBB14_33
LBB14_33:                               ;   in Loop: Header=BB14_32 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #16]
	ldr	w10, [sp, #92]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB14_34
LBB14_34:                               ;   in Loop: Header=BB14_32 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB14_32
LBB14_35:
	b	LBB14_61
LBB14_36:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB14_38
	b	LBB14_37
LBB14_37:
	b	LBB14_61
LBB14_38:
	str	wzr, [sp, #76]
	b	LBB14_39
LBB14_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldr	x9, [sp, #80]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB14_42
	b	LBB14_40
LBB14_40:                               ;   in Loop: Header=BB14_39 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #80]
	add	x9, x9, #16
	ldr	w10, [sp, #76]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB14_41
LBB14_41:                               ;   in Loop: Header=BB14_39 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB14_39
LBB14_42:
	b	LBB14_61
LBB14_43:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	cbz	x8, LBB14_45
	b	LBB14_44
LBB14_44:
	ldr	x8, [sp, #64]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB14_46
	b	LBB14_45
LBB14_45:
	b	LBB14_61
LBB14_46:
	str	wzr, [sp, #60]
	b	LBB14_47
LBB14_47:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB14_52
	b	LBB14_48
LBB14_48:                               ;   in Loop: Header=BB14_47 Depth=1
	ldr	x8, [sp, #64]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.eq	LBB14_50
	b	LBB14_49
LBB14_49:                               ;   in Loop: Header=BB14_47 Depth=1
	b	LBB14_51
LBB14_50:                               ;   in Loop: Header=BB14_47 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #64]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldur	x3, [x29, #-40]
	ldr	x1, [x9, #8]
	ldr	x2, [x9, #16]
	blr	x8
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #64]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldur	x3, [x29, #-40]
	ldr	x1, [x9, #24]
	ldr	x2, [x9, #32]
	blr	x8
	b	LBB14_51
LBB14_51:                               ;   in Loop: Header=BB14_47 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB14_47
LBB14_52:
	b	LBB14_61
LBB14_53:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB14_55
	b	LBB14_54
LBB14_54:
	b	LBB14_61
LBB14_55:
	strh	wzr, [sp, #46]
	b	LBB14_56
LBB14_56:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB14_59
	b	LBB14_57
LBB14_57:                               ;   in Loop: Header=BB14_56 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #48]
	add	x9, x9, #24
	ldrh	w10, [sp, #46]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB14_58
LBB14_58:                               ;   in Loop: Header=BB14_56 Depth=1
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB14_56
LBB14_59:
	b	LBB14_61
LBB14_60:
	b	LBB14_61
LBB14_61:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_gray_child
_mark_gray_child:                       ; @mark_gray_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB15_2
	b	LBB15_1
LBB15_1:
	b	LBB15_5
LBB15_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB15_4
	b	LBB15_3
LBB15_3:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	b	LBB15_4
LBB15_4:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	bl	_mark_gray
	b	LBB15_5
LBB15_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_string
_val_string:                            ; @val_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #5                          ; =0x5
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan_child
_scan_child:                            ; @scan_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	str	x3, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_scan
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan_black_child
_scan_black_child:                      ; @scan_black_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB18_2
	b	LBB18_1
LBB18_1:
	b	LBB18_4
LBB18_2:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	cbz	w8, LBB18_4
	b	LBB18_3
LBB18_3:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	bl	_scan_black
	b	LBB18_4
LBB18_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function for_each_child_slot
_for_each_child_slot:                   ; @for_each_child_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	x1, [x8]
	str	x2, [x8, #8]
	stur	x0, [x29, #-24]
	stur	x3, [x29, #-32]
	stur	x4, [x29, #-40]
	ldurb	w8, [x29, #-16]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	subs	w8, w8, #7
	b.eq	LBB19_6
	b	LBB19_1
LBB19_1:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB19_14
	b	LBB19_2
LBB19_2:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB19_27
	b	LBB19_3
LBB19_3:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #12
	b.eq	LBB19_34
	b	LBB19_4
LBB19_4:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB19_41
	b	LBB19_5
LBB19_5:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.eq	LBB19_51
	b	LBB19_58
LBB19_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB19_8
	b	LBB19_7
LBB19_7:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB19_9
	b	LBB19_8
LBB19_8:
	b	LBB19_59
LBB19_9:
	stur	wzr, [x29, #-52]
	b	LBB19_10
LBB19_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB19_13
	b	LBB19_11
LBB19_11:                               ;   in Loop: Header=BB19_10 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_12
LBB19_12:                               ;   in Loop: Header=BB19_10 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB19_10
LBB19_13:
	b	LBB19_59
LBB19_14:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbnz	x8, LBB19_16
	b	LBB19_15
LBB19_15:
	b	LBB19_59
LBB19_16:
	stur	wzr, [x29, #-68]
	b	LBB19_17
LBB19_17:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB19_20
	b	LBB19_18
LBB19_18:                               ;   in Loop: Header=BB19_17 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-68]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_19
LBB19_19:                               ;   in Loop: Header=BB19_17 Depth=1
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB19_17
LBB19_20:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	cbz	x8, LBB19_26
	b	LBB19_21
LBB19_21:
	stur	wzr, [x29, #-72]
	b	LBB19_22
LBB19_22:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-72]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB19_25
	b	LBB19_23
LBB19_23:                               ;   in Loop: Header=BB19_22 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_val_string
	mov	x8, x1
	add	x1, sp, #88
	str	x0, [sp, #88]
	str	x8, [sp, #96]
	ldur	x8, [x29, #-64]
	ldr	x9, [x8, #16]
	ldur	w8, [x29, #-72]
	mov	x10, x8
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_24
LBB19_24:                               ;   in Loop: Header=BB19_22 Depth=1
	ldur	w8, [x29, #-72]
	add	w8, w8, #1
	stur	w8, [x29, #-72]
	b	LBB19_22
LBB19_25:
	b	LBB19_26
LBB19_26:
	b	LBB19_59
LBB19_27:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB19_29
	b	LBB19_28
LBB19_28:
	b	LBB19_59
LBB19_29:
	str	wzr, [sp, #76]
	b	LBB19_30
LBB19_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.hs	LBB19_33
	b	LBB19_31
LBB19_31:                               ;   in Loop: Header=BB19_30 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #80]
	ldr	x9, [x9, #16]
	ldr	w10, [sp, #76]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_32
LBB19_32:                               ;   in Loop: Header=BB19_30 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB19_30
LBB19_33:
	b	LBB19_59
LBB19_34:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB19_36
	b	LBB19_35
LBB19_35:
	b	LBB19_59
LBB19_36:
	str	wzr, [sp, #60]
	b	LBB19_37
LBB19_37:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB19_40
	b	LBB19_38
LBB19_38:                               ;   in Loop: Header=BB19_37 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #64]
	add	x9, x9, #16
	ldr	w10, [sp, #60]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_39
LBB19_39:                               ;   in Loop: Header=BB19_37 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB19_37
LBB19_40:
	b	LBB19_59
LBB19_41:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	cbz	x8, LBB19_43
	b	LBB19_42
LBB19_42:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB19_44
	b	LBB19_43
LBB19_43:
	b	LBB19_59
LBB19_44:
	str	wzr, [sp, #44]
	b	LBB19_45
LBB19_45:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB19_50
	b	LBB19_46
LBB19_46:                               ;   in Loop: Header=BB19_45 Depth=1
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.eq	LBB19_48
	b	LBB19_47
LBB19_47:                               ;   in Loop: Header=BB19_45 Depth=1
	b	LBB19_49
LBB19_48:                               ;   in Loop: Header=BB19_45 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #48]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x1, x9, #8
	ldur	x2, [x29, #-40]
	blr	x8
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #48]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x1, x9, #24
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_49
LBB19_49:                               ;   in Loop: Header=BB19_45 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB19_45
LBB19_50:
	b	LBB19_59
LBB19_51:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB19_53
	b	LBB19_52
LBB19_52:
	b	LBB19_59
LBB19_53:
	strh	wzr, [sp, #30]
	b	LBB19_54
LBB19_54:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB19_57
	b	LBB19_55
LBB19_55:                               ;   in Loop: Header=BB19_54 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #32]
	add	x9, x9, #24
	ldrh	w10, [sp, #30]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB19_56
LBB19_56:                               ;   in Loop: Header=BB19_54 Depth=1
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB19_54
LBB19_57:
	b	LBB19_59
LBB19_58:
	b	LBB19_59
LBB19_59:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_white_slot
_collect_white_slot:                    ; @collect_white_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	q0, [x8]
	str	q0, [sp, #32]
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	q0, [sp, #16]
	str	q0, [x8]
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB20_4
	b	LBB20_1
LBB20_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #2
	b.ne	LBB20_4
	b	LBB20_2
LBB20_2:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	cbnz	w8, LBB20_4
	b	LBB20_3
LBB20_3:
	ldur	x0, [x29, #-8]
	ldur	x3, [x29, #-24]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #40]
	bl	_collect_white
	b	LBB20_4
LBB20_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dead_push
_dead_push:                             ; @dead_push
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB21_7
	b	LBB21_1
LBB21_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	cbz	w8, LBB21_3
	b	LBB21_2
LBB21_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	lsl	w8, w8, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB21_4
LBB21_3:
	mov	w8, #32                         ; =0x20
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB21_4
LBB21_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #20]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB21_6
	b	LBB21_5
LBB21_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_8
LBB21_6:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #12]
	b	LBB21_7
LBB21_7:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x10, [x9]
	ldur	x13, [x29, #-16]
	ldr	w9, [x13, #8]
	mov	x11, x9
	mov	x12, x11
	mov	w9, #1                          ; =0x1
	add	w12, w12, #1
	str	w12, [x13, #8]
	str	x8, [x10, x11, lsl #3]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB21_8
LBB21_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_void
_val_void:                              ; @val_void
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	xzr, [sp]
	str	xzr, [sp, #8]
	strb	wzr, [sp]
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
