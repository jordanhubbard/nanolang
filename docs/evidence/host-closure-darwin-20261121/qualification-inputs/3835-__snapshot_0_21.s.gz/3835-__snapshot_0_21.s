	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_execute_indirect_bytes
lCPI0_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_execute_indirect_bytes
	.p2align	2
_nvm_socket_execute_indirect_bytes:     ; @nvm_socket_execute_indirect_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1440
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x19, x8
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w1, #1                          ; =0x1
	mov	w2, #2                          ; =0x2
	bl	_nvm_socket_host_enter
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w0, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w0, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w0, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w8, #4                          ; =0x4
	b	LBB0_10
LBB0_5:
	cbz	w0, LBB0_16
; %bb.6:
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB0_10
LBB0_7:
	mov	w8, #2                          ; =0x2
	b	LBB0_10
LBB0_8:
	mov	x9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	str	q0, [x19, #32]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	mov	w8, #11                         ; =0xb
	b	LBB0_13
LBB0_9:
	mov	w8, #5                          ; =0x5
LBB0_10:
	mov	x9, #0                          ; =0x0
	str	xzr, [x19, #144]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	mov	w10, #1                         ; =0x1
	str	w10, [x19]
	cbz	x21, LBB0_13
; %bb.11:
	cmp	w0, #5
	b.eq	LBB0_13
; %bb.12:
	ldr	x9, [x21, #8]
LBB0_13:
	str	x9, [x19, #128]
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	stur	q0, [x19, #108]
	str	wzr, [x19, #124]
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
LBB0_14:
	ldur	x8, [x29, #-104]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_356
; %bb.15:
	add	sp, sp, #1440
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_16:
	cbz	x21, LBB0_22
; %bb.17:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB0_24
; %bb.18:
	ldr	x8, [x21, #8]
	cbz	x20, LBB0_23
; %bb.19:
	mov	w9, #16961                      ; =0x4241
	movk	w9, #15, lsl #16
	cmp	x8, x9
	b.hs	LBB0_23
; %bb.20:
	add	x24, sp, #352
	ldr	q0, [x21]
	str	q0, [sp, #128]
	str	xzr, [sp, #112]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	str	xzr, [sp, #256]
	add	x3, sp, #128
	add	x4, sp, #256
	mov	x0, x23
	mov	x1, x22
	mov	w2, #0                          ; =0x0
	bl	_nvm_socket_runtime_indirect_create
	cbz	w0, LBB0_27
; %bb.21:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #464]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #432]
	stp	q0, q0, [sp, #400]
	str	q0, [sp, #384]
	ldr	x8, [sp, #136]
	str	xzr, [sp, #496]
	str	x8, [sp, #480]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #352]
	str	w0, [sp, #360]
	b	LBB0_138
LBB0_22:
	mov	x8, #0                          ; =0x0
LBB0_23:
	stp	xzr, xzr, [sp, #352]
	b	LBB0_25
LBB0_24:
	stp	xzr, xzr, [sp, #352]
	ldr	x8, [x21, #8]
LBB0_25:
Lloh6:
	adrp	x9, lCPI0_0@PAGE
Lloh7:
	ldr	d0, [x9, lCPI0_0@PAGEOFF]
	str	d0, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	stur	q0, [x19, #108]
	str	wzr, [x19, #124]
	str	x8, [x19, #128]
	ldr	q0, [sp, #352]
	stur	q0, [x19, #136]
LBB0_26:
	bl	_nvm_socket_host_leave
	b	LBB0_14
LBB0_27:
	ldr	x0, [sp, #256]
	bl	_nvm_socket_runtime_indirect_plan
	mov	x21, x0
	add	x1, sp, #968
	bl	_nvm_socket_indirect_hosted_startup
	cbz	w0, LBB0_137
; %bb.28:
	ldrb	w8, [sp, #1056]
	tbnz	w8, #0, LBB0_137
; %bb.29:
	ldr	w8, [sp, #980]
	cbz	w8, LBB0_132
; %bb.30:
	mov	w22, #0                         ; =0x0
	mov	w26, #415                       ; =0x19f
	mov	w27, #151                       ; =0x97
LBB0_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;       Child Loop BB0_43 Depth 3
                                        ;         Child Loop BB0_75 Depth 4
                                        ;         Child Loop BB0_114 Depth 4
	add	x2, sp, #152
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_function
	cbz	w0, LBB0_137
; %bb.32:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrb	w8, [sp, #232]
	cbnz	w8, LBB0_137
; %bb.33:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrh	w8, [sp, #160]
	cbz	w8, LBB0_131
; %bb.34:                               ;   in Loop: Header=BB0_31 Depth=1
	mov	w28, #0                         ; =0x0
LBB0_35:                                ;   Parent Loop BB0_31 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_43 Depth 3
                                        ;         Child Loop BB0_75 Depth 4
                                        ;         Child Loop BB0_114 Depth 4
	and	w2, w28, #0xffff
	add	x3, sp, #352
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_instruction
	cbz	w0, LBB0_137
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w0, [sp, #360]
	bl	_fcd_supported
	ldrb	w8, [sp, #428]
	cmp	w0, #0
	ccmp	w8, #2, #2, ne
	b.hi	LBB0_137
; %bb.37:                               ;   in Loop: Header=BB0_35 Depth=2
	and	w2, w28, #0xffff
	add	x3, sp, #1092
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_variant_count
	cbz	w0, LBB0_137
; %bb.38:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w8, [sp, #1092]
	cmp	w8, #16
	b.hi	LBB0_137
; %bb.39:                               ;   in Loop: Header=BB0_35 Depth=2
	tst	w28, #0xffff
	b.ne	LBB0_41
; %bb.40:                               ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_137
LBB0_41:                                ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_130
; %bb.42:                               ;   in Loop: Header=BB0_35 Depth=2
	mov	w25, #0                         ; =0x0
LBB0_43:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_75 Depth 4
                                        ;         Child Loop BB0_114 Depth 4
	and	w2, w28, #0xffff
	and	w3, w25, #0xff
	add	x4, sp, #1176
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_variant
	cbz	w0, LBB0_137
; %bb.44:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1196]
	tbz	w8, #0, LBB0_137
; %bb.45:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w23, [sp, #360]
	mov	x0, x23
	bl	_fcd_supported
	cbz	w0, LBB0_137
; %bb.46:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	cmp	w23, #147
	b.gt	LBB0_50
; %bb.47:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #60
	b.gt	LBB0_78
; %bb.48:                               ;   in Loop: Header=BB0_43 Depth=3
	sub	w9, w23, #59
	cmp	w9, #2
	b.lo	LBB0_52
; %bb.49:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #15
	b.eq	LBB0_52
	b	LBB0_53
LBB0_50:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #150
	b.le	LBB0_81
; %bb.51:                               ;   in Loop: Header=BB0_43 Depth=3
	sub	w9, w23, #151
	cmp	w9, #2
	b.hs	LBB0_126
LBB0_52:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #5                          ; =0x5
LBB0_53:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #1208]
	cmp	w9, w8
	b.ne	LBB0_137
; %bb.54:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1198]
	cmp	w23, #146
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.55:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1197]
	cmp	w23, #61
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.56:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	sub	w9, w23, #59
	cmp	w9, #2
	b.lo	LBB0_59
; %bb.57:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #152
	b.eq	LBB0_59
; %bb.58:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #15
	ccmp	w23, w27, #4, ne
	cset	w8, eq
LBB0_59:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	ldrb	w9, [sp, #1199]
	csinc	w8, w8, wzr, ne
	cmp	w9, w8
	b.ne	LBB0_137
; %bb.60:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w8, LBB0_77
; %bb.61:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1224]
	ldr	w9, [sp, #352]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.62:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #-1                         ; =0xffffffff
	cmp	w23, #60
	b.eq	LBB0_65
; %bb.63:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #152
	b.eq	LBB0_65
; %bb.64:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #368]
LBB0_65:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #1228]
	cmp	w9, w8
	b.ne	LBB0_137
; %bb.66:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	cset	w8, ne
	ldr	w9, [sp, #1220]
	cmp	w9, w8
	b.ne	LBB0_137
; %bb.67:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	b.ne	LBB0_84
; %bb.68:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w23, [sp, #944]
	add	x2, sp, #264
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_socket_indirect_hosted_import
	cbz	w0, LBB0_137
; %bb.69:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #264]
	ldr	w9, [sp, #1228]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.70:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	x0, x23
	bl	_nl_socket_catalog_method
	cbz	x0, LBB0_137
; %bb.71:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1236]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.72:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1240]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.73:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [x0, #44]
	cmp	w8, #1
	mov	w8, #399                        ; =0x18f
	csel	w8, w26, w8, eq
	ldr	x10, [x0, #56]
	cmp	x10, #2
	b.lo	LBB0_76
; %bb.74:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	x9, [x0, #48]
	add	x9, x9, #40
	sub	x10, x10, #1
LBB0_75:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ;       Parent Loop BB0_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x9], #48
	orr	w12, w8, #0x20
	cmp	w11, #1
	csel	w8, w12, w8, eq
	subs	x10, x10, #1
	b.ne	LBB0_75
LBB0_76:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #0                          ; =0x0
	orr	w10, w8, #0x200
	cmp	w23, #0
	csel	w8, w10, w8, eq
	b	LBB0_85
LBB0_77:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #0                          ; =0x0
	mov	w8, #128                        ; =0x80
	b	LBB0_86
LBB0_78:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #61
	b.eq	LBB0_128
; %bb.79:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	b.ne	LBB0_53
; %bb.80:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #6                          ; =0x6
	b	LBB0_53
LBB0_81:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #148
	b.eq	LBB0_129
; %bb.82:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #149
	b.ne	LBB0_53
; %bb.83:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #2                          ; =0x2
	b	LBB0_53
LBB0_84:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #448                        ; =0x1c0
	mov	w9, #64                         ; =0x40
LBB0_85:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #1232]
	cmp	w10, w8
	b.ne	LBB0_137
LBB0_86:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #1212]
	cmp	w10, w9
	b.ne	LBB0_137
; %bb.87:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #1216]
	bic	w8, w8, w9
	cmp	w10, w8
	b.ne	LBB0_137
; %bb.88:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #1200]
	ldrh	w9, [sp, #1178]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.89:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #1202]
	ldrh	w9, [sp, #1188]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.90:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1276]
	ldrb	w9, [sp, #428]
	lsr	w10, w8, w9
	cbnz	w10, LBB0_137
; %bb.91:                               ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #0, LBB0_93
; %bb.92:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w9, [sp, #1277]
	cmp	w9, #255
	b.eq	LBB0_98
	b	LBB0_137
LBB0_93:                                ;   in Loop: Header=BB0_43 Depth=3
	cbz	w9, LBB0_137
; %bb.94:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #424]
	ldrh	w8, [sp, #160]
	cmp	w2, w8
	b.hs	LBB0_137
; %bb.95:                               ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #264
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_variant_count
	cbz	w0, LBB0_137
; %bb.96:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1277]
	ldrb	w9, [sp, #264]
	cmp	w8, w9
	b.hs	LBB0_137
; %bb.97:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1276]
LBB0_98:                                ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #1, LBB0_100
; %bb.99:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1278]
	cmp	w8, #255
	b.eq	LBB0_104
	b	LBB0_137
LBB0_100:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #428]
	cmp	w8, #2
	b.lo	LBB0_137
; %bb.101:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #426]
	ldrh	w8, [sp, #160]
	cmp	w2, w8
	b.hs	LBB0_137
; %bb.102:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #264
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_variant_count
	cbz	w0, LBB0_137
; %bb.103:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1278]
	ldrb	w9, [sp, #264]
	cmp	w8, w9
	b.hs	LBB0_137
LBB0_104:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #360]
	cmp	w8, #152
	b.eq	LBB0_106
; %bb.105:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #60
	b.ne	LBB0_120
LBB0_106:                               ;   in Loop: Header=BB0_43 Depth=3
	and	w2, w28, #0xffff
	and	w3, w25, #0xff
	add	x4, sp, #1096
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_socket_indirect_hosted_call
	cbz	w0, LBB0_137
; %bb.107:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	x8, [sp, #1104]
	cbz	x8, LBB0_137
; %bb.108:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	x9, [sp, #1112]
	cmp	x8, x9
	b.ne	LBB0_137
; %bb.109:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1096]
	cmp	w8, w22
	b.ne	LBB0_137
; %bb.110:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1100]
	ldr	w9, [sp, #352]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.111:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1128]
	cmn	w8, #1
	b.ne	LBB0_137
; %bb.112:                              ;   in Loop: Header=BB0_43 Depth=3
	mov	x23, #0                         ; =0x0
	b	LBB0_114
LBB0_113:                               ;   in Loop: Header=BB0_114 Depth=4
	add	x23, x23, #1
	cmp	x23, #64
	b.eq	LBB0_119
LBB0_114:                               ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ;       Parent Loop BB0_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	x8, [sp, #1104]
	lsr	x8, x8, x23
	tbz	w8, #0, LBB0_113
; %bb.115:                              ;   in Loop: Header=BB0_114 Depth=4
	add	x2, sp, #264
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_socket_indirect_hosted_function
	cbz	w0, LBB0_137
; %bb.116:                              ;   in Loop: Header=BB0_114 Depth=4
	ldrb	w8, [sp, #344]
	cbnz	w8, LBB0_137
; %bb.117:                              ;   in Loop: Header=BB0_114 Depth=4
	ldrh	w8, [sp, #276]
	ldrh	w9, [sp, #1144]
	cmp	w8, w9
	b.ne	LBB0_137
; %bb.118:                              ;   in Loop: Header=BB0_114 Depth=4
	ldrb	w8, [sp, #280]
	ldrb	w9, [sp, #1150]
	cmp	w8, w9
	b.eq	LBB0_113
	b	LBB0_137
LBB0_119:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #360]
LBB0_120:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #15
	b.eq	LBB0_123
; %bb.121:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #151
	b.eq	LBB0_123
; %bb.122:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #59
	b.ne	LBB0_125
LBB0_123:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w1, [sp, #368]
	add	x2, sp, #264
	mov	x0, x21
	bl	_nvm_socket_indirect_hosted_function
	cbz	w0, LBB0_137
; %bb.124:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #344]
	cbnz	w8, LBB0_137
LBB0_125:                               ;   in Loop: Header=BB0_43 Depth=3
	add	w25, w25, #1
	ldrb	w8, [sp, #1092]
	cmp	w8, w25, uxtb
	b.hi	LBB0_43
	b	LBB0_130
LBB0_126:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #161
	b.ne	LBB0_53
; %bb.127:                              ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #3                          ; =0x3
	b	LBB0_53
LBB0_128:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #4                          ; =0x4
	b	LBB0_53
LBB0_129:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_53
LBB0_130:                               ;   in Loop: Header=BB0_35 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #160]
	cmp	w8, w28, uxth
	b.hi	LBB0_35
LBB0_131:                               ;   in Loop: Header=BB0_31 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #980]
	cmp	w22, w8
	b.lo	LBB0_31
LBB0_132:
	ldr	x0, [sp, #256]
	bl	_nvm_socket_runtime_begin
	cbnz	w0, LBB0_134
; %bb.133:
	ldr	x0, [sp, #256]
	bl	_nvm_socket_runtime_frame_start
	cbz	w0, LBB0_157
LBB0_134:
	mov	x1, x0
LBB0_135:
	ldr	x0, [sp, #256]
	bl	_nvm_socket_runtime_fail
LBB0_136:
	add	x8, sp, #352
	add	x0, sp, #256
	mov	x1, sp
	bl	_nvm_socket_runtime_indirect_destroy
	b	LBB0_139
LBB0_137:
	add	x8, sp, #352
	add	x0, sp, #256
	mov	x1, #0                          ; =0x0
	bl	_nvm_socket_runtime_indirect_destroy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #464]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #416]
	str	q0, [sp, #448]
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #136]
	str	xzr, [sp, #496]
	str	x9, [sp, #480]
	mov	w9, #2                          ; =0x2
	str	w8, [sp, #352]
	str	w9, [sp, #360]
LBB0_138:
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x24, #20]
LBB0_139:
	ldp	q0, q1, [sp, #448]
	stp	q0, q1, [x19, #96]
	ldr	q0, [sp, #480]
	str	q0, [x19, #128]
	ldr	x8, [sp, #496]
	str	x8, [x19, #144]
	ldp	q0, q1, [sp, #384]
	stp	q0, q1, [x19, #32]
	ldp	q0, q1, [sp, #416]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [sp, #352]
	stp	q0, q1, [x19]
	ldr	w8, [x19, #8]
	cbnz	w8, LBB0_156
; %bb.140:
	ldrb	w8, [x19, #12]
	tbz	w8, #0, LBB0_155
; %bb.141:
	ldr	w9, [x19, #16]
	mov	w8, #10                         ; =0xa
	cbnz	w9, LBB0_156
; %bb.142:
	ldr	w9, [x19, #32]
	cbnz	w9, LBB0_156
; %bb.143:
	ldr	x9, [x19, #40]
	cbnz	x9, LBB0_156
; %bb.144:
	ldrb	w9, [sp]
	mov	w8, #6                          ; =0x6
	tbz	w9, #0, LBB0_156
; %bb.145:
	ldrb	w9, [sp, #1]
	tbnz	w9, #0, LBB0_156
; %bb.146:
	ldrb	w9, [sp, #2]
	tbnz	w9, #0, LBB0_156
; %bb.147:
	ldrb	w9, [sp, #5]
	cbnz	w9, LBB0_156
; %bb.148:
	ldr	w9, [sp, #16]
	cbnz	w9, LBB0_156
; %bb.149:
	ldr	w9, [sp, #8]
	cmn	w9, #1
	b.ne	LBB0_156
; %bb.150:
	ldr	w9, [sp, #12]
	cmn	w9, #1
	b.ne	LBB0_156
; %bb.151:
	ldrb	w9, [sp, #24]
	cmp	w9, #1
	b.ne	LBB0_156
; %bb.152:
	ldrb	w9, [sp, #4]
	cmp	w9, #4
	b.eq	LBB0_353
; %bb.153:
	cmp	w9, #1
	b.ne	LBB0_156
; %bb.154:
	ldr	x10, [sp, #32]
	b	LBB0_354
LBB0_155:
	mov	w8, #5                          ; =0x5
LBB0_156:
	ldurh	w9, [x19, #13]
	strh	w9, [sp, #968]
	ldurb	w9, [x19, #15]
	strb	w9, [sp, #970]
	ldur	x9, [x19, #20]
	str	x9, [sp, #1176]
	ldur	w9, [x19, #28]
	str	w9, [sp, #1184]
	ldp	q0, q1, [x19, #80]
	stp	q0, q1, [sp, #384]
	ldur	q0, [x19, #112]
	str	q0, [sp, #416]
	ldp	q1, q0, [x19, #48]
	stp	q1, q0, [sp, #352]
	str	w8, [x19, #8]
	ldrb	w8, [sp, #970]
	sturb	w8, [x19, #15]
	ldrh	w8, [sp, #968]
	sturh	w8, [x19, #13]
	mov	w8, w9
	stur	w8, [x19, #28]
	ldr	x8, [sp, #1176]
	stur	x8, [x19, #20]
	ldp	q0, q1, [sp, #400]
	stp	q0, q1, [x19, #96]
	ldp	q1, q2, [sp, #368]
	stp	q1, q2, [x19, #64]
	ldr	q0, [sp, #352]
	stur	q0, [x19, #48]
	b	LBB0_26
LBB0_157:
	mov	w27, #-1                        ; =0xffffffff
	b	LBB0_159
LBB0_158:                               ;   in Loop: Header=BB0_159 Depth=1
	cbnz	w1, LBB0_135
LBB0_159:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_235 Depth 2
	ldr	x0, [sp, #256]
	add	x1, sp, #264
	bl	_nvm_socket_runtime_indirect_frame_view
	cbz	w0, LBB0_355
; %bb.160:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #317]
	tbnz	w8, #0, LBB0_355
; %bb.161:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #268]
	cbnz	w8, LBB0_355
; %bb.162:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #272]
	ldrh	w2, [sp, #276]
	add	x3, sp, #352
	mov	x0, x21
	bl	_nvm_socket_indirect_hosted_instruction
	cbz	w0, LBB0_355
; %bb.163:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #272]
	ldrh	w2, [sp, #276]
	ldrb	w3, [sp, #316]
	add	x4, sp, #152
	mov	x0, x21
	bl	_nvm_socket_indirect_hosted_variant
	cbz	w0, LBB0_355
; %bb.164:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #172]
	tbz	w8, #0, LBB0_355
; %bb.165:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w8, [sp, #154]
	ldr	w9, [sp, #304]
	cmp	w9, w8
	b.ne	LBB0_355
; %bb.166:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x0, [sp, #256]
	bl	_nvm_socket_runtime_indirect_enter
	mov	x1, x0
	cbnz	w0, LBB0_135
; %bb.167:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x22, [sp, #256]
	ldr	w26, [sp, #304]
	ldrb	w23, [sp, #360]
	str	w27, [sp, #1092]
	str	w27, [sp, #1088]
	mov	w8, #2                          ; =0x2
	cmp	w23, #255
	b.eq	LBB0_196
; %bb.168:                              ;   in Loop: Header=BB0_159 Depth=1
Lloh8:
	adrp	x11, lJTI0_0@PAGE
Lloh9:
	add	x11, x11, lJTI0_0@PAGEOFF
	adr	x9, LBB0_169
	ldrh	w10, [x11, x23, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB0_169:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_call
	b	LBB0_297
LBB0_170:                               ;   in Loop: Header=BB0_159 Depth=1
	cbz	w26, LBB0_295
; %bb.171:                              ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w26, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	tbz	w0, #0, LBB0_295
; %bb.172:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w23, #252
	b.eq	LBB0_174
; %bb.173:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w23, #106
	b.ne	LBB0_276
LBB0_174:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	ldrh	w2, [sp, #368]
	mov	x0, x22
	mov	x3, x1
	bl	_nvm_socket_runtime_project
	b	LBB0_291
LBB0_175:                               ;   in Loop: Header=BB0_159 Depth=1
	cbz	w26, LBB0_295
; %bb.176:                              ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w26, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.177:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	add	x2, sp, #968
	mov	x0, x22
	bl	_nvm_socket_runtime_view
	tbz	w0, #0, LBB0_295
; %bb.178:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #968]
	cmp	w8, #1
	b.ne	LBB0_317
; %bb.179:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #969]
	tbnz	w8, #0, LBB0_317
; %bb.180:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #970]
	tbnz	w8, #0, LBB0_317
; %bb.181:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #973]
	cbnz	w8, LBB0_317
; %bb.182:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #984]
	cbnz	w8, LBB0_317
; %bb.183:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #972]
	cmp	w8, #4
	b.ne	LBB0_317
; %bb.184:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #976]
	cmn	w8, #1
	b.ne	LBB0_317
; %bb.185:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #980]
	cmn	w8, #1
	b.ne	LBB0_317
; %bb.186:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #992]
	cmp	w8, #1
	b.ne	LBB0_317
; %bb.187:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x8, [sp, #1000]
	cmp	x8, #2
	b.hs	LBB0_317
; %bb.188:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	mov	x0, x22
	bl	_nvm_socket_runtime_drop
	cbnz	w0, LBB0_134
; %bb.189:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x8, [sp, #1000]
	cmp	w23, #161
	b.ne	LBB0_305
; %bb.190:                              ;   in Loop: Header=BB0_159 Depth=1
	cbz	x8, LBB0_323
; %bb.191:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	w1, #0                          ; =0x0
	b	LBB0_292
LBB0_192:                               ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	tbz	w0, #0, LBB0_295
; %bb.193:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w23, #3
	mov	w8, #4                          ; =0x4
	csel	w8, w8, wzr, eq
	cmp	w23, #1
	csinc	w2, w8, wzr, ne
	b.ne	LBB0_274
; %bb.194:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x3, [sp, #368]
	b	LBB0_284
LBB0_195:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w1, #1                          ; =0x1
	mov	w8, #1                          ; =0x1
LBB0_196:                               ;   in Loop: Header=BB0_159 Depth=1
	subs	w25, w26, w8
	b.lo	LBB0_295
; %bb.197:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	x24, x1
	and	w1, w25, #0xffff
	add	x2, sp, #1096
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	tbz	w0, #0, LBB0_295
; %bb.198:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1096]
	add	x2, sp, #1176
	mov	x0, x22
	bl	_nvm_socket_runtime_view
	tbz	w0, #0, LBB0_295
; %bb.199:                              ;   in Loop: Header=BB0_159 Depth=1
	tbz	w24, #0, LBB0_293
LBB0_200:                               ;   in Loop: Header=BB0_159 Depth=1
	and	w8, w23, #0xfe
	cmp	w23, #50
	mov	w9, #48                         ; =0x30
	ccmp	w8, w9, #4, ne
	cset	w9, eq
	sub	w10, w23, #48
	cmp	w10, #3
	cset	w11, lo
	cmp	w8, #40
	ldrb	w10, [sp, #1180]
	and	w8, w10, #0xff
	ccmp	w8, #4, #0, eq
	csinc	w9, w9, wzr, ne
	csinc	w8, w11, wzr, ne
	cmp	w9, #0
	mov	w9, #4                          ; =0x4
	csinc	w9, w9, wzr, ne
	ldrb	w11, [sp, #1176]
	cmp	w11, #1
	b.ne	LBB0_317
; %bb.201:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w11, [sp, #1177]
	tbnz	w11, #0, LBB0_317
; %bb.202:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w11, [sp, #1178]
	tbnz	w11, #0, LBB0_317
; %bb.203:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w11, [sp, #1181]
	cbnz	w11, LBB0_317
; %bb.204:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w11, [sp, #1192]
	cbnz	w11, LBB0_317
; %bb.205:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w9, w10, uxtb
	b.ne	LBB0_317
; %bb.206:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w10, [sp, #1184]
	cmn	w10, #1
	b.ne	LBB0_317
; %bb.207:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w10, [sp, #1188]
	cmn	w10, #1
	b.ne	LBB0_317
; %bb.208:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w10, [sp, #1200]
	cmp	w10, #1
	b.ne	LBB0_317
; %bb.209:                              ;   in Loop: Header=BB0_159 Depth=1
	cbz	w8, LBB0_211
; %bb.210:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x10, [sp, #1208]
	cmp	x10, #2
	b.hs	LBB0_317
LBB0_211:                               ;   in Loop: Header=BB0_159 Depth=1
	tbz	w24, #0, LBB0_306
LBB0_212:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	x10, [sp, #1328]
	cmp	w24, #0
	csel	x9, xzr, x10, ne
	sub	w11, w23, #32
	cmp	w11, #181
	b.hi	LBB0_295
; %bb.213:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x8, [sp, #1208]
Lloh10:
	adrp	x14, lJTI0_1@PAGE
Lloh11:
	add	x14, x14, lJTI0_1@PAGEOFF
	adr	x12, LBB0_214
	ldrh	w13, [x14, x11, lsl #1]
	add	x12, x12, x13, lsl #2
	br	x12
LBB0_214:                               ;   in Loop: Header=BB0_159 Depth=1
	add	x25, x9, x8
	b	LBB0_338
LBB0_215:                               ;   in Loop: Header=BB0_159 Depth=1
	cbz	w26, LBB0_295
; %bb.216:                              ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w26, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.217:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	add	x2, sp, #968
	mov	x0, x22
	bl	_nvm_socket_runtime_view
	tbz	w0, #0, LBB0_295
; %bb.218:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w23, #8
	b.ne	LBB0_244
; %bb.219:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #969]
	tbnz	w8, #0, LBB0_317
; %bb.220:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #970]
	tbz	w8, #0, LBB0_244
	b	LBB0_317
LBB0_221:                               ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w1, [sp, #368]
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_local
	cbz	w0, LBB0_295
; %bb.222:                              ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	cbz	w0, LBB0_295
; %bb.223:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	add	x2, sp, #968
	mov	x0, x22
	bl	_nvm_socket_runtime_view
	tbz	w0, #0, LBB0_295
; %bb.224:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #968]
	cmp	w8, #1
	b.ne	LBB0_317
; %bb.225:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #970]
	tbnz	w8, #0, LBB0_317
; %bb.226:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #969]
	cmp	w23, #11
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_317
; %bb.227:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	ldr	w2, [sp, #1088]
	mov	x0, x22
	cmp	w23, #16
	b.ne	LBB0_318
; %bb.228:                              ;   in Loop: Header=BB0_159 Depth=1
	bl	_nvm_socket_runtime_copy
	b	LBB0_291
LBB0_229:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_store
	b	LBB0_291
LBB0_230:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_borrow
	b	LBB0_291
LBB0_231:                               ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w8, [sp, #384]
	ldrh	w9, [sp, #376]
	cmp	w23, #251
	csel	w25, w8, w9, eq
	ldrh	w9, [sp, #392]
	csel	w8, w9, w8, eq
	and	w9, w8, #0xffff
	cmp	w9, #11
	b.hi	LBB0_295
; %bb.232:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w26, w9
	b.lo	LBB0_295
; %bb.233:                              ;   in Loop: Header=BB0_159 Depth=1
	tst	w8, #0xffff
	b.eq	LBB0_286
; %bb.234:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	x28, #0                         ; =0x0
	and	x23, x8, #0xffff
	sub	w26, w26, w8
	add	x24, sp, #1176
LBB0_235:                               ;   Parent Loop BB0_159 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w8, w26, w28
	and	w1, w8, #0xffff
	mov	x0, x22
	mov	x2, x24
	bl	_nvm_socket_runtime_frame_operand
	tbz	w0, #0, LBB0_295
; %bb.236:                              ;   in Loop: Header=BB0_235 Depth=2
	add	x28, x28, #1
	add	x24, x24, #4
	cmp	x23, x28
	b.ne	LBB0_235
; %bb.237:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w5, [sp, #1176]
	str	w5, [sp, #1088]
	b	LBB0_288
LBB0_238:                               ;   in Loop: Header=BB0_159 Depth=1
	str	w27, [sp, #1176]
	cmp	w23, #68
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
	subs	w8, w26, w8
	b.lo	LBB0_295
; %bb.239:                              ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w8, #0xffff
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.240:                              ;   in Loop: Header=BB0_159 Depth=1
	cmp	w23, #68
	b.ne	LBB0_289
; %bb.241:                              ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w26, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1176
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.242:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w3, [sp, #1176]
	b	LBB0_290
LBB0_243:                               ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w1, [sp, #368]
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_local
	tbz	w0, #0, LBB0_295
LBB0_244:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	mov	x0, x22
	bl	_nvm_socket_runtime_drop
	b	LBB0_291
LBB0_245:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_end_reference
	b	LBB0_291
LBB0_246:                               ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	tbz	w0, #0, LBB0_295
; %bb.247:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1088]
	mov	x0, x22
	bl	_nvm_socket_runtime_indirect_funcref
	b	LBB0_291
LBB0_248:                               ;   in Loop: Header=BB0_159 Depth=1
	cbz	w26, LBB0_295
; %bb.249:                              ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w26, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.250:                              ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	tbz	w0, #0, LBB0_295
; %bb.251:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	ldr	w2, [sp, #1088]
	mov	x0, x22
	bl	_nvm_socket_runtime_copy
	b	LBB0_291
LBB0_252:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w23, [sp, #944]
	str	w27, [sp, #1096]
	mov	x0, x22
	bl	_nvm_socket_runtime_indirect_plan
	add	x2, sp, #1176
	mov	x1, x23
	bl	_nvm_socket_indirect_hosted_import
	cbz	w0, LBB0_295
; %bb.253:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #1176]
	ldr	w9, [sp, #368]
	cmp	w8, w9
	b.ne	LBB0_295
; %bb.254:                              ;   in Loop: Header=BB0_159 Depth=1
	add	x1, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_scratch
	cbz	w0, LBB0_295
; %bb.255:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	w24, #0                         ; =0x0
	cmp	w23, #4
	b.hi	LBB0_260
; %bb.256:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w23
	mov	w9, #19                         ; =0x13
	tst	w8, w9
	b.eq	LBB0_260
; %bb.257:                              ;   in Loop: Header=BB0_159 Depth=1
	cbz	w26, LBB0_295
; %bb.258:                              ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w26, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.259:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	w24, #-1                        ; =0xffffffff
LBB0_260:                               ;   in Loop: Header=BB0_159 Depth=1
	sub	w8, w23, #1
	cmp	w8, #2
	b.hi	LBB0_319
; %bb.261:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w1, [sp, #376]
	add	x2, sp, #1096
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reference
	cbz	w0, LBB0_295
; %bb.262:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w2, [sp, #1096]
	b	LBB0_320
LBB0_263:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_return
	b	LBB0_297
LBB0_264:                               ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	tbz	w0, #0, LBB0_295
; %bb.265:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1088]
	mov	x0, x22
	bl	_nvm_socket_runtime_string_literal
	b	LBB0_291
LBB0_266:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_region_begin
	b	LBB0_291
LBB0_267:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_region_end
	b	LBB0_291
LBB0_268:                               ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w1, [sp, #368]
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_local
	cbz	w0, LBB0_295
; %bb.269:                              ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	tbz	w0, #0, LBB0_295
; %bb.270:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	ldrb	w8, [sp, #376]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w2, w8, ne
	ldr	w3, [sp, #1088]
	mov	x0, x22
	bl	_nvm_socket_runtime_take
	b	LBB0_291
LBB0_271:                               ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w1, [sp, #368]
	add	x2, sp, #1092
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_local
	tbz	w0, #0, LBB0_295
; %bb.272:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	add	x2, sp, #1176
	mov	x0, x22
	bl	_nvm_socket_runtime_result_arm
	mov	x1, x0
	cbnz	w0, LBB0_298
; %bb.273:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #1176]
	cmp	w8, #3
	cset	w1, eq
	b	LBB0_292
LBB0_274:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	w23, #3
	b.ne	LBB0_283
; %bb.275:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w3, [sp, #368]
	b	LBB0_284
LBB0_276:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	add	x2, sp, #968
	mov	x0, x22
	bl	_nvm_socket_runtime_view
	cbz	w0, LBB0_303
; %bb.277:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #969]
	mov	w1, #6                          ; =0x6
	tbnz	w8, #0, LBB0_304
; %bb.278:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #970]
	tbnz	w8, #0, LBB0_304
; %bb.279:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w8, [sp, #984]
	cmp	w8, #3
	b.ne	LBB0_304
; %bb.280:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	add	x2, sp, #1176
	mov	x0, x22
	bl	_nvm_socket_runtime_result_arm
	cbnz	w0, LBB0_297
; %bb.281:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	mov	x0, x22
	bl	_nvm_socket_runtime_drop
	cbnz	w0, LBB0_297
; %bb.282:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1092]
	ldr	w8, [sp, #1176]
	cmp	w8, #3
	cset	w3, eq
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	b	LBB0_285
LBB0_283:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x3, #0                          ; =0x0
LBB0_284:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1088]
	mov	x0, x22
LBB0_285:                               ;   in Loop: Header=BB0_159 Depth=1
	bl	_nvm_socket_runtime_scalar
	b	LBB0_291
LBB0_286:                               ;   in Loop: Header=BB0_159 Depth=1
	and	w1, w26, #0xffff
	add	x2, sp, #1088
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	cbz	w0, LBB0_295
; %bb.287:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	x23, #0                         ; =0x0
	ldr	w5, [sp, #1088]
LBB0_288:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #944]
	and	w2, w25, #0xffff
	add	x3, sp, #1176
	mov	x0, x22
	mov	x4, x23
	bl	_nvm_socket_runtime_construct
	b	LBB0_291
LBB0_289:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w3, #-1                         ; =0xffffffff
LBB0_290:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w2, [sp, #1092]
	mov	x0, x22
	mov	x1, x23
	mov	x4, x2
	bl	_nvm_socket_runtime_string_operation
LBB0_291:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x1, x0
	cbnz	w0, LBB0_135
LBB0_292:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_next
	b	LBB0_297
LBB0_293:                               ;   in Loop: Header=BB0_159 Depth=1
	add	w8, w25, #1
	and	w1, w8, #0xffff
	add	x8, sp, #1096
	add	x2, x8, #4
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_operand
	cbz	w0, LBB0_295
; %bb.294:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1100]
	add	x8, sp, #1176
	add	x2, x8, #120
	mov	x0, x22
	bl	_nvm_socket_runtime_view
	tbnz	w0, #0, LBB0_200
LBB0_295:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	mov	w1, #5                          ; =0x5
LBB0_296:                               ;   in Loop: Header=BB0_159 Depth=1
	bl	_nvm_socket_runtime_fail
LBB0_297:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x1, x0
LBB0_298:                               ;   in Loop: Header=BB0_159 Depth=1
	cbnz	w1, LBB0_135
; %bb.299:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w8, [sp, #360]
	cmp	w8, #61
	b.ne	LBB0_158
; %bb.300:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrh	w8, [sp, #284]
	cmp	w8, #1
	b.ne	LBB0_158
; %bb.301:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x0, [sp, #256]
	add	x1, sp, #1176
	bl	_nvm_socket_runtime_current_root
	tbz	w0, #0, LBB0_136
; %bb.302:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x0, [sp, #256]
	bl	_nvm_socket_runtime_frame_start
	mov	x1, x0
	b	LBB0_158
LBB0_303:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w1, #5                          ; =0x5
LBB0_304:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	b	LBB0_296
LBB0_305:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, #0
	cset	w8, ne
	cmp	w23, #57
	cset	w9, ne
	eor	w1, w9, w8
	b	LBB0_292
LBB0_306:                               ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w10, [sp, #1296]
	cmp	w10, #1
	b.ne	LBB0_317
; %bb.307:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w10, [sp, #1297]
	tbnz	w10, #0, LBB0_317
; %bb.308:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w10, [sp, #1298]
	tbnz	w10, #0, LBB0_317
; %bb.309:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w10, [sp, #1301]
	cbnz	w10, LBB0_317
; %bb.310:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w10, [sp, #1312]
	cbnz	w10, LBB0_317
; %bb.311:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w10, [sp, #1300]
	cmp	w10, w9
	b.ne	LBB0_317
; %bb.312:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w9, [sp, #1304]
	cmn	w9, #1
	b.ne	LBB0_317
; %bb.313:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w9, [sp, #1308]
	cmn	w9, #1
	b.ne	LBB0_317
; %bb.314:                              ;   in Loop: Header=BB0_159 Depth=1
	ldrb	w9, [sp, #1320]
	cmp	w9, #1
	b.ne	LBB0_317
; %bb.315:                              ;   in Loop: Header=BB0_159 Depth=1
	cbz	w8, LBB0_212
; %bb.316:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.ls	LBB0_212
LBB0_317:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	mov	w1, #6                          ; =0x6
	b	LBB0_296
LBB0_318:                               ;   in Loop: Header=BB0_159 Depth=1
	bl	_nvm_socket_runtime_move
	b	LBB0_291
LBB0_319:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w2, #-1                         ; =0xffffffff
LBB0_320:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #368]
	ldr	w3, [sp, #1092]
	ldr	w4, [sp, #1088]
	mov	x0, x22
	bl	_nvm_socket_runtime_service
	mov	x1, x0
	cbnz	w0, LBB0_298
; %bb.321:                              ;   in Loop: Header=BB0_159 Depth=1
	add	w8, w24, w26
	and	w1, w8, #0xffff
	add	x2, sp, #964
	mov	x0, x22
	bl	_nvm_socket_runtime_frame_reserve
	tbz	w0, #0, LBB0_295
; %bb.322:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1088]
	ldr	w2, [sp, #964]
	mov	x0, x22
	bl	_nvm_socket_runtime_move
	b	LBB0_291
LBB0_323:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x0, x22
	mov	w1, #9                          ; =0x9
	b	LBB0_296
LBB0_324:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, x9
	cset	w25, ge
	b	LBB0_348
LBB0_325:                               ;   in Loop: Header=BB0_159 Depth=1
	cbz	x9, LBB0_337
; %bb.326:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	x11, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x11
	b.ne	LBB0_328
; %bb.327:                              ;   in Loop: Header=BB0_159 Depth=1
	cmn	x9, #1
	b.eq	LBB0_337
LBB0_328:                               ;   in Loop: Header=BB0_159 Depth=1
	sdiv	x9, x8, x10
	msub	x25, x9, x10, x8
	b	LBB0_338
LBB0_329:                               ;   in Loop: Header=BB0_159 Depth=1
	neg	x25, x8
	b	LBB0_338
LBB0_330:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, x9
	cset	w25, le
	b	LBB0_348
LBB0_331:                               ;   in Loop: Header=BB0_159 Depth=1
	sub	x25, x8, x9
	b	LBB0_338
LBB0_332:                               ;   in Loop: Header=BB0_159 Depth=1
	mul	x25, x9, x8
	b	LBB0_338
LBB0_333:                               ;   in Loop: Header=BB0_159 Depth=1
	cbz	x9, LBB0_337
; %bb.334:                              ;   in Loop: Header=BB0_159 Depth=1
	mov	x25, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x25
	b.ne	LBB0_336
; %bb.335:                              ;   in Loop: Header=BB0_159 Depth=1
	cmn	x9, #1
	b.eq	LBB0_338
LBB0_336:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w23, #1                         ; =0x1
	sdiv	x25, x8, x10
	b	LBB0_349
LBB0_337:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	x25, #0                         ; =0x0
LBB0_338:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w23, #1                         ; =0x1
	b	LBB0_349
LBB0_339:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, x9
	b	LBB0_345
LBB0_340:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, x9
	b	LBB0_347
LBB0_341:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, x9
	cset	w25, lt
	b	LBB0_348
LBB0_342:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, x9
	cset	w25, gt
	b	LBB0_348
LBB0_343:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, #0
	ccmp	x9, #0, #4, ne
	b	LBB0_347
LBB0_344:                               ;   in Loop: Header=BB0_159 Depth=1
	cmp	x8, #0
LBB0_345:                               ;   in Loop: Header=BB0_159 Depth=1
	cset	w25, eq
	b	LBB0_348
LBB0_346:                               ;   in Loop: Header=BB0_159 Depth=1
	orr	x8, x8, x9
	cmp	x8, #0
LBB0_347:                               ;   in Loop: Header=BB0_159 Depth=1
	cset	w25, ne
LBB0_348:                               ;   in Loop: Header=BB0_159 Depth=1
	mov	w23, #4                         ; =0x4
LBB0_349:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1096]
	mov	x0, x22
	bl	_nvm_socket_runtime_drop
	cbnz	w0, LBB0_297
; %bb.350:                              ;   in Loop: Header=BB0_159 Depth=1
	tbnz	w24, #0, LBB0_352
; %bb.351:                              ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1100]
	mov	x0, x22
	bl	_nvm_socket_runtime_drop
	cbnz	w0, LBB0_297
LBB0_352:                               ;   in Loop: Header=BB0_159 Depth=1
	ldr	w1, [sp, #1096]
	mov	x0, x22
	mov	x2, x23
	mov	x3, x25
	bl	_nvm_socket_runtime_scalar
	mov	x1, x0
	cbnz	w0, LBB0_298
	b	LBB0_292
LBB0_353:
	ldr	x10, [sp, #32]
	cmp	x10, #1
	b.hi	LBB0_156
LBB0_354:
	mov	w8, #0                          ; =0x0
	strb	w9, [x20]
	stur	wzr, [x20, #1]
	str	wzr, [x20, #4]
	str	x10, [x20, #8]
	b	LBB0_156
LBB0_355:
	ldr	x0, [sp, #256]
	mov	w1, #5                          ; =0x5
	bl	_nvm_socket_runtime_fail
	cbnz	w0, LBB0_134
	b	LBB0_136
LBB0_356:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_292-LBB0_169)>>2
	.short	(LBB0_192-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_192-LBB0_169)>>2
	.short	(LBB0_264-LBB0_169)>>2
	.short	(LBB0_192-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_248-LBB0_169)>>2
	.short	(LBB0_215-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_221-LBB0_169)>>2
	.short	(LBB0_229-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_169-LBB0_169)>>2
	.short	(LBB0_221-LBB0_169)>>2
	.short	(LBB0_229-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_266-LBB0_169)>>2
	.short	(LBB0_267-LBB0_169)>>2
	.short	(LBB0_230-LBB0_169)>>2
	.short	(LBB0_230-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_195-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_195-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_292-LBB0_169)>>2
	.short	(LBB0_175-LBB0_169)>>2
	.short	(LBB0_175-LBB0_169)>>2
	.short	(LBB0_169-LBB0_169)>>2
	.short	(LBB0_169-LBB0_169)>>2
	.short	(LBB0_263-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_238-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_238-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_231-LBB0_169)>>2
	.short	(LBB0_170-LBB0_169)>>2
	.short	(LBB0_170-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_252-LBB0_169)>>2
	.short	(LBB0_271-LBB0_169)>>2
	.short	(LBB0_268-LBB0_169)>>2
	.short	(LBB0_243-LBB0_169)>>2
	.short	(LBB0_215-LBB0_169)>>2
	.short	(LBB0_245-LBB0_169)>>2
	.short	(LBB0_169-LBB0_169)>>2
	.short	(LBB0_169-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_175-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_195-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_246-LBB0_169)>>2
	.short	(LBB0_231-LBB0_169)>>2
	.short	(LBB0_170-LBB0_169)>>2
	.short	(LBB0_196-LBB0_169)>>2
	.short	(LBB0_170-LBB0_169)>>2
	.p2align	1, 0x0
lJTI0_1:
	.short	(LBB0_214-LBB0_214)>>2
	.short	(LBB0_331-LBB0_214)>>2
	.short	(LBB0_332-LBB0_214)>>2
	.short	(LBB0_333-LBB0_214)>>2
	.short	(LBB0_325-LBB0_214)>>2
	.short	(LBB0_329-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_339-LBB0_214)>>2
	.short	(LBB0_340-LBB0_214)>>2
	.short	(LBB0_341-LBB0_214)>>2
	.short	(LBB0_330-LBB0_214)>>2
	.short	(LBB0_342-LBB0_214)>>2
	.short	(LBB0_324-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_343-LBB0_214)>>2
	.short	(LBB0_346-LBB0_214)>>2
	.short	(LBB0_344-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_214-LBB0_214)>>2
	.short	(LBB0_331-LBB0_214)>>2
	.short	(LBB0_332-LBB0_214)>>2
	.short	(LBB0_333-LBB0_214)>>2
	.short	(LBB0_325-LBB0_214)>>2
	.short	(LBB0_329-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_295-LBB0_214)>>2
	.short	(LBB0_339-LBB0_214)>>2
	.short	(LBB0_340-LBB0_214)>>2
	.short	(LBB0_341-LBB0_214)>>2
	.short	(LBB0_330-LBB0_214)>>2
	.short	(LBB0_342-LBB0_214)>>2
	.short	(LBB0_324-LBB0_214)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fcd_supported
_fcd_supported:                         ; @fcd_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB1_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh12:
	adrp	x9, lJTI1_0@PAGE
Lloh13:
	add	x9, x9, lJTI1_0@PAGEOFF
	adr	x10, LBB1_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB1_2:
	ret
LBB1_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
	.section	__TEXT,__const
lJTI1_0:
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
                                        ; -- End function
.subsections_via_symbols
