	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_ownership_path     ; -- Begin function nvm_ownership_path
	.globl	_nvm_ownership_path
	.p2align	2
_nvm_ownership_path:                    ; @nvm_ownership_path
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	cbz	x0, LBB0_21
; %bb.1:
	mov	x21, x0
	mov	w0, #13                         ; =0xd
	cmn	w1, #1
	b.eq	LBB0_22
; %bb.2:
	ldr	x8, [x21, #296]
	cbz	x8, LBB0_22
; %bb.3:
	mov	x20, x1
	mov	x23, x3
	mov	x19, x2
	mov	x22, x4
	add	x1, sp, #71
	mov	x0, x21
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB0_22
; %bb.4:
	ldr	x1, [x21, #296]
	ldr	w2, [x21, #304]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_22
; %bb.5:
	ldr	w8, [sp, #36]
	sub	w8, w8, #4
	cmn	w8, #2
	b.hs	LBB0_7
; %bb.6:
	mov	w0, #3                          ; =0x3
	b	LBB0_22
LBB0_7:
	add	x0, sp, #40
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_22
; %bb.8:
	ldr	w1, [sp, #32]
	add	x0, sp, #40
	add	x2, sp, #16
	bl	_nvm_v2_take
	cbnz	w0, LBB0_22
; %bb.9:
	add	x0, sp, #40
	bl	_nvm_v2_align4
	cbnz	w0, LBB0_22
; %bb.10:
	add	x0, sp, #40
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_22
; %bb.11:
	ldr	w8, [sp, #28]
	ldr	w9, [x21, #272]
	cmp	w8, w9
	b.ne	LBB0_21
; %bb.12:
	cbz	w8, LBB0_19
; %bb.13:
	mov	w21, #0                         ; =0x0
LBB0_14:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #40
	add	x1, sp, #72
	bl	_nvm_v2_u16
	cbnz	w0, LBB0_22
; %bb.15:                               ;   in Loop: Header=BB0_14 Depth=1
	add	x0, sp, #40
	add	x1, sp, #14
	bl	_nvm_v2_u16
	cbnz	w0, LBB0_22
; %bb.16:                               ;   in Loop: Header=BB0_14 Depth=1
	ldrh	w9, [sp, #14]
	ldrh	w8, [sp, #72]
	cmp	w9, w8
	b.hi	LBB0_21
; %bb.17:                               ;   in Loop: Header=BB0_14 Depth=1
	lsl	x8, x8, #3
	add	x0, sp, #40
	add	x1, x8, #8
	add	x2, sp, #16
	bl	_nvm_v2_take
	cbnz	w0, LBB0_22
; %bb.18:                               ;   in Loop: Header=BB0_14 Depth=1
	add	w21, w21, #1
	ldr	w8, [sp, #28]
	cmp	w21, w8
	b.lo	LBB0_14
LBB0_19:
	strh	wzr, [sp, #14]
	ldr	w8, [sp, #36]
	add	x0, sp, #40
	add	x2, sp, #72
	add	x4, sp, #14
	mov	x1, x20
	mov	w3, #32                         ; =0x20
	cmp	w8, #2
	b.ne	LBB0_24
; %bb.20:
	bl	_paths_read
	b	LBB0_25
LBB0_21:
	mov	w0, #13                         ; =0xd
LBB0_22:
	ldur	x8, [x29, #-56]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_32
; %bb.23:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB0_24:
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_extension_suffix_read_map
LBB0_25:
	cbnz	w0, LBB0_22
; %bb.26:
	mov	w0, #13                         ; =0xd
	cbz	x19, LBB0_22
; %bb.27:
	cbz	x22, LBB0_22
; %bb.28:
	ldrh	w20, [sp, #14]
	cmp	w20, w23
	b.hi	LBB0_22
; %bb.29:
	cbz	w20, LBB0_31
; %bb.30:
	lsl	x2, x20, #1
	add	x1, sp, #72
	mov	x0, x19
	bl	_memcpy
LBB0_31:
	mov	w0, #0                          ; =0x0
	strh	w20, [x22]
	b	LBB0_22
LBB0_32:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_contracts_validate ; -- Begin function nvm_ownership_contracts_validate
	.globl	_nvm_ownership_contracts_validate
	.p2align	2
_nvm_ownership_contracts_validate:      ; @nvm_ownership_contracts_validate
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #13                         ; =0xd
	cbz	x8, LBB1_10
; %bb.1:
	cbz	x1, LBB1_10
; %bb.2:
	strb	wzr, [x1]
	ldr	w10, [x8, #304]
	ldr	x9, [x8, #296]
	cbz	w10, LBB1_9
; %bb.3:
	cbz	x9, LBB1_8
; %bb.4:
	ldr	w9, [x8, #320]
	cbz	w9, LBB1_8
; %bb.5:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x8
	mov	x0, x8
	bl	_nvm_retained_layouts_valid
	cbz	w0, LBB1_11
; %bb.6:
	stp	xzr, xzr, [sp]
	ldr	x0, [x20, #312]
	ldr	w1, [x20, #320]
	mov	x2, sp
	bl	_nvm_v2_layouts_decode
	cbnz	w0, LBB1_12
; %bb.7:
	mov	x1, sp
	mov	x0, x20
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	bl	_ownership_validate_owned
	mov	x19, x0
	mov	x0, sp
	bl	_nvm_v2_layouts_free
	mov	x0, x19
	b	LBB1_12
LBB1_8:
	mov	w0, #8                          ; =0x8
	ret
LBB1_9:
	cmp	x9, #0
	mov	w8, #9                          ; =0x9
	csel	w0, wzr, w8, eq
LBB1_10:
	ret
LBB1_11:
	mov	w0, #8                          ; =0x8
LBB1_12:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function paths_read
_paths_read:                            ; @paths_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x21, x3
	mov	x20, x2
	mov	x22, x1
	mov	x23, x0
Lloh6:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x8, [x8]
	str	x8, [sp, #88]
	add	x1, sp, #20
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.1:
	ldr	w8, [sp, #20]
	cmp	w8, #256
	b.ls	LBB2_5
LBB2_2:
	mov	w0, #13                         ; =0xd
LBB2_3:
	ldr	x8, [sp, #88]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_29
; %bb.4:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB2_5:
	cbz	w8, LBB2_18
; %bb.6:
	mov	w25, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	add	x26, sp, #24
LBB2_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_13 Depth 2
	add	x1, sp, #18
	mov	x0, x23
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_3
; %bb.8:                                ;   in Loop: Header=BB2_7 Depth=1
	add	x1, sp, #16
	mov	x0, x23
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_3
; %bb.9:                                ;   in Loop: Header=BB2_7 Depth=1
	ldrh	w8, [sp, #16]
	cbnz	w8, LBB2_28
; %bb.10:                               ;   in Loop: Header=BB2_7 Depth=1
	ldrh	w8, [sp, #18]
	sub	w8, w8, #33
	cmn	w8, #32
	b.lo	LBB2_2
; %bb.11:                               ;   in Loop: Header=BB2_7 Depth=1
	mov	x27, #0                         ; =0x0
	b	LBB2_13
LBB2_12:                                ;   in Loop: Header=BB2_13 Depth=2
	add	x27, x27, #1
	ldrh	w28, [sp, #18]
	cmp	x27, x28
	b.hs	LBB2_16
LBB2_13:                                ;   Parent Loop BB2_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x1, sp, #14
	mov	x0, x23
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_3
; %bb.14:                               ;   in Loop: Header=BB2_13 Depth=2
	cmp	w25, w22
	b.ne	LBB2_12
; %bb.15:                               ;   in Loop: Header=BB2_13 Depth=2
	ldrh	w8, [sp, #14]
	strh	w8, [x26, x27, lsl #1]
	b	LBB2_12
LBB2_16:                                ;   in Loop: Header=BB2_7 Depth=1
	mov	x0, x23
	bl	_nvm_v2_align4
	cbnz	w0, LBB2_3
; %bb.17:                               ;   in Loop: Header=BB2_7 Depth=1
	cmp	w25, w22
	csel	w24, w28, w24, eq
	add	w25, w25, #1
	ldr	w8, [sp, #20]
	cmp	w25, w8
	b.lo	LBB2_7
	b	LBB2_19
LBB2_18:
	mov	w24, #0                         ; =0x0
LBB2_19:
	ldp	x9, x8, [x23, #8]
	cmp	x8, x9
	b.ne	LBB2_26
; %bb.20:
	cmn	w22, #1
	b.eq	LBB2_27
; %bb.21:
	mov	w0, #13                         ; =0xd
	tst	w24, #0xffff
	b.eq	LBB2_3
; %bb.22:
	cbz	x19, LBB2_3
; %bb.23:
	cbz	x20, LBB2_3
; %bb.24:
	cmp	w21, w24, uxth
	b.lo	LBB2_3
; %bb.25:
	ubfiz	x2, x24, #1, #16
	add	x1, sp, #24
	mov	x0, x20
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	strh	w24, [x19]
	b	LBB2_3
LBB2_26:
	mov	w0, #9                          ; =0x9
	b	LBB2_3
LBB2_27:
	mov	w0, #0                          ; =0x0
	b	LBB2_3
LBB2_28:
	mov	w0, #7                          ; =0x7
	b	LBB2_3
LBB2_29:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_validate_owned
_ownership_validate_owned:              ; @ownership_validate_owned
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x5
	mov	x20, x4
	mov	x19, x3
	mov	x21, x2
	mov	x23, x1
	mov	x24, x0
	sturb	wzr, [x29, #-97]
	stur	xzr, [x29, #-112]
	ldr	x1, [x0, #296]
	ldr	w2, [x0, #304]
	sub	x0, x29, #136
	bl	_nvm_v2_cursor_init
	sturb	wzr, [x29, #-153]
	sub	x0, x29, #136
	sub	x1, x29, #140
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_74
; %bb.1:
	sub	x0, x29, #136
	sub	x1, x29, #144
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_74
; %bb.2:
	ldur	w8, [x29, #-140]
	sub	w8, w8, #1
	cmp	w8, #2
	b.hi	LBB3_73
; %bb.3:
	ldur	w1, [x29, #-144]
	ldr	w8, [x23, #8]
	cmp	w1, w8
	b.ne	LBB3_53
; %bb.4:
	sub	x0, x29, #136
	sub	x2, x29, #152
	bl	_nvm_v2_take
	cbnz	w0, LBB3_74
; %bb.5:
	sub	x0, x29, #136
	bl	_nvm_v2_align4
	cbnz	w0, LBB3_74
; %bb.6:
	ldur	x1, [x29, #-152]
	ldur	w8, [x29, #-140]
	cmp	w8, #3
	cset	w8, eq
	cmp	x19, #0
	cset	w3, ne
	csel	w4, wzr, w8, ne
	cmp	x22, #0
	cset	w5, ne
	sub	x2, x29, #153
	mov	x0, x23
	bl	_check_layouts
	cbnz	w0, LBB3_74
; %bb.7:
	sub	x0, x29, #136
	sub	x1, x29, #144
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_74
; %bb.8:
	cbz	x19, LBB3_12
; %bb.9:
	ldr	w8, [x23, #8]
	cbz	w8, LBB3_12
; %bb.10:
	mov	x8, #0                          ; =0x0
	ldur	x9, [x29, #-152]
	add	x10, x19, #32
LBB3_11:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9, x8]
	strb	w11, [x10, x8]
	add	x8, x8, #1
	ldr	w11, [x23, #8]
	cmp	x8, x11
	b.lo	LBB3_11
LBB3_12:
	ldur	w8, [x29, #-144]
	ldr	w9, [x24, #272]
	cmp	w8, w9
	b.ne	LBB3_53
; %bb.13:
	cbz	w8, LBB3_45
; %bb.14:
	ldr	x8, [x24, #256]
	cbz	x8, LBB3_53
; %bb.15:
	mov	x26, #0                         ; =0x0
	sub	x8, x29, #97
	cmp	x19, #0
	csel	x25, x8, xzr, ne
	sub	x8, x29, #112
	csel	x27, xzr, x8, ne
	b	LBB3_17
LBB3_16:                                ;   in Loop: Header=BB3_17 Depth=1
	add	x26, x26, #1
	ldur	w8, [x29, #-144]
	cmp	x26, x8
	b.hs	LBB3_45
LBB3_17:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_34 Depth 2
	ldr	x28, [x24, #256]
	sub	x0, x29, #136
	add	x1, sp, #8
	bl	_nvm_v2_u16
	cbnz	w0, LBB3_74
; %bb.18:                               ;   in Loop: Header=BB3_17 Depth=1
	sub	x0, x29, #136
	sub	x1, x29, #156
	bl	_nvm_v2_u16
	cbnz	w0, LBB3_74
; %bb.19:                               ;   in Loop: Header=BB3_17 Depth=1
	mov	w8, #24                         ; =0x18
	madd	x8, x26, x8, x28
	ldrh	w9, [sp, #8]
	ldrh	w10, [x8, #16]
	cmp	w9, w10
	b.ne	LBB3_53
; %bb.20:                               ;   in Loop: Header=BB3_17 Depth=1
	ldurh	w10, [x29, #-156]
	mov	w0, #13                         ; =0xd
	cmp	w10, w9
	b.hi	LBB3_74
; %bb.21:                               ;   in Loop: Header=BB3_17 Depth=1
	ldrh	w9, [x8, #4]
	cmp	w10, w9
	b.ne	LBB3_74
; %bb.22:                               ;   in Loop: Header=BB3_17 Depth=1
	ldrb	w9, [x8, #21]
	cmp	w9, #1
	b.hi	LBB3_74
; %bb.23:                               ;   in Loop: Header=BB3_17 Depth=1
	cbz	w9, LBB3_26
; %bb.24:                               ;   in Loop: Header=BB3_17 Depth=1
	ldrb	w5, [x8, #20]
	cbz	x22, LBB3_27
; %bb.25:                               ;   in Loop: Header=BB3_17 Depth=1
	cmp	w5, #13
	b.ne	LBB3_27
	b	LBB3_67
LBB3_26:                                ;   in Loop: Header=BB3_17 Depth=1
	mov	w5, #0                          ; =0x0
LBB3_27:                                ;   in Loop: Header=BB3_17 Depth=1
	sturb	wzr, [x29, #-97]
	ldur	x2, [x29, #-152]
	ldur	w3, [x29, #-140]
	str	x27, [sp]
	sub	x0, x29, #136
	sub	x6, x29, #153
	mov	x1, x23
	mov	w4, #0                          ; =0x0
	mov	x7, x25
	bl	_descriptor
	cbz	w0, LBB3_31
; %bb.28:                               ;   in Loop: Header=BB3_17 Depth=1
	cbz	x20, LBB3_74
; %bb.29:                               ;   in Loop: Header=BB3_17 Depth=1
	ldurb	w8, [x29, #-97]
	tbz	w8, #0, LBB3_74
; %bb.30:                               ;   in Loop: Header=BB3_17 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #48]
LBB3_31:                                ;   in Loop: Header=BB3_17 Depth=1
	ldrh	w8, [sp, #8]
	cbz	w8, LBB3_16
; %bb.32:                               ;   in Loop: Header=BB3_17 Depth=1
	mov	x28, #0                         ; =0x0
	b	LBB3_34
LBB3_33:                                ;   in Loop: Header=BB3_34 Depth=2
	add	x28, x28, #1
	ldrh	w8, [sp, #8]
	cmp	x28, x8
	b.hs	LBB3_16
LBB3_34:                                ;   Parent Loop BB3_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-156]
	cmp	x28, x8
	b.hs	LBB3_39
; %bb.35:                               ;   in Loop: Header=BB3_34 Depth=2
	ldr	x9, [x24, #264]
	cbz	x9, LBB3_40
; %bb.36:                               ;   in Loop: Header=BB3_34 Depth=2
	ldr	x9, [x9, x26, lsl #3]
	cbz	x9, LBB3_40
; %bb.37:                               ;   in Loop: Header=BB3_34 Depth=2
	ldrb	w5, [x9, x28]
	cbz	x22, LBB3_41
; %bb.38:                               ;   in Loop: Header=BB3_34 Depth=2
	cmp	w5, #13
	b.ne	LBB3_41
	b	LBB3_67
LBB3_39:                                ;   in Loop: Header=BB3_34 Depth=2
	mov	w5, #-1                         ; =0xffffffff
	b	LBB3_41
LBB3_40:                                ;   in Loop: Header=BB3_34 Depth=2
	mov	w5, #0                          ; =0x0
LBB3_41:                                ;   in Loop: Header=BB3_34 Depth=2
	cmp	x28, x8
	cset	w4, lo
	sturb	wzr, [x29, #-97]
	ldur	x2, [x29, #-152]
	ldur	w3, [x29, #-140]
	str	x27, [sp]
	sub	x0, x29, #136
	sub	x6, x29, #153
	mov	x1, x23
	mov	x7, x25
	bl	_descriptor
	cbz	w0, LBB3_33
; %bb.42:                               ;   in Loop: Header=BB3_34 Depth=2
	cbz	x20, LBB3_74
; %bb.43:                               ;   in Loop: Header=BB3_34 Depth=2
	ldurb	w8, [x29, #-97]
	tbz	w8, #0, LBB3_74
; %bb.44:                               ;   in Loop: Header=BB3_34 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #48]
	b	LBB3_33
LBB3_45:
	sub	x25, x29, #224
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x25, #32]
	stp	q0, q0, [x25]
	stp	xzr, xzr, [x29, #-240]
	ldur	w8, [x29, #-140]
	cmp	w8, #3
	b.eq	LBB3_54
; %bb.46:
	cmp	w8, #2
	b.ne	LBB3_48
; %bb.47:
	sub	x0, x29, #136
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_paths_read
	cbnz	w0, LBB3_74
LBB3_48:
	mov	w24, #0                         ; =0x0
LBB3_49:
	cbz	x22, LBB3_52
; %bb.50:
	ldur	x1, [x29, #-240]
	cbz	x1, LBB3_67
; %bb.51:
	ldur	x4, [x29, #-152]
	ldur	x2, [x29, #-232]
	mov	x0, x22
	mov	x3, x23
	bl	_map_payload
	cbz	w0, LBB3_67
LBB3_52:
	ldur	w8, [x29, #-112]
	cmp	w8, w24
	b.ls	LBB3_65
LBB3_53:
	mov	w0, #13                         ; =0xd
	b	LBB3_74
LBB3_54:
	sub	x8, x29, #240
	cmp	x22, #0
	csel	x6, x8, xzr, ne
	sub	x0, x29, #136
	sub	x5, x29, #224
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_extension_suffix_read_map
	cbnz	w0, LBB3_74
; %bb.55:
	ldur	x1, [x29, #-224]
	cmp	x1, #0
	cset	w8, ne
	ldr	w9, [x24, #476]
	cmp	w9, #0
	cset	w9, eq
	cmp	w8, w9
	b.eq	LBB3_67
; %bb.56:
	cbz	x1, LBB3_61
; %bb.57:
	ldur	w2, [x29, #-216]
	add	x0, sp, #8
	bl	_nvm_v2_cursor_init
	ldur	x3, [x29, #-152]
	add	x0, sp, #8
	mov	x1, x24
	mov	x2, x23
	mov	w4, #-1                         ; =0xffffffff
	mov	w5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	mov	x7, x20
	bl	_union_facts_read
	cbnz	w0, LBB3_74
; %bb.58:
	cbz	x20, LBB3_60
; %bb.59:
	ldr	q0, [x25]
	str	q0, [x20]
LBB3_60:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-153]
LBB3_61:
	ldur	x0, [x29, #-192]
	cbz	x0, LBB3_71
; %bb.62:
	cbnz	x19, LBB3_73
; %bb.63:
	ldur	x3, [x29, #-152]
	ldur	x1, [x29, #-184]
	mov	x2, x23
	bl	_globals_read
	cbnz	w0, LBB3_78
; %bb.64:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-153]
	ldur	x0, [x29, #-176]
	cbnz	x0, LBB3_80
	b	LBB3_79
LBB3_65:
	cbz	w24, LBB3_68
; %bb.66:
	ldurb	w8, [x29, #-108]
	tbz	w8, #0, LBB3_68
LBB3_67:
	mov	w0, #8                          ; =0x8
	b	LBB3_74
LBB3_68:
	ldp	x9, x8, [x29, #-128]
	cmp	x8, x9
	b.ne	LBB3_70
; %bb.69:
	mov	w0, #0                          ; =0x0
	ldurb	w8, [x29, #-153]
	strb	w8, [x21]
	b	LBB3_74
LBB3_70:
	mov	w0, #9                          ; =0x9
	b	LBB3_74
LBB3_71:
	ldur	x0, [x29, #-176]
	cbz	x0, LBB3_79
; %bb.72:
	cbz	x19, LBB3_80
LBB3_73:
	mov	w0, #3                          ; =0x3
LBB3_74:
	cbnz	x20, LBB3_78
; %bb.75:
	cbz	x19, LBB3_78
; %bb.76:
	ldurb	w8, [x29, #-97]
	tbz	w8, #0, LBB3_78
; %bb.77:
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #300]
LBB3_78:
	add	sp, sp, #2224
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB3_79:
	mov	w24, #0                         ; =0x0
	ldur	x0, [x29, #-208]
	cbnz	x0, LBB3_82
	b	LBB3_49
LBB3_80:
	ldur	x4, [x29, #-152]
	ldur	x1, [x29, #-168]
	str	xzr, [sp]
	add	x7, sp, #8
	mov	x2, x24
	mov	x3, x23
	mov	w5, #-1                         ; =0xffffffff
	mov	x6, #0                          ; =0x0
	bl	_effects_read
	cbnz	w0, LBB3_78
; %bb.81:
	ldr	w24, [sp, #8]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-153]
	ldur	x0, [x29, #-208]
	cbz	x0, LBB3_49
LBB3_82:
	cbz	x19, LBB3_84
; %bb.83:
	ldur	x1, [x29, #-200]
	mov	x2, x19
	bl	_oaa_array_fields
	cbnz	w0, LBB3_74
	b	LBB3_49
LBB3_84:
	mov	w0, #3                          ; =0x3
	b	LBB3_78
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_globals  ; -- Begin function nvm_ownership_globals
	.globl	_nvm_ownership_globals
	.p2align	2
_nvm_ownership_globals:                 ; @nvm_ownership_globals
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #2192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x0
Lloh12:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh13:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh14:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w0, #13                         ; =0xd
	cbz	x20, LBB4_25
; %bb.1:
	cbz	x3, LBB4_25
; %bb.2:
	cbnz	x1, LBB4_4
; %bb.3:
	cbnz	w2, LBB4_25
LBB4_4:
	mov	x22, x2
	mov	x19, x1
	mov	x21, x3
	add	x1, sp, #135
	mov	x0, x20
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB4_25
; %bb.5:
	ldr	w2, [x20, #304]
	cbz	w2, LBB4_24
; %bb.6:
	ldr	x1, [x20, #296]
	add	x0, sp, #104
	bl	_nvm_v2_cursor_init
	add	x0, sp, #104
	add	x1, sp, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_25
; %bb.7:
	ldr	w8, [sp, #100]
	cmp	w8, #3
	b.ne	LBB4_24
; %bb.8:
	add	x0, sp, #104
	add	x1, sp, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_25
; %bb.9:
	ldr	w1, [sp, #96]
	add	x0, sp, #104
	add	x2, sp, #88
	bl	_nvm_v2_take
	cbnz	w0, LBB4_25
; %bb.10:
	add	x0, sp, #104
	bl	_nvm_v2_align4
	cbnz	w0, LBB4_25
; %bb.11:
	add	x0, sp, #104
	add	x1, sp, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_25
; %bb.12:
	ldr	w8, [sp, #96]
	cbz	w8, LBB4_18
; %bb.13:
	mov	w20, #0                         ; =0x0
LBB4_14:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #104
	add	x1, sp, #136
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_25
; %bb.15:                               ;   in Loop: Header=BB4_14 Depth=1
	add	x0, sp, #104
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_25
; %bb.16:                               ;   in Loop: Header=BB4_14 Depth=1
	ldrh	w8, [sp, #136]
	lsl	x8, x8, #3
	add	x0, sp, #104
	add	x1, x8, #8
	add	x2, sp, #88
	bl	_nvm_v2_take
	cbnz	w0, LBB4_25
; %bb.17:                               ;   in Loop: Header=BB4_14 Depth=1
	add	w20, w20, #1
	ldr	w8, [sp, #96]
	cmp	w20, w8
	b.lo	LBB4_14
LBB4_18:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	add	x0, sp, #104
	add	x5, sp, #16
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_extension_suffix_read_map
	cbnz	w0, LBB4_25
; %bb.19:
	ldr	x1, [sp, #48]
	cbz	x1, LBB4_24
; %bb.20:
	ldr	w2, [sp, #56]
	add	x0, sp, #104
	bl	_nvm_v2_cursor_init
	add	x0, sp, #104
	add	x1, sp, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_25
; %bb.21:
	ldr	w8, [sp, #96]
	cbz	x19, LBB4_27
; %bb.22:
	cmp	w22, w8
	b.hs	LBB4_27
; %bb.23:
	mov	w0, #13                         ; =0xd
	b	LBB4_25
LBB4_24:
	mov	w0, #0                          ; =0x0
	str	wzr, [x21]
LBB4_25:
	ldur	x8, [x29, #-56]
Lloh15:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh17:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB4_39
; %bb.26:
	add	sp, sp, #2192
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB4_27:
	cbz	w8, LBB4_37
; %bb.28:
	mov	x22, #0                         ; =0x0
	add	x20, sp, #136
LBB4_29:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #104
	mov	x1, x20
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_25
; %bb.30:                               ;   in Loop: Header=BB4_29 Depth=1
	add	x0, sp, #104
	add	x1, sp, #15
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_25
; %bb.31:                               ;   in Loop: Header=BB4_29 Depth=1
	add	x0, sp, #104
	add	x1, sp, #12
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_25
; %bb.32:                               ;   in Loop: Header=BB4_29 Depth=1
	add	x0, sp, #104
	add	x1, x20, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_25
; %bb.33:                               ;   in Loop: Header=BB4_29 Depth=1
	ldrb	w8, [sp, #15]
	cmp	w8, #0
	cset	w8, ne
	strb	w8, [x20, #1]
	add	x22, x22, #1
	ldr	w23, [sp, #96]
	add	x20, x20, #8
	cmp	x22, x23
	b.lo	LBB4_29
; %bb.34:
	cbz	x19, LBB4_38
; %bb.35:
	cbz	w23, LBB4_38
; %bb.36:
	lsl	x2, x23, #3
	add	x1, sp, #136
	mov	x0, x19
	bl	_memcpy
	b	LBB4_38
LBB4_37:
	mov	w23, #0                         ; =0x0
LBB4_38:
	mov	w0, #0                          ; =0x0
	str	w23, [x21]
	b	LBB4_25
LBB4_39:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_effect   ; -- Begin function nvm_ownership_effect
	.globl	_nvm_ownership_effect
	.p2align	2
_nvm_ownership_effect:                  ; @nvm_ownership_effect
	.cfi_startproc
; %bb.0:
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	b	_ownership_effect_query
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_effect_query
_ownership_effect_query:                ; @ownership_effect_query
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_25
; %bb.1:
	cbnz	x2, LBB6_4
; %bb.2:
	cbnz	x3, LBB6_4
; %bb.3:
	cbz	x4, LBB6_25
LBB6_4:
	cbz	x2, LBB6_6
; %bb.5:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB6_25
LBB6_6:
	sub	sp, sp, #240
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x25, x4
	mov	x21, x1
	mov	x20, x2
	mov	x19, x3
	sub	x1, x29, #65
	mov	x22, x0
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB6_27
; %bb.7:
	ldr	w2, [x22, #304]
	cbz	w2, LBB6_26
; %bb.8:
	ldr	x1, [x22, #296]
	sub	x0, x29, #96
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB6_27
; %bb.9:
	ldur	w8, [x29, #-100]
	cmp	w8, #3
	b.ne	LBB6_26
; %bb.10:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	cbnz	w0, LBB6_27
; %bb.11:
	ldur	w1, [x29, #-104]
	sub	x0, x29, #96
	add	x2, sp, #112
	bl	_nvm_v2_take
	cbnz	w0, LBB6_27
; %bb.12:
	sub	x0, x29, #96
	bl	_nvm_v2_align4
	cbnz	w0, LBB6_27
; %bb.13:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	cbnz	w0, LBB6_27
; %bb.14:
	ldur	w8, [x29, #-104]
	cbz	w8, LBB6_20
; %bb.15:
	mov	w23, #0                         ; =0x0
LBB6_16:                                ; =>This Inner Loop Header: Depth=1
	sub	x0, x29, #96
	add	x1, sp, #32
	bl	_nvm_v2_u16
	cbnz	w0, LBB6_27
; %bb.17:                               ;   in Loop: Header=BB6_16 Depth=1
	sub	x0, x29, #96
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB6_27
; %bb.18:                               ;   in Loop: Header=BB6_16 Depth=1
	ldrh	w8, [sp, #32]
	lsl	x8, x8, #3
	sub	x0, x29, #96
	add	x1, x8, #8
	add	x2, sp, #104
	bl	_nvm_v2_take
	cbnz	w0, LBB6_27
; %bb.19:                               ;   in Loop: Header=BB6_16 Depth=1
	add	w23, w23, #1
	ldur	w8, [x29, #-104]
	cmp	w23, w8
	b.lo	LBB6_16
LBB6_20:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	sub	x0, x29, #96
	add	x5, sp, #32
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_extension_suffix_read_map
	cbnz	w0, LBB6_27
; %bb.21:
	ldr	x24, [sp, #80]
	cbz	x24, LBB6_26
; %bb.22:
	stp	xzr, xzr, [sp, #16]
	ldr	x0, [x22, #312]
	ldr	w1, [x22, #320]
	add	x2, sp, #16
	bl	_nvm_v2_layouts_decode
	mov	x23, x0
	cbnz	w0, LBB6_24
; %bb.23:
	ldr	x4, [sp, #112]
	ldr	x1, [sp, #88]
	str	x25, [sp]
	add	x3, sp, #16
	mov	x0, x24
	mov	x2, x22
	mov	x5, x21
	mov	x6, x20
	mov	x7, x19
	bl	_effects_read
	mov	x23, x0
	add	x0, sp, #16
	bl	_nvm_v2_layouts_free
LBB6_24:
	mov	x0, x23
	b	LBB6_27
LBB6_25:
	mov	w0, #13                         ; =0xd
	ret
LBB6_26:
	mov	w0, #13                         ; =0xd
LBB6_27:
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_effect_types ; -- Begin function nvm_ownership_effect_types
	.globl	_nvm_ownership_effect_types
	.p2align	2
_nvm_ownership_effect_types:            ; @nvm_ownership_effect_types
	.cfi_startproc
; %bb.0:
	mov	x3, x1
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	b	_ownership_effect_query
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_array_constructor ; -- Begin function nvm_ownership_array_constructor
	.globl	_nvm_ownership_array_constructor
	.p2align	2
_nvm_ownership_array_constructor:       ; @nvm_ownership_array_constructor
	.cfi_startproc
; %bb.0:
	mov	w8, #13                         ; =0xd
	cbz	x0, LBB8_8
; %bb.1:
	cbz	x3, LBB8_8
; %bb.2:
	ldr	x8, [x0, #256]
	cbz	x8, LBB8_9
; %bb.3:
	ldr	w9, [x0, #272]
	cmp	w1, w9
	b.hs	LBB8_9
; %bb.4:
	mov	w9, #24                         ; =0x18
	umaddl	x8, w1, w9, x8
	ldr	w8, [x8, #12]
	cmp	w2, w8
	b.hs	LBB8_9
; %bb.5:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x3
	stp	w1, w2, [sp, #4]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]
	add	x4, sp, #4
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_ownership_effect_query
	mov	x8, x0
	cbnz	w0, LBB8_7
; %bb.6:
	ldr	w9, [sp, #12]
	str	w9, [x19]
LBB8_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB8_8:
	mov	x0, x8
	ret
LBB8_9:
	mov	w0, #13                         ; =0xd
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_union_variant ; -- Begin function nvm_ownership_union_variant
	.globl	_nvm_ownership_union_variant
	.p2align	2
_nvm_ownership_union_variant:           ; @nvm_ownership_union_variant
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #13                         ; =0xd
	cbz	x8, LBB9_15
; %bb.1:
	cbz	x3, LBB9_15
; %bb.2:
	ldr	x9, [x8, #296]
	cbz	x9, LBB9_15
; %bb.3:
	ldr	x9, [x8, #312]
	cbz	x9, LBB9_15
; %bb.4:
	sub	sp, sp, #256
	stp	x24, x23, [sp, #192]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #208]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #224]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #240]            ; 16-byte Folded Spill
	add	x29, sp, #240
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x2
	mov	x22, x3
	sub	x1, x29, #49
	mov	x21, x8
	mov	x0, x8
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB9_14
; %bb.5:
	sub	x8, x29, #72
	stp	xzr, xzr, [x8]
	ldr	x0, [x21, #312]
	ldr	w1, [x21, #320]
	sub	x2, x29, #72
	bl	_nvm_v2_layouts_decode
	cbnz	w0, LBB9_14
; %bb.6:
	ldr	x1, [x21, #296]
	ldr	w2, [x21, #304]
	sub	x0, x29, #96
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB9_12
; %bb.7:
	ldur	w8, [x29, #-100]
	cmp	w8, #3
	b.ne	LBB9_12
; %bb.8:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	cbnz	w0, LBB9_12
; %bb.9:
	ldur	w1, [x29, #-104]
	sub	x0, x29, #96
	add	x2, sp, #120
	bl	_nvm_v2_take
	cbnz	w0, LBB9_12
; %bb.10:
	sub	x0, x29, #96
	bl	_nvm_v2_align4
	cbnz	w0, LBB9_12
; %bb.11:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	cbz	w0, LBB9_16
LBB9_12:
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w19, w8, w0, eq
LBB9_13:
	sub	x0, x29, #72
	bl	_nvm_v2_layouts_free
	mov	x0, x19
LBB9_14:
	ldp	x29, x30, [sp, #240]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #224]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #208]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #256
LBB9_15:
	ret
LBB9_16:
	ldur	w8, [x29, #-104]
	cbz	w8, LBB9_22
; %bb.17:
	mov	w23, #0                         ; =0x0
LBB9_18:                                ; =>This Inner Loop Header: Depth=1
	sub	x0, x29, #96
	add	x1, sp, #118
	bl	_nvm_v2_u16
	cbnz	w0, LBB9_23
; %bb.19:                               ;   in Loop: Header=BB9_18 Depth=1
	sub	x0, x29, #96
	add	x1, sp, #116
	bl	_nvm_v2_u16
	cbnz	w0, LBB9_23
; %bb.20:                               ;   in Loop: Header=BB9_18 Depth=1
	ldrh	w8, [sp, #118]
	lsl	x8, x8, #3
	sub	x0, x29, #96
	add	x1, x8, #8
	sub	x2, x29, #112
	bl	_nvm_v2_take
	cbnz	w0, LBB9_23
; %bb.21:                               ;   in Loop: Header=BB9_18 Depth=1
	add	w23, w23, #1
	ldur	w8, [x29, #-104]
	cmp	w23, w8
	b.lo	LBB9_18
LBB9_22:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	sub	x0, x29, #96
	add	x5, sp, #48
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_extension_suffix_read_map
	cbz	w0, LBB9_24
LBB9_23:
	mov	x19, x0
	b	LBB9_13
LBB9_24:
	ldr	x1, [sp, #48]
	cbz	x1, LBB9_27
; %bb.25:
	ldr	w2, [sp, #56]
	add	x0, sp, #24
	bl	_nvm_v2_cursor_init
	ldr	x3, [sp, #120]
	add	x0, sp, #24
	sub	x2, x29, #72
	add	x6, sp, #12
	mov	x1, x21
	mov	x4, x20
	mov	x5, x19
	mov	x7, #0                          ; =0x0
	bl	_union_facts_read
	mov	x19, x0
	cbnz	w0, LBB9_13
; %bb.26:
	ldur	x8, [sp, #12]
	str	x8, [x22]
	ldr	w8, [sp, #20]
	str	w8, [x22, #8]
	b	LBB9_13
LBB9_27:
	mov	w19, #3                         ; =0x3
	b	LBB9_13
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_facts_read
_union_facts_read:                      ; @union_facts_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x7
	mov	x20, x6
	mov	x26, x5
	mov	x21, x4
	mov	x24, x3
	mov	x23, x2
	mov	x25, x1
	mov	x22, x0
	sub	x1, x29, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_72
; %bb.1:
	ldur	w8, [x29, #-84]
	ldr	w9, [x25, #476]
	cmp	w8, #256
	ccmp	w8, w9, #0, ls
	b.eq	LBB10_3
LBB10_2:
	mov	w0, #13                         ; =0xd
	b	LBB10_72
LBB10_3:
	cbz	w8, LBB10_60
; %bb.4:
	str	xzr, [sp, #80]                  ; 8-byte Folded Spill
	stp	xzr, xzr, [sp, #40]             ; 16-byte Folded Spill
	str	wzr, [sp, #36]                  ; 4-byte Folded Spill
	mov	w27, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	mov	w9, w26
	mov	w8, w21
	stp	x9, x8, [sp, #56]               ; 16-byte Folded Spill
LBB10_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_10 Depth 2
                                        ;     Child Loop BB10_22 Depth 2
                                        ;       Child Loop BB10_30 Depth 3
                                        ;       Child Loop BB10_36 Depth 3
	sub	x1, x29, #88
	mov	x0, x22
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_72
; %bb.6:                                ;   in Loop: Header=BB10_5 Depth=1
	sub	x1, x29, #90
	mov	x0, x22
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_72
; %bb.7:                                ;   in Loop: Header=BB10_5 Depth=1
	sub	x1, x29, #92
	mov	x0, x22
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_72
; %bb.8:                                ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [x23, #8]
	subs	w9, w8, w27
	b.ls	LBB10_59
; %bb.9:                                ;   in Loop: Header=BB10_5 Depth=1
	ldr	x8, [x23]
	mov	w26, w27
	add	x10, x8, w27, uxtw #4
LBB10_10:                               ;   Parent Loop BB10_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w11, [x10], #16
	cmp	w11, #2
	b.eq	LBB10_12
; %bb.11:                               ;   in Loop: Header=BB10_10 Depth=2
	add	x26, x26, #1
	subs	w9, w9, #1
	b.ne	LBB10_10
	b	LBB10_59
LBB10_12:                               ;   in Loop: Header=BB10_5 Depth=1
	ldurh	w9, [x29, #-92]
	mov	w0, #8                          ; =0x8
	cbnz	w9, LBB10_72
; %bb.13:                               ;   in Loop: Header=BB10_5 Depth=1
	str	w28, [sp, #76]                  ; 4-byte Folded Spill
	ldurh	w9, [x29, #-90]
	sub	w10, w9, #1
	ldur	w11, [x29, #-88]
	cmp	w10, #255
	ccmp	w11, w26, #0, ls
	b.ne	LBB10_72
; %bb.14:                               ;   in Loop: Header=BB10_5 Depth=1
	add	x27, x8, w26, uxtw #4
	ldrb	w8, [x27]
	cmp	w8, #2
	b.ne	LBB10_72
; %bb.15:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [x27, #4]
	cmn	w8, #1
	b.eq	LBB10_72
; %bb.16:                               ;   in Loop: Header=BB10_5 Depth=1
	str	x23, [sp, #24]                  ; 8-byte Folded Spill
	cbz	x19, LBB10_21
; %bb.17:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	x8, [x19, #16]
	cbz	x8, LBB10_21
; %bb.18:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [x19, #24]
	mov	w0, #13                         ; =0xd
	ldr	w10, [sp, #76]                  ; 4-byte Folded Reload
	subs	w8, w8, w10
	b.lo	LBB10_72
; %bb.19:                               ;   in Loop: Header=BB10_5 Depth=1
	cmp	w8, w9
	b.lo	LBB10_72
; %bb.20:                               ;   in Loop: Header=BB10_5 Depth=1
	ldp	x8, x10, [x19, #32]
	ldr	w11, [sp, #76]                  ; 4-byte Folded Reload
	ldr	x12, [sp, #80]                  ; 8-byte Folded Reload
	str	w11, [x8, x12, lsl #2]
	strh	w9, [x10, x12, lsl #1]
	ldurh	w8, [x29, #-90]
	cbz	w8, LBB10_55
LBB10_21:                               ;   in Loop: Header=BB10_5 Depth=1
	mov	x28, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	ldr	x8, [x22, #16]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	neg	x8, x8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB10_22:                               ;   Parent Loop BB10_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB10_30 Depth 3
                                        ;       Child Loop BB10_36 Depth 3
	mov	x23, x24
	mov	x24, x19
	mov	x19, x21
	mov	x21, x20
	mov	x20, x9
	add	x1, sp, #96
	mov	x0, x22
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_72
; %bb.23:                               ;   in Loop: Header=BB10_22 Depth=2
	add	x1, sp, #94
	mov	x0, x22
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_72
; %bb.24:                               ;   in Loop: Header=BB10_22 Depth=2
	add	x1, sp, #92
	mov	x0, x22
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_72
; %bb.25:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	w10, [sp, #96]
	ldr	w8, [x25, #248]
	cmp	w10, w8
	b.hs	LBB10_2
; %bb.26:                               ;   in Loop: Header=BB10_22 Depth=2
	ldrh	w8, [sp, #94]
	cmp	w20, w8
	b.ne	LBB10_2
; %bb.27:                               ;   in Loop: Header=BB10_22 Depth=2
	ldrh	w9, [sp, #92]
	ldrh	w11, [x27, #2]
	sub	w11, w11, w20
	cmp	w11, w9
	b.lt	LBB10_2
; %bb.28:                               ;   in Loop: Header=BB10_22 Depth=2
	mov	x20, x21
	mov	x21, x19
	mov	x19, x24
	mov	x24, x23
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x28, LBB10_34
; %bb.29:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	x11, [x22, #8]
	ldp	x12, x14, [sp, #8]              ; 16-byte Folded Reload
	add	x12, x12, x11
	mov	x13, x28
LBB10_30:                               ;   Parent Loop BB10_5 Depth=1
                                        ;     Parent Loop BB10_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov	w0, #9                          ; =0x9
	cmp	x14, x11
	b.hi	LBB10_72
; %bb.31:                               ;   in Loop: Header=BB10_30 Depth=3
	cmp	x12, #4
	b.lo	LBB10_72
; %bb.32:                               ;   in Loop: Header=BB10_30 Depth=3
	ldr	x15, [x22]
	ldr	w15, [x15, x14]
	cmp	w15, w10
	b.eq	LBB10_59
; %bb.33:                               ;   in Loop: Header=BB10_30 Depth=3
	sub	x12, x12, #8
	add	x14, x14, #8
	subs	x13, x13, #1
	b.ne	LBB10_30
LBB10_34:                               ;   in Loop: Header=BB10_22 Depth=2
	cbz	w9, LBB10_48
; %bb.35:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	x13, [x27, #8]
	ldur	w11, [x29, #-88]
	ldrb	w12, [x24, x11]
	mov	w14, #12                        ; =0xc
	umaddl	x13, w8, w14, x13
	add	x13, x13, #4
	mov	x14, x9
LBB10_36:                               ;   Parent Loop BB10_5 Depth=1
                                        ;     Parent Loop BB10_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w16, [x13, #-4]
	sub	w15, w16, #1
	cmp	w15, #4
	b.hi	LBB10_38
; %bb.37:                               ;   in Loop: Header=BB10_36 Depth=3
	ldr	w15, [x13]
	cmn	w15, #1
	cset	w15, eq
	tbz	w12, #0, LBB10_44
	b	LBB10_39
LBB10_38:                               ;   in Loop: Header=BB10_36 Depth=3
	mov	w15, #0                         ; =0x0
	tbz	w12, #0, LBB10_44
LBB10_39:                               ;   in Loop: Header=BB10_36 Depth=3
	ldr	w17, [x13]
	cmp	w17, w11
	b.hs	LBB10_44
; %bb.40:                               ;   in Loop: Header=BB10_36 Depth=3
	ldrb	w0, [x24, x17]
	tbz	w0, #0, LBB10_44
; %bb.41:                               ;   in Loop: Header=BB10_36 Depth=3
	cmp	w16, #10
	b.eq	LBB10_47
; %bb.42:                               ;   in Loop: Header=BB10_36 Depth=3
	cmp	w16, #8
	b.ne	LBB10_44
; %bb.43:                               ;   in Loop: Header=BB10_36 Depth=3
	ldr	x16, [x3]
	lsl	x17, x17, #4
	ldrb	w16, [x16, x17]
	cbz	w16, LBB10_45
LBB10_44:                               ;   in Loop: Header=BB10_36 Depth=3
	mov	w16, #0                         ; =0x0
	orr	w15, w15, w16
	tbz	w15, #0, LBB10_59
LBB10_45:                               ;   in Loop: Header=BB10_36 Depth=3
	ldr	w15, [x13, #4]
	cmn	w15, #1
	b.eq	LBB10_59
; %bb.46:                               ;   in Loop: Header=BB10_36 Depth=3
	add	x13, x13, #12
	subs	x14, x14, #1
	b.ne	LBB10_36
	b	LBB10_48
LBB10_47:                               ;   in Loop: Header=BB10_36 Depth=3
	ldr	x16, [x3]
	lsl	x17, x17, #4
	ldrb	w16, [x16, x17]
	cmp	w16, #2
	cset	w16, eq
	orr	w15, w15, w16
	tbnz	w15, #0, LBB10_45
	b	LBB10_59
LBB10_48:                               ;   in Loop: Header=BB10_22 Depth=2
	cbz	x19, LBB10_51
; %bb.49:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	x11, [x19, #16]
	cbz	x11, LBB10_51
; %bb.50:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	w12, [sp, #76]                  ; 4-byte Folded Reload
	mov	w13, #12                        ; =0xc
	umaddl	x11, w12, w13, x11
	ldur	w12, [x29, #-88]
	stp	w12, w10, [x11]
	strh	w8, [x11, #8]
	strh	w9, [x11, #10]
	ldrh	w8, [sp, #94]
	ldrh	w9, [sp, #92]
LBB10_51:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	cmp	x10, x11
	b.ne	LBB10_54
; %bb.52:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	cmp	x28, x10
	b.ne	LBB10_54
; %bb.53:                               ;   in Loop: Header=BB10_22 Depth=2
	ldur	w11, [x29, #-88]
	mov	w10, #1                         ; =0x1
	stp	w10, w8, [sp, #36]              ; 8-byte Folded Spill
	ldr	w10, [sp, #96]
	stp	w10, w11, [sp, #48]             ; 8-byte Folded Spill
	str	w9, [sp, #44]                   ; 4-byte Folded Spill
LBB10_54:                               ;   in Loop: Header=BB10_22 Depth=2
	ldr	w10, [sp, #76]                  ; 4-byte Folded Reload
	add	w10, w10, #1
	str	w10, [sp, #76]                  ; 4-byte Folded Spill
	add	w9, w9, w8
	add	x28, x28, #1
	ldurh	w8, [x29, #-90]
	cmp	x28, x8
	b.lo	LBB10_22
	b	LBB10_56
LBB10_55:                               ;   in Loop: Header=BB10_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB10_56:                               ;   in Loop: Header=BB10_5 Depth=1
	ldrh	w8, [x27, #2]
	cmp	w9, w8
	b.ne	LBB10_2
; %bb.57:                               ;   in Loop: Header=BB10_5 Depth=1
	add	w27, w26, #1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	add	x9, x9, #1
	ldur	w8, [x29, #-84]
	str	x9, [sp, #80]                   ; 8-byte Folded Spill
	cmp	x9, x8
	ldr	w28, [sp, #76]                  ; 4-byte Folded Reload
	ldr	x23, [sp, #24]                  ; 8-byte Folded Reload
	b.lo	LBB10_5
; %bb.58:
	add	w8, w26, #1
	ldp	w12, w11, [sp, #48]             ; 8-byte Folded Reload
	ldp	w14, w13, [sp, #40]             ; 8-byte Folded Reload
	ldr	w15, [sp, #36]                  ; 4-byte Folded Reload
	b	LBB10_61
LBB10_59:
	mov	w0, #8                          ; =0x8
	b	LBB10_72
LBB10_60:
	mov	w28, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
LBB10_61:
	ldr	w9, [x23, #8]
	subs	w9, w9, w8
	b.ls	LBB10_65
; %bb.62:
	ldr	x10, [x23]
	add	x8, x10, w8, uxtw #4
LBB10_63:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x8], #16
	cmp	w10, #2
	b.eq	LBB10_2
; %bb.64:                               ;   in Loop: Header=BB10_63 Depth=1
	subs	w9, w9, #1
	b.ne	LBB10_63
LBB10_65:
	ldp	x9, x8, [x22, #8]
	cmp	x8, x9
	b.ne	LBB10_71
; %bb.66:
	cmn	w21, #1
	cset	w8, eq
	orr	w8, w8, w15
	tbz	w8, #0, LBB10_2
; %bb.67:
	cmp	x20, #0
	cset	w8, eq
	orn	w8, w8, w15
	tbnz	w8, #0, LBB10_69
; %bb.68:
	stp	w11, w12, [x20]
	strh	w14, [x20, #8]
	strh	w13, [x20, #10]
LBB10_69:
	mov	w0, #0                          ; =0x0
	cbz	x19, LBB10_72
; %bb.70:
	str	w28, [x19, #28]
	b	LBB10_72
LBB10_71:
	mov	w0, #9                          ; =0x9
LBB10_72:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_layout_authority ; -- Begin function nvm_ownership_layout_authority
	.globl	_nvm_ownership_layout_authority
	.p2align	2
_nvm_ownership_layout_authority:        ; @nvm_ownership_layout_authority
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	mov	w0, #13                         ; =0xd
	cmn	w1, #1
	b.eq	LBB11_4
; %bb.1:
	cbz	x19, LBB11_4
; %bb.2:
	cbz	x2, LBB11_4
; %bb.3:
	mov	x21, x1
	mov	x20, x2
	sub	x1, x29, #33
	mov	x0, x19
	bl	_nvm_ownership_contracts_validate
	cbz	w0, LBB11_5
LBB11_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB11_5:
	ldr	w2, [x19, #304]
	cbz	w2, LBB11_11
; %bb.6:
	ldr	x1, [x19, #296]
	add	x0, sp, #16
	bl	_nvm_v2_cursor_init
	add	x0, sp, #16
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB11_4
; %bb.7:
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB11_4
; %bb.8:
	ldr	w1, [sp, #8]
	add	x0, sp, #16
	mov	x2, sp
	bl	_nvm_v2_take
	cbnz	w0, LBB11_4
; %bb.9:
	ldr	w8, [sp, #8]
	cmp	w21, w8
	b.hs	LBB11_13
; %bb.10:
	ldr	x8, [sp]
	ldrb	w8, [x8, w21, uxtw]
	sbfx	w9, w8, #0, #1
	tst	w8, #0x2
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, ne
	and	w8, w9, w8
	b	LBB11_12
LBB11_11:
	mov	w8, #0                          ; =0x0
LBB11_12:
	mov	w0, #0                          ; =0x0
	str	w8, [x20]
	b	LBB11_4
LBB11_13:
	mov	w0, #13                         ; =0xd
	b	LBB11_4
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_layout_authorities ; -- Begin function nvm_ownership_layout_authorities
	.globl	_nvm_ownership_layout_authorities
	.p2align	2
_nvm_ownership_layout_authorities:      ; @nvm_ownership_layout_authorities
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB12_3
; %bb.1:
	cbz	w1, LBB12_4
; %bb.2:
	cbnz	x2, LBB12_4
LBB12_3:
	mov	w0, #13                         ; =0xd
	ret
LBB12_4:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x2
	sub	x1, x29, #33
	mov	x21, x0
	bl	_nvm_ownership_contracts_validate
	cbz	w0, LBB12_6
LBB12_5:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB12_6:
	str	xzr, [sp, #32]
	ldr	w2, [x21, #304]
	cbz	w2, LBB12_12
; %bb.7:
	ldr	x1, [x21, #296]
	add	x0, sp, #8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB12_5
; %bb.8:
	add	x0, sp, #8
	mov	x1, sp
	bl	_nvm_v2_u32
	cbnz	w0, LBB12_5
; %bb.9:
	ldr	w9, [sp]
	cmp	w9, w20
	b.ne	LBB12_19
; %bb.10:
	mov	w1, w20
	add	x0, sp, #8
	add	x2, sp, #32
	bl	_nvm_v2_take
	cbnz	w0, LBB12_5
; %bb.11:
	cbnz	w20, LBB12_13
	b	LBB12_5
LBB12_12:
	cbz	w20, LBB12_18
LBB12_13:
	ldr	x8, [sp, #32]
	mov	w9, w20
	mov	w10, #1                         ; =0x1
	mov	x11, x8
	b	LBB12_16
LBB12_14:                               ;   in Loop: Header=BB12_16 Depth=1
	ldrb	w12, [x11]
	tst	w12, #0x2
	cinc	w13, w10, ne
	tst	w12, #0x1
	csel	w12, wzr, w13, eq
LBB12_15:                               ;   in Loop: Header=BB12_16 Depth=1
	str	w12, [x19], #4
	add	x11, x11, #1
	subs	x9, x9, #1
	b.eq	LBB12_18
LBB12_16:                               ; =>This Inner Loop Header: Depth=1
	cbnz	x8, LBB12_14
; %bb.17:                               ;   in Loop: Header=BB12_16 Depth=1
	mov	w12, #0                         ; =0x0
	b	LBB12_15
LBB12_18:
	mov	w0, #0                          ; =0x0
	b	LBB12_5
LBB12_19:
	mov	w0, #13                         ; =0xd
	b	LBB12_5
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ordinary_array_authority_free ; -- Begin function nvm_ordinary_array_authority_free
	.globl	_nvm_ordinary_array_authority_free
	.p2align	2
_nvm_ordinary_array_authority_free:     ; @nvm_ordinary_array_authority_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB13_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ordinary_array_authority_counts ; -- Begin function nvm_ordinary_array_authority_counts
	.globl	_nvm_ordinary_array_authority_counts
	.p2align	2
_nvm_ordinary_array_authority_counts:   ; @nvm_ordinary_array_authority_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB14_2
; %bb.1:
	ldr	w9, [x8, #8]
	ldr	d0, [x8, #288]
	str	w9, [x1]
	stur	d0, [x1, #4]
LBB14_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ordinary_array_authority_type ; -- Begin function nvm_ordinary_array_authority_type
	.globl	_nvm_ordinary_array_authority_type
	.p2align	2
_nvm_ordinary_array_authority_type:     ; @nvm_ordinary_array_authority_type
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB15_5
; %bb.1:
	cbz	x2, LBB15_5
; %bb.2:
	ldr	w9, [x8, #288]
	cmp	w1, w9
	b.hs	LBB15_4
; %bb.3:
	ldr	x8, [x8, #16]
	ldr	x8, [x8, w1, uxtw #3]
	str	x8, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB15_4:
	mov	w0, #0                          ; =0x0
LBB15_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ordinary_array_authority_binding ; -- Begin function nvm_ordinary_array_authority_binding
	.globl	_nvm_ordinary_array_authority_binding
	.p2align	2
_nvm_ordinary_array_authority_binding:  ; @nvm_ordinary_array_authority_binding
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB16_5
; %bb.1:
	cbz	x2, LBB16_5
; %bb.2:
	ldr	w9, [x8, #292]
	cmp	w1, w9
	b.hs	LBB16_4
; %bb.3:
	ldr	x8, [x8, #24]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB16_4:
	mov	w0, #0                          ; =0x0
LBB16_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_describe_ordinary_array_authority ; -- Begin function nvm_describe_ordinary_array_authority
	.globl	_nvm_describe_ordinary_array_authority
	.p2align	2
_nvm_describe_ordinary_array_authority: ; @nvm_describe_ordinary_array_authority
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	b	_oaa_prepare_map
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_free ; -- Begin function nvm_ownership_declarations_free
	.globl	_nvm_ownership_declarations_free
	.p2align	2
_nvm_ownership_declarations_free:       ; @nvm_ownership_declarations_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB18_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB18_3
; %bb.2:
	mov	x0, x20
	bl	_nvm_v2_layouts_free
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #24]
	bl	_free
	mov	x0, x20
	bl	_free
LBB18_3:
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB18_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_ownership_declarations ; -- Begin function nvm_prepare_ownership_declarations
	.globl	_nvm_prepare_ownership_declarations
	.p2align	2
_nvm_prepare_ownership_declarations:    ; @nvm_prepare_ownership_declarations
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	b	_prepare_ownership_declarations_map
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function prepare_ownership_declarations_map
_prepare_ownership_declarations_map:    ; @prepare_ownership_declarations_map
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB20_5
; %bb.1:
	sub	sp, sp, #192
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x3, x2
	mov	x23, x1
	str	xzr, [sp, #112]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #80]
	str	q0, [sp, #64]
	str	xzr, [sp, #56]
	add	x8, sp, #32
	add	x1, sp, #56
	add	x2, sp, #64
	mov	x20, x0
	bl	_oaa_prepare_map
	ldr	w0, [sp, #32]
	cmp	w0, #2
	b.gt	LBB20_6
; %bb.2:
	cbz	w0, LBB20_9
; %bb.3:
	cmp	w0, #1
	b.ne	LBB20_29
; %bb.4:
Lloh18:
	adrp	x1, l_.str.5@PAGE
Lloh19:
	add	x1, x1, l_.str.5@PAGEOFF
	mov	w0, #1                          ; =0x1
	b	LBB20_30
LBB20_5:
Lloh20:
	adrp	x1, l_.str.2@PAGE
Lloh21:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	w0, #2                          ; =0x2
	ret
LBB20_6:
	cmp	w0, #3
	b.eq	LBB20_12
; %bb.7:
	cmp	w0, #4
	b.ne	LBB20_29
LBB20_8:
Lloh22:
	adrp	x1, l_.str.8@PAGE
Lloh23:
	add	x1, x1, l_.str.8@PAGEOFF
	mov	w0, #4                          ; =0x4
	b	LBB20_30
LBB20_9:
	ldr	x19, [sp, #56]
	ldr	w9, [x19, #8]
	lsl	x8, x9, #4
	add	x8, x8, #312
	cbz	w9, LBB20_18
; %bb.10:
	ldr	x10, [x19]
	cmp	w9, #4
	b.hs	LBB20_13
; %bb.11:
	mov	x11, #0                         ; =0x0
	b	LBB20_16
LBB20_12:
Lloh24:
	adrp	x1, l_.str.7@PAGE
Lloh25:
	add	x1, x1, l_.str.7@PAGEOFF
	b	LBB20_30
LBB20_13:
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x11, x9, #0xfffffffc
	add	x15, x10, #34
	mov	w16, #12                        ; =0xc
	mov	x17, x11
LBB20_14:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w0, [x15, #-32]
	ldurh	w1, [x15, #-16]
	ldrh	w2, [x15]
	ldrh	w3, [x15, #16]
	umaddl	x8, w0, w16, x8
	umaddl	x12, w1, w16, x12
	umaddl	x13, w2, w16, x13
	umaddl	x14, w3, w16, x14
	add	x15, x15, #64
	subs	x17, x17, #4
	b.ne	LBB20_14
; %bb.15:
	add	x8, x12, x8
	add	x12, x14, x13
	add	x8, x12, x8
	cmp	x11, x9
	b.eq	LBB20_18
LBB20_16:
	add	x10, x10, x11, lsl #4
	add	x10, x10, #2
	sub	x9, x9, x11
	mov	w11, #12                        ; =0xc
LBB20_17:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w12, [x10], #16
	umaddl	x8, w12, w11, x8
	subs	x9, x9, #1
	b.ne	LBB20_17
LBB20_18:
	ldr	w22, [sp, #92]
	cmp	w22, #16, lsl #12               ; =65536
	b.hi	LBB20_26
; %bb.19:
	ldr	w9, [x19, #288]
	add	x8, x8, x9, lsl #3
	ldr	w9, [x19, #292]
	mov	w10, #12                        ; =0xc
	umaddl	x8, w9, w10, x8
	add	x9, x22, w22, uxtw #1
	lsl	x9, x9, #2
	mov	w10, #63976                     ; =0xf9e8
	movk	w10, #255, lsl #16
	sub	x11, x10, x8
	cmp	x10, x8
	ccmp	x9, x11, #2, hs
	b.hi	LBB20_26
; %bb.20:
	mov	w0, #1                          ; =0x1
	mov	w1, #1560                       ; =0x618
	bl	_calloc
	cbz	x0, LBB20_27
; %bb.21:
	mov	x21, x0
	str	x19, [x0]
	ldr	w8, [x20, #476]
	stp	w8, w22, [x0, #16]
	cbz	w22, LBB20_25
; %bb.22:
	mov	x0, x22
	mov	w1, #12                         ; =0xc
	bl	_calloc
	str	x0, [x21, #8]
	cbz	x0, LBB20_31
; %bb.23:
	str	x0, [sp, #80]
	str	w22, [sp, #88]
	add	x8, x21, #24
	add	x9, x21, #1048
	stp	x8, x9, [sp, #96]
	ldr	x1, [sp, #64]
	ldr	w2, [sp, #72]
	add	x0, sp, #8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x3, x19, #32
	add	x7, sp, #64
	mov	x1, x20
	mov	x2, x19
	mov	w4, #-1                         ; =0xffffffff
	mov	w5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_union_facts_read
	cbnz	w0, LBB20_28
; %bb.24:
	ldr	w8, [sp, #92]
	ldr	w9, [x21, #20]
	cmp	w8, w9
	b.ne	LBB20_28
LBB20_25:
	mov	x0, #0                          ; =0x0
	str	x21, [x23]
Lloh26:
	adrp	x1, l_.str.6@PAGE
Lloh27:
	add	x1, x1, l_.str.6@PAGEOFF
	b	LBB20_30
LBB20_26:
	mov	x0, x19
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	mov	x0, x19
	bl	_free
Lloh28:
	adrp	x1, l_.str.7@PAGE
Lloh29:
	add	x1, x1, l_.str.7@PAGEOFF
	mov	w0, #3                          ; =0x3
	b	LBB20_30
LBB20_27:
	mov	x0, x19
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	mov	x0, x19
	bl	_free
	b	LBB20_8
LBB20_28:
	mov	x0, x21
	bl	_nvm_ownership_declarations_free
LBB20_29:
Lloh30:
	adrp	x1, l_.str.2@PAGE
Lloh31:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	w0, #2                          ; =0x2
LBB20_30:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB20_31:
	mov	x0, x21
	bl	_nvm_ownership_declarations_free
	b	LBB20_8
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_counts ; -- Begin function nvm_ownership_declarations_counts
	.globl	_nvm_ownership_declarations_counts
	.p2align	2
_nvm_ownership_declarations_counts:     ; @nvm_ownership_declarations_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB21_2
; %bb.1:
	ldr	x9, [x8]
	ldr	w10, [x9, #8]
	ldr	d0, [x9, #288]
	ldr	d1, [x8, #16]
	str	w10, [x1]
	mov.d	v0[1], v1[0]
	stur	q0, [x1, #4]
LBB21_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_layout ; -- Begin function nvm_ownership_declarations_layout
	.globl	_nvm_ownership_declarations_layout
	.p2align	2
_nvm_ownership_declarations_layout:     ; @nvm_ownership_declarations_layout
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB22_4
; %bb.1:
	cbz	x2, LBB22_4
; %bb.2:
	ldr	x8, [x8]
	ldr	w9, [x8, #8]
	cmp	w1, w9
	b.hs	LBB22_5
; %bb.3:
	ldr	x9, [x8]
	add	x9, x9, w1, uxtw #4
	ldrb	w10, [x9]
	add	x8, x8, w1, uxtw
	ldrb	w8, [x8, #32]
	ldrh	w11, [x9, #2]
	ldr	w9, [x9, #4]
	strb	w10, [x2]
	strb	w8, [x2, #1]
	strh	w11, [x2, #2]
	str	w9, [x2, #4]
	mov	w0, #1                          ; =0x1
LBB22_4:
	ret
LBB22_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_field ; -- Begin function nvm_ownership_declarations_field
	.globl	_nvm_ownership_declarations_field
	.p2align	2
_nvm_ownership_declarations_field:      ; @nvm_ownership_declarations_field
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB23_5
; %bb.1:
	cbz	x3, LBB23_5
; %bb.2:
	ldr	x8, [x8]
	ldr	w9, [x8, #8]
	cmp	w1, w9
	b.hs	LBB23_6
; %bb.3:
	ldr	x8, [x8]
	add	x8, x8, w1, uxtw #4
	ldrh	w9, [x8, #2]
	cmp	w2, w9
	b.hs	LBB23_6
; %bb.4:
	ldr	x8, [x8, #8]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w2, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x3, #8]
	str	x9, [x3]
	mov	w0, #1                          ; =0x1
LBB23_5:
	ret
LBB23_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_type ; -- Begin function nvm_ownership_declarations_type
	.globl	_nvm_ownership_declarations_type
	.p2align	2
_nvm_ownership_declarations_type:       ; @nvm_ownership_declarations_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB24_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB24_5
; %bb.3:
	ldr	w9, [x8, #288]
	cmp	w1, w9
	b.hs	LBB24_6
; %bb.4:
	ldr	x8, [x8, #16]
	ldr	x8, [x8, w1, uxtw #3]
	str	x8, [x2]
	mov	w0, #1                          ; =0x1
LBB24_5:
	ret
LBB24_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_binding ; -- Begin function nvm_ownership_declarations_binding
	.globl	_nvm_ownership_declarations_binding
	.p2align	2
_nvm_ownership_declarations_binding:    ; @nvm_ownership_declarations_binding
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB25_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB25_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB25_5
; %bb.3:
	ldr	w9, [x8, #292]
	cmp	w1, w9
	b.hs	LBB25_6
; %bb.4:
	ldr	x8, [x8, #24]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB25_5:
	ret
LBB25_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_variant ; -- Begin function nvm_ownership_declarations_variant
	.globl	_nvm_ownership_declarations_variant
	.p2align	2
_nvm_ownership_declarations_variant:    ; @nvm_ownership_declarations_variant
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB26_6
; %bb.1:
	cbz	x3, LBB26_6
; %bb.2:
	ldr	w8, [x0, #16]
	cmp	w1, w8
	b.hs	LBB26_5
; %bb.3:
	add	x8, x0, w1, uxtw #1
	ldrh	w8, [x8, #1048]
	cmp	w2, w8
	b.hs	LBB26_5
; %bb.4:
	mov	w8, w1
	ldr	x9, [x0, #8]
	add	x8, x0, x8, lsl #2
	ldr	w8, [x8, #24]
	add	w8, w8, w2
	mov	w10, #12                        ; =0xc
	umaddl	x8, w8, w10, x9
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x3, #8]
	str	x9, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB26_5:
	mov	w8, #0                          ; =0x0
LBB26_6:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_declarations_retained_cost ; -- Begin function nvm_ownership_declarations_retained_cost
	.globl	_nvm_ownership_declarations_retained_cost
	.p2align	2
_nvm_ownership_declarations_retained_cost: ; @nvm_ownership_declarations_retained_cost
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB27_4
; %bb.1:
	ldrb	w8, [x1, #16]
	tbnz	w8, #0, LBB27_3
; %bb.2:
	ldp	x9, x10, [x1]
	subs	x8, x10, x9
	ccmp	x8, #15, #0, hs
	b.hi	LBB27_6
LBB27_3:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
LBB27_4:
	mov	w0, #2                          ; =0x2
LBB27_5:
	ret
LBB27_6:
	add	x11, x9, #16
	str	x11, [x1]
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB27_5
; %bb.7:
	cbz	x2, LBB27_5
; %bb.8:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x22, x8
	ldr	x20, [x22]
	cbz	x20, LBB27_14
; %bb.9:
	mov	x8, x22
	ldr	w12, [x22, #16]
	cmp	w12, #256
	b.hi	LBB27_14
; %bb.10:
	ldr	w8, [x8, #20]
	cmp	w8, #16, lsl #12                ; =65536
	b.hi	LBB27_14
; %bb.11:
	ldr	w8, [x20, #8]
	cmp	w8, #256
	b.hi	LBB27_14
; %bb.12:
	ldr	w12, [x20, #288]
	cmp	w12, #1, lsl #12                ; =4096
	b.hi	LBB27_14
; %bb.13:
	ldr	w12, [x20, #292]
	cmp	w12, #16, lsl #12               ; =65536
	b.ls	LBB27_16
LBB27_14:
	mov	w0, #1                          ; =0x1
LBB27_15:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB27_16:
	subs	x11, x10, x11
	b.lo	LBB27_32
; %bb.17:
	cmp	x11, #3
	b.ls	LBB27_32
; %bb.18:
	add	x11, x9, #20
	str	x11, [x1]
	subs	x10, x10, x11
	b.lo	LBB27_32
; %bb.19:
	cmp	x10, #3
	b.ls	LBB27_32
; %bb.20:
	mov	x21, x2
	add	x9, x9, #24
	str	x9, [x1]
	mov	w9, #1872                       ; =0x750
	str	x9, [sp, #8]
	ldr	x9, [x20]
	add	x4, sp, #8
	mov	x19, x1
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
	mov	w3, #16                         ; =0x10
	bl	_nvm_map_copy_term
	cbnz	w0, LBB27_15
; %bb.21:
	ldr	x1, [x22, #8]
	ldr	w2, [x22, #20]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #12                         ; =0xc
	bl	_nvm_map_copy_term
	cbnz	w0, LBB27_15
; %bb.22:
	ldr	x1, [x20, #16]
	str	x20, [sp]                       ; 8-byte Folded Spill
	ldr	w2, [x20, #288]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #8                          ; =0x8
	bl	_nvm_map_copy_term
	cbnz	w0, LBB27_15
; %bb.23:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [x8, #24]
	ldr	w2, [x8, #292]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #12                         ; =0xc
	bl	_nvm_map_copy_term
	cbnz	w0, LBB27_15
; %bb.24:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	cbz	w8, LBB27_31
; %bb.25:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w25, #65536                     ; =0x10000
LBB27_26:                               ; =>This Inner Loop Header: Depth=1
	mov	x8, x19
	ldrb	w9, [x19, #16]
	tbnz	w9, #0, LBB27_34
; %bb.27:                               ;   in Loop: Header=BB27_26 Depth=1
	ldp	x9, x10, [x8]
	subs	x10, x10, x9
	ccmp	x10, #7, #0, hs
	b.ls	LBB27_34
; %bb.28:                               ;   in Loop: Header=BB27_26 Depth=1
	add	x9, x9, #8
	str	x9, [x8]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	add	x8, x8, x22
	ldrh	w20, [x8, #2]
	sub	w9, w25, w24
	cmp	w9, w20
	b.lo	LBB27_14
; %bb.29:                               ;   in Loop: Header=BB27_26 Depth=1
	ldr	x1, [x8, #8]
	add	x4, sp, #8
	mov	x0, x19
	mov	x2, x20
	mov	w3, #12                         ; =0xc
	bl	_nvm_map_copy_term
	cbnz	w0, LBB27_15
; %bb.30:                               ;   in Loop: Header=BB27_26 Depth=1
	add	w24, w24, w20
	add	x23, x23, #1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	add	x22, x22, #16
	cmp	x23, x8
	b.lo	LBB27_26
LBB27_31:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp, #8]
	str	x8, [x21]
	b	LBB27_15
LBB27_32:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
LBB27_33:
	mov	w0, #2                          ; =0x2
	b	LBB27_15
LBB27_34:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #16]
	b	LBB27_33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_map_copy_term
_nvm_map_copy_term:                     ; @nvm_map_copy_term
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB28_4
; %bb.1:
	ldrb	w8, [x0, #16]
	tbnz	w8, #0, LBB28_3
; %bb.2:
	ldp	x8, x9, [x0]
	subs	x9, x9, x8
	ccmp	x9, #3, #0, hs
	b.hi	LBB28_5
LBB28_3:
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #16]
LBB28_4:
	mov	w0, #2                          ; =0x2
	ret
LBB28_5:
	add	x8, x8, #4
	str	x8, [x0]
	cmp	x1, #0
	cset	w8, ne
	cmp	x2, #0
	cset	w9, eq
	cmp	w8, w9
	b.eq	LBB28_8
; %bb.6:
	mul	x8, x3, x2
	ldr	x9, [x4]
	cmn	x9, x8
	b.hs	LBB28_4
; %bb.7:
	mov	w0, #0                          ; =0x0
	add	x8, x9, x8
	str	x8, [x4]
	ret
LBB28_8:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_free ; -- Begin function nvm_map_declarations_free
	.globl	_nvm_map_declarations_free
	.p2align	2
_nvm_map_declarations_free:             ; @nvm_map_declarations_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB29_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x0, [x0, #8]
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	ldr	x0, [x19, #32]
	bl	_free
	ldr	x20, [x19]
	cbz	x20, LBB29_5
; %bb.2:
	ldr	x21, [x20]
	cbz	x21, LBB29_4
; %bb.3:
	mov	x0, x21
	bl	_nvm_v2_layouts_free
	ldr	x0, [x21, #16]
	bl	_free
	ldr	x0, [x21, #24]
	bl	_free
	mov	x0, x21
	bl	_free
LBB29_4:
	ldr	x0, [x20, #8]
	bl	_free
	mov	x0, x20
	bl	_free
LBB29_5:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB29_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_map_declarations ; -- Begin function nvm_prepare_map_declarations
	.globl	_nvm_prepare_map_declarations
	.p2align	2
_nvm_prepare_map_declarations:          ; @nvm_prepare_map_declarations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x28, x27, [sp, #144]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x1, LBB30_37
; %bb.1:
	cbz	x0, LBB30_37
; %bb.2:
	ldr	x9, [x0, #312]
	ldr	w2, [x0, #320]
	cmp	x2, #0
	cset	w8, eq
	cmp	x9, #0
	cset	w10, ne
	cmp	w10, w8
	b.eq	LBB30_37
; %bb.3:
	ldr	x8, [x0, #296]
	ldr	w10, [x0, #304]
	cmp	w10, #0
	cset	w11, eq
	cmp	x8, #0
	cset	w8, ne
	cmp	w8, w11
	b.eq	LBB30_37
; %bb.4:
	mov	x21, #0                         ; =0x0
	orr	w11, w10, w2
	mov	w8, #2                          ; =0x2
	cmp	w11, #0
	csel	w8, wzr, w8, eq
	cbz	w10, LBB30_32
; %bb.5:
	cbz	w2, LBB30_32
; %bb.6:
	cbz	w11, LBB30_32
; %bb.7:
Lloh32:
	adrp	x8, l_.str.12@PAGE
Lloh33:
	add	x8, x8, l_.str.12@PAGEOFF
	mov	w19, #3                         ; =0x3
	mov	w11, #16777216                  ; =0x1000000
	cmp	w2, w11
	b.hi	LBB30_38
; %bb.8:
	cmp	w10, w11
	b.hi	LBB30_38
; %bb.9:
	add	w21, w10, w2
	cmp	w21, #1024, lsl #12             ; =4194304
	b.hi	LBB30_36
; %bb.10:
	mov	x19, x0
	mov	x20, x1
	sub	x0, x29, #104
	mov	x1, x9
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #104
	sub	x1, x29, #108
	bl	_nvm_v2_u32
	cbz	w0, LBB30_14
LBB30_11:
	mov	w8, #2                          ; =0x2
LBB30_12:
	mov	x1, x20
LBB30_13:
	mov	x0, x19
	b	LBB30_32
LBB30_14:
	ldur	w8, [x29, #-108]
	cmp	w8, #256
	mov	x1, x20
	b.ls	LBB30_16
; %bb.15:
	mov	x0, x19
	mov	w8, #3                          ; =0x3
	b	LBB30_32
LBB30_16:
	cbz	w8, LBB30_51
; %bb.17:
	mov	w23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	w25, #65536                     ; =0x10000
LBB30_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB30_24 Depth 2
	sub	x0, x29, #104
	add	x2, sp, #104
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB30_11
; %bb.19:                               ;   in Loop: Header=BB30_18 Depth=1
	ldr	x8, [sp, #104]
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB30_11
; %bb.20:                               ;   in Loop: Header=BB30_18 Depth=1
	ldrb	w9, [x8]
	cmp	w9, #3
	b.hi	LBB30_11
; %bb.21:                               ;   in Loop: Header=BB30_18 Depth=1
	ldrh	w26, [x8, #2]
	sub	w8, w25, w24
	cmp	w26, w8
	b.hi	LBB30_92
; %bb.22:                               ;   in Loop: Header=BB30_18 Depth=1
	cbz	w26, LBB30_30
; %bb.23:                               ;   in Loop: Header=BB30_18 Depth=1
	mov	w27, #0                         ; =0x0
LBB30_24:                               ;   Parent Loop BB30_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x0, x29, #104
	add	x2, sp, #104
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cbnz	w0, LBB30_11
; %bb.25:                               ;   in Loop: Header=BB30_24 Depth=2
	ldr	x9, [sp, #104]
	ldrb	w8, [x9]
	cmp	w8, #15
	mov	x1, x20
	mov	x0, x19
	b.hi	LBB30_31
; %bb.26:                               ;   in Loop: Header=BB30_24 Depth=2
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB30_31
; %bb.27:                               ;   in Loop: Header=BB30_24 Depth=2
	ldrb	w10, [x9, #2]
	cbnz	w10, LBB30_31
; %bb.28:                               ;   in Loop: Header=BB30_24 Depth=2
	ldrb	w9, [x9, #3]
	cbnz	w9, LBB30_31
; %bb.29:                               ;   in Loop: Header=BB30_24 Depth=2
	cmp	w8, #13
	cset	w8, eq
	orr	w22, w22, w8
	add	w27, w27, #1
	cmp	w27, w26
	b.lo	LBB30_24
LBB30_30:                               ;   in Loop: Header=BB30_18 Depth=1
	add	w24, w26, w24
	add	w23, w23, #1
	ldur	w8, [x29, #-108]
	cmp	w23, w8
	mov	x1, x20
	b.lo	LBB30_18
	b	LBB30_52
LBB30_31:
	mov	w8, #2                          ; =0x2
LBB30_32:
	cbz	w8, LBB30_44
; %bb.33:
	cmp	w8, #1
	b.eq	LBB30_39
; %bb.34:
	cmp	w8, #3
	b.ne	LBB30_37
; %bb.35:
Lloh34:
	adrp	x8, l_.str.12@PAGE
Lloh35:
	add	x8, x8, l_.str.12@PAGEOFF
LBB30_36:
	mov	w19, #3                         ; =0x3
	b	LBB30_38
LBB30_37:
Lloh36:
	adrp	x8, l_.str.9@PAGE
Lloh37:
	add	x8, x8, l_.str.9@PAGEOFF
	mov	w19, #2                         ; =0x2
LBB30_38:
	mov	x0, x19
	mov	x1, x8
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
LBB30_39:
	mov	x19, x0
	mov	x22, x1
	mov	w0, #1                          ; =0x1
	mov	w1, #80                         ; =0x50
	bl	_calloc
	cbz	x0, LBB30_43
; %bb.40:
	mov	x20, x0
	mov	w8, #80                         ; =0x50
	stp	x8, x21, [x0, #56]
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #72]
	mov	x0, x19
	mov	x1, x20
	mov	x2, x20
	bl	_prepare_ownership_declarations_map
	cbz	w0, LBB30_45
; %bb.41:
	cmp	w0, #4
	b.ne	LBB30_46
; %bb.42:
	mov	x0, x20
	bl	_nvm_map_declarations_free
LBB30_43:
Lloh38:
	adrp	x8, l_.str.13@PAGE
Lloh39:
	add	x8, x8, l_.str.13@PAGEOFF
	mov	w19, #4                         ; =0x4
	b	LBB30_38
LBB30_44:
	mov	w19, w8
Lloh40:
	adrp	x8, l_.str.10@PAGE
Lloh41:
	add	x8, x8, l_.str.10@PAGEOFF
	b	LBB30_38
LBB30_45:
	str	x20, [x22]
Lloh42:
	adrp	x8, l_.str.11@PAGE
Lloh43:
	add	x8, x8, l_.str.11@PAGEOFF
	mov	w19, #1                         ; =0x1
	b	LBB30_38
LBB30_46:
	ldr	w19, [x20, #72]
	mov	x21, x0
	mov	x0, x20
	bl	_nvm_map_declarations_free
	cmp	w21, #3
	b.ne	LBB30_48
; %bb.47:
Lloh44:
	adrp	x8, l_.str.12@PAGE
Lloh45:
	add	x8, x8, l_.str.12@PAGEOFF
	mov	w19, #3                         ; =0x3
	b	LBB30_38
LBB30_48:
Lloh46:
	adrp	x8, l_.str.9@PAGE
Lloh47:
	add	x8, x8, l_.str.9@PAGEOFF
	cmp	w19, #4
	b.hi	LBB30_38
; %bb.49:
	mov	w9, #27                         ; =0x1b
	lsr	w9, w9, w19
	tbz	w9, #0, LBB30_38
; %bb.50:
Lloh48:
	adrp	x9, l_switch.table.nvm_prepare_map_declarations@PAGE
Lloh49:
	add	x9, x9, l_switch.table.nvm_prepare_map_declarations@PAGEOFF
Lloh50:
	adrp	x8, l_switch.table.nvm_prepare_map_declarations.19@PAGE
Lloh51:
	add	x8, x8, l_switch.table.nvm_prepare_map_declarations.19@PAGEOFF
	ldr	x8, [x8, x19, lsl #3]
	ldr	x19, [x9, x19, lsl #3]
	b	LBB30_38
LBB30_51:
	mov	w22, #0                         ; =0x0
LBB30_52:
	ldp	x9, x8, [x29, #-96]
	cmp	x8, x9
	b.ne	LBB30_91
; %bb.53:
	ldr	x1, [x19, #296]
	ldr	w2, [x19, #304]
	sub	x0, x29, #104
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #104
	add	x1, sp, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB30_11
; %bb.54:
	ldr	w8, [sp, #100]
	sub	w8, w8, #1
	cmp	w8, #2
	b.hi	LBB30_11
; %bb.55:
	sub	x0, x29, #104
	add	x1, sp, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB30_11
; %bb.56:
	ldr	w1, [sp, #96]
	ldur	w8, [x29, #-108]
	cmp	w1, w8
	b.ne	LBB30_11
; %bb.57:
	sub	x0, x29, #104
	add	x2, sp, #104
	bl	_nvm_v2_take
	cbnz	w0, LBB30_11
; %bb.58:
	ldr	w8, [sp, #96]
	cbz	w8, LBB30_62
; %bb.59:
	ldr	x9, [sp, #104]
LBB30_60:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	cmp	w10, #4
	b.hs	LBB30_11
; %bb.61:                               ;   in Loop: Header=BB30_60 Depth=1
	subs	x8, x8, #1
	b.ne	LBB30_60
LBB30_62:
	sub	x0, x29, #104
	bl	_nvm_v2_align4
	cbnz	w0, LBB30_11
; %bb.63:
	sub	x0, x29, #104
	add	x1, sp, #92
	bl	_nvm_v2_u32
	cbnz	w0, LBB30_11
; %bb.64:
	ldr	w8, [sp, #92]
	ldr	w9, [x19, #272]
	cmp	w8, w9
	b.ne	LBB30_11
; %bb.65:
	cbz	w8, LBB30_81
; %bb.66:
	ldr	x8, [x19, #256]
	cbz	x8, LBB30_11
; %bb.67:
	mov	x23, #0                         ; =0x0
	mov	w24, #24                        ; =0x18
LBB30_68:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB30_75 Depth 2
	sub	x0, x29, #104
	mov	x1, sp
	bl	_nvm_v2_u16
	cbnz	w0, LBB30_11
; %bb.69:                               ;   in Loop: Header=BB30_68 Depth=1
	sub	x0, x29, #104
	add	x1, sp, #72
	bl	_nvm_v2_u16
	cbnz	w0, LBB30_11
; %bb.70:                               ;   in Loop: Header=BB30_68 Depth=1
	ldrh	w8, [sp]
	ldr	x9, [x19, #256]
	madd	x9, x23, x24, x9
	ldrh	w10, [x9, #16]
	cmp	w8, w10
	b.ne	LBB30_11
; %bb.71:                               ;   in Loop: Header=BB30_68 Depth=1
	ldrh	w10, [sp, #72]
	cmp	w10, w8
	b.hi	LBB30_11
; %bb.72:                               ;   in Loop: Header=BB30_68 Depth=1
	ldrh	w9, [x9, #4]
	cmp	w10, w9
	b.ne	LBB30_11
; %bb.73:                               ;   in Loop: Header=BB30_68 Depth=1
	lsl	x8, x8, #3
	sub	x0, x29, #104
	add	x1, x8, #8
	add	x2, sp, #104
	bl	_nvm_v2_take
	cbnz	w0, LBB30_11
; %bb.74:                               ;   in Loop: Header=BB30_68 Depth=1
	ldrh	w8, [sp]
	ldr	x9, [sp, #104]
	add	x8, x8, #1
	add	x9, x9, #3
LBB30_75:                               ;   Parent Loop BB30_68 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w10, [x9, #-3]
	cmp	w10, #15
	b.hi	LBB30_11
; %bb.76:                               ;   in Loop: Header=BB30_75 Depth=2
	ldurb	w10, [x9, #-2]
	cmp	w10, #2
	b.hi	LBB30_11
; %bb.77:                               ;   in Loop: Header=BB30_75 Depth=2
	ldurb	w10, [x9, #-1]
	cbnz	w10, LBB30_11
; %bb.78:                               ;   in Loop: Header=BB30_75 Depth=2
	ldrb	w10, [x9], #8
	cbnz	w10, LBB30_11
; %bb.79:                               ;   in Loop: Header=BB30_75 Depth=2
	subs	x8, x8, #1
	b.ne	LBB30_75
; %bb.80:                               ;   in Loop: Header=BB30_68 Depth=1
	add	x23, x23, #1
	ldr	w8, [sp, #92]
	cmp	x23, x8
	b.lo	LBB30_68
LBB30_81:
	ldr	w8, [sp, #100]
	cmp	w8, #3
	b.ne	LBB30_88
; %bb.82:
	ldur	q0, [x29, #-104]
	str	q0, [sp]
	ldur	x8, [x29, #-88]
	str	x8, [sp, #16]
	mov	x0, sp
	add	x1, sp, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB30_11
; %bb.83:
	ldr	w1, [sp, #72]
	mov	x0, sp
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB30_11
; %bb.84:
	mov	x0, sp
	add	x1, sp, #88
	bl	_nvm_v2_u32
	cbnz	w0, LBB30_11
; %bb.85:
	mov	w8, #3                          ; =0x3
	mov	w9, #4194296                    ; =0x3ffff8
	cmp	w21, w9
	b.hi	LBB30_12
; %bb.86:
	ldr	w9, [sp, #88]
	cmp	w9, #5
	b.hs	LBB30_12
; %bb.87:
	add	x21, x21, #8
	ldr	w8, [sp, #100]
LBB30_88:
	stp	xzr, xzr, [sp, #72]
	cmp	w8, #3
	b.eq	LBB30_93
; %bb.89:
	cmp	w8, #2
	b.ne	LBB30_95
; %bb.90:
	sub	x0, x29, #104
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_paths_read
	b	LBB30_94
LBB30_91:
	mov	w8, #2                          ; =0x2
	b	LBB30_13
LBB30_92:
	mov	w8, #3                          ; =0x3
	b	LBB30_12
LBB30_93:
	sub	x0, x29, #104
	mov	x5, sp
	add	x6, sp, #72
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_extension_suffix_read_map
LBB30_94:
	cbnz	w0, LBB30_11
LBB30_95:
	ldp	x9, x8, [x29, #-96]
	cmp	x8, x9
	b.ne	LBB30_11
; %bb.96:
	ldr	x8, [sp, #72]
	cmp	x8, #0
	cset	w8, ne
	orr	w8, w22, w8
	and	w8, w8, #0x1
	b	LBB30_12
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_counts ; -- Begin function nvm_map_declarations_counts
	.globl	_nvm_map_declarations_counts
	.p2align	2
_nvm_map_declarations_counts:           ; @nvm_map_declarations_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB31_2
; %bb.1:
	ldr	x9, [x8, #40]
	ldr	w8, [x8, #48]
	str	w8, [x1, #8]
	str	x9, [x1]
LBB31_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_scalar ; -- Begin function nvm_map_declarations_scalar
	.globl	_nvm_map_declarations_scalar
	.p2align	2
_nvm_map_declarations_scalar:           ; @nvm_map_declarations_scalar
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB32_5
; %bb.1:
	cbz	x2, LBB32_5
; %bb.2:
	ldr	w9, [x8, #40]
	cmp	w1, w9
	b.hs	LBB32_4
; %bb.3:
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, w1, uxtw]
	strb	w8, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB32_4:
	mov	w0, #0                          ; =0x0
LBB32_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_pair ; -- Begin function nvm_map_declarations_pair
	.globl	_nvm_map_declarations_pair
	.p2align	2
_nvm_map_declarations_pair:             ; @nvm_map_declarations_pair
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB33_5
; %bb.1:
	cbz	x2, LBB33_5
; %bb.2:
	ldr	w9, [x8, #44]
	cmp	w1, w9
	b.hs	LBB33_4
; %bb.3:
	ldr	x8, [x8, #16]
	ldr	x8, [x8, w1, uxtw #3]
	str	x8, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB33_4:
	mov	w0, #0                          ; =0x0
LBB33_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_binding ; -- Begin function nvm_map_declarations_binding
	.globl	_nvm_map_declarations_binding
	.p2align	2
_nvm_map_declarations_binding:          ; @nvm_map_declarations_binding
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB34_5
; %bb.1:
	cbz	x2, LBB34_5
; %bb.2:
	ldr	w9, [x8, #48]
	cmp	w1, w9
	b.hs	LBB34_4
; %bb.3:
	ldr	x8, [x8, #24]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB34_4:
	mov	w0, #0                          ; =0x0
LBB34_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_field ; -- Begin function nvm_map_declarations_field
	.globl	_nvm_map_declarations_field
	.p2align	2
_nvm_map_declarations_field:            ; @nvm_map_declarations_field
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB35_8
; %bb.1:
	cbz	x3, LBB35_8
; %bb.2:
	ldr	w8, [x0, #52]
	cmp	w1, w8
	b.hs	LBB35_7
; %bb.3:
	ldr	x9, [x0, #32]
	ldr	w8, [x9, w1, uxtw #2]
	add	w10, w1, #1
	ldr	w9, [x9, w10, uxtw #2]
	cmp	w8, w9
	b.hs	LBB35_7
; %bb.4:
	ldr	x10, [x0, #24]
	mov	w11, #12                        ; =0xc
LBB35_5:                                ; =>This Inner Loop Header: Depth=1
	sub	w12, w9, w8
	add	w12, w8, w12, lsr #1
	umaddl	x13, w12, w11, x10
	ldrh	w14, [x13, #4]
	cmp	w14, w2
	b.eq	LBB35_9
; %bb.6:                                ;   in Loop: Header=BB35_5 Depth=1
	csel	w9, w9, w12, lo
	csinc	w8, w8, w12, hs
	cmp	w8, w9
	b.lo	LBB35_5
LBB35_7:
	mov	w8, #0                          ; =0x0
LBB35_8:
	mov	x0, x8
	ret
LBB35_9:
	ldr	x8, [x0, #16]
	ldr	w9, [x13, #8]
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [x3]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_map_declarations_split ; -- Begin function nvm_prepare_map_declarations_split
	.globl	_nvm_prepare_map_declarations_split
	.p2align	2
_nvm_prepare_map_declarations_split:    ; @nvm_prepare_map_declarations_split
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x8, x0
Lloh52:
	adrp	x1, l_.str.9@PAGE
Lloh53:
	add	x1, x1, l_.str.9@PAGEOFF
	mov	w0, #2                          ; =0x2
	cmp	x19, x2
	b.eq	LBB36_5
; %bb.1:
	cbz	x19, LBB36_5
; %bb.2:
	mov	x20, x2
	cbz	x2, LBB36_5
; %bb.3:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x0, x8
	bl	_nvm_prepare_map_declarations
	cmp	w0, #1
	b.ne	LBB36_5
; %bb.4:
	ldr	x8, [sp, #8]
	ldr	x9, [x8]
	str	x9, [x20]
	str	xzr, [x8]
	str	x8, [x19]
LBB36_5:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_map_declarations_retained_cost ; -- Begin function nvm_map_declarations_retained_cost
	.globl	_nvm_map_declarations_retained_cost
	.p2align	2
_nvm_map_declarations_retained_cost:    ; @nvm_map_declarations_retained_cost
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB37_4
; %bb.1:
	ldrb	w8, [x1, #16]
	tbnz	w8, #0, LBB37_3
; %bb.2:
	ldp	x9, x10, [x1]
	subs	x8, x10, x9
	ccmp	x8, #15, #0, hs
	b.hi	LBB37_6
LBB37_3:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
LBB37_4:
	mov	w0, #2                          ; =0x2
LBB37_5:
	ret
LBB37_6:
	add	x12, x9, #16
	str	x12, [x1]
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB37_5
; %bb.7:
	cbz	x2, LBB37_5
; %bb.8:
	mov	x11, x8
	ldr	x8, [x8]
	cbnz	x8, LBB37_5
; %bb.9:
	ldr	w8, [x11, #40]
	sub	w13, w8, #6
	cmn	w13, #5
	b.lo	LBB37_5
; %bb.10:
	ldr	w13, [x11, #44]
	sub	w13, w13, #26
	cmn	w13, #25
	b.lo	LBB37_5
; %bb.11:
	ldr	w13, [x11, #48]
	mov	w14, #-65537                    ; =0xfffeffff
	add	w13, w13, w14
	cmn	w13, #16, lsl #12               ; =65536
	b.lo	LBB37_5
; %bb.12:
	ldr	w13, [x11, #52]
	cmp	w13, #256
	b.hi	LBB37_5
; %bb.13:
	subs	x10, x10, x12
	b.lo	LBB37_3
; %bb.14:
	cmp	x10, #3
	b.ls	LBB37_3
; %bb.15:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	add	x9, x9, #20
	str	x9, [x1]
	mov	w9, #80                         ; =0x50
	str	x9, [sp, #8]
	mov	x21, x11
	ldr	x9, [x11, #8]
	add	x4, sp, #8
	mov	x19, x1
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
	mov	w3, #1                          ; =0x1
	bl	_nvm_map_copy_term
	cbnz	w0, LBB37_20
; %bb.16:
	ldr	x1, [x21, #16]
	ldr	w2, [x21, #44]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #8                          ; =0x8
	bl	_nvm_map_copy_term
	cbnz	w0, LBB37_20
; %bb.17:
	ldr	x1, [x21, #24]
	ldr	w2, [x21, #48]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #12                         ; =0xc
	bl	_nvm_map_copy_term
	cbnz	w0, LBB37_20
; %bb.18:
	ldr	x1, [x21, #32]
	add	x4, sp, #8
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	mov	w3, #4                          ; =0x4
	bl	_nvm_map_copy_term
	cbnz	w0, LBB37_20
; %bb.19:
	ldr	x8, [sp, #8]
	str	x8, [x20]
LBB37_20:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_route   ; -- Begin function nvm_record_map_route
	.globl	_nvm_record_map_route
	.p2align	2
_nvm_record_map_route:                  ; @nvm_record_map_route
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB38_4
; %bb.1:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
	ldr	x1, [x0, #312]
	cbz	x1, LBB38_5
; %bb.2:
	strb	wzr, [sp, #3]
	add	x20, x19, #320
	ldr	w8, [x19, #320]
	mov	w9, #16777216                   ; =0x1000000
	cmp	w8, w9
	csel	w2, w8, w9, lo
	add	x0, sp, #24
	bl	_nvm_v2_cursor_init
	add	x0, sp, #24
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB38_9
; %bb.3:
	mov	w2, #0                          ; =0x0
	mov	w23, #0                         ; =0x0
	b	LBB38_30
LBB38_4:
	mov	w0, #4                          ; =0x4
	ret
LBB38_5:
	ldr	w8, [x19, #320]
	cmp	w8, #0
	cset	w23, eq
	cbnz	w8, LBB38_8
; %bb.6:
	ldr	x8, [x19, #296]
	cbnz	x8, LBB38_8
; %bb.7:
	ldr	w8, [x19, #304]
	cbz	w8, LBB38_39
LBB38_8:
	mov	w2, #0                          ; =0x0
	add	x20, x19, #320
	strb	wzr, [sp, #3]
	b	LBB38_30
LBB38_9:
	ldr	w2, [sp, #4]
	cbz	w2, LBB38_28
; %bb.10:
	mov	x21, x2
	mov	w22, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w24, #1                         ; =0x1
	b	LBB38_12
LBB38_11:                               ;   in Loop: Header=BB38_12 Depth=1
	add	w23, w23, #1
	ldr	w8, [sp, #4]
	cmp	w23, w8
	b.hs	LBB38_40
LBB38_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_18 Depth 2
	add	x0, sp, #24
	add	x2, sp, #16
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB38_27
; %bb.13:                               ;   in Loop: Header=BB38_12 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB38_15
; %bb.14:                               ;   in Loop: Header=BB38_12 Depth=1
	ldrb	w9, [x8]
	cmp	w9, #4
	b.lo	LBB38_16
LBB38_15:                               ;   in Loop: Header=BB38_12 Depth=1
	mov	w24, #0                         ; =0x0
LBB38_16:                               ;   in Loop: Header=BB38_12 Depth=1
	ldrh	w25, [x8, #2]
	cbz	w25, LBB38_11
; %bb.17:                               ;   in Loop: Header=BB38_12 Depth=1
	mov	w26, #0                         ; =0x0
LBB38_18:                               ;   Parent Loop BB38_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #24
	add	x2, sp, #8
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cbnz	w0, LBB38_27
; %bb.19:                               ;   in Loop: Header=BB38_18 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w9, [x8]
	cmp	w9, #13
	b.ne	LBB38_21
; %bb.20:                               ;   in Loop: Header=BB38_18 Depth=2
	mov	w22, #1                         ; =0x1
	b	LBB38_22
LBB38_21:                               ;   in Loop: Header=BB38_18 Depth=2
	cmp	w9, #15
	b.hi	LBB38_24
LBB38_22:                               ;   in Loop: Header=BB38_18 Depth=2
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB38_24
; %bb.23:                               ;   in Loop: Header=BB38_18 Depth=2
	ldrb	w9, [x8, #2]
	cbz	w9, LBB38_26
LBB38_24:                               ;   in Loop: Header=BB38_18 Depth=2
	mov	w24, #0                         ; =0x0
LBB38_25:                               ;   in Loop: Header=BB38_18 Depth=2
	add	w26, w26, #1
	cmp	w26, w25
	b.lo	LBB38_18
	b	LBB38_11
LBB38_26:                               ;   in Loop: Header=BB38_18 Depth=2
	ldrb	w8, [x8, #3]
	cmp	w8, #0
	cset	w8, eq
	and	w24, w8, w24
	b	LBB38_25
LBB38_27:
	mov	w23, #0                         ; =0x0
	strb	w22, [sp, #3]
	mov	x2, x21
	b	LBB38_30
LBB38_28:
	mov	w24, #1                         ; =0x1
LBB38_29:
	ldp	x9, x8, [sp, #32]
	cmp	x8, x9
	cset	w8, eq
	and	w23, w24, w8
LBB38_30:
	add	x1, sp, #3
	mov	x0, x19
	bl	_map_public_ownership_scan
	ldrb	w8, [sp, #3]
	tbz	w8, #0, LBB38_34
; %bb.31:
	ldr	w10, [x20]
	mov	w9, #16777216                   ; =0x1000000
	cmp	w10, w9
	b.hi	LBB38_33
; %bb.32:
	ldr	w8, [x19, #304]
	cmp	w8, w9
	b.ls	LBB38_36
LBB38_33:
	mov	w0, #3                          ; =0x3
	b	LBB38_35
LBB38_34:
	tst	w23, w0
	mov	w8, #4                          ; =0x4
	csel	w0, wzr, w8, ne
LBB38_35:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB38_36:
	mov	x9, x0
	mov	w0, #2                          ; =0x2
	cbz	w10, LBB38_35
; %bb.37:
	ldr	x10, [x19, #312]
	cbz	x10, LBB38_35
; %bb.38:
	ldr	x10, [x19, #296]
	mov	w11, #2                         ; =0x2
	cmp	w8, #0
	cset	w8, ne
	and	w8, w8, w23
	tst	w8, w9
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
	cmp	x10, #0
	csel	w0, w11, w8, eq
	b	LBB38_35
LBB38_39:
	mov	w0, #0                          ; =0x0
	b	LBB38_35
LBB38_40:
	strb	w22, [sp, #3]
	mov	x2, x21
	b	LBB38_29
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_public_ownership_scan
_map_public_ownership_scan:             ; @map_public_ownership_scan
	.cfi_startproc
; %bb.0:
	mov	x8, x1
	ldr	x1, [x0, #296]
	ldr	w9, [x0, #304]
	cbz	x1, LBB39_7
; %bb.1:
	sub	sp, sp, #224
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x8
	mov	w8, #16777216                   ; =0x1000000
	cmp	w9, w8
	csel	w2, w9, w8, lo
	sub	x0, x29, #56
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #56
	sub	x1, x29, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB39_22
; %bb.2:
	sub	x0, x29, #56
	sub	x1, x29, #64
	bl	_nvm_v2_u32
	cbnz	w0, LBB39_22
; %bb.3:
	ldur	w1, [x29, #-64]
	sub	x0, x29, #56
	sub	x2, x29, #80
	bl	_nvm_v2_take
	cbnz	w0, LBB39_22
; %bb.4:
	ldur	w8, [x29, #-60]
	sub	w8, w8, #1
	cmp	w8, #3
	ldur	w8, [x29, #-64]
	ccmp	w8, w20, #0, lo
	cset	w20, eq
	cbz	w8, LBB39_20
; %bb.5:
	ldur	x9, [x29, #-80]
	cmp	w8, #7
	b.hi	LBB39_8
; %bb.6:
	mov	x10, #0                         ; =0x0
	mov	x11, x20
	b	LBB39_18
LBB39_7:
	cmp	w9, #0
	cset	w0, eq
	ret
LBB39_8:
	cmp	w8, #64
	b.hs	LBB39_10
; %bb.9:
	mov	x10, #0                         ; =0x0
	mov	x11, x20
	b	LBB39_15
LBB39_10:
	and	x10, x8, #0xffffffc0
	add	x11, x9, #32
	movi.2d	v0, #0000000000000000
	movi.16b	v1, #3
	mov	x12, x10
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB39_11:                               ; =>This Inner Loop Header: Depth=1
	ldp	q5, q6, [x11, #-32]
	ldp	q7, q16, [x11], #64
	cmhi.16b	v5, v5, v1
	cmhi.16b	v6, v6, v1
	cmhi.16b	v7, v7, v1
	cmhi.16b	v16, v16, v1
	orr.16b	v0, v0, v5
	orr.16b	v2, v2, v6
	orr.16b	v3, v3, v7
	orr.16b	v4, v4, v16
	subs	x12, x12, #64
	b.ne	LBB39_11
; %bb.12:
	orr.16b	v0, v2, v0
	orr.16b	v0, v3, v0
	orr.16b	v0, v4, v0
	shl.16b	v0, v0, #7
	cmlt.16b	v0, v0, #0
	umaxv.16b	b0, v0
	fmov	w11, s0
	eor	w11, w11, #0x1
	and	w11, w11, w20
	cmp	x10, x8
	b.ne	LBB39_14
; %bb.13:
	mov	x20, x11
	b	LBB39_20
LBB39_14:
	tst	x8, #0x38
	b.eq	LBB39_18
LBB39_15:
	mov	x12, x10
	eor	w11, w11, w20
	and	x10, x8, #0xfffffff8
	dup.8b	v0, w11
	sub	x11, x12, x10
	add	x12, x9, x12
	movi.8b	v1, #3
LBB39_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	d2, [x12], #8
	cmhi.8b	v2, v2, v1
	orr.8b	v0, v0, v2
	adds	x11, x11, #8
	b.ne	LBB39_16
; %bb.17:
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w11, s0
	eor	w11, w11, #0x1
	and	w11, w11, w20
	mov	x20, x11
	cmp	x10, x8
	b.eq	LBB39_20
LBB39_18:
	add	x9, x9, x10
	sub	x8, x8, x10
	mov	x20, x11
LBB39_19:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	cmp	w10, #4
	cset	w10, lo
	and	w20, w10, w20
	subs	x8, x8, #1
	b.ne	LBB39_19
LBB39_20:
	sub	x0, x29, #56
	bl	_nvm_v2_align4
	cbnz	w0, LBB39_22
; %bb.21:
	sub	x0, x29, #56
	sub	x1, x29, #68
	bl	_nvm_v2_u32
	cbz	w0, LBB39_24
LBB39_22:
	mov	w0, #0                          ; =0x0
LBB39_23:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB39_24:
	ldur	w8, [x29, #-68]
	cbz	w8, LBB39_30
; %bb.25:
	mov	w21, #0                         ; =0x0
LBB39_26:                               ; =>This Inner Loop Header: Depth=1
	sub	x0, x29, #56
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB39_22
; %bb.27:                               ;   in Loop: Header=BB39_26 Depth=1
	sub	x0, x29, #56
	add	x1, sp, #96
	bl	_nvm_v2_u16
	cbnz	w0, LBB39_22
; %bb.28:                               ;   in Loop: Header=BB39_26 Depth=1
	ldrh	w8, [sp, #16]
	lsl	x8, x8, #3
	sub	x0, x29, #56
	add	x1, x8, #8
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB39_22
; %bb.29:                               ;   in Loop: Header=BB39_26 Depth=1
	ldrh	w8, [sp, #96]
	ldrh	w9, [sp, #16]
	cmp	w8, w9
	cset	w8, ls
	and	w20, w8, w20
	add	w21, w21, #1
	ldur	w8, [x29, #-68]
	cmp	w21, w8
	b.lo	LBB39_26
LBB39_30:
	ldur	w8, [x29, #-60]
	cmp	w8, #2
	b.eq	LBB39_46
; %bb.31:
	cmp	w8, #3
	b.ne	LBB39_47
; %bb.32:
	ldur	q0, [x29, #-56]
	str	q0, [sp, #96]
	ldur	x8, [x29, #-40]
	str	x8, [sp, #112]
	add	x0, sp, #96
	add	x1, sp, #92
	bl	_nvm_v2_u32
	cbnz	w0, LBB39_22
; %bb.33:
	ldr	w1, [sp, #92]
	add	x0, sp, #96
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB39_22
; %bb.34:
	add	x0, sp, #96
	add	x1, sp, #88
	bl	_nvm_v2_u32
	cbnz	w0, LBB39_22
; %bb.35:
	ldr	w8, [sp, #88]
	cbz	w8, LBB39_45
; %bb.36:
	mov	w21, #0                         ; =0x0
	mov	w22, #1                         ; =0x1
LBB39_37:                               ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #96
	mov	x1, sp
	bl	_nvm_v2_u16
	cbnz	w0, LBB39_22
; %bb.38:                               ;   in Loop: Header=BB39_37 Depth=1
	ldrh	w8, [sp]
	cmp	w8, #5
	b.ne	LBB39_40
; %bb.39:                               ;   in Loop: Header=BB39_37 Depth=1
	strb	w22, [x19]
LBB39_40:                               ;   in Loop: Header=BB39_37 Depth=1
	add	x0, sp, #96
	add	x1, sp, #86
	bl	_nvm_v2_u16
	cbnz	w0, LBB39_22
; %bb.41:                               ;   in Loop: Header=BB39_37 Depth=1
	add	x0, sp, #96
	add	x1, sp, #16
	bl	_nvm_v2_u32
	cbnz	w0, LBB39_22
; %bb.42:                               ;   in Loop: Header=BB39_37 Depth=1
	ldr	w1, [sp, #16]
	add	x0, sp, #96
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB39_22
; %bb.43:                               ;   in Loop: Header=BB39_37 Depth=1
	add	x0, sp, #96
	bl	_nvm_v2_align4
	cbnz	w0, LBB39_22
; %bb.44:                               ;   in Loop: Header=BB39_37 Depth=1
	add	w21, w21, #1
	ldr	w8, [sp, #88]
	cmp	w21, w8
	b.lo	LBB39_37
LBB39_45:
	sub	x0, x29, #56
	add	x5, sp, #16
	mov	x6, sp
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_extension_suffix_read_map
	cbnz	w0, LBB39_22
	b	LBB39_47
LBB39_46:
	sub	x0, x29, #56
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_paths_read
	cbnz	w0, LBB39_22
LBB39_47:
	ldp	x9, x8, [x29, #-48]
	cmp	x8, x9
	cset	w8, eq
	and	w0, w20, w8
	b	LBB39_23
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_wire_selected ; -- Begin function nvm_record_map_wire_selected
	.globl	_nvm_record_map_wire_selected
	.p2align	2
_nvm_record_map_wire_selected:          ; @nvm_record_map_wire_selected
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB40_23
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #496
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x8, sp, #16
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #448]
	stp	q0, q0, [x8, #416]
	stp	q0, q0, [x8, #384]
	stp	q0, q0, [x8, #352]
	stp	q0, q0, [x8, #320]
	stp	q0, q0, [x8, #288]
	stp	q0, q0, [x8, #256]
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	ldr	x9, [x0, #184]
	str	x9, [x8, #296]
	ldr	w9, [x0, #192]
	str	w9, [x8, #304]
	strb	wzr, [sp, #15]
	ldr	w2, [x0, #64]
	add	x0, sp, #16
	add	x1, sp, #15
	bl	_map_public_ownership_scan
	ldrb	w8, [sp, #15]
	tbz	w8, #0, LBB40_3
; %bb.2:
	mov	w0, #1                          ; =0x1
	b	LBB40_22
LBB40_3:
	ldr	x8, [x19, #56]
	cbz	x8, LBB40_17
; %bb.4:
	ldr	w9, [x19, #64]
	cbz	w9, LBB40_18
; %bb.5:
	mov	x10, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	w11, #16777216                  ; =0x1000000
LBB40_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB40_10 Depth 2
	add	x12, x15, #1
	cmp	x12, x11
	b.hi	LBB40_19
; %bb.7:                                ;   in Loop: Header=BB40_6 Depth=1
	add	x13, x8, x10, lsl #4
	ldr	x14, [x13, #8]
	ldrh	w13, [x13, #2]
	cbz	x14, LBB40_14
; %bb.8:                                ;   in Loop: Header=BB40_6 Depth=1
	cbz	w13, LBB40_15
; %bb.9:                                ;   in Loop: Header=BB40_6 Depth=1
	sub	w16, w13, #1
	add	x15, x15, w16, uxth
	add	x16, x15, #2
LBB40_10:                               ;   Parent Loop BB40_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x17, x12, #24
	cmp	x17, #0
	cset	w15, eq
	cbnz	x17, LBB40_20
; %bb.11:                               ;   in Loop: Header=BB40_10 Depth=2
	ldrb	w17, [x14], #12
	cmp	w17, #13
	b.eq	LBB40_20
; %bb.12:                               ;   in Loop: Header=BB40_10 Depth=2
	add	x12, x12, #1
	subs	x13, x13, #1
	b.ne	LBB40_10
; %bb.13:                               ;   in Loop: Header=BB40_6 Depth=1
	mov	x12, x16
	b	LBB40_15
LBB40_14:                               ;   in Loop: Header=BB40_6 Depth=1
	cbnz	w13, LBB40_19
LBB40_15:                               ;   in Loop: Header=BB40_6 Depth=1
	add	x10, x10, #1
	mov	x15, x12
	cmp	x10, x9
	b.ne	LBB40_6
; %bb.16:
	mov	w8, #0                          ; =0x0
	mov	w15, #0                         ; =0x0
	b	LBB40_21
LBB40_17:
	mov	w0, #0                          ; =0x0
	b	LBB40_22
LBB40_18:
	mov	w8, #0                          ; =0x0
                                        ; implicit-def: $w15
	b	LBB40_21
LBB40_19:
	mov	w15, #0                         ; =0x0
LBB40_20:
	mov	w8, #1                          ; =0x1
LBB40_21:
	and	w0, w8, w15
LBB40_22:
	add	sp, sp, #496
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB40_23:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_declarations_free ; -- Begin function nvm_union_field_declarations_free
	.globl	_nvm_union_field_declarations_free
	.p2align	2
_nvm_union_field_declarations_free:     ; @nvm_union_field_declarations_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB41_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nvm_v2_layouts_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB41_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_union_field_declarations_prepare
lCPI42_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
lCPI42_2:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
lCPI42_3:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
lCPI42_4:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI42_1:
	.quad	0                               ; 0x0
	.quad	64                              ; 0x40
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_union_field_declarations_prepare
	.globl	_nvm_union_field_declarations_prepare
	.p2align	2
_nvm_union_field_declarations_prepare:  ; @nvm_union_field_declarations_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB42_13
; %bb.1:
	cbz	x1, LBB42_13
; %bb.2:
	ldr	x9, [x0, #312]
	ldr	w2, [x0, #320]
	cmp	x2, #0
	cset	w10, eq
	cmp	x9, #0
	cset	w11, ne
	cmp	w11, w10
	b.eq	LBB42_13
; %bb.3:
	ldr	x11, [x0, #296]
	ldr	w10, [x0, #304]
	cmp	w10, #0
	cset	w12, eq
	cmp	x11, #0
	cset	w11, ne
	eor	w11, w11, w12
	tbz	w11, #0, LBB42_13
; %bb.4:
	cbz	w2, LBB42_16
; %bb.5:
	cbz	w10, LBB42_16
; %bb.6:
	mov	w11, #16777216                  ; =0x1000000
	cmp	w2, w11
	b.hi	LBB42_12
; %bb.7:
	cmp	w10, w11
	b.hi	LBB42_12
; %bb.8:
	ldr	w11, [x0, #272]
	cmp	w11, #257
	b.hs	LBB42_12
; %bb.9:
	cbz	w11, LBB42_11
; %bb.10:
	ldr	x11, [x0, #256]
	cbz	x11, LBB42_13
LBB42_11:
	mov	w11, #65473                     ; =0xffc1
	movk	w11, #15, lsl #16
	add	w23, w10, w2
	cmp	w23, w11
	b.lo	LBB42_17
LBB42_12:
Lloh54:
	adrp	x9, lCPI42_4@PAGE
Lloh55:
	ldr	d0, [x9, lCPI42_4@PAGEOFF]
	str	d0, [x8]
Lloh56:
	adrp	x9, l_.str.17@PAGE
Lloh57:
	add	x9, x9, l_.str.17@PAGEOFF
	b	LBB42_14
LBB42_13:
Lloh58:
	adrp	x9, lCPI42_0@PAGE
Lloh59:
	ldr	d0, [x9, lCPI42_0@PAGEOFF]
	str	d0, [x8]
Lloh60:
	adrp	x9, l_.str.14@PAGE
Lloh61:
	add	x9, x9, l_.str.14@PAGEOFF
LBB42_14:
	str	x9, [x8, #8]
Lloh62:
	adrp	x9, lCPI42_1@PAGE
Lloh63:
	ldr	q0, [x9, lCPI42_1@PAGEOFF]
	str	q0, [x8, #16]
LBB42_15:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB42_16:
Lloh64:
	adrp	x9, lCPI42_2@PAGE
Lloh65:
	ldr	d0, [x9, lCPI42_2@PAGEOFF]
	str	d0, [x8]
Lloh66:
	adrp	x9, l_.str.16@PAGE
Lloh67:
	add	x9, x9, l_.str.16@PAGEOFF
	b	LBB42_14
LBB42_17:
	mov	x19, x0
	mov	x22, x1
	mov	x21, x8
	add	x20, x23, #64
	sub	x0, x29, #120
	mov	x1, x9
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbz	w0, LBB42_21
LBB42_18:
Lloh68:
	adrp	x8, lCPI42_0@PAGE
Lloh69:
	ldr	d0, [x8, lCPI42_0@PAGEOFF]
	str	d0, [x21]
Lloh70:
	adrp	x8, l_.str.14@PAGE
Lloh71:
	add	x8, x8, l_.str.14@PAGEOFF
LBB42_19:
	str	x8, [x21, #8]
LBB42_20:
	stp	xzr, x20, [x21, #16]
	b	LBB42_15
LBB42_21:
	ldur	w8, [x29, #-124]
	cmp	w8, #2
	mov	x8, x21
	b.ne	LBB42_25
; %bb.22:
	mov	x9, x19
	ldr	w10, [x19, #468]
	cmp	w10, #1
	b.ne	LBB42_25
; %bb.23:
	ldr	w10, [x9, #476]
	cmp	w10, #1
	b.ne	LBB42_25
; %bb.24:
	ldr	w9, [x9, #472]
	cbz	w9, LBB42_26
LBB42_25:
Lloh72:
	adrp	x9, lCPI42_2@PAGE
Lloh73:
	ldr	d0, [x9, lCPI42_2@PAGEOFF]
	str	d0, [x8]
Lloh74:
	adrp	x9, l_.str.16@PAGE
Lloh75:
	add	x9, x9, l_.str.16@PAGEOFF
	stp	x9, xzr, [x8, #8]
	str	x20, [x8, #24]
	b	LBB42_15
LBB42_26:
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB42_18
; %bb.27:
	ldr	x8, [sp, #120]
	ldrh	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB42_32
; %bb.28:
	ldrb	w8, [x8]
	cmp	w8, #2
	b.ne	LBB42_32
; %bb.29:
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cbnz	w0, LBB42_18
; %bb.30:
	ldr	x8, [sp, #120]
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB42_32
; %bb.31:
	ldr	w8, [x8, #4]
	cmn	w8, #1
	b.eq	LBB42_33
LBB42_32:
Lloh76:
	adrp	x8, lCPI42_2@PAGE
Lloh77:
	ldr	d0, [x8, lCPI42_2@PAGEOFF]
	str	d0, [x21]
Lloh78:
	adrp	x8, l_.str.16@PAGE
Lloh79:
	add	x8, x8, l_.str.16@PAGEOFF
	b	LBB42_19
LBB42_33:
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB42_18
; %bb.34:
	ldr	x8, [sp, #120]
	ldrh	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB42_32
; %bb.35:
	ldrb	w8, [x8]
	cbnz	w8, LBB42_32
; %bb.36:
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cbnz	w0, LBB42_18
; %bb.37:
	ldr	x8, [sp, #120]
	ldrb	w9, [x8]
	cmp	w9, #10
	b.ne	LBB42_32
; %bb.38:
	ldr	w8, [x8, #4]
	cbnz	w8, LBB42_32
; %bb.39:
	sub	x24, x29, #120
	ldp	x9, x8, [x24, #8]
	cmp	x8, x9
	b.ne	LBB42_18
; %bb.40:
	ldr	x1, [x19, #296]
	ldr	w2, [x19, #304]
	sub	x0, x29, #120
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.41:
	ldur	w8, [x29, #-124]
	cmp	w8, #3
	b.ne	LBB42_32
; %bb.42:
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.43:
	ldur	w8, [x29, #-124]
	cmp	w8, #2
	b.ne	LBB42_18
; %bb.44:
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #2                          ; =0x2
	bl	_nvm_v2_take
	cbnz	w0, LBB42_18
; %bb.45:
	ldr	x8, [sp, #120]
	ldrb	w9, [x8]
	strb	w9, [sp, #118]
	ldrb	w8, [x8, #1]
	strb	w8, [sp, #119]
	cmp	w9, #1
	b.ne	LBB42_32
; %bb.46:
	cmp	w8, #1
	b.ne	LBB42_32
; %bb.47:
	sub	x0, x29, #120
	bl	_nvm_v2_align4
	cbnz	w0, LBB42_18
; %bb.48:
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.49:
	ldur	w8, [x29, #-124]
	ldr	w9, [x19, #272]
	cmp	w8, w9
	b.ne	LBB42_18
; %bb.50:
	cbz	w8, LBB42_64
; %bb.51:
	mov	x26, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
Lloh80:
	adrp	x25, l_.str.14@PAGE
Lloh81:
	add	x25, x25, l_.str.14@PAGEOFF
LBB42_52:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB42_59 Depth 2
	sub	x0, x29, #120
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB42_95
; %bb.53:                               ;   in Loop: Header=BB42_52 Depth=1
	sub	x0, x29, #120
	add	x1, sp, #88
	bl	_nvm_v2_u16
	cbnz	w0, LBB42_95
; %bb.54:                               ;   in Loop: Header=BB42_52 Depth=1
	ldrh	w9, [sp, #16]
	cmp	w9, #256
	b.hi	LBB42_98
; %bb.55:                               ;   in Loop: Header=BB42_52 Depth=1
	ldr	x8, [x19, #256]
	mov	w10, #24                        ; =0x18
	madd	x10, x26, x10, x8
	ldrh	w8, [x10, #16]
	cmp	w9, w8
	b.ne	LBB42_95
; %bb.56:                               ;   in Loop: Header=BB42_52 Depth=1
	ldrh	w11, [sp, #88]
	mov	w8, #2                          ; =0x2
	cmp	w11, w9
	b.hi	LBB42_97
; %bb.57:                               ;   in Loop: Header=BB42_52 Depth=1
	ldrh	w10, [x10, #4]
	cmp	w11, w10
	b.ne	LBB42_97
; %bb.58:                               ;   in Loop: Header=BB42_52 Depth=1
	add	x8, x9, x27
	add	x27, x8, #1
	mov	w28, #-1                        ; =0xffffffff
LBB42_59:                               ;   Parent Loop BB42_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB42_95
; %bb.60:                               ;   in Loop: Header=BB42_59 Depth=2
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB42_96
; %bb.61:                               ;   in Loop: Header=BB42_59 Depth=2
	ldrh	w8, [sp, #16]
	add	w28, w28, #1
	cmp	w28, w8
	b.lo	LBB42_59
; %bb.62:                               ;   in Loop: Header=BB42_52 Depth=1
	add	x26, x26, #1
	ldur	w8, [x29, #-124]
	cmp	x26, x8
	b.lo	LBB42_52
; %bb.63:
	lsl	x25, x27, #5
	b	LBB42_65
LBB42_64:
	mov	x25, #0                         ; =0x0
LBB42_65:
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.66:
	ldur	w8, [x29, #-124]
	cmp	w8, #4
	b.ne	LBB42_32
; %bb.67:
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.68:
	ldur	w8, [x29, #-124]
	cbnz	w8, LBB42_32
; %bb.69:
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.70:
	ldur	w8, [x29, #-124]
	cmp	w8, #1
	b.ne	LBB42_32
; %bb.71:
	sub	x0, x29, #120
	add	x1, sp, #116
	bl	_nvm_v2_u16
	cbnz	w0, LBB42_18
; %bb.72:
	sub	x0, x29, #120
	add	x1, sp, #114
	bl	_nvm_v2_u16
	cbnz	w0, LBB42_18
; %bb.73:
	ldrh	w8, [sp, #116]
	cmp	w8, #1
	b.ne	LBB42_32
; %bb.74:
	ldrh	w8, [sp, #114]
	cmp	w8, #1
	b.ne	LBB42_32
; %bb.75:
	sub	x0, x29, #120
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.76:
	ldur	w8, [x29, #-124]
	cmp	w8, #28
	b.ne	LBB42_32
; %bb.77:
	sub	x0, x29, #120
	add	x2, sp, #120
	mov	w1, #28                         ; =0x1c
	bl	_nvm_v2_take
	cbnz	w0, LBB42_18
; %bb.78:
	ldp	x9, x8, [x24, #8]
	cmp	x8, x9
	b.ne	LBB42_18
; %bb.79:
	ldr	x1, [sp, #120]
	add	x0, sp, #88
	mov	w2, #28                         ; =0x1c
	bl	_nvm_v2_cursor_init
	add	x0, sp, #88
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.80:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB42_18
; %bb.81:
	add	x0, sp, #88
	add	x1, sp, #78
	bl	_nvm_v2_u16
	cbnz	w0, LBB42_18
; %bb.82:
	add	x0, sp, #88
	add	x1, sp, #76
	bl	_nvm_v2_u16
	cbnz	w0, LBB42_18
; %bb.83:
	ldr	w8, [sp, #84]
	cmp	w8, #1
	b.ne	LBB42_18
; %bb.84:
	ldr	w8, [sp, #80]
	cbnz	w8, LBB42_18
; %bb.85:
	ldrh	w8, [sp, #78]
	cmp	w8, #2
	b.ne	LBB42_18
; %bb.86:
	ldrh	w8, [sp, #76]
	cbnz	w8, LBB42_18
; %bb.87:
	ldr	w8, [x19, #432]
	cbnz	w8, LBB42_32
; %bb.88:
	ldr	w8, [x19, #448]
	cbnz	w8, LBB42_32
; %bb.89:
	ldr	w8, [x19, #336]
	cbnz	w8, LBB42_32
; %bb.90:
	ldr	x8, [x19, #328]
	cbnz	x8, LBB42_32
; %bb.91:
	ldr	w8, [x19, #352]
	cbnz	w8, LBB42_32
; %bb.92:
	ldr	x8, [x19, #344]
	cbnz	x8, LBB42_32
; %bb.93:
	add	x8, x25, x23, lsl #2
	add	x8, x8, #384
	mov	w9, #1048512                    ; =0xfffc0
	sub	x9, x9, x23
	cmp	x8, x9
	b.ls	LBB42_99
; %bb.94:
Lloh82:
	adrp	x8, lCPI42_4@PAGE
Lloh83:
	ldr	d0, [x8, lCPI42_4@PAGEOFF]
	str	d0, [x21]
Lloh84:
	adrp	x8, l_.str.17@PAGE
Lloh85:
	add	x8, x8, l_.str.17@PAGEOFF
	b	LBB42_19
LBB42_95:
	mov	w8, #2                          ; =0x2
	b	LBB42_97
LBB42_96:
	mov	w8, #1                          ; =0x1
Lloh86:
	adrp	x25, l_.str.16@PAGE
Lloh87:
	add	x25, x25, l_.str.16@PAGEOFF
LBB42_97:
	stp	w8, wzr, [x21]
	str	x25, [x21, #8]
	b	LBB42_20
LBB42_98:
	mov	w8, #3                          ; =0x3
Lloh88:
	adrp	x25, l_.str.17@PAGE
Lloh89:
	add	x25, x25, l_.str.17@PAGEOFF
	b	LBB42_97
LBB42_99:
	add	x23, x8, x20
	mov	w0, #1                          ; =0x1
	mov	w1, #56                         ; =0x38
	bl	_calloc
	cbz	x0, LBB42_103
; %bb.100:
	mov	x20, x0
	strb	wzr, [sp, #75]
	ldr	x0, [x19, #312]
	ldr	w1, [x19, #320]
	add	x3, sp, #75
	mov	x2, x20
	bl	_nvm_ownership_mixed_layouts_private_decode_detailed
	cbz	w0, LBB42_104
; %bb.101:
	ldrb	w8, [sp, #75]
	tbz	w8, #0, LBB42_128
; %bb.102:
Lloh90:
	adrp	x22, l_.str.18@PAGE
Lloh91:
	add	x22, x22, l_.str.18@PAGEOFF
	mov	w19, #4                         ; =0x4
	b	LBB42_129
LBB42_103:
Lloh92:
	adrp	x8, lCPI42_3@PAGE
Lloh93:
	ldr	d0, [x8, lCPI42_3@PAGEOFF]
	str	d0, [x21]
Lloh94:
	adrp	x8, l_.str.18@PAGE
Lloh95:
	add	x8, x8, l_.str.18@PAGEOFF
	mov	w9, #112                        ; =0x70
	stp	x8, x9, [x21, #8]
	b	LBB42_131
LBB42_104:
	ldr	w8, [x20, #8]
	cmp	w8, #2
	b.ne	LBB42_128
; %bb.105:
	ldr	x8, [x20]
	ldrb	w9, [x8]
	cmp	w9, #2
	b.ne	LBB42_128
; %bb.106:
	ldrb	w9, [x8, #16]
	cbnz	w9, LBB42_128
; %bb.107:
	ldrh	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB42_128
; %bb.108:
	ldr	w10, [x8, #4]
	ldr	w9, [x19, #248]
	cmp	w10, w9
	b.hs	LBB42_128
; %bb.109:
	ldr	x10, [x8, #8]
	ldr	w11, [x10, #8]
	cmp	w11, w9
	b.hs	LBB42_128
; %bb.110:
	ldrb	w11, [x10]
	cmp	w11, #1
	b.ne	LBB42_128
; %bb.111:
	ldr	w10, [x10, #4]
	cmn	w10, #1
	b.ne	LBB42_128
; %bb.112:
	ldrh	w10, [x8, #18]
	cmp	w10, #1
	b.ne	LBB42_128
; %bb.113:
	ldr	w10, [x8, #20]
	cmp	w10, w9
	b.hs	LBB42_128
; %bb.114:
	ldr	x8, [x8, #24]
	ldr	w10, [x8, #8]
	cmp	w10, w9
	b.hs	LBB42_128
; %bb.115:
	ldrb	w9, [x8]
	cmp	w9, #10
	b.ne	LBB42_128
; %bb.116:
	ldr	w8, [x8, #4]
	cbnz	w8, LBB42_128
; %bb.117:
	str	xzr, [sp, #64]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #32]
	str	q0, [sp, #16]
	add	x2, sp, #15
	add	x4, sp, #16
	mov	x0, x19
	mov	x1, x20
	mov	x3, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	bl	_ownership_validate_owned
	cbnz	w0, LBB42_128
; %bb.118:
	ldrb	w8, [sp, #64]
	tbnz	w8, #0, LBB42_128
; %bb.119:
	ldr	w8, [sp, #44]
	cmp	w8, #2
	b.ne	LBB42_128
; %bb.120:
	ldr	x1, [sp, #16]
	cbz	x1, LBB42_128
; %bb.121:
	str	wzr, [sp, #8]
	strh	wzr, [sp, #6]
	add	x8, x20, #16
	str	x8, [sp, #32]
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #40]
	add	x8, sp, #8
	add	x9, sp, #6
	stp	x8, x9, [sp, #48]
	ldr	w2, [sp, #24]
	add	x0, sp, #88
	bl	_nvm_v2_cursor_init
	add	x0, sp, #88
	add	x3, sp, #118
	add	x7, sp, #16
	mov	x1, x19
	mov	x2, x20
	mov	w4, #-1                         ; =0xffffffff
	mov	w5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_union_facts_read
	cbnz	w0, LBB42_128
; %bb.122:
	ldrb	w8, [sp, #64]
	tbnz	w8, #0, LBB42_128
; %bb.123:
	ldr	w8, [sp, #44]
	cmp	w8, #2
	b.ne	LBB42_128
; %bb.124:
	ldr	w8, [sp, #8]
	cbnz	w8, LBB42_128
; %bb.125:
	ldrh	w8, [sp, #6]
	cmp	w8, #2
	b.ne	LBB42_128
; %bb.126:
	ldrh	w8, [x20, #26]
	ldrh	w9, [x20, #38]
	add	w9, w9, w8
	cmp	w9, #1
	b.ne	LBB42_128
; %bb.127:
	mov	w19, #0                         ; =0x0
	cmp	w8, #0
	cset	w8, eq
	strh	w8, [x20, #46]
	cset	w8, ne
	strh	w8, [x20, #48]
	strh	wzr, [x20, #44]
	mov	w8, #257                        ; =0x101
	movk	w8, #1, lsl #16
	str	w8, [x20, #40]
	str	x20, [x22]
Lloh96:
	adrp	x22, l_.str.15@PAGE
Lloh97:
	add	x22, x22, l_.str.15@PAGEOFF
	b	LBB42_130
LBB42_128:
Lloh98:
	adrp	x22, l_.str.14@PAGE
Lloh99:
	add	x22, x22, l_.str.14@PAGEOFF
	mov	w19, #2                         ; =0x2
LBB42_129:
	mov	x0, x20
	bl	_nvm_v2_layouts_free
	mov	x0, x20
	bl	_free
LBB42_130:
	stp	w19, wzr, [x21]
	mov	w8, #112                        ; =0x70
	stp	x22, x8, [x21, #8]
LBB42_131:
	str	x23, [x21, #24]
	b	LBB42_15
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdrp	Lloh72, Lloh74
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_declarations_layout ; -- Begin function nvm_union_field_declarations_layout
	.globl	_nvm_union_field_declarations_layout
	.p2align	2
_nvm_union_field_declarations_layout:   ; @nvm_union_field_declarations_layout
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x2, #0, #4, ne
	ccmp	w1, #2, #2, ne
	cset	w0, lo
	cmp	w0, #1
	b.ne	LBB43_2
; %bb.1:
	ldr	x9, [x8]
	add	x9, x9, w1, uxtw #4
	ldrb	w10, [x9]
	add	x8, x8, w1, uxtw
	ldrb	w8, [x8, #40]
	ldrh	w11, [x9, #2]
	ldr	w9, [x9, #4]
	strb	w10, [x2]
	strb	w8, [x2, #1]
	strh	w11, [x2, #2]
	str	w9, [x2, #4]
LBB43_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_declarations_field ; -- Begin function nvm_union_field_declarations_field
	.globl	_nvm_union_field_declarations_field
	.p2align	2
_nvm_union_field_declarations_field:    ; @nvm_union_field_declarations_field
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x3, #0, #4, ne
	ccmp	w1, #2, #2, ne
	ccmp	w2, #0, #0, lo
	cset	w0, eq
	b.ne	LBB44_2
; %bb.1:
	ldr	x8, [x8]
	add	x8, x8, w1, uxtw #4
	ldr	x8, [x8, #8]
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x3, #8]
	str	x9, [x3]
LBB44_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_declarations_variant ; -- Begin function nvm_union_field_declarations_variant
	.globl	_nvm_union_field_declarations_variant
	.p2align	2
_nvm_union_field_declarations_variant:  ; @nvm_union_field_declarations_variant
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x3, #0, #4, ne
	ccmp	w1, #0, #0, ne
	ccmp	w2, #2, #2, eq
	cset	w0, lo
	cmp	w0, #1
	b.ne	LBB45_2
; %bb.1:
	mov	w9, #12                         ; =0xc
	umaddl	x8, w2, w9, x8
	ldr	x9, [x8, #16]
	ldr	w8, [x8, #24]
	str	w8, [x3, #8]
	str	x9, [x3]
LBB45_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_declarations_nominal ; -- Begin function nvm_union_field_declarations_nominal
	.globl	_nvm_union_field_declarations_nominal
	.p2align	2
_nvm_union_field_declarations_nominal:  ; @nvm_union_field_declarations_nominal
	.cfi_startproc
; %bb.0:
	cmp	x0, #0
	ccmp	x3, #0, #4, ne
	ccmp	w2, #0, #0, ne
	and	w8, w1, #0xfffffffd
	ccmp	w8, #8, #0, eq
	cset	w8, eq
	b.ne	LBB46_2
; %bb.1:
	cmp	w1, #8
	mov	w9, #44                         ; =0x2c
	mov	w10, #42                        ; =0x2a
	csel	x9, x10, x9, eq
	ldrh	w9, [x0, x9]
	str	w9, [x3]
LBB46_2:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_declarations_retained_cost ; -- Begin function nvm_union_declarations_retained_cost
	.globl	_nvm_union_declarations_retained_cost
	.p2align	2
_nvm_union_declarations_retained_cost:  ; @nvm_union_declarations_retained_cost
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB47_5
; %bb.1:
	cbz	x2, LBB47_5
; %bb.2:
	subs	x9, x1, x2
	cmp	x9, #7
	cset	w9, hi
	sub	x10, x2, x1
	cmp	x10, #23
	cset	w10, hi
	cmp	x1, x2
	csel	w9, w9, w10, hi
	cmp	w9, #1
	b.ne	LBB47_5
; %bb.3:
	ldrb	w9, [x1, #16]
	tbz	w9, #0, LBB47_6
LBB47_4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
	mov	w0, #2                          ; =0x2
LBB47_5:
	ret
LBB47_6:
	ldp	x9, x10, [x1]
	subs	x11, x10, x9
	b.lo	LBB47_4
; %bb.7:
	cmp	x11, #31
	b.ls	LBB47_4
; %bb.8:
	add	x11, x9, #32
	str	x11, [x1]
	cbz	x8, LBB47_5
; %bb.9:
	ldr	w12, [x8, #8]
	cmp	w12, #2
	b.ne	LBB47_5
; %bb.10:
	mov	x12, x1
	ldr	x1, [x8]
	cbz	x1, LBB47_5
; %bb.11:
	ldrh	w13, [x8, #42]
	cmp	w13, #1
	b.ne	LBB47_5
; %bb.12:
	ldrh	w13, [x8, #44]
	cbnz	w13, LBB47_5
; %bb.13:
	ldrh	w14, [x8, #46]
	cmp	w14, #1
	b.hi	LBB47_5
; %bb.14:
	ldrh	w13, [x8, #48]
	sub	w15, w0, w14
	cmp	w13, w15
	b.ne	LBB47_5
; %bb.15:
	ldrb	w15, [x8, #40]
	cmp	w15, #1
	b.ne	LBB47_5
; %bb.16:
	ldrb	w15, [x8, #41]
	cmp	w15, #1
	b.ne	LBB47_5
; %bb.17:
	add	x15, x8, #16
	mov	w16, #12                        ; =0xc
	umaddl	x14, w14, w16, x15
	ldrh	w14, [x14, #10]
	cmp	w14, #1
	b.ne	LBB47_5
; %bb.18:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	stp	x12, x8, [sp, #8]               ; 16-byte Folded Spill
	str	x2, [sp]                        ; 8-byte Folded Spill
	mov	w8, #12                         ; =0xc
	umaddl	x8, w13, w8, x15
	ldrh	w8, [x8, #10]
	cbnz	w8, LBB47_35
; %bb.19:
	ldr	w8, [x15]
	cbnz	w8, LBB47_35
; %bb.20:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #28]
	cbnz	w8, LBB47_35
; %bb.21:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #24]
	cbnz	w8, LBB47_35
; %bb.22:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w12, [x8, #36]
	ldrh	w8, [x8, #26]
	cmp	w12, w8
	b.ne	LBB47_35
; %bb.23:
	subs	x8, x10, x11
	b.lo	LBB47_27
; %bb.24:
	cmp	x8, #3
	b.ls	LBB47_27
; %bb.25:
	add	x8, x9, #36
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0]
	mov	w8, #56                         ; =0x38
	str	x8, [sp, #24]
	add	x4, sp, #24
	mov	w2, #2                          ; =0x2
	mov	w3, #16                         ; =0x10
	bl	_nvm_map_copy_term
	cbnz	w0, LBB47_36
; %bb.26:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB47_28
LBB47_27:
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	strb	w9, [x8, #16]
	mov	w0, #2                          ; =0x2
	b	LBB47_36
LBB47_28:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x8, x9, [x9]
	subs	x9, x9, x8
	b.lo	LBB47_27
; %bb.29:
	cmp	x9, #7
	b.ls	LBB47_27
; %bb.30:
	add	x9, x8, #8
	ldp	x10, x8, [sp, #8]               ; 16-byte Folded Reload
	str	x9, [x10]
	ldr	x19, [x8]
	ldrb	w8, [x19]
	cmp	w8, #2
	b.ne	LBB47_35
; %bb.31:
	ldrh	w8, [x19, #2]
	cmp	w8, #1
	b.ne	LBB47_35
; %bb.32:
	ldr	x1, [x19, #8]
	add	x4, sp, #24
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	w2, #1                          ; =0x1
	mov	w3, #12                         ; =0xc
	bl	_nvm_map_copy_term
	cbnz	w0, LBB47_36
; %bb.33:
	ldr	x8, [x19, #8]
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB47_35
; %bb.34:
	ldr	w8, [x8, #4]
	cmn	w8, #1
	b.eq	LBB47_37
LBB47_35:
	mov	w0, #1                          ; =0x1
LBB47_36:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB47_37:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB47_27
; %bb.38:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x8, x9, [x9]
	subs	x9, x9, x8
	b.lo	LBB47_27
; %bb.39:
	cmp	x9, #8
	b.lo	LBB47_27
; %bb.40:
	add	x9, x8, #8
	ldp	x10, x8, [sp, #8]               ; 16-byte Folded Reload
	str	x9, [x10]
	ldr	x19, [x8]
	ldrb	w8, [x19, #16]
	cbnz	w8, LBB47_35
; %bb.41:
	ldrh	w8, [x19, #18]
	cmp	w8, #1
	b.ne	LBB47_35
; %bb.42:
	ldr	x1, [x19, #24]
	add	x4, sp, #24
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	w2, #1                          ; =0x1
	mov	w3, #12                         ; =0xc
	bl	_nvm_map_copy_term
	cbnz	w0, LBB47_36
; %bb.43:
	ldr	x8, [x19, #24]
	ldrb	w9, [x8]
	cmp	w9, #10
	b.ne	LBB47_35
; %bb.44:
	ldr	w8, [x8, #4]
	cbnz	w8, LBB47_35
; %bb.45:
	mov	w0, #0                          ; =0x0
	ldr	x9, [sp, #24]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x9, [x8]
	b	LBB47_36
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function extension_suffix_read_map
_extension_suffix_read_map:             ; @extension_suffix_read_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x6
	mov	x19, x5
	mov	x22, x4
	mov	x23, x3
	mov	x24, x2
	mov	x25, x1
	mov	x21, x0
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB48_8
; %bb.1:
	ldr	w1, [sp, #84]
	and	w8, w1, #0x3
	cmp	w1, #4
	ccmp	w8, #0, #0, hs
	b.eq	LBB48_3
LBB48_2:
	mov	w0, #9                          ; =0x9
	b	LBB48_8
LBB48_3:
	add	x2, sp, #72
	mov	x0, x21
	bl	_nvm_v2_take
	cbnz	w0, LBB48_8
; %bb.4:
	ldr	x1, [sp, #72]
	ldr	w2, [sp, #84]
	add	x0, sp, #48
	bl	_nvm_v2_cursor_init
	add	x0, sp, #48
	mov	x1, x25
	mov	x2, x24
	mov	x3, x23
	mov	x4, x22
	bl	_paths_read
	cbnz	w0, LBB48_8
; %bb.5:
	sub	x1, x29, #84
	mov	x0, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB48_8
; %bb.6:
	ldur	w8, [x29, #-84]
	sub	w8, w8, #5
	cmn	w8, #4
	b.hs	LBB48_9
; %bb.7:
	mov	w0, #13                         ; =0xd
LBB48_8:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB48_9:
	mov	x23, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	str	xzr, [sp, #40]                  ; 8-byte Folded Spill
	str	wzr, [sp, #36]                  ; 4-byte Folded Spill
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
	str	wzr, [sp, #20]                  ; 4-byte Folded Spill
	str	xzr, [sp, #8]                   ; 8-byte Folded Spill
	str	wzr, [sp, #4]                   ; 4-byte Folded Spill
	mov	w24, #0                         ; =0x0
	b	LBB48_12
LBB48_10:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	w11, #1                         ; =0x1
	str	w11, [sp, #44]                  ; 4-byte Folded Spill
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	str	w10, [sp, #36]                  ; 4-byte Folded Spill
LBB48_11:                               ;   in Loop: Header=BB48_12 Depth=1
	add	w26, w26, #1
	ldur	w9, [x29, #-84]
	mov	x22, x8
	cmp	w26, w9
	b.hs	LBB48_34
LBB48_12:                               ; =>This Inner Loop Header: Depth=1
	sub	x1, x29, #86
	mov	x0, x21
	bl	_nvm_v2_u16
	cbnz	w0, LBB48_8
; %bb.13:                               ;   in Loop: Header=BB48_12 Depth=1
	sub	x1, x29, #88
	mov	x0, x21
	bl	_nvm_v2_u16
	cbnz	w0, LBB48_8
; %bb.14:                               ;   in Loop: Header=BB48_12 Depth=1
	sub	x1, x29, #92
	mov	x0, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB48_8
; %bb.15:                               ;   in Loop: Header=BB48_12 Depth=1
	ldur	w1, [x29, #-92]
	add	x2, sp, #88
	mov	x0, x21
	bl	_nvm_v2_take
	cbnz	w0, LBB48_8
; %bb.16:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	x0, x21
	bl	_nvm_v2_align4
	cbnz	w0, LBB48_8
; %bb.17:                               ;   in Loop: Header=BB48_12 Depth=1
	ldurh	w8, [x29, #-86]
	cmp	w8, w22
	b.ls	LBB48_33
; %bb.18:                               ;   in Loop: Header=BB48_12 Depth=1
	ldurh	w9, [x29, #-88]
	cmp	w9, #1
	b.ne	LBB48_23
; %bb.19:                               ;   in Loop: Header=BB48_12 Depth=1
	ldr	x9, [sp, #88]
	ldur	w10, [x29, #-92]
	cmp	w8, #2
	b.gt	LBB48_26
; %bb.20:                               ;   in Loop: Header=BB48_12 Depth=1
	cmp	w8, #1
	b.eq	LBB48_32
; %bb.21:                               ;   in Loop: Header=BB48_12 Depth=1
	cmp	w8, #2
	b.ne	LBB48_29
; %bb.22:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	w11, #1                         ; =0x1
	str	w11, [sp, #40]                  ; 4-byte Folded Spill
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	b	LBB48_11
LBB48_23:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	w0, #3                          ; =0x3
	cmp	w8, #4
	b.ne	LBB48_8
; %bb.24:                               ;   in Loop: Header=BB48_12 Depth=1
	and	w8, w9, #0xfffe
	cmp	w8, #2
	b.ne	LBB48_8
; %bb.25:                               ;   in Loop: Header=BB48_12 Depth=1
	ldr	x25, [sp, #88]
	mov	w8, #4                          ; =0x4
	ldur	w28, [x29, #-92]
	mov	x27, x9
	b	LBB48_11
LBB48_26:                               ;   in Loop: Header=BB48_12 Depth=1
	cmp	w8, #3
	b.eq	LBB48_10
; %bb.27:                               ;   in Loop: Header=BB48_12 Depth=1
	cmp	w8, #4
	b.ne	LBB48_29
; %bb.28:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	w27, #1                         ; =0x1
	mov	x25, x9
	mov	x28, x10
	b	LBB48_11
LBB48_29:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB48_8
; %bb.30:                               ;   in Loop: Header=BB48_12 Depth=1
	cmp	w8, #5
	b.ne	LBB48_8
; %bb.31:                               ;   in Loop: Header=BB48_12 Depth=1
	str	x9, [x20]
	mov	w9, #1                          ; =0x1
	stp	w10, w9, [x20, #8]
	b	LBB48_11
LBB48_32:                               ;   in Loop: Header=BB48_12 Depth=1
	mov	x24, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	mov	x23, x9
	b	LBB48_11
LBB48_33:
	mov	w0, #8                          ; =0x8
	b	LBB48_8
LBB48_34:
	ldp	x9, x8, [x21, #8]
	cmp	x8, x9
	b.ne	LBB48_2
; %bb.35:
	mov	w0, #0                          ; =0x0
	cbz	x19, LBB48_8
; %bb.36:
	str	x23, [x19]
	str	w24, [x19, #8]
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	strh	w8, [x19, #12]
	strh	wzr, [x19, #14]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x19, #16]
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [x19, #24]
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	strh	w8, [x19, #28]
	strh	wzr, [x19, #30]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [x19, #32]
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	str	w8, [x19, #40]
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	strh	w8, [x19, #44]
	strh	wzr, [x19, #46]
	str	x25, [x19, #48]
	str	w28, [x19, #56]
	strh	w27, [x19, #60]
	strh	wzr, [x19, #62]
	b	LBB48_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function check_layouts
_check_layouts:                         ; @check_layouts
	.cfi_startproc
; %bb.0:
	ldr	w9, [x0, #8]
	cbz	w9, LBB49_3
; %bb.1:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	cmp	x9, #7
	b.hi	LBB49_4
; %bb.2:
	mov	x8, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB49_13
LBB49_3:
	mov	w0, #0                          ; =0x0
	ret
LBB49_4:
	cmp	x9, #64
	b.hs	LBB49_6
; %bb.5:
	mov	x8, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB49_10
LBB49_6:
	and	x8, x9, #0xffffffc0
	add	x10, x1, #32
	movi.2d	v0, #0000000000000000
	movi.16b	v1, #2
	mov	x11, x8
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB49_7:                                ; =>This Inner Loop Header: Depth=1
	ldp	q5, q6, [x10, #-32]
	ldp	q7, q16, [x10], #64
	and.16b	v5, v5, v1
	and.16b	v6, v6, v1
	and.16b	v7, v7, v1
	and.16b	v16, v16, v1
	cmeq.16b	v5, v5, #0
	cmeq.16b	v6, v6, #0
	cmeq.16b	v7, v7, #0
	cmeq.16b	v16, v16, #0
	orn.16b	v0, v0, v5
	orn.16b	v2, v2, v6
	orn.16b	v3, v3, v7
	orn.16b	v4, v4, v16
	subs	x11, x11, #64
	b.ne	LBB49_7
; %bb.8:
	orr.16b	v0, v2, v0
	orr.16b	v1, v4, v3
	orr.16b	v0, v1, v0
	shl.16b	v0, v0, #7
	cmlt.16b	v0, v0, #0
	umaxv.16b	b0, v0
	fmov	w10, s0
	and	w10, w10, #0x1
	cmp	x8, x9
	b.eq	LBB49_15
; %bb.9:
	tst	x9, #0x38
	b.eq	LBB49_13
LBB49_10:
	mov	x11, x8
	and	x8, x9, #0xfffffff8
	dup.8b	v0, w10
	sub	x10, x11, x8
	add	x11, x1, x11
	movi.8b	v1, #2
LBB49_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	d2, [x11], #8
	and.8b	v2, v2, v1
	cmeq.8b	v2, v2, #0
	orn.8b	v0, v0, v2
	adds	x10, x10, #8
	b.ne	LBB49_11
; %bb.12:
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w10, s0
	and	w10, w10, #0x1
	cmp	x8, x9
	b.eq	LBB49_15
LBB49_13:
	add	x11, x1, x8
	sub	x8, x9, x8
LBB49_14:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x11], #1
	and	w12, w12, #0x2
	orr	w10, w10, w12, lsr #1
	subs	x8, x8, #1
	b.ne	LBB49_14
LBB49_15:
	tbz	w10, #0, LBB49_22
; %bb.16:
	mov	x8, #0                          ; =0x0
	ldr	x11, [x0]
	b	LBB49_18
LBB49_17:                               ;   in Loop: Header=BB49_18 Depth=1
	add	x8, x8, #1
	cmp	x8, x9
	b.eq	LBB49_22
LBB49_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB49_20 Depth 2
	add	x13, x11, x8, lsl #4
	ldrh	w12, [x13, #2]
	cbz	x12, LBB49_17
; %bb.19:                               ;   in Loop: Header=BB49_18 Depth=1
	ldr	x13, [x13, #8]
	add	x13, x13, #4
LBB49_20:                               ;   Parent Loop BB49_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w14, [x13], #12
	cmn	w14, #1
	ccmp	x8, x14, #2, ne
	b.ls	LBB49_45
; %bb.21:                               ;   in Loop: Header=BB49_20 Depth=2
	subs	x12, x12, #1
	b.ne	LBB49_20
	b	LBB49_17
LBB49_22:
	mov	x11, #0                         ; =0x0
	mov	w12, #1                         ; =0x1
	mov	w13, #2                         ; =0x2
	b	LBB49_24
LBB49_23:                               ;   in Loop: Header=BB49_24 Depth=1
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB49_48
LBB49_24:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB49_30 Depth 2
	ldrb	w14, [x1, x11]
	cmp	w14, #3
	b.hi	LBB49_47
; %bb.25:                               ;   in Loop: Header=BB49_24 Depth=1
	and	w8, w14, #0x1
	cmp	w14, #2
	ccmp	w8, #0, #0, hs
	b.eq	LBB49_45
; %bb.26:                               ;   in Loop: Header=BB49_24 Depth=1
	tbz	w14, #0, LBB49_23
; %bb.27:                               ;   in Loop: Header=BB49_24 Depth=1
	ldr	x15, [x0]
	add	x8, x15, x11, lsl #4
	ldrb	w17, [x8]
	cmp	w17, #2
	csel	w16, wzr, w4, ne
	cmp	w17, #0
	ccmp	w16, #0, #0, ne
	b.eq	LBB49_45
; %bb.28:                               ;   in Loop: Header=BB49_24 Depth=1
	ldrh	w16, [x8, #2]
	cbz	x16, LBB49_43
; %bb.29:                               ;   in Loop: Header=BB49_24 Depth=1
	cmp	w14, #1
	csel	w6, wzr, w5, ne
	cmp	w14, #2
	csel	w7, wzr, w3, hs
	ldr	x8, [x8, #8]
	cmp	w17, #0
	csel	w19, wzr, w6, ne
	add	x17, x8, #4
	eor	w6, w7, #0x1
	eor	w7, w19, #0x1
LBB49_30:                               ;   Parent Loop BB49_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w19, [x17, #-4]
	sub	w8, w19, #1
	cmp	w8, #4
	b.ls	LBB49_33
; %bb.31:                               ;   in Loop: Header=BB49_30 Depth=2
	cmp	w19, #7
	csinc	w8, w6, wzr, eq
	tbz	w8, #0, LBB49_33
; %bb.32:                               ;   in Loop: Header=BB49_30 Depth=2
	cmp	w19, #13
	csinc	w8, w7, wzr, eq
	tbnz	w8, #0, LBB49_35
LBB49_33:                               ;   in Loop: Header=BB49_30 Depth=2
	ldr	w8, [x17]
	cmn	w8, #1
	b.ne	LBB49_45
LBB49_34:                               ;   in Loop: Header=BB49_30 Depth=2
	add	x17, x17, #12
	subs	x16, x16, #1
	b.ne	LBB49_30
	b	LBB49_43
LBB49_35:                               ;   in Loop: Header=BB49_30 Depth=2
	cmp	w19, #10
	csel	w8, wzr, w4, ne
	cmp	w19, #8
	b.eq	LBB49_37
; %bb.36:                               ;   in Loop: Header=BB49_30 Depth=2
	cbz	w8, LBB49_45
LBB49_37:                               ;   in Loop: Header=BB49_30 Depth=2
	ldr	w20, [x17]
	cmp	x20, x11
	cset	w21, hs
	mov	w8, #8                          ; =0x8
	cmp	x20, x9
	b.hs	LBB49_46
; %bb.38:                               ;   in Loop: Header=BB49_30 Depth=2
	and	w21, w10, w21
	tbnz	w21, #0, LBB49_46
; %bb.39:                               ;   in Loop: Header=BB49_30 Depth=2
	lsl	x8, x20, #4
	ldrb	w8, [x15, x8]
	cmp	w19, #8
	csel	w19, wzr, w13, eq
	cmp	w19, w8
	b.ne	LBB49_45
; %bb.40:                               ;   in Loop: Header=BB49_30 Depth=2
	ldrb	w8, [x1, x20]
	tbz	w8, #0, LBB49_45
; %bb.41:                               ;   in Loop: Header=BB49_30 Depth=2
	cmp	w14, #1
	b.hi	LBB49_34
; %bb.42:                               ;   in Loop: Header=BB49_30 Depth=2
	tbz	w8, #1, LBB49_34
	b	LBB49_45
LBB49_43:                               ;   in Loop: Header=BB49_24 Depth=1
	cmp	w14, #2
	b.lo	LBB49_23
; %bb.44:                               ;   in Loop: Header=BB49_24 Depth=1
	strb	w12, [x2]
	b	LBB49_23
LBB49_45:
	mov	w8, #8                          ; =0x8
LBB49_46:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB49_47:
	mov	w8, #7                          ; =0x7
	b	LBB49_46
LBB49_48:
	mov	w8, #0                          ; =0x0
	b	LBB49_46
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor
_descriptor:                            ; @descriptor
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x7
	mov	x19, x6
	mov	x24, x5
	mov	x25, x4
	mov	x23, x3
	mov	x22, x2
	mov	x21, x1
	mov	x26, x0
	add	x1, sp, #47
	bl	_nvm_v2_u8
	cbnz	w0, LBB50_6
; %bb.1:
	add	x1, sp, #46
	mov	x0, x26
	bl	_nvm_v2_u8
	cbnz	w0, LBB50_6
; %bb.2:
	add	x1, sp, #44
	mov	x0, x26
	bl	_nvm_v2_u16
	cbnz	w0, LBB50_6
; %bb.3:
	add	x1, sp, #40
	mov	x0, x26
	bl	_nvm_v2_u32
	cbnz	w0, LBB50_6
; %bb.4:
	ldrh	w8, [sp, #44]
	cbz	w8, LBB50_7
; %bb.5:
	mov	w0, #7                          ; =0x7
LBB50_6:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB50_7:
	ldrb	w8, [sp, #46]
	cmp	w8, #0
	cset	w10, eq
	cmp	w8, #3
	cset	w11, lo
	ldrb	w9, [sp, #47]
	cmp	w25, #0
	csel	w10, w11, w10, ne
	mov	w0, #8                          ; =0x8
	cmp	w9, #15
	b.hi	LBB50_6
; %bb.8:
	cbz	w10, LBB50_6
; %bb.9:
	tbnz	w24, #31, LBB50_11
; %bb.10:
	cmp	w24, w9
	b.ne	LBB50_6
LBB50_11:
	ldr	x10, [x29, #16]
	ldr	w1, [sp, #40]
	cbz	x10, LBB50_19
; %bb.12:
	cmp	w9, #7
	b.ne	LBB50_19
; %bb.13:
	cmn	w1, #1
	b.eq	LBB50_24
; %bb.14:
	cmp	w23, #3
	b.ne	LBB50_6
; %bb.15:
	cbnz	w8, LBB50_6
; %bb.16:
	ldr	w8, [x10]
	cmp	w8, w1
	b.hi	LBB50_18
; %bb.17:
	add	w8, w1, #1
	str	w8, [x10]
LBB50_18:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	b	LBB50_6
LBB50_19:
	cmn	w1, #1
	b.eq	LBB50_25
; %bb.20:
	ldr	w10, [x21, #8]
	cmp	w1, w10
	b.hs	LBB50_26
; %bb.21:
	cmp	w9, #8
	b.ne	LBB50_27
; %bb.22:
	ldrb	w9, [x22, x1]
	tbz	w9, #0, LBB50_6
; %bb.23:
	ldr	x9, [x21]
	lsl	x10, x1, #4
	ldrb	w9, [x9, x10]
	cbnz	w9, LBB50_6
	b	LBB50_33
LBB50_24:
	mov	w9, #1                          ; =0x1
	strb	w9, [x10, #4]
LBB50_25:
	mov	w9, #8                          ; =0x8
	cmp	w8, #0
	csel	w0, wzr, w9, eq
	b	LBB50_6
LBB50_26:
	mov	w0, #13                         ; =0xd
	b	LBB50_6
LBB50_27:
	cmp	w23, #3
	b.ne	LBB50_6
; %bb.28:
	cmp	w9, #10
	b.ne	LBB50_6
; %bb.29:
	ldrb	w9, [x22, x1]
	cbz	w9, LBB50_31
; %bb.30:
	tbz	w9, #0, LBB50_6
LBB50_31:
	ldr	x9, [x21]
	lsl	x10, x1, #4
	ldrb	w9, [x9, x10]
	cmp	w9, #2
	b.ne	LBB50_6
; %bb.32:
	mov	w9, #1                          ; =0x1
	strb	w9, [x19]
LBB50_33:
	mov	w9, #8                          ; =0x8
	cmp	w8, #0
	csel	w0, wzr, w9, eq
	cbz	w8, LBB50_6
; %bb.34:
	ldrb	w9, [x22, x1]
	tbz	w9, #1, LBB50_39
; %bb.35:
	mov	w22, #1                         ; =0x1
	str	x22, [sp]
	stp	wzr, w1, [sp, #8]
	str	xzr, [sp, #16]
	stp	wzr, w1, [sp, #24]
	stp	w8, wzr, [sp, #32]
	mov	x2, sp
	mov	x0, x21
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_reference_place_valid
	tbz	w0, #0, LBB50_37
; %bb.36:
	mov	w0, #0                          ; =0x0
	strb	w22, [x19]
	b	LBB50_6
LBB50_37:
	cbz	x20, LBB50_39
; %bb.38:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20]
LBB50_39:
	mov	w0, #8                          ; =0x8
	b	LBB50_6
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function globals_read
_globals_read:                          ; @globals_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	mov	x20, x2
	mov	x8, x0
	mov	w2, w1
	add	x0, sp, #24
	mov	x1, x8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #24
	add	x1, sp, #20
	bl	_nvm_v2_u32
	cbnz	w0, LBB51_3
; %bb.1:
	ldr	w8, [sp, #20]
	sub	w8, w8, #257
	cmn	w8, #256
	b.hs	LBB51_4
LBB51_2:
	mov	w0, #13                         ; =0xd
LBB51_3:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB51_4:
	mov	w21, #0                         ; =0x0
	mov	w22, #2                         ; =0x2
	b	LBB51_7
LBB51_5:                                ;   in Loop: Header=BB51_7 Depth=1
	ldr	w8, [sp, #12]
	cmn	w8, #1
	b.ne	LBB51_18
LBB51_6:                                ;   in Loop: Header=BB51_7 Depth=1
	add	w21, w21, #1
	ldr	w8, [sp, #20]
	cmp	w21, w8
	b.hs	LBB51_19
LBB51_7:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #24
	add	x1, sp, #19
	bl	_nvm_v2_u8
	cbnz	w0, LBB51_3
; %bb.8:                                ;   in Loop: Header=BB51_7 Depth=1
	add	x0, sp, #24
	add	x1, sp, #18
	bl	_nvm_v2_u8
	cbnz	w0, LBB51_3
; %bb.9:                                ;   in Loop: Header=BB51_7 Depth=1
	add	x0, sp, #24
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB51_3
; %bb.10:                               ;   in Loop: Header=BB51_7 Depth=1
	add	x0, sp, #24
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB51_3
; %bb.11:                               ;   in Loop: Header=BB51_7 Depth=1
	ldrh	w8, [sp, #16]
	mov	w0, #7                          ; =0x7
	cbnz	w8, LBB51_3
; %bb.12:                               ;   in Loop: Header=BB51_7 Depth=1
	ldrb	w8, [sp, #18]
	cmp	w8, #1
	b.hi	LBB51_3
; %bb.13:                               ;   in Loop: Header=BB51_7 Depth=1
	ldrb	w8, [sp, #19]
	sub	w9, w8, #1
	cmp	w9, #4
	b.ls	LBB51_5
; %bb.14:                               ;   in Loop: Header=BB51_7 Depth=1
	orr	w9, w8, #0x2
	cmp	w9, #10
	b.ne	LBB51_18
; %bb.15:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	w9, [sp, #12]
	ldr	w10, [x20, #8]
	cmp	w9, w10
	b.hs	LBB51_2
; %bb.16:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	x10, [x20]
	lsl	x11, x9, #4
	ldrb	w10, [x10, x11]
	cmp	w8, #8
	csel	w8, wzr, w22, eq
	cmp	w8, w10
	b.ne	LBB51_18
; %bb.17:                               ;   in Loop: Header=BB51_7 Depth=1
	ldrb	w8, [x19, x9]
	tbnz	w8, #0, LBB51_6
LBB51_18:
	mov	w0, #8                          ; =0x8
	b	LBB51_3
LBB51_19:
	ldp	x9, x8, [sp, #32]
	cmp	x8, x9
	mov	w8, #9                          ; =0x9
	csel	w0, wzr, w8, eq
	b	LBB51_3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effects_read
_effects_read:                          ; @effects_read
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #7344                       ; =0x1cb0
Lloh100:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh101:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3248
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x28, x7
	mov	x27, x6
	mov	x21, x5
	mov	x22, x4
	mov	x23, x3
	mov	x24, x2
	mov	x25, x1
	mov	x1, x0
Lloh102:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh103:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh104:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w2, w25
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	bl	_nvm_v2_cursor_init
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #104
	mov	w1, #2064                       ; =0x810
	bl	_bzero
	add	x0, sp, #2148
	mov	w1, #2052                       ; =0x804
	bl	_bzero
	ubfx	x19, x25, #32, #16
	cmp	w19, #2
	b.lo	LBB52_6
; %bb.1:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #2148
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.2:
	ldr	w8, [sp, #2148]
	sub	w8, w8, #257
	cmn	w8, #256
	b.lo	LBB52_42
; %bb.3:
	mov	x25, #0                         ; =0x0
	add	x8, sp, #2148
	add	x26, x8, #4
LBB52_4:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	mov	x1, x23
	mov	x2, x22
	mov	w3, #0                          ; =0x0
	mov	x4, x25
	mov	w5, #1                          ; =0x1
	mov	x6, x26
	bl	_effect_value_read
	cbnz	w0, LBB52_43
; %bb.5:                                ;   in Loop: Header=BB52_4 Depth=1
	add	x25, x25, #1
	ldr	w8, [sp, #2148]
	add	x26, x26, #8
	cmp	x25, x8
	b.lo	LBB52_4
LBB52_6:
	ldr	x20, [x29, #16]
	cbz	x20, LBB52_35
; %bb.7:
	ldp	w26, w25, [x20]
	cmp	w19, #3
	b.ne	LBB52_36
LBB52_8:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2208
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.9:
	ldr	w8, [sp, #6304]
	cmp	w8, #8, lsl #12                 ; =32768
	b.hi	LBB52_42
; %bb.10:
	stp	w25, w26, [sp, #56]             ; 8-byte Folded Spill
	stp	x28, x27, [sp, #40]             ; 16-byte Folded Spill
	cbz	w8, LBB52_80
; %bb.11:
	mov	w25, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	add	x8, sp, #2148
	add	x8, x8, #4
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	mov	w9, #-1                         ; =0xffffffff
	mov	w27, #-1                        ; =0xffffffff
LBB52_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB52_26 Depth 2
	str	w9, [sp, #76]                   ; 4-byte Folded Spill
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2204
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.13:                               ;   in Loop: Header=BB52_12 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2200
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.14:                               ;   in Loop: Header=BB52_12 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2196
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.15:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	x9, [x24, #256]
	cbz	x9, LBB52_42
; %bb.16:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	w8, [sp, #6300]
	ldr	w10, [x24, #272]
	cmp	w8, w10
	b.hs	LBB52_42
; %bb.17:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	w10, [sp, #6292]
	ldr	w11, [sp, #2148]
	cmp	w10, w11
	b.hs	LBB52_42
; %bb.18:                               ;   in Loop: Header=BB52_12 Depth=1
	cbz	w25, LBB52_22
; %bb.19:                               ;   in Loop: Header=BB52_12 Depth=1
	cmp	w8, w27
	b.lo	LBB52_79
; %bb.20:                               ;   in Loop: Header=BB52_12 Depth=1
	cmp	w8, w27
	b.ne	LBB52_22
; %bb.21:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	w10, [sp, #6296]
	cmp	w10, w26
	b.ls	LBB52_79
LBB52_22:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	x10, [x24, #280]
	cbz	x10, LBB52_42
; %bb.23:                               ;   in Loop: Header=BB52_12 Depth=1
	mov	w10, #24                        ; =0x18
	umaddl	x26, w8, w10, x9
	ldr	w9, [x26, #8]
	ldr	w10, [x24, #288]
	subs	w10, w10, w9
	b.lo	LBB52_42
; %bb.24:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	w11, [x26, #12]
	ldr	w9, [sp, #6296]
	cmp	w11, w10
	ccmp	w9, w11, #2, ls
	b.hs	LBB52_42
; %bb.25:                               ;   in Loop: Header=BB52_12 Depth=1
	cmp	w8, w27
	csel	w28, w28, wzr, eq
	cmp	w28, w9
	b.hs	LBB52_28
LBB52_26:                               ;   Parent Loop BB52_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x24, #280]
	ldp	w9, w10, [x26, #8]
	add	x8, x8, x9
	add	x0, x8, w28, uxtw
	sub	w1, w10, w28
	add	x2, sp, #80
	bl	_isa_decode
	cbz	w0, LBB52_79
; %bb.27:                               ;   in Loop: Header=BB52_26 Depth=2
	ldr	w9, [sp, #6296]
	add	w28, w0, w28
	cmp	w28, w9
	b.lo	LBB52_26
LBB52_28:                               ;   in Loop: Header=BB52_12 Depth=1
	cmp	w28, w9
	b.ne	LBB52_79
; %bb.29:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	x8, [x24, #280]
	ldp	w9, w10, [x26, #8]
	add	x8, x8, x9
	add	x0, x8, w28, uxtw
	sub	w1, w10, w28
	add	x2, sp, #80
	bl	_isa_decode
	cbz	w0, LBB52_79
; %bb.30:                               ;   in Loop: Header=BB52_12 Depth=1
	ldrb	w8, [sp, #80]
	cmp	w8, #80
	b.eq	LBB52_33
; %bb.31:                               ;   in Loop: Header=BB52_12 Depth=1
	cmp	w8, #88
	b.ne	LBB52_79
; %bb.32:                               ;   in Loop: Header=BB52_12 Depth=1
	ldrh	w8, [sp, #96]
	cbnz	w8, LBB52_79
LBB52_33:                               ;   in Loop: Header=BB52_12 Depth=1
	ldrb	w9, [sp, #88]
	ldr	w8, [sp, #6292]
	lsl	x10, x8, #3
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	ldrb	w10, [x11, x10]
	cmp	w9, w10
	b.ne	LBB52_79
; %bb.34:                               ;   in Loop: Header=BB52_12 Depth=1
	ldr	w27, [sp, #6300]
	ldr	w26, [sp, #6296]
	ldp	w10, w9, [sp, #56]              ; 8-byte Folded Reload
	cmp	w10, w26
	ccmp	w9, w27, #0, eq
	ldr	w9, [sp, #76]                   ; 4-byte Folded Reload
	csel	w9, w8, w9, eq
	add	w28, w0, w28
	add	w25, w25, #1
	ldr	w8, [sp, #6304]
	cmp	w25, w8
	b.lo	LBB52_12
	b	LBB52_81
LBB52_35:
	mov	w25, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	cmp	w19, #3
	b.eq	LBB52_8
LBB52_36:
	mov	w9, #-1                         ; =0xffffffff
LBB52_37:
	str	w9, [sp, #76]                   ; 4-byte Folded Spill
	cmn	w21, #1
	b.eq	LBB52_39
; %bb.38:
	mov	x0, x24
	mov	x1, x21
	bl	_nvm_get_string
	cbnz	x0, LBB52_40
	b	LBB52_42
LBB52_39:
	mov	x0, #0                          ; =0x0
LBB52_40:
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2204
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.41:
	ldr	w8, [sp, #6300]
	sub	w8, w8, #257
	cmn	w8, #256
	b.hs	LBB52_45
LBB52_42:
	mov	w0, #13                         ; =0xd
LBB52_43:
	ldur	x8, [x29, #-96]
Lloh105:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh106:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh107:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB52_83
; %bb.44:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3248
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB52_45:
	stp	w25, w26, [sp, #56]             ; 8-byte Folded Spill
	mov	x25, #0                         ; =0x0
	str	wzr, [sp, #20]                  ; 4-byte Folded Spill
	add	x8, sp, #80
	add	x8, x8, #16
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	str	x27, [sp, #48]                  ; 8-byte Folded Spill
LBB52_46:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB52_58 Depth 2
                                        ;     Child Loop BB52_63 Depth 2
	add	x0, sp, #80
	mov	w1, #2064                       ; =0x810
	bl	_bzero
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB52_43
; %bb.47:                               ;   in Loop: Header=BB52_46 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x8, sp, #80
	add	x1, x8, #4
	bl	_nvm_v2_u16
	cbnz	w0, LBB52_43
; %bb.48:                               ;   in Loop: Header=BB52_46 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2200
	bl	_nvm_v2_u16
	cbnz	w0, LBB52_43
; %bb.49:                               ;   in Loop: Header=BB52_46 Depth=1
	ldrh	w8, [sp, #6296]
	cbnz	w8, LBB52_82
; %bb.50:                               ;   in Loop: Header=BB52_46 Depth=1
	ldrh	w8, [sp, #84]
	cmp	w8, #256
	b.hi	LBB52_42
; %bb.51:                               ;   in Loop: Header=BB52_46 Depth=1
	ldr	w1, [sp, #80]
	ldr	w8, [x24, #248]
	cmp	w1, w8
	b.hs	LBB52_42
; %bb.52:                               ;   in Loop: Header=BB52_46 Depth=1
	mov	x0, x24
	bl	_nvm_get_string
	mov	x26, x0
	ldr	w1, [sp, #80]
	mov	x0, x24
	bl	_nvm_get_string_len
	mov	x8, x0
	mov	w0, #8                          ; =0x8
	cbz	x26, LBB52_43
; %bb.53:                               ;   in Loop: Header=BB52_46 Depth=1
	cbz	w8, LBB52_43
; %bb.54:                               ;   in Loop: Header=BB52_46 Depth=1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	mov	w2, w8
	mov	x0, x26
	mov	w1, #0                          ; =0x0
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	_memchr
	cbnz	x0, LBB52_79
; %bb.55:                               ;   in Loop: Header=BB52_46 Depth=1
	cbz	x25, LBB52_60
; %bb.56:                               ;   in Loop: Header=BB52_46 Depth=1
	ldr	w8, [sp, #80]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2208
	add	x9, x9, x25, lsl #2
	ldur	w9, [x9, #-4]
	cmp	w8, w9
	b.ls	LBB52_79
; %bb.57:                               ;   in Loop: Header=BB52_46 Depth=1
	mov	x27, #0                         ; =0x0
LBB52_58:                               ;   Parent Loop BB52_46 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2208
	ldr	w1, [x8, x27, lsl #2]
	mov	x0, x24
	bl	_nvm_get_string
	mov	x1, x0
	mov	x0, x26
	bl	_strcmp
	cbz	w0, LBB52_79
; %bb.59:                               ;   in Loop: Header=BB52_58 Depth=2
	add	x27, x27, #1
	cmp	x25, x27
	b.ne	LBB52_58
LBB52_60:                               ;   in Loop: Header=BB52_46 Depth=1
	cmp	w19, #1
	cset	w5, hi
	ldr	w8, [sp, #80]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2208
	str	w8, [x9, x25, lsl #2]
	ldr	w4, [sp, #2148]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	add	x8, sp, #80
	add	x6, x8, #8
	mov	x1, x23
	mov	x2, x22
	mov	w3, #1                          ; =0x1
	bl	_effect_value_read
	cbnz	w0, LBB52_43
; %bb.61:                               ;   in Loop: Header=BB52_46 Depth=1
	str	x28, [sp, #40]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #84]
	cbz	w8, LBB52_65
; %bb.62:                               ;   in Loop: Header=BB52_46 Depth=1
	mov	x27, #0                         ; =0x0
	ldr	x28, [sp, #24]                  ; 8-byte Folded Reload
LBB52_63:                               ;   Parent Loop BB52_46 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w19, #1
	cset	w5, hi
	ldr	w4, [sp, #2148]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2168
	mov	x1, x23
	mov	x2, x22
	mov	w3, #0                          ; =0x0
	mov	x6, x28
	bl	_effect_value_read
	cbnz	w0, LBB52_43
; %bb.64:                               ;   in Loop: Header=BB52_63 Depth=2
	add	x27, x27, #1
	ldrh	w8, [sp, #84]
	add	x28, x28, #8
	cmp	x27, x8
	b.lo	LBB52_63
LBB52_65:                               ;   in Loop: Header=BB52_46 Depth=1
	cmn	w21, #1
	b.eq	LBB52_69
; %bb.66:                               ;   in Loop: Header=BB52_46 Depth=1
	mov	x0, x24
	mov	x1, x21
	bl	_nvm_get_string_len
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	cmp	w0, w8
	ldp	x28, x27, [sp, #40]             ; 16-byte Folded Reload
	b.ne	LBB52_70
; %bb.67:                               ;   in Loop: Header=BB52_46 Depth=1
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	mov	x1, x26
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	bl	_memcmp
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	cbnz	w0, LBB52_71
; %bb.68:                               ;   in Loop: Header=BB52_46 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #104
	add	x1, sp, #80
	mov	w2, #2064                       ; =0x810
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB52_71
LBB52_69:                               ;   in Loop: Header=BB52_46 Depth=1
	mov	w8, #1                          ; =0x1
	ldp	x28, x27, [sp, #40]             ; 16-byte Folded Reload
	b	LBB52_71
LBB52_70:                               ;   in Loop: Header=BB52_46 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
LBB52_71:                               ;   in Loop: Header=BB52_46 Depth=1
	add	x25, x25, #1
	ldr	w9, [sp, #6300]
	cmp	x25, x9
	ldr	w26, [sp, #60]                  ; 4-byte Folded Reload
	b.lo	LBB52_46
; %bb.72:
	ldr	x9, [sp, #6280]
	ldr	x10, [sp, #6272]
	cmp	x9, x10
	cset	w9, eq
	and	w8, w9, w8
	mov	w9, #9                          ; =0x9
	mov	w10, #13                        ; =0xd
	csel	w0, w10, w9, eq
	cmp	w8, #1
	b.ne	LBB52_43
; %bb.73:
	cmp	x27, #0
	cset	w8, ne
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, w9
	cmp	w8, #1
	b.ne	LBB52_75
; %bb.74:
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #104
	mov	x0, x27
	mov	w2, #2064                       ; =0x810
	bl	_memcpy
LBB52_75:
	ldr	w19, [sp, #56]                  ; 4-byte Folded Reload
	cbz	x28, LBB52_77
; %bb.76:
	add	x1, sp, #2148
	mov	x0, x28
	mov	w2, #2052                       ; =0x804
	bl	_memcpy
LBB52_77:
	mov	w0, #0                          ; =0x0
	cbz	x20, LBB52_43
; %bb.78:
	stp	w26, w19, [x20]
	ldr	w8, [sp, #76]                   ; 4-byte Folded Reload
	str	w8, [x20, #8]
	b	LBB52_43
LBB52_79:
	mov	w0, #8                          ; =0x8
	b	LBB52_43
LBB52_80:
	mov	w9, #-1                         ; =0xffffffff
LBB52_81:
	ldp	x28, x27, [sp, #40]             ; 16-byte Folded Reload
	ldp	w25, w26, [sp, #56]             ; 8-byte Folded Reload
	b	LBB52_37
LBB52_82:
	mov	w0, #7                          ; =0x7
	b	LBB52_43
LBB52_83:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh102, Lloh103, Lloh104
	.loh AdrpLdrGotLdr	Lloh105, Lloh106, Lloh107
	.loh AdrpLdrGot	Lloh100, Lloh101
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_array_fields
_oaa_array_fields:                      ; @oaa_array_fields
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	mov	w9, #8544                       ; =0x2160
Lloh108:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh109:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x19, x2
	mov	x8, x0
Lloh110:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh111:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh112:
	ldr	x9, [x9]
	stur	x9, [x29, #-72]
	mov	w2, w1
	add	x0, sp, #64
	mov	x1, x8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #64
	add	x1, sp, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB53_5
; %bb.1:
	ldr	w8, [sp, #60]
	cmp	w8, #1, lsl #12                 ; =4096
	b.ls	LBB53_3
LBB53_2:
	mov	w8, #3                          ; =0x3
	str	w8, [x19, #300]
	mov	w0, #13                         ; =0xd
	b	LBB53_5
LBB53_3:
	lsl	x1, x8, #3
	add	x0, sp, #64
	add	x2, sp, #48
	bl	_nvm_v2_take
	cbnz	w0, LBB53_5
; %bb.4:
	add	x0, sp, #64
	add	x1, sp, #56
	bl	_nvm_v2_u32
	cbz	w0, LBB53_7
LBB53_5:
	ldur	x8, [x29, #-72]
Lloh113:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh114:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh115:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB53_104
; %bb.6:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #352
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB53_7:
	ldr	w8, [sp, #56]
	cmp	w8, #16, lsl #12                ; =65536
	b.hi	LBB53_2
; %bb.8:
	add	x8, x8, x8, lsl #1
	lsl	x1, x8, #2
	add	x0, sp, #64
	add	x2, sp, #40
	bl	_nvm_v2_take
	cbnz	w0, LBB53_5
; %bb.9:
	ldp	x9, x8, [sp, #72]
	cmp	x8, x9
	b.ne	LBB53_13
; %bb.10:
	ldr	w9, [x19, #8]
	lsl	x8, x9, #4
	add	x8, x8, #312
	cbz	w9, LBB53_19
; %bb.11:
	ldr	x10, [x19]
	cmp	w9, #4
	b.hs	LBB53_14
; %bb.12:
	mov	x11, #0                         ; =0x0
	b	LBB53_17
LBB53_13:
	mov	w0, #9                          ; =0x9
	b	LBB53_5
LBB53_14:
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x11, x9, #0xfffffffc
	add	x15, x10, #34
	mov	w16, #12                        ; =0xc
	mov	x17, x11
LBB53_15:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w0, [x15, #-32]
	ldurh	w1, [x15, #-16]
	ldrh	w2, [x15]
	ldrh	w3, [x15, #16]
	umaddl	x8, w0, w16, x8
	umaddl	x12, w1, w16, x12
	umaddl	x13, w2, w16, x13
	umaddl	x14, w3, w16, x14
	add	x15, x15, #64
	subs	x17, x17, #4
	b.ne	LBB53_15
; %bb.16:
	add	x8, x12, x8
	add	x12, x14, x13
	add	x8, x12, x8
	cmp	x11, x9
	b.eq	LBB53_19
LBB53_17:
	add	x10, x10, x11, lsl #4
	add	x10, x10, #2
	sub	x9, x9, x11
	mov	w11, #12                        ; =0xc
LBB53_18:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w12, [x10], #16
	umaddl	x8, w12, w11, x8
	subs	x9, x9, #1
	b.ne	LBB53_18
LBB53_19:
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB53_2
; %bb.20:
	ldp	w21, w22, [sp, #56]
	lsl	x20, x22, #3
	mov	w9, #12                         ; =0xc
	umaddl	x9, w21, w9, x20
	mov	w10, #16777216                  ; =0x1000000
	sub	x8, x10, x8
	cmp	x9, x8
	b.hi	LBB53_2
; %bb.21:
	str	w22, [x19, #288]
	str	w21, [x19, #292]
	cbz	w22, LBB53_23
; %bb.22:
	mov	x0, x22
	mov	w1, #8                          ; =0x8
	bl	_calloc
	str	x0, [x19, #16]
LBB53_23:
	cbz	w21, LBB53_25
; %bb.24:
	mov	x0, x21
	mov	w1, #12                         ; =0xc
	bl	_calloc
	str	x0, [x19, #24]
LBB53_25:
	cbz	w22, LBB53_27
; %bb.26:
	ldr	x8, [x19, #16]
	cbz	x8, LBB53_50
LBB53_27:
	cbz	w21, LBB53_29
; %bb.28:
	ldr	x8, [x19, #24]
	cbz	x8, LBB53_50
LBB53_29:
	ldr	x1, [sp, #48]
	add	x0, sp, #16
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	ldr	w8, [sp, #60]
	cbz	w8, LBB53_80
; %bb.30:
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	add	x23, x19, #32
	mov	w24, #1                         ; =0x1
LBB53_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x19, #296]
	cmp	w8, #256, lsl #12               ; =1048576
	b.eq	LBB53_2
; %bb.32:                               ;   in Loop: Header=BB53_31 Depth=1
	add	w8, w8, #1
	str	w8, [x19, #296]
	add	x0, sp, #16
	add	x1, sp, #88
	bl	_nvm_v2_u8
	cbnz	w0, LBB53_5
; %bb.33:                               ;   in Loop: Header=BB53_31 Depth=1
	add	x0, sp, #16
	add	x1, sp, #12
	bl	_nvm_v2_u8
	cbnz	w0, LBB53_5
; %bb.34:                               ;   in Loop: Header=BB53_31 Depth=1
	add	x0, sp, #16
	add	x1, sp, #344
	bl	_nvm_v2_u16
	cbnz	w0, LBB53_5
; %bb.35:                               ;   in Loop: Header=BB53_31 Depth=1
	add	x0, sp, #16
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #344
	bl	_nvm_v2_u32
	cbnz	w0, LBB53_5
; %bb.36:                               ;   in Loop: Header=BB53_31 Depth=1
	ldrb	w8, [sp, #12]
	mov	w0, #7                          ; =0x7
	cbnz	w8, LBB53_5
; %bb.37:                               ;   in Loop: Header=BB53_31 Depth=1
	ldrh	w8, [sp, #344]
	cbnz	w8, LBB53_5
; %bb.38:                               ;   in Loop: Header=BB53_31 Depth=1
	ldrb	w8, [sp, #88]
	sub	w9, w8, #1
	cmp	w9, #5
	b.hs	LBB53_42
; %bb.39:                               ;   in Loop: Header=BB53_31 Depth=1
	ldr	w9, [sp, #4440]
	cmn	w9, #1
	b.ne	LBB53_49
; %bb.40:                               ;   in Loop: Header=BB53_31 Depth=1
	mov	w9, #-1                         ; =0xffffffff
LBB53_41:                               ;   in Loop: Header=BB53_31 Depth=1
	ldr	x10, [x19, #16]
	add	x10, x10, x21
	strb	w8, [x10]
	sturh	wzr, [x10, #1]
	strb	wzr, [x10, #3]
	str	w9, [x10, #4]
	add	x22, x22, #1
	ldr	w20, [sp, #60]
	add	x21, x21, #8
	cmp	x22, x20
	b.lo	LBB53_31
	b	LBB53_51
LBB53_42:                               ;   in Loop: Header=BB53_31 Depth=1
	cmp	w8, #7
	b.eq	LBB53_48
; %bb.43:                               ;   in Loop: Header=BB53_31 Depth=1
	cmp	w8, #8
	b.ne	LBB53_129
; %bb.44:                               ;   in Loop: Header=BB53_31 Depth=1
	ldr	w9, [sp, #4440]
	ldr	w10, [x19, #8]
	cmp	w9, w10
	b.hs	LBB53_129
; %bb.45:                               ;   in Loop: Header=BB53_31 Depth=1
	ldr	x10, [x19]
	lsl	x11, x9, #4
	ldrb	w10, [x10, x11]
	cbnz	w10, LBB53_129
; %bb.46:                               ;   in Loop: Header=BB53_31 Depth=1
	ldrb	w10, [x23, x9]
	cmp	w10, #1
	b.ne	LBB53_129
; %bb.47:                               ;   in Loop: Header=BB53_31 Depth=1
	strb	w24, [x19, #304]
	b	LBB53_41
LBB53_48:                               ;   in Loop: Header=BB53_31 Depth=1
	ldr	w9, [sp, #4440]
	ldr	w10, [sp, #60]
	cmp	w9, w10
	b.lo	LBB53_41
LBB53_49:
	mov	w0, #13                         ; =0xd
	b	LBB53_5
LBB53_50:
	mov	w8, #4                          ; =0x4
	str	w8, [x19, #300]
	mov	w0, #1                          ; =0x1
	b	LBB53_5
LBB53_51:
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #344
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #344
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	add	x22, sp, #344
	add	x0, sp, #344
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	cbz	x20, LBB53_80
; %bb.52:
	mov	x8, #0                          ; =0x0
	add	x9, sp, #88
	sub	x10, x9, #8
	sub	x11, x9, #4
	mov	w12, #1                         ; =0x1
	mov	w13, #64                        ; =0x40
	mov	w14, #2                         ; =0x2
	mov	w15, #4                         ; =0x4
LBB53_53:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB53_54 Depth 2
                                        ;     Child Loop BB53_66 Depth 2
                                        ;     Child Loop BB53_68 Depth 2
	mov	x17, #0                         ; =0x0
	ldrb	w1, [x21, x8]
	mov	x16, x8
LBB53_54:                               ;   Parent Loop BB53_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbnz	w1, LBB53_59
; %bb.55:                               ;   in Loop: Header=BB53_54 Depth=2
	ldr	w0, [x19, #296]
	cmp	w0, #256, lsl #12               ; =1048576
	b.eq	LBB53_2
; %bb.56:                               ;   in Loop: Header=BB53_54 Depth=2
	add	w0, w0, #1
	str	w0, [x19, #296]
	cmp	x17, #64
	b.eq	LBB53_2
; %bb.57:                               ;   in Loop: Header=BB53_54 Depth=2
	strb	w12, [x21, x16]
	str	w16, [x9, x17, lsl #2]
	ldr	x0, [x19, #16]
	add	x16, x0, x16, lsl #3
	ldrb	w0, [x16]
	cmp	w0, #7
	b.ne	LBB53_62
; %bb.58:                               ;   in Loop: Header=BB53_54 Depth=2
	ldr	w16, [x16, #4]
	ldrb	w1, [x21, x16]
	add	x17, x17, #1
	mov	w0, #8                          ; =0x8
	cmp	w1, #1
	b.ne	LBB53_54
	b	LBB53_5
LBB53_59:                               ;   in Loop: Header=BB53_53 Depth=1
	cmp	w1, #2
	b.ne	LBB53_61
; %bb.60:                               ;   in Loop: Header=BB53_53 Depth=1
	ldrb	w16, [x22, x16]
	b	LBB53_63
LBB53_61:                               ;   in Loop: Header=BB53_53 Depth=1
	mov	w16, #0                         ; =0x0
	b	LBB53_63
LBB53_62:                               ;   in Loop: Header=BB53_53 Depth=1
	mov	w16, #0                         ; =0x0
	add	x17, x17, #1
LBB53_63:                               ;   in Loop: Header=BB53_53 Depth=1
	mov	w0, w17
	cbz	x0, LBB53_70
; %bb.64:                               ;   in Loop: Header=BB53_53 Depth=1
	sub	x1, x17, #1
	subs	w2, w13, w16
	csel	w2, wzr, w2, lo
	cmp	x1, x2
	csel	x2, x1, x2, lo
	cmp	x2, #4
	b.lo	LBB53_68
; %bb.65:                               ;   in Loop: Header=BB53_53 Depth=1
	add	x1, x2, #1
	ands	x3, x1, #0x3
	csel	x3, x15, x3, eq
	sub	x1, x1, x3
	sub	x0, x0, x1
	add	w1, w16, w1
	mvn	x2, x2
	add	x2, x2, x3
	add	x17, x10, x17, lsl #2
LBB53_66:                               ;   Parent Loop BB53_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	w4, w3, [x17]
	ldp	w6, w5, [x17, #-8]
	strb	w14, [x21, x3]
	strb	w14, [x21, x4]
	strb	w14, [x21, x5]
	strb	w14, [x21, x6]
	add	w7, w16, #1
	add	w23, w16, #2
	add	w24, w16, #3
	strb	w7, [x22, x3]
	strb	w23, [x22, x4]
	add	w16, w16, #4
	sub	x17, x17, #16
	strb	w24, [x22, x5]
	strb	w16, [x22, x6]
	add	x2, x2, #4
	cbnz	x2, LBB53_66
; %bb.67:                               ;   in Loop: Header=BB53_53 Depth=1
	mov	x16, x1
LBB53_68:                               ;   Parent Loop BB53_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w16, #64
	b.hs	LBB53_2
; %bb.69:                               ;   in Loop: Header=BB53_68 Depth=2
	add	w16, w16, #1
	ldr	w17, [x11, x0, lsl #2]
	strb	w14, [x21, x17]
	strb	w16, [x22, x17]
	subs	x0, x0, #1
	b.ne	LBB53_68
LBB53_70:                               ;   in Loop: Header=BB53_53 Depth=1
	add	x8, x8, #1
	cmp	x8, x20
	b.ne	LBB53_53
; %bb.71:
	ldr	x8, [x19, #16]
	add	x9, x8, #4
	mov	w10, #1                         ; =0x1
	b	LBB53_73
LBB53_72:                               ;   in Loop: Header=BB53_73 Depth=1
	add	x9, x9, #8
	subs	x20, x20, #1
	b.eq	LBB53_80
LBB53_73:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w11, [x9, #-4]
	cmp	w11, #7
	b.ne	LBB53_72
; %bb.74:                               ;   in Loop: Header=BB53_73 Depth=1
	ldr	w12, [x19, #296]
	cmp	w12, #256, lsl #12              ; =1048576
	b.eq	LBB53_2
; %bb.75:                               ;   in Loop: Header=BB53_73 Depth=1
	add	w14, w12, #1
	str	w14, [x19, #296]
	ldr	w11, [x9]
	add	x11, x8, x11, lsl #3
	ldrb	w13, [x11]
	ldr	w11, [x11, #4]
	cmp	w13, #7
	b.ne	LBB53_78
; %bb.76:                               ;   in Loop: Header=BB53_73 Depth=1
	cmp	w14, #256, lsl #12              ; =1048576
	b.eq	LBB53_2
; %bb.77:                               ;   in Loop: Header=BB53_73 Depth=1
	add	w12, w12, #2
	str	w12, [x19, #296]
	add	x11, x8, x11, lsl #3
	ldrb	w13, [x11]
	ldr	w11, [x11, #4]
LBB53_78:                               ;   in Loop: Header=BB53_73 Depth=1
	sub	w12, w13, #6
	cmn	w12, #5
	ccmn	w11, #1, #0, hs
	b.eq	LBB53_72
; %bb.79:                               ;   in Loop: Header=BB53_73 Depth=1
	strb	w10, [x19, #304]
	b	LBB53_72
LBB53_80:
	ldr	x1, [sp, #40]
	ldr	w8, [sp, #56]
	add	x8, x8, x8, lsl #1
	lsl	x2, x8, #2
	add	x0, sp, #16
	bl	_nvm_v2_cursor_init
	ldr	w8, [sp, #56]
	cbz	w8, LBB53_88
; %bb.81:
	ldr	w8, [x19, #296]
	cmp	w8, #256, lsl #12               ; =1048576
	b.eq	LBB53_2
; %bb.82:
	add	w8, w8, #1
	str	w8, [x19, #296]
	add	x0, sp, #16
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB53_5
; %bb.83:
	add	x0, sp, #16
	add	x1, sp, #6
	bl	_nvm_v2_u16
	cbnz	w0, LBB53_5
; %bb.84:
	add	x0, sp, #16
	add	x1, sp, #4
	bl	_nvm_v2_u16
	cbnz	w0, LBB53_5
; %bb.85:
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB53_5
; %bb.86:
	ldrh	w8, [sp, #4]
	cbz	w8, LBB53_105
LBB53_87:
	mov	w0, #7                          ; =0x7
	b	LBB53_5
LBB53_88:
	mov	x8, #0                          ; =0x0
LBB53_89:
	ldr	w9, [x19, #8]
	cbz	w9, LBB53_102
; %bb.90:
	mov	x11, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x12, x19
	ldr	x13, [x12], #32
	mov	w14, #12                        ; =0xc
	b	LBB53_92
LBB53_91:                               ;   in Loop: Header=BB53_92 Depth=1
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB53_103
LBB53_92:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB53_95 Depth 2
	add	x15, x13, x11, lsl #4
	ldrh	w16, [x15, #2]
	cbz	x16, LBB53_91
; %bb.93:                               ;   in Loop: Header=BB53_92 Depth=1
	mov	x17, #0                         ; =0x0
	ldr	w0, [x19, #296]
	b	LBB53_95
LBB53_94:                               ;   in Loop: Header=BB53_95 Depth=2
	add	x17, x17, #1
	cmp	x17, x16
	b.eq	LBB53_91
LBB53_95:                               ;   Parent Loop BB53_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w0, #256, lsl #12               ; =1048576
	b.eq	LBB53_2
; %bb.96:                               ;   in Loop: Header=BB53_95 Depth=2
	add	w0, w0, #1
	str	w0, [x19, #296]
	ldrb	w1, [x12, x11]
	cmp	w1, #1
	b.ne	LBB53_94
; %bb.97:                               ;   in Loop: Header=BB53_95 Depth=2
	ldur	x1, [x15, #8]
	mul	x2, x17, x14
	ldrb	w1, [x1, x2]
	cmp	w1, #7
	b.ne	LBB53_94
; %bb.98:                               ;   in Loop: Header=BB53_95 Depth=2
	cmp	x10, x8
	b.hs	LBB53_129
; %bb.99:                               ;   in Loop: Header=BB53_95 Depth=2
	ldr	x1, [x19, #24]
	madd	x1, x10, x14, x1
	ldr	w2, [x1]
	cmp	x11, x2
	b.ne	LBB53_129
; %bb.100:                              ;   in Loop: Header=BB53_95 Depth=2
	ldrh	w1, [x1, #4]
	cmp	x17, x1
	b.ne	LBB53_129
; %bb.101:                              ;   in Loop: Header=BB53_95 Depth=2
	add	x10, x10, #1
	b	LBB53_94
LBB53_102:
	mov	x10, #0                         ; =0x0
LBB53_103:
	cmp	x10, x8
	mov	w8, #8                          ; =0x8
	csel	w0, wzr, w8, eq
	b	LBB53_5
LBB53_104:
	bl	___stack_chk_fail
LBB53_105:
	ldr	w8, [sp, #12]
	ldr	w9, [x19, #8]
	cmp	w8, w9
	b.hs	LBB53_129
; %bb.106:
	ldr	w9, [sp, #8]
	ldr	w10, [sp, #60]
	cmp	w9, w10
	b.hs	LBB53_129
; %bb.107:
	add	x20, x19, #32
	ldrb	w10, [x20, x8]
	cmp	w10, #1
	b.ne	LBB53_129
; %bb.108:
	ldr	x10, [x19]
	add	x11, x10, x8, lsl #4
	ldrb	w10, [x11]
	cbnz	w10, LBB53_129
; %bb.109:
	ldrh	w10, [sp, #6]
	ldrh	w12, [x11, #2]
	cmp	w10, w12
	b.hs	LBB53_129
; %bb.110:
	ldr	x11, [x11, #8]
	mov	w12, #12                        ; =0xc
	umull	x12, w10, w12
	ldrb	w11, [x11, x12]
	cmp	w11, #7
	b.ne	LBB53_129
; %bb.111:
	ldr	x11, [x19, #24]
	str	w8, [x11]
	strh	w10, [x11, #4]
	strh	wzr, [x11, #6]
	str	w9, [x11, #8]
	ldr	w8, [sp, #56]
	cmp	w8, #2
	b.lo	LBB53_89
; %bb.112:
	mov	x21, #0                         ; =0x0
	mov	w22, #1                         ; =0x1
	mov	w23, #12                        ; =0xc
	b	LBB53_114
LBB53_113:                              ;   in Loop: Header=BB53_114 Depth=1
	str	w8, [x12, #12]
	add	x8, x11, x21
	strh	w10, [x8, #16]
	strh	wzr, [x8, #18]
	str	w9, [x8, #20]
	add	x22, x22, #1
	ldr	w8, [sp, #56]
	add	x21, x21, #12
	cmp	x22, x8
	b.hs	LBB53_89
LBB53_114:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x19, #296]
	cmp	w8, #256, lsl #12               ; =1048576
	b.eq	LBB53_2
; %bb.115:                              ;   in Loop: Header=BB53_114 Depth=1
	add	w8, w8, #1
	str	w8, [x19, #296]
	add	x0, sp, #16
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB53_5
; %bb.116:                              ;   in Loop: Header=BB53_114 Depth=1
	add	x0, sp, #16
	add	x1, sp, #6
	bl	_nvm_v2_u16
	cbnz	w0, LBB53_5
; %bb.117:                              ;   in Loop: Header=BB53_114 Depth=1
	add	x0, sp, #16
	add	x1, sp, #4
	bl	_nvm_v2_u16
	cbnz	w0, LBB53_5
; %bb.118:                              ;   in Loop: Header=BB53_114 Depth=1
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB53_5
; %bb.119:                              ;   in Loop: Header=BB53_114 Depth=1
	ldrh	w8, [sp, #4]
	cbnz	w8, LBB53_87
; %bb.120:                              ;   in Loop: Header=BB53_114 Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [x19, #8]
	cmp	w8, w9
	b.hs	LBB53_129
; %bb.121:                              ;   in Loop: Header=BB53_114 Depth=1
	ldr	w9, [sp, #8]
	ldr	w10, [sp, #60]
	cmp	w9, w10
	b.hs	LBB53_129
; %bb.122:                              ;   in Loop: Header=BB53_114 Depth=1
	ldrb	w10, [x20, x8]
	cmp	w10, #1
	b.ne	LBB53_129
; %bb.123:                              ;   in Loop: Header=BB53_114 Depth=1
	ldr	x10, [x19]
	add	x11, x10, x8, lsl #4
	ldrb	w10, [x11]
	cbnz	w10, LBB53_129
; %bb.124:                              ;   in Loop: Header=BB53_114 Depth=1
	ldrh	w10, [sp, #6]
	ldrh	w12, [x11, #2]
	cmp	w10, w12
	b.hs	LBB53_129
; %bb.125:                              ;   in Loop: Header=BB53_114 Depth=1
	ldr	x11, [x11, #8]
	umull	x12, w10, w23
	ldrb	w11, [x11, x12]
	cmp	w11, #7
	b.ne	LBB53_129
; %bb.126:                              ;   in Loop: Header=BB53_114 Depth=1
	ldr	x11, [x19, #24]
	add	x12, x11, x21
	ldr	w13, [x12]
	cmp	w8, w13
	b.lo	LBB53_129
; %bb.127:                              ;   in Loop: Header=BB53_114 Depth=1
	b.ne	LBB53_113
; %bb.128:                              ;   in Loop: Header=BB53_114 Depth=1
	add	x13, x11, x21
	ldrh	w13, [x13, #4]
	cmp	w10, w13
	b.hi	LBB53_113
LBB53_129:
	mov	w0, #8                          ; =0x8
	b	LBB53_5
	.loh AdrpLdrGotLdr	Lloh110, Lloh111, Lloh112
	.loh AdrpLdrGotLdr	Lloh113, Lloh114, Lloh115
	.loh AdrpLdrGot	Lloh108, Lloh109
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_payload
_map_payload:                           ; @map_payload
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #208]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #224]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #240]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x9, x0
Lloh116:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh117:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh118:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	ldr	x10, [x0, #56]
	mov	w8, #2097024                    ; =0x1fff80
	cmp	x10, x8
	b.hi	LBB54_2
; %bb.1:
	mov	w8, w2
	lsl	x11, x8, #1
	ldr	x12, [x9, #64]
	mov	w13, #4194304                   ; =0x400000
	sub	x13, x13, x12
	cmp	x12, #1024, lsl #12             ; =4194304
	ccmp	x11, x13, #2, ls
	b.ls	LBB54_3
LBB54_2:
	mov	w0, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #72]
	b	LBB54_6
LBB54_3:
	mov	x25, x4
	mov	x24, x3
	add	x13, sp, #48
	add	x10, x10, #128
	add	x11, x12, x11
	stp	x10, x11, [x9, #56]
	mov	x23, x9
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x13, #96]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	add	x19, sp, #48
	stp	q0, q0, [sp, #48]
	add	x0, x19, #32
	mov	x20, x2
	mov	x2, x8
	bl	_nvm_v2_cursor_init
	and	x8, x20, #0xffff00000000
	mov	x9, #4294967296                 ; =0x100000000
	cmp	x8, x9
	b.ne	LBB54_5
; %bb.4:
	add	x0, x19, #32
	add	x1, x19, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB54_8
LBB54_5:
	mov	w0, #0                          ; =0x0
LBB54_6:
	ldur	x8, [x29, #-104]
Lloh119:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh120:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh121:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB54_42
; %bb.7:
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #240]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #224]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
LBB54_8:
	ldr	w8, [sp, #148]
	sub	w9, w8, #6
	cmn	w9, #6
	b.hi	LBB54_10
LBB54_9:
	mov	w0, #0                          ; =0x0
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, ne
	str	w8, [x23, #72]
	b	LBB54_6
LBB54_10:
	lsl	x1, x8, #3
	add	x0, x19, #32
	add	x2, sp, #40
	bl	_nvm_v2_take
	cbnz	w0, LBB54_5
; %bb.11:
	add	x8, sp, #48
	add	x0, x19, #32
	add	x1, x8, #104
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.12:
	ldr	w8, [sp, #152]
	sub	w9, w8, #26
	cmn	w9, #26
	b.ls	LBB54_9
; %bb.13:
	lsl	x1, x8, #3
	add	x0, x19, #32
	add	x2, sp, #32
	bl	_nvm_v2_take
	cbnz	w0, LBB54_5
; %bb.14:
	add	x8, sp, #48
	add	x0, x19, #32
	add	x1, x8, #108
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.15:
	ldr	w8, [sp, #156]
	mov	w9, #-65537                     ; =0xfffeffff
	add	w9, w8, w9
	cmn	w9, #16, lsl #12                ; =65536
	b.lo	LBB54_9
; %bb.16:
	add	x8, x8, x8, lsl #1
	lsl	x1, x8, #2
	add	x0, x19, #32
	add	x2, sp, #24
	bl	_nvm_v2_take
	cbnz	w0, LBB54_5
; %bb.17:
	ldp	x9, x8, [sp, #88]
	cmp	x8, x9
	b.ne	LBB54_5
; %bb.18:
	ldr	w8, [x24, #8]
	cmp	w8, #256
	b.hi	LBB54_5
; %bb.19:
	ldp	w19, w21, [sp, #148]
	ldr	w20, [sp, #156]
	stp	w19, w21, [x23, #40]
	str	w20, [x23, #48]
	ldr	w8, [x24, #8]
	str	w8, [x23, #52]
	mov	x0, x23
	mov	x1, x19
	mov	w2, #1                          ; =0x1
	bl	_map_alloc
	str	x0, [x23, #8]
	cbz	x0, LBB54_6
; %bb.20:
	mov	x0, x23
	mov	x1, x21
	mov	w2, #8                          ; =0x8
	bl	_map_alloc
	str	x0, [x23, #16]
	cbz	x0, LBB54_6
; %bb.21:
	mov	x0, x23
	mov	x1, x20
	mov	w2, #12                         ; =0xc
	bl	_map_alloc
	str	x0, [x23, #24]
	cbz	x0, LBB54_6
; %bb.22:
	mov	x0, x23
	mov	w1, #257                        ; =0x101
	mov	w2, #4                          ; =0x4
	bl	_map_alloc
	str	x0, [x23, #32]
	ldr	x9, [x23, #8]
	cbz	x9, LBB54_5
; %bb.23:
	ldr	x9, [x23, #16]
	cbz	x9, LBB54_5
; %bb.24:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB54_6
; %bb.25:
	ldr	x8, [x23, #24]
	cbz	x8, LBB54_6
; %bb.26:
	add	x20, sp, #48
	ldr	x1, [sp, #40]
	lsl	x2, x19, #3
	add	x0, x20, #56
	bl	_nvm_v2_cursor_init
	str	wzr, [sp, #160]
	ldr	w8, [sp, #148]
	cbnz	w8, LBB54_30
LBB54_27:
	ldr	x1, [sp, #32]
	ldr	w8, [sp, #152]
	lsl	x2, x8, #3
	add	x0, x20, #56
	bl	_nvm_v2_cursor_init
	str	wzr, [sp, #160]
	ldr	w8, [sp, #152]
	cbz	w8, LBB54_54
; %bb.28:
	add	x19, sp, #8
	mov	w21, #65533                     ; =0xfffd
	movk	w21, #63, lsl #16
	add	x22, sp, #48
	mov	w26, #1                         ; =0x1
	b	LBB54_44
LBB54_29:                               ;   in Loop: Header=BB54_30 Depth=1
	ldr	x10, [x23, #8]
	strb	w8, [x10, x9]
	ldrb	w8, [sp, #23]
	strb	w8, [sp, #168]
	ldr	w8, [sp, #160]
	ldr	w9, [sp, #148]
	add	w8, w8, #1
	str	w8, [sp, #160]
	cmp	w8, w9
	b.hs	LBB54_27
LBB54_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #56]
	cmp	x8, #512, lsl #12               ; =2097152
	b.hi	LBB54_89
; %bb.31:                               ;   in Loop: Header=BB54_30 Depth=1
	ldr	x8, [x23, #64]
	cmp	x8, #1024, lsl #12              ; =4194304
	b.hs	LBB54_89
; %bb.32:                               ;   in Loop: Header=BB54_30 Depth=1
	add	x8, x8, #1
	str	x8, [x23, #64]
	add	x0, x20, #56
	add	x1, sp, #23
	bl	_nvm_v2_u8
	cbnz	w0, LBB54_5
; %bb.33:                               ;   in Loop: Header=BB54_30 Depth=1
	add	x0, x20, #56
	add	x1, sp, #22
	bl	_nvm_v2_u8
	cbnz	w0, LBB54_5
; %bb.34:                               ;   in Loop: Header=BB54_30 Depth=1
	add	x0, x20, #56
	add	x1, sp, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB54_5
; %bb.35:                               ;   in Loop: Header=BB54_30 Depth=1
	add	x0, x20, #56
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.36:                               ;   in Loop: Header=BB54_30 Depth=1
	ldrb	w8, [sp, #22]
	cbnz	w8, LBB54_5
; %bb.37:                               ;   in Loop: Header=BB54_30 Depth=1
	ldrh	w8, [sp, #20]
	cbnz	w8, LBB54_5
; %bb.38:                               ;   in Loop: Header=BB54_30 Depth=1
	ldr	w8, [sp, #8]
	cmn	w8, #1
	b.ne	LBB54_5
; %bb.39:                               ;   in Loop: Header=BB54_30 Depth=1
	ldrb	w8, [sp, #23]
	sub	w9, w8, #1
	cmp	w9, #4
	b.hi	LBB54_5
; %bb.40:                               ;   in Loop: Header=BB54_30 Depth=1
	ldr	w9, [sp, #160]
	cbz	w9, LBB54_29
; %bb.41:                               ;   in Loop: Header=BB54_30 Depth=1
	ldrb	w10, [sp, #168]
	cmp	w8, w10
	b.hi	LBB54_29
	b	LBB54_5
LBB54_42:
	bl	___stack_chk_fail
LBB54_43:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	x9, [x23, #16]
	ldr	x10, [sp, #8]
	str	x10, [x9, x8, lsl #3]
	ldr	x8, [sp, #8]
	str	x8, [sp, #128]
	strb	w26, [x22, w8, uxtw]
	lsr	x8, x8, #32
	strb	w26, [x22, x8]
	ldr	w8, [sp, #160]
	ldr	w9, [sp, #152]
	add	w8, w8, #1
	str	w8, [sp, #160]
	cmp	w8, w9
	b.hs	LBB54_54
LBB54_44:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #56]
	cmp	x8, #512, lsl #12               ; =2097152
	b.hi	LBB54_89
; %bb.45:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	x8, [x23, #64]
	cmp	x8, x21
	b.hs	LBB54_89
; %bb.46:                               ;   in Loop: Header=BB54_44 Depth=1
	add	x8, x8, #4
	str	x8, [x23, #64]
	add	x0, x20, #56
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.47:                               ;   in Loop: Header=BB54_44 Depth=1
	add	x0, x20, #56
	orr	x1, x19, #0x4
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.48:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	w10, [sp, #8]
	ldr	w8, [sp, #148]
	cmp	w10, w8
	b.hs	LBB54_5
; %bb.49:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	w9, [sp, #12]
	cmp	w9, w8
	b.hs	LBB54_5
; %bb.50:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	w8, [sp, #160]
	cbz	w8, LBB54_43
; %bb.51:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	w11, [sp, #128]
	cmp	w10, w11
	b.lo	LBB54_5
; %bb.52:                               ;   in Loop: Header=BB54_44 Depth=1
	b.ne	LBB54_43
; %bb.53:                               ;   in Loop: Header=BB54_44 Depth=1
	ldr	w10, [sp, #132]
	cmp	w9, w10
	b.hi	LBB54_43
	b	LBB54_5
LBB54_54:
	ldr	x1, [sp, #24]
	ldr	w8, [sp, #156]
	add	x8, x8, x8, lsl #1
	lsl	x2, x8, #2
	add	x0, x20, #56
	bl	_nvm_v2_cursor_init
	str	wzr, [sp, #160]
	ldr	w8, [sp, #156]
	cbz	w8, LBB54_75
; %bb.55:
	add	x19, sp, #8
	add	x21, sp, #48
	mov	w8, #5                          ; =0x5
	orr	x22, x21, x8
	mov	w26, #4194300                   ; =0x3ffffc
	mov	w27, #12                        ; =0xc
	mov	w28, #1                         ; =0x1
LBB54_56:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #56]
	cmp	x8, #512, lsl #12               ; =2097152
	b.hi	LBB54_89
; %bb.57:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	x8, [x23, #64]
	cmp	x8, x26
	b.hs	LBB54_89
; %bb.58:                               ;   in Loop: Header=BB54_56 Depth=1
	add	x8, x8, #5
	str	x8, [x23, #64]
	add	x0, x20, #56
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.59:                               ;   in Loop: Header=BB54_56 Depth=1
	add	x0, x20, #56
	add	x1, x19, #4
	bl	_nvm_v2_u16
	cbnz	w0, LBB54_5
; %bb.60:                               ;   in Loop: Header=BB54_56 Depth=1
	add	x0, x20, #56
	add	x1, sp, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB54_5
; %bb.61:                               ;   in Loop: Header=BB54_56 Depth=1
	add	x0, x20, #56
	add	x1, x19, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_5
; %bb.62:                               ;   in Loop: Header=BB54_56 Depth=1
	ldrh	w8, [sp, #20]
	cbnz	w8, LBB54_5
; %bb.63:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	w9, [sp, #8]
	ldr	w8, [x24, #8]
	cmp	w9, w8
	b.hs	LBB54_5
; %bb.64:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	w8, [sp, #16]
	ldr	w10, [sp, #152]
	cmp	w8, w10
	b.hs	LBB54_5
; %bb.65:                               ;   in Loop: Header=BB54_56 Depth=1
	ldrh	w10, [sp, #12]
	ldr	x8, [x24]
	add	x11, x8, x9, lsl #4
	ldrh	w8, [x11, #2]
	cmp	w10, w8
	b.hs	LBB54_5
; %bb.66:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	w8, [sp, #160]
	cbz	w8, LBB54_70
; %bb.67:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	w12, [sp, #136]
	cmp	w9, w12
	b.lo	LBB54_5
; %bb.68:                               ;   in Loop: Header=BB54_56 Depth=1
	cmp	w9, w12
	b.ne	LBB54_70
; %bb.69:                               ;   in Loop: Header=BB54_56 Depth=1
	ldrh	w12, [sp, #140]
	cmp	w10, w12
	b.ls	LBB54_5
LBB54_70:                               ;   in Loop: Header=BB54_56 Depth=1
	ldrb	w12, [x11]
	cbnz	w12, LBB54_5
; %bb.71:                               ;   in Loop: Header=BB54_56 Depth=1
	ldrb	w9, [x25, x9]
	cmp	w9, #1
	b.ne	LBB54_5
; %bb.72:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	x9, [x11, #8]
	umaddl	x9, w10, w27, x9
	ldrb	w10, [x9]
	cmp	w10, #13
	b.ne	LBB54_5
; %bb.73:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	w9, [x9, #4]
	cmn	w9, #1
	b.ne	LBB54_5
; %bb.74:                               ;   in Loop: Header=BB54_56 Depth=1
	ldr	x9, [x23, #24]
	umaddl	x8, w8, w27, x9
	ldr	x9, [sp, #8]
	ldr	w10, [sp, #16]
	str	w10, [x8, #8]
	str	x9, [x8]
	ldr	x8, [sp, #8]
	stur	x8, [x21, #88]
	ldr	w8, [sp, #16]
	stur	w8, [x21, #96]
	strb	w28, [x22, x8]
	ldp	w9, w8, [sp, #156]
	add	w8, w8, #1
	str	w8, [sp, #160]
	cmp	w8, w9
	b.lo	LBB54_56
LBB54_75:
	str	xzr, [sp, #160]
	ldr	w13, [x24, #8]
	cbz	w13, LBB54_90
; %bb.76:
	mov	w15, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	ldr	x9, [x24]
	ldr	x10, [x23, #56]
	mov	w11, #4194303                   ; =0x3fffff
	mov	w12, #12                        ; =0xc
LBB54_77:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB54_82 Depth 2
	cmp	x10, #512, lsl #12              ; =2097152
	b.hi	LBB54_100
; %bb.78:                               ;   in Loop: Header=BB54_77 Depth=1
	ldr	x14, [x23, #64]
	cmp	x14, #1024, lsl #12             ; =4194304
	b.hs	LBB54_100
; %bb.79:                               ;   in Loop: Header=BB54_77 Depth=1
	add	x13, x9, w15, uxtw #4
	add	x14, x14, #1
	str	x14, [x23, #64]
	ldr	x16, [x23, #32]
	str	w8, [x16, w15, uxtw #2]
	ldrh	w16, [x13, #2]
	ldp	w8, w15, [sp, #160]
	cbz	x16, LBB54_88
; %bb.80:                               ;   in Loop: Header=BB54_77 Depth=1
	mov	x17, #0                         ; =0x0
	ldr	w0, [sp, #156]
	b	LBB54_82
LBB54_81:                               ;   in Loop: Header=BB54_82 Depth=2
	add	x17, x17, #1
	cmp	x17, x16
	b.eq	LBB54_88
LBB54_82:                               ;   Parent Loop BB54_77 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x14, x11
	b.hs	LBB54_100
; %bb.83:                               ;   in Loop: Header=BB54_82 Depth=2
	add	x14, x14, #2
	str	x14, [x23, #64]
	ldr	x1, [x13, #8]
	mul	x2, x17, x12
	ldrb	w1, [x1, x2]
	cmp	w1, #13
	b.ne	LBB54_81
; %bb.84:                               ;   in Loop: Header=BB54_82 Depth=2
	cmp	x8, x0
	b.hs	LBB54_5
; %bb.85:                               ;   in Loop: Header=BB54_82 Depth=2
	ldr	x1, [x23, #24]
	madd	x1, x8, x12, x1
	ldr	w2, [x1]
	cmp	w2, w15
	b.ne	LBB54_5
; %bb.86:                               ;   in Loop: Header=BB54_82 Depth=2
	ldrh	w1, [x1, #4]
	cmp	x17, x1
	b.ne	LBB54_5
; %bb.87:                               ;   in Loop: Header=BB54_82 Depth=2
	add	x8, x8, #1
	str	w8, [sp, #160]
	b	LBB54_81
LBB54_88:                               ;   in Loop: Header=BB54_77 Depth=1
	add	w15, w15, #1
	str	w15, [sp, #164]
	ldr	w13, [x24, #8]
	cmp	w15, w13
	b.lo	LBB54_77
	b	LBB54_91
LBB54_89:
	mov	w8, #3                          ; =0x3
	str	w8, [x23, #72]
	b	LBB54_5
LBB54_90:
	mov	x8, #0                          ; =0x0
LBB54_91:
	ldr	x9, [x23, #32]
	str	w8, [x9, w13, uxtw #2]
	ldp	w9, w8, [sp, #156]
	cmp	w8, w9
	b.ne	LBB54_5
; %bb.92:
	ldr	w8, [sp, #148]
	cbz	w8, LBB54_98
; %bb.93:
	ldr	x9, [x23, #56]
	cmp	x9, #512, lsl #12               ; =2097152
	b.hi	LBB54_100
; %bb.94:
	ldr	x10, [x23, #64]
	mov	w9, #4194304                    ; =0x400000
	cmp	x10, #1024, lsl #12             ; =4194304
	csel	x9, x10, x9, lo
	sub	x9, x9, #1024, lsl #12          ; =4194304
	add	x10, x10, #1
	add	x11, sp, #48
LBB54_95:                               ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB54_100
; %bb.96:                               ;   in Loop: Header=BB54_95 Depth=1
	str	x10, [x23, #64]
	ldrb	w12, [x11], #1
	cbz	w12, LBB54_5
; %bb.97:                               ;   in Loop: Header=BB54_95 Depth=1
	add	x9, x9, #1
	add	x10, x10, #1
	subs	x8, x8, #1
	b.ne	LBB54_95
LBB54_98:
	ldr	w9, [sp, #152]
	cbz	w9, LBB54_101
; %bb.99:
	ldr	x8, [x23, #56]
	cmp	x8, #512, lsl #12               ; =2097152
	b.ls	LBB54_102
LBB54_100:
	mov	w0, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
	str	w8, [x23, #72]
	b	LBB54_6
LBB54_101:
	mov	w0, #1                          ; =0x1
	b	LBB54_6
LBB54_102:
	mov	w8, #5                          ; =0x5
	add	x10, sp, #48
	orr	x8, x10, x8
	ldr	x11, [x23, #64]
	sub	x9, x9, #1
	mov	w10, #4194304                   ; =0x400000
	cmp	x11, #1024, lsl #12             ; =4194304
	csel	x10, x11, x10, lo
	sub	x10, x10, #1024, lsl #12        ; =4194304
	add	x11, x11, #1
LBB54_103:                              ; =>This Inner Loop Header: Depth=1
	cbz	x10, LBB54_100
; %bb.104:                              ;   in Loop: Header=BB54_103 Depth=1
	str	x11, [x23, #64]
	ldrb	w13, [x8], #1
	cmp	w13, #0
	cset	w0, ne
	subs	x9, x9, #1
	cset	w12, hs
	cbz	w13, LBB54_6
; %bb.105:                              ;   in Loop: Header=BB54_103 Depth=1
	add	x10, x10, #1
	add	x11, x11, #1
	tbnz	w12, #0, LBB54_103
	b	LBB54_6
	.loh AdrpLdrGotLdr	Lloh116, Lloh117, Lloh118
	.loh AdrpLdrGotLdr	Lloh119, Lloh120, Lloh121
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_value_read
_effect_value_read:                     ; @effect_value_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x6
	mov	x23, x5
	mov	x21, x4
	mov	x24, x3
	mov	x20, x2
	mov	x22, x1
	mov	x25, x0
	str	xzr, [sp]
	mov	x1, sp
	bl	_nvm_v2_u8
	cbnz	w0, LBB55_4
; %bb.1:
	add	x1, sp, #15
	mov	x0, x25
	bl	_nvm_v2_u8
	cbnz	w0, LBB55_4
; %bb.2:
	add	x1, sp, #12
	mov	x0, x25
	bl	_nvm_v2_u16
	cbnz	w0, LBB55_4
; %bb.3:
	mov	x8, sp
	orr	x1, x8, #0x4
	mov	x0, x25
	bl	_nvm_v2_u32
	cbz	w0, LBB55_5
LBB55_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB55_5:
	ldrb	w8, [sp, #15]
	mov	w0, #7                          ; =0x7
	cbnz	w8, LBB55_4
; %bb.6:
	ldrh	w8, [sp, #12]
	cbnz	w8, LBB55_4
; %bb.7:
	ldrb	w8, [sp]
	tst	w8, #0xff
	csel	w9, wzr, w24, ne
	tbnz	w9, #0, LBB55_13
; %bb.8:
	sub	w9, w8, #1
	and	w9, w9, #0xff
	cmp	w9, #4
	b.ls	LBB55_13
; %bb.9:
	orr	w9, w8, #0x2
	and	w9, w9, #0xff
	cmp	w9, #10
	b.ne	LBB55_15
; %bb.10:
	ldr	w9, [sp, #4]
	ldr	w10, [x22, #8]
	cmp	w9, w10
	b.hs	LBB55_19
; %bb.11:
	and	w8, w8, #0xff
	ldr	x10, [x22]
	lsl	x11, x9, #4
	ldrb	w10, [x10, x11]
	mov	w11, #2                         ; =0x2
	cmp	w8, #8
	csel	w8, wzr, w11, eq
	cmp	w8, w10
	b.ne	LBB55_14
; %bb.12:
	ldrb	w8, [x20, x9]
	tbz	w8, #0, LBB55_14
	b	LBB55_18
LBB55_13:
	ldr	w8, [sp, #4]
	cmn	w8, #1
	b.eq	LBB55_18
LBB55_14:
	mov	w0, #8                          ; =0x8
	b	LBB55_4
LBB55_15:
	mov	w0, #8                          ; =0x8
	cbz	w23, LBB55_4
; %bb.16:
	and	w8, w8, #0xff
	cmp	w8, #7
	b.ne	LBB55_4
; %bb.17:
	ldr	w8, [sp, #4]
	cmp	w8, w21
	b.hs	LBB55_19
LBB55_18:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp]
	str	x8, [x19]
	b	LBB55_4
LBB55_19:
	mov	w0, #13                         ; =0xd
	b	LBB55_4
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_alloc
_map_alloc:                             ; @map_alloc
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mul	x8, x2, x1
	ldr	x9, [x0, #56]
	mov	w10, #2097152                   ; =0x200000
	sub	x10, x10, x9
	cmp	x9, #512, lsl #12               ; =2097152
	ccmp	x8, x10, #2, ls
	b.hi	LBB56_2
; %bb.1:
	ldr	x10, [x0, #64]
	cmp	x10, #1024, lsl #12             ; =4194304
	b.ls	LBB56_5
LBB56_2:
	mov	w9, #3                          ; =0x3
LBB56_3:
	mov	x8, #0                          ; =0x0
	str	w9, [x0, #72]
LBB56_4:
	mov	x0, x8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB56_5:
	add	x8, x9, x8
	mov	x19, x0
	str	x8, [x0, #56]
	mov	x0, x1
	mov	x1, x2
	bl	_calloc
	mov	x8, x0
	cbnz	x0, LBB56_4
; %bb.6:
	mov	w9, #4                          ; =0x4
	mov	x0, x19
	b	LBB56_3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oaa_prepare_map
lCPI57_0:
	.long	2                               ; 0x2
	.long	4294967295                      ; 0xffffffff
	.long	4294967295                      ; 0xffffffff
	.long	0                               ; 0x0
lCPI57_1:
	.long	4                               ; 0x4
	.long	4294967295                      ; 0xffffffff
	.long	4294967295                      ; 0xffffffff
	.long	0                               ; 0x0
lCPI57_2:
	.long	1                               ; 0x1
	.long	4294967295                      ; 0xffffffff
	.long	4294967295                      ; 0xffffffff
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oaa_prepare_map:                       ; @oaa_prepare_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	d9, d8, [sp, #80]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	cbz	x0, LBB57_11
; %bb.1:
	cbz	x1, LBB57_11
; %bb.2:
	ldr	x10, [x0, #312]
	ldr	w9, [x0, #320]
	cmp	x9, #0
	cset	w11, eq
	cmp	x10, #0
	cset	w12, ne
	cmp	w12, w11
	b.eq	LBB57_11
; %bb.3:
	ldr	x11, [x0, #296]
	ldr	w12, [x0, #304]
	cmp	w12, #0
	cset	w13, eq
	cmp	x11, #0
	cset	w11, ne
	eor	w11, w11, w13
	tbz	w11, #0, LBB57_11
; %bb.4:
	cbz	w9, LBB57_14
; %bb.5:
	cbz	w12, LBB57_14
; %bb.6:
Lloh122:
	adrp	x20, l_.str.3@PAGE
Lloh123:
	add	x20, x20, l_.str.3@PAGEOFF
	mov	w11, #3                         ; =0x3
	mov	w13, #16777216                  ; =0x1000000
	cmp	w9, w13
	b.hi	LBB57_18
; %bb.7:
	cmp	w12, w13
	b.hi	LBB57_18
; %bb.8:
	mov	x21, x3
	mov	x24, x0
	stp	x1, x2, [sp, #8]                ; 16-byte Folded Spill
	mov	x22, x8
	add	x0, sp, #56
	mov	x1, x10
	mov	x2, x9
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbz	w0, LBB57_15
; %bb.9:
Lloh124:
	adrp	x20, l_.str.2@PAGE
Lloh125:
	add	x20, x20, l_.str.2@PAGEOFF
LBB57_10:
	mov	w11, #2                         ; =0x2
	b	LBB57_17
LBB57_11:
Lloh126:
	adrp	x9, lCPI57_0@PAGE
Lloh127:
	ldr	q0, [x9, lCPI57_0@PAGEOFF]
	str	q0, [x8]
Lloh128:
	adrp	x9, l_.str.2@PAGE
Lloh129:
	add	x9, x9, l_.str.2@PAGEOFF
LBB57_12:
	str	x9, [x8, #16]
LBB57_13:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #80]               ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB57_14:
Lloh130:
	adrp	x9, lCPI57_2@PAGE
Lloh131:
	ldr	q0, [x9, lCPI57_2@PAGEOFF]
	str	q0, [x8]
Lloh132:
	adrp	x9, l_.str@PAGE
Lloh133:
	add	x9, x9, l_.str@PAGEOFF
	b	LBB57_12
LBB57_15:
	ldr	w10, [sp, #52]
	cmp	w10, #256
	b.ls	LBB57_19
; %bb.16:
	mov	w11, #3                         ; =0x3
LBB57_17:
	mov	x8, x22
LBB57_18:
	str	w11, [x8]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #4]
	str	wzr, [x8, #12]
	str	x20, [x8, #16]
	b	LBB57_13
LBB57_19:
	cbz	w10, LBB57_26
; %bb.20:
	mov	w25, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
Lloh134:
	adrp	x20, l_.str.2@PAGE
Lloh135:
	add	x20, x20, l_.str.2@PAGEOFF
	mov	w28, #65536                     ; =0x10000
	mov	w23, #12                        ; =0xc
Lloh136:
	adrp	x27, l_.str.3@PAGE
Lloh137:
	add	x27, x27, l_.str.3@PAGEOFF
LBB57_21:                               ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #56
	add	x2, sp, #40
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB57_10
; %bb.22:                               ;   in Loop: Header=BB57_21 Depth=1
	ldr	x8, [sp, #40]
	ldrh	w19, [x8, #2]
	sub	w8, w28, w25
	cmp	w8, w19
	b.lo	LBB57_41
; %bb.23:                               ;   in Loop: Header=BB57_21 Depth=1
	umull	x1, w19, w23
	add	x0, sp, #56
	add	x2, sp, #32
	bl	_nvm_v2_take
	cbnz	w0, LBB57_10
; %bb.24:                               ;   in Loop: Header=BB57_21 Depth=1
	add	w25, w25, w19
	add	w26, w26, #1
	ldr	w11, [sp, #52]
	cmp	w26, w11
	b.lo	LBB57_21
; %bb.25:
	mov	x8, x22
	mov	x9, x24
	b	LBB57_27
LBB57_26:
	mov	x9, x24
	mov	x8, x22
	mov	w11, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
LBB57_27:
	ldp	x12, x10, [sp, #64]
	cmp	x10, x12
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	b.ne	LBB57_40
; %bb.28:
	ldr	w12, [x9, #272]
	cbz	w12, LBB57_30
; %bb.29:
	ldr	x13, [x9, #256]
	cbz	x13, LBB57_40
LBB57_30:
	add	w13, w25, w11
	lsl	w11, w13, #2
	add	w13, w13, w25, lsl #1
	add	w13, w13, #33
	mov	w14, #1048576                   ; =0x100000
	sub	w14, w14, w11
	udiv	w15, w14, w13
	cmp	w12, w15
	b.hi	LBB57_38
; %bb.31:
	cbz	w12, LBB57_37
; %bb.32:
	ldr	x14, [x9, #256]
	add	x14, x14, #16
	mov	w15, #1048576                   ; =0x100000
Lloh138:
	adrp	x20, l_.str.3@PAGE
Lloh139:
	add	x20, x20, l_.str.3@PAGEOFF
LBB57_33:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w16, [x14], #24
	sub	w17, w15, w11
	udiv	w0, w17, w13
	cmp	w0, w16
	b.ls	LBB57_39
; %bb.34:                               ;   in Loop: Header=BB57_33 Depth=1
	madd	w16, w13, w16, w13
	cmp	w16, w17
	b.hi	LBB57_39
; %bb.35:                               ;   in Loop: Header=BB57_33 Depth=1
	add	w11, w16, w11
	subs	x12, x12, #1
	b.ne	LBB57_33
; %bb.36:
	mov	w12, #1048576                   ; =0x100000
	sub	w14, w12, w11
LBB57_37:
	ldr	w23, [x9, #476]
	cmp	x10, #0
	mov	w9, #16                         ; =0x10
	cinc	w25, w9, ne
	lsr	w9, w14, w25
	cmp	w23, w9
	b.ls	LBB57_42
LBB57_38:
Lloh140:
	adrp	x20, l_.str.3@PAGE
Lloh141:
	add	x20, x20, l_.str.3@PAGEOFF
LBB57_39:
	mov	w11, #3                         ; =0x3
	b	LBB57_18
LBB57_40:
Lloh142:
	adrp	x20, l_.str.2@PAGE
Lloh143:
	add	x20, x20, l_.str.2@PAGEOFF
	mov	w11, #2                         ; =0x2
	b	LBB57_18
LBB57_41:
	mov	w11, #3                         ; =0x3
	mov	x20, x27
	b	LBB57_17
LBB57_42:
	mov	x19, x11
	mov	w0, #1                          ; =0x1
	mov	w1, #312                        ; =0x138
	bl	_calloc
	cbz	x0, LBB57_45
; %bb.43:
	mov	x20, x0
	lsl	w8, w23, w25
	add	w8, w8, w19
	mov	w9, #2                          ; =0x2
	str	w9, [x0, #300]
	str	w8, [x0, #296]
	strb	wzr, [sp, #56]
	ldr	x0, [x24, #312]
	ldr	w1, [x24, #320]
	cbz	x21, LBB57_46
; %bb.44:
	add	x3, sp, #56
	mov	x2, x20
	bl	_nvm_ownership_map_layouts_private_decode_detailed
	b	LBB57_49
LBB57_45:
Lloh144:
	adrp	x8, lCPI57_1@PAGE
Lloh145:
	ldr	q0, [x8, lCPI57_1@PAGEOFF]
	str	q0, [x22]
Lloh146:
	adrp	x8, l_.str.4@PAGE
Lloh147:
	add	x8, x8, l_.str.4@PAGEOFF
	b	LBB57_89
LBB57_46:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB57_48
; %bb.47:
	add	x3, sp, #56
	mov	x2, x20
	bl	_nvm_ownership_mixed_layouts_private_decode_detailed
	b	LBB57_49
LBB57_48:
	mov	x2, x20
	bl	_nvm_ownership_layouts_private_decode
LBB57_49:
	cbz	w0, LBB57_52
; %bb.50:
	ldrb	w8, [sp, #56]
	cmp	w0, #1
	mov	w9, #1                          ; =0x1
	cinc	w19, w9, ne
	tbz	w8, #0, LBB57_84
; %bb.51:
	mov	x0, x20
	bl	_nvm_ordinary_array_authority_free
Lloh148:
	adrp	x8, l_.str.4@PAGE
Lloh149:
	add	x8, x8, l_.str.4@PAGEOFF
	mov	w19, #4                         ; =0x4
	b	LBB57_88
LBB57_52:
	ldr	w11, [x20, #8]
	cbz	w11, LBB57_78
; %bb.53:
	mov	x12, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	ldr	x13, [x20]
	mov	w14, #1                         ; =0x1
	mov	w15, #416                       ; =0x1a0
	b	LBB57_55
LBB57_54:                               ;   in Loop: Header=BB57_55 Depth=1
	add	x12, x12, #1
	cmp	x12, x11
	b.eq	LBB57_79
LBB57_55:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB57_64 Depth 2
	add	x0, x13, x12, lsl #4
	ldr	w16, [x0, #4]
	cmn	w16, #1
	b.eq	LBB57_57
; %bb.56:                               ;   in Loop: Header=BB57_55 Depth=1
	ldr	w17, [x24, #248]
	cmp	w16, w17
	b.hs	LBB57_87
LBB57_57:                               ;   in Loop: Header=BB57_55 Depth=1
	ldr	x16, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x16, #0
	cset	w16, ne
	ldrb	w17, [x0]
	cmp	w17, #0
	cinc	w10, w10, eq
	cmp	w17, #3
	cinc	w9, w9, eq
	cmp	w17, #2
	csel	w16, wzr, w16, ne
	cinc	w8, w8, eq
	cbz	w17, LBB57_60
; %bb.58:                               ;   in Loop: Header=BB57_55 Depth=1
	tbnz	w16, #0, LBB57_60
; %bb.59:                               ;   in Loop: Header=BB57_55 Depth=1
	strb	w14, [x20, #304]
LBB57_60:                               ;   in Loop: Header=BB57_55 Depth=1
	ldrh	w16, [x0, #2]
	cbz	x16, LBB57_54
; %bb.61:                               ;   in Loop: Header=BB57_55 Depth=1
	mov	x17, x24
	ldr	x0, [x0, #8]
	add	x0, x0, #8
	b	LBB57_64
LBB57_62:                               ;   in Loop: Header=BB57_64 Depth=2
	strb	w14, [x20, #304]
LBB57_63:                               ;   in Loop: Header=BB57_64 Depth=2
	add	x0, x0, #12
	subs	x16, x16, #1
	b.eq	LBB57_54
LBB57_64:                               ;   Parent Loop BB57_55 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	w1, w2, [x0, #-4]
	cmn	w2, #1
	b.eq	LBB57_66
; %bb.65:                               ;   in Loop: Header=BB57_64 Depth=2
	ldr	w3, [x17, #248]
	cmp	w2, w3
	b.hs	LBB57_87
LBB57_66:                               ;   in Loop: Header=BB57_64 Depth=2
	ldurb	w2, [x0, #-8]
	cmp	w2, #8
	b.ne	LBB57_69
; %bb.67:                               ;   in Loop: Header=BB57_64 Depth=2
	cmp	w1, w11
	b.hs	LBB57_87
; %bb.68:                               ;   in Loop: Header=BB57_64 Depth=2
	lsl	x1, x1, #4
	ldrb	w1, [x13, x1]
	cbz	w1, LBB57_63
	b	LBB57_87
LBB57_69:                               ;   in Loop: Header=BB57_64 Depth=2
	cmp	w2, #9
	ccmn	w1, #1, #4, eq
	b.ne	LBB57_76
; %bb.70:                               ;   in Loop: Header=BB57_64 Depth=2
	cmn	w1, #1
	b.ne	LBB57_87
; %bb.71:                               ;   in Loop: Header=BB57_64 Depth=2
	sub	w1, w2, #1
	cmp	w1, #4
	b.lo	LBB57_63
; %bb.72:                               ;   in Loop: Header=BB57_64 Depth=2
	cmp	w2, #8
	b.hi	LBB57_74
; %bb.73:                               ;   in Loop: Header=BB57_64 Depth=2
	lsl	w1, w14, w2
	tst	w1, w15
	b.ne	LBB57_63
LBB57_74:                               ;   in Loop: Header=BB57_64 Depth=2
	cbz	x21, LBB57_62
; %bb.75:                               ;   in Loop: Header=BB57_64 Depth=2
	cmp	w2, #13
	b.eq	LBB57_63
	b	LBB57_62
LBB57_76:                               ;   in Loop: Header=BB57_64 Depth=2
	cmp	w1, w11
	b.hs	LBB57_87
; %bb.77:                               ;   in Loop: Header=BB57_64 Depth=2
	lsl	x1, x1, #4
	ldrb	w1, [x13, x1]
	cmp	w1, #3
	b.eq	LBB57_62
	b	LBB57_87
LBB57_78:
	mov	w10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
LBB57_79:
	ldr	w11, [x24, #468]
	cmp	w10, w11
	b.ne	LBB57_87
; %bb.80:
	mov	x0, x24
	ldr	w10, [x24, #472]
	cmp	w9, w10
	b.ne	LBB57_87
; %bb.81:
	ldr	w9, [x0, #476]
	cmp	w8, w9
	b.ne	LBB57_87
; %bb.82:
	strb	wzr, [sp, #31]
	add	x2, sp, #31
	mov	x1, x20
	mov	x3, x20
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	mov	x5, x21
	bl	_ownership_validate_owned
	cbz	w0, LBB57_90
; %bb.83:
	ldr	w19, [x20, #300]
LBB57_84:
	mov	x0, x20
	bl	_nvm_ordinary_array_authority_free
Lloh150:
	adrp	x8, l_.str@PAGE
Lloh151:
	add	x8, x8, l_.str@PAGEOFF
	cmp	w19, #4
	b.hi	LBB57_88
; %bb.85:
	mov	w9, #29                         ; =0x1d
	lsr	w9, w9, w19
	tbz	w9, #0, LBB57_88
; %bb.86:
Lloh152:
	adrp	x9, l_switch.table.oaa_prepare_map@PAGE
Lloh153:
	add	x9, x9, l_switch.table.oaa_prepare_map@PAGEOFF
Lloh154:
	adrp	x8, l_switch.table.oaa_prepare_map.20@PAGE
Lloh155:
	add	x8, x8, l_switch.table.oaa_prepare_map.20@PAGEOFF
	ldr	x8, [x8, w19, uxtw #3]
	ldr	w19, [x9, w19, uxtw #2]
	b	LBB57_88
LBB57_87:
	mov	x0, x20
	bl	_nvm_ordinary_array_authority_free
Lloh156:
	adrp	x8, l_.str.2@PAGE
Lloh157:
	add	x8, x8, l_.str.2@PAGEOFF
	mov	w19, #2                         ; =0x2
LBB57_88:
	str	w19, [x22]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x22, #4]
	str	wzr, [x22, #12]
LBB57_89:
	str	x8, [x22, #16]
	b	LBB57_13
LBB57_90:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbnz	x8, LBB57_92
; %bb.91:
	ldrb	w8, [sp, #31]
	tbnz	w8, #0, LBB57_100
LBB57_92:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB57_94
; %bb.93:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #48]
	tbnz	w8, #0, LBB57_100
LBB57_94:
	ldr	w8, [x24, #432]
	cbnz	w8, LBB57_100
; %bb.95:
	ldr	w8, [x24, #448]
	cbnz	w8, LBB57_100
; %bb.96:
	ldr	w8, [x24, #336]
	cbnz	w8, LBB57_100
; %bb.97:
	ldr	x8, [x24, #328]
	cbnz	x8, LBB57_100
; %bb.98:
	ldr	w8, [x24, #352]
	cbnz	w8, LBB57_100
; %bb.99:
	ldr	x8, [x24, #344]
	cbz	x8, LBB57_101
LBB57_100:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #304]
LBB57_101:
	ldr	w8, [x20, #8]
	cbz	w8, LBB57_126
; %bb.102:
	mov	x9, #0                          ; =0x0
	mov	w17, #0                         ; =0x0
	mov	x10, x20
	ldr	x11, [x10], #32
	mov	w12, #12                        ; =0xc
	movi.8b	v0, #7
	movi.4s	v1, #1
	movi.16b	v2, #7
	mov	w13, #1                         ; =0x1
	b	LBB57_104
LBB57_103:                              ;   in Loop: Header=BB57_104 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB57_123
LBB57_104:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB57_115 Depth 2
                                        ;     Child Loop BB57_119 Depth 2
                                        ;     Child Loop BB57_122 Depth 2
	ldr	x14, [sp, #16]                  ; 8-byte Folded Reload
	cbz	x14, LBB57_106
; %bb.105:                              ;   in Loop: Header=BB57_104 Depth=1
	lsl	x14, x9, #4
	ldrb	w14, [x11, x14]
	cmp	w14, #2
	cset	w14, ne
	b	LBB57_107
LBB57_106:                              ;   in Loop: Header=BB57_104 Depth=1
	mov	w14, #1                         ; =0x1
LBB57_107:                              ;   in Loop: Header=BB57_104 Depth=1
	ldrb	w15, [x10, x9]
	cmp	w14, w15
	b.eq	LBB57_109
; %bb.108:                              ;   in Loop: Header=BB57_104 Depth=1
	strb	w13, [x20, #304]
LBB57_109:                              ;   in Loop: Header=BB57_104 Depth=1
	add	x15, x11, x9, lsl #4
	ldrh	w14, [x15, #2]
	cbz	w14, LBB57_103
; %bb.110:                              ;   in Loop: Header=BB57_104 Depth=1
	ldr	x15, [x15, #8]
	cmp	w14, #7
	b.hi	LBB57_112
; %bb.111:                              ;   in Loop: Header=BB57_104 Depth=1
	mov	x16, #0                         ; =0x0
	b	LBB57_121
LBB57_112:                              ;   in Loop: Header=BB57_104 Depth=1
	cmp	w14, #64
	b.hs	LBB57_114
; %bb.113:                              ;   in Loop: Header=BB57_104 Depth=1
	mov	x16, #0                         ; =0x0
	b	LBB57_118
LBB57_114:                              ;   in Loop: Header=BB57_104 Depth=1
	and	x16, x14, #0xffc0
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.s	v3[0], w17
	mov	x17, x15
	movi.2d	v5, #0000000000000000
	mov	x0, x16
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB57_115:                              ;   Parent Loop BB57_104 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x1, x17, #12
	ldr	b27, [x17]
	ld1.b	{ v27 }[1], [x1]
	add	x1, x17, #24
	ld1.b	{ v27 }[2], [x1]
	add	x1, x17, #36
	ld1.b	{ v27 }[3], [x1]
	add	x1, x17, #48
	ld1.b	{ v27 }[4], [x1]
	add	x1, x17, #60
	ld1.b	{ v27 }[5], [x1]
	add	x1, x17, #72
	ld1.b	{ v27 }[6], [x1]
	add	x1, x17, #84
	ld1.b	{ v27 }[7], [x1]
	add	x1, x17, #108
	ldur	b29, [x17, #96]
	ld1.b	{ v29 }[1], [x1]
	add	x1, x17, #120
	ld1.b	{ v29 }[2], [x1]
	add	x1, x17, #132
	ld1.b	{ v29 }[3], [x1]
	add	x1, x17, #144
	ld1.b	{ v29 }[4], [x1]
	add	x1, x17, #156
	ld1.b	{ v29 }[5], [x1]
	add	x1, x17, #168
	ld1.b	{ v29 }[6], [x1]
	add	x1, x17, #180
	ld1.b	{ v29 }[7], [x1]
	add	x1, x17, #204
	ldr	b28, [x17, #192]
	ld1.b	{ v28 }[1], [x1]
	add	x1, x17, #216
	ld1.b	{ v28 }[2], [x1]
	add	x1, x17, #228
	ld1.b	{ v28 }[3], [x1]
	add	x1, x17, #240
	ld1.b	{ v28 }[4], [x1]
	add	x1, x17, #252
	ld1.b	{ v28 }[5], [x1]
	add	x1, x17, #264
	ld1.b	{ v28 }[6], [x1]
	add	x1, x17, #276
	ld1.b	{ v28 }[7], [x1]
	add	x1, x17, #300
	ldr	b30, [x17, #288]
	ld1.b	{ v30 }[1], [x1]
	add	x1, x17, #312
	ld1.b	{ v30 }[2], [x1]
	add	x1, x17, #324
	ld1.b	{ v30 }[3], [x1]
	add	x1, x17, #336
	ld1.b	{ v30 }[4], [x1]
	add	x1, x17, #348
	ld1.b	{ v30 }[5], [x1]
	add	x1, x17, #360
	ld1.b	{ v30 }[6], [x1]
	add	x1, x17, #372
	ld1.b	{ v30 }[7], [x1]
	add	x1, x17, #396
	ldr	b31, [x17, #384]
	ld1.b	{ v31 }[1], [x1]
	add	x1, x17, #408
	ld1.b	{ v31 }[2], [x1]
	add	x1, x17, #420
	ld1.b	{ v31 }[3], [x1]
	add	x1, x17, #432
	ld1.b	{ v31 }[4], [x1]
	add	x1, x17, #444
	ld1.b	{ v31 }[5], [x1]
	add	x1, x17, #456
	ld1.b	{ v31 }[6], [x1]
	add	x1, x17, #468
	ld1.b	{ v31 }[7], [x1]
	add	x1, x17, #492
	ldr	b8, [x17, #480]
	ld1.b	{ v8 }[1], [x1]
	add	x1, x17, #504
	ld1.b	{ v8 }[2], [x1]
	add	x1, x17, #516
	ld1.b	{ v8 }[3], [x1]
	add	x1, x17, #528
	ld1.b	{ v8 }[4], [x1]
	add	x1, x17, #540
	ld1.b	{ v8 }[5], [x1]
	add	x1, x17, #552
	ld1.b	{ v8 }[6], [x1]
	add	x1, x17, #564
	ld1.b	{ v8 }[7], [x1]
	add	x1, x17, #588
	zip1.2d	v9, v27, v29
	ldr	b27, [x17, #576]
	ld1.b	{ v27 }[1], [x1]
	add	x1, x17, #600
	ld1.b	{ v27 }[2], [x1]
	add	x1, x17, #612
	ld1.b	{ v27 }[3], [x1]
	add	x1, x17, #624
	ld1.b	{ v27 }[4], [x1]
	add	x1, x17, #636
	ld1.b	{ v27 }[5], [x1]
	add	x1, x17, #648
	ld1.b	{ v27 }[6], [x1]
	add	x1, x17, #660
	ld1.b	{ v27 }[7], [x1]
	add	x1, x17, #684
	zip1.2d	v28, v28, v30
	ldr	b30, [x17, #672]
	ld1.b	{ v30 }[1], [x1]
	add	x1, x17, #696
	ld1.b	{ v30 }[2], [x1]
	add	x1, x17, #708
	ld1.b	{ v30 }[3], [x1]
	add	x1, x17, #720
	ld1.b	{ v30 }[4], [x1]
	add	x1, x17, #732
	ld1.b	{ v30 }[5], [x1]
	add	x1, x17, #744
	ld1.b	{ v30 }[6], [x1]
	add	x1, x17, #756
	ld1.b	{ v30 }[7], [x1]
	zip1.2d	v29, v31, v8
	zip1.2d	v27, v27, v30
	cmeq.16b	v30, v9, v2
	ushll2.8h	v31, v30, #0
	ushll2.4s	v8, v31, #0
	and.16b	v8, v8, v1
	add.4s	v6, v6, v8
	ushll.8h	v30, v30, #0
	ushll.4s	v31, v31, #0
	and.16b	v31, v31, v1
	add.4s	v5, v5, v31
	ushll.4s	v31, v30, #0
	and.16b	v31, v31, v1
	ushll2.4s	v30, v30, #0
	and.16b	v30, v30, v1
	cmeq.16b	v28, v28, v2
	add.4s	v4, v4, v30
	ushll2.8h	v30, v28, #0
	add.4s	v3, v3, v31
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v1
	add.4s	v24, v24, v31
	ushll.8h	v28, v28, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v1
	add.4s	v18, v18, v30
	ushll.4s	v30, v28, #0
	and.16b	v30, v30, v1
	ushll2.4s	v28, v28, #0
	and.16b	v28, v28, v1
	cmeq.16b	v29, v29, v2
	add.4s	v21, v21, v28
	add.4s	v7, v7, v30
	ushll2.8h	v28, v29, #0
	ushll2.4s	v30, v28, #0
	and.16b	v30, v30, v1
	add.4s	v22, v22, v30
	ushll.8h	v29, v29, #0
	ushll.4s	v28, v28, #0
	and.16b	v28, v28, v1
	add.4s	v25, v25, v28
	ushll.4s	v28, v29, #0
	and.16b	v28, v28, v1
	ushll2.4s	v29, v29, #0
	cmeq.16b	v27, v27, v2
	and.16b	v29, v29, v1
	add.4s	v16, v16, v29
	ushll2.8h	v29, v27, #0
	add.4s	v19, v19, v28
	ushll2.4s	v28, v29, #0
	and.16b	v28, v28, v1
	add.4s	v26, v26, v28
	ushll.8h	v27, v27, #0
	ushll.4s	v28, v29, #0
	and.16b	v28, v28, v1
	add.4s	v20, v20, v28
	ushll2.4s	v28, v27, #0
	and.16b	v28, v28, v1
	add.4s	v23, v23, v28
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v1
	add.4s	v17, v17, v27
	add	x17, x17, #768
	subs	x0, x0, #64
	b.ne	LBB57_115
; %bb.116:                              ;   in Loop: Header=BB57_104 Depth=1
	add.4s	v4, v21, v4
	add.4s	v6, v24, v6
	add.4s	v3, v7, v3
	add.4s	v5, v18, v5
	add.4s	v5, v25, v5
	add.4s	v3, v19, v3
	add.4s	v6, v22, v6
	add.4s	v4, v16, v4
	add.4s	v4, v23, v4
	add.4s	v6, v26, v6
	add.4s	v3, v17, v3
	add.4s	v5, v20, v5
	add.4s	v3, v3, v5
	add.4s	v4, v4, v6
	add.4s	v3, v3, v4
	addv.4s	s3, v3
	fmov	w17, s3
	cmp	x16, x14
	b.eq	LBB57_103
; %bb.117:                              ;   in Loop: Header=BB57_104 Depth=1
	tst	x14, #0x38
	b.eq	LBB57_121
LBB57_118:                              ;   in Loop: Header=BB57_104 Depth=1
	mov	x0, x16
	and	x16, x14, #0xfff8
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	mov.s	v4[0], w17
	umaddl	x1, w0, w12, x15
	sub	x17, x0, x16
	add	x0, x1, #48
LBB57_119:                              ;   Parent Loop BB57_104 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x1, x0, #36
	sub	x2, x0, #24
	sub	x3, x0, #12
	add	x4, x0, #12
	add	x5, x0, #24
	add	x6, x0, #36
	ldur	b5, [x0, #-48]
	ld1.b	{ v5 }[1], [x1]
	ld1.b	{ v5 }[2], [x2]
	ld1.b	{ v5 }[3], [x3]
	ld1.b	{ v5 }[4], [x0]
	ld1.b	{ v5 }[5], [x4]
	ld1.b	{ v5 }[6], [x5]
	ld1.b	{ v5 }[7], [x6]
	cmeq.8b	v5, v5, v0
	ushll.8h	v5, v5, #0
	ushll.4s	v6, v5, #0
	and.16b	v6, v6, v1
	ushll2.4s	v5, v5, #0
	and.16b	v5, v5, v1
	add.4s	v3, v3, v5
	add.4s	v4, v4, v6
	add	x0, x0, #96
	adds	x17, x17, #8
	b.ne	LBB57_119
; %bb.120:                              ;   in Loop: Header=BB57_104 Depth=1
	add.4s	v3, v4, v3
	addv.4s	s3, v3
	fmov	w17, s3
	cmp	x16, x14
	b.eq	LBB57_103
LBB57_121:                              ;   in Loop: Header=BB57_104 Depth=1
	umaddl	x15, w16, w12, x15
	sub	x14, x14, x16
LBB57_122:                              ;   Parent Loop BB57_104 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w16, [x15], #12
	cmp	w16, #7
	cinc	w17, w17, eq
	subs	x14, x14, #1
	b.ne	LBB57_122
	b	LBB57_103
LBB57_123:
	cbz	w17, LBB57_126
; %bb.124:
	ldr	w8, [x20, #292]
	cbnz	w8, LBB57_126
; %bb.125:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #304]
LBB57_126:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB57_130
; %bb.127:
	ldr	w8, [x24, #476]
	cbz	w8, LBB57_130
; %bb.128:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB57_130
; %bb.129:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #304]
LBB57_130:
	ldrb	w8, [x20, #304]
	cmp	w8, #1
	b.ne	LBB57_132
; %bb.131:
	mov	x0, x20
	bl	_nvm_ordinary_array_authority_free
Lloh158:
	adrp	x8, l_.str@PAGE
Lloh159:
	add	x8, x8, l_.str@PAGEOFF
	mov	w19, #1                         ; =0x1
	b	LBB57_88
LBB57_132:
	mov	w19, #0                         ; =0x0
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x20, [x8]
Lloh160:
	adrp	x8, l_.str.1@PAGE
Lloh161:
	add	x8, x8, l_.str.1@PAGEOFF
	b	LBB57_88
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdrp	Lloh126, Lloh128
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdrp	Lloh130, Lloh132
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdrp	Lloh144, Lloh146
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh160, Lloh161
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I could not establish complete ordinary array declarations."

l_.str.1:                               ; @.str.1
	.asciz	"I copied ordinary array declarations without executable admission."

l_.str.2:                               ; @.str.2
	.asciz	"I require consistent complete declaration bytes."

l_.str.3:                               ; @.str.3
	.asciz	"I reached my bounded declaration budget."

l_.str.4:                               ; @.str.4
	.asciz	"I could not allocate my declaration report."

l_.str.5:                               ; @.str.5
	.asciz	"I could not establish complete mixed declarations."

l_.str.6:                               ; @.str.6
	.asciz	"I copied complete declarations without execution authority."

l_.str.7:                               ; @.str.7
	.asciz	"I reached my declaration storage or work bound."

l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate my declaration projection."

l_.str.9:                               ; @.str.9
	.asciz	"I require complete exact map declarations."

l_.str.10:                              ; @.str.10
	.asciz	"I found no map declaration route."

l_.str.11:                              ; @.str.11
	.asciz	"I copied exact map declarations without execution authority."

l_.str.12:                              ; @.str.12
	.asciz	"I reached my map declaration bound."

l_.str.13:                              ; @.str.13
	.asciz	"I could not allocate map declarations."

l_.str.14:                              ; @.str.14
	.asciz	"I require consistent union declaration bytes."

l_.str.15:                              ; @.str.15
	.asciz	"I copied union declarations without execution authority."

l_.str.16:                              ; @.str.16
	.asciz	"I could not establish the supported union declarations."

l_.str.17:                              ; @.str.17
	.asciz	"I reached the union declaration bound."

l_.str.18:                              ; @.str.18
	.asciz	"I could not allocate union declarations."

	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @switch.table.nvm_prepare_map_declarations
l_switch.table.nvm_prepare_map_declarations:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.space	8
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @switch.table.nvm_prepare_map_declarations.19
l_switch.table.nvm_prepare_map_declarations.19:
	.quad	l_.str.10
	.quad	l_.str.11
	.space	8
	.quad	l_.str.12
	.quad	l_.str.13

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @switch.table.oaa_prepare_map
l_switch.table.oaa_prepare_map:
	.long	0                               ; 0x0
	.space	4
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	4                               ; 0x4

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @switch.table.oaa_prepare_map.20
l_switch.table.oaa_prepare_map.20:
	.quad	l_.str.1
	.space	8
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4

.subsections_via_symbols
