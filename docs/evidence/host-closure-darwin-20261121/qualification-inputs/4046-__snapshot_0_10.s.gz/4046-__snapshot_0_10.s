	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_file_nominal_check         ; -- Begin function nvm_file_nominal_check
	.p2align	2
_nvm_file_nominal_check:                ; @nvm_file_nominal_check
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_5
LBB0_2:
	ldr	x0, [sp, #16]
	mov	x1, #5                          ; =0x5
	bl	_indices
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB0_4
	b	LBB0_3
LBB0_3:
	ldr	x8, [sp, #16]
	add	x0, x8, #20
	mov	x1, #8                          ; =0x8
	bl	_indices
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_4
LBB0_4:
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	mov	w9, #8                          ; =0x8
	mov	w8, #0                          ; =0x0
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	stur	w8, [x29, #-4]
	b	LBB0_5
LBB0_5:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function indices
_indices:                               ; @indices
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	str	xzr, [sp, #16]
	b	LBB1_1
LBB1_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_5 Depth 2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	LBB1_12
	b	LBB1_2
LBB1_2:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #16]
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.ne	LBB1_4
	b	LBB1_3
LBB1_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB1_13
LBB1_4:                                 ;   in Loop: Header=BB1_1 Depth=1
	str	xzr, [sp, #8]
	b	LBB1_5
LBB1_5:                                 ;   Parent Loop BB1_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB1_10
	b	LBB1_6
LBB1_6:                                 ;   in Loop: Header=BB1_5 Depth=2
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #8]
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #32]
	ldr	x10, [sp, #16]
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.ne	LBB1_8
	b	LBB1_7
LBB1_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB1_13
LBB1_8:                                 ;   in Loop: Header=BB1_5 Depth=2
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_5 Depth=2
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB1_5
LBB1_10:                                ;   in Loop: Header=BB1_1 Depth=1
	b	LBB1_11
LBB1_11:                                ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB1_1
LBB1_12:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB1_13
LBB1_13:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_nominal_decode        ; -- Begin function nvm_file_nominal_decode
	.p2align	2
_nvm_file_nominal_decode:               ; @nvm_file_nominal_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB2_3
	b	LBB2_2
LBB2_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_3:
	ldur	x8, [x29, #-24]
	subs	x8, x8, #120
	b.eq	LBB2_5
	b	LBB2_4
LBB2_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_5:
	ldur	x0, [x29, #-16]
	bl	_get16
	subs	w8, w0, #2
	b.eq	LBB2_7
	b	LBB2_6
LBB2_6:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_7:
	ldur	x8, [x29, #-16]
	add	x0, x8, #2
	bl	_get16
	subs	w8, w0, #1
	b.eq	LBB2_9
	b	LBB2_8
LBB2_8:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_9:
	ldur	x8, [x29, #-16]
	add	x0, x8, #4
	bl	_get32
	subs	w8, w0, #5
	b.ne	LBB2_11
	b	LBB2_10
LBB2_10:
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	bl	_get32
	subs	w8, w0, #8
	b.eq	LBB2_12
	b	LBB2_11
LBB2_11:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_12:
	ldur	x8, [x29, #-16]
	add	x0, x8, #12
	bl	_get32
	cbz	w0, LBB2_14
	b	LBB2_13
LBB2_13:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_14:
	str	xzr, [sp, #16]
	b	LBB2_15
LBB2_15:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #5
	b.hs	LBB2_20
	b	LBB2_16
LBB2_16:                                ;   in Loop: Header=BB2_15 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #16
	ldr	x10, [sp, #16]
	mov	x9, #8                          ; =0x8
	mul	x9, x9, x10
	add	x0, x8, x9
	bl	_get32
	mov	w8, w0
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.eq	LBB2_18
	b	LBB2_17
LBB2_17:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_18:                                ;   in Loop: Header=BB2_15 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #20
	ldr	x10, [sp, #16]
	mov	x9, #8                          ; =0x8
	mul	x9, x9, x10
	add	x0, x8, x9
	bl	_get32
	ldr	x9, [sp, #16]
	add	x8, sp, #28
	str	w0, [x8, x9, lsl #2]
	b	LBB2_19
LBB2_19:                                ;   in Loop: Header=BB2_15 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB2_15
LBB2_20:
	str	xzr, [sp, #8]
	b	LBB2_21
LBB2_21:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	subs	x8, x8, #8
	b.hs	LBB2_26
	b	LBB2_22
LBB2_22:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #56
	ldr	x10, [sp, #8]
	mov	x9, #8                          ; =0x8
	mul	x9, x9, x10
	add	x0, x8, x9
	bl	_get32
	mov	w8, w0
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.eq	LBB2_24
	b	LBB2_23
LBB2_23:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_24:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #60
	ldr	x10, [sp, #8]
	mov	x9, #8                          ; =0x8
	mul	x9, x9, x10
	add	x0, x8, x9
	bl	_get32
	add	x8, sp, #28
	add	x8, x8, #20
	ldr	x9, [sp, #8]
	str	w0, [x8, x9, lsl #2]
	b	LBB2_25
LBB2_25:                                ;   in Loop: Header=BB2_21 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB2_21
LBB2_26:
	add	x0, sp, #28
	bl	_nvm_file_nominal_check
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB2_28
	b	LBB2_27
LBB2_27:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB2_29
LBB2_28:
	ldur	x0, [x29, #-32]
	add	x1, sp, #28
	mov	x2, #52                         ; =0x34
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB2_29
LBB2_29:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get16
_get16:                                 ; @get16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	and	w0, w8, #0xffff
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get32
_get32:                                 ; @get32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w0, w8, w9, lsl #24
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_nominal_encode        ; -- Begin function nvm_file_nominal_encode
	.p2align	2
_nvm_file_nominal_encode:               ; @nvm_file_nominal_encode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	add	x29, sp, #272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #112]
	str	x1, [sp, #104]
	str	x2, [sp, #96]
	str	x3, [sp, #88]
	ldr	x8, [sp, #88]
	cbnz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #124]
	b	LBB5_18
LBB5_2:
	ldr	x0, [sp, #112]
	bl	_nvm_file_nominal_check
	str	w0, [sp, #84]
	ldr	w8, [sp, #84]
	cbz	w8, LBB5_4
	b	LBB5_3
LBB5_3:
	ldr	w8, [sp, #84]
	str	w8, [sp, #124]
	b	LBB5_18
LBB5_4:
	ldr	x8, [sp, #104]
	cbz	x8, LBB5_7
	b	LBB5_5
LBB5_5:
	ldr	x8, [sp, #96]
	subs	x8, x8, #120
	b.hs	LBB5_7
	b	LBB5_6
LBB5_6:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #124]
	b	LBB5_18
LBB5_7:
	ldr	x8, [sp, #104]
	cbnz	x8, LBB5_9
	b	LBB5_8
LBB5_8:
	ldr	x9, [sp, #88]
	mov	x8, #120                        ; =0x78
	str	x8, [x9]
	str	wzr, [sp, #124]
	b	LBB5_18
LBB5_9:
	add	x0, sp, #128
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	mov	x2, #120                        ; =0x78
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	mov	w1, #2                          ; =0x2
	bl	_put16
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x0, x8, #2
	mov	w1, #1                          ; =0x1
	bl	_put16
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x0, x8, #4
	mov	w1, #5                          ; =0x5
	bl	_put32
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x0, x8, #8
	mov	w1, #8                          ; =0x8
	bl	_put32
	str	xzr, [sp, #72]
	b	LBB5_10
LBB5_10:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #72]
	subs	x8, x8, #5
	b.hs	LBB5_13
	b	LBB5_11
LBB5_11:                                ;   in Loop: Header=BB5_10 Depth=1
	add	x8, sp, #128
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x8, x8, #16
	ldr	x10, [sp, #72]
	mov	x9, #8                          ; =0x8
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	mul	x9, x9, x10
	add	x0, x8, x9
	ldr	x8, [sp, #72]
	mov	x1, x8
	bl	_put32
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	add	x8, x8, #20
	ldr	x10, [sp, #72]
	mul	x9, x9, x10
	add	x0, x8, x9
	ldr	x8, [sp, #112]
	ldr	x9, [sp, #72]
	ldr	w1, [x8, x9, lsl #2]
	bl	_put32
	b	LBB5_12
LBB5_12:                                ;   in Loop: Header=BB5_10 Depth=1
	ldr	x8, [sp, #72]
	add	x8, x8, #1
	str	x8, [sp, #72]
	b	LBB5_10
LBB5_13:
	str	xzr, [sp, #64]
	b	LBB5_14
LBB5_14:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #64]
	subs	x8, x8, #8
	b.hs	LBB5_17
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_14 Depth=1
	add	x8, sp, #128
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	add	x8, x8, #56
	ldr	x10, [sp, #64]
	mov	x9, #8                          ; =0x8
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	mul	x9, x9, x10
	add	x0, x8, x9
	ldr	x8, [sp, #64]
	mov	x1, x8
	bl	_put32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	add	x8, x8, #60
	ldr	x10, [sp, #64]
	mul	x9, x9, x10
	add	x0, x8, x9
	ldr	x8, [sp, #112]
	add	x8, x8, #20
	ldr	x9, [sp, #64]
	ldr	w1, [x8, x9, lsl #2]
	bl	_put32
	b	LBB5_16
LBB5_16:                                ;   in Loop: Header=BB5_14 Depth=1
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB5_14
LBB5_17:
	ldr	x0, [sp, #104]
	add	x1, sp, #128
	mov	x2, #120                        ; =0x78
	str	x2, [sp, #16]                   ; 8-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #88]
	str	x8, [x9]
	str	wzr, [sp, #124]
	b	LBB5_18
LBB5_18:
	ldr	w8, [sp, #124]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB5_20
	b	LBB5_19
LBB5_19:
	bl	___stack_chk_fail
LBB5_20:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function put16
_put16:                                 ; @put16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	ldrh	w8, [sp, #6]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldrh	w8, [sp, #6]
	asr	w8, w8, #8
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function put32
_put32:                                 ; @put32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #8
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #16
	ldr	x9, [sp, #8]
	strb	w8, [x9, #2]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #24
	ldr	x9, [sp, #8]
	strb	w8, [x9, #3]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
