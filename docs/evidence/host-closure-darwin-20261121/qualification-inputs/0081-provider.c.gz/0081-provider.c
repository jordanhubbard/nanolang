const char *path_basename(const char *s) { (void)s; return "exact-host-ok"; }
