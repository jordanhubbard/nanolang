	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_passive_valid              ; -- Begin function nvm_passive_valid
	.p2align	2
_nvm_passive_valid:                     ; @nvm_passive_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_29
LBB0_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB0_4
	b	LBB0_3
LBB0_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #344]
	subs	x8, x8, #0
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_29
LBB0_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #344]
	cbz	x8, LBB0_7
	b	LBB0_5
LBB0_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	cbz	x8, LBB0_7
	b	LBB0_6
LBB0_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB0_8
	b	LBB0_7
LBB0_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_29
LBB0_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #344]
	sub	x0, x29, #40
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #352]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-32]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-24]
	stur	wzr, [x0, #17]
	stur	wzr, [x29, #-20]
	bl	_word
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	stur	w8, [x29, #-44]
	bl	_word
	stur	w0, [x29, #-48]
	ldurb	w8, [x29, #-24]
	tbz	w8, #0, LBB0_13
	b	LBB0_9
LBB0_9:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #1
	b.eq	LBB0_11
	b	LBB0_10
LBB0_10:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #2
	b.ne	LBB0_13
	b	LBB0_11
LBB0_11:
	ldur	w8, [x29, #-48]
	cbz	w8, LBB0_13
	b	LBB0_12
LBB0_12:
	ldur	w8, [x29, #-48]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-32]
	mov	x10, #48                        ; =0x30
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB0_14
	b	LBB0_13
LBB0_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_29
LBB0_14:
	stur	wzr, [x29, #-52]
	str	wzr, [sp, #56]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #32]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	wzr, [sp, #48]
	str	wzr, [sp, #52]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB0_16
	b	LBB0_15
LBB0_15:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_17
LBB0_16:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_17
LBB0_17:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB0_19
	b	LBB0_18
LBB0_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_29
LBB0_19:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #31]
	str	wzr, [sp, #24]
	b	LBB0_20
LBB0_20:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [sp, #31]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB0_22
	b	LBB0_21
LBB0_21:                                ;   in Loop: Header=BB0_20 Depth=1
	ldr	w8, [sp, #24]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB0_22
LBB0_22:                                ;   in Loop: Header=BB0_20 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB0_25
	b	LBB0_23
LBB0_23:                                ;   in Loop: Header=BB0_20 Depth=1
	ldur	x1, [x29, #-16]
	ldr	w8, [sp, #24]
	subs	w8, w8, #0
	cset	w4, eq
	ldur	w5, [x29, #-44]
	sub	x0, x29, #40
	sub	x2, x29, #52
	add	x3, sp, #56
	add	x6, sp, #32
	bl	_block
	strb	w0, [sp, #31]
	b	LBB0_24
LBB0_24:                                ;   in Loop: Header=BB0_20 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB0_20
LBB0_25:
	ldr	x0, [sp, #40]
	bl	_free
	ldrb	w8, [sp, #31]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB0_28
	b	LBB0_26
LBB0_26:
	ldurb	w8, [x29, #-24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB0_28
	b	LBB0_27
LBB0_27:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #0
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB0_28
LBB0_28:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_29
LBB0_29:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function word
_word:                                  ; @word
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	subs	x8, x8, #4
	b.hs	LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #16]
	strb	wzr, [x8, #16]
	str	wzr, [sp, #28]
	b	LBB1_3
LBB1_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #24
	str	w8, [sp, #4]
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #4
	str	x8, [x9]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #8]
	subs	x8, x8, #4
	str	x8, [x9, #8]
	ldr	w8, [sp, #4]
	str	w8, [sp, #28]
	b	LBB1_3
LBB1_3:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function block
_block:                                 ; @block
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #336
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	sturb	w4, [x29, #-57]
	stur	w5, [x29, #-64]
	stur	x6, [x29, #-72]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-76]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-80]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-84]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-88]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-92]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB2_8
	b	LBB2_1
LBB2_1:
	ldur	w8, [x29, #-76]
	subs	w8, w8, #1
	b.eq	LBB2_3
	b	LBB2_2
LBB2_2:
	ldur	w8, [x29, #-76]
	subs	w8, w8, #2
	b.ne	LBB2_8
	b	LBB2_3
LBB2_3:
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB2_8
	b	LBB2_4
LBB2_4:
	ldur	w8, [x29, #-92]
	cbz	w8, LBB2_8
	b	LBB2_5
LBB2_5:
	ldur	w8, [x29, #-92]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #8]
	mov	x10, #28                        ; =0x1c
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB2_8
	b	LBB2_6
LBB2_6:
	ldur	w8, [x29, #-84]
	ldur	w9, [x29, #-88]
	subs	w8, w8, w9
	b.hs	LBB2_8
	b	LBB2_7
LBB2_7:
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.ls	LBB2_9
	b	LBB2_8
LBB2_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB2_138
LBB2_9:
	ldur	x8, [x29, #-40]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-80]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-104]
	ldur	x8, [x29, #-104]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB2_17
	b	LBB2_10
LBB2_10:
	ldur	x8, [x29, #-104]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-104]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB2_17
	b	LBB2_11
LBB2_11:
	ldur	w8, [x29, #-84]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB2_17
	b	LBB2_12
LBB2_12:
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #8]
	ldur	x10, [x29, #-104]
	ldr	w10, [x10, #12]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB2_17
	b	LBB2_13
LBB2_13:
	ldurb	w8, [x29, #-57]
	tbnz	w8, #0, LBB2_18
	b	LBB2_14
LBB2_14:
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB2_17
	b	LBB2_15
LBB2_15:
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB2_18
	b	LBB2_16
LBB2_16:
	ldur	w8, [x29, #-84]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB2_18
	b	LBB2_17
LBB2_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB2_138
LBB2_18:
	ldur	w8, [x29, #-92]
	mov	x0, x8
	mov	x1, #48                         ; =0x30
	bl	_calloc
	stur	x0, [x29, #-112]
	ldur	x8, [x29, #-112]
	cbnz	x8, LBB2_20
	b	LBB2_19
LBB2_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB2_138
LBB2_20:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-113]
	stur	wzr, [x29, #-120]
	b	LBB2_21
LBB2_21:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_40 Depth 2
                                        ;     Child Loop BB2_49 Depth 2
                                        ;     Child Loop BB2_62 Depth 2
	ldurb	w8, [x29, #-113]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #36]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_23
	b	LBB2_22
LBB2_22:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	w8, [x29, #-120]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB2_23
LBB2_23:                                ;   in Loop: Header=BB2_21 Depth=1
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB2_69
	b	LBB2_24
LBB2_24:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x10, [x29, #-112]
	ldur	w8, [x29, #-120]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-128]
	ldur	x0, [x29, #-32]
	bl	_word
	ldur	x8, [x29, #-128]
	str	w0, [x8]
	ldur	x0, [x29, #-32]
	bl	_word
	ldur	x8, [x29, #-128]
	str	w0, [x8, #4]
	ldur	x0, [x29, #-32]
	bl	_word
	ldur	x8, [x29, #-128]
	str	w0, [x8, #8]
	ldur	x0, [x29, #-32]
	bl	_word
	ldur	x8, [x29, #-128]
	str	w0, [x8, #12]
	ldur	x0, [x29, #-32]
	bl	_word
	ldur	x8, [x29, #-128]
	str	w0, [x8, #16]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-132]
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-136]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB2_38
	b	LBB2_25
LBB2_25:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	w8, [x29, #-132]
	cbnz	w8, LBB2_38
	b	LBB2_26
LBB2_26:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	w8, [x29, #-136]
	cbnz	w8, LBB2_38
	b	LBB2_27
LBB2_27:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.lo	LBB2_38
	b	LBB2_28
LBB2_28:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-88]
	subs	w8, w8, w9
	b.hi	LBB2_38
	b	LBB2_29
LBB2_29:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8]
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB2_38
	b	LBB2_30
LBB2_30:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB2_38
	b	LBB2_31
LBB2_31:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB2_38
	b	LBB2_32
LBB2_32:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hi	LBB2_38
	b	LBB2_33
LBB2_33:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	w8, [x29, #-64]
	subs	w8, w8, #1
	b.ne	LBB2_35
	b	LBB2_34
LBB2_34:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #16]
	cbnz	w8, LBB2_38
	b	LBB2_35
LBB2_35:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #8]
	mov	x10, #4                         ; =0x4
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB2_38
	b	LBB2_36
LBB2_36:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	w8, [x29, #-76]
	subs	w8, w8, #1
	b.ne	LBB2_39
	b	LBB2_37
LBB2_37:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #12]
	cbz	w8, LBB2_39
	b	LBB2_38
LBB2_38:
	sturb	wzr, [x29, #-113]
	b	LBB2_69
LBB2_39:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldur	x9, [x29, #-128]
	str	x8, [x9, #24]
	stur	wzr, [x29, #-140]
	b	LBB2_40
LBB2_40:                                ;   Parent Loop BB2_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-140]
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB2_48
	b	LBB2_41
LBB2_41:                                ;   in Loop: Header=BB2_40 Depth=2
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-144]
	ldur	w8, [x29, #-144]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB2_45
	b	LBB2_42
LBB2_42:                                ;   in Loop: Header=BB2_40 Depth=2
	ldur	w8, [x29, #-144]
	ldur	w9, [x29, #-120]
	subs	w8, w8, w9
	b.eq	LBB2_45
	b	LBB2_43
LBB2_43:                                ;   in Loop: Header=BB2_40 Depth=2
	ldur	w8, [x29, #-140]
	cbz	w8, LBB2_46
	b	LBB2_44
LBB2_44:                                ;   in Loop: Header=BB2_40 Depth=2
	ldur	w8, [x29, #-144]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-128]
	ldr	x0, [x8, #24]
	ldur	w8, [x29, #-140]
	subs	w1, w8, #1
	bl	_at
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.hi	LBB2_46
	b	LBB2_45
LBB2_45:                                ;   in Loop: Header=BB2_40 Depth=2
	sturb	wzr, [x29, #-113]
	b	LBB2_46
LBB2_46:                                ;   in Loop: Header=BB2_40 Depth=2
	b	LBB2_47
LBB2_47:                                ;   in Loop: Header=BB2_40 Depth=2
	ldur	w8, [x29, #-140]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	b	LBB2_40
LBB2_48:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldur	x9, [x29, #-128]
	str	x8, [x9, #32]
	stur	wzr, [x29, #-148]
	b	LBB2_49
LBB2_49:                                ;   Parent Loop BB2_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-148]
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB2_61
	b	LBB2_50
LBB2_50:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	x0, [x29, #-32]
	bl	_word
	stur	w0, [x29, #-152]
	ldur	w8, [x29, #-152]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB2_58
	b	LBB2_51
LBB2_51:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	w8, [x29, #-148]
	cbz	w8, LBB2_53
	b	LBB2_52
LBB2_52:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	w8, [x29, #-152]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-128]
	ldr	x0, [x8, #32]
	ldur	w8, [x29, #-148]
	subs	w1, w8, #1
	bl	_at
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ls	LBB2_58
	b	LBB2_53
LBB2_53:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #264]
	cbz	x8, LBB2_58
	b	LBB2_54
LBB2_54:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-80]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB2_58
	b	LBB2_55
LBB2_55:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	w8, [x29, #-152]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB2_59
	b	LBB2_56
LBB2_56:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-80]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	w9, [x29, #-152]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	bl	_scalar
	tbz	w0, #0, LBB2_58
	b	LBB2_57
LBB2_57:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	x0, [x29, #-40]
	ldur	w1, [x29, #-80]
	ldur	w2, [x29, #-152]
	ldur	w3, [x29, #-84]
	bl	_guarded_input
	tbnz	w0, #0, LBB2_59
	b	LBB2_58
LBB2_58:                                ;   in Loop: Header=BB2_49 Depth=2
	sturb	wzr, [x29, #-113]
	b	LBB2_59
LBB2_59:                                ;   in Loop: Header=BB2_49 Depth=2
	b	LBB2_60
LBB2_60:                                ;   in Loop: Header=BB2_49 Depth=2
	ldur	w8, [x29, #-148]
	add	w8, w8, #1
	stur	w8, [x29, #-148]
	b	LBB2_49
LBB2_61:                                ;   in Loop: Header=BB2_21 Depth=1
	stur	wzr, [x29, #-156]
	b	LBB2_62
LBB2_62:                                ;   Parent Loop BB2_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-156]
	ldur	w9, [x29, #-120]
	subs	w8, w8, w9
	b.hs	LBB2_67
	b	LBB2_63
LBB2_63:                                ;   in Loop: Header=BB2_62 Depth=2
	ldur	x10, [x29, #-112]
	ldur	w8, [x29, #-156]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB2_65
	b	LBB2_64
LBB2_64:                                ;   in Loop: Header=BB2_62 Depth=2
	sturb	wzr, [x29, #-113]
	b	LBB2_65
LBB2_65:                                ;   in Loop: Header=BB2_62 Depth=2
	b	LBB2_66
LBB2_66:                                ;   in Loop: Header=BB2_62 Depth=2
	ldur	w8, [x29, #-156]
	add	w8, w8, #1
	stur	w8, [x29, #-156]
	b	LBB2_62
LBB2_67:                                ;   in Loop: Header=BB2_21 Depth=1
	b	LBB2_68
LBB2_68:                                ;   in Loop: Header=BB2_21 Depth=1
	ldur	w8, [x29, #-120]
	add	w8, w8, #1
	stur	w8, [x29, #-120]
	b	LBB2_21
LBB2_69:
	ldur	w8, [x29, #-84]
	str	w8, [sp, #160]
	str	wzr, [sp, #156]
	b	LBB2_70
LBB2_70:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_74 Depth 2
                                        ;       Child Loop BB2_78 Depth 3
	ldurb	w8, [x29, #-113]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_72
	b	LBB2_71
LBB2_71:                                ;   in Loop: Header=BB2_70 Depth=1
	ldr	w8, [sp, #156]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB2_72
LBB2_72:                                ;   in Loop: Header=BB2_70 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB2_92
	b	LBB2_73
LBB2_73:                                ;   in Loop: Header=BB2_70 Depth=1
	ldur	w8, [x29, #-92]
	str	w8, [sp, #152]
	str	wzr, [sp, #148]
	b	LBB2_74
LBB2_74:                                ;   Parent Loop BB2_70 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_78 Depth 3
	ldr	w8, [sp, #148]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB2_87
	b	LBB2_75
LBB2_75:                                ;   in Loop: Header=BB2_74 Depth=2
	ldur	x10, [x29, #-112]
	ldr	w8, [sp, #148]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #40]
	tbz	w8, #0, LBB2_77
	b	LBB2_76
LBB2_76:                                ;   in Loop: Header=BB2_74 Depth=2
	b	LBB2_86
LBB2_77:                                ;   in Loop: Header=BB2_74 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #147]
	str	wzr, [sp, #140]
	b	LBB2_78
LBB2_78:                                ;   Parent Loop BB2_70 Depth=1
                                        ;     Parent Loop BB2_74 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [sp, #140]
	ldur	x11, [x29, #-112]
	ldr	w9, [sp, #148]
                                        ; kill: def $x9 killed $w9
	mov	x10, #48                        ; =0x30
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB2_83
	b	LBB2_79
LBB2_79:                                ;   in Loop: Header=BB2_78 Depth=3
	ldur	x8, [x29, #-112]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x10, [x29, #-112]
	ldr	w8, [sp, #148]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #24]
	ldr	w1, [sp, #140]
	bl	_at
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	mov	w8, #48                         ; =0x30
	umaddl	x8, w0, w8, x9
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB2_81
	b	LBB2_80
LBB2_80:                                ;   in Loop: Header=BB2_78 Depth=3
	strb	wzr, [sp, #147]
	b	LBB2_81
LBB2_81:                                ;   in Loop: Header=BB2_78 Depth=3
	b	LBB2_82
LBB2_82:                                ;   in Loop: Header=BB2_78 Depth=3
	ldr	w8, [sp, #140]
	add	w8, w8, #1
	str	w8, [sp, #140]
	b	LBB2_78
LBB2_83:                                ;   in Loop: Header=BB2_74 Depth=2
	ldrb	w8, [sp, #147]
	tbz	w8, #0, LBB2_85
	b	LBB2_84
LBB2_84:                                ;   in Loop: Header=BB2_70 Depth=1
	ldr	w8, [sp, #148]
	str	w8, [sp, #152]
	b	LBB2_87
LBB2_85:                                ;   in Loop: Header=BB2_74 Depth=2
	b	LBB2_86
LBB2_86:                                ;   in Loop: Header=BB2_74 Depth=2
	ldr	w8, [sp, #148]
	add	w8, w8, #1
	str	w8, [sp, #148]
	b	LBB2_74
LBB2_87:                                ;   in Loop: Header=BB2_70 Depth=1
	ldr	w8, [sp, #152]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.eq	LBB2_89
	b	LBB2_88
LBB2_88:                                ;   in Loop: Header=BB2_70 Depth=1
	ldur	x8, [x29, #-112]
	ldr	w9, [sp, #152]
                                        ; kill: def $x9 killed $w9
	mov	x10, #48                        ; =0x30
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #160]
	subs	w8, w8, w9
	b.eq	LBB2_90
	b	LBB2_89
LBB2_89:
	sturb	wzr, [x29, #-113]
	b	LBB2_92
LBB2_90:                                ;   in Loop: Header=BB2_70 Depth=1
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-104]
	ldur	x2, [x29, #-112]
	ldur	w3, [x29, #-92]
	ldr	w4, [sp, #152]
	ldur	w5, [x29, #-64]
	ldur	x6, [x29, #-72]
	bl	_node_code
	sturb	w0, [x29, #-113]
	ldur	x11, [x29, #-112]
	ldr	w8, [sp, #152]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w8, [x8, #4]
	str	w8, [sp, #160]
	ldur	x10, [x29, #-112]
	ldr	w8, [sp, #152]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #40]
	b	LBB2_91
LBB2_91:                                ;   in Loop: Header=BB2_70 Depth=1
	ldr	w8, [sp, #156]
	add	w8, w8, #1
	str	w8, [sp, #156]
	b	LBB2_70
LBB2_92:
	ldr	w8, [sp, #160]
	ldur	w9, [x29, #-88]
	subs	w8, w8, w9
	b.eq	LBB2_94
	b	LBB2_93
LBB2_93:
	sturb	wzr, [x29, #-113]
	b	LBB2_94
LBB2_94:
	strb	wzr, [sp, #139]
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #8]
	ldur	x10, [x29, #-104]
	ldr	w10, [x10, #12]
	add	w9, w9, w10
	subs	w8, w8, w9
	cset	w8, eq
	strb	w8, [sp, #138]
	ldur	x8, [x29, #-104]
	ldr	w8, [x8, #8]
	str	w8, [sp, #132]
	b	LBB2_95
LBB2_95:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_127 Depth 2
	ldurb	w8, [x29, #-113]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_97
	b	LBB2_96
LBB2_96:                                ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #132]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #8]
	ldur	x10, [x29, #-104]
	ldr	w10, [x10, #12]
	add	w9, w9, w10
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_97
LBB2_97:                                ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB2_134
	b	LBB2_98
LBB2_98:                                ;   in Loop: Header=BB2_95 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #280]
	ldr	w9, [sp, #132]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-104]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #12]
	add	w8, w8, w9
	ldr	w9, [sp, #132]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #64
	bl	_isa_decode
	str	w0, [sp, #60]
	ldr	w8, [sp, #60]
	cbnz	w8, LBB2_100
	b	LBB2_99
LBB2_99:
	sturb	wzr, [x29, #-113]
	b	LBB2_134
LBB2_100:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w0, [sp, #64]
	ldur	w1, [x29, #-64]
	bl	_allowed
	tbnz	w0, #0, LBB2_113
	b	LBB2_101
LBB2_101:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #56
	b.eq	LBB2_113
	b	LBB2_102
LBB2_102:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #57
	b.eq	LBB2_113
	b	LBB2_103
LBB2_103:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #58
	b.eq	LBB2_113
	b	LBB2_104
LBB2_104:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #61
	b.eq	LBB2_113
	b	LBB2_105
LBB2_105:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #163
	b.eq	LBB2_113
	b	LBB2_106
LBB2_106:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #160
	b.eq	LBB2_113
	b	LBB2_107
LBB2_107:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #164
	b.eq	LBB2_113
	b	LBB2_108
LBB2_108:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #161
	b.eq	LBB2_113
	b	LBB2_109
LBB2_109:                               ;   in Loop: Header=BB2_95 Depth=1
	ldur	w8, [x29, #-64]
	subs	w8, w8, #2
	b.ne	LBB2_112
	b	LBB2_110
LBB2_110:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #140
	b.eq	LBB2_113
	b	LBB2_111
LBB2_111:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #59
	b.eq	LBB2_113
	b	LBB2_112
LBB2_112:
	sturb	wzr, [x29, #-113]
	b	LBB2_134
LBB2_113:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #132]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.ne	LBB2_115
	b	LBB2_114
LBB2_114:                               ;   in Loop: Header=BB2_95 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #139]
	b	LBB2_115
LBB2_115:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #132]
	ldur	w9, [x29, #-88]
	subs	w8, w8, w9
	b.ne	LBB2_117
	b	LBB2_116
LBB2_116:                               ;   in Loop: Header=BB2_95 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #138]
	b	LBB2_117
LBB2_117:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #56
	b.eq	LBB2_120
	b	LBB2_118
LBB2_118:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #57
	b.eq	LBB2_120
	b	LBB2_119
LBB2_119:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #58
	b.ne	LBB2_125
	b	LBB2_120
LBB2_120:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #132]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #72]
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.le	LBB2_124
	b	LBB2_121
LBB2_121:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #48]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ge	LBB2_124
	b	LBB2_122
LBB2_122:                               ;   in Loop: Header=BB2_95 Depth=1
	ldur	x0, [x29, #-112]
	ldur	w1, [x29, #-92]
	ldr	w2, [sp, #132]
	ldr	x3, [sp, #48]
	ldur	w4, [x29, #-64]
	bl	_internal_node_edge
	tbnz	w0, #0, LBB2_124
	b	LBB2_123
LBB2_123:                               ;   in Loop: Header=BB2_95 Depth=1
	sturb	wzr, [x29, #-113]
	b	LBB2_124
LBB2_124:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_125
LBB2_125:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #17
	b.ne	LBB2_133
	b	LBB2_126
LBB2_126:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrh	w8, [sp, #72]
	str	w8, [sp, #44]
	str	wzr, [sp, #40]
	b	LBB2_127
LBB2_127:                               ;   Parent Loop BB2_95 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB2_132
	b	LBB2_128
LBB2_128:                               ;   in Loop: Header=BB2_127 Depth=2
	ldur	x11, [x29, #-112]
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x0, [x8, #32]
	ldur	x10, [x29, #-112]
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w1, [x8, #16]
	ldr	w2, [sp, #44]
	bl	_contains
	tbz	w0, #0, LBB2_130
	b	LBB2_129
LBB2_129:                               ;   in Loop: Header=BB2_127 Depth=2
	sturb	wzr, [x29, #-113]
	b	LBB2_130
LBB2_130:                               ;   in Loop: Header=BB2_127 Depth=2
	b	LBB2_131
LBB2_131:                               ;   in Loop: Header=BB2_127 Depth=2
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB2_127
LBB2_132:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_133
LBB2_133:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w9, [sp, #60]
	ldr	w8, [sp, #132]
	add	w8, w8, w9
	str	w8, [sp, #132]
	b	LBB2_95
LBB2_134:
	ldur	x0, [x29, #-112]
	bl	_free
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-48]
	str	w8, [x9]
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-56]
	str	w8, [x9]
	ldurb	w8, [x29, #-113]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_137
	b	LBB2_135
LBB2_135:
	ldrb	w8, [sp, #139]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_137
	b	LBB2_136
LBB2_136:
	ldrb	w8, [sp, #138]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB2_137
LBB2_137:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB2_138
LBB2_138:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function at
_at:                                    ; @at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	ldur	x8, [x29, #-8]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #2
	add	x0, sp, #8
	str	x8, [sp, #8]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #24]
	stur	wzr, [x0, #17]
	str	wzr, [sp, #28]
	bl	_word
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar
_scalar:                                ; @scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_5
	b	LBB4_1
LBB4_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_5
	b	LBB4_2
LBB4_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_5
	b	LBB4_3
LBB4_3:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_5
	b	LBB4_4
LBB4_4:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_5
LBB4_5:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function guarded_input
_guarded_input:                         ; @guarded_input
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #56]
	str	w1, [sp, #52]
	str	w2, [sp, #48]
	str	w3, [sp, #44]
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #264]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB5_3
	b	LBB5_2
LBB5_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_3:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #8]
	str	w8, [sp, #28]
	str	wzr, [sp, #24]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #23]
	b	LBB5_4
LBB5_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_6 Depth 2
	ldr	w8, [sp, #28]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.hs	LBB5_30
	b	LBB5_5
LBB5_5:                                 ;   in Loop: Header=BB5_4 Depth=1
	str	wzr, [sp, #16]
	b	LBB5_6
LBB5_6:                                 ;   Parent Loop BB5_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #16]
	subs	w8, w8, #3
	b.hs	LBB5_13
	b	LBB5_7
LBB5_7:                                 ;   in Loop: Header=BB5_6 Depth=2
	ldr	w8, [sp, #28]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.lo	LBB5_9
	b	LBB5_8
LBB5_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_9:                                 ;   in Loop: Header=BB5_6 Depth=2
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #280]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	ldr	w8, [sp, #16]
	mov	x9, x8
	add	x8, sp, #72
	add	x2, x8, x9, lsl #6
	bl	_isa_decode
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbnz	w8, LBB5_11
	b	LBB5_10
LBB5_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_11:                                ;   in Loop: Header=BB5_6 Depth=2
	ldr	w9, [sp, #12]
	ldr	w8, [sp, #28]
	add	w8, w8, w9
	str	w8, [sp, #28]
	b	LBB5_12
LBB5_12:                                ;   in Loop: Header=BB5_6 Depth=2
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB5_6
LBB5_13:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrb	w8, [sp, #72]
	subs	w8, w8, #16
	b.ne	LBB5_16
	b	LBB5_14
LBB5_14:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrb	w8, [sp, #136]
	subs	w8, w8, #140
	b.ne	LBB5_16
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrb	w8, [sp, #200]
	subs	w8, w8, #161
	b.eq	LBB5_17
	b	LBB5_16
LBB5_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_17:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrh	w8, [sp, #80]
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB5_20
	b	LBB5_18
LBB5_18:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrb	w8, [sp, #23]
	tbnz	w8, #0, LBB5_21
	b	LBB5_19
LBB5_19:                                ;   in Loop: Header=BB5_4 Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.hi	LBB5_21
	b	LBB5_20
LBB5_20:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_21:                                ;   in Loop: Header=BB5_4 Depth=1
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #7]
	ldrb	w0, [sp, #7]
	bl	_scalar
	tbz	w0, #0, LBB5_24
	b	LBB5_22
LBB5_22:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrb	w8, [sp, #7]
	subs	w8, w8, #2
	b.eq	LBB5_24
	b	LBB5_23
LBB5_23:                                ;   in Loop: Header=BB5_4 Depth=1
	ldrb	w8, [sp, #144]
	ldrb	w9, [sp, #7]
	subs	w8, w8, w9
	b.eq	LBB5_25
	b	LBB5_24
LBB5_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_25:                                ;   in Loop: Header=BB5_4 Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #48]
	subs	w8, w8, w9
	b.ne	LBB5_27
	b	LBB5_26
LBB5_26:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_27:                                ;   in Loop: Header=BB5_4 Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #48]
	subs	w8, w8, w9
	b.ls	LBB5_29
	b	LBB5_28
LBB5_28:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_29:                                ;   in Loop: Header=BB5_4 Depth=1
	ldr	w8, [sp, #8]
	str	w8, [sp, #24]
	strb	wzr, [sp, #23]
	b	LBB5_4
LBB5_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #71]
	b	LBB5_31
LBB5_31:
	ldrb	w8, [sp, #71]
	str	w8, [sp]                        ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB5_33
	b	LBB5_32
LBB5_32:
	bl	___stack_chk_fail
LBB5_33:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function node_code
_node_code:                             ; @node_code
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	w3, [x29, #-52]
	stur	w4, [x29, #-56]
	stur	w5, [x29, #-60]
	stur	x6, [x29, #-72]
	ldur	w8, [x29, #-60]
	subs	w8, w8, #2
	b.ne	LBB6_2
	b	LBB6_1
LBB6_1:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-48]
	ldur	w3, [x29, #-52]
	ldur	w4, [x29, #-56]
	ldur	x5, [x29, #-72]
	bl	_node_cfg
	and	w8, w0, #0x1
	sturb	w8, [x29, #-17]
	b	LBB6_70
LBB6_2:
	ldur	x10, [x29, #-48]
	ldur	w8, [x29, #-56]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-80]
	stur	wzr, [x29, #-84]
	ldur	w8, [x29, #-52]
	mov	x0, x8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	stur	x0, [x29, #-96]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB6_4
	b	LBB6_3
LBB6_3:
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB6_5
LBB6_4:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB6_5
LBB6_5:
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	stur	x0, [x29, #-104]
	ldur	x8, [x29, #-96]
	cbz	x8, LBB6_7
	b	LBB6_6
LBB6_6:
	ldur	x8, [x29, #-104]
	cbnz	x8, LBB6_8
	b	LBB6_7
LBB6_7:
	ldur	x0, [x29, #-96]
	bl	_free
	ldur	x0, [x29, #-104]
	bl	_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB6_70
LBB6_8:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-105]
	ldur	x8, [x29, #-80]
	ldr	w8, [x8]
	stur	w8, [x29, #-112]
	b	LBB6_9
LBB6_9:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_39 Depth 2
	ldurb	w8, [x29, #-105]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB6_11
	b	LBB6_10
LBB6_10:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-112]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB6_11
LBB6_11:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB6_55
	b	LBB6_12
LBB6_12:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-112]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #80
	bl	_isa_decode
	str	w0, [sp, #76]
	ldr	w8, [sp, #76]
	cbz	w8, LBB6_16
	b	LBB6_13
LBB6_13:                                ;   in Loop: Header=BB6_9 Depth=1
	ldrb	w0, [sp, #80]
	ldur	w1, [x29, #-60]
	bl	_allowed
	tbnz	w0, #0, LBB6_17
	b	LBB6_14
LBB6_14:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-60]
	subs	w8, w8, #2
	b.ne	LBB6_16
	b	LBB6_15
LBB6_15:                                ;   in Loop: Header=BB6_9 Depth=1
	ldrb	w8, [sp, #80]
	subs	w8, w8, #59
	b.eq	LBB6_17
	b	LBB6_16
LBB6_16:
	sturb	wzr, [x29, #-105]
	b	LBB6_55
LBB6_17:                                ;   in Loop: Header=BB6_9 Depth=1
	ldrb	w0, [sp, #80]
	bl	_isa_get_info
	str	x0, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB6_19
	b	LBB6_18
LBB6_18:
	sturb	wzr, [x29, #-105]
	b	LBB6_55
LBB6_19:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	x8, [sp, #64]
	ldrsb	w8, [x8, #28]
	str	w8, [sp, #60]
	ldr	x8, [sp, #64]
	ldrsb	w8, [x8, #29]
	str	w8, [sp, #56]
	ldrb	w8, [sp, #80]
	subs	w8, w8, #59
	b.ne	LBB6_23
	b	LBB6_20
LBB6_20:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #88]
	str	w8, [sp, #52]
	ldur	x0, [x29, #-72]
	ldr	w1, [sp, #52]
	bl	_closed_function
	tbnz	w0, #0, LBB6_22
	b	LBB6_21
LBB6_21:
	sturb	wzr, [x29, #-105]
	b	LBB6_55
LBB6_22:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrh	w8, [x8, #4]
	str	w8, [sp, #60]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #21]
	str	w8, [sp, #56]
	b	LBB6_23
LBB6_23:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #60]
	tbnz	w8, #31, LBB6_27
	b	LBB6_24
LBB6_24:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #56]
	tbnz	w8, #31, LBB6_27
	b	LBB6_25
LBB6_25:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-84]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.lo	LBB6_27
	b	LBB6_26
LBB6_26:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-84]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	ldr	w10, [sp, #56]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB6_28
	b	LBB6_27
LBB6_27:
	sturb	wzr, [x29, #-105]
	b	LBB6_55
LBB6_28:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-84]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	ldr	w9, [sp, #56]
	add	w8, w8, w9
	stur	w8, [x29, #-84]
	ldrb	w8, [sp, #80]
	subs	w8, w8, #17
	b.ne	LBB6_34
	b	LBB6_29
LBB6_29:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-112]
	ldr	w9, [sp, #76]
	add	w8, w8, w9
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB6_32
	b	LBB6_30
LBB6_30:                                ;   in Loop: Header=BB6_9 Depth=1
	ldrh	w8, [sp, #88]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB6_32
	b	LBB6_31
LBB6_31:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-84]
	cbz	w8, LBB6_33
	b	LBB6_32
LBB6_32:                                ;   in Loop: Header=BB6_9 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB6_33
LBB6_33:                                ;   in Loop: Header=BB6_9 Depth=1
	b	LBB6_37
LBB6_34:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	w8, [x29, #-112]
	ldr	w9, [sp, #76]
	add	w8, w8, w9
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB6_36
	b	LBB6_35
LBB6_35:                                ;   in Loop: Header=BB6_9 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB6_36
LBB6_36:                                ;   in Loop: Header=BB6_9 Depth=1
	b	LBB6_37
LBB6_37:                                ;   in Loop: Header=BB6_9 Depth=1
	ldrb	w8, [sp, #80]
	subs	w8, w8, #16
	b.ne	LBB6_54
	b	LBB6_38
LBB6_38:                                ;   in Loop: Header=BB6_9 Depth=1
	ldrh	w8, [sp, #88]
	str	w8, [sp, #48]
	ldur	w8, [x29, #-52]
	str	w8, [sp, #44]
	str	wzr, [sp, #40]
	b	LBB6_39
LBB6_39:                                ;   Parent Loop BB6_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB6_44
	b	LBB6_40
LBB6_40:                                ;   in Loop: Header=BB6_39 Depth=2
	ldur	x10, [x29, #-48]
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #48]
	subs	w8, w8, w9
	b.ne	LBB6_42
	b	LBB6_41
LBB6_41:                                ;   in Loop: Header=BB6_39 Depth=2
	ldr	w8, [sp, #40]
	str	w8, [sp, #44]
	b	LBB6_42
LBB6_42:                                ;   in Loop: Header=BB6_39 Depth=2
	b	LBB6_43
LBB6_43:                                ;   in Loop: Header=BB6_39 Depth=2
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB6_39
LBB6_44:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #44]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB6_48
	b	LBB6_45
LBB6_45:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	x8, [x29, #-80]
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-80]
	ldr	w1, [x8, #12]
	ldr	w2, [sp, #44]
	bl	_contains
	tbnz	w0, #0, LBB6_47
	b	LBB6_46
LBB6_46:                                ;   in Loop: Header=BB6_9 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB6_47
LBB6_47:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	x8, [x29, #-96]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB6_53
LBB6_48:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #48]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB6_50
	b	LBB6_49
LBB6_49:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	x8, [x29, #-80]
	ldr	x0, [x8, #32]
	ldur	x8, [x29, #-80]
	ldr	w1, [x8, #16]
	ldr	w2, [sp, #48]
	bl	_contains
	tbnz	w0, #0, LBB6_51
	b	LBB6_50
LBB6_50:                                ;   in Loop: Header=BB6_9 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB6_52
LBB6_51:                                ;   in Loop: Header=BB6_9 Depth=1
	ldur	x8, [x29, #-104]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB6_52
LBB6_52:                                ;   in Loop: Header=BB6_9 Depth=1
	b	LBB6_53
LBB6_53:                                ;   in Loop: Header=BB6_9 Depth=1
	b	LBB6_54
LBB6_54:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w9, [sp, #76]
	ldur	w8, [x29, #-112]
	add	w8, w8, w9
	stur	w8, [x29, #-112]
	b	LBB6_9
LBB6_55:
	str	wzr, [sp, #36]
	b	LBB6_56
LBB6_56:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB6_61
	b	LBB6_57
LBB6_57:                                ;   in Loop: Header=BB6_56 Depth=1
	ldur	x8, [x29, #-96]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-80]
	ldr	x0, [x8, #24]
	ldr	w1, [sp, #36]
	bl	_at
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, w0, uxtw
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB6_59
	b	LBB6_58
LBB6_58:                                ;   in Loop: Header=BB6_56 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB6_59
LBB6_59:                                ;   in Loop: Header=BB6_56 Depth=1
	b	LBB6_60
LBB6_60:                                ;   in Loop: Header=BB6_56 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB6_56
LBB6_61:
	str	wzr, [sp, #32]
	b	LBB6_62
LBB6_62:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB6_67
	b	LBB6_63
LBB6_63:                                ;   in Loop: Header=BB6_62 Depth=1
	ldur	x8, [x29, #-104]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-80]
	ldr	x0, [x8, #32]
	ldr	w1, [sp, #32]
	bl	_at
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x8, w0, uxtw
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB6_65
	b	LBB6_64
LBB6_64:                                ;   in Loop: Header=BB6_62 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB6_65
LBB6_65:                                ;   in Loop: Header=BB6_62 Depth=1
	b	LBB6_66
LBB6_66:                                ;   in Loop: Header=BB6_62 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB6_62
LBB6_67:
	ldur	x0, [x29, #-96]
	bl	_free
	ldur	x0, [x29, #-104]
	bl	_free
	ldurb	w8, [x29, #-105]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB6_69
	b	LBB6_68
LBB6_68:
	ldur	w8, [x29, #-84]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB6_69
LBB6_69:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB6_70
LBB6_70:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function allowed
_allowed:                               ; @allowed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	str	w1, [sp, #8]
	ldrb	w8, [sp, #14]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #226
	b.hi	LBB7_4
; %bb.1:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI7_0@PAGE
	add	x10, x10, lJTI7_0@PAGEOFF
Ltmp3:
	adr	x8, Ltmp3
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB7_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB7_5
LBB7_3:
	ldr	w8, [sp, #8]
	subs	w8, w8, #2
	cset	w8, eq
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB7_5
LBB7_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB7_5
LBB7_5:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
	.p2align	2
lJTI7_0:
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_2-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_4-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
	.long	LBB7_3-Ltmp3
                                        ; -- End function
	.p2align	2                               ; -- Begin function internal_node_edge
_internal_node_edge:                    ; @internal_node_edge
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	w1, [sp, #28]
	str	w2, [sp, #24]
	str	x3, [sp, #16]
	str	w4, [sp, #12]
	ldr	w8, [sp, #12]
	subs	w8, w8, #2
	b.eq	LBB8_2
	b	LBB8_1
LBB8_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB8_12
LBB8_2:
	str	wzr, [sp, #8]
	b	LBB8_3
LBB8_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.hs	LBB8_11
	b	LBB8_4
LBB8_4:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	w8, [sp, #24]
	ldr	x9, [sp, #32]
	ldr	w10, [sp, #8]
                                        ; kill: def $x10 killed $w10
	mov	x11, #48                        ; =0x30
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB8_9
	b	LBB8_5
LBB8_5:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	w8, [sp, #24]
	ldr	x11, [sp, #32]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #48                        ; =0x30
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB8_9
	b	LBB8_6
LBB8_6:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.le	LBB8_9
	b	LBB8_7
LBB8_7:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	x8, [sp, #16]
	ldr	x11, [sp, #32]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #48                        ; =0x30
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ge	LBB8_9
	b	LBB8_8
LBB8_8:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB8_12
LBB8_9:                                 ;   in Loop: Header=BB8_3 Depth=1
	b	LBB8_10
LBB8_10:                                ;   in Loop: Header=BB8_3 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB8_3
LBB8_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB8_12
LBB8_12:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function contains
_contains:                              ; @contains
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	w2, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB9_1
LBB9_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.hs	LBB9_6
	b	LBB9_2
LBB9_2:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	x0, [sp, #16]
	ldr	w1, [sp, #4]
	bl	_at
	ldr	w8, [sp, #8]
	subs	w8, w0, w8
	b.ne	LBB9_4
	b	LBB9_3
LBB9_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_7
LBB9_4:                                 ;   in Loop: Header=BB9_1 Depth=1
	b	LBB9_5
LBB9_5:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB9_1
LBB9_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_7
LBB9_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function node_cfg
_node_cfg:                              ; @node_cfg
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #496
	stp	x28, x27, [sp, #464]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #480]            ; 16-byte Folded Spill
	add	x29, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-48]
	stur	x1, [x29, #-56]
	stur	x2, [x29, #-64]
	stur	w3, [x29, #-68]
	stur	w4, [x29, #-72]
	stur	x5, [x29, #-80]
	ldur	x10, [x29, #-64]
	ldur	w8, [x29, #-72]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-88]
	stur	wzr, [x29, #-92]
	ldur	x8, [x29, #-88]
	ldr	w8, [x8]
	stur	w8, [x29, #-96]
	b	LBB10_1
LBB10_1:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-96]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB10_6
	b	LBB10_2
LBB10_2:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-96]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-96]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	sub	x2, x29, #160
	bl	_isa_decode
	stur	w0, [x29, #-164]
	ldur	w8, [x29, #-164]
	cbz	w8, LBB10_4
	b	LBB10_3
LBB10_3:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	w8, [x29, #-92]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ne	LBB10_5
	b	LBB10_4
LBB10_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-33]
	b	LBB10_103
LBB10_5:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	ldur	w9, [x29, #-164]
	ldur	w8, [x29, #-96]
	add	w8, w8, w9
	stur	w8, [x29, #-96]
	b	LBB10_1
LBB10_6:
	ldur	w8, [x29, #-92]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	stur	x0, [x29, #-176]
	ldur	w8, [x29, #-68]
	mov	x0, x8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	stur	x0, [x29, #-184]
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB10_8
	b	LBB10_7
LBB10_7:
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB10_9
LBB10_8:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB10_9
LBB10_9:
	ldr	w9, [sp, #52]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	stur	x0, [x29, #-192]
	ldur	x8, [x29, #-176]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #48]                   ; 4-byte Folded Spill
	cbz	x8, LBB10_12
	b	LBB10_10
LBB10_10:
	ldur	x8, [x29, #-184]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #48]                   ; 4-byte Folded Spill
	cbz	x8, LBB10_12
	b	LBB10_11
LBB10_11:
	ldur	x8, [x29, #-192]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB10_12
LBB10_12:
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-193]
	ldurb	w8, [x29, #-193]
	tbnz	w8, #0, LBB10_14
	b	LBB10_13
LBB10_13:
	b	LBB10_102
LBB10_14:
	ldur	x8, [x29, #-88]
	ldr	w8, [x8]
	stur	w8, [x29, #-200]
	stur	wzr, [x29, #-204]
	b	LBB10_15
LBB10_15:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-204]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB10_18
	b	LBB10_16
LBB10_16:                               ;   in Loop: Header=BB10_15 Depth=1
	ldur	w8, [x29, #-200]
	ldur	x9, [x29, #-176]
	ldur	w10, [x29, #-204]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #4
	str	w8, [x9, x10]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-200]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-200]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #208
	bl	_isa_decode
	ldur	x8, [x29, #-176]
	ldur	w9, [x29, #-204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	w0, [x8, #4]
	ldur	x8, [x29, #-176]
	ldur	w9, [x29, #-204]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [x9, #8]
	ldur	x8, [x29, #-176]
	ldur	w9, [x29, #-204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w9, [x8, #4]
	ldur	w8, [x29, #-200]
	add	w8, w8, w9
	stur	w8, [x29, #-200]
	b	LBB10_17
LBB10_17:                               ;   in Loop: Header=BB10_15 Depth=1
	ldur	w8, [x29, #-204]
	add	w8, w8, #1
	stur	w8, [x29, #-204]
	b	LBB10_15
LBB10_18:
	ldur	x8, [x29, #-176]
	str	xzr, [x8, #8]
	str	wzr, [sp, #204]
	b	LBB10_19
LBB10_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_50 Depth 2
                                        ;     Child Loop BB10_73 Depth 2
	ldurb	w8, [x29, #-193]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #44]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB10_21
	b	LBB10_20
LBB10_20:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #204]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB10_21
LBB10_21:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB10_85
	b	LBB10_22
LBB10_22:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-176]
	ldr	w10, [sp, #204]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #4
	ldr	w9, [x9, x10]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #4]
	mov	x1, x8
	add	x2, sp, #136
	bl	_isa_decode
	ldrb	w9, [sp, #136]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #56
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB10_25
	b	LBB10_23
LBB10_23:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w9, [sp, #136]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #57
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB10_25
	b	LBB10_24
LBB10_24:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w8, [sp, #136]
	subs	w8, w8, #58
	cset	w8, eq
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB10_25
LBB10_25:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #135]
	ldrb	w0, [sp, #136]
	bl	_isa_get_info
	str	x0, [sp, #120]
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	tbnz	x8, #63, LBB10_30
	b	LBB10_26
LBB10_26:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x8, [sp, #120]
	cbz	x8, LBB10_30
	b	LBB10_27
LBB10_27:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w0, [sp, #136]
	mov	w1, #2                          ; =0x2
	bl	_allowed
	tbnz	w0, #0, LBB10_31
	b	LBB10_28
LBB10_28:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w8, [sp, #136]
	subs	w8, w8, #59
	b.eq	LBB10_31
	b	LBB10_29
LBB10_29:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w8, [sp, #135]
	tbnz	w8, #0, LBB10_31
	b	LBB10_30
LBB10_30:
	sturb	wzr, [x29, #-193]
	b	LBB10_85
LBB10_31:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x8, [sp, #120]
	ldrsb	w8, [x8, #28]
	str	w8, [sp, #116]
	ldr	x8, [sp, #120]
	ldrsb	w8, [x8, #29]
	str	w8, [sp, #112]
	ldrb	w8, [sp, #136]
	subs	w8, w8, #59
	b.ne	LBB10_35
	b	LBB10_32
LBB10_32:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #144]
	str	w8, [sp, #108]
	ldur	x0, [x29, #-80]
	ldr	w1, [sp, #108]
	bl	_closed_function
	tbnz	w0, #0, LBB10_34
	b	LBB10_33
LBB10_33:
	sturb	wzr, [x29, #-193]
	b	LBB10_85
LBB10_34:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrh	w8, [x8, #4]
	str	w8, [sp, #116]
	ldur	x8, [x29, #-48]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #108]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #21]
	str	w8, [sp, #112]
	b	LBB10_35
LBB10_35:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #116]
	tbnz	w8, #31, LBB10_39
	b	LBB10_36
LBB10_36:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #112]
	tbnz	w8, #31, LBB10_39
	b	LBB10_37
LBB10_37:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldrsw	x9, [sp, #116]
	subs	x8, x8, x9
	b.lt	LBB10_39
	b	LBB10_38
LBB10_38:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldrsw	x9, [sp, #116]
	subs	x8, x8, x9
	ldr	w10, [sp, #112]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.le	LBB10_40
	b	LBB10_39
LBB10_39:
	sturb	wzr, [x29, #-193]
	b	LBB10_85
LBB10_40:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #204]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldrsw	x9, [sp, #116]
	subs	x8, x8, x9
	ldrsw	x9, [sp, #112]
	add	x8, x8, x9
	str	x8, [sp, #96]
	ldrb	w8, [sp, #136]
	subs	w8, w8, #17
	b.ne	LBB10_46
	b	LBB10_41
LBB10_41:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #204]
	add	w8, w8, #1
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.ne	LBB10_44
	b	LBB10_42
LBB10_42:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrh	w8, [sp, #144]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB10_44
	b	LBB10_43
LBB10_43:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x8, [sp, #96]
	cbz	x8, LBB10_45
	b	LBB10_44
LBB10_44:                               ;   in Loop: Header=BB10_19 Depth=1
	sturb	wzr, [x29, #-193]
	b	LBB10_45
LBB10_45:                               ;   in Loop: Header=BB10_19 Depth=1
	b	LBB10_84
LBB10_46:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #204]
	add	w8, w8, #1
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.ne	LBB10_48
	b	LBB10_47
LBB10_47:
	sturb	wzr, [x29, #-193]
	b	LBB10_85
LBB10_48:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w8, [sp, #136]
	subs	w8, w8, #16
	b.ne	LBB10_65
	b	LBB10_49
LBB10_49:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrh	w8, [sp, #144]
	str	w8, [sp, #92]
	ldur	w8, [x29, #-68]
	str	w8, [sp, #88]
	str	wzr, [sp, #84]
	b	LBB10_50
LBB10_50:                               ;   Parent Loop BB10_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.hs	LBB10_55
	b	LBB10_51
LBB10_51:                               ;   in Loop: Header=BB10_50 Depth=2
	ldur	x10, [x29, #-64]
	ldr	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.ne	LBB10_53
	b	LBB10_52
LBB10_52:                               ;   in Loop: Header=BB10_50 Depth=2
	ldr	w8, [sp, #84]
	str	w8, [sp, #88]
	b	LBB10_53
LBB10_53:                               ;   in Loop: Header=BB10_50 Depth=2
	b	LBB10_54
LBB10_54:                               ;   in Loop: Header=BB10_50 Depth=2
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB10_50
LBB10_55:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #88]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.hs	LBB10_59
	b	LBB10_56
LBB10_56:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-88]
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-88]
	ldr	w1, [x8, #12]
	ldr	w2, [sp, #88]
	bl	_contains
	tbnz	w0, #0, LBB10_58
	b	LBB10_57
LBB10_57:                               ;   in Loop: Header=BB10_19 Depth=1
	sturb	wzr, [x29, #-193]
	b	LBB10_58
LBB10_58:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-184]
	ldr	w9, [sp, #88]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB10_64
LBB10_59:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #92]
	ldur	x9, [x29, #-56]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB10_61
	b	LBB10_60
LBB10_60:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-88]
	ldr	x0, [x8, #32]
	ldur	x8, [x29, #-88]
	ldr	w1, [x8, #16]
	ldr	w2, [sp, #92]
	bl	_contains
	tbnz	w0, #0, LBB10_62
	b	LBB10_61
LBB10_61:                               ;   in Loop: Header=BB10_19 Depth=1
	sturb	wzr, [x29, #-193]
	b	LBB10_63
LBB10_62:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-192]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB10_63
LBB10_63:                               ;   in Loop: Header=BB10_19 Depth=1
	b	LBB10_64
LBB10_64:                               ;   in Loop: Header=BB10_19 Depth=1
	b	LBB10_65
LBB10_65:                               ;   in Loop: Header=BB10_19 Depth=1
	str	wzr, [sp, #80]
	ldrb	w8, [sp, #135]
	tbz	w8, #0, LBB10_70
	b	LBB10_66
LBB10_66:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #204]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #144]
	add	x8, x8, x9
	str	x8, [sp, #72]
	ldr	x8, [sp, #72]
	ldur	x9, [x29, #-176]
	ldr	w10, [sp, #204]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #4
	ldr	w9, [x9, x10]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.le	LBB10_68
	b	LBB10_67
LBB10_67:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x8, [sp, #72]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.lt	LBB10_69
	b	LBB10_68
LBB10_68:
	sturb	wzr, [x29, #-193]
	b	LBB10_85
LBB10_69:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	x0, [x29, #-176]
	ldur	w1, [x29, #-92]
	ldr	x8, [sp, #72]
	mov	x2, x8
	bl	_passive_target
	ldr	w8, [sp, #80]
	mov	x9, x8
	mov	x8, x9
	add	w8, w8, #1
	str	w8, [sp, #80]
	sub	x8, x29, #32
	str	w0, [x8, x9, lsl #2]
	b	LBB10_70
LBB10_70:                               ;   in Loop: Header=BB10_19 Depth=1
	ldrb	w8, [sp, #136]
	subs	w8, w8, #56
	b.eq	LBB10_72
	b	LBB10_71
LBB10_71:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #204]
	add	w8, w8, #1
	ldr	w9, [sp, #80]
	mov	x10, x9
	mov	x9, x10
	add	w9, w9, #1
	str	w9, [sp, #80]
	sub	x9, x29, #32
	str	w8, [x9, x10, lsl #2]
	b	LBB10_72
LBB10_72:                               ;   in Loop: Header=BB10_19 Depth=1
	str	wzr, [sp, #68]
	b	LBB10_73
LBB10_73:                               ;   Parent Loop BB10_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w8, [x29, #-193]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #36]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB10_75
	b	LBB10_74
LBB10_74:                               ;   in Loop: Header=BB10_73 Depth=2
	ldr	w8, [sp, #68]
	ldr	w9, [sp, #80]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB10_75
LBB10_75:                               ;   in Loop: Header=BB10_73 Depth=2
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB10_83
	b	LBB10_76
LBB10_76:                               ;   in Loop: Header=BB10_73 Depth=2
	ldr	w8, [sp, #68]
	mov	x9, x8
	sub	x8, x29, #32
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #64]
	ldr	w8, [sp, #64]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB10_79
	b	LBB10_77
LBB10_77:                               ;   in Loop: Header=BB10_73 Depth=2
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	tbnz	x8, #63, LBB10_80
	b	LBB10_78
LBB10_78:                               ;   in Loop: Header=BB10_73 Depth=2
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #96]
	subs	x8, x8, x9
	b.eq	LBB10_80
	b	LBB10_79
LBB10_79:                               ;   in Loop: Header=BB10_73 Depth=2
	sturb	wzr, [x29, #-193]
	b	LBB10_81
LBB10_80:                               ;   in Loop: Header=BB10_73 Depth=2
	ldr	x8, [sp, #96]
	ldur	x9, [x29, #-176]
	ldr	w10, [sp, #64]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x8, [x9, #8]
	b	LBB10_81
LBB10_81:                               ;   in Loop: Header=BB10_73 Depth=2
	b	LBB10_82
LBB10_82:                               ;   in Loop: Header=BB10_73 Depth=2
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB10_73
LBB10_83:                               ;   in Loop: Header=BB10_19 Depth=1
	b	LBB10_84
LBB10_84:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w8, [sp, #204]
	add	w8, w8, #1
	str	w8, [sp, #204]
	b	LBB10_19
LBB10_85:
	str	wzr, [sp, #60]
	b	LBB10_86
LBB10_86:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w8, [x29, #-193]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #32]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB10_88
	b	LBB10_87
LBB10_87:                               ;   in Loop: Header=BB10_86 Depth=1
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB10_88
LBB10_88:                               ;   in Loop: Header=BB10_86 Depth=1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB10_93
	b	LBB10_89
LBB10_89:                               ;   in Loop: Header=BB10_86 Depth=1
	ldur	x8, [x29, #-184]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-88]
	ldr	x0, [x8, #24]
	ldr	w1, [sp, #60]
	bl	_at
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, w0, uxtw
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB10_91
	b	LBB10_90
LBB10_90:                               ;   in Loop: Header=BB10_86 Depth=1
	sturb	wzr, [x29, #-193]
	b	LBB10_91
LBB10_91:                               ;   in Loop: Header=BB10_86 Depth=1
	b	LBB10_92
LBB10_92:                               ;   in Loop: Header=BB10_86 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB10_86
LBB10_93:
	str	wzr, [sp, #56]
	b	LBB10_94
LBB10_94:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w8, [x29, #-193]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB10_96
	b	LBB10_95
LBB10_95:                               ;   in Loop: Header=BB10_94 Depth=1
	ldr	w8, [sp, #56]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB10_96
LBB10_96:                               ;   in Loop: Header=BB10_94 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB10_101
	b	LBB10_97
LBB10_97:                               ;   in Loop: Header=BB10_94 Depth=1
	ldur	x8, [x29, #-192]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-88]
	ldr	x0, [x8, #32]
	ldr	w1, [sp, #56]
	bl	_at
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x8, w0, uxtw
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB10_99
	b	LBB10_98
LBB10_98:                               ;   in Loop: Header=BB10_94 Depth=1
	sturb	wzr, [x29, #-193]
	b	LBB10_99
LBB10_99:                               ;   in Loop: Header=BB10_94 Depth=1
	b	LBB10_100
LBB10_100:                              ;   in Loop: Header=BB10_94 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB10_94
LBB10_101:
	b	LBB10_102
LBB10_102:
	ldur	x0, [x29, #-176]
	bl	_free
	ldur	x0, [x29, #-184]
	bl	_free
	ldur	x0, [x29, #-192]
	bl	_free
	ldurb	w8, [x29, #-193]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-33]
	b	LBB10_103
LBB10_103:
	ldurb	w8, [x29, #-33]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB10_105
	b	LBB10_104
LBB10_104:
	bl	___stack_chk_fail
LBB10_105:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #464]            ; 16-byte Folded Reload
	add	sp, sp, #496
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function closed_function
_closed_function:                       ; @closed_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-48]
	stur	w1, [x29, #-52]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	stur	x8, [x29, #-64]
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB11_2
	b	LBB11_1
LBB11_1:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #16]
	subs	w8, w8, #64
	b.lo	LBB11_3
	b	LBB11_2
LBB11_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-33]
	b	LBB11_141
LBB11_3:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB11_5
	b	LBB11_4
LBB11_4:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-33]
	b	LBB11_141
LBB11_5:
	ldur	x8, [x29, #-64]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-72]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB11_11
	b	LBB11_6
LBB11_6:
	ldur	x8, [x29, #-72]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-72]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.gt	LBB11_11
	b	LBB11_7
LBB11_7:
	ldur	x8, [x29, #-72]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.gt	LBB11_11
	b	LBB11_8
LBB11_8:
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #12]
	cbz	w8, LBB11_11
	b	LBB11_9
LBB11_9:
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB11_11
	b	LBB11_10
LBB11_10:
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-72]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB11_12
	b	LBB11_11
LBB11_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-33]
	b	LBB11_141
LBB11_12:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x10, [x29, #-48]
	ldr	w9, [x10, #16]
	add	w9, w9, #1
	str	w9, [x10, #16]
	sturb	w8, [x29, #-73]
	sturb	wzr, [x29, #-74]
	stur	wzr, [x29, #-80]
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #12]
	add	w8, w8, w9
	stur	w8, [x29, #-84]
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-88]
	b	LBB11_13
LBB11_13:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-88]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB11_18
	b	LBB11_14
LBB11_14:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w8, [x29, #-84]
	ldur	w9, [x29, #-88]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	sub	x2, x29, #152
	bl	_isa_decode
	stur	w0, [x29, #-156]
	ldur	w8, [x29, #-156]
	cbz	w8, LBB11_16
	b	LBB11_15
LBB11_15:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	w8, [x29, #-80]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ne	LBB11_17
	b	LBB11_16
LBB11_16:
	sturb	wzr, [x29, #-73]
	b	LBB11_18
LBB11_17:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	w8, [x29, #-80]
	add	w8, w8, #1
	stur	w8, [x29, #-80]
	ldur	w9, [x29, #-156]
	ldur	w8, [x29, #-88]
	add	w8, w8, w9
	stur	w8, [x29, #-88]
	b	LBB11_13
LBB11_18:
	ldur	x8, [x29, #-72]
	ldrh	w8, [x8, #16]
	add	w8, w8, #63
	mov	w9, #64                         ; =0x40
	udiv	w8, w8, w9
	stur	w8, [x29, #-160]
	ldur	w8, [x29, #-160]
	cbnz	w8, LBB11_20
	b	LBB11_19
LBB11_19:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-160]
	b	LBB11_20
LBB11_20:
	ldurb	w8, [x29, #-73]
	tbz	w8, #0, LBB11_22
	b	LBB11_21
LBB11_21:
	ldur	w8, [x29, #-80]
	ldur	w10, [x29, #-160]
	mov	w9, #2097152                    ; =0x200000
	udiv	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB11_23
	b	LBB11_22
LBB11_22:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #3                          ; =0x3
	strb	w8, [x9]
	ldur	x9, [x29, #-48]
	ldr	w8, [x9, #16]
	subs	w8, w8, #1
	str	w8, [x9, #16]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-33]
	b	LBB11_141
LBB11_23:
	ldur	w8, [x29, #-80]
	mov	x0, x8
	mov	x1, #80                         ; =0x50
	bl	_calloc
	stur	x0, [x29, #-168]
	ldur	w8, [x29, #-80]
                                        ; kill: def $x8 killed $w8
	ldur	w9, [x29, #-160]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x0, w8, w9
	mov	x1, #8                          ; =0x8
	str	x1, [sp, #56]                   ; 8-byte Folded Spill
	bl	_calloc
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-176]
	ldur	w8, [x29, #-160]
	mov	x0, x8
	bl	_calloc
	stur	x0, [x29, #-184]
	ldur	w8, [x29, #-80]
	mov	x0, x8
	mov	x1, #4                          ; =0x4
	bl	_calloc
	str	x0, [sp, #192]
	ldur	x8, [x29, #-168]
	cbz	x8, LBB11_27
	b	LBB11_24
LBB11_24:
	ldur	x8, [x29, #-176]
	cbz	x8, LBB11_27
	b	LBB11_25
LBB11_25:
	ldur	x8, [x29, #-184]
	cbz	x8, LBB11_27
	b	LBB11_26
LBB11_26:
	ldr	x8, [sp, #192]
	cbnz	x8, LBB11_28
	b	LBB11_27
LBB11_27:
	sturb	wzr, [x29, #-73]
	b	LBB11_138
LBB11_28:
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #8]
	str	w8, [sp, #188]
	str	wzr, [sp, #184]
	b	LBB11_29
LBB11_29:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #184]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	b.hs	LBB11_32
	b	LBB11_30
LBB11_30:                               ;   in Loop: Header=BB11_29 Depth=1
	ldr	w8, [sp, #188]
	ldur	x12, [x29, #-168]
	ldr	w9, [sp, #184]
	mov	x10, x9
	mov	x9, #80                         ; =0x50
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	str	w8, [x10, #64]
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #280]
	ldr	w10, [sp, #188]
                                        ; kill: def $x10 killed $w10
	add	x0, x8, x10
	ldur	w8, [x29, #-84]
	ldr	w10, [sp, #188]
	subs	w8, w8, w10
	mov	w8, w8
	mov	x1, x8
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x2, w8, w9, x10
	bl	_isa_decode
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x11, [x29, #-168]
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	w0, [x8, #68]
	ldur	x11, [x29, #-168]
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w10, x11
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x10, #72]
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w9, [x8, #68]
	ldr	w8, [sp, #188]
	add	w8, w8, w9
	str	w8, [sp, #188]
	b	LBB11_31
LBB11_31:                               ;   in Loop: Header=BB11_29 Depth=1
	ldr	w8, [sp, #184]
	add	w8, w8, #1
	str	w8, [sp, #184]
	b	LBB11_29
LBB11_32:
	str	wzr, [sp, #180]
	b	LBB11_33
LBB11_33:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #180]
	ldur	x9, [x29, #-72]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB11_36
	b	LBB11_34
LBB11_34:                               ;   in Loop: Header=BB11_33 Depth=1
	ldr	w8, [sp, #180]
	mov	w10, #64                        ; =0x40
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x11, x8, x9
	ldur	x9, [x29, #-176]
	ldr	w8, [sp, #180]
	udiv	w10, w8, w10
	ldr	x8, [x9, w10, uxtw #3]
	orr	x8, x8, x11
	str	x8, [x9, w10, uxtw #3]
	b	LBB11_35
LBB11_35:                               ;   in Loop: Header=BB11_33 Depth=1
	ldr	w8, [sp, #180]
	add	w8, w8, #1
	str	w8, [sp, #180]
	b	LBB11_33
LBB11_36:
	ldur	x9, [x29, #-168]
	mov	w8, #0                          ; =0x0
	str	wzr, [x9, #72]
	ldur	x10, [x29, #-168]
	mov	w9, #1                          ; =0x1
	strb	w9, [x10, #76]
	str	wzr, [sp, #176]
	str	wzr, [sp, #172]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #168]
	str	wzr, [sp, #164]
	ldr	x9, [sp, #192]
	ldr	w10, [sp, #172]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #172]
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #172]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	b.ne	LBB11_38
	b	LBB11_37
LBB11_37:
	str	wzr, [sp, #172]
	b	LBB11_38
LBB11_38:
	b	LBB11_39
LBB11_39:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB11_75 Depth 2
                                        ;     Child Loop BB11_101 Depth 2
                                        ;       Child Loop BB11_110 Depth 3
	ldurb	w8, [x29, #-73]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #44]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_41
	b	LBB11_40
LBB11_40:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #168]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB11_41
LBB11_41:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB11_126
	b	LBB11_42
LBB11_42:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #164]
	add	w8, w8, #1
	str	w8, [sp, #164]
	subs	w8, w8, #256, lsl #12           ; =1048576
	b.ls	LBB11_44
	b	LBB11_43
LBB11_43:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_44:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #192]
	ldr	w9, [sp, #176]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #176]
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #160]
	ldr	w8, [sp, #176]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	b.ne	LBB11_46
	b	LBB11_45
LBB11_45:                               ;   in Loop: Header=BB11_39 Depth=1
	str	wzr, [sp, #176]
	b	LBB11_46
LBB11_46:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #168]
	subs	w8, w8, #1
	str	w8, [sp, #168]
	ldur	x11, [x29, #-168]
	ldr	w8, [sp, #160]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	strb	wzr, [x8, #76]
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #160]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #152]
	ldr	x8, [sp, #152]
	ldrb	w0, [x8]
	bl	_isa_get_info
	str	x0, [sp, #144]
	ldr	x8, [sp, #144]
	cbnz	x8, LBB11_48
	b	LBB11_47
LBB11_47:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_48:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #144]
	ldrsb	w8, [x8, #28]
	str	w8, [sp, #140]
	ldr	x8, [sp, #144]
	ldrsb	w8, [x8, #29]
	str	w8, [sp, #136]
	ldr	x8, [sp, #152]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #56
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB11_51
	b	LBB11_49
LBB11_49:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #57
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB11_51
	b	LBB11_50
LBB11_50:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #58
	cset	w8, eq
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB11_51
LBB11_51:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #135]
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #59
	b.eq	LBB11_53
	b	LBB11_52
LBB11_52:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #51
	b.ne	LBB11_56
	b	LBB11_53
LBB11_53:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldr	w8, [x8, #8]
	str	w8, [sp, #128]
	ldur	x0, [x29, #-48]
	ldr	w1, [sp, #128]
	bl	_closed_function
	tbnz	w0, #0, LBB11_55
	b	LBB11_54
LBB11_54:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_55:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #128]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrh	w8, [x8, #4]
	str	w8, [sp, #140]
	ldur	x8, [x29, #-64]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #128]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #21]
	str	w8, [sp, #136]
	b	LBB11_69
LBB11_56:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #61
	b.ne	LBB11_58
	b	LBB11_57
LBB11_57:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x8, [x29, #-72]
	ldrb	w8, [x8, #21]
	str	w8, [sp, #140]
	str	wzr, [sp, #136]
	b	LBB11_68
LBB11_58:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w0, [x8]
	mov	w1, #2                          ; =0x2
	bl	_allowed
	tbnz	w0, #0, LBB11_67
	b	LBB11_59
LBB11_59:                               ;   in Loop: Header=BB11_39 Depth=1
	ldrb	w8, [sp, #135]
	tbnz	w8, #0, LBB11_67
	b	LBB11_60
LBB11_60:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #140
	b.eq	LBB11_67
	b	LBB11_61
LBB11_61:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #161
	b.eq	LBB11_67
	b	LBB11_62
LBB11_62:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #136
	b.eq	LBB11_67
	b	LBB11_63
LBB11_63:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #137
	b.eq	LBB11_67
	b	LBB11_64
LBB11_64:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #138
	b.eq	LBB11_67
	b	LBB11_65
LBB11_65:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #139
	b.eq	LBB11_67
	b	LBB11_66
LBB11_66:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_67:                               ;   in Loop: Header=BB11_39 Depth=1
	b	LBB11_68
LBB11_68:                               ;   in Loop: Header=BB11_39 Depth=1
	b	LBB11_69
LBB11_69:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #140]
	tbnz	w8, #31, LBB11_73
	b	LBB11_70
LBB11_70:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #136]
	tbnz	w8, #31, LBB11_73
	b	LBB11_71
LBB11_71:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #160]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #72]
	ldr	w9, [sp, #140]
	subs	w8, w8, w9
	b.lt	LBB11_73
	b	LBB11_72
LBB11_72:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #160]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #72]
	ldr	w9, [sp, #140]
	subs	w8, w8, w9
	ldr	w10, [sp, #136]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.le	LBB11_74
	b	LBB11_73
LBB11_73:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_74:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #160]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #72]
	ldr	w9, [sp, #140]
	subs	w8, w8, w9
	ldr	w9, [sp, #136]
	add	w8, w8, w9
	str	w8, [sp, #124]
	str	wzr, [sp, #120]
	b	LBB11_75
LBB11_75:                               ;   Parent Loop BB11_39 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #120]
	ldur	w9, [x29, #-160]
	subs	w8, w8, w9
	b.hs	LBB11_78
	b	LBB11_76
LBB11_76:                               ;   in Loop: Header=BB11_75 Depth=2
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #160]
                                        ; kill: def $x9 killed $w9
	ldur	w10, [x29, #-160]
                                        ; kill: def $x10 killed $w10
	ldr	w11, [sp, #120]
                                        ; kill: def $x11 killed $w11
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-184]
	ldr	w10, [sp, #120]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	b	LBB11_77
LBB11_77:                               ;   in Loop: Header=BB11_75 Depth=2
	ldr	w8, [sp, #120]
	add	w8, w8, #1
	str	w8, [sp, #120]
	b	LBB11_75
LBB11_78:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.eq	LBB11_80
	b	LBB11_79
LBB11_79:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #17
	b.ne	LBB11_85
	b	LBB11_80
LBB11_80:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrh	w8, [x8, #8]
	str	w8, [sp, #116]
	ldr	w8, [sp, #116]
	ldur	x9, [x29, #-72]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB11_82
	b	LBB11_81
LBB11_81:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_82:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #17
	b.ne	LBB11_84
	b	LBB11_83
LBB11_83:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #116]
	mov	w10, #64                        ; =0x40
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x11, x8, x9
	ldur	x9, [x29, #-184]
	ldr	w8, [sp, #116]
	udiv	w10, w8, w10
	ldr	x8, [x9, w10, uxtw #3]
	orr	x8, x8, x11
	str	x8, [x9, w10, uxtw #3]
	b	LBB11_84
LBB11_84:                               ;   in Loop: Header=BB11_39 Depth=1
	b	LBB11_85
LBB11_85:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #61
	b.eq	LBB11_87
	b	LBB11_86
LBB11_86:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #51
	b.ne	LBB11_93
	b	LBB11_87
LBB11_87:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #61
	b.ne	LBB11_89
	b	LBB11_88
LBB11_88:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #124]
	cbnz	w8, LBB11_91
	b	LBB11_92
LBB11_89:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #124]
	ldur	x9, [x29, #-72]
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.ne	LBB11_91
	b	LBB11_90
LBB11_90:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #152]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #21]
	ldur	x9, [x29, #-72]
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.eq	LBB11_92
	b	LBB11_91
LBB11_91:                               ;   in Loop: Header=BB11_39 Depth=1
	sturb	wzr, [x29, #-73]
	b	LBB11_92
LBB11_92:                               ;   in Loop: Header=BB11_39 Depth=1
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-74]
	b	LBB11_39
LBB11_93:                               ;   in Loop: Header=BB11_39 Depth=1
	str	wzr, [sp, #112]
	ldrb	w8, [sp, #135]
	tbz	w8, #0, LBB11_98
	b	LBB11_94
LBB11_94:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #160]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #64]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #152]
	ldrsw	x9, [x9, #8]
	add	x8, x8, x9
	str	x8, [sp, #104]
	ldr	x8, [sp, #104]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.lt	LBB11_96
	b	LBB11_95
LBB11_95:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #104]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.lt	LBB11_97
	b	LBB11_96
LBB11_96:
	sturb	wzr, [x29, #-73]
	b	LBB11_126
LBB11_97:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x0, [x29, #-168]
	ldur	w1, [x29, #-80]
	ldr	x8, [sp, #104]
	mov	x2, x8
	bl	_closed_target
	ldr	w8, [sp, #112]
	mov	x9, x8
	mov	x8, x9
	add	w8, w8, #1
	str	w8, [sp, #112]
	sub	x8, x29, #32
	str	w0, [x8, x9, lsl #2]
	b	LBB11_98
LBB11_98:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	subs	w8, w8, #56
	b.eq	LBB11_100
	b	LBB11_99
LBB11_99:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #160]
	add	w8, w8, #1
	ldr	w9, [sp, #112]
	mov	x10, x9
	mov	x9, x10
	add	w9, w9, #1
	str	w9, [sp, #112]
	sub	x9, x29, #32
	str	w8, [x9, x10, lsl #2]
	b	LBB11_100
LBB11_100:                              ;   in Loop: Header=BB11_39 Depth=1
	str	wzr, [sp, #100]
	b	LBB11_101
LBB11_101:                              ;   Parent Loop BB11_39 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB11_110 Depth 3
	ldurb	w8, [x29, #-73]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #36]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_103
	b	LBB11_102
LBB11_102:                              ;   in Loop: Header=BB11_101 Depth=2
	ldr	w8, [sp, #100]
	ldr	w9, [sp, #112]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB11_103
LBB11_103:                              ;   in Loop: Header=BB11_101 Depth=2
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB11_125
	b	LBB11_104
LBB11_104:                              ;   in Loop: Header=BB11_101 Depth=2
	ldr	w8, [sp, #100]
	mov	x9, x8
	sub	x8, x29, #32
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #96]
	ldr	w8, [sp, #96]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	b.lo	LBB11_106
	b	LBB11_105
LBB11_105:                              ;   in Loop: Header=BB11_39 Depth=1
	sturb	wzr, [x29, #-73]
	b	LBB11_125
LBB11_106:                              ;   in Loop: Header=BB11_101 Depth=2
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #72]
	subs	w8, w8, #0
	cset	w8, lt
	strb	w8, [sp, #95]
	ldrb	w8, [sp, #95]
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #94]
	ldrb	w8, [sp, #95]
	tbnz	w8, #0, LBB11_109
	b	LBB11_107
LBB11_107:                              ;   in Loop: Header=BB11_101 Depth=2
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #72]
	ldr	w9, [sp, #124]
	subs	w8, w8, w9
	b.eq	LBB11_109
	b	LBB11_108
LBB11_108:                              ;   in Loop: Header=BB11_39 Depth=1
	sturb	wzr, [x29, #-73]
	b	LBB11_125
LBB11_109:                              ;   in Loop: Header=BB11_101 Depth=2
	ldr	w8, [sp, #124]
	ldur	x11, [x29, #-168]
	ldr	w9, [sp, #96]
                                        ; kill: def $x9 killed $w9
	mov	x10, #80                        ; =0x50
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #72]
	str	wzr, [sp, #88]
	b	LBB11_110
LBB11_110:                              ;   Parent Loop BB11_39 Depth=1
                                        ;     Parent Loop BB11_101 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [sp, #88]
	ldur	w9, [x29, #-160]
	subs	w8, w8, w9
	b.hs	LBB11_118
	b	LBB11_111
LBB11_111:                              ;   in Loop: Header=BB11_110 Depth=3
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #96]
                                        ; kill: def $x9 killed $w9
	ldur	w10, [x29, #-160]
                                        ; kill: def $x10 killed $w10
	ldr	w11, [sp, #88]
                                        ; kill: def $x11 killed $w11
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #80]
	ldrb	w8, [sp, #95]
	tbz	w8, #0, LBB11_113
	b	LBB11_112
LBB11_112:                              ;   in Loop: Header=BB11_110 Depth=3
	ldur	x8, [x29, #-184]
	ldr	w9, [sp, #88]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB11_114
LBB11_113:                              ;   in Loop: Header=BB11_110 Depth=3
	ldr	x8, [sp, #80]
	ldr	x8, [x8]
	ldur	x9, [x29, #-184]
	ldr	w10, [sp, #88]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	and	x8, x8, x9
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB11_114
LBB11_114:                              ;   in Loop: Header=BB11_110 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #72]
	ldr	x8, [sp, #80]
	ldr	x8, [x8]
	ldr	x9, [sp, #72]
	subs	x8, x8, x9
	b.eq	LBB11_116
	b	LBB11_115
LBB11_115:                              ;   in Loop: Header=BB11_110 Depth=3
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #94]
	b	LBB11_116
LBB11_116:                              ;   in Loop: Header=BB11_110 Depth=3
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #80]
	str	x8, [x9]
	b	LBB11_117
LBB11_117:                              ;   in Loop: Header=BB11_110 Depth=3
	ldr	w8, [sp, #88]
	add	w8, w8, #1
	str	w8, [sp, #88]
	b	LBB11_110
LBB11_118:                              ;   in Loop: Header=BB11_101 Depth=2
	ldrb	w8, [sp, #94]
	tbz	w8, #0, LBB11_123
	b	LBB11_119
LBB11_119:                              ;   in Loop: Header=BB11_101 Depth=2
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #76]
	tbnz	w8, #0, LBB11_123
	b	LBB11_120
LBB11_120:                              ;   in Loop: Header=BB11_101 Depth=2
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #76]
	ldr	w8, [sp, #96]
	ldr	x9, [sp, #192]
	ldr	w10, [sp, #172]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #172]
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #172]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	b.ne	LBB11_122
	b	LBB11_121
LBB11_121:                              ;   in Loop: Header=BB11_101 Depth=2
	str	wzr, [sp, #172]
	b	LBB11_122
LBB11_122:                              ;   in Loop: Header=BB11_101 Depth=2
	ldr	w8, [sp, #168]
	add	w8, w8, #1
	str	w8, [sp, #168]
	b	LBB11_123
LBB11_123:                              ;   in Loop: Header=BB11_101 Depth=2
	b	LBB11_124
LBB11_124:                              ;   in Loop: Header=BB11_101 Depth=2
	ldr	w8, [sp, #100]
	add	w8, w8, #1
	str	w8, [sp, #100]
	b	LBB11_101
LBB11_125:                              ;   in Loop: Header=BB11_39 Depth=1
	b	LBB11_39
LBB11_126:
	str	wzr, [sp, #68]
	b	LBB11_127
LBB11_127:                              ; =>This Inner Loop Header: Depth=1
	ldurb	w8, [x29, #-73]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_129
	b	LBB11_128
LBB11_128:                              ;   in Loop: Header=BB11_127 Depth=1
	ldr	w8, [sp, #68]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB11_129
LBB11_129:                              ;   in Loop: Header=BB11_127 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB11_137
	b	LBB11_130
LBB11_130:                              ;   in Loop: Header=BB11_127 Depth=1
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #72]
	tbnz	w8, #31, LBB11_132
	b	LBB11_131
LBB11_131:                              ;   in Loop: Header=BB11_127 Depth=1
	ldur	x8, [x29, #-168]
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	mov	x10, #80                        ; =0x50
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #16
	b.eq	LBB11_133
	b	LBB11_132
LBB11_132:                              ;   in Loop: Header=BB11_127 Depth=1
	b	LBB11_136
LBB11_133:                              ;   in Loop: Header=BB11_127 Depth=1
	ldur	x10, [x29, #-168]
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	str	w8, [sp, #64]
	ldur	x8, [x29, #-176]
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	ldur	w10, [x29, #-160]
                                        ; kill: def $x10 killed $w10
	ldr	w12, [sp, #64]
	mov	w11, #64                        ; =0x40
	udiv	w12, w12, w11
	mov	w12, w12
                                        ; kill: def $x12 killed $w12
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x12
	ldr	x8, [x8, x9, lsl #3]
	ldr	w9, [sp, #64]
	udiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w10, w9, w10
	mov	x9, #1                          ; =0x1
                                        ; kill: def $x10 killed $w10
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbnz	x8, LBB11_135
	b	LBB11_134
LBB11_134:                              ;   in Loop: Header=BB11_127 Depth=1
	sturb	wzr, [x29, #-73]
	b	LBB11_135
LBB11_135:                              ;   in Loop: Header=BB11_127 Depth=1
	b	LBB11_136
LBB11_136:                              ;   in Loop: Header=BB11_127 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB11_127
LBB11_137:
	b	LBB11_138
LBB11_138:
	ldur	x0, [x29, #-168]
	bl	_free
	ldur	x0, [x29, #-176]
	bl	_free
	ldur	x0, [x29, #-184]
	bl	_free
	ldr	x0, [sp, #192]
	bl	_free
	ldurb	w8, [x29, #-73]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_140
	b	LBB11_139
LBB11_139:
	ldurb	w8, [x29, #-74]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB11_140
LBB11_140:
	ldr	w11, [sp, #16]                  ; 4-byte Folded Reload
	mov	w10, #3                         ; =0x3
	mov	w8, #2                          ; =0x2
	mov	w9, #1                          ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w8, w8, w10, ne
	ldur	x10, [x29, #-48]
	ldr	x10, [x10, #8]
	ldur	w11, [x29, #-52]
                                        ; kill: def $x11 killed $w11
	strb	w8, [x10, x11]
	ldur	x10, [x29, #-48]
	ldr	w8, [x10, #16]
	subs	w8, w8, #1
	str	w8, [x10, #16]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #8]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	ldrb	w8, [x8, x10]
	subs	w8, w8, #2
	cset	w8, eq
	and	w8, w8, w9
	sturb	w8, [x29, #-33]
	b	LBB11_141
LBB11_141:
	ldurb	w8, [x29, #-33]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB11_143
	b	LBB11_142
LBB11_142:
	bl	___stack_chk_fail
LBB11_143:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function passive_target
_passive_target:                        ; @passive_target
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	w1, [sp, #20]
	str	w2, [sp, #16]
	str	wzr, [sp, #12]
	ldr	w8, [sp, #20]
	str	w8, [sp, #8]
	b	LBB12_1
LBB12_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #8]
	subs	w8, w8, w9
	b.hs	LBB12_6
	b	LBB12_2
LBB12_2:                                ;   in Loop: Header=BB12_1 Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #8]
	ldr	w10, [sp, #12]
	subs	w9, w9, w10
	mov	w10, #2                         ; =0x2
	udiv	w9, w9, w10
	add	w8, w8, w9
	str	w8, [sp, #4]
	ldr	x8, [sp, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.hs	LBB12_4
	b	LBB12_3
LBB12_3:                                ;   in Loop: Header=BB12_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB12_5
LBB12_4:                                ;   in Loop: Header=BB12_1 Depth=1
	ldr	w8, [sp, #4]
	str	w8, [sp, #8]
	b	LBB12_5
LBB12_5:                                ;   in Loop: Header=BB12_1 Depth=1
	b	LBB12_1
LBB12_6:
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.hs	LBB12_9
	b	LBB12_7
LBB12_7:
	ldr	x8, [sp, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.ne	LBB12_9
	b	LBB12_8
LBB12_8:
	ldr	w8, [sp, #12]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB12_10
LBB12_9:
	ldr	w8, [sp, #20]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB12_10
LBB12_10:
	ldr	w0, [sp]                        ; 4-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function closed_target
_closed_target:                         ; @closed_target
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	w1, [sp, #20]
	str	w2, [sp, #16]
	str	wzr, [sp, #12]
	ldr	w8, [sp, #20]
	str	w8, [sp, #8]
	b	LBB13_1
LBB13_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #8]
	subs	w8, w8, w9
	b.hs	LBB13_6
	b	LBB13_2
LBB13_2:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #8]
	ldr	w10, [sp, #12]
	subs	w9, w9, w10
	mov	w10, #2                         ; =0x2
	udiv	w9, w9, w10
	add	w8, w8, w9
	str	w8, [sp, #4]
	ldr	x10, [sp, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #64]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.hs	LBB13_4
	b	LBB13_3
LBB13_3:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB13_5
LBB13_4:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	w8, [sp, #4]
	str	w8, [sp, #8]
	b	LBB13_5
LBB13_5:                                ;   in Loop: Header=BB13_1 Depth=1
	b	LBB13_1
LBB13_6:
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.hs	LBB13_9
	b	LBB13_7
LBB13_7:
	ldr	x10, [sp, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #80                         ; =0x50
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #64]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.ne	LBB13_9
	b	LBB13_8
LBB13_8:
	ldr	w8, [sp, #12]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB13_10
LBB13_9:
	ldr	w8, [sp, #20]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB13_10
LBB13_10:
	ldr	w0, [sp]                        ; 4-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
