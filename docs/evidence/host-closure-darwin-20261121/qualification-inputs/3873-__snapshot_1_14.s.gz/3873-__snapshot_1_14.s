	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_module_free     ; -- Begin function nvm_v2_module_free
	.globl	_nvm_v2_module_free
	.p2align	2
_nvm_v2_module_free:                    ; @nvm_v2_module_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x0, x0, #8
	bl	_nvm_v2_metadata_free
	add	x0, x19, #24
	bl	_nvm_v2_constants_free
	add	x0, x19, #40
	bl	_nvm_v2_signatures_free
	add	x0, x19, #56
	bl	_nvm_v2_layouts_free
	add	x0, x19, #72
	bl	_nvm_v2_functions_free
	add	x0, x19, #88
	bl	_nvm_v2_globals_free
	add	x0, x19, #104
	bl	_nvm_v2_imports_free
	add	x0, x19, #120
	bl	_nvm_v2_callbacks_free
	add	x0, x19, #136
	bl	_nvm_v2_links_free
	add	x0, x19, #152
	bl	_nvm_v2_debug_free
	ldr	x0, [x19, #232]
	bl	_free
	str	xzr, [x19, #232]
	str	xzr, [x19, #216]
	str	wzr, [x19, #224]
	str	xzr, [x19, #200]
	str	wzr, [x19, #208]
	strb	wzr, [x19, #228]
	stp	xzr, xzr, [x19, #168]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_private_serialize  ; -- Begin function nvm_private_serialize
	.globl	_nvm_private_serialize
	.p2align	2
_nvm_private_serialize:                 ; @nvm_private_serialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x4
	mov	x19, x3
	mov	x23, x2
	mov	x20, x1
	mov	x22, x0
	bl	_nvm_record_map_wire_selected
	cbz	w0, LBB1_9
; %bb.1:
	str	xzr, [sp, #8]
	add	x3, sp, #8
	mov	x0, x22
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x4, x21
	bl	_nvm_serialize_core
	cbnz	w0, LBB1_13
; %bb.2:
	cbz	x20, LBB1_11
; %bb.3:
	ldr	x24, [sp, #8]
	cmp	x23, x24
	b.lo	LBB1_10
; %bb.4:
	cmp	x24, #1
	csinc	x0, x24, xzr, hi
	bl	_malloc
	cbz	x0, LBB1_10
; %bb.5:
	mov	x23, x0
	mov	x0, x22
	mov	x1, x23
	mov	x2, x24
	mov	x3, #0                          ; =0x0
	mov	x4, x21
	bl	_nvm_serialize_core
	mov	x21, x0
	cbnz	w0, LBB1_8
; %bb.6:
	mov	x0, x20
	mov	x1, x23
	mov	x2, x24
	bl	_memcpy
	cbz	x19, LBB1_8
; %bb.7:
	str	x24, [x19]
LBB1_8:
	mov	x0, x23
	bl	_free
	mov	x0, x21
	b	LBB1_13
LBB1_9:
	mov	x0, x22
	mov	x1, x20
	mov	x2, x23
	mov	x3, x19
	mov	x4, x21
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	b	_nvm_serialize_core
LBB1_10:
	mov	w0, #1                          ; =0x1
	b	LBB1_13
LBB1_11:
	mov	w0, #0                          ; =0x0
	cbz	x19, LBB1_13
; %bb.12:
	ldr	x8, [sp, #8]
	str	x8, [x19]
LBB1_13:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_serialize_core
lCPI2_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
lCPI2_1:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
lCPI2_2:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
lCPI2_3:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
lCPI2_4:
	.long	5                               ; 0x5
	.long	0                               ; 0x0
lCPI2_5:
	.long	6                               ; 0x6
	.long	0                               ; 0x0
lCPI2_6:
	.long	7                               ; 0x7
	.long	0                               ; 0x0
lCPI2_7:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
lCPI2_8:
	.long	9                               ; 0x9
	.long	0                               ; 0x0
lCPI2_9:
	.long	10                              ; 0xa
	.long	0                               ; 0x0
lCPI2_10:
	.long	11                              ; 0xb
	.long	0                               ; 0x0
lCPI2_11:
	.long	12                              ; 0xc
	.long	0                               ; 0x0
lCPI2_12:
	.long	13                              ; 0xd
	.long	0                               ; 0x0
lCPI2_13:
	.long	14                              ; 0xe
	.long	0                               ; 0x0
lCPI2_14:
	.byte	78                              ; 0x4e
	.byte	86                              ; 0x56
	.byte	77                              ; 0x4d
	.byte	2                               ; 0x2
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_nvm_serialize_core:                    ; @nvm_serialize_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #592
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB2_6
; %bb.1:
	cbz	x4, LBB2_8
; %bb.2:
	ldr	x8, [x4]
	cbz	x8, LBB2_7
; %bb.3:
	ldr	x8, [x4, #8]
	cbz	x8, LBB2_7
; %bb.4:
	ldr	w9, [x4, #16]
	cbz	w9, LBB2_7
; %bb.5:
	mov	x20, x4
	mov	x21, x3
	mov	x28, x2
	mov	x22, x1
	mov	x19, x0
	blr	x8
	cbnz	w0, LBB2_70
	b	LBB2_9
LBB2_6:
	mov	w0, #13                         ; =0xd
	b	LBB2_70
LBB2_7:
	mov	w0, #8                          ; =0x8
	b	LBB2_70
LBB2_8:
	mov	x20, x4
	mov	x21, x3
	mov	x28, x2
	mov	x22, x1
	mov	x19, x0
	bl	_nvm_v2_service_bindings_validate
	cbnz	w0, LBB2_70
LBB2_9:
	mov	x0, x19
	ldr	w8, [x19, #208]
	cbz	w8, LBB2_11
; %bb.10:
	ldr	x9, [x0, #200]
	cbnz	x9, LBB2_12
	b	LBB2_18
LBB2_11:
	ldrb	w9, [x0, #240]
	tbnz	w9, #6, LBB2_18
LBB2_12:
	ldr	w9, [x0, #192]
	cbz	w9, LBB2_15
; %bb.13:
	ldr	x9, [x0, #184]
	cbz	x9, LBB2_18
; %bb.14:
	mov	w9, #0                          ; =0x0
	b	LBB2_21
LBB2_15:
	ldrb	w9, [x0, #241]
	tbnz	w9, #0, LBB2_18
; %bb.16:
	cbz	w8, LBB2_19
; %bb.17:
	mov	w9, #1                          ; =0x1
	b	LBB2_21
LBB2_18:
	mov	w0, #14                         ; =0xe
	b	LBB2_70
LBB2_19:
	mov	x19, x0
	bl	_nvm_v2_service_bindings_present
	cbz	w0, LBB2_28
; %bb.20:
	mov	x0, x19
	ldr	w8, [x19, #208]
	ldr	w9, [x19, #192]
	cmp	w9, #0
	cset	w9, eq
LBB2_21:
	ldr	w10, [x0, #144]
	cmp	w10, #0
	cset	w10, ne
	ldr	w11, [x0, #112]
	mov	w12, #2                         ; =0x2
	cinc	w12, w12, ne
	cmp	w11, #0
	csel	w10, w10, w12, eq
	ldr	w11, [x0, #128]
	orr	w12, w10, #0x20
	cmp	w11, #0
	csel	w10, w10, w12, eq
	orr	w11, w10, #0x40
	cmp	w8, #0
	csel	w8, w10, w11, eq
	orr	w10, w8, #0x100
	cmp	w9, #0
	csel	w8, w8, w10, ne
	ldr	w9, [x0, #224]
	orr	w10, w8, #0x200
	cmp	w9, #0
	csel	w23, w8, w10, eq
	mov	x19, x0
	add	x0, x0, #56
	bl	_nvm_layouts_have_facts
	mov	x8, x19
	orr	w9, w23, #0x80
	cmp	w0, #0
	csel	w9, w9, w23, ne
	ldrb	w10, [x19, #228]
	orr	w9, w9, w10, lsl #3
	ldr	w10, [x19, #112]
	cbz	w10, LBB2_24
; %bb.22:
	ldr	x11, [x8, #104]
	add	x11, x11, #12
	mov	x2, x20
LBB2_23:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x11], #16
	orr	w13, w9, #0x4
	cmp	w12, #1
	csel	w9, w13, w9, eq
	subs	x10, x10, #1
	b.ne	LBB2_23
	b	LBB2_25
LBB2_24:
	mov	x2, x20
LBB2_25:
	ldr	w10, [x8, #240]
	orr	w1, w10, w9
	mov	x0, x8
	mov	x20, x2
	bl	_validate_cross_section
	cbnz	w0, LBB2_70
; %bb.26:
	str	xzr, [sp, #128]
	add	x1, sp, #128
	mov	x0, x19
	mov	x2, x20
	bl	_nvm_private_to_module
	mov	x20, x0
	ldr	x0, [sp, #128]
	bl	_nvm_module_free
	cbz	w20, LBB2_28
; %bb.27:
	mov	x0, x20
	b	LBB2_70
LBB2_28:
	add	x26, sp, #128
	add	x0, x19, #8
	bl	_nvm_v2_metadata_encoded_size
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
Lloh3:
	adrp	x8, lCPI2_0@PAGE
Lloh4:
	ldr	d0, [x8, lCPI2_0@PAGEOFF]
	str	d0, [sp, #128]
	stp	x0, xzr, [sp, #136]
	mov	w23, #1                         ; =0x1
	strb	w23, [sp, #152]
	stur	wzr, [sp, #153]
	str	wzr, [sp, #156]
	add	x0, x19, #24
	bl	_nvm_v2_constants_encoded_size
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
Lloh5:
	adrp	x8, lCPI2_1@PAGE
Lloh6:
	ldr	d0, [x8, lCPI2_1@PAGEOFF]
	str	d0, [sp, #160]
	stp	x0, xzr, [sp, #168]
	strb	w23, [sp, #184]
	stur	wzr, [x26, #57]
	str	wzr, [sp, #188]
	add	x0, x19, #40
	bl	_nvm_v2_signatures_encoded_size
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
Lloh7:
	adrp	x8, lCPI2_2@PAGE
Lloh8:
	ldr	d0, [x8, lCPI2_2@PAGEOFF]
	str	d0, [sp, #192]
	stp	x0, xzr, [sp, #200]
	strb	w23, [sp, #216]
	stur	wzr, [x26, #89]
	str	wzr, [sp, #220]
	add	x0, x19, #56
	bl	_nvm_v2_layouts_encoded_size
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
Lloh9:
	adrp	x8, lCPI2_3@PAGE
Lloh10:
	ldr	d0, [x8, lCPI2_3@PAGEOFF]
	str	d0, [sp, #224]
	stp	x0, xzr, [sp, #232]
	strb	w23, [sp, #248]
	stur	wzr, [x26, #121]
	str	wzr, [sp, #252]
	add	x0, x19, #72
	bl	_nvm_v2_functions_encoded_size
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
Lloh11:
	adrp	x8, lCPI2_4@PAGE
Lloh12:
	ldr	d0, [x8, lCPI2_4@PAGEOFF]
	str	d0, [sp, #256]
	stp	x0, xzr, [sp, #264]
	strb	w23, [sp, #280]
	stur	wzr, [x26, #153]
	str	wzr, [sp, #284]
	ldr	x9, [x19, #176]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
Lloh13:
	adrp	x8, lCPI2_5@PAGE
Lloh14:
	ldr	d0, [x8, lCPI2_5@PAGEOFF]
	str	d0, [sp, #288]
	stp	x9, xzr, [sp, #296]
	strb	w23, [sp, #312]
	stur	wzr, [x26, #185]
	str	wzr, [sp, #316]
	add	x0, x19, #88
	bl	_nvm_v2_globals_encoded_size
	mov	x24, x0
Lloh15:
	adrp	x8, lCPI2_6@PAGE
Lloh16:
	ldr	d0, [x8, lCPI2_6@PAGEOFF]
	str	d0, [sp, #320]
	stp	x0, xzr, [sp, #328]
	strb	w23, [sp, #344]
	stur	wzr, [x26, #217]
	str	wzr, [sp, #348]
	add	x0, x19, #104
	bl	_nvm_v2_imports_encoded_size
	mov	x25, x0
Lloh17:
	adrp	x8, lCPI2_7@PAGE
Lloh18:
	ldr	d0, [x8, lCPI2_7@PAGEOFF]
	str	d0, [sp, #352]
	stp	x0, xzr, [sp, #360]
	strb	w23, [sp, #376]
	stur	wzr, [x26, #249]
	str	wzr, [sp, #380]
	add	x0, x19, #136
	bl	_nvm_v2_links_encoded_size
	mov	x26, x0
Lloh19:
	adrp	x8, lCPI2_8@PAGE
Lloh20:
	ldr	d0, [x8, lCPI2_8@PAGEOFF]
	str	d0, [sp, #384]
	stp	x0, xzr, [sp, #392]
	strb	w23, [sp, #408]
	add	x20, sp, #128
	add	x8, x20, #281
	str	wzr, [x8]
	str	wzr, [sp, #412]
	add	x0, x19, #152
	bl	_nvm_v2_debug_encoded_size
	mov	x27, x0
	ldrb	w23, [x19, #228]
Lloh21:
	adrp	x8, lCPI2_9@PAGE
Lloh22:
	ldr	d0, [x8, lCPI2_9@PAGEOFF]
	str	d0, [sp, #416]
	stp	x0, xzr, [sp, #424]
	strb	w23, [sp, #440]
	add	x8, x20, #313
	str	wzr, [x8]
	str	wzr, [sp, #444]
	add	x0, x19, #120
	bl	_nvm_v2_callbacks_encoded_size
	mov	x9, x19
	ldr	w14, [x19, #128]
	cmp	w14, #0
	cset	w8, ne
Lloh23:
	adrp	x10, lCPI2_10@PAGE
Lloh24:
	ldr	d0, [x10, lCPI2_10@PAGEOFF]
	str	d0, [sp, #448]
	stp	x0, xzr, [sp, #456]
	strb	w8, [sp, #472]
	add	x8, x20, #345
	str	wzr, [x8]
	str	wzr, [sp, #476]
	ldr	w11, [x19, #208]
	cinc	w8, w23, ne
	cmp	x11, #0
	cset	w10, ne
Lloh25:
	adrp	x12, lCPI2_11@PAGE
Lloh26:
	ldr	d0, [x12, lCPI2_11@PAGEOFF]
	str	d0, [sp, #480]
	stp	x11, xzr, [sp, #488]
	strb	w10, [sp, #504]
	add	x10, x20, #377
	str	wzr, [x10]
	str	wzr, [sp, #508]
	ldr	w12, [x19, #192]
	cinc	w8, w8, ne
	cmp	x12, #0
	cset	w10, ne
Lloh27:
	adrp	x13, lCPI2_12@PAGE
Lloh28:
	ldr	d0, [x13, lCPI2_12@PAGEOFF]
	str	d0, [sp, #512]
	str	x12, [sp, #520]
	str	xzr, [sp, #528]
	strb	w10, [sp, #536]
	add	x10, x20, #409
	str	wzr, [x10]
	str	wzr, [sp, #540]
	ldr	w13, [x19, #224]
	cinc	w8, w8, ne
	cmp	x13, #0
	cset	w10, ne
Lloh29:
	adrp	x15, lCPI2_13@PAGE
Lloh30:
	ldr	d0, [x15, lCPI2_13@PAGEOFF]
	str	d0, [sp, #544]
	str	x13, [sp, #552]
	str	xzr, [sp, #560]
	strb	w10, [sp, #568]
	add	x10, x20, #441
	str	wzr, [x10]
	str	wzr, [sp, #572]
	cinc	w10, w8, ne
	mov	w8, #24                         ; =0x18
	mov	w15, #259                       ; =0x103
	madd	w8, w10, w8, w15
	and	w8, w8, #0x7ffffff8
	ldr	x15, [sp, #48]                  ; 8-byte Folded Reload
	add	x15, x15, x8
	add	x15, x15, #3
	and	x15, x15, #0xfffffffffffffffc
	str	x8, [sp, #144]
	str	x15, [sp, #176]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x15
	add	x8, x8, #3
	and	x8, x8, #0xfffffffffffffffc
	ldr	x15, [sp, #32]                  ; 8-byte Folded Reload
	add	x15, x15, x8
	add	x15, x15, #3
	and	x15, x15, #0xfffffffffffffffc
	str	x8, [sp, #208]
	str	x15, [sp, #240]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, x15
	add	x8, x8, #3
	and	x8, x8, #0xfffffffffffffffc
	ldr	x15, [sp, #16]                  ; 8-byte Folded Reload
	add	x15, x15, x8
	add	x15, x15, #3
	and	x15, x15, #0xfffffffffffffffc
	str	x8, [sp, #272]
	str	x15, [sp, #304]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x8, x15
	add	x8, x8, #3
	and	x8, x8, #0xfffffffffffffffc
	add	x15, x24, x8
	add	x15, x15, #3
	and	x15, x15, #0xfffffffffffffffc
	str	x8, [sp, #336]
	str	x15, [sp, #368]
	add	x8, x25, x15
	add	x8, x8, #3
	and	x8, x8, #0xfffffffffffffffc
	str	x8, [sp, #400]
	add	x19, x26, x8
	cmp	w23, #1
	b.ne	LBB2_30
; %bb.29:
	add	x8, x19, #3
	and	x8, x8, #0xfffffffffffffffc
	str	x8, [sp, #432]
	add	x19, x27, x8
LBB2_30:
	mov	x8, x22
	cbz	w14, LBB2_32
; %bb.31:
	add	x14, x19, #3
	and	x14, x14, #0xfffffffffffffffc
	str	x14, [sp, #464]
	add	x19, x0, x14
LBB2_32:
	cbz	w11, LBB2_34
; %bb.33:
	add	x14, x19, #3
	and	x14, x14, #0xfffffffffffffffc
	str	x14, [sp, #496]
	add	x19, x14, x11
LBB2_34:
	cbz	w12, LBB2_36
; %bb.35:
	add	x11, x19, #3
	and	x11, x11, #0xfffffffffffffffc
	str	x11, [sp, #528]
	add	x19, x11, x12
LBB2_36:
	cbz	w13, LBB2_38
; %bb.37:
	add	x11, x19, #3
	and	x11, x11, #0xfffffffffffffffc
	str	x11, [sp, #560]
	add	x19, x11, x13
LBB2_38:
	cbz	x21, LBB2_40
; %bb.39:
	str	x19, [x21]
LBB2_40:
	cbz	x8, LBB2_69
; %bb.41:
	mov	w0, #1                          ; =0x1
	cmp	x28, x19
	b.lo	LBB2_70
; %bb.42:
	add	w22, w10, #9
	mov	x20, x9
	mov	w23, #1                         ; =0x1
	mov	x0, x8
	mov	x21, x8
	mov	x1, x19
	bl	_bzero
	str	xzr, [sp, #120]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #104]
	stur	q0, [sp, #88]
Lloh31:
	adrp	x8, lCPI2_14@PAGE
Lloh32:
	ldr	d0, [x8, lCPI2_14@PAGEOFF]
	str	s0, [sp, #80]
	strh	w23, [sp, #84]
	ldrh	w8, [x20]
	mov	w9, #2                          ; =0x2
	cmp	w8, #0
	csel	w8, w9, w8, eq
	strh	w8, [sp, #86]
	mov	x0, x20
	bl	_required_features
	ldr	w8, [x20, #240]
	orr	w8, w8, w0
	str	w8, [sp, #88]
	str	x19, [sp, #96]
	mov	w23, #40                        ; =0x28
	stp	w23, w22, [sp, #104]
	mov	x22, x20
	ldr	w8, [x20, #4]
	stp	wzr, wzr, [sp, #116]
	str	w8, [sp, #112]
	add	x1, sp, #80
	mov	x20, x21
	mov	x0, x21
	bl	_nvm_v2_write_header
	add	x21, sp, #128
	mov	w24, #14                        ; =0xe
	b	LBB2_44
LBB2_43:                                ;   in Loop: Header=BB2_44 Depth=1
	add	x21, x21, #32
	subs	x24, x24, #1
	b.eq	LBB2_46
LBB2_44:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x21, #24]
	cmp	w8, #1
	b.ne	LBB2_43
; %bb.45:                               ;   in Loop: Header=BB2_44 Depth=1
	ldr	w8, [x21]
	stp	w8, wzr, [sp, #56]
	ldur	q0, [x21, #8]
	ext.16b	v0, v0, v0, #8
	stur	q0, [sp, #64]
	add	x0, x20, x23
	add	x1, sp, #56
	bl	_nvm_v2_write_section
	add	x23, x23, #24
	b	LBB2_43
LBB2_46:
	add	x8, sp, #128
	add	x21, x8, #16
	mov	w23, #14                        ; =0xe
Lloh33:
	adrp	x24, lJTI2_0@PAGE
Lloh34:
	add	x24, x24, lJTI2_0@PAGEOFF
	mov	x8, x20
	mov	x9, x22
	b	LBB2_51
LBB2_47:                                ;   in Loop: Header=BB2_51 Depth=1
	ldr	x1, [x9, #200]
LBB2_48:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x8, x10
	bl	_memcpy
LBB2_49:                                ;   in Loop: Header=BB2_51 Depth=1
	mov	x9, x22
	mov	x8, x20
LBB2_50:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x21, x21, #32
	subs	x23, x23, #1
	b.eq	LBB2_68
LBB2_51:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x21, #8]
	cmp	w10, #1
	b.ne	LBB2_50
; %bb.52:                               ;   in Loop: Header=BB2_51 Depth=1
	ldur	x2, [x21, #-8]
	cbz	x2, LBB2_50
; %bb.53:                               ;   in Loop: Header=BB2_51 Depth=1
	ldur	w10, [x21, #-16]
	sub	w11, w10, #1
	cmp	w11, #13
	b.hi	LBB2_50
; %bb.54:                               ;   in Loop: Header=BB2_51 Depth=1
	ldr	x10, [x21]
	adr	x12, LBB2_47
	ldrb	w13, [x24, x11]
	add	x12, x12, x13, lsl #2
	br	x12
LBB2_55:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #8
	add	x1, x20, x10
	bl	_nvm_v2_metadata_encode
	b	LBB2_49
LBB2_56:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #72
	add	x1, x20, x10
	bl	_nvm_v2_functions_encode
	b	LBB2_49
LBB2_57:                                ;   in Loop: Header=BB2_51 Depth=1
	ldr	x1, [x9, #184]
	b	LBB2_48
LBB2_58:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #152
	add	x1, x20, x10
	bl	_nvm_v2_debug_encode
	b	LBB2_49
LBB2_59:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #40
	add	x1, x20, x10
	bl	_nvm_v2_signatures_encode
	b	LBB2_49
LBB2_60:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #56
	add	x1, x20, x10
	bl	_nvm_v2_layouts_encode
	b	LBB2_49
LBB2_61:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #104
	add	x1, x20, x10
	bl	_nvm_v2_imports_encode
	b	LBB2_49
LBB2_62:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #24
	add	x1, x20, x10
	bl	_nvm_v2_constants_encode
	b	LBB2_49
LBB2_63:                                ;   in Loop: Header=BB2_51 Depth=1
	ldr	x1, [x9, #168]
	cbnz	x1, LBB2_48
	b	LBB2_50
LBB2_64:                                ;   in Loop: Header=BB2_51 Depth=1
	ldr	x1, [x9, #216]
	b	LBB2_48
LBB2_65:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #88
	add	x1, x20, x10
	bl	_nvm_v2_globals_encode
	b	LBB2_49
LBB2_66:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #120
	add	x1, x20, x10
	bl	_nvm_v2_callbacks_encode
	b	LBB2_49
LBB2_67:                                ;   in Loop: Header=BB2_51 Depth=1
	add	x0, x22, #136
	add	x1, x20, x10
	bl	_nvm_v2_links_encode
	b	LBB2_49
LBB2_68:
	sub	w1, w19, #40
	add	x0, x8, #40
	mov	x19, x8
	bl	_nvm_crc32
	str	w0, [sp, #120]
	add	x1, sp, #80
	mov	x0, x19
	bl	_nvm_v2_write_header
LBB2_69:
	mov	w0, #0                          ; =0x0
LBB2_70:
	ldur	x8, [x29, #-96]
Lloh35:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh36:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh37:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_72
; %bb.71:
	add	sp, sp, #592
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB2_72:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdr	Lloh29, Lloh30
	.loh AdrpLdr	Lloh27, Lloh28
	.loh AdrpLdr	Lloh25, Lloh26
	.loh AdrpLdr	Lloh23, Lloh24
	.loh AdrpLdr	Lloh21, Lloh22
	.loh AdrpLdr	Lloh19, Lloh20
	.loh AdrpLdr	Lloh17, Lloh18
	.loh AdrpLdr	Lloh15, Lloh16
	.loh AdrpLdr	Lloh13, Lloh14
	.loh AdrpAdrp	Lloh11, Lloh13
	.loh AdrpLdr	Lloh11, Lloh12
	.loh AdrpLdr	Lloh9, Lloh10
	.loh AdrpLdr	Lloh7, Lloh8
	.loh AdrpLdr	Lloh5, Lloh6
	.loh AdrpLdr	Lloh3, Lloh4
	.loh AdrpLdr	Lloh31, Lloh32
	.loh AdrpAdd	Lloh33, Lloh34
	.loh AdrpLdrGotLdr	Lloh35, Lloh36, Lloh37
	.cfi_endproc
	.section	__TEXT,__const
lJTI2_0:
	.byte	(LBB2_55-LBB2_47)>>2
	.byte	(LBB2_62-LBB2_47)>>2
	.byte	(LBB2_59-LBB2_47)>>2
	.byte	(LBB2_60-LBB2_47)>>2
	.byte	(LBB2_56-LBB2_47)>>2
	.byte	(LBB2_63-LBB2_47)>>2
	.byte	(LBB2_65-LBB2_47)>>2
	.byte	(LBB2_61-LBB2_47)>>2
	.byte	(LBB2_67-LBB2_47)>>2
	.byte	(LBB2_58-LBB2_47)>>2
	.byte	(LBB2_66-LBB2_47)>>2
	.byte	(LBB2_47-LBB2_47)>>2
	.byte	(LBB2_57-LBB2_47)>>2
	.byte	(LBB2_64-LBB2_47)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_private_deserialize ; -- Begin function nvm_private_deserialize
	.globl	_nvm_private_deserialize
	.p2align	2
_nvm_private_deserialize:               ; @nvm_private_deserialize
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #560
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x3
	mov	x19, x2
	mov	x21, x1
	mov	x22, x0
	sub	x2, x29, #96
	bl	_nvm_v2_read_header
	cbz	w0, LBB3_3
LBB3_1:
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, x20
	bl	_nvm_deserialize_core
LBB3_2:
	add	sp, sp, #560
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB3_3:
	ldur	w8, [x29, #-68]
	cbz	w8, LBB3_1
; %bb.4:
	mov	w23, #0                         ; =0x0
	b	LBB3_8
LBB3_5:                                 ;   in Loop: Header=BB3_8 Depth=1
	add	x9, x22, x9
	str	x9, [sp, #296]
	str	w8, [sp, #304]
LBB3_6:                                 ;   in Loop: Header=BB3_8 Depth=1
	mov	x0, sp
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #3
	b.lo	LBB3_15
LBB3_7:                                 ;   in Loop: Header=BB3_8 Depth=1
	add	w23, w23, #1
	ldur	w8, [x29, #-68]
	cmp	w23, w8
	b.hs	LBB3_1
LBB3_8:                                 ; =>This Inner Loop Header: Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #448]
	stp	q0, q0, [sp, #416]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #320]
	stp	q0, q0, [sp, #288]
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	sub	x2, x29, #96
	sub	x4, x29, #120
	mov	x0, x22
	mov	x1, x21
	mov	x3, x23
	bl	_nvm_v2_read_section
	cbnz	w0, LBB3_1
; %bb.9:                                ;   in Loop: Header=BB3_8 Depth=1
	ldur	x9, [x29, #-112]
	subs	x10, x21, x9
	b.lo	LBB3_7
; %bb.10:                               ;   in Loop: Header=BB3_8 Depth=1
	ldur	x8, [x29, #-104]
	cmp	x8, x10
	b.hi	LBB3_7
; %bb.11:                               ;   in Loop: Header=BB3_8 Depth=1
	lsr	x10, x8, #32
	cbnz	x10, LBB3_7
; %bb.12:                               ;   in Loop: Header=BB3_8 Depth=1
	ldur	w10, [x29, #-120]
	cmp	w10, #13
	b.eq	LBB3_5
; %bb.13:                               ;   in Loop: Header=BB3_8 Depth=1
	cmp	w10, #4
	b.ne	LBB3_6
; %bb.14:                               ;   in Loop: Header=BB3_8 Depth=1
	add	x9, x22, x9
	str	x9, [sp, #312]
	str	w8, [sp, #320]
	b	LBB3_6
LBB3_15:
	cbz	x19, LBB3_18
; %bb.16:
	str	xzr, [sp, #240]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #208]
	stp	q0, q0, [sp, #176]
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	mov	x2, sp
	mov	x0, x22
	mov	x1, x21
	mov	x3, x20
	bl	_nvm_deserialize_core
	cbz	w0, LBB3_19
; %bb.17:
	mov	x19, x0
	mov	x0, sp
	bl	_nvm_v2_module_free
	mov	x0, x19
	b	LBB3_2
LBB3_18:
	mov	w0, #13                         ; =0xd
	b	LBB3_2
LBB3_19:
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x19, #192]
	ldr	q0, [sp, #224]
	str	q0, [x19, #224]
	ldr	x8, [sp, #240]
	str	x8, [x19, #240]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x19, #128]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x19, #160]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x19, #96]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x19, #32]
	b	LBB3_2
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_deserialize_core
_nvm_deserialize_core:                  ; @nvm_deserialize_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #576
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x19, x2
	mov	x21, x1
	mov	x22, x0
	str	xzr, [x2, #240]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x2, #208]
	stp	q0, q0, [x2, #176]
	stp	q0, q0, [x2, #144]
	stp	q0, q0, [x2, #112]
	stp	q0, q0, [x2, #80]
	stp	q0, q0, [x2, #48]
	stp	q0, q0, [x2, #16]
	str	q0, [x2]
	bl	_nvm_v2_validate
	cbnz	w0, LBB4_55
; %bb.1:
	sub	x2, x29, #144
	mov	x0, x22
	mov	x1, x21
	bl	_nvm_v2_read_header
	cbnz	w0, LBB4_55
; %bb.2:
	ldurh	w8, [x29, #-138]
	strh	w8, [x19]
	ldp	w9, w8, [x29, #-116]
	str	w8, [x19, #4]
	ldur	w8, [x29, #-136]
	str	w8, [x19, #240]
	add	x8, sp, #32
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #448]
	stp	q0, q0, [x8, #416]
	stp	q0, q0, [x8, #384]
	stp	q0, q0, [x8, #352]
	stp	q0, q0, [x8, #320]
	stp	q0, q0, [x8, #288]
	stp	q0, q0, [x8, #256]
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	str	q0, [x8, #112]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	str	q0, [sp, #32]
	cbz	w9, LBB4_13
; %bb.3:
	mov	w23, #0                         ; =0x0
	b	LBB4_6
LBB4_4:                                 ;   in Loop: Header=BB4_6 Depth=1
	ldr	x9, [sp, #16]
	add	x9, x22, x9
	str	x9, [sp, #328]
	str	w8, [sp, #336]
LBB4_5:                                 ;   in Loop: Header=BB4_6 Depth=1
	add	w23, w23, #1
	ldur	w8, [x29, #-116]
	cmp	w23, w8
	b.hs	LBB4_13
LBB4_6:                                 ; =>This Inner Loop Header: Depth=1
	sub	x2, x29, #144
	add	x4, sp, #8
	mov	x0, x22
	mov	x1, x21
	mov	x3, x23
	bl	_nvm_v2_read_section
	cbnz	w0, LBB4_53
; %bb.7:                                ;   in Loop: Header=BB4_6 Depth=1
	ldr	x8, [sp, #24]
	lsr	x9, x8, #32
	cbnz	x9, LBB4_5
; %bb.8:                                ;   in Loop: Header=BB4_6 Depth=1
	ldr	w9, [sp, #8]
	cmp	w9, #14
	b.eq	LBB4_12
; %bb.9:                                ;   in Loop: Header=BB4_6 Depth=1
	cmp	w9, #13
	b.eq	LBB4_4
; %bb.10:                               ;   in Loop: Header=BB4_6 Depth=1
	cmp	w9, #4
	b.ne	LBB4_5
; %bb.11:                               ;   in Loop: Header=BB4_6 Depth=1
	ldr	x9, [sp, #16]
	add	x9, x22, x9
	str	x9, [sp, #344]
	str	w8, [sp, #352]
	b	LBB4_5
LBB4_12:                                ;   in Loop: Header=BB4_6 Depth=1
	ldr	x9, [sp, #16]
	add	x9, x22, x9
	str	x9, [sp, #360]
	str	w8, [sp, #368]
	b	LBB4_5
LBB4_13:
	add	x0, sp, #32
	bl	_nvm_record_array_candidate
	mov	x23, x0
	add	x0, sp, #32
	bl	_nvm_record_map_route
	and	w8, w0, #0xfffffffe
	cmp	w8, #2
	b.ne	LBB4_15
; %bb.14:
	mov	w20, #13                        ; =0xd
	b	LBB4_54
LBB4_15:
	ldur	w8, [x29, #-116]
	cbz	w8, LBB4_52
; %bb.16:
	mov	x24, x0
	mov	w25, #0                         ; =0x0
	mov	x27, #-4294967296               ; =0xffffffff00000000
	mov	x28, #-4294967295               ; =0xffffffff00000001
Lloh38:
	adrp	x26, lJTI4_0@PAGE
Lloh39:
	add	x26, x26, lJTI4_0@PAGEOFF
	b	LBB4_19
LBB4_17:                                ;   in Loop: Header=BB4_19 Depth=1
	cmp	x1, #0
	csel	x8, xzr, x0, eq
	stp	x8, x1, [x19, #168]
LBB4_18:                                ;   in Loop: Header=BB4_19 Depth=1
	add	w25, w25, #1
	ldur	w8, [x29, #-116]
	cmp	w25, w8
	b.hs	LBB4_52
LBB4_19:                                ; =>This Inner Loop Header: Depth=1
	sub	x2, x29, #144
	add	x4, sp, #8
	mov	x0, x22
	mov	x1, x21
	mov	x3, x25
	bl	_nvm_v2_read_section
	cbnz	w0, LBB4_50
; %bb.20:                               ;   in Loop: Header=BB4_19 Depth=1
	ldr	w8, [sp, #8]
	sub	w8, w8, #1
	cmp	w8, #13
	b.hi	LBB4_64
; %bb.21:                               ;   in Loop: Header=BB4_19 Depth=1
	ldp	x9, x1, [sp, #16]
	add	x0, x22, x9
	adr	x9, LBB4_17
	ldrb	w10, [x26, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB4_22:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #8
	bl	_nvm_v2_metadata_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_23:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x8, x1, x27
	cmp	x8, x28
	b.lo	LBB4_63
; %bb.24:                               ;   in Loop: Header=BB4_19 Depth=1
	str	x0, [x19, #200]
	str	w1, [x19, #208]
	b	LBB4_18
LBB4_25:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #72
	bl	_nvm_v2_functions_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_26:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x8, x1, x27
	cmp	x8, x28
	b.lo	LBB4_63
; %bb.27:                               ;   in Loop: Header=BB4_19 Depth=1
	str	x0, [x19, #184]
	str	w1, [x19, #192]
	b	LBB4_18
LBB4_28:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #152
	bl	_nvm_v2_debug_decode
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #228]
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_29:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #40
	bl	_nvm_v2_signatures_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_30:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #56
	cmp	w24, #1
	b.ne	LBB4_41
; %bb.31:                               ;   in Loop: Header=BB4_19 Depth=1
	mov	x3, #0                          ; =0x0
	bl	_nvm_ownership_map_layouts_private_decode_detailed
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_32:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #104
	bl	_nvm_v2_imports_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_33:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #24
	bl	_nvm_v2_constants_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_34:                                ;   in Loop: Header=BB4_19 Depth=1
	cbz	x20, LBB4_43
; %bb.35:                               ;   in Loop: Header=BB4_19 Depth=1
	ldr	w9, [x20, #16]
	mov	w8, #9                          ; =0x9
	cbz	w9, LBB4_51
; %bb.36:                               ;   in Loop: Header=BB4_19 Depth=1
	cmp	x1, x9
	b.ne	LBB4_51
LBB4_37:                                ;   in Loop: Header=BB4_19 Depth=1
	str	x0, [x19, #216]
	str	w1, [x19, #224]
	b	LBB4_18
LBB4_38:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #88
	bl	_nvm_v2_globals_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_39:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #120
	bl	_nvm_v2_callbacks_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_40:                                ;   in Loop: Header=BB4_19 Depth=1
	add	x2, x19, #136
	bl	_nvm_v2_links_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_41:                                ;   in Loop: Header=BB4_19 Depth=1
	cbz	w23, LBB4_49
; %bb.42:                               ;   in Loop: Header=BB4_19 Depth=1
	bl	_nvm_ownership_layouts_private_decode
	cbz	w0, LBB4_18
	b	LBB4_50
LBB4_43:                                ;   in Loop: Header=BB4_19 Depth=1
	cmp	x1, #56
	b.eq	LBB4_37
; %bb.44:                               ;   in Loop: Header=BB4_19 Depth=1
	cmp	x1, #120
	b.eq	LBB4_37
; %bb.45:                               ;   in Loop: Header=BB4_19 Depth=1
	cmp	x1, #128
	b.eq	LBB4_37
; %bb.46:                               ;   in Loop: Header=BB4_19 Depth=1
	sub	x8, x1, #80
	cmp	x8, #4032
	b.hi	LBB4_63
; %bb.47:                               ;   in Loop: Header=BB4_19 Depth=1
	ldrb	w8, [x0]
	cmp	w8, #3
	b.ne	LBB4_63
; %bb.48:                               ;   in Loop: Header=BB4_19 Depth=1
	ldrb	w8, [x0, #1]
	cbz	w8, LBB4_37
	b	LBB4_63
LBB4_49:                                ;   in Loop: Header=BB4_19 Depth=1
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB4_18
LBB4_50:
	mov	x8, x0
LBB4_51:
	mov	x20, x8
	b	LBB4_54
LBB4_52:
	ldur	w1, [x29, #-136]
	mov	x0, x19
	mov	x2, x20
	bl	_validate_cross_section
	cbz	w0, LBB4_56
LBB4_53:
	mov	x20, x0
LBB4_54:
	mov	x0, x19
	bl	_nvm_v2_module_free
	mov	x0, x20
LBB4_55:
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB4_56:
	ldur	w9, [x29, #-136]
	ldr	w8, [x19, #208]
	cmp	w8, #0
	cset	w10, ne
	tst	w9, #0x40
	cset	w11, eq
	cmp	w10, w11
	b.eq	LBB4_62
; %bb.57:
	ldr	w10, [x19, #192]
	cmp	w10, #0
	cset	w11, ne
	tst	w9, #0x100
	cset	w9, eq
	cmp	w9, w11
	b.eq	LBB4_62
; %bb.58:
	orr	w8, w10, w8
	cbnz	w8, LBB4_60
; %bb.59:
	ldr	w8, [x19, #224]
	cbz	w8, LBB4_61
LBB4_60:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x0, x19
	mov	x2, x20
	bl	_nvm_private_to_module
	mov	x20, x0
	ldr	x0, [sp, #8]
	bl	_nvm_module_free
	cbnz	w20, LBB4_54
LBB4_61:
	mov	w0, #0                          ; =0x0
	b	LBB4_55
LBB4_62:
	mov	w20, #14                        ; =0xe
	b	LBB4_54
LBB4_63:
	mov	w20, #9                         ; =0x9
	b	LBB4_54
LBB4_64:
	mov	w20, #8                         ; =0x8
	b	LBB4_54
	.loh AdrpAdd	Lloh38, Lloh39
	.cfi_endproc
	.section	__TEXT,__const
lJTI4_0:
	.byte	(LBB4_22-LBB4_17)>>2
	.byte	(LBB4_33-LBB4_17)>>2
	.byte	(LBB4_29-LBB4_17)>>2
	.byte	(LBB4_30-LBB4_17)>>2
	.byte	(LBB4_25-LBB4_17)>>2
	.byte	(LBB4_17-LBB4_17)>>2
	.byte	(LBB4_38-LBB4_17)>>2
	.byte	(LBB4_32-LBB4_17)>>2
	.byte	(LBB4_40-LBB4_17)>>2
	.byte	(LBB4_28-LBB4_17)>>2
	.byte	(LBB4_39-LBB4_17)>>2
	.byte	(LBB4_23-LBB4_17)>>2
	.byte	(LBB4_26-LBB4_17)>>2
	.byte	(LBB4_34-LBB4_17)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_module_serialize ; -- Begin function nvm_v2_module_serialize
	.globl	_nvm_v2_module_serialize
	.p2align	2
_nvm_v2_module_serialize:               ; @nvm_v2_module_serialize
	.cfi_startproc
; %bb.0:
	mov	x4, #0                          ; =0x0
	b	_nvm_private_serialize
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_module_deserialize ; -- Begin function nvm_v2_module_deserialize
	.globl	_nvm_v2_module_deserialize
	.p2align	2
_nvm_v2_module_deserialize:             ; @nvm_v2_module_deserialize
	.cfi_startproc
; %bb.0:
	mov	x3, #0                          ; =0x0
	b	_nvm_private_deserialize
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function validate_cross_section
lCPI7_0:
	.long	16                              ; 0x10
	.long	32                              ; 0x20
	.long	64                              ; 0x40
	.long	128                             ; 0x80
lCPI7_1:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	8                               ; 0x8
lCPI7_2:
	.long	256                             ; 0x100
	.long	512                             ; 0x200
	.long	1024                            ; 0x400
	.long	2048                            ; 0x800
lCPI7_3:
	.long	4096                            ; 0x1000
	.long	8192                            ; 0x2000
	.long	16384                           ; 0x4000
	.long	32768                           ; 0x8000
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_validate_cross_section:                ; @validate_cross_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	d9, d8, [sp, #112]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x19, x1
	mov	x20, x0
	cbz	x2, LBB7_5
; %bb.1:
	ldr	x8, [x2]
	cbz	x8, LBB7_33
; %bb.2:
	ldr	x8, [x2, #8]
	cbz	x8, LBB7_33
; %bb.3:
	ldr	w9, [x2, #16]
	cbz	w9, LBB7_33
; %bb.4:
	mov	x0, x20
	blr	x8
	cbnz	w0, LBB7_34
	b	LBB7_6
LBB7_5:
	mov	x0, x20
	bl	_nvm_v2_service_bindings_validate
	cbnz	w0, LBB7_34
LBB7_6:
	ldr	w8, [x20, #224]
	cmp	w8, #0
	cset	w8, ne
	tst	w19, #0x200
	cset	w9, eq
	cmp	w9, w8
	b.eq	LBB7_21
; %bb.7:
	ldr	w21, [x20, #32]
	ldr	w23, [x20, #48]
	ldr	w25, [x20, #64]
	ldr	w8, [x20, #80]
	cbz	w8, LBB7_14
; %bb.8:
	ldr	x9, [x20, #72]
	add	x9, x9, #8
LBB7_9:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-8]
	cmp	w10, w21
	b.hs	LBB7_95
; %bb.10:                               ;   in Loop: Header=BB7_9 Depth=1
	ldur	w10, [x9, #-4]
	cmp	w10, w23
	b.hs	LBB7_95
; %bb.11:                               ;   in Loop: Header=BB7_9 Depth=1
	ldr	x10, [x9]
	ldr	x11, [x20, #176]
	subs	x10, x11, x10
	b.lo	LBB7_95
; %bb.12:                               ;   in Loop: Header=BB7_9 Depth=1
	ldr	x11, [x9, #8]
	cmp	x11, x10
	b.hi	LBB7_95
; %bb.13:                               ;   in Loop: Header=BB7_9 Depth=1
	add	x9, x9, #32
	subs	x8, x8, #1
	b.ne	LBB7_9
LBB7_14:
	ldr	w8, [x20, #96]
	cbz	w8, LBB7_19
; %bb.15:
	ldr	x9, [x20, #88]
	add	x9, x9, #8
LBB7_16:                                ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-8]
	cmp	w10, w21
	b.hs	LBB7_95
; %bb.17:                               ;   in Loop: Header=BB7_16 Depth=1
	ldr	w10, [x9], #12
	cmp	w10, w21
	ccmn	w10, #1, #4, hs
	b.ne	LBB7_95
; %bb.18:                               ;   in Loop: Header=BB7_16 Depth=1
	subs	x8, x8, #1
	b.ne	LBB7_16
LBB7_19:
	ldr	w22, [x20, #112]
	cbz	w22, LBB7_35
; %bb.20:
	ldr	x8, [x20, #104]
	add	x24, x8, #8
	b	LBB7_23
LBB7_21:
	mov	w0, #14                         ; =0xe
	b	LBB7_34
LBB7_22:                                ;   in Loop: Header=BB7_23 Depth=1
	add	x24, x24, #16
	subs	x22, x22, #1
	b.eq	LBB7_35
LBB7_23:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x24, #4]
	cmp	w9, #3
	b.hi	LBB7_33
; %bb.24:                               ;   in Loop: Header=BB7_23 Depth=1
	ldur	w8, [x24, #-8]
	cmp	w8, w21
	b.hs	LBB7_95
; %bb.25:                               ;   in Loop: Header=BB7_23 Depth=1
	ldur	w10, [x24, #-4]
	cmp	w10, w21
	b.hs	LBB7_95
; %bb.26:                               ;   in Loop: Header=BB7_23 Depth=1
	ldr	w10, [x24]
	cmp	w10, w23
	b.hs	LBB7_95
; %bb.27:                               ;   in Loop: Header=BB7_23 Depth=1
	cmp	w9, #2
	b.ne	LBB7_22
; %bb.28:                               ;   in Loop: Header=BB7_23 Depth=1
	ldr	x9, [x20, #24]
	add	x8, x9, x8, lsl #4
	ldrb	w9, [x8]
	cmp	w9, #5
	b.ne	LBB7_33
; %bb.29:                               ;   in Loop: Header=BB7_23 Depth=1
	ldr	w2, [x8, #4]
	cbz	w2, LBB7_33
; %bb.30:                               ;   in Loop: Header=BB7_23 Depth=1
	ldr	x0, [x8, #8]
	cbz	x0, LBB7_33
; %bb.31:                               ;   in Loop: Header=BB7_23 Depth=1
	ldrb	w8, [x0]
	cmp	w8, #47
	b.ne	LBB7_33
; %bb.32:                               ;   in Loop: Header=BB7_23 Depth=1
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB7_22
LBB7_33:
	mov	w0, #8                          ; =0x8
LBB7_34:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #112]              ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB7_35:
	stp	w23, w25, [sp, #8]              ; 8-byte Folded Spill
	mov	x8, #0                          ; =0x0
Lloh40:
	adrp	x9, lCPI7_2@PAGE
Lloh41:
	ldr	q0, [x9, lCPI7_2@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
Lloh42:
	adrp	x9, lCPI7_1@PAGE
Lloh43:
	ldr	q0, [x9, lCPI7_1@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Folded Spill
Lloh44:
	adrp	x9, lCPI7_3@PAGE
Lloh45:
	ldr	q0, [x9, lCPI7_3@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh46:
	adrp	x9, lCPI7_0@PAGE
Lloh47:
	ldr	q0, [x9, lCPI7_0@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	ldr	w28, [x20, #128]
	movi.8b	v8, #251
	movi.8b	v9, #11
LBB7_36:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_42 Depth 2
                                        ;     Child Loop BB7_50 Depth 2
	cmp	x8, x28
	b.hs	LBB7_73
; %bb.37:                               ;   in Loop: Header=BB7_36 Depth=1
	ldr	x9, [x20, #120]
	add	x15, x9, x8, lsl #4
	ldr	w9, [x15]
	ldr	w10, [x20, #112]
	cmp	w9, w10
	b.hs	LBB7_95
; %bb.38:                               ;   in Loop: Header=BB7_36 Depth=1
	ldr	x10, [x20, #40]
	ldr	x11, [x20, #104]
	add	x9, x11, x9, lsl #4
	ldr	w9, [x9, #8]
	mov	w11, #24                        ; =0x18
	umaddl	x9, w9, w11, x10
	str	x9, [sp, #88]                   ; 8-byte Folded Spill
	ldrh	w9, [x9]
	cmp	w9, #16
	b.hi	LBB7_95
; %bb.39:                               ;   in Loop: Header=BB7_36 Depth=1
	cbz	w9, LBB7_43
; %bb.40:                               ;   in Loop: Header=BB7_36 Depth=1
	ldr	x10, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x10, [x10, #8]
	cmp	w9, #7
	mov	w14, #1                         ; =0x1
	b.hi	LBB7_44
; %bb.41:                               ;   in Loop: Header=BB7_36 Depth=1
	mov	x11, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
LBB7_42:                                ;   Parent Loop BB7_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w12, [x10, x11]
	orr	w12, w12, #0x4
	lsl	w13, w14, w11
	orr	w13, w13, w25
	cmp	w12, #15
	csel	w25, w13, w25, eq
	add	x11, x11, #1
	cmp	x9, x11
	b.ne	LBB7_42
	b	LBB7_49
LBB7_43:                                ;   in Loop: Header=BB7_36 Depth=1
	mov	w25, #0                         ; =0x0
	b	LBB7_49
LBB7_44:                                ;   in Loop: Header=BB7_36 Depth=1
	cmp	w9, #16
	b.ne	LBB7_46
; %bb.45:                               ;   in Loop: Header=BB7_36 Depth=1
	ldr	q0, [x10]
	movi.16b	v1, #251
	and.16b	v0, v0, v1
	movi.16b	v1, #11
	cmeq.16b	v0, v0, v1
	sshll.8h	v1, v0, #0
	ushll2.4s	v2, v1, #0
	sshll2.8h	v0, v0, #0
	ushll2.4s	v3, v0, #0
	ushll.4s	v1, v1, #0
	ushll.4s	v0, v0, #0
	ldr	q4, [sp, #32]                   ; 16-byte Folded Reload
	and.16b	v0, v0, v4
	ldr	q4, [sp, #64]                   ; 16-byte Folded Reload
	and.16b	v1, v1, v4
	ldr	q4, [sp, #16]                   ; 16-byte Folded Reload
	and.16b	v3, v3, v4
	ldr	q4, [sp, #48]                   ; 16-byte Folded Reload
	and.16b	v2, v2, v4
	orr.16b	v2, v2, v3
	orr.16b	v0, v1, v0
	orr.16b	v0, v0, v2
	ext.16b	v1, v0, v0, #8
	orr.8b	v0, v0, v1
	fmov	x9, d0
	lsr	x10, x9, #32
	orr	w25, w9, w10
	b	LBB7_49
LBB7_46:                                ;   in Loop: Header=BB7_36 Depth=1
	and	x11, x9, #0x18
	ldr	d0, [x10]
	and.8b	v0, v0, v8
	cmeq.8b	v0, v0, v9
	sshll.8h	v0, v0, #0
	sshll.4s	v1, v0, #0
	sshll2.4s	v0, v0, #0
	ldp	q3, q2, [sp, #48]               ; 32-byte Folded Reload
	and.16b	v0, v0, v3
	and.16b	v1, v1, v2
	cmp	x11, #8
	b.eq	LBB7_48
; %bb.47:                               ;   in Loop: Header=BB7_36 Depth=1
	ldr	d2, [x10, #8]
	and.8b	v2, v2, v8
	cmeq.8b	v2, v2, v9
	sshll.8h	v2, v2, #0
	sshll2.4s	v3, v2, #0
	sshll.4s	v2, v2, #0
	ldp	q4, q5, [sp, #16]               ; 32-byte Folded Reload
	and.16b	v2, v2, v5
	and.16b	v3, v3, v4
	orr.16b	v0, v0, v3
	orr.16b	v1, v1, v2
LBB7_48:                                ;   in Loop: Header=BB7_36 Depth=1
	orr.16b	v0, v1, v0
	ext.16b	v1, v0, v0, #8
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x13, x12, #32
	orr	w25, w12, w13
	cmp	x11, x9
	b.ne	LBB7_42
LBB7_49:                                ;   in Loop: Header=BB7_36 Depth=1
	mov	x23, #0                         ; =0x0
	str	wzr, [sp, #100]                 ; 4-byte Folded Spill
	add	x9, x8, #1
	lsl	x8, x8, #4
	add	x24, x8, #16
	mov	x27, x15
LBB7_50:                                ;   Parent Loop BB7_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w26, [x27, #12]
	ldr	w8, [x20, #32]
	cmp	w26, w8
	b.hs	LBB7_95
; %bb.51:                               ;   in Loop: Header=BB7_50 Depth=2
	mov	x10, x9
	ldr	x8, [x20, #24]
	add	x8, x8, x26, lsl #4
	ldrb	w9, [x8]
	cmp	w9, #5
	b.ne	LBB7_33
; %bb.52:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	w2, [x8, #4]
	cbz	w2, LBB7_33
; %bb.53:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	x0, [x8, #8]
	cbz	x0, LBB7_33
; %bb.54:                               ;   in Loop: Header=BB7_50 Depth=2
	str	x10, [sp, #104]                 ; 8-byte Folded Spill
	mov	x22, x15
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB7_33
; %bb.55:                               ;   in Loop: Header=BB7_50 Depth=2
	ldrb	w8, [x27, #7]
	ldrb	w9, [x22, #7]
	cmp	w8, w9
	b.ne	LBB7_33
; %bb.56:                               ;   in Loop: Header=BB7_50 Depth=2
	mov	x15, x22
	ldr	w8, [x22, #12]
	cmp	w26, w8
	b.ne	LBB7_33
; %bb.57:                               ;   in Loop: Header=BB7_50 Depth=2
	ldrh	w8, [x27, #4]
	mov	w9, #65535                      ; =0xffff
	cmp	w8, w9
	b.ne	LBB7_61
; %bb.58:                               ;   in Loop: Header=BB7_50 Depth=2
	mov	w0, #13                         ; =0xd
	cbnz	w25, LBB7_34
; %bb.59:                               ;   in Loop: Header=BB7_50 Depth=2
	cbnz	x23, LBB7_34
; %bb.60:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	w8, [x27, #8]
	cmn	w8, #1
	b.eq	LBB7_70
	b	LBB7_34
LBB7_61:                                ;   in Loop: Header=BB7_50 Depth=2
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldrh	w9, [x9]
	cmp	w8, w9
	b.hs	LBB7_95
; %bb.62:                               ;   in Loop: Header=BB7_50 Depth=2
	lsr	w8, w25, w8
	tbz	w8, #0, LBB7_95
; %bb.63:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	w8, [x27, #8]
	ldr	w9, [x20, #48]
	cmp	w8, w9
	b.hs	LBB7_95
; %bb.64:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	x9, [x20, #40]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w8, w10, x9
	ldrh	w9, [x8, #2]
	cmp	w9, #1
	b.hi	LBB7_33
; %bb.65:                               ;   in Loop: Header=BB7_50 Depth=2
	cbz	w9, LBB7_67
; %bb.66:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	x9, [x8, #16]
	ldrb	w2, [x9]
	cbnz	w2, LBB7_68
	b	LBB7_33
LBB7_67:                                ;   in Loop: Header=BB7_50 Depth=2
	mov	w2, #0                          ; =0x0
LBB7_68:                                ;   in Loop: Header=BB7_50 Depth=2
	ldr	x0, [x8, #8]
	ldrh	w1, [x8]
	bl	_nvm_callback_shape_valid
	cbz	w0, LBB7_33
; %bb.69:                               ;   in Loop: Header=BB7_50 Depth=2
	ldrh	w8, [x27, #4]
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	ldr	w9, [sp, #100]                  ; 4-byte Folded Reload
	orr	w9, w8, w9
	str	w9, [sp, #100]                  ; 4-byte Folded Spill
	ldr	w28, [x20, #128]
	mov	x15, x22
LBB7_70:                                ;   in Loop: Header=BB7_50 Depth=2
	ldr	x11, [sp, #104]                 ; 8-byte Folded Reload
	cmp	x11, x28
	b.hs	LBB7_72
; %bb.71:                               ;   in Loop: Header=BB7_50 Depth=2
	ldr	x8, [x20, #120]
	add	x27, x8, x24
	ldr	w8, [x27]
	ldr	w10, [x15]
	sub	x23, x23, #16
	add	x9, x11, #1
	add	x24, x24, #16
	cmp	w8, w10
	b.eq	LBB7_50
LBB7_72:                                ;   in Loop: Header=BB7_36 Depth=1
	mov	w8, w11
	mov	w0, #13                         ; =0xd
	ldr	w9, [sp, #100]                  ; 4-byte Folded Reload
	cmp	w25, w9
	b.eq	LBB7_36
	b	LBB7_34
LBB7_73:
	ldr	w8, [x20, #144]
	ldp	w11, w15, [sp, #8]              ; 8-byte Folded Reload
	cbz	w8, LBB7_79
; %bb.74:
	ldr	x9, [x20, #136]
	add	x9, x9, #8
LBB7_75:                                ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-8]
	cmp	w10, w21
	b.hs	LBB7_95
; %bb.76:                               ;   in Loop: Header=BB7_75 Depth=1
	ldur	w10, [x9, #-4]
	cmp	w10, w21
	ccmn	w10, #1, #4, hs
	b.ne	LBB7_95
; %bb.77:                               ;   in Loop: Header=BB7_75 Depth=1
	ldr	w10, [x9], #16
	cmp	w10, w11
	ccmn	w10, #1, #4, hs
	b.ne	LBB7_95
; %bb.78:                               ;   in Loop: Header=BB7_75 Depth=1
	subs	x8, x8, #1
	b.ne	LBB7_75
LBB7_79:
	ldr	w8, [x20, #64]
	cbz	w8, LBB7_88
; %bb.80:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20, #56]
	b	LBB7_82
LBB7_81:                                ;   in Loop: Header=BB7_82 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB7_88
LBB7_82:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_85 Depth 2
	add	x12, x10, x9, lsl #4
	ldr	w11, [x12, #4]
	cmp	w11, w21
	ccmn	w11, #1, #4, hs
	b.ne	LBB7_95
; %bb.83:                               ;   in Loop: Header=BB7_82 Depth=1
	ldrh	w11, [x12, #2]
	cbz	x11, LBB7_81
; %bb.84:                               ;   in Loop: Header=BB7_82 Depth=1
	ldr	x12, [x12, #8]
	add	x13, x12, #8
	mov	x12, x13
LBB7_85:                                ;   Parent Loop BB7_82 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w14, [x12], #12
	cmp	w14, w21
	ccmn	w14, #1, #4, hs
	b.ne	LBB7_95
; %bb.86:                               ;   in Loop: Header=BB7_85 Depth=2
	ldur	w13, [x13, #-4]
	cmp	w13, w15
	ccmn	w13, #1, #4, hs
	b.ne	LBB7_95
; %bb.87:                               ;   in Loop: Header=BB7_85 Depth=2
	mov	x13, x12
	subs	x11, x11, #1
	b.ne	LBB7_85
	b	LBB7_81
LBB7_88:
	ldr	w8, [x20, #16]
	cbz	w8, LBB7_93
; %bb.89:
	ldr	x9, [x20, #8]
	add	x9, x9, #4
LBB7_90:                                ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-4]
	cmp	w10, w21
	b.hs	LBB7_95
; %bb.91:                               ;   in Loop: Header=BB7_90 Depth=1
	ldr	w10, [x9], #8
	cmp	w10, w21
	b.hs	LBB7_95
; %bb.92:                               ;   in Loop: Header=BB7_90 Depth=1
	subs	x8, x8, #1
	b.ne	LBB7_90
LBB7_93:
	ldr	w8, [x20, #4]
	cmn	w8, #1
	b.eq	LBB7_96
; %bb.94:
	ldr	w9, [x20, #80]
	cmp	w8, w9
	b.lo	LBB7_96
LBB7_95:
	mov	w0, #13                         ; =0xd
	b	LBB7_34
LBB7_96:
	mov	x0, x20
	bl	_required_features
	ldr	w8, [x20, #128]
	cmp	w8, #0
	cset	w8, ne
	tst	w19, #0x20
	cset	w9, eq
	eor	w8, w9, w8
	bics	wzr, w0, w19
	cset	w9, eq
	tst	w8, w9
	mov	w8, #14                         ; =0xe
	csel	w0, wzr, w8, ne
	b	LBB7_34
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function required_features
_required_features:                     ; @required_features
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	w8, [x0, #144]
	cmp	w8, #0
	cset	w8, ne
	ldr	w9, [x0, #112]
	mov	w10, #2                         ; =0x2
	cinc	w10, w10, ne
	cmp	w9, #0
	csel	w8, w8, w10, eq
	ldr	w9, [x0, #128]
	orr	w10, w8, #0x20
	cmp	w9, #0
	csel	w8, w8, w10, eq
	ldr	w9, [x0, #208]
	orr	w10, w8, #0x40
	cmp	w9, #0
	csel	w8, w8, w10, eq
	ldr	w9, [x0, #192]
	orr	w10, w8, #0x100
	cmp	w9, #0
	csel	w8, w8, w10, eq
	ldr	w9, [x0, #224]
	orr	w10, w8, #0x200
	cmp	w9, #0
	csel	w20, w8, w10, eq
	add	x0, x0, #56
	bl	_nvm_layouts_have_facts
	orr	w8, w20, #0x80
	cmp	w0, #0
	csel	w8, w8, w20, ne
	ldrb	w9, [x19, #228]
	orr	w0, w8, w9, lsl #3
	ldr	w8, [x19, #112]
	cbz	w8, LBB8_3
; %bb.1:
	ldr	x9, [x19, #104]
	add	x9, x9, #12
LBB8_2:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #16
	orr	w11, w0, #0x4
	cmp	w10, #1
	csel	w0, w11, w0, eq
	subs	x8, x8, #1
	b.ne	LBB8_2
LBB8_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
