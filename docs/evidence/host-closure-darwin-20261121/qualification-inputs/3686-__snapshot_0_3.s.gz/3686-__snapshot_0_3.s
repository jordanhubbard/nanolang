	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_cJSON_GetErrorPtr              ; -- Begin function cJSON_GetErrorPtr
	.p2align	2
_cJSON_GetErrorPtr:                     ; @cJSON_GetErrorPtr
	.cfi_startproc
; %bb.0:
	adrp	x8, _global_error@PAGE
	adrp	x9, _global_error@PAGE
	add	x9, x9, _global_error@PAGEOFF
	ldr	x8, [x8, _global_error@PAGEOFF]
	ldr	x9, [x9, #8]
	add	x0, x8, x9
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_GetStringValue           ; -- Begin function cJSON_GetStringValue
	.p2align	2
_cJSON_GetStringValue:                  ; @cJSON_GetStringValue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x0, [sp]
	bl	_cJSON_IsString
	cbnz	w0, LBB1_2
	b	LBB1_1
LBB1_1:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	LBB1_3
LBB1_2:
	ldr	x8, [sp]
	ldr	x8, [x8, #32]
	str	x8, [sp, #8]
	b	LBB1_3
LBB1_3:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsString                 ; -- Begin function cJSON_IsString
	.p2align	2
_cJSON_IsString:                        ; @cJSON_IsString
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	str	wzr, [sp, #12]
	b	LBB2_3
LBB2_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #16
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB2_3
LBB2_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_GetNumberValue           ; -- Begin function cJSON_GetNumberValue
	.p2align	2
_cJSON_GetNumberValue:                  ; @cJSON_GetNumberValue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x0, [sp]
	bl	_cJSON_IsNumber
	cbnz	w0, LBB3_2
	b	LBB3_1
LBB3_1:
	mov	x8, #9221120237041090560        ; =0x7ff8000000000000
	fmov	d0, x8
	str	d0, [sp, #8]
	b	LBB3_3
LBB3_2:
	ldr	x8, [sp]
	ldr	d0, [x8, #48]
	str	d0, [sp, #8]
	b	LBB3_3
LBB3_3:
	ldr	d0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsNumber                 ; -- Begin function cJSON_IsNumber
	.p2align	2
_cJSON_IsNumber:                        ; @cJSON_IsNumber
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	str	wzr, [sp, #12]
	b	LBB4_3
LBB4_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #8
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB4_3
LBB4_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Version                  ; -- Begin function cJSON_Version
	.p2align	2
_cJSON_Version:                         ; @cJSON_Version
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, sp
	mov	x8, #1                          ; =0x1
	str	x8, [x9]
	mov	x8, #7                          ; =0x7
	str	x8, [x9, #8]
	mov	x8, #19                         ; =0x13
	str	x8, [x9, #16]
	adrp	x0, _cJSON_Version.version@PAGE
	add	x0, x0, _cJSON_Version.version@PAGEOFF
	stur	x0, [x29, #-8]                  ; 8-byte Folded Spill
	mov	x3, #15                         ; =0xf
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str@PAGE
	add	x4, x4, l_.str@PAGEOFF
	bl	___snprintf_chk
	ldur	x0, [x29, #-8]                  ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_InitHooks                ; -- Begin function cJSON_InitHooks
	.p2align	2
_cJSON_InitHooks:                       ; @cJSON_InitHooks
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	adrp	x10, _global_hooks@PAGE
	adrp	x9, _global_hooks@PAGE
	add	x9, x9, _global_hooks@PAGEOFF
	adrp	x8, _malloc@GOTPAGE
	ldr	x8, [x8, _malloc@GOTPAGEOFF]
	str	x8, [x10, _global_hooks@PAGEOFF]
	adrp	x8, _free@GOTPAGE
	ldr	x8, [x8, _free@GOTPAGEOFF]
	str	x8, [x9, #8]
	adrp	x8, _realloc@GOTPAGE
	ldr	x8, [x8, _realloc@GOTPAGEOFF]
	str	x8, [x9, #16]
	b	LBB6_9
LBB6_2:
	adrp	x9, _global_hooks@PAGE
	adrp	x8, _malloc@GOTPAGE
	ldr	x8, [x8, _malloc@GOTPAGEOFF]
	str	x8, [x9, _global_hooks@PAGEOFF]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbz	x8, LBB6_4
	b	LBB6_3
LBB6_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	adrp	x9, _global_hooks@PAGE
	str	x8, [x9, _global_hooks@PAGEOFF]
	b	LBB6_4
LBB6_4:
	adrp	x9, _global_hooks@PAGE
	add	x9, x9, _global_hooks@PAGEOFF
	adrp	x8, _free@GOTPAGE
	ldr	x8, [x8, _free@GOTPAGEOFF]
	str	x8, [x9, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbz	x8, LBB6_6
	b	LBB6_5
LBB6_5:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	adrp	x9, _global_hooks@PAGE
	add	x9, x9, _global_hooks@PAGEOFF
	str	x8, [x9, #8]
	b	LBB6_6
LBB6_6:
	adrp	x8, _global_hooks@PAGE
	adrp	x9, _global_hooks@PAGE
	add	x9, x9, _global_hooks@PAGEOFF
                                        ; kill: def $x10 killed $xzr
	str	xzr, [x9, #16]
	ldr	x8, [x8, _global_hooks@PAGEOFF]
	adrp	x9, _malloc@GOTPAGE
	ldr	x9, [x9, _malloc@GOTPAGEOFF]
	subs	x8, x8, x9
	b.ne	LBB6_9
	b	LBB6_7
LBB6_7:
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	x8, [x8, #8]
	adrp	x9, _free@GOTPAGE
	ldr	x9, [x9, _free@GOTPAGEOFF]
	subs	x8, x8, x9
	b.ne	LBB6_9
	b	LBB6_8
LBB6_8:
	adrp	x8, _realloc@GOTPAGE
	ldr	x8, [x8, _realloc@GOTPAGEOFF]
	adrp	x9, _global_hooks@PAGE
	add	x9, x9, _global_hooks@PAGEOFF
	str	x8, [x9, #16]
	b	LBB6_9
LBB6_9:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Delete                   ; -- Begin function cJSON_Delete
	.p2align	2
_cJSON_Delete:                          ; @cJSON_Delete
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp]
	b	LBB7_1
LBB7_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_12
	b	LBB7_2
LBB7_2:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #24]
	tbnz	w8, #8, LBB7_5
	b	LBB7_3
LBB7_3:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB7_5
	b	LBB7_4
LBB7_4:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_cJSON_Delete
	b	LBB7_5
LBB7_5:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #24]
	tbnz	w8, #8, LBB7_8
	b	LBB7_6
LBB7_6:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	cbz	x8, LBB7_8
	b	LBB7_7
LBB7_7:                                 ;   in Loop: Header=BB7_1 Depth=1
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #32]
	blr	x8
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #32]
	b	LBB7_8
LBB7_8:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #24]
	tbnz	w8, #9, LBB7_11
	b	LBB7_9
LBB7_9:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #56]
	cbz	x8, LBB7_11
	b	LBB7_10
LBB7_10:                                ;   in Loop: Header=BB7_1 Depth=1
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #56]
	blr	x8
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #56]
	b	LBB7_11
LBB7_11:                                ;   in Loop: Header=BB7_1 Depth=1
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	x8, [x8, #8]
	ldr	x0, [sp, #8]
	blr	x8
	ldr	x8, [sp]
	str	x8, [sp, #8]
	b	LBB7_1
LBB7_12:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_SetNumberHelper          ; -- Begin function cJSON_SetNumberHelper
	.p2align	2
_cJSON_SetNumberHelper:                 ; @cJSON_SetNumberHelper
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	d0, [sp]
	ldr	d0, [sp]
	mov	x8, #281474972516352            ; =0xffffffc00000
	movk	x8, #16863, lsl #48
	fmov	d1, x8
	fcmp	d0, d1
	b.lt	LBB8_2
	b	LBB8_1
LBB8_1:
	ldr	x9, [sp, #8]
	mov	w8, #2147483647                 ; =0x7fffffff
	str	w8, [x9, #40]
	b	LBB8_6
LBB8_2:
	ldr	d0, [sp]
	mov	x8, #-4476578029606273024       ; =0xc1e0000000000000
	fmov	d1, x8
	fcmp	d0, d1
	b.hi	LBB8_4
	b	LBB8_3
LBB8_3:
	ldr	x9, [sp, #8]
	mov	w8, #-2147483648                ; =0x80000000
	str	w8, [x9, #40]
	b	LBB8_5
LBB8_4:
	ldr	d0, [sp]
	fcvtzs	w8, d0
	ldr	x9, [sp, #8]
	str	w8, [x9, #40]
	b	LBB8_5
LBB8_5:
	b	LBB8_6
LBB8_6:
	ldr	d0, [sp]
	ldr	x8, [sp, #8]
	str	d0, [x8, #48]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_SetValuestring           ; -- Begin function cJSON_SetValuestring
	.p2align	2
_cJSON_SetValuestring:                  ; @cJSON_SetValuestring
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB9_3
	b	LBB9_1
LBB9_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	tbz	w8, #4, LBB9_3
	b	LBB9_2
LBB9_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	tbz	w8, #8, LBB9_4
	b	LBB9_3
LBB9_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB9_17
LBB9_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	cbz	x8, LBB9_6
	b	LBB9_5
LBB9_5:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB9_7
	b	LBB9_6
LBB9_6:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB9_17
LBB9_7:
	ldr	x0, [sp, #24]
	bl	_strlen
	str	x0, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #32]
	bl	_strlen
	str	x0, [sp]
	ldr	x8, [sp, #8]
	ldr	x9, [sp]
	subs	x8, x8, x9
	b.hi	LBB9_12
	b	LBB9_8
LBB9_8:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	add	x8, x8, x9
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.lo	LBB9_11
	b	LBB9_9
LBB9_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldr	x9, [sp]
	add	x8, x8, x9
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.lo	LBB9_11
	b	LBB9_10
LBB9_10:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB9_17
LBB9_11:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #32]
	ldr	x1, [sp, #24]
	mov	x2, #-1                         ; =0xffffffffffffffff
	bl	___strcpy_chk
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	stur	x8, [x29, #-8]
	b	LBB9_17
LBB9_12:
	ldr	x0, [sp, #24]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_cJSON_strdup
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB9_14
	b	LBB9_13
LBB9_13:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB9_17
LBB9_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	cbz	x8, LBB9_16
	b	LBB9_15
LBB9_15:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #32]
	bl	_cJSON_free
	b	LBB9_16
LBB9_16:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #32]
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB9_17
LBB9_17:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function cJSON_strdup
_cJSON_strdup:                          ; @cJSON_strdup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	xzr, [sp, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_5
LBB10_2:
	ldur	x0, [x29, #-16]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #16]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x0, [sp, #16]
	blr	x8
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB10_4
	b	LBB10_3
LBB10_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_5
LBB10_4:
	ldr	x0, [sp, #8]
	ldur	x1, [x29, #-16]
	ldr	x2, [sp, #16]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB10_5
LBB10_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_free                     ; -- Begin function cJSON_free
	.p2align	2
_cJSON_free:                            ; @cJSON_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	x8, [x8, #8]
	ldr	x0, [sp, #8]
	blr	x8
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ParseWithOpts            ; -- Begin function cJSON_ParseWithOpts
	.p2align	2
_cJSON_ParseWithOpts:                   ; @cJSON_ParseWithOpts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	w2, [sp, #20]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB12_3
LBB12_2:
	ldur	x0, [x29, #-16]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #24]
	ldr	w3, [sp, #20]
	bl	_cJSON_ParseWithLengthOpts
	stur	x0, [x29, #-8]
	b	LBB12_3
LBB12_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ParseWithLengthOpts      ; -- Begin function cJSON_ParseWithLengthOpts
	.p2align	2
_cJSON_ParseWithLengthOpts:             ; @cJSON_ParseWithLengthOpts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	stur	w3, [x29, #-36]
	add	x0, sp, #32
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	adrp	x9, _global_error@PAGE
	adrp	x8, _global_error@PAGE
	add	x8, x8, _global_error@PAGEOFF
	str	xzr, [x9, _global_error@PAGEOFF]
	str	xzr, [x8, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB13_3
	b	LBB13_2
LBB13_2:
	b	LBB13_15
LBB13_3:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #40]
	str	xzr, [sp, #48]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	ldr	q0, [x0]
	str	q0, [sp, #64]
	ldr	x8, [x0, #16]
	str	x8, [sp, #80]
	bl	_cJSON_New_Item
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB13_5
	b	LBB13_4
LBB13_4:
	b	LBB13_15
LBB13_5:
	ldr	x8, [sp, #24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	add	x0, sp, #32
	bl	_skip_utf8_bom
	bl	_buffer_skip_whitespace
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_parse_value
	cbnz	w0, LBB13_7
	b	LBB13_6
LBB13_6:
	b	LBB13_15
LBB13_7:
	ldur	w8, [x29, #-36]
	cbz	w8, LBB13_12
	b	LBB13_8
LBB13_8:
	add	x0, sp, #32
	bl	_buffer_skip_whitespace
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.hs	LBB13_10
	b	LBB13_9
LBB13_9:
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #48]
	ldrb	w8, [x8, x9]
	cbz	w8, LBB13_11
	b	LBB13_10
LBB13_10:
	b	LBB13_15
LBB13_11:
	b	LBB13_12
LBB13_12:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB13_14
	b	LBB13_13
LBB13_13:
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #48]
	add	x8, x8, x9
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	b	LBB13_14
LBB13_14:
	ldr	x8, [sp, #24]
	stur	x8, [x29, #-8]
	b	LBB13_27
LBB13_15:
	ldr	x8, [sp, #24]
	cbz	x8, LBB13_17
	b	LBB13_16
LBB13_16:
	ldr	x0, [sp, #24]
	bl	_cJSON_Delete
	b	LBB13_17
LBB13_17:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB13_26
	b	LBB13_18
LBB13_18:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]
	str	xzr, [sp, #16]
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.hs	LBB13_20
	b	LBB13_19
LBB13_19:
	ldr	x8, [sp, #48]
	str	x8, [sp, #16]
	b	LBB13_23
LBB13_20:
	ldr	x8, [sp, #40]
	subs	x8, x8, #0
	b.ls	LBB13_22
	b	LBB13_21
LBB13_21:
	ldr	x8, [sp, #40]
	subs	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB13_22
LBB13_22:
	b	LBB13_23
LBB13_23:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB13_25
	b	LBB13_24
LBB13_24:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	add	x8, x8, x9
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	b	LBB13_25
LBB13_25:
	ldur	q0, [sp, #8]
	adrp	x8, _global_error@PAGE
	add	x8, x8, _global_error@PAGEOFF
	str	q0, [x8]
	b	LBB13_26
LBB13_26:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB13_27
LBB13_27:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function cJSON_New_Item
_cJSON_New_Item:                        ; @cJSON_New_Item
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	mov	x0, #64                         ; =0x40
	blr	x8
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB14_2
	b	LBB14_1
LBB14_1:
	ldr	x0, [sp]
	mov	w1, #0                          ; =0x0
	mov	x2, #64                         ; =0x40
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB14_2
LBB14_2:
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_value
_parse_value:                           ; @parse_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_2
	b	LBB15_1
LBB15_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB15_3
	b	LBB15_2
LBB15_2:
	stur	wzr, [x29, #-4]
	b	LBB15_34
LBB15_3:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_7
	b	LBB15_4
LBB15_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #4
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB15_7
	b	LBB15_5
LBB15_5:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	add	x0, x8, x9
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x2, #4                          ; =0x4
	bl	_strncmp
	cbnz	w0, LBB15_7
	b	LBB15_6
LBB15_6:
	ldr	x9, [sp, #16]
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #24]
	ldr	x9, [sp, #8]
	ldr	x8, [x9, #16]
	add	x8, x8, #4
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB15_34
LBB15_7:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_11
	b	LBB15_8
LBB15_8:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #5
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB15_11
	b	LBB15_9
LBB15_9:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	add	x0, x8, x9
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	mov	x2, #5                          ; =0x5
	bl	_strncmp
	cbnz	w0, LBB15_11
	b	LBB15_10
LBB15_10:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #24]
	ldr	x10, [sp, #8]
	ldr	x9, [x10, #16]
	add	x9, x9, #5
	str	x9, [x10, #16]
	stur	w8, [x29, #-4]
	b	LBB15_34
LBB15_11:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_15
	b	LBB15_12
LBB15_12:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #4
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB15_15
	b	LBB15_13
LBB15_13:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	add	x0, x8, x9
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	mov	x2, #4                          ; =0x4
	bl	_strncmp
	cbnz	w0, LBB15_15
	b	LBB15_14
LBB15_14:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #24]
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #40]
	ldr	x10, [sp, #8]
	ldr	x9, [x10, #16]
	add	x9, x9, #4
	str	x9, [x10, #16]
	stur	w8, [x29, #-4]
	b	LBB15_34
LBB15_15:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_19
	b	LBB15_16
LBB15_16:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB15_19
	b	LBB15_17
LBB15_17:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #34
	b.ne	LBB15_19
	b	LBB15_18
LBB15_18:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_parse_string
	stur	w0, [x29, #-4]
	b	LBB15_34
LBB15_19:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_25
	b	LBB15_20
LBB15_20:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB15_25
	b	LBB15_21
LBB15_21:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #45
	b.eq	LBB15_24
	b	LBB15_22
LBB15_22:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #48
	b.lt	LBB15_25
	b	LBB15_23
LBB15_23:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #57
	b.gt	LBB15_25
	b	LBB15_24
LBB15_24:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_parse_number
	stur	w0, [x29, #-4]
	b	LBB15_34
LBB15_25:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_29
	b	LBB15_26
LBB15_26:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB15_29
	b	LBB15_27
LBB15_27:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #91
	b.ne	LBB15_29
	b	LBB15_28
LBB15_28:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_parse_array
	stur	w0, [x29, #-4]
	b	LBB15_34
LBB15_29:
	ldr	x8, [sp, #8]
	cbz	x8, LBB15_33
	b	LBB15_30
LBB15_30:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB15_33
	b	LBB15_31
LBB15_31:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #123
	b.ne	LBB15_33
	b	LBB15_32
LBB15_32:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_parse_object
	stur	w0, [x29, #-4]
	b	LBB15_34
LBB15_33:
	stur	wzr, [x29, #-4]
	b	LBB15_34
LBB15_34:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function buffer_skip_whitespace
_buffer_skip_whitespace:                ; @buffer_skip_whitespace
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB16_2
	b	LBB16_1
LBB16_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	cbnz	x8, LBB16_3
	b	LBB16_2
LBB16_2:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB16_15
LBB16_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB16_5
	b	LBB16_4
LBB16_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB16_6
	b	LBB16_5
LBB16_5:
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB16_15
LBB16_6:
	b	LBB16_7
LBB16_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB16_10
	b	LBB16_8
LBB16_8:                                ;   in Loop: Header=BB16_7 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	add	x9, x8, #0
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB16_10
	b	LBB16_9
LBB16_9:                                ;   in Loop: Header=BB16_7 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #32
	cset	w8, le
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB16_10
LBB16_10:                               ;   in Loop: Header=BB16_7 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB16_12
	b	LBB16_11
LBB16_11:                               ;   in Loop: Header=BB16_7 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB16_7
LBB16_12:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.ne	LBB16_14
	b	LBB16_13
LBB16_13:
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB16_14
LBB16_14:
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB16_15
LBB16_15:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function skip_utf8_bom
_skip_utf8_bom:                         ; @skip_utf8_bom
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB17_3
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB17_3
	b	LBB17_2
LBB17_2:
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	cbz	x8, LBB17_4
	b	LBB17_3
LBB17_3:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	LBB17_9
LBB17_4:
	ldr	x8, [sp]
	cbz	x8, LBB17_8
	b	LBB17_5
LBB17_5:
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	add	x8, x8, #4
	ldr	x9, [sp]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB17_8
	b	LBB17_6
LBB17_6:
	ldr	x8, [sp]
	ldr	x8, [x8]
	ldr	x9, [sp]
	ldr	x9, [x9, #16]
	add	x0, x8, x9
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x2, #3                          ; =0x3
	bl	_strncmp
	cbnz	w0, LBB17_8
	b	LBB17_7
LBB17_7:
	ldr	x9, [sp]
	ldr	x8, [x9, #16]
	add	x8, x8, #3
	str	x8, [x9, #16]
	b	LBB17_8
LBB17_8:
	ldr	x8, [sp]
	str	x8, [sp, #8]
	b	LBB17_9
LBB17_9:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Parse                    ; -- Begin function cJSON_Parse
	.p2align	2
_cJSON_Parse:                           ; @cJSON_Parse
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_cJSON_ParseWithOpts
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ParseWithLength          ; -- Begin function cJSON_ParseWithLength
	.p2align	2
_cJSON_ParseWithLength:                 ; @cJSON_ParseWithLength
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_cJSON_ParseWithLengthOpts
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Print                    ; -- Begin function cJSON_Print
	.p2align	2
_cJSON_Print:                           ; @cJSON_Print
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w1, #1                          ; =0x1
	adrp	x2, _global_hooks@PAGE
	add	x2, x2, _global_hooks@PAGEOFF
	bl	_print
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print
_print:                                 ; @print
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #72]
	str	w1, [sp, #68]
	str	x2, [sp, #56]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #48]
	sub	x0, x29, #72
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #56]
	ldr	x8, [x8]
	mov	x0, #256                        ; =0x100
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	blr	x8
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-72]
	stur	x8, [x29, #-64]
	ldr	w8, [sp, #68]
	stur	w8, [x29, #-36]
	ldr	x8, [sp, #56]
	ldr	q0, [x8]
	stur	q0, [x9, #40]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-16]
	ldur	x8, [x29, #-72]
	cbnz	x8, LBB21_2
	b	LBB21_1
LBB21_1:
	b	LBB21_15
LBB21_2:
	ldr	x0, [sp, #72]
	sub	x1, x29, #72
	bl	_print_value
	cbnz	w0, LBB21_4
	b	LBB21_3
LBB21_3:
	b	LBB21_15
LBB21_4:
	sub	x0, x29, #72
	bl	_update_offset
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #16]
	cbz	x8, LBB21_8
	b	LBB21_5
LBB21_5:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #16]
	ldur	x0, [x29, #-72]
	ldur	x9, [x29, #-56]
	add	x1, x9, #1
	blr	x8
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB21_7
	b	LBB21_6
LBB21_6:
	b	LBB21_15
LBB21_7:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-72]
	b	LBB21_14
LBB21_8:
	ldr	x8, [sp, #56]
	ldr	x8, [x8]
	ldur	x9, [x29, #-56]
	add	x0, x9, #1
	blr	x8
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB21_10
	b	LBB21_9
LBB21_9:
	b	LBB21_15
LBB21_10:
	ldr	x8, [sp, #48]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-72]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-64]
	ldur	x9, [x29, #-56]
	add	x9, x9, #1
	subs	x8, x8, x9
	b.hs	LBB21_12
	b	LBB21_11
LBB21_11:
	ldur	x8, [x29, #-64]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB21_13
LBB21_12:
	ldur	x8, [x29, #-56]
	add	x8, x8, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB21_13
LBB21_13:
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-56]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	ldur	x0, [x29, #-72]
	blr	x8
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-72]
	b	LBB21_14
LBB21_14:
	ldr	x8, [sp, #48]
	str	x8, [sp, #80]
	b	LBB21_20
LBB21_15:
	ldur	x8, [x29, #-72]
	cbz	x8, LBB21_17
	b	LBB21_16
LBB21_16:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	ldur	x0, [x29, #-72]
	blr	x8
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-72]
	b	LBB21_17
LBB21_17:
	ldr	x8, [sp, #48]
	cbz	x8, LBB21_19
	b	LBB21_18
LBB21_18:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	ldr	x0, [sp, #48]
	blr	x8
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #48]
	b	LBB21_19
LBB21_19:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #80]
	b	LBB21_20
LBB21_20:
	ldr	x8, [sp, #80]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB21_22
	b	LBB21_21
LBB21_21:
	bl	___stack_chk_fail
LBB21_22:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_PrintUnformatted         ; -- Begin function cJSON_PrintUnformatted
	.p2align	2
_cJSON_PrintUnformatted:                ; @cJSON_PrintUnformatted
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	adrp	x2, _global_hooks@PAGE
	add	x2, x2, _global_hooks@PAGEOFF
	bl	_print
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_PrintBuffered            ; -- Begin function cJSON_PrintBuffered
	.p2align	2
_cJSON_PrintBuffered:                   ; @cJSON_PrintBuffered
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	add	x0, sp, #8
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldur	w8, [x29, #-20]
	tbz	w8, #31, LBB23_2
	b	LBB23_1
LBB23_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB23_7
LBB23_2:
	adrp	x8, _global_hooks@PAGE
	ldr	x8, [x8, _global_hooks@PAGEOFF]
	ldursw	x0, [x29, #-20]
	blr	x8
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB23_4
	b	LBB23_3
LBB23_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB23_7
LBB23_4:
	ldursw	x8, [x29, #-20]
	add	x1, sp, #8
	str	x8, [sp, #16]
	str	xzr, [sp, #24]
	str	wzr, [sp, #40]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #44]
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x1, #40]
	ldr	x8, [x8, #16]
	str	x8, [sp, #64]
	ldur	x0, [x29, #-16]
	bl	_print_value
	cbnz	w0, LBB23_6
	b	LBB23_5
LBB23_5:
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	x8, [x8, #8]
	ldr	x0, [sp, #8]
	blr	x8
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	stur	xzr, [x29, #-8]
	b	LBB23_7
LBB23_6:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB23_7
LBB23_7:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_value
_print_value:                           ; @print_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB24_2
	b	LBB24_1
LBB24_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB24_3
	b	LBB24_2
LBB24_2:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_3:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #24]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB24_14
	b	LBB24_4
LBB24_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB24_17
	b	LBB24_5
LBB24_5:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB24_11
	b	LBB24_6
LBB24_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB24_20
	b	LBB24_7
LBB24_7:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #16
	b.eq	LBB24_26
	b	LBB24_8
LBB24_8:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #32
	b.eq	LBB24_27
	b	LBB24_9
LBB24_9:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #64
	b.eq	LBB24_28
	b	LBB24_10
LBB24_10:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #128
	b.eq	LBB24_21
	b	LBB24_29
LBB24_11:
	ldr	x0, [sp, #24]
	mov	x1, #5                          ; =0x5
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB24_13
	b	LBB24_12
LBB24_12:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_13:
	ldr	x0, [sp, #16]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x2, #-1                         ; =0xffffffffffffffff
	bl	___strcpy_chk
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_30
LBB24_14:
	ldr	x0, [sp, #24]
	mov	x1, #6                          ; =0x6
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB24_16
	b	LBB24_15
LBB24_15:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_16:
	ldr	x0, [sp, #16]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	mov	x2, #-1                         ; =0xffffffffffffffff
	bl	___strcpy_chk
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_30
LBB24_17:
	ldr	x0, [sp, #24]
	mov	x1, #5                          ; =0x5
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB24_19
	b	LBB24_18
LBB24_18:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_19:
	ldr	x0, [sp, #16]
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	mov	x2, #-1                         ; =0xffffffffffffffff
	bl	___strcpy_chk
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_30
LBB24_20:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	bl	_print_number
	stur	w0, [x29, #-4]
	b	LBB24_30
LBB24_21:
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB24_23
	b	LBB24_22
LBB24_22:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_23:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #32]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #8]
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #8]
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB24_25
	b	LBB24_24
LBB24_24:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_25:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #32]
	ldr	x2, [sp, #8]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_30
LBB24_26:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	bl	_print_string
	stur	w0, [x29, #-4]
	b	LBB24_30
LBB24_27:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	bl	_print_array
	stur	w0, [x29, #-4]
	b	LBB24_30
LBB24_28:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	bl	_print_object
	stur	w0, [x29, #-4]
	b	LBB24_30
LBB24_29:
	stur	wzr, [x29, #-4]
	b	LBB24_30
LBB24_30:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_PrintPreallocated        ; -- Begin function cJSON_PrintPreallocated
	.p2align	2
_cJSON_PrintPreallocated:               ; @cJSON_PrintPreallocated
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	stur	w3, [x29, #-32]
	mov	x0, sp
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldur	w8, [x29, #-28]
	tbnz	w8, #31, LBB25_2
	b	LBB25_1
LBB25_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB25_3
	b	LBB25_2
LBB25_2:
	stur	wzr, [x29, #-4]
	b	LBB25_4
LBB25_3:
	ldur	x8, [x29, #-24]
	mov	x1, sp
	str	x8, [sp]
	ldursw	x8, [x29, #-28]
	str	x8, [sp, #8]
	str	xzr, [sp, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #32]
	ldur	w8, [x29, #-32]
	str	w8, [sp, #36]
	adrp	x8, _global_hooks@PAGE
	add	x8, x8, _global_hooks@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x1, #40]
	ldr	x8, [x8, #16]
	str	x8, [sp, #56]
	ldur	x0, [x29, #-16]
	bl	_print_value
	stur	w0, [x29, #-4]
	b	LBB25_4
LBB25_4:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_GetArraySize             ; -- Begin function cJSON_GetArraySize
	.p2align	2
_cJSON_GetArraySize:                    ; @cJSON_GetArraySize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	str	xzr, [sp]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB26_2
	b	LBB26_1
LBB26_1:
	str	wzr, [sp, #28]
	b	LBB26_6
LBB26_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #8]
	b	LBB26_3
LBB26_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	cbz	x8, LBB26_5
	b	LBB26_4
LBB26_4:                                ;   in Loop: Header=BB26_3 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	b	LBB26_3
LBB26_5:
	ldr	x8, [sp]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #28]
	b	LBB26_6
LBB26_6:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_GetArrayItem             ; -- Begin function cJSON_GetArrayItem
	.p2align	2
_cJSON_GetArrayItem:                    ; @cJSON_GetArrayItem
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB27_2
	b	LBB27_1
LBB27_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB27_3
LBB27_2:
	ldr	x0, [sp, #16]
	ldrsw	x1, [sp, #12]
	bl	_get_array_item
	stur	x0, [x29, #-8]
	b	LBB27_3
LBB27_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get_array_item
_get_array_item:                        ; @get_array_item
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB28_2
	b	LBB28_1
LBB28_1:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	b	LBB28_8
LBB28_2:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	str	x8, [sp, #16]
	b	LBB28_3
LBB28_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB28_5
	b	LBB28_4
LBB28_4:                                ;   in Loop: Header=BB28_3 Depth=1
	ldr	x8, [sp, #24]
	subs	x8, x8, #0
	cset	w8, hi
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB28_5
LBB28_5:                                ;   in Loop: Header=BB28_3 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB28_7
	b	LBB28_6
LBB28_6:                                ;   in Loop: Header=BB28_3 Depth=1
	ldr	x8, [sp, #24]
	subs	x8, x8, #1
	str	x8, [sp, #24]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	str	x8, [sp, #16]
	b	LBB28_3
LBB28_7:
	ldr	x8, [sp, #16]
	str	x8, [sp, #40]
	b	LBB28_8
LBB28_8:
	ldr	x0, [sp, #40]
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_GetObjectItem            ; -- Begin function cJSON_GetObjectItem
	.p2align	2
_cJSON_GetObjectItem:                   ; @cJSON_GetObjectItem
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w2, #0                          ; =0x0
	bl	_get_object_item
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get_object_item
_get_object_item:                       ; @get_object_item
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	w2, [sp, #20]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB30_2
	b	LBB30_1
LBB30_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB30_3
	b	LBB30_2
LBB30_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB30_21
LBB30_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #8]
	ldr	w8, [sp, #20]
	cbz	w8, LBB30_11
	b	LBB30_4
LBB30_4:
	b	LBB30_5
LBB30_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB30_8
	b	LBB30_6
LBB30_6:                                ;   in Loop: Header=BB30_5 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #56]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB30_8
	b	LBB30_7
LBB30_7:                                ;   in Loop: Header=BB30_5 Depth=1
	ldr	x0, [sp, #24]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #56]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB30_8
LBB30_8:                                ;   in Loop: Header=BB30_5 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB30_10
	b	LBB30_9
LBB30_9:                                ;   in Loop: Header=BB30_5 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	b	LBB30_5
LBB30_10:
	b	LBB30_17
LBB30_11:
	b	LBB30_12
LBB30_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB30_14
	b	LBB30_13
LBB30_13:                               ;   in Loop: Header=BB30_12 Depth=1
	ldr	x0, [sp, #24]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #56]
	bl	_case_insensitive_strcmp
	subs	w8, w0, #0
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB30_14
LBB30_14:                               ;   in Loop: Header=BB30_12 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	tbz	w8, #0, LBB30_16
	b	LBB30_15
LBB30_15:                               ;   in Loop: Header=BB30_12 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	b	LBB30_12
LBB30_16:
	b	LBB30_17
LBB30_17:
	ldr	x8, [sp, #8]
	cbz	x8, LBB30_19
	b	LBB30_18
LBB30_18:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB30_20
	b	LBB30_19
LBB30_19:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB30_21
LBB30_20:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB30_21
LBB30_21:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_GetObjectItemCaseSensitive ; -- Begin function cJSON_GetObjectItemCaseSensitive
	.p2align	2
_cJSON_GetObjectItemCaseSensitive:      ; @cJSON_GetObjectItemCaseSensitive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w2, #1                          ; =0x1
	bl	_get_object_item
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_HasObjectItem            ; -- Begin function cJSON_HasObjectItem
	.p2align	2
_cJSON_HasObjectItem:                   ; @cJSON_HasObjectItem
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	_cJSON_GetObjectItem
	mov	w8, #0                          ; =0x0
	subs	x9, x0, #0
	csinc	w0, w8, wzr, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddItemToArray           ; -- Begin function cJSON_AddItemToArray
	.p2align	2
_cJSON_AddItemToArray:                  ; @cJSON_AddItemToArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	_add_item_to_array
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function add_item_to_array
_add_item_to_array:                     ; @add_item_to_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, LBB34_3
	b	LBB34_1
LBB34_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB34_3
	b	LBB34_2
LBB34_2:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB34_4
	b	LBB34_3
LBB34_3:
	stur	wzr, [x29, #-4]
	b	LBB34_10
LBB34_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	str	x8, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB34_6
	b	LBB34_5
LBB34_5:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9, #16]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #8]
	str	x8, [x9, #8]
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	b	LBB34_9
LBB34_6:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	cbz	x8, LBB34_8
	b	LBB34_7
LBB34_7:
	ldr	x8, [sp]
	ldr	x0, [x8, #8]
	ldr	x1, [sp, #8]
	bl	_suffix_object
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB34_8
LBB34_8:
	b	LBB34_9
LBB34_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB34_10
LBB34_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddItemToObject          ; -- Begin function cJSON_AddItemToObject
	.p2align	2
_cJSON_AddItemToObject:                 ; @cJSON_AddItemToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function add_item_to_object
_add_item_to_object:                    ; @add_item_to_object
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	str	w4, [sp, #20]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	str	wzr, [sp, #4]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB36_4
	b	LBB36_1
LBB36_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB36_4
	b	LBB36_2
LBB36_2:
	ldr	x8, [sp, #32]
	cbz	x8, LBB36_4
	b	LBB36_3
LBB36_3:
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.ne	LBB36_5
	b	LBB36_4
LBB36_4:
	stur	wzr, [x29, #-4]
	b	LBB36_14
LBB36_5:
	ldr	w8, [sp, #20]
	cbz	w8, LBB36_7
	b	LBB36_6
LBB36_6:
	ldur	x0, [x29, #-24]
	bl	_cast_away_const
	str	x0, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #24]
	orr	w8, w8, #0x200
	str	w8, [sp, #4]
	b	LBB36_10
LBB36_7:
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #24]
	bl	_cJSON_strdup
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB36_9
	b	LBB36_8
LBB36_8:
	stur	wzr, [x29, #-4]
	b	LBB36_14
LBB36_9:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #24]
	and	w8, w8, #0xfffffdff
	str	w8, [sp, #4]
	b	LBB36_10
LBB36_10:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #24]
	tbnz	w8, #9, LBB36_13
	b	LBB36_11
LBB36_11:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #56]
	cbz	x8, LBB36_13
	b	LBB36_12
LBB36_12:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #32]
	ldr	x0, [x9, #56]
	blr	x8
	b	LBB36_13
LBB36_13:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #32]
	str	x8, [x9, #56]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #32]
	str	w8, [x9, #24]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	bl	_add_item_to_array
	stur	w0, [x29, #-4]
	b	LBB36_14
LBB36_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddItemToObjectCS        ; -- Begin function cJSON_AddItemToObjectCS
	.p2align	2
_cJSON_AddItemToObjectCS:               ; @cJSON_AddItemToObjectCS
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #1                          ; =0x1
	bl	_add_item_to_object
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddItemReferenceToArray  ; -- Begin function cJSON_AddItemReferenceToArray
	.p2align	2
_cJSON_AddItemReferenceToArray:         ; @cJSON_AddItemReferenceToArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB38_2
	b	LBB38_1
LBB38_1:
	stur	wzr, [x29, #-4]
	b	LBB38_3
LBB38_2:
	ldr	x8, [sp, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [sp, #8]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_create_reference
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_add_item_to_array
	stur	w0, [x29, #-4]
	b	LBB38_3
LBB38_3:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function create_reference
_create_reference:                      ; @create_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB39_2
	b	LBB39_1
LBB39_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB39_5
LBB39_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_New_Item
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB39_4
	b	LBB39_3
LBB39_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB39_5
LBB39_4:
	ldr	x0, [sp]
	ldr	x1, [sp, #16]
	mov	x2, #64                         ; =0x40
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #56]
	ldr	x9, [sp]
	ldr	w8, [x9, #24]
	orr	w8, w8, #0x100
	str	w8, [x9, #24]
	ldr	x8, [sp]
	str	xzr, [x8, #8]
	ldr	x8, [sp]
	str	xzr, [x8]
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB39_5
LBB39_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddItemReferenceToObject ; -- Begin function cJSON_AddItemReferenceToObject
	.p2align	2
_cJSON_AddItemReferenceToObject:        ; @cJSON_AddItemReferenceToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB40_2
	b	LBB40_1
LBB40_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB40_3
	b	LBB40_2
LBB40_2:
	stur	wzr, [x29, #-4]
	b	LBB40_4
LBB40_3:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [sp, #32]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	bl	_create_reference
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	mov	x2, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	stur	w0, [x29, #-4]
	b	LBB40_4
LBB40_4:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddNullToObject          ; -- Begin function cJSON_AddNullToObject
	.p2align	2
_cJSON_AddNullToObject:                 ; @cJSON_AddNullToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	bl	_cJSON_CreateNull
	str	x0, [sp]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB41_2
	b	LBB41_1
LBB41_1:
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB41_3
LBB41_2:
	ldr	x0, [sp]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB41_3
LBB41_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateNull               ; -- Begin function cJSON_CreateNull
	.p2align	2
_cJSON_CreateNull:                      ; @cJSON_CreateNull
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB42_2
	b	LBB42_1
LBB42_1:
	ldr	x9, [sp, #8]
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #24]
	b	LBB42_2
LBB42_2:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddTrueToObject          ; -- Begin function cJSON_AddTrueToObject
	.p2align	2
_cJSON_AddTrueToObject:                 ; @cJSON_AddTrueToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	bl	_cJSON_CreateTrue
	str	x0, [sp]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB43_2
	b	LBB43_1
LBB43_1:
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB43_3
LBB43_2:
	ldr	x0, [sp]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB43_3
LBB43_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateTrue               ; -- Begin function cJSON_CreateTrue
	.p2align	2
_cJSON_CreateTrue:                      ; @cJSON_CreateTrue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB44_2
	b	LBB44_1
LBB44_1:
	ldr	x9, [sp, #8]
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #24]
	b	LBB44_2
LBB44_2:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddFalseToObject         ; -- Begin function cJSON_AddFalseToObject
	.p2align	2
_cJSON_AddFalseToObject:                ; @cJSON_AddFalseToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	bl	_cJSON_CreateFalse
	str	x0, [sp]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB45_2
	b	LBB45_1
LBB45_1:
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB45_3
LBB45_2:
	ldr	x0, [sp]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB45_3
LBB45_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateFalse              ; -- Begin function cJSON_CreateFalse
	.p2align	2
_cJSON_CreateFalse:                     ; @cJSON_CreateFalse
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB46_2
	b	LBB46_1
LBB46_1:
	ldr	x9, [sp, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #24]
	b	LBB46_2
LBB46_2:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddBoolToObject          ; -- Begin function cJSON_AddBoolToObject
	.p2align	2
_cJSON_AddBoolToObject:                 ; @cJSON_AddBoolToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	w2, [sp, #20]
	ldr	w0, [sp, #20]
	bl	_cJSON_CreateBool
	str	x0, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #8]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB47_2
	b	LBB47_1
LBB47_1:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB47_3
LBB47_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB47_3
LBB47_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateBool               ; -- Begin function cJSON_CreateBool
	.p2align	2
_cJSON_CreateBool:                      ; @cJSON_CreateBool
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-4]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB48_2
	b	LBB48_1
LBB48_1:
	ldur	w9, [x29, #-4]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #0
	csinc	w8, w8, wzr, ne
	ldr	x9, [sp]
	str	w8, [x9, #24]
	b	LBB48_2
LBB48_2:
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddNumberToObject        ; -- Begin function cJSON_AddNumberToObject
	.p2align	2
_cJSON_AddNumberToObject:               ; @cJSON_AddNumberToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	d0, [sp, #16]
	ldr	d0, [sp, #16]
	bl	_cJSON_CreateNumber
	str	x0, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #8]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB49_2
	b	LBB49_1
LBB49_1:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB49_3
LBB49_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB49_3
LBB49_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateNumber             ; -- Begin function cJSON_CreateNumber
	.p2align	2
_cJSON_CreateNumber:                    ; @cJSON_CreateNumber
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	d0, [sp, #8]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB50_8
	b	LBB50_1
LBB50_1:
	ldr	x9, [sp]
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #24]
	ldr	d0, [sp, #8]
	ldr	x8, [sp]
	str	d0, [x8, #48]
	ldr	d0, [sp, #8]
	mov	x8, #281474972516352            ; =0xffffffc00000
	movk	x8, #16863, lsl #48
	fmov	d1, x8
	fcmp	d0, d1
	b.lt	LBB50_3
	b	LBB50_2
LBB50_2:
	ldr	x9, [sp]
	mov	w8, #2147483647                 ; =0x7fffffff
	str	w8, [x9, #40]
	b	LBB50_7
LBB50_3:
	ldr	d0, [sp, #8]
	mov	x8, #-4476578029606273024       ; =0xc1e0000000000000
	fmov	d1, x8
	fcmp	d0, d1
	b.hi	LBB50_5
	b	LBB50_4
LBB50_4:
	ldr	x9, [sp]
	mov	w8, #-2147483648                ; =0x80000000
	str	w8, [x9, #40]
	b	LBB50_6
LBB50_5:
	ldr	d0, [sp, #8]
	fcvtzs	w8, d0
	ldr	x9, [sp]
	str	w8, [x9, #40]
	b	LBB50_6
LBB50_6:
	b	LBB50_7
LBB50_7:
	b	LBB50_8
LBB50_8:
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddStringToObject        ; -- Begin function cJSON_AddStringToObject
	.p2align	2
_cJSON_AddStringToObject:               ; @cJSON_AddStringToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_cJSON_CreateString
	str	x0, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #8]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB51_2
	b	LBB51_1
LBB51_1:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB51_3
LBB51_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB51_3
LBB51_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateString             ; -- Begin function cJSON_CreateString
	.p2align	2
_cJSON_CreateString:                    ; @cJSON_CreateString
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB52_4
	b	LBB52_1
LBB52_1:
	ldr	x9, [sp, #8]
	mov	w8, #16                         ; =0x10
	str	w8, [x9, #24]
	ldr	x0, [sp, #16]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_cJSON_strdup
	ldr	x8, [sp, #8]
	str	x0, [x8, #32]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB52_3
	b	LBB52_2
LBB52_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB52_5
LBB52_3:
	b	LBB52_4
LBB52_4:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB52_5
LBB52_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddRawToObject           ; -- Begin function cJSON_AddRawToObject
	.p2align	2
_cJSON_AddRawToObject:                  ; @cJSON_AddRawToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_cJSON_CreateRaw
	str	x0, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #8]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB53_2
	b	LBB53_1
LBB53_1:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB53_3
LBB53_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB53_3
LBB53_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateRaw                ; -- Begin function cJSON_CreateRaw
	.p2align	2
_cJSON_CreateRaw:                       ; @cJSON_CreateRaw
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB54_4
	b	LBB54_1
LBB54_1:
	ldr	x9, [sp, #8]
	mov	w8, #128                        ; =0x80
	str	w8, [x9, #24]
	ldr	x0, [sp, #16]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_cJSON_strdup
	ldr	x8, [sp, #8]
	str	x0, [x8, #32]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB54_3
	b	LBB54_2
LBB54_2:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB54_5
LBB54_3:
	b	LBB54_4
LBB54_4:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB54_5
LBB54_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddObjectToObject        ; -- Begin function cJSON_AddObjectToObject
	.p2align	2
_cJSON_AddObjectToObject:               ; @cJSON_AddObjectToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	bl	_cJSON_CreateObject
	str	x0, [sp]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB55_2
	b	LBB55_1
LBB55_1:
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB55_3
LBB55_2:
	ldr	x0, [sp]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB55_3
LBB55_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateObject             ; -- Begin function cJSON_CreateObject
	.p2align	2
_cJSON_CreateObject:                    ; @cJSON_CreateObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB56_2
	b	LBB56_1
LBB56_1:
	ldr	x9, [sp, #8]
	mov	w8, #64                         ; =0x40
	str	w8, [x9, #24]
	b	LBB56_2
LBB56_2:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_AddArrayToObject         ; -- Begin function cJSON_AddArrayToObject
	.p2align	2
_cJSON_AddArrayToObject:                ; @cJSON_AddArrayToObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	bl	_cJSON_CreateArray
	str	x0, [sp]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp]
	adrp	x3, _global_hooks@PAGE
	add	x3, x3, _global_hooks@PAGEOFF
	mov	w4, #0                          ; =0x0
	bl	_add_item_to_object
	cbz	w0, LBB57_2
	b	LBB57_1
LBB57_1:
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB57_3
LBB57_2:
	ldr	x0, [sp]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB57_3
LBB57_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateArray              ; -- Begin function cJSON_CreateArray
	.p2align	2
_cJSON_CreateArray:                     ; @cJSON_CreateArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB58_2
	b	LBB58_1
LBB58_1:
	ldr	x9, [sp, #8]
	mov	w8, #32                         ; =0x20
	str	w8, [x9, #24]
	b	LBB58_2
LBB58_2:
	ldr	x0, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DetachItemViaPointer     ; -- Begin function cJSON_DetachItemViaPointer
	.p2align	2
_cJSON_DetachItemViaPointer:            ; @cJSON_DetachItemViaPointer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB59_4
	b	LBB59_1
LBB59_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB59_4
	b	LBB59_2
LBB59_2:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.eq	LBB59_5
	b	LBB59_3
LBB59_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB59_5
	b	LBB59_4
LBB59_4:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB59_15
LBB59_5:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.eq	LBB59_7
	b	LBB59_6
LBB59_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	str	x8, [x9]
	b	LBB59_7
LBB59_7:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbz	x8, LBB59_9
	b	LBB59_8
LBB59_8:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	str	x8, [x9, #8]
	b	LBB59_9
LBB59_9:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.ne	LBB59_11
	b	LBB59_10
LBB59_10:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	str	x8, [x9, #16]
	b	LBB59_14
LBB59_11:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB59_13
	b	LBB59_12
LBB59_12:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB59_13
LBB59_13:
	b	LBB59_14
LBB59_14:
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #8]
	ldr	x8, [sp, #8]
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	b	LBB59_15
LBB59_15:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DetachItemFromArray      ; -- Begin function cJSON_DetachItemFromArray
	.p2align	2
_cJSON_DetachItemFromArray:             ; @cJSON_DetachItemFromArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB60_2
	b	LBB60_1
LBB60_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB60_3
LBB60_2:
	ldr	x8, [sp, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [sp, #16]
	ldrsw	x1, [sp, #12]
	bl	_get_array_item
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_cJSON_DetachItemViaPointer
	stur	x0, [x29, #-8]
	b	LBB60_3
LBB60_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DeleteItemFromArray      ; -- Begin function cJSON_DeleteItemFromArray
	.p2align	2
_cJSON_DeleteItemFromArray:             ; @cJSON_DeleteItemFromArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_cJSON_DetachItemFromArray
	bl	_cJSON_Delete
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DetachItemFromObject     ; -- Begin function cJSON_DetachItemFromObject
	.p2align	2
_cJSON_DetachItemFromObject:            ; @cJSON_DetachItemFromObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_cJSON_GetObjectItem
	str	x0, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	bl	_cJSON_DetachItemViaPointer
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DetachItemFromObjectCaseSensitive ; -- Begin function cJSON_DetachItemFromObjectCaseSensitive
	.p2align	2
_cJSON_DetachItemFromObjectCaseSensitive: ; @cJSON_DetachItemFromObjectCaseSensitive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	bl	_cJSON_DetachItemViaPointer
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DeleteItemFromObject     ; -- Begin function cJSON_DeleteItemFromObject
	.p2align	2
_cJSON_DeleteItemFromObject:            ; @cJSON_DeleteItemFromObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	_cJSON_DetachItemFromObject
	bl	_cJSON_Delete
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_DeleteItemFromObjectCaseSensitive ; -- Begin function cJSON_DeleteItemFromObjectCaseSensitive
	.p2align	2
_cJSON_DeleteItemFromObjectCaseSensitive: ; @cJSON_DeleteItemFromObjectCaseSensitive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	_cJSON_DetachItemFromObjectCaseSensitive
	bl	_cJSON_Delete
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_InsertItemInArray        ; -- Begin function cJSON_InsertItemInArray
	.p2align	2
_cJSON_InsertItemInArray:               ; @cJSON_InsertItemInArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	ldur	w8, [x29, #-20]
	tbnz	w8, #31, LBB66_2
	b	LBB66_1
LBB66_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB66_3
	b	LBB66_2
LBB66_2:
	stur	wzr, [x29, #-4]
	b	LBB66_12
LBB66_3:
	ldur	x0, [x29, #-16]
	ldursw	x1, [x29, #-20]
	bl	_get_array_item
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB66_5
	b	LBB66_4
LBB66_4:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #16]
	bl	_add_item_to_array
	stur	w0, [x29, #-4]
	b	LBB66_12
LBB66_5:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.eq	LBB66_8
	b	LBB66_6
LBB66_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB66_8
	b	LBB66_7
LBB66_7:
	stur	wzr, [x29, #-4]
	b	LBB66_12
LBB66_8:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	str	x8, [x9, #8]
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.ne	LBB66_10
	b	LBB66_9
LBB66_9:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #16]
	b	LBB66_11
LBB66_10:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	str	x8, [x9]
	b	LBB66_11
LBB66_11:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB66_12
LBB66_12:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ReplaceItemViaPointer    ; -- Begin function cJSON_ReplaceItemViaPointer
	.p2align	2
_cJSON_ReplaceItemViaPointer:           ; @cJSON_ReplaceItemViaPointer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB67_4
	b	LBB67_1
LBB67_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	cbz	x8, LBB67_4
	b	LBB67_2
LBB67_2:
	ldr	x8, [sp]
	cbz	x8, LBB67_4
	b	LBB67_3
LBB67_3:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB67_5
	b	LBB67_4
LBB67_4:
	stur	wzr, [x29, #-4]
	b	LBB67_19
LBB67_5:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB67_7
	b	LBB67_6
LBB67_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB67_19
LBB67_7:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp]
	str	x8, [x9, #8]
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB67_9
	b	LBB67_8
LBB67_8:
	ldr	x8, [sp]
	ldr	x9, [sp]
	ldr	x9, [x9]
	str	x8, [x9, #8]
	b	LBB67_9
LBB67_9:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB67_13
	b	LBB67_10
LBB67_10:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.ne	LBB67_12
	b	LBB67_11
LBB67_11:
	ldr	x8, [sp]
	ldr	x9, [sp]
	str	x8, [x9, #8]
	b	LBB67_12
LBB67_12:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	str	x8, [x9, #16]
	b	LBB67_18
LBB67_13:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	cbz	x8, LBB67_15
	b	LBB67_14
LBB67_14:
	ldr	x8, [sp]
	ldr	x9, [sp]
	ldr	x9, [x9, #8]
	str	x8, [x9]
	b	LBB67_15
LBB67_15:
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbnz	x8, LBB67_17
	b	LBB67_16
LBB67_16:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB67_17
LBB67_17:
	b	LBB67_18
LBB67_18:
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #8]
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB67_19
LBB67_19:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ReplaceItemInArray       ; -- Begin function cJSON_ReplaceItemInArray
	.p2align	2
_cJSON_ReplaceItemInArray:              ; @cJSON_ReplaceItemInArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
	ldur	w8, [x29, #-20]
	tbz	w8, #31, LBB68_2
	b	LBB68_1
LBB68_1:
	stur	wzr, [x29, #-4]
	b	LBB68_3
LBB68_2:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	ldursw	x1, [x29, #-20]
	bl	_get_array_item
	mov	x1, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #16]
	bl	_cJSON_ReplaceItemViaPointer
	stur	w0, [x29, #-4]
	b	LBB68_3
LBB68_3:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ReplaceItemInObject      ; -- Begin function cJSON_ReplaceItemInObject
	.p2align	2
_cJSON_ReplaceItemInObject:             ; @cJSON_ReplaceItemInObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	w3, #0                          ; =0x0
	bl	_replace_item_in_object
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function replace_item_in_object
_replace_item_in_object:                ; @replace_item_in_object
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	str	w3, [sp, #12]
	ldr	x8, [sp, #16]
	cbz	x8, LBB70_2
	b	LBB70_1
LBB70_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB70_3
	b	LBB70_2
LBB70_2:
	stur	wzr, [x29, #-4]
	b	LBB70_9
LBB70_3:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #24]
	tbnz	w8, #9, LBB70_6
	b	LBB70_4
LBB70_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	cbz	x8, LBB70_6
	b	LBB70_5
LBB70_5:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #56]
	bl	_cJSON_free
	b	LBB70_6
LBB70_6:
	ldr	x0, [sp, #24]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_cJSON_strdup
	ldr	x8, [sp, #16]
	str	x0, [x8, #56]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB70_8
	b	LBB70_7
LBB70_7:
	stur	wzr, [x29, #-4]
	b	LBB70_9
LBB70_8:
	ldr	x9, [sp, #16]
	ldr	w8, [x9, #24]
	and	w8, w8, #0xfffffdff
	str	w8, [x9, #24]
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	w2, [sp, #12]
	bl	_get_object_item
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #16]
	bl	_cJSON_ReplaceItemViaPointer
	stur	w0, [x29, #-4]
	b	LBB70_9
LBB70_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_ReplaceItemInObjectCaseSensitive ; -- Begin function cJSON_ReplaceItemInObjectCaseSensitive
	.p2align	2
_cJSON_ReplaceItemInObjectCaseSensitive: ; @cJSON_ReplaceItemInObjectCaseSensitive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	w3, #1                          ; =0x1
	bl	_replace_item_in_object
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateStringReference    ; -- Begin function cJSON_CreateStringReference
	.p2align	2
_cJSON_CreateStringReference:           ; @cJSON_CreateStringReference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB72_2
	b	LBB72_1
LBB72_1:
	ldr	x9, [sp]
	mov	w8, #272                        ; =0x110
	str	w8, [x9, #24]
	ldr	x0, [sp, #8]
	bl	_cast_away_const
	ldr	x8, [sp]
	str	x0, [x8, #32]
	b	LBB72_2
LBB72_2:
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function cast_away_const
_cast_away_const:                       ; @cast_away_const
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateObjectReference    ; -- Begin function cJSON_CreateObjectReference
	.p2align	2
_cJSON_CreateObjectReference:           ; @cJSON_CreateObjectReference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB74_2
	b	LBB74_1
LBB74_1:
	ldr	x9, [sp]
	mov	w8, #320                        ; =0x140
	str	w8, [x9, #24]
	ldr	x0, [sp, #8]
	bl	_cast_away_const
	ldr	x8, [sp]
	str	x0, [x8, #16]
	b	LBB74_2
LBB74_2:
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateArrayReference     ; -- Begin function cJSON_CreateArrayReference
	.p2align	2
_cJSON_CreateArrayReference:            ; @cJSON_CreateArrayReference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB75_2
	b	LBB75_1
LBB75_1:
	ldr	x9, [sp]
	mov	w8, #288                        ; =0x120
	str	w8, [x9, #24]
	ldr	x0, [sp, #8]
	bl	_cast_away_const
	ldr	x8, [sp]
	str	x0, [x8, #16]
	b	LBB75_2
LBB75_2:
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateIntArray           ; -- Begin function cJSON_CreateIntArray
	.p2align	2
_cJSON_CreateIntArray:                  ; @cJSON_CreateIntArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	xzr, [sp, #32]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	w8, [x29, #-20]
	tbnz	w8, #31, LBB76_2
	b	LBB76_1
LBB76_1:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB76_3
	b	LBB76_2
LBB76_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB76_18
LBB76_3:
	bl	_cJSON_CreateArray
	str	x0, [sp, #8]
	str	xzr, [sp, #32]
	b	LBB76_4
LBB76_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB76_6
	b	LBB76_5
LBB76_5:                                ;   in Loop: Header=BB76_4 Depth=1
	ldr	x8, [sp, #32]
	ldursw	x9, [x29, #-20]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB76_6
LBB76_6:                                ;   in Loop: Header=BB76_4 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB76_14
	b	LBB76_7
LBB76_7:                                ;   in Loop: Header=BB76_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldr	s1, [x8, x9, lsl #2]
                                        ; implicit-def: $d0
	mov.16b	v0, v1
	sshll.2d	v0, v0, #0
                                        ; kill: def $d0 killed $d0 killed $q0
	scvtf	d0, d0
	bl	_cJSON_CreateNumber
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB76_9
	b	LBB76_8
LBB76_8:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB76_18
LBB76_9:                                ;   in Loop: Header=BB76_4 Depth=1
	ldr	x8, [sp, #32]
	cbnz	x8, LBB76_11
	b	LBB76_10
LBB76_10:                               ;   in Loop: Header=BB76_4 Depth=1
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	str	x8, [x9, #16]
	b	LBB76_12
LBB76_11:                               ;   in Loop: Header=BB76_4 Depth=1
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_suffix_object
	b	LBB76_12
LBB76_12:                               ;   in Loop: Header=BB76_4 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #16]
	b	LBB76_13
LBB76_13:                               ;   in Loop: Header=BB76_4 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB76_4
LBB76_14:
	ldr	x8, [sp, #8]
	cbz	x8, LBB76_17
	b	LBB76_15
LBB76_15:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB76_17
	b	LBB76_16
LBB76_16:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB76_17
LBB76_17:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB76_18
LBB76_18:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function suffix_object
_suffix_object:                         ; @suffix_object
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldr	x9, [sp]
	str	x8, [x9, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateFloatArray         ; -- Begin function cJSON_CreateFloatArray
	.p2align	2
_cJSON_CreateFloatArray:                ; @cJSON_CreateFloatArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	xzr, [sp, #32]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	w8, [x29, #-20]
	tbnz	w8, #31, LBB78_2
	b	LBB78_1
LBB78_1:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB78_3
	b	LBB78_2
LBB78_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB78_18
LBB78_3:
	bl	_cJSON_CreateArray
	str	x0, [sp, #8]
	str	xzr, [sp, #32]
	b	LBB78_4
LBB78_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB78_6
	b	LBB78_5
LBB78_5:                                ;   in Loop: Header=BB78_4 Depth=1
	ldr	x8, [sp, #32]
	ldursw	x9, [x29, #-20]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB78_6
LBB78_6:                                ;   in Loop: Header=BB78_4 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB78_14
	b	LBB78_7
LBB78_7:                                ;   in Loop: Header=BB78_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldr	s0, [x8, x9, lsl #2]
	fcvt	d0, s0
	bl	_cJSON_CreateNumber
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB78_9
	b	LBB78_8
LBB78_8:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB78_18
LBB78_9:                                ;   in Loop: Header=BB78_4 Depth=1
	ldr	x8, [sp, #32]
	cbnz	x8, LBB78_11
	b	LBB78_10
LBB78_10:                               ;   in Loop: Header=BB78_4 Depth=1
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	str	x8, [x9, #16]
	b	LBB78_12
LBB78_11:                               ;   in Loop: Header=BB78_4 Depth=1
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_suffix_object
	b	LBB78_12
LBB78_12:                               ;   in Loop: Header=BB78_4 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #16]
	b	LBB78_13
LBB78_13:                               ;   in Loop: Header=BB78_4 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB78_4
LBB78_14:
	ldr	x8, [sp, #8]
	cbz	x8, LBB78_17
	b	LBB78_15
LBB78_15:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB78_17
	b	LBB78_16
LBB78_16:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB78_17
LBB78_17:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB78_18
LBB78_18:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateDoubleArray        ; -- Begin function cJSON_CreateDoubleArray
	.p2align	2
_cJSON_CreateDoubleArray:               ; @cJSON_CreateDoubleArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	xzr, [sp, #32]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	w8, [x29, #-20]
	tbnz	w8, #31, LBB79_2
	b	LBB79_1
LBB79_1:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB79_3
	b	LBB79_2
LBB79_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB79_18
LBB79_3:
	bl	_cJSON_CreateArray
	str	x0, [sp, #8]
	str	xzr, [sp, #32]
	b	LBB79_4
LBB79_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB79_6
	b	LBB79_5
LBB79_5:                                ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [sp, #32]
	ldursw	x9, [x29, #-20]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB79_6
LBB79_6:                                ;   in Loop: Header=BB79_4 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB79_14
	b	LBB79_7
LBB79_7:                                ;   in Loop: Header=BB79_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldr	d0, [x8, x9, lsl #3]
	bl	_cJSON_CreateNumber
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB79_9
	b	LBB79_8
LBB79_8:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB79_18
LBB79_9:                                ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [sp, #32]
	cbnz	x8, LBB79_11
	b	LBB79_10
LBB79_10:                               ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	str	x8, [x9, #16]
	b	LBB79_12
LBB79_11:                               ;   in Loop: Header=BB79_4 Depth=1
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_suffix_object
	b	LBB79_12
LBB79_12:                               ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #16]
	b	LBB79_13
LBB79_13:                               ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB79_4
LBB79_14:
	ldr	x8, [sp, #8]
	cbz	x8, LBB79_17
	b	LBB79_15
LBB79_15:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB79_17
	b	LBB79_16
LBB79_16:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB79_17
LBB79_17:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB79_18
LBB79_18:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_CreateStringArray        ; -- Begin function cJSON_CreateStringArray
	.p2align	2
_cJSON_CreateStringArray:               ; @cJSON_CreateStringArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	xzr, [sp, #32]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	w8, [x29, #-20]
	tbnz	w8, #31, LBB80_2
	b	LBB80_1
LBB80_1:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB80_3
	b	LBB80_2
LBB80_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB80_18
LBB80_3:
	bl	_cJSON_CreateArray
	str	x0, [sp, #8]
	str	xzr, [sp, #32]
	b	LBB80_4
LBB80_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB80_6
	b	LBB80_5
LBB80_5:                                ;   in Loop: Header=BB80_4 Depth=1
	ldr	x8, [sp, #32]
	ldursw	x9, [x29, #-20]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB80_6
LBB80_6:                                ;   in Loop: Header=BB80_4 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB80_14
	b	LBB80_7
LBB80_7:                                ;   in Loop: Header=BB80_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldr	x0, [x8, x9, lsl #3]
	bl	_cJSON_CreateString
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB80_9
	b	LBB80_8
LBB80_8:
	ldr	x0, [sp, #8]
	bl	_cJSON_Delete
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB80_18
LBB80_9:                                ;   in Loop: Header=BB80_4 Depth=1
	ldr	x8, [sp, #32]
	cbnz	x8, LBB80_11
	b	LBB80_10
LBB80_10:                               ;   in Loop: Header=BB80_4 Depth=1
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	str	x8, [x9, #16]
	b	LBB80_12
LBB80_11:                               ;   in Loop: Header=BB80_4 Depth=1
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_suffix_object
	b	LBB80_12
LBB80_12:                               ;   in Loop: Header=BB80_4 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #16]
	b	LBB80_13
LBB80_13:                               ;   in Loop: Header=BB80_4 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB80_4
LBB80_14:
	ldr	x8, [sp, #8]
	cbz	x8, LBB80_17
	b	LBB80_15
LBB80_15:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB80_17
	b	LBB80_16
LBB80_16:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB80_17
LBB80_17:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB80_18
LBB80_18:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Duplicate                ; -- Begin function cJSON_Duplicate
	.p2align	2
_cJSON_Duplicate:                       ; @cJSON_Duplicate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w2, [sp, #4]
	mov	x1, #0                          ; =0x0
	bl	_cJSON_Duplicate_rec
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Duplicate_rec            ; -- Begin function cJSON_Duplicate_rec
	.p2align	2
_cJSON_Duplicate_rec:                   ; @cJSON_Duplicate_rec
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB82_2
	b	LBB82_1
LBB82_1:
	b	LBB82_31
LBB82_2:
	adrp	x0, _global_hooks@PAGE
	add	x0, x0, _global_hooks@PAGEOFF
	bl	_cJSON_New_Item
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB82_4
	b	LBB82_3
LBB82_3:
	b	LBB82_31
LBB82_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	and	w8, w8, #0xfffffeff
	ldr	x9, [sp, #40]
	str	w8, [x9, #24]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #40]
	ldr	x9, [sp, #40]
	str	w8, [x9, #40]
	ldur	x8, [x29, #-16]
	ldr	d0, [x8, #48]
	ldr	x8, [sp, #40]
	str	d0, [x8, #48]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	cbz	x8, LBB82_8
	b	LBB82_5
LBB82_5:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #32]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_cJSON_strdup
	ldr	x8, [sp, #40]
	str	x0, [x8, #32]
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB82_7
	b	LBB82_6
LBB82_6:
	b	LBB82_31
LBB82_7:
	b	LBB82_8
LBB82_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	cbz	x8, LBB82_15
	b	LBB82_9
LBB82_9:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	tbz	w8, #9, LBB82_11
	b	LBB82_10
LBB82_10:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #56]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB82_12
LBB82_11:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #56]
	adrp	x1, _global_hooks@PAGE
	add	x1, x1, _global_hooks@PAGEOFF
	bl	_cJSON_strdup
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB82_12
LBB82_12:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp, #40]
	str	x8, [x9, #56]
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB82_14
	b	LBB82_13
LBB82_13:
	b	LBB82_31
LBB82_14:
	b	LBB82_15
LBB82_15:
	ldur	w8, [x29, #-28]
	cbnz	w8, LBB82_17
	b	LBB82_16
LBB82_16:
	ldr	x8, [sp, #40]
	stur	x8, [x29, #-8]
	b	LBB82_34
LBB82_17:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #32]
	b	LBB82_18
LBB82_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	cbz	x8, LBB82_27
	b	LBB82_19
LBB82_19:                               ;   in Loop: Header=BB82_18 Depth=1
	ldur	x8, [x29, #-24]
	mov	x9, #10000                      ; =0x2710
	subs	x8, x8, x9
	b.lo	LBB82_21
	b	LBB82_20
LBB82_20:
	b	LBB82_31
LBB82_21:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x0, [sp, #32]
	ldur	x8, [x29, #-24]
	add	x1, x8, #1
	mov	w2, #1                          ; =0x1
	bl	_cJSON_Duplicate_rec
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB82_23
	b	LBB82_22
LBB82_22:
	b	LBB82_31
LBB82_23:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x8, [sp, #24]
	cbz	x8, LBB82_25
	b	LBB82_24
LBB82_24:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB82_26
LBB82_25:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #40]
	str	x8, [x9, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB82_26
LBB82_26:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	str	x8, [sp, #32]
	b	LBB82_18
LBB82_27:
	ldr	x8, [sp, #40]
	cbz	x8, LBB82_30
	b	LBB82_28
LBB82_28:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #16]
	cbz	x8, LBB82_30
	b	LBB82_29
LBB82_29:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #16]
	str	x8, [x9, #8]
	b	LBB82_30
LBB82_30:
	ldr	x8, [sp, #40]
	stur	x8, [x29, #-8]
	b	LBB82_34
LBB82_31:
	ldr	x8, [sp, #40]
	cbz	x8, LBB82_33
	b	LBB82_32
LBB82_32:
	ldr	x0, [sp, #40]
	bl	_cJSON_Delete
	b	LBB82_33
LBB82_33:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB82_34
LBB82_34:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Minify                   ; -- Begin function cJSON_Minify
	.p2align	2
_cJSON_Minify:                          ; @cJSON_Minify
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB83_2
	b	LBB83_1
LBB83_1:
	b	LBB83_21
LBB83_2:
	b	LBB83_3
LBB83_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-8]
	ldrsb	w8, [x8]
	cbz	w8, LBB83_20
	b	LBB83_4
LBB83_4:                                ;   in Loop: Header=BB83_3 Depth=1
	ldur	x8, [x29, #-8]
	ldrsb	w8, [x8]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	subs	w8, w8, #9
	subs	w8, w8, #1
	b.ls	LBB83_9
	b	LBB83_5
LBB83_5:                                ;   in Loop: Header=BB83_3 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB83_9
	b	LBB83_6
LBB83_6:                                ;   in Loop: Header=BB83_3 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #32
	b.eq	LBB83_9
	b	LBB83_7
LBB83_7:                                ;   in Loop: Header=BB83_3 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #34
	b.eq	LBB83_17
	b	LBB83_8
LBB83_8:                                ;   in Loop: Header=BB83_3 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #47
	b.eq	LBB83_10
	b	LBB83_18
LBB83_9:                                ;   in Loop: Header=BB83_3 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #1
	stur	x8, [x29, #-8]
	b	LBB83_19
LBB83_10:                               ;   in Loop: Header=BB83_3 Depth=1
	ldur	x8, [x29, #-8]
	ldrsb	w8, [x8, #1]
	subs	w8, w8, #47
	b.ne	LBB83_12
	b	LBB83_11
LBB83_11:                               ;   in Loop: Header=BB83_3 Depth=1
	sub	x0, x29, #8
	bl	_skip_oneline_comment
	b	LBB83_16
LBB83_12:                               ;   in Loop: Header=BB83_3 Depth=1
	ldur	x8, [x29, #-8]
	ldrsb	w8, [x8, #1]
	subs	w8, w8, #42
	b.ne	LBB83_14
	b	LBB83_13
LBB83_13:                               ;   in Loop: Header=BB83_3 Depth=1
	sub	x0, x29, #8
	bl	_skip_multiline_comment
	b	LBB83_15
LBB83_14:                               ;   in Loop: Header=BB83_3 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #1
	stur	x8, [x29, #-8]
	b	LBB83_15
LBB83_15:                               ;   in Loop: Header=BB83_3 Depth=1
	b	LBB83_16
LBB83_16:                               ;   in Loop: Header=BB83_3 Depth=1
	b	LBB83_19
LBB83_17:                               ;   in Loop: Header=BB83_3 Depth=1
	sub	x0, x29, #8
	add	x1, sp, #16
	bl	_minify_string
	b	LBB83_19
LBB83_18:                               ;   in Loop: Header=BB83_3 Depth=1
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #16]
	strb	w8, [x9]
	ldur	x8, [x29, #-8]
	add	x8, x8, #1
	stur	x8, [x29, #-8]
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB83_19
LBB83_19:                               ;   in Loop: Header=BB83_3 Depth=1
	b	LBB83_3
LBB83_20:
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	b	LBB83_21
LBB83_21:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function skip_oneline_comment
_skip_oneline_comment:                  ; @skip_oneline_comment
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #2
	str	x8, [x9]
	b	LBB84_1
LBB84_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	cbz	w8, LBB84_6
	b	LBB84_2
LBB84_2:                                ;   in Loop: Header=BB84_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB84_4
	b	LBB84_3
LBB84_3:
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB84_6
LBB84_4:                                ;   in Loop: Header=BB84_1 Depth=1
	b	LBB84_5
LBB84_5:                                ;   in Loop: Header=BB84_1 Depth=1
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB84_1
LBB84_6:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function skip_multiline_comment
_skip_multiline_comment:                ; @skip_multiline_comment
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #2
	str	x8, [x9]
	b	LBB85_1
LBB85_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	cbz	w8, LBB85_7
	b	LBB85_2
LBB85_2:                                ;   in Loop: Header=BB85_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #42
	b.ne	LBB85_5
	b	LBB85_3
LBB85_3:                                ;   in Loop: Header=BB85_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8, #1]
	subs	w8, w8, #47
	b.ne	LBB85_5
	b	LBB85_4
LBB85_4:
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #2
	str	x8, [x9]
	b	LBB85_7
LBB85_5:                                ;   in Loop: Header=BB85_1 Depth=1
	b	LBB85_6
LBB85_6:                                ;   in Loop: Header=BB85_1 Depth=1
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB85_1
LBB85_7:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function minify_string
_minify_string:                         ; @minify_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrb	w8, [x8]
	ldr	x9, [sp]
	ldr	x9, [x9]
	strb	w8, [x9]
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	ldr	x9, [sp]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB86_1
LBB86_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	cbz	w8, LBB86_10
	b	LBB86_2
LBB86_2:                                ;   in Loop: Header=BB86_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrb	w8, [x8]
	ldr	x9, [sp]
	ldr	x9, [x9]
	strb	w8, [x9]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #34
	b.ne	LBB86_4
	b	LBB86_3
LBB86_3:
	ldr	x8, [sp]
	ldr	x9, [x8]
	mov	w8, #34                         ; =0x22
	strb	w8, [x9]
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	ldr	x9, [sp]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB86_10
LBB86_4:                                ;   in Loop: Header=BB86_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #92
	b.ne	LBB86_7
	b	LBB86_5
LBB86_5:                                ;   in Loop: Header=BB86_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8, #1]
	subs	w8, w8, #34
	b.ne	LBB86_7
	b	LBB86_6
LBB86_6:                                ;   in Loop: Header=BB86_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrb	w8, [x8, #1]
	ldr	x9, [sp]
	ldr	x9, [x9]
	strb	w8, [x9, #1]
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	ldr	x9, [sp]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB86_7
LBB86_7:                                ;   in Loop: Header=BB86_1 Depth=1
	b	LBB86_8
LBB86_8:                                ;   in Loop: Header=BB86_1 Depth=1
	b	LBB86_9
LBB86_9:                                ;   in Loop: Header=BB86_1 Depth=1
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	ldr	x9, [sp]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB86_1
LBB86_10:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsInvalid                ; -- Begin function cJSON_IsInvalid
	.p2align	2
_cJSON_IsInvalid:                       ; @cJSON_IsInvalid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB87_2
	b	LBB87_1
LBB87_1:
	str	wzr, [sp, #12]
	b	LBB87_3
LBB87_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB87_3
LBB87_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsFalse                  ; -- Begin function cJSON_IsFalse
	.p2align	2
_cJSON_IsFalse:                         ; @cJSON_IsFalse
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB88_2
	b	LBB88_1
LBB88_1:
	str	wzr, [sp, #12]
	b	LBB88_3
LBB88_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB88_3
LBB88_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsTrue                   ; -- Begin function cJSON_IsTrue
	.p2align	2
_cJSON_IsTrue:                          ; @cJSON_IsTrue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB89_2
	b	LBB89_1
LBB89_1:
	str	wzr, [sp, #12]
	b	LBB89_3
LBB89_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB89_3
LBB89_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsBool                   ; -- Begin function cJSON_IsBool
	.p2align	2
_cJSON_IsBool:                          ; @cJSON_IsBool
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB90_2
	b	LBB90_1
LBB90_1:
	str	wzr, [sp, #12]
	b	LBB90_3
LBB90_2:
	ldr	x8, [sp]
	ldr	w8, [x8, #24]
	ands	w8, w8, #0x3
	cset	w8, ne
	str	w8, [sp, #12]
	b	LBB90_3
LBB90_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsNull                   ; -- Begin function cJSON_IsNull
	.p2align	2
_cJSON_IsNull:                          ; @cJSON_IsNull
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB91_2
	b	LBB91_1
LBB91_1:
	str	wzr, [sp, #12]
	b	LBB91_3
LBB91_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #4
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB91_3
LBB91_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsArray                  ; -- Begin function cJSON_IsArray
	.p2align	2
_cJSON_IsArray:                         ; @cJSON_IsArray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB92_2
	b	LBB92_1
LBB92_1:
	str	wzr, [sp, #12]
	b	LBB92_3
LBB92_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #32
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB92_3
LBB92_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsObject                 ; -- Begin function cJSON_IsObject
	.p2align	2
_cJSON_IsObject:                        ; @cJSON_IsObject
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB93_2
	b	LBB93_1
LBB93_1:
	str	wzr, [sp, #12]
	b	LBB93_3
LBB93_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #64
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB93_3
LBB93_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_IsRaw                    ; -- Begin function cJSON_IsRaw
	.p2align	2
_cJSON_IsRaw:                           ; @cJSON_IsRaw
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB94_2
	b	LBB94_1
LBB94_1:
	str	wzr, [sp, #12]
	b	LBB94_3
LBB94_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #128
	cset	w8, eq
	str	w8, [sp, #12]
	b	LBB94_3
LBB94_3:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_Compare                  ; -- Begin function cJSON_Compare
	.p2align	2
_cJSON_Compare:                         ; @cJSON_Compare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB95_3
	b	LBB95_1
LBB95_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB95_3
	b	LBB95_2
LBB95_2:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #24]
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #24]
	subs	w8, w8, w9
	b.eq	LBB95_4
	b	LBB95_3
LBB95_3:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_4:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #24]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #1
	subs	w8, w8, #1
	b.ls	LBB95_11
	b	LBB95_5
LBB95_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB95_11
	b	LBB95_6
LBB95_6:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB95_11
	b	LBB95_7
LBB95_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #16
	b.eq	LBB95_11
	b	LBB95_8
LBB95_8:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #32
	b.eq	LBB95_11
	b	LBB95_9
LBB95_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #64
	b.eq	LBB95_11
	b	LBB95_10
LBB95_10:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #128
	b.ne	LBB95_12
	b	LBB95_11
LBB95_11:
	b	LBB95_13
LBB95_12:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_13:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.ne	LBB95_15
	b	LBB95_14
LBB95_14:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB95_66
LBB95_15:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #24]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	subs	w8, w8, #1
	subs	w8, w8, #1
	b.ls	LBB95_22
	b	LBB95_16
LBB95_16:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB95_22
	b	LBB95_17
LBB95_17:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB95_23
	b	LBB95_18
LBB95_18:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #16
	b.eq	LBB95_26
	b	LBB95_19
LBB95_19:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #32
	b.eq	LBB95_32
	b	LBB95_20
LBB95_20:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #64
	b.eq	LBB95_42
	b	LBB95_21
LBB95_21:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #128
	b.eq	LBB95_26
	b	LBB95_65
LBB95_22:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB95_66
LBB95_23:
	ldur	x8, [x29, #-16]
	ldr	d0, [x8, #48]
	ldur	x8, [x29, #-24]
	ldr	d1, [x8, #48]
	bl	_compare_double
	cbz	w0, LBB95_25
	b	LBB95_24
LBB95_24:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB95_66
LBB95_25:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_26:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	cbz	x8, LBB95_28
	b	LBB95_27
LBB95_27:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB95_29
	b	LBB95_28
LBB95_28:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_29:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #32]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	bl	_strcmp
	cbnz	w0, LBB95_31
	b	LBB95_30
LBB95_30:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB95_66
LBB95_31:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_32:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	str	x8, [sp, #48]
	b	LBB95_33
LBB95_33:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-40]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	x8, LBB95_35
	b	LBB95_34
LBB95_34:                               ;   in Loop: Header=BB95_33 Depth=1
	ldr	x8, [sp, #48]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB95_35
LBB95_35:                               ;   in Loop: Header=BB95_33 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB95_39
	b	LBB95_36
LBB95_36:                               ;   in Loop: Header=BB95_33 Depth=1
	ldur	x0, [x29, #-40]
	ldr	x1, [sp, #48]
	ldur	w2, [x29, #-28]
	bl	_cJSON_Compare
	cbnz	w0, LBB95_38
	b	LBB95_37
LBB95_37:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_38:                               ;   in Loop: Header=BB95_33 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	ldr	x8, [sp, #48]
	ldr	x8, [x8]
	str	x8, [sp, #48]
	b	LBB95_33
LBB95_39:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	subs	x8, x8, x9
	b.eq	LBB95_41
	b	LBB95_40
LBB95_40:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_41:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB95_66
LBB95_42:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB95_44
	b	LBB95_43
LBB95_43:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB95_45
LBB95_44:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB95_45
LBB95_45:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #40]
	b	LBB95_46
LBB95_46:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #40]
	cbz	x8, LBB95_53
	b	LBB95_47
LBB95_47:                               ;   in Loop: Header=BB95_46 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	ldr	x1, [x8, #56]
	ldur	w2, [x29, #-28]
	bl	_get_object_item
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB95_49
	b	LBB95_48
LBB95_48:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_49:                               ;   in Loop: Header=BB95_46 Depth=1
	ldr	x0, [sp, #40]
	ldr	x1, [sp, #32]
	ldur	w2, [x29, #-28]
	bl	_cJSON_Compare
	cbnz	w0, LBB95_51
	b	LBB95_50
LBB95_50:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_51:                               ;   in Loop: Header=BB95_46 Depth=1
	b	LBB95_52
LBB95_52:                               ;   in Loop: Header=BB95_46 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8]
	str	x8, [sp, #40]
	b	LBB95_46
LBB95_53:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB95_55
	b	LBB95_54
LBB95_54:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB95_56
LBB95_55:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB95_56
LBB95_56:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #32]
	b	LBB95_57
LBB95_57:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	cbz	x8, LBB95_64
	b	LBB95_58
LBB95_58:                               ;   in Loop: Header=BB95_57 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #32]
	ldr	x1, [x8, #56]
	ldur	w2, [x29, #-28]
	bl	_get_object_item
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB95_60
	b	LBB95_59
LBB95_59:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_60:                               ;   in Loop: Header=BB95_57 Depth=1
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	ldur	w2, [x29, #-28]
	bl	_cJSON_Compare
	cbnz	w0, LBB95_62
	b	LBB95_61
LBB95_61:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_62:                               ;   in Loop: Header=BB95_57 Depth=1
	b	LBB95_63
LBB95_63:                               ;   in Loop: Header=BB95_57 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	str	x8, [sp, #32]
	b	LBB95_57
LBB95_64:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB95_66
LBB95_65:
	stur	wzr, [x29, #-4]
	b	LBB95_66
LBB95_66:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function compare_double
_compare_double:                        ; @compare_double
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	d0, [sp, #24]
	str	d1, [sp, #16]
	ldr	d0, [sp, #24]
	fabs	d0, d0
	ldr	d1, [sp, #16]
	fabs	d1, d1
	fcmp	d0, d1
	b.le	LBB96_2
	b	LBB96_1
LBB96_1:
	ldr	d0, [sp, #24]
	fabs	d0, d0
	str	d0, [sp]                        ; 8-byte Folded Spill
	b	LBB96_3
LBB96_2:
	ldr	d0, [sp, #16]
	fabs	d0, d0
	str	d0, [sp]                        ; 8-byte Folded Spill
	b	LBB96_3
LBB96_3:
	ldr	d0, [sp]                        ; 8-byte Folded Reload
	str	d0, [sp, #8]
	ldr	d0, [sp, #24]
	ldr	d1, [sp, #16]
	fabd	d0, d0, d1
	ldr	d1, [sp, #8]
	mov	x8, #4372995238176751616        ; =0x3cb0000000000000
	fmov	d2, x8
	fmul	d1, d1, d2
	fcmp	d0, d1
	cset	w0, ls
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_cJSON_malloc                   ; -- Begin function cJSON_malloc
	.p2align	2
_cJSON_malloc:                          ; @cJSON_malloc
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	adrp	x8, _global_hooks@PAGE
	ldr	x8, [x8, _global_hooks@PAGEOFF]
	ldr	x0, [sp, #8]
	blr	x8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function update_offset
_update_offset:                         ; @update_offset
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, LBB98_2
	b	LBB98_1
LBB98_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB98_3
	b	LBB98_2
LBB98_2:
	b	LBB98_4
LBB98_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	str	x8, [sp]
	ldr	x0, [sp]
	bl	_strlen
	ldr	x9, [sp, #8]
	ldr	x8, [x9, #16]
	add	x8, x8, x0
	str	x8, [x9, #16]
	b	LBB98_4
LBB98_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_string
_parse_string:                          ; @parse_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	add	x8, x8, #1
	stur	x8, [x29, #-40]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #48]
	str	xzr, [sp, #40]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #34
	b.eq	LBB99_2
	b	LBB99_1
LBB99_1:
	b	LBB99_44
LBB99_2:
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	b	LBB99_3
LBB99_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x9, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.hs	LBB99_5
	b	LBB99_4
LBB99_4:                                ;   in Loop: Header=BB99_3 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8]
	subs	w8, w8, #34
	cset	w8, ne
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB99_5
LBB99_5:                                ;   in Loop: Header=BB99_3 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB99_11
	b	LBB99_6
LBB99_6:                                ;   in Loop: Header=BB99_3 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8]
	subs	w8, w8, #92
	b.ne	LBB99_10
	b	LBB99_7
LBB99_7:                                ;   in Loop: Header=BB99_3 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB99_9
	b	LBB99_8
LBB99_8:
	b	LBB99_44
LBB99_9:                                ;   in Loop: Header=BB99_3 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB99_10
LBB99_10:                               ;   in Loop: Header=BB99_3 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB99_3
LBB99_11:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB99_13
	b	LBB99_12
LBB99_12:
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8]
	subs	w8, w8, #34
	b.eq	LBB99_14
	b	LBB99_13
LBB99_13:
	b	LBB99_44
LBB99_14:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	ldur	x10, [x29, #-24]
	ldr	x10, [x10, #16]
	add	x9, x9, x10
	subs	x8, x8, x9
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #32]
	add	x0, x9, #1
	blr	x8
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB99_16
	b	LBB99_15
LBB99_15:
	b	LBB99_44
LBB99_16:
	ldr	x8, [sp, #40]
	str	x8, [sp, #48]
	b	LBB99_17
LBB99_17:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	subs	x8, x8, x9
	b.hs	LBB99_43
	b	LBB99_18
LBB99_18:                               ;   in Loop: Header=BB99_17 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	subs	w8, w8, #92
	b.eq	LBB99_20
	b	LBB99_19
LBB99_19:                               ;   in Loop: Header=BB99_17 Depth=1
	ldur	x8, [x29, #-32]
	add	x9, x8, #1
	stur	x9, [x29, #-32]
	ldrb	w8, [x8]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	strb	w8, [x9]
	b	LBB99_42
LBB99_20:                               ;   in Loop: Header=BB99_17 Depth=1
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #23]
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-32]
	subs	x8, x8, x9
	subs	x8, x8, #1
	b.ge	LBB99_22
	b	LBB99_21
LBB99_21:
	b	LBB99_44
LBB99_22:                               ;   in Loop: Header=BB99_17 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #1]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	subs	w8, w8, #34
	b.eq	LBB99_36
	b	LBB99_23
LBB99_23:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #47
	b.eq	LBB99_36
	b	LBB99_24
LBB99_24:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #92
	b.eq	LBB99_36
	b	LBB99_25
LBB99_25:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #98
	b.eq	LBB99_31
	b	LBB99_26
LBB99_26:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #102
	b.eq	LBB99_32
	b	LBB99_27
LBB99_27:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #110
	b.eq	LBB99_33
	b	LBB99_28
LBB99_28:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #114
	b.eq	LBB99_34
	b	LBB99_29
LBB99_29:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #116
	b.eq	LBB99_35
	b	LBB99_30
LBB99_30:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #117
	b.eq	LBB99_37
	b	LBB99_40
LBB99_31:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	x9, [sp, #48]
	add	x8, x9, #1
	str	x8, [sp, #48]
	mov	w8, #8                          ; =0x8
	strb	w8, [x9]
	b	LBB99_41
LBB99_32:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	x9, [sp, #48]
	add	x8, x9, #1
	str	x8, [sp, #48]
	mov	w8, #12                         ; =0xc
	strb	w8, [x9]
	b	LBB99_41
LBB99_33:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	x9, [sp, #48]
	add	x8, x9, #1
	str	x8, [sp, #48]
	mov	w8, #10                         ; =0xa
	strb	w8, [x9]
	b	LBB99_41
LBB99_34:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	x9, [sp, #48]
	add	x8, x9, #1
	str	x8, [sp, #48]
	mov	w8, #13                         ; =0xd
	strb	w8, [x9]
	b	LBB99_41
LBB99_35:                               ;   in Loop: Header=BB99_17 Depth=1
	ldr	x9, [sp, #48]
	add	x8, x9, #1
	str	x8, [sp, #48]
	mov	w8, #9                          ; =0x9
	strb	w8, [x9]
	b	LBB99_41
LBB99_36:                               ;   in Loop: Header=BB99_17 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #1]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	strb	w8, [x9]
	b	LBB99_41
LBB99_37:                               ;   in Loop: Header=BB99_17 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	add	x2, sp, #48
	bl	_utf16_literal_to_utf8
	strb	w0, [sp, #23]
	ldrb	w8, [sp, #23]
	cbnz	w8, LBB99_39
	b	LBB99_38
LBB99_38:
	b	LBB99_44
LBB99_39:                               ;   in Loop: Header=BB99_17 Depth=1
	b	LBB99_41
LBB99_40:
	b	LBB99_44
LBB99_41:                               ;   in Loop: Header=BB99_17 Depth=1
	ldrb	w9, [sp, #23]
	ldur	x8, [x29, #-32]
	add	x8, x8, w9, sxtw
	stur	x8, [x29, #-32]
	b	LBB99_42
LBB99_42:                               ;   in Loop: Header=BB99_17 Depth=1
	b	LBB99_17
LBB99_43:
	ldr	x8, [sp, #48]
	strb	wzr, [x8]
	ldur	x9, [x29, #-16]
	mov	w8, #16                         ; =0x10
	str	w8, [x9, #24]
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #32]
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	ldur	x9, [x29, #-24]
	str	x8, [x9, #16]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_49
LBB99_44:
	ldr	x8, [sp, #40]
	cbz	x8, LBB99_46
	b	LBB99_45
LBB99_45:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldr	x0, [sp, #40]
	blr	x8
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	b	LBB99_46
LBB99_46:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB99_48
	b	LBB99_47
LBB99_47:
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	ldur	x9, [x29, #-24]
	str	x8, [x9, #16]
	b	LBB99_48
LBB99_48:
	stur	wzr, [x29, #-4]
	b	LBB99_49
LBB99_49:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_number
_parse_number:                          ; @parse_number
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	movi.2d	v0, #0000000000000000
	stur	d0, [x29, #-32]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-40]
	bl	_get_decimal_point
	strb	w0, [sp, #47]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	wzr, [sp, #20]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB100_2
	b	LBB100_1
LBB100_1:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	cbnz	x8, LBB100_3
	b	LBB100_2
LBB100_2:
	stur	wzr, [x29, #-4]
	b	LBB100_38
LBB100_3:
	str	xzr, [sp, #32]
	b	LBB100_4
LBB100_4:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbz	x8, LBB100_6
	b	LBB100_5
LBB100_5:                               ;   in Loop: Header=BB100_4 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #32]
	add	x8, x8, x9
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB100_6
LBB100_6:                               ;   in Loop: Header=BB100_4 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB100_18
	b	LBB100_7
LBB100_7:                               ;   in Loop: Header=BB100_4 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	ldr	x9, [sp, #32]
	ldrb	w8, [x8, x9]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	subs	w8, w8, #43
	b.eq	LBB100_13
	b	LBB100_8
LBB100_8:                               ;   in Loop: Header=BB100_4 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #45
	b.eq	LBB100_13
	b	LBB100_9
LBB100_9:                               ;   in Loop: Header=BB100_4 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #46
	b.eq	LBB100_14
	b	LBB100_10
LBB100_10:                              ;   in Loop: Header=BB100_4 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #48
	subs	w8, w8, #9
	b.ls	LBB100_13
	b	LBB100_11
LBB100_11:                              ;   in Loop: Header=BB100_4 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #69
	b.eq	LBB100_13
	b	LBB100_12
LBB100_12:                              ;   in Loop: Header=BB100_4 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #101
	b.ne	LBB100_15
	b	LBB100_13
LBB100_13:                              ;   in Loop: Header=BB100_4 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB100_16
LBB100_14:                              ;   in Loop: Header=BB100_4 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]
	b	LBB100_16
LBB100_15:
	b	LBB100_19
LBB100_16:                              ;   in Loop: Header=BB100_4 Depth=1
	b	LBB100_17
LBB100_17:                              ;   in Loop: Header=BB100_4 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB100_4
LBB100_18:
	b	LBB100_19
LBB100_19:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #24]
	add	x0, x9, #1
	blr	x8
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB100_21
	b	LBB100_20
LBB100_20:
	stur	wzr, [x29, #-4]
	b	LBB100_38
LBB100_21:
	ldr	x0, [sp, #48]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	add	x1, x8, x9
	ldr	x2, [sp, #24]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #24]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	w8, [sp, #20]
	cbz	w8, LBB100_29
	b	LBB100_22
LBB100_22:
	str	xzr, [sp, #32]
	b	LBB100_23
LBB100_23:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	LBB100_28
	b	LBB100_24
LBB100_24:                              ;   in Loop: Header=BB100_23 Depth=1
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #32]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #46
	b.ne	LBB100_26
	b	LBB100_25
LBB100_25:                              ;   in Loop: Header=BB100_23 Depth=1
	ldrb	w8, [sp, #47]
	ldr	x9, [sp, #48]
	ldr	x10, [sp, #32]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB100_26
LBB100_26:                              ;   in Loop: Header=BB100_23 Depth=1
	b	LBB100_27
LBB100_27:                              ;   in Loop: Header=BB100_23 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB100_23
LBB100_28:
	b	LBB100_29
LBB100_29:
	ldr	x0, [sp, #48]
	sub	x1, x29, #40
	bl	_strtod
	stur	d0, [x29, #-32]
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-40]
	subs	x8, x8, x9
	b.ne	LBB100_31
	b	LBB100_30
LBB100_30:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldr	x0, [sp, #48]
	blr	x8
	stur	wzr, [x29, #-4]
	b	LBB100_38
LBB100_31:
	ldur	d0, [x29, #-32]
	ldur	x8, [x29, #-16]
	str	d0, [x8, #48]
	ldur	d0, [x29, #-32]
	mov	x8, #281474972516352            ; =0xffffffc00000
	movk	x8, #16863, lsl #48
	fmov	d1, x8
	fcmp	d0, d1
	b.lt	LBB100_33
	b	LBB100_32
LBB100_32:
	ldur	x9, [x29, #-16]
	mov	w8, #2147483647                 ; =0x7fffffff
	str	w8, [x9, #40]
	b	LBB100_37
LBB100_33:
	ldur	d0, [x29, #-32]
	mov	x8, #-4476578029606273024       ; =0xc1e0000000000000
	fmov	d1, x8
	fcmp	d0, d1
	b.hi	LBB100_35
	b	LBB100_34
LBB100_34:
	ldur	x9, [x29, #-16]
	mov	w8, #-2147483648                ; =0x80000000
	str	w8, [x9, #40]
	b	LBB100_36
LBB100_35:
	ldur	d0, [x29, #-32]
	fcvtzs	w8, d0
	ldur	x9, [x29, #-16]
	str	w8, [x9, #40]
	b	LBB100_36
LBB100_36:
	b	LBB100_37
LBB100_37:
	ldur	x9, [x29, #-16]
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #24]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	subs	x10, x8, x9
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldr	x0, [sp, #48]
	blr	x8
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB100_38
LBB100_38:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_array
_parse_array:                           ; @parse_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	subs	x8, x8, #1000
	b.lo	LBB101_2
	b	LBB101_1
LBB101_1:
	stur	wzr, [x29, #-4]
	b	LBB101_35
LBB101_2:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #91
	b.eq	LBB101_4
	b	LBB101_3
LBB101_3:
	b	LBB101_32
LBB101_4:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	ldur	x8, [x29, #-24]
	cbz	x8, LBB101_8
	b	LBB101_5
LBB101_5:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB101_8
	b	LBB101_6
LBB101_6:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #93
	b.ne	LBB101_8
	b	LBB101_7
LBB101_7:
	b	LBB101_29
LBB101_8:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB101_10
	b	LBB101_9
LBB101_9:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB101_11
	b	LBB101_10
LBB101_10:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB101_32
LBB101_11:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB101_12
LBB101_12:                              ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-24]
	add	x0, x8, #32
	bl	_cJSON_New_Item
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB101_14
	b	LBB101_13
LBB101_13:
	b	LBB101_32
LBB101_14:                              ;   in Loop: Header=BB101_12 Depth=1
	ldr	x8, [sp, #32]
	cbnz	x8, LBB101_16
	b	LBB101_15
LBB101_15:                              ;   in Loop: Header=BB101_12 Depth=1
	ldr	x8, [sp, #16]
	str	x8, [sp, #32]
	str	x8, [sp, #24]
	b	LBB101_17
LBB101_16:                              ;   in Loop: Header=BB101_12 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB101_17
LBB101_17:                              ;   in Loop: Header=BB101_12 Depth=1
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-24]
	bl	_parse_value
	cbnz	w0, LBB101_19
	b	LBB101_18
LBB101_18:
	b	LBB101_32
LBB101_19:                              ;   in Loop: Header=BB101_12 Depth=1
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	b	LBB101_20
LBB101_20:                              ;   in Loop: Header=BB101_12 Depth=1
	ldur	x8, [x29, #-24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB101_23
	b	LBB101_21
LBB101_21:                              ;   in Loop: Header=BB101_12 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x9, x8, #0
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB101_23
	b	LBB101_22
LBB101_22:                              ;   in Loop: Header=BB101_12 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #44
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB101_23
LBB101_23:                              ;   in Loop: Header=BB101_12 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbnz	w8, #0, LBB101_12
	b	LBB101_24
LBB101_24:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB101_27
	b	LBB101_25
LBB101_25:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB101_27
	b	LBB101_26
LBB101_26:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #93
	b.eq	LBB101_28
	b	LBB101_27
LBB101_27:
	b	LBB101_32
LBB101_28:
	b	LBB101_29
LBB101_29:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #24]
	subs	x8, x8, #1
	str	x8, [x9, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB101_31
	b	LBB101_30
LBB101_30:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #32]
	str	x8, [x9, #8]
	b	LBB101_31
LBB101_31:
	ldur	x9, [x29, #-16]
	mov	w8, #32                         ; =0x20
	str	w8, [x9, #24]
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #16]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB101_35
LBB101_32:
	ldr	x8, [sp, #32]
	cbz	x8, LBB101_34
	b	LBB101_33
LBB101_33:
	ldr	x0, [sp, #32]
	bl	_cJSON_Delete
	b	LBB101_34
LBB101_34:
	stur	wzr, [x29, #-4]
	b	LBB101_35
LBB101_35:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_object
_parse_object:                          ; @parse_object
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	subs	x8, x8, #1000
	b.lo	LBB102_2
	b	LBB102_1
LBB102_1:
	stur	wzr, [x29, #-4]
	b	LBB102_46
LBB102_2:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB102_5
	b	LBB102_3
LBB102_3:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB102_5
	b	LBB102_4
LBB102_4:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #123
	b.eq	LBB102_6
	b	LBB102_5
LBB102_5:
	b	LBB102_43
LBB102_6:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	ldur	x8, [x29, #-24]
	cbz	x8, LBB102_10
	b	LBB102_7
LBB102_7:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB102_10
	b	LBB102_8
LBB102_8:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #125
	b.ne	LBB102_10
	b	LBB102_9
LBB102_9:
	b	LBB102_40
LBB102_10:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB102_12
	b	LBB102_11
LBB102_11:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB102_13
	b	LBB102_12
LBB102_12:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB102_43
LBB102_13:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB102_14
LBB102_14:                              ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-24]
	add	x0, x8, #32
	bl	_cJSON_New_Item
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB102_16
	b	LBB102_15
LBB102_15:
	b	LBB102_43
LBB102_16:                              ;   in Loop: Header=BB102_14 Depth=1
	ldr	x8, [sp, #32]
	cbnz	x8, LBB102_18
	b	LBB102_17
LBB102_17:                              ;   in Loop: Header=BB102_14 Depth=1
	ldr	x8, [sp, #16]
	str	x8, [sp, #32]
	str	x8, [sp, #24]
	b	LBB102_19
LBB102_18:                              ;   in Loop: Header=BB102_14 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB102_19
LBB102_19:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	cbz	x8, LBB102_21
	b	LBB102_20
LBB102_20:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #1
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB102_22
	b	LBB102_21
LBB102_21:
	b	LBB102_43
LBB102_22:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-24]
	bl	_parse_string
	cbnz	w0, LBB102_24
	b	LBB102_23
LBB102_23:
	b	LBB102_43
LBB102_24:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #24]
	str	x8, [x9, #56]
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #32]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB102_27
	b	LBB102_25
LBB102_25:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB102_27
	b	LBB102_26
LBB102_26:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #58
	b.eq	LBB102_28
	b	LBB102_27
LBB102_27:
	b	LBB102_43
LBB102_28:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-24]
	bl	_parse_value
	cbnz	w0, LBB102_30
	b	LBB102_29
LBB102_29:
	b	LBB102_43
LBB102_30:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x0, [x29, #-24]
	bl	_buffer_skip_whitespace
	b	LBB102_31
LBB102_31:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB102_34
	b	LBB102_32
LBB102_32:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x9, x8, #0
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB102_34
	b	LBB102_33
LBB102_33:                              ;   in Loop: Header=BB102_14 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #44
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB102_34
LBB102_34:                              ;   in Loop: Header=BB102_14 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbnz	w8, #0, LBB102_14
	b	LBB102_35
LBB102_35:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB102_38
	b	LBB102_36
LBB102_36:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	add	x8, x8, #0
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB102_38
	b	LBB102_37
LBB102_37:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #125
	b.eq	LBB102_39
	b	LBB102_38
LBB102_38:
	b	LBB102_43
LBB102_39:
	b	LBB102_40
LBB102_40:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #24]
	subs	x8, x8, #1
	str	x8, [x9, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB102_42
	b	LBB102_41
LBB102_41:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #32]
	str	x8, [x9, #8]
	b	LBB102_42
LBB102_42:
	ldur	x9, [x29, #-16]
	mov	w8, #64                         ; =0x40
	str	w8, [x9, #24]
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #16]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB102_46
LBB102_43:
	ldr	x8, [sp, #32]
	cbz	x8, LBB102_45
	b	LBB102_44
LBB102_44:
	ldr	x0, [sp, #32]
	bl	_cJSON_Delete
	b	LBB102_45
LBB102_45:
	stur	wzr, [x29, #-4]
	b	LBB102_46
LBB102_46:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function utf16_literal_to_utf8
_utf16_literal_to_utf8:                 ; @utf16_literal_to_utf8
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	str	xzr, [sp, #40]
	str	wzr, [sp, #36]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]
	strb	wzr, [sp, #23]
	strb	wzr, [sp, #22]
	strb	wzr, [sp, #21]
	strb	wzr, [sp, #20]
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	subs	x8, x8, #6
	b.ge	LBB103_2
	b	LBB103_1
LBB103_1:
	b	LBB103_37
LBB103_2:
	ldr	x8, [sp, #24]
	add	x0, x8, #2
	bl	_parse_hex4
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	mov	w9, #56320                      ; =0xdc00
	subs	w8, w8, w9
	b.lo	LBB103_5
	b	LBB103_3
LBB103_3:
	ldr	w8, [sp, #36]
	subs	w8, w8, #14, lsl #12            ; =57344
	b.hs	LBB103_5
	b	LBB103_4
LBB103_4:
	b	LBB103_37
LBB103_5:
	ldr	w8, [sp, #36]
	mov	w9, #55296                      ; =0xd800
	subs	w8, w8, w9
	b.lo	LBB103_16
	b	LBB103_6
LBB103_6:
	ldr	w8, [sp, #36]
	mov	w9, #56319                      ; =0xdbff
	subs	w8, w8, w9
	b.hi	LBB103_16
	b	LBB103_7
LBB103_7:
	ldr	x8, [sp, #24]
	add	x8, x8, #6
	str	x8, [sp, #8]
	str	wzr, [sp, #4]
	mov	w8, #12                         ; =0xc
	strb	w8, [sp, #21]
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	subs	x8, x8, #6
	b.ge	LBB103_9
	b	LBB103_8
LBB103_8:
	b	LBB103_37
LBB103_9:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #92
	b.ne	LBB103_11
	b	LBB103_10
LBB103_10:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #1]
	subs	w8, w8, #117
	b.eq	LBB103_12
	b	LBB103_11
LBB103_11:
	b	LBB103_37
LBB103_12:
	ldr	x8, [sp, #8]
	add	x0, x8, #2
	bl	_parse_hex4
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	mov	w9, #56320                      ; =0xdc00
	subs	w8, w8, w9
	b.lo	LBB103_14
	b	LBB103_13
LBB103_13:
	ldr	w8, [sp, #4]
	subs	w8, w8, #14, lsl #12            ; =57344
	b.lo	LBB103_15
	b	LBB103_14
LBB103_14:
	b	LBB103_37
LBB103_15:
	ldr	w8, [sp, #36]
	and	w9, w8, #0x3ff
	ldr	w8, [sp, #4]
	bfi	w8, w9, #10, #22
	add	w8, w8, #16, lsl #12            ; =65536
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #40]
	b	LBB103_17
LBB103_16:
	mov	w8, #6                          ; =0x6
	strb	w8, [sp, #21]
	ldr	w8, [sp, #36]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #40]
	b	LBB103_17
LBB103_17:
	ldr	x8, [sp, #40]
	subs	x8, x8, #128
	b.hs	LBB103_19
	b	LBB103_18
LBB103_18:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #23]
	b	LBB103_29
LBB103_19:
	ldr	x8, [sp, #40]
	subs	x8, x8, #2048
	b.hs	LBB103_21
	b	LBB103_20
LBB103_20:
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #23]
	mov	w8, #192                        ; =0xc0
	strb	w8, [sp, #20]
	b	LBB103_28
LBB103_21:
	ldr	x8, [sp, #40]
	subs	x8, x8, #16, lsl #12            ; =65536
	b.hs	LBB103_23
	b	LBB103_22
LBB103_22:
	mov	w8, #3                          ; =0x3
	strb	w8, [sp, #23]
	mov	w8, #224                        ; =0xe0
	strb	w8, [sp, #20]
	b	LBB103_27
LBB103_23:
	ldr	x8, [sp, #40]
	subs	x8, x8, #272, lsl #12           ; =1114112
	b.hs	LBB103_25
	b	LBB103_24
LBB103_24:
	mov	w8, #4                          ; =0x4
	strb	w8, [sp, #23]
	mov	w8, #240                        ; =0xf0
	strb	w8, [sp, #20]
	b	LBB103_26
LBB103_25:
	b	LBB103_37
LBB103_26:
	b	LBB103_27
LBB103_27:
	b	LBB103_28
LBB103_28:
	b	LBB103_29
LBB103_29:
	ldrb	w8, [sp, #23]
	subs	w8, w8, #1
	strb	w8, [sp, #22]
	b	LBB103_30
LBB103_30:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [sp, #22]
	subs	w8, w8, #0
	b.le	LBB103_33
	b	LBB103_31
LBB103_31:                              ;   in Loop: Header=BB103_30 Depth=1
	ldr	x8, [sp, #40]
	orr	x8, x8, #0x80
	mov	x9, #191                        ; =0xbf
	and	x8, x8, x9
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	ldrb	w10, [sp, #22]
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9, x10]
	ldr	x8, [sp, #40]
	lsr	x8, x8, #6
	str	x8, [sp, #40]
	b	LBB103_32
LBB103_32:                              ;   in Loop: Header=BB103_30 Depth=1
	ldrb	w9, [sp, #22]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w9, uxtb
	strb	w8, [sp, #22]
	b	LBB103_30
LBB103_33:
	ldrb	w8, [sp, #23]
	subs	w8, w8, #1
	b.le	LBB103_35
	b	LBB103_34
LBB103_34:
	ldr	x8, [sp, #40]
	ldrb	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	orr	x8, x8, x9
	and	x8, x8, #0xff
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9]
	b	LBB103_36
LBB103_35:
	ldr	x8, [sp, #40]
	and	x8, x8, #0x7f
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9]
	b	LBB103_36
LBB103_36:
	ldrb	w10, [sp, #23]
	ldur	x9, [x29, #-32]
	ldr	x8, [x9]
	add	x8, x8, w10, sxtw
	str	x8, [x9]
	ldrb	w8, [sp, #21]
	sturb	w8, [x29, #-1]
	b	LBB103_38
LBB103_37:
	sturb	wzr, [x29, #-1]
	b	LBB103_38
LBB103_38:
	ldurb	w0, [x29, #-1]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_hex4
_parse_hex4:                            ; @parse_hex4
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	wzr, [sp, #12]
	str	xzr, [sp]
	str	xzr, [sp]
	b	LBB104_1
LBB104_1:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	subs	x8, x8, #4
	b.hs	LBB104_18
	b	LBB104_2
LBB104_2:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #48
	b.lt	LBB104_5
	b	LBB104_3
LBB104_3:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #57
	b.gt	LBB104_5
	b	LBB104_4
LBB104_4:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w9, w8, #48
	ldr	w8, [sp, #12]
	add	w8, w8, w9
	str	w8, [sp, #12]
	b	LBB104_14
LBB104_5:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #65
	b.lt	LBB104_8
	b	LBB104_6
LBB104_6:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #70
	b.gt	LBB104_8
	b	LBB104_7
LBB104_7:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	add	w8, w8, #10
	subs	w9, w8, #65
	ldr	w8, [sp, #12]
	add	w8, w8, w9
	str	w8, [sp, #12]
	b	LBB104_13
LBB104_8:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #97
	b.lt	LBB104_11
	b	LBB104_9
LBB104_9:                               ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #102
	b.gt	LBB104_11
	b	LBB104_10
LBB104_10:                              ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp]
	ldrb	w8, [x8, x9]
	add	w8, w8, #10
	subs	w9, w8, #97
	ldr	w8, [sp, #12]
	add	w8, w8, w9
	str	w8, [sp, #12]
	b	LBB104_12
LBB104_11:
	str	wzr, [sp, #28]
	b	LBB104_19
LBB104_12:                              ;   in Loop: Header=BB104_1 Depth=1
	b	LBB104_13
LBB104_13:                              ;   in Loop: Header=BB104_1 Depth=1
	b	LBB104_14
LBB104_14:                              ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp]
	subs	x8, x8, #3
	b.hs	LBB104_16
	b	LBB104_15
LBB104_15:                              ;   in Loop: Header=BB104_1 Depth=1
	ldr	w8, [sp, #12]
	lsl	w8, w8, #4
	str	w8, [sp, #12]
	b	LBB104_16
LBB104_16:                              ;   in Loop: Header=BB104_1 Depth=1
	b	LBB104_17
LBB104_17:                              ;   in Loop: Header=BB104_1 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB104_1
LBB104_18:
	ldr	w8, [sp, #12]
	str	w8, [sp, #28]
	b	LBB104_19
LBB104_19:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get_decimal_point
_get_decimal_point:                     ; @get_decimal_point
	.cfi_startproc
; %bb.0:
	mov	w0, #46                         ; =0x2e
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ensure
_ensure:                                ; @ensure
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB106_2
	b	LBB106_1
LBB106_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	cbnz	x8, LBB106_3
	b	LBB106_2
LBB106_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	subs	x8, x8, #0
	b.ls	LBB106_6
	b	LBB106_4
LBB106_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	LBB106_6
	b	LBB106_5
LBB106_5:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_6:
	ldr	x8, [sp, #24]
	mov	x9, #2147483647                 ; =0x7fffffff
	subs	x8, x8, x9
	b.ls	LBB106_8
	b	LBB106_7
LBB106_7:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	add	x9, x8, #1
	ldr	x8, [sp, #24]
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB106_10
	b	LBB106_9
LBB106_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	stur	x8, [x29, #-8]
	b	LBB106_26
LBB106_10:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #32]
	cbz	w8, LBB106_12
	b	LBB106_11
LBB106_11:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_12:
	ldr	x8, [sp, #24]
	mov	x9, #1073741823                 ; =0x3fffffff
	subs	x8, x8, x9
	b.ls	LBB106_17
	b	LBB106_13
LBB106_13:
	ldr	x8, [sp, #24]
	mov	x9, #2147483647                 ; =0x7fffffff
	subs	x8, x8, x9
	b.hi	LBB106_15
	b	LBB106_14
LBB106_14:
	mov	x8, #2147483647                 ; =0x7fffffff
	str	x8, [sp, #8]
	b	LBB106_16
LBB106_15:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_16:
	b	LBB106_18
LBB106_17:
	ldr	x8, [sp, #24]
	lsl	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB106_18
LBB106_18:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	cbz	x8, LBB106_22
	b	LBB106_19
LBB106_19:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-16]
	ldr	x0, [x9]
	ldr	x1, [sp, #8]
	blr	x8
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB106_21
	b	LBB106_20
LBB106_20:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-16]
	ldr	x0, [x9]
	blr	x8
	ldur	x8, [x29, #-16]
	str	xzr, [x8, #8]
	ldur	x8, [x29, #-16]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_21:
	b	LBB106_25
LBB106_22:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x0, [sp, #8]
	blr	x8
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB106_24
	b	LBB106_23
LBB106_23:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-16]
	ldr	x0, [x9]
	blr	x8
	ldur	x8, [x29, #-16]
	str	xzr, [x8, #8]
	ldur	x8, [x29, #-16]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	stur	xzr, [x29, #-8]
	b	LBB106_26
LBB106_24:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	add	x2, x8, #1
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-16]
	ldr	x0, [x9]
	blr	x8
	b	LBB106_25
LBB106_25:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	stur	x8, [x29, #-8]
	b	LBB106_26
LBB106_26:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_number
_print_number:                          ; @print_number
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #80]
	str	x1, [sp, #72]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #64]
	ldr	x8, [sp, #80]
	ldr	d0, [x8, #48]
	str	d0, [sp, #56]
	str	wzr, [sp, #52]
	str	xzr, [sp, #40]
	stur	xzr, [x29, #-40]
	stur	xzr, [x29, #-32]
	stur	xzr, [x29, #-24]
	sturh	wzr, [x29, #-16]
	bl	_get_decimal_point
	strb	w0, [sp, #39]
	movi.2d	v0, #0000000000000000
	str	d0, [sp, #24]
	ldr	x8, [sp, #72]
	cbnz	x8, LBB107_2
	b	LBB107_1
LBB107_1:
	str	wzr, [sp, #88]
	b	LBB107_32
LBB107_2:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB107_4
	b	LBB107_3
LBB107_3:
	ldr	d0, [sp, #56]
	fcvt	s0, d0
	stur	s0, [x29, #-84]
	ldur	s0, [x29, #-84]
	ldur	s1, [x29, #-84]
	fcmp	s0, s1
	cset	w8, ne
	cbnz	w8, LBB107_12
	b	LBB107_7
LBB107_4:
	mov	w8, #1                          ; =0x1
	tbz	w8, #0, LBB107_6
	b	LBB107_5
LBB107_5:
	ldr	d0, [sp, #56]
	stur	d0, [x29, #-80]
	ldur	d0, [x29, #-80]
	ldur	d1, [x29, #-80]
	fcmp	d0, d1
	cset	w8, ne
	cbnz	w8, LBB107_12
	b	LBB107_7
LBB107_6:
	ldr	d0, [sp, #56]
	stur	d0, [x29, #-72]
	ldur	d0, [x29, #-72]
	ldur	d1, [x29, #-72]
	fcmp	d0, d1
	cset	w8, ne
	cbnz	w8, LBB107_12
	b	LBB107_7
LBB107_7:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB107_9
	b	LBB107_8
LBB107_8:
	ldr	d0, [sp, #56]
	fcvt	s0, d0
	stur	s0, [x29, #-60]
	ldur	s0, [x29, #-60]
	fabs	s0, s0
	mov	w8, #2139095040                 ; =0x7f800000
	fmov	s1, w8
	fcmp	s0, s1
	cset	w8, eq
	cbnz	w8, LBB107_12
	b	LBB107_13
LBB107_9:
	mov	w8, #1                          ; =0x1
	tbz	w8, #0, LBB107_11
	b	LBB107_10
LBB107_10:
	ldr	d0, [sp, #56]
	stur	d0, [x29, #-56]
	ldur	d0, [x29, #-56]
	fabs	d0, d0
	mov	x8, #9218868437227405312        ; =0x7ff0000000000000
	fmov	d1, x8
	fcmp	d0, d1
	cset	w8, eq
	cbnz	w8, LBB107_12
	b	LBB107_13
LBB107_11:
	ldr	d0, [sp, #56]
	stur	d0, [x29, #-48]
	ldur	d0, [x29, #-48]
	fabs	d0, d0
	mov	x8, #9218868437227405312        ; =0x7ff0000000000000
	fmov	d1, x8
	fcmp	d0, d1
	cset	w8, eq
	cbz	w8, LBB107_13
	b	LBB107_12
LBB107_12:
	sub	x0, x29, #40
	mov	x3, #26                         ; =0x1a
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.2@PAGE
	add	x4, x4, l_.str.2@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #52]
	b	LBB107_20
LBB107_13:
	ldr	d0, [sp, #56]
	ldr	x8, [sp, #80]
	ldr	s2, [x8, #40]
                                        ; implicit-def: $d1
	mov.16b	v1, v2
	sshll.2d	v1, v1, #0
                                        ; kill: def $d1 killed $d1 killed $q1
	scvtf	d1, d1
	fcmp	d0, d1
	b.ne	LBB107_15
	b	LBB107_14
LBB107_14:
	ldr	x8, [sp, #80]
	ldr	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	sub	x0, x29, #40
	mov	x3, #26                         ; =0x1a
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.5@PAGE
	add	x4, x4, l_.str.5@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #52]
	b	LBB107_19
LBB107_15:
	ldr	d0, [sp, #56]
	mov	x8, sp
	str	d0, [x8]
	sub	x0, x29, #40
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x3, #26                         ; =0x1a
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.6@PAGE
	add	x4, x4, l_.str.6@PAGEOFF
	bl	___snprintf_chk
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	str	w8, [sp, #52]
	mov	x9, sp
	add	x8, sp, #24
	str	x8, [x9]
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	bl	_sscanf
	subs	w8, w0, #1
	b.ne	LBB107_17
	b	LBB107_16
LBB107_16:
	ldr	d0, [sp, #24]
	ldr	d1, [sp, #56]
	bl	_compare_double
	cbnz	w0, LBB107_18
	b	LBB107_17
LBB107_17:
	ldr	d0, [sp, #56]
	mov	x8, sp
	str	d0, [x8]
	sub	x0, x29, #40
	mov	x3, #26                         ; =0x1a
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.8@PAGE
	add	x4, x4, l_.str.8@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #52]
	b	LBB107_18
LBB107_18:
	b	LBB107_19
LBB107_19:
	b	LBB107_20
LBB107_20:
	ldr	w8, [sp, #52]
	tbnz	w8, #31, LBB107_22
	b	LBB107_21
LBB107_21:
	ldr	w8, [sp, #52]
	subs	w8, w8, #25
	b.le	LBB107_23
	b	LBB107_22
LBB107_22:
	str	wzr, [sp, #88]
	b	LBB107_32
LBB107_23:
	ldr	x0, [sp, #72]
	ldrsw	x8, [sp, #52]
	add	x1, x8, #1
	bl	_ensure
	str	x0, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB107_25
	b	LBB107_24
LBB107_24:
	str	wzr, [sp, #88]
	b	LBB107_32
LBB107_25:
	str	xzr, [sp, #40]
	b	LBB107_26
LBB107_26:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #40]
	ldrsw	x9, [sp, #52]
	subs	x8, x8, x9
	b.hs	LBB107_31
	b	LBB107_27
LBB107_27:                              ;   in Loop: Header=BB107_26 Depth=1
	ldr	x9, [sp, #40]
	sub	x8, x29, #40
	ldrb	w8, [x8, x9]
	ldrb	w9, [sp, #39]
	subs	w8, w8, w9
	b.ne	LBB107_29
	b	LBB107_28
LBB107_28:                              ;   in Loop: Header=BB107_26 Depth=1
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #40]
	add	x9, x8, x9
	mov	w8, #46                         ; =0x2e
	strb	w8, [x9]
	b	LBB107_30
LBB107_29:                              ;   in Loop: Header=BB107_26 Depth=1
	ldr	x9, [sp, #40]
	sub	x8, x29, #40
	add	x8, x8, x9
	ldrb	w8, [x8]
	ldr	x9, [sp, #64]
	ldr	x10, [sp, #40]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB107_30
LBB107_30:                              ;   in Loop: Header=BB107_26 Depth=1
	ldr	x8, [sp, #40]
	add	x8, x8, #1
	str	x8, [sp, #40]
	b	LBB107_26
LBB107_31:
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #40]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldrsw	x10, [sp, #52]
	ldr	x9, [sp, #72]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #88]
	b	LBB107_32
LBB107_32:
	ldr	w8, [sp, #88]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB107_34
	b	LBB107_33
LBB107_33:
	bl	___stack_chk_fail
LBB107_34:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_string
_print_string:                          ; @print_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	ldr	x1, [sp]
	bl	_print_string_ptr
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_array
_print_array:                           ; @print_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB109_2
	b	LBB109_1
LBB109_1:
	stur	wzr, [x29, #-4]
	b	LBB109_18
LBB109_2:
	ldr	x0, [sp, #24]
	mov	x1, #1                          ; =0x1
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB109_4
	b	LBB109_3
LBB109_3:
	stur	wzr, [x29, #-4]
	b	LBB109_18
LBB109_4:
	ldr	x9, [sp, #16]
	mov	w8, #91                         ; =0x5b
	strb	w8, [x9]
	ldr	x9, [sp, #24]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x9, [sp, #24]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	b	LBB109_5
LBB109_5:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	cbz	x8, LBB109_15
	b	LBB109_6
LBB109_6:                               ;   in Loop: Header=BB109_5 Depth=1
	ldr	x0, [sp]
	ldr	x1, [sp, #24]
	bl	_print_value
	cbnz	w0, LBB109_8
	b	LBB109_7
LBB109_7:
	stur	wzr, [x29, #-4]
	b	LBB109_18
LBB109_8:                               ;   in Loop: Header=BB109_5 Depth=1
	ldr	x0, [sp, #24]
	bl	_update_offset
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB109_14
	b	LBB109_9
LBB109_9:                               ;   in Loop: Header=BB109_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	w9, [x8, #36]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #0
	csinc	w9, w8, wzr, ne
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	str	x8, [sp, #8]
	ldr	x0, [sp, #24]
	ldr	x8, [sp, #8]
	add	x1, x8, #1
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB109_11
	b	LBB109_10
LBB109_10:
	stur	wzr, [x29, #-4]
	b	LBB109_18
LBB109_11:                              ;   in Loop: Header=BB109_5 Depth=1
	ldr	x9, [sp, #16]
	add	x8, x9, #1
	str	x8, [sp, #16]
	mov	w8, #44                         ; =0x2c
	strb	w8, [x9]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB109_13
	b	LBB109_12
LBB109_12:                              ;   in Loop: Header=BB109_5 Depth=1
	ldr	x9, [sp, #16]
	add	x8, x9, #1
	str	x8, [sp, #16]
	mov	w8, #32                         ; =0x20
	strb	w8, [x9]
	b	LBB109_13
LBB109_13:                              ;   in Loop: Header=BB109_5 Depth=1
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #24]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	b	LBB109_14
LBB109_14:                              ;   in Loop: Header=BB109_5 Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8]
	str	x8, [sp]
	b	LBB109_5
LBB109_15:
	ldr	x0, [sp, #24]
	mov	x1, #2                          ; =0x2
	bl	_ensure
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB109_17
	b	LBB109_16
LBB109_16:
	stur	wzr, [x29, #-4]
	b	LBB109_18
LBB109_17:
	ldr	x9, [sp, #16]
	add	x8, x9, #1
	str	x8, [sp, #16]
	mov	w8, #93                         ; =0x5d
	strb	w8, [x9]
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	ldr	x9, [sp, #24]
	ldr	x8, [x9, #24]
	subs	x8, x8, #1
	str	x8, [x9, #24]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB109_18
LBB109_18:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_object
_print_object:                          ; @print_object
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	str	xzr, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB110_2
	b	LBB110_1
LBB110_1:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_2:
	ldur	x8, [x29, #-24]
	ldr	w9, [x8, #36]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #0
	csinc	w9, w8, wzr, ne
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	str	x8, [sp, #40]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	add	x1, x8, #1
	bl	_ensure
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB110_4
	b	LBB110_3
LBB110_3:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_4:
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #123                        ; =0x7b
	strb	w8, [x9]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB110_6
	b	LBB110_5
LBB110_5:
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #10                         ; =0xa
	strb	w8, [x9]
	b	LBB110_6
LBB110_6:
	ldr	x10, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	b	LBB110_7
LBB110_7:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB110_12 Depth 2
	ldr	x8, [sp, #32]
	cbz	x8, LBB110_31
	b	LBB110_8
LBB110_8:                               ;   in Loop: Header=BB110_7 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB110_16
	b	LBB110_9
LBB110_9:                               ;   in Loop: Header=BB110_7 Depth=1
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #24]
	bl	_ensure
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB110_11
	b	LBB110_10
LBB110_10:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_11:                              ;   in Loop: Header=BB110_7 Depth=1
	str	xzr, [sp, #24]
	b	LBB110_12
LBB110_12:                              ;   Parent Loop BB110_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB110_15
	b	LBB110_13
LBB110_13:                              ;   in Loop: Header=BB110_12 Depth=2
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #9                          ; =0x9
	strb	w8, [x9]
	b	LBB110_14
LBB110_14:                              ;   in Loop: Header=BB110_12 Depth=2
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB110_12
LBB110_15:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #24]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	b	LBB110_16
LBB110_16:                              ;   in Loop: Header=BB110_7 Depth=1
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #56]
	ldur	x1, [x29, #-24]
	bl	_print_string_ptr
	cbnz	w0, LBB110_18
	b	LBB110_17
LBB110_17:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_18:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x0, [x29, #-24]
	bl	_update_offset
	ldur	x8, [x29, #-24]
	ldr	w9, [x8, #36]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #0
	csinc	w9, w8, wzr, ne
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	str	x8, [sp, #40]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #40]
	bl	_ensure
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB110_20
	b	LBB110_19
LBB110_19:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_20:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #58                         ; =0x3a
	strb	w8, [x9]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB110_22
	b	LBB110_21
LBB110_21:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #9                          ; =0x9
	strb	w8, [x9]
	b	LBB110_22
LBB110_22:                              ;   in Loop: Header=BB110_7 Depth=1
	ldr	x10, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	ldr	x0, [sp, #32]
	ldur	x1, [x29, #-24]
	bl	_print_value
	cbnz	w0, LBB110_24
	b	LBB110_23
LBB110_23:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_24:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x0, [x29, #-24]
	bl	_update_offset
	ldur	x8, [x29, #-24]
	ldr	w9, [x8, #36]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #0
	csinc	w9, w8, wzr, eq
	ldr	x10, [sp, #32]
	ldr	x10, [x10]
	subs	x10, x10, #0
	csinc	w10, w8, wzr, eq
                                        ; implicit-def: $x8
	mov	x8, x10
	sxtw	x8, w8
	add	x8, x8, w9, sxtw
	str	x8, [sp, #40]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	add	x1, x8, #1
	bl	_ensure
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB110_26
	b	LBB110_25
LBB110_25:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_26:                              ;   in Loop: Header=BB110_7 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	cbz	x8, LBB110_28
	b	LBB110_27
LBB110_27:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #44                         ; =0x2c
	strb	w8, [x9]
	b	LBB110_28
LBB110_28:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB110_30
	b	LBB110_29
LBB110_29:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #10                         ; =0xa
	strb	w8, [x9]
	b	LBB110_30
LBB110_30:                              ;   in Loop: Header=BB110_7 Depth=1
	ldur	x8, [x29, #-32]
	strb	wzr, [x8]
	ldr	x10, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	str	x8, [sp, #32]
	b	LBB110_7
LBB110_31:
	ldur	x8, [x29, #-24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB110_33
	b	LBB110_32
LBB110_32:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	add	x8, x8, #1
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB110_34
LBB110_33:
	mov	x8, #2                          ; =0x2
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB110_34
LBB110_34:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	bl	_ensure
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB110_36
	b	LBB110_35
LBB110_35:
	stur	wzr, [x29, #-4]
	b	LBB110_43
LBB110_36:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #36]
	cbz	w8, LBB110_42
	b	LBB110_37
LBB110_37:
	str	xzr, [sp, #16]
	b	LBB110_38
LBB110_38:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #24]
	subs	x9, x9, #1
	subs	x8, x8, x9
	b.hs	LBB110_41
	b	LBB110_39
LBB110_39:                              ;   in Loop: Header=BB110_38 Depth=1
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #9                          ; =0x9
	strb	w8, [x9]
	b	LBB110_40
LBB110_40:                              ;   in Loop: Header=BB110_38 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB110_38
LBB110_41:
	b	LBB110_42
LBB110_42:
	ldur	x9, [x29, #-32]
	add	x8, x9, #1
	stur	x8, [x29, #-32]
	mov	w8, #125                        ; =0x7d
	strb	w8, [x9]
	ldur	x8, [x29, #-32]
	strb	wzr, [x8]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #24]
	subs	x8, x8, #1
	str	x8, [x9, #24]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB110_43
LBB110_43:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function print_string_ptr
_print_string_ptr:                      ; @print_string_ptr
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	stur	xzr, [x29, #-40]
	str	xzr, [sp, #48]
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB111_2
	b	LBB111_1
LBB111_1:
	stur	wzr, [x29, #-4]
	b	LBB111_47
LBB111_2:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB111_6
	b	LBB111_3
LBB111_3:
	ldur	x0, [x29, #-24]
	mov	x1, #3                          ; =0x3
	bl	_ensure
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB111_5
	b	LBB111_4
LBB111_4:
	stur	wzr, [x29, #-4]
	b	LBB111_47
LBB111_5:
	ldur	x0, [x29, #-40]
	adrp	x1, l_.str.9@PAGE
	add	x1, x1, l_.str.9@PAGEOFF
	mov	x2, #-1                         ; =0xffffffffffffffff
	bl	___strcpy_chk
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB111_47
LBB111_6:
	ldur	x8, [x29, #-16]
	stur	x8, [x29, #-32]
	b	LBB111_7
LBB111_7:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	cbz	w8, LBB111_18
	b	LBB111_8
LBB111_8:                               ;   in Loop: Header=BB111_7 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #8
	subs	w8, w8, #2
	b.ls	LBB111_12
	b	LBB111_9
LBB111_9:                               ;   in Loop: Header=BB111_7 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #12
	subs	w8, w8, #1
	b.ls	LBB111_12
	b	LBB111_10
LBB111_10:                              ;   in Loop: Header=BB111_7 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #34
	b.eq	LBB111_12
	b	LBB111_11
LBB111_11:                              ;   in Loop: Header=BB111_7 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #92
	b.ne	LBB111_13
	b	LBB111_12
LBB111_12:                              ;   in Loop: Header=BB111_7 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB111_16
LBB111_13:                              ;   in Loop: Header=BB111_7 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	subs	w8, w8, #32
	b.ge	LBB111_15
	b	LBB111_14
LBB111_14:                              ;   in Loop: Header=BB111_7 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #5
	str	x8, [sp, #32]
	b	LBB111_15
LBB111_15:                              ;   in Loop: Header=BB111_7 Depth=1
	b	LBB111_16
LBB111_16:                              ;   in Loop: Header=BB111_7 Depth=1
	b	LBB111_17
LBB111_17:                              ;   in Loop: Header=BB111_7 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB111_7
LBB111_18:
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-16]
	subs	x8, x8, x9
	ldr	x9, [sp, #32]
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	add	x1, x8, #3
	bl	_ensure
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB111_20
	b	LBB111_19
LBB111_19:
	stur	wzr, [x29, #-4]
	b	LBB111_47
LBB111_20:
	ldr	x8, [sp, #32]
	cbnz	x8, LBB111_22
	b	LBB111_21
LBB111_21:
	ldur	x9, [x29, #-40]
	mov	w8, #34                         ; =0x22
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	strb	w8, [x9]
	ldur	x8, [x29, #-40]
	add	x0, x8, #1
	ldur	x1, [x29, #-16]
	ldr	x2, [sp, #40]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	ldur	x9, [x29, #-40]
	ldr	x10, [sp, #40]
	add	x10, x10, #1
	add	x9, x9, x10
	strb	w8, [x9]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #40]
	add	x9, x9, #2
	add	x8, x8, x9
	strb	wzr, [x8]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB111_47
LBB111_22:
	ldur	x9, [x29, #-40]
	mov	w8, #34                         ; =0x22
	strb	w8, [x9]
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	str	x8, [sp, #48]
	ldur	x8, [x29, #-16]
	stur	x8, [x29, #-32]
	b	LBB111_23
LBB111_23:                              ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	cbz	w8, LBB111_46
	b	LBB111_24
LBB111_24:                              ;   in Loop: Header=BB111_23 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	subs	w8, w8, #31
	b.le	LBB111_28
	b	LBB111_25
LBB111_25:                              ;   in Loop: Header=BB111_23 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	subs	w8, w8, #34
	b.eq	LBB111_28
	b	LBB111_26
LBB111_26:                              ;   in Loop: Header=BB111_23 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	subs	w8, w8, #92
	b.eq	LBB111_28
	b	LBB111_27
LBB111_27:                              ;   in Loop: Header=BB111_23 Depth=1
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	ldr	x9, [sp, #48]
	strb	w8, [x9]
	b	LBB111_44
LBB111_28:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	add	x8, x9, #1
	str	x8, [sp, #48]
	mov	w8, #92                         ; =0x5c
	strb	w8, [x9]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	subs	w8, w8, #8
	b.eq	LBB111_37
	b	LBB111_29
LBB111_29:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #9
	b.eq	LBB111_41
	b	LBB111_30
LBB111_30:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB111_39
	b	LBB111_31
LBB111_31:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #12
	b.eq	LBB111_38
	b	LBB111_32
LBB111_32:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB111_40
	b	LBB111_33
LBB111_33:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #34
	b.eq	LBB111_36
	b	LBB111_34
LBB111_34:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #92
	b.ne	LBB111_42
	b	LBB111_35
LBB111_35:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #92                         ; =0x5c
	strb	w8, [x9]
	b	LBB111_43
LBB111_36:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #34                         ; =0x22
	strb	w8, [x9]
	b	LBB111_43
LBB111_37:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #98                         ; =0x62
	strb	w8, [x9]
	b	LBB111_43
LBB111_38:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #102                        ; =0x66
	strb	w8, [x9]
	b	LBB111_43
LBB111_39:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #110                        ; =0x6e
	strb	w8, [x9]
	b	LBB111_43
LBB111_40:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #114                        ; =0x72
	strb	w8, [x9]
	b	LBB111_43
LBB111_41:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x9, [sp, #48]
	mov	w8, #116                        ; =0x74
	strb	w8, [x9]
	b	LBB111_43
LBB111_42:                              ;   in Loop: Header=BB111_23 Depth=1
	ldr	x0, [sp, #48]
	ldur	x8, [x29, #-32]
	ldrb	w10, [x8]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	mov	x1, #6                          ; =0x6
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.10@PAGE
	add	x4, x4, l_.str.10@PAGEOFF
	bl	___snprintf_chk
	ldr	x8, [sp, #48]
	add	x8, x8, #4
	str	x8, [sp, #48]
	b	LBB111_43
LBB111_43:                              ;   in Loop: Header=BB111_23 Depth=1
	b	LBB111_44
LBB111_44:                              ;   in Loop: Header=BB111_23 Depth=1
	b	LBB111_45
LBB111_45:                              ;   in Loop: Header=BB111_23 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	ldr	x8, [sp, #48]
	add	x8, x8, #1
	str	x8, [sp, #48]
	b	LBB111_23
LBB111_46:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #40]
	add	x9, x9, #1
	add	x9, x8, x9
	mov	w8, #34                         ; =0x22
	strb	w8, [x9]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #40]
	add	x9, x9, #2
	add	x8, x8, x9
	strb	wzr, [x8]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB111_47
LBB111_47:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function case_insensitive_strcmp
_case_insensitive_strcmp:               ; @case_insensitive_strcmp
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB112_2
	b	LBB112_1
LBB112_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB112_3
	b	LBB112_2
LBB112_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB112_12
LBB112_3:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB112_5
	b	LBB112_4
LBB112_4:
	stur	wzr, [x29, #-4]
	b	LBB112_12
LBB112_5:
	b	LBB112_6
LBB112_6:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	ldrb	w0, [x8]
	bl	_tolower
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	ldr	x8, [sp, #8]
	ldrb	w0, [x8]
	bl	_tolower
	mov	x8, x0
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w0, w8
	b.ne	LBB112_11
	b	LBB112_7
LBB112_7:                               ;   in Loop: Header=BB112_6 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	cbnz	w8, LBB112_9
	b	LBB112_8
LBB112_8:
	stur	wzr, [x29, #-4]
	b	LBB112_12
LBB112_9:                               ;   in Loop: Header=BB112_6 Depth=1
	b	LBB112_10
LBB112_10:                              ;   in Loop: Header=BB112_6 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB112_6
LBB112_11:
	ldr	x8, [sp, #16]
	ldrb	w0, [x8]
	bl	_tolower
	str	w0, [sp]                        ; 4-byte Folded Spill
	ldr	x8, [sp, #8]
	ldrb	w0, [x8]
	bl	_tolower
	mov	x8, x0
	ldr	w0, [sp]                        ; 4-byte Folded Reload
	subs	w8, w0, w8
	stur	w8, [x29, #-4]
	b	LBB112_12
LBB112_12:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_global_error,16,3 ; @global_error
.zerofill __DATA,__bss,_cJSON_Version.version,15,0 ; @cJSON_Version.version
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"%i.%i.%i"

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @global_hooks
_global_hooks:
	.quad	_malloc
	.quad	_free
	.quad	_realloc

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"\357\273\277"

	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @print.default_buffer_size
_print.default_buffer_size:
	.quad	256                             ; 0x100

	.section	__TEXT,__cstring,cstring_literals
l_.str.2:                               ; @.str.2
	.asciz	"null"

l_.str.3:                               ; @.str.3
	.asciz	"false"

l_.str.4:                               ; @.str.4
	.asciz	"true"

l_.str.5:                               ; @.str.5
	.asciz	"%d"

l_.str.6:                               ; @.str.6
	.asciz	"%1.15g"

l_.str.7:                               ; @.str.7
	.asciz	"%lg"

l_.str.8:                               ; @.str.8
	.asciz	"%1.17g"

l_.str.9:                               ; @.str.9
	.asciz	"\"\""

l_.str.10:                              ; @.str.10
	.asciz	"u%04x"

.subsections_via_symbols
