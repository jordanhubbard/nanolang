nano_module_dependencies: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /private/var/folders/v0/pxyl2_m512v5j9nhv674pt400000gn/T/nano-host-closure-darwin-2lk666s2/client/provider/api.c
