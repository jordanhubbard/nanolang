	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nl_file_plan_build     ; -- Begin function nl_file_plan_build
	.globl	_nl_file_plan_build
	.p2align	2
_nl_file_plan_build:                    ; @nl_file_plan_build
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	cbz	x19, LBB0_6
; %bb.1:
	cbz	x1, LBB0_6
; %bb.2:
	ldr	w8, [x19]
	cbnz	w8, LBB0_6
; %bb.3:
	ldr	x0, [x19, #8]
	cbz	x0, LBB0_5
; %bb.4:
	mov	x20, x1
Lloh0:
	adrp	x1, l_.str@PAGE
Lloh1:
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB0_7
LBB0_5:
	mov	w0, #1                          ; =0x1
LBB0_6:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_7:
	ldr	x0, [x19, #16]
	cbz	x0, LBB0_5
; %bb.8:
Lloh2:
	adrp	x1, l_.str.1@PAGE
Lloh3:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.9:
	ldr	x8, [x19, #32]
	cmp	x8, #5
	b.ne	LBB0_5
; %bb.10:
	ldr	x8, [x19, #48]
	cmp	x8, #8
	b.ne	LBB0_5
; %bb.11:
	ldr	x8, [x19, #64]
	cmp	x8, #1
	b.ne	LBB0_5
; %bb.12:
	ldr	x8, [x19, #80]
	cmp	x8, #1
	b.ne	LBB0_5
; %bb.13:
	ldr	x21, [x19, #24]
	cbz	x21, LBB0_5
; %bb.14:
	ldr	x8, [x19, #40]
	cbz	x8, LBB0_5
; %bb.15:
	ldr	x23, [x19, #56]
	cbz	x23, LBB0_5
; %bb.16:
	ldr	x22, [x19, #72]
	cbz	x22, LBB0_5
; %bb.17:
	ldr	x0, [x23]
	cbz	x0, LBB0_5
; %bb.18:
	mov	x19, x8
Lloh4:
	adrp	x1, l_.str.2@PAGE
Lloh5:
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.19:
	ldr	x8, [x23, #8]
	cbz	x8, LBB0_5
; %bb.20:
	ldrb	w9, [x8]
	cmp	w9, #105
	b.ne	LBB0_5
; %bb.21:
	ldrb	w9, [x8, #1]
	cmp	w9, #111
	b.ne	LBB0_5
; %bb.22:
	ldrb	w8, [x8, #2]
	cbnz	w8, LBB0_5
; %bb.23:
	ldr	x8, [x23, #16]
	cbz	x8, LBB0_5
; %bb.24:
	ldrb	w9, [x8]
	cmp	w9, #49
	b.ne	LBB0_5
; %bb.25:
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB0_5
; %bb.26:
	ldr	x0, [x22]
	cbz	x0, LBB0_5
; %bb.27:
Lloh6:
	adrp	x1, l_.str.5@PAGE
Lloh7:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.28:
	ldr	x0, [x22, #8]
	cbz	x0, LBB0_5
; %bb.29:
Lloh8:
	adrp	x1, l_.str.6@PAGE
Lloh9:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.30:
	mov	x23, #0                         ; =0x0
	mov	w24, #40                        ; =0x28
	mov	w25, #96                        ; =0x60
Lloh10:
	adrp	x22, _methods@PAGE
Lloh11:
	add	x22, x22, _methods@PAGEOFF
LBB0_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_42 Depth 2
	madd	x28, x23, x24, x21
	madd	x27, x23, x25, x22
	ldr	x0, [x28]
	ldr	x1, [x27]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_33
; %bb.32:                               ;   in Loop: Header=BB0_31 Depth=1
	cmp	x0, x1
	b.eq	LBB0_34
	b	LBB0_5
LBB0_33:                                ;   in Loop: Header=BB0_31 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_34:                                ;   in Loop: Header=BB0_31 Depth=1
	ldr	x0, [x28, #8]
	ldr	x1, [x27, #8]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_36
; %bb.35:                               ;   in Loop: Header=BB0_31 Depth=1
	cmp	x0, x1
	b.eq	LBB0_37
	b	LBB0_5
LBB0_36:                                ;   in Loop: Header=BB0_31 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_37:                                ;   in Loop: Header=BB0_31 Depth=1
	ldr	w8, [x28, #32]
	cbnz	w8, LBB0_5
; %bb.38:                               ;   in Loop: Header=BB0_31 Depth=1
	ldr	x26, [x28, #24]
	ldr	x8, [x27, #56]
	cmp	x26, x8
	b.ne	LBB0_5
; %bb.39:                               ;   in Loop: Header=BB0_31 Depth=1
	ldr	x8, [x28, #16]
	cbz	x8, LBB0_5
; %bb.40:                               ;   in Loop: Header=BB0_31 Depth=1
	cbz	x26, LBB0_59
; %bb.41:                               ;   in Loop: Header=BB0_31 Depth=1
	ldr	x9, [x27, #48]
	add	x27, x8, #24
	add	x28, x9, #24
LBB0_42:                                ;   Parent Loop BB0_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x0, [x27, #-24]
	ldur	x1, [x28, #-24]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_44
; %bb.43:                               ;   in Loop: Header=BB0_42 Depth=2
	cmp	x0, x1
	b.eq	LBB0_45
	b	LBB0_5
LBB0_44:                                ;   in Loop: Header=BB0_42 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_45:                                ;   in Loop: Header=BB0_42 Depth=2
	ldur	x0, [x27, #-16]
	ldur	x1, [x28, #-16]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_47
; %bb.46:                               ;   in Loop: Header=BB0_42 Depth=2
	cmp	x0, x1
	b.eq	LBB0_48
	b	LBB0_5
LBB0_47:                                ;   in Loop: Header=BB0_42 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_48:                                ;   in Loop: Header=BB0_42 Depth=2
	ldur	x0, [x27, #-8]
	ldur	x1, [x28, #-8]
	cbz	x0, LBB0_51
; %bb.49:                               ;   in Loop: Header=BB0_42 Depth=2
	cbz	x1, LBB0_51
; %bb.50:                               ;   in Loop: Header=BB0_42 Depth=2
	bl	_strcmp
	cbz	w0, LBB0_52
	b	LBB0_5
LBB0_51:                                ;   in Loop: Header=BB0_42 Depth=2
	cmp	x0, x1
	b.ne	LBB0_5
LBB0_52:                                ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [x27]
	ldr	w9, [x28]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.53:                               ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [x27, #4]
	ldr	w9, [x28, #4]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.54:                               ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [x27, #8]
	ldr	w9, [x28, #8]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.55:                               ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [x27, #12]
	ldr	w9, [x28, #12]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.56:                               ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [x27, #16]
	cbnz	w8, LBB0_5
; %bb.57:                               ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [x27, #20]
	cbnz	w8, LBB0_5
; %bb.58:                               ;   in Loop: Header=BB0_42 Depth=2
	add	x27, x27, #48
	add	x28, x28, #48
	subs	x26, x26, #1
	b.ne	LBB0_42
LBB0_59:                                ;   in Loop: Header=BB0_31 Depth=1
	add	x23, x23, #1
	cmp	x23, #5
	b.ne	LBB0_31
; %bb.60:
	mov	x23, #0                         ; =0x0
	mov	w24, #40                        ; =0x28
Lloh12:
	adrp	x21, _types@PAGE
Lloh13:
	add	x21, x21, _types@PAGEOFF
LBB0_61:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_77 Depth 2
	add	x27, x19, x23, lsl #6
	madd	x26, x23, x24, x21
	ldr	x0, [x27]
	ldr	x1, [x26]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_63
; %bb.62:                               ;   in Loop: Header=BB0_61 Depth=1
	cmp	x0, x1
	b.eq	LBB0_64
	b	LBB0_5
LBB0_63:                                ;   in Loop: Header=BB0_61 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_64:                                ;   in Loop: Header=BB0_61 Depth=1
	ldr	x0, [x27, #8]
	ldr	x1, [x26, #8]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_66
; %bb.65:                               ;   in Loop: Header=BB0_61 Depth=1
	cmp	x0, x1
	b.eq	LBB0_67
	b	LBB0_5
LBB0_66:                                ;   in Loop: Header=BB0_61 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_67:                                ;   in Loop: Header=BB0_61 Depth=1
	ldr	w8, [x27, #16]
	ldr	w9, [x26, #16]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.68:                               ;   in Loop: Header=BB0_61 Depth=1
	ldr	x25, [x27, #32]
	ldr	x8, [x26, #32]
	cmp	x25, x8
	b.ne	LBB0_5
; %bb.69:                               ;   in Loop: Header=BB0_61 Depth=1
	ldr	x8, [x27, #40]
	cbnz	x8, LBB0_5
; %bb.70:                               ;   in Loop: Header=BB0_61 Depth=1
	ldr	x8, [x27, #48]
	cbnz	x8, LBB0_5
; %bb.71:                               ;   in Loop: Header=BB0_61 Depth=1
	ldr	x8, [x27, #56]
	cbnz	x8, LBB0_5
; %bb.72:                               ;   in Loop: Header=BB0_61 Depth=1
	ldr	x8, [x27, #24]
	cbz	x25, LBB0_86
; %bb.73:                               ;   in Loop: Header=BB0_61 Depth=1
	cbz	x8, LBB0_5
; %bb.74:                               ;   in Loop: Header=BB0_61 Depth=1
	ldr	x9, [x26, #24]
	add	x26, x9, #16
	add	x27, x8, #16
	b	LBB0_77
LBB0_75:                                ;   in Loop: Header=BB0_77 Depth=2
	cmp	x0, x1
	b.ne	LBB0_5
LBB0_76:                                ;   in Loop: Header=BB0_77 Depth=2
	add	x26, x26, #32
	add	x27, x27, #24
	subs	x25, x25, #1
	b.eq	LBB0_87
LBB0_77:                                ;   Parent Loop BB0_61 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x0, [x27, #-16]
	ldur	x1, [x26, #-16]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_79
; %bb.78:                               ;   in Loop: Header=BB0_77 Depth=2
	cmp	x0, x1
	b.eq	LBB0_80
	b	LBB0_5
LBB0_79:                                ;   in Loop: Header=BB0_77 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_80:                                ;   in Loop: Header=BB0_77 Depth=2
	ldur	x0, [x27, #-8]
	ldur	x1, [x26, #-8]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_82
; %bb.81:                               ;   in Loop: Header=BB0_77 Depth=2
	cmp	x0, x1
	b.eq	LBB0_83
	b	LBB0_5
LBB0_82:                                ;   in Loop: Header=BB0_77 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_83:                                ;   in Loop: Header=BB0_77 Depth=2
	ldr	x0, [x27]
	ldr	x1, [x26]
	cbz	x0, LBB0_75
; %bb.84:                               ;   in Loop: Header=BB0_77 Depth=2
	cbz	x1, LBB0_75
; %bb.85:                               ;   in Loop: Header=BB0_77 Depth=2
	bl	_strcmp
	cbz	w0, LBB0_76
	b	LBB0_5
LBB0_86:                                ;   in Loop: Header=BB0_61 Depth=1
	cbnz	x8, LBB0_5
LBB0_87:                                ;   in Loop: Header=BB0_61 Depth=1
	add	x23, x23, #1
	cmp	x23, #8
	b.ne	LBB0_61
; %bb.88:
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB0_90
; %bb.89:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	stp	x22, x21, [x8]
	str	x8, [x20]
	b	LBB0_6
LBB0_90:
	mov	w0, #2                          ; =0x2
	b	LBB0_6
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_free      ; -- Begin function nl_file_plan_free
	.globl	_nl_file_plan_free
	.p2align	2
_nl_file_plan_free:                     ; @nl_file_plan_free
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_storage_size ; -- Begin function nl_file_plan_storage_size
	.globl	_nl_file_plan_storage_size
	.p2align	2
_nl_file_plan_storage_size:             ; @nl_file_plan_storage_size
	.cfi_startproc
; %bb.0:
	mov	w0, #16                         ; =0x10
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_interface ; -- Begin function nl_file_plan_interface
	.globl	_nl_file_plan_interface
	.p2align	2
_nl_file_plan_interface:                ; @nl_file_plan_interface
	.cfi_startproc
; %bb.0:
Lloh14:
	adrp	x8, l_.str@PAGE
Lloh15:
	add	x8, x8, l_.str@PAGEOFF
	cmp	x0, #0
	csel	x0, xzr, x8, eq
	ret
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_method_count ; -- Begin function nl_file_plan_method_count
	.globl	_nl_file_plan_method_count
	.p2align	2
_nl_file_plan_method_count:             ; @nl_file_plan_method_count
	.cfi_startproc
; %bb.0:
	mov	w8, #5                          ; =0x5
	cmp	x0, #0
	csel	x0, xzr, x8, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_type_count ; -- Begin function nl_file_plan_type_count
	.globl	_nl_file_plan_type_count
	.p2align	2
_nl_file_plan_type_count:               ; @nl_file_plan_type_count
	.cfi_startproc
; %bb.0:
	mov	w8, #8                          ; =0x8
	cmp	x0, #0
	csel	x0, xzr, x8, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_method    ; -- Begin function nl_file_plan_method
	.globl	_nl_file_plan_method
	.p2align	2
_nl_file_plan_method:                   ; @nl_file_plan_method
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	cbz	x8, LBB6_3
; %bb.1:
	cmp	x1, #4
	b.hi	LBB6_3
; %bb.2:
	ldr	x8, [x8]
	mov	w9, #96                         ; =0x60
	madd	x0, x1, x9, x8
LBB6_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_plan_type      ; -- Begin function nl_file_plan_type
	.globl	_nl_file_plan_type
	.p2align	2
_nl_file_plan_type:                     ; @nl_file_plan_type
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	cbz	x8, LBB7_3
; %bb.1:
	cmp	x1, #7
	b.hi	LBB7_3
; %bb.2:
	ldr	x8, [x8, #8]
	mov	w9, #40                         ; =0x28
	madd	x0, x1, x9, x8
LBB7_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_catalog_interface ; -- Begin function nl_file_catalog_interface
	.globl	_nl_file_catalog_interface
	.p2align	2
_nl_file_catalog_interface:             ; @nl_file_catalog_interface
	.cfi_startproc
; %bb.0:
Lloh16:
	adrp	x0, l_.str@PAGE
Lloh17:
	add	x0, x0, l_.str@PAGEOFF
	ret
	.loh AdrpAdd	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_catalog_method ; -- Begin function nl_file_catalog_method
	.globl	_nl_file_catalog_method
	.p2align	2
_nl_file_catalog_method:                ; @nl_file_catalog_method
	.cfi_startproc
; %bb.0:
	mov	w8, #96                         ; =0x60
Lloh18:
	adrp	x9, _methods@PAGE
Lloh19:
	add	x9, x9, _methods@PAGEOFF
	madd	x8, x0, x8, x9
	cmp	x0, #5
	csel	x0, x8, xzr, lo
	ret
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_file_catalog_type   ; -- Begin function nl_file_catalog_type
	.globl	_nl_file_catalog_type
	.p2align	2
_nl_file_catalog_type:                  ; @nl_file_catalog_type
	.cfi_startproc
; %bb.0:
	mov	w8, #40                         ; =0x28
Lloh20:
	adrp	x9, _types@PAGE
Lloh21:
	add	x9, x9, _types@PAGEOFF
	madd	x8, x0, x8, x9
	cmp	x0, #8
	csel	x0, x8, xzr, lo
	ret
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/filesystem"

l_.str.1:                               ; @.str.1
	.asciz	"filesystem"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:nanolang/filesystem#io"

l_.str.5:                               ; @.str.5
	.asciz	"cap:nanolang/filesystem.temp"

l_.str.6:                               ; @.str.6
	.asciz	"temp"

l_.str.7:                               ; @.str.7
	.asciz	"nsi:nanolang/filesystem#temp"

l_.str.8:                               ; @.str.8
	.asciz	"nsi_nanolang_filesystem_temp"

l_.str.9:                               ; @.str.9
	.asciz	"nsi.local-file.v1.temp"

l_.str.10:                              ; @.str.10
	.asciz	"nsi:nanolang/filesystem#File"

l_.str.11:                              ; @.str.11
	.asciz	"nsi:nanolang/filesystem#write_byte"

l_.str.12:                              ; @.str.12
	.asciz	"write_byte"

l_.str.13:                              ; @.str.13
	.asciz	"nsi_nanolang_filesystem_write_byte"

l_.str.14:                              ; @.str.14
	.asciz	"nsi.local-file.v1.write_byte"

l_.str.15:                              ; @.str.15
	.asciz	"nsi:nanolang/filesystem#rewind"

l_.str.16:                              ; @.str.16
	.asciz	"rewind"

l_.str.17:                              ; @.str.17
	.asciz	"nsi_nanolang_filesystem_rewind"

l_.str.18:                              ; @.str.18
	.asciz	"nsi.local-file.v1.rewind"

l_.str.19:                              ; @.str.19
	.asciz	"nsi:nanolang/filesystem#read_byte"

l_.str.20:                              ; @.str.20
	.asciz	"read_byte"

l_.str.21:                              ; @.str.21
	.asciz	"nsi_nanolang_filesystem_read_byte"

l_.str.22:                              ; @.str.22
	.asciz	"nsi.local-file.v1.read_byte"

l_.str.23:                              ; @.str.23
	.asciz	"nsi:nanolang/filesystem#close"

l_.str.24:                              ; @.str.24
	.asciz	"close"

l_.str.25:                              ; @.str.25
	.asciz	"nsi_nanolang_filesystem_close"

l_.str.26:                              ; @.str.26
	.asciz	"nsi.local-file.v1.close"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @methods
_methods:
	.quad	l_.str.7
	.quad	l_.str.6
	.quad	l_.str.8
	.quad	l_.str.9
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	19                              ; 0x13
	.long	0                               ; 0x0
	.quad	_temp_params
	.quad	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.10
	.space	16
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13
	.quad	l_.str.14
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_write_params
	.quad	3                               ; 0x3
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.15
	.quad	l_.str.16
	.quad	l_.str.17
	.quad	l_.str.18
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_rewind_params
	.quad	2                               ; 0x2
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.19
	.quad	l_.str.20
	.quad	l_.str.21
	.quad	l_.str.22
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_read_params
	.quad	2                               ; 0x2
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.23
	.quad	l_.str.24
	.quad	l_.str.25
	.quad	l_.str.26
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.quad	_close_params
	.quad	2                               ; 0x2
	.long	2                               ; 0x2
	.space	4
	.quad	0
	.long	2                               ; 0x2
	.space	4
	.quad	0

	.section	__TEXT,__cstring,cstring_literals
l_.str.28:                              ; @.str.28
	.asciz	"nsi:nanolang/filesystem#temp.result"

l_.str.29:                              ; @.str.29
	.asciz	"result"

l_.str.30:                              ; @.str.30
	.asciz	"nsi:nanolang/filesystem#OpenResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @temp_params
_temp_params:
	.quad	l_.str.28
	.quad	l_.str.29
	.quad	l_.str.30
	.long	3                               ; 0x3
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.32:                              ; @.str.32
	.asciz	"nsi:nanolang/filesystem#write_byte.file"

l_.str.33:                              ; @.str.33
	.asciz	"file"

l_.str.34:                              ; @.str.34
	.asciz	"nsi:nanolang/filesystem#write_byte.value"

l_.str.35:                              ; @.str.35
	.asciz	"value"

l_.str.36:                              ; @.str.36
	.asciz	"nsi:core/int"

l_.str.37:                              ; @.str.37
	.asciz	"nsi:nanolang/filesystem#write_byte.result"

l_.str.38:                              ; @.str.38
	.asciz	"nsi:nanolang/filesystem#WriteResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @write_params
_write_params:
	.quad	l_.str.32
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.34
	.quad	l_.str.35
	.quad	l_.str.36
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.space	4
	.quad	l_.str.37
	.quad	l_.str.29
	.quad	l_.str.38
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.40:                              ; @.str.40
	.asciz	"nsi:nanolang/filesystem#rewind.file"

l_.str.41:                              ; @.str.41
	.asciz	"nsi:nanolang/filesystem#rewind.result"

l_.str.42:                              ; @.str.42
	.asciz	"nsi:nanolang/filesystem#PositionResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @rewind_params
_rewind_params:
	.quad	l_.str.40
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.41
	.quad	l_.str.29
	.quad	l_.str.42
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.44:                              ; @.str.44
	.asciz	"nsi:nanolang/filesystem#read_byte.file"

l_.str.45:                              ; @.str.45
	.asciz	"nsi:nanolang/filesystem#read_byte.result"

l_.str.46:                              ; @.str.46
	.asciz	"nsi:nanolang/filesystem#ReadResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @read_params
_read_params:
	.quad	l_.str.44
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.45
	.quad	l_.str.29
	.quad	l_.str.46
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.48:                              ; @.str.48
	.asciz	"nsi:nanolang/filesystem#close.file"

l_.str.49:                              ; @.str.49
	.asciz	"nsi:nanolang/filesystem#close.result"

l_.str.50:                              ; @.str.50
	.asciz	"nsi:nanolang/filesystem#CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @close_params
_close_params:
	.quad	l_.str.48
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.49
	.quad	l_.str.29
	.quad	l_.str.50
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.52:                              ; @.str.52
	.asciz	"File"

l_.str.53:                              ; @.str.53
	.asciz	"nsi:nanolang/filesystem#FileError"

l_.str.54:                              ; @.str.54
	.asciz	"FileError"

l_.str.55:                              ; @.str.55
	.asciz	"nsi:nanolang/filesystem#ReadByte"

l_.str.56:                              ; @.str.56
	.asciz	"ReadByte"

l_.str.57:                              ; @.str.57
	.asciz	"OpenResult"

l_.str.58:                              ; @.str.58
	.asciz	"WriteResult"

l_.str.59:                              ; @.str.59
	.asciz	"PositionResult"

l_.str.60:                              ; @.str.60
	.asciz	"ReadResult"

l_.str.61:                              ; @.str.61
	.asciz	"CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @types
_types:
	.quad	l_.str.10
	.quad	l_.str.52
	.long	6                               ; 0x6
	.space	4
	.quad	0
	.quad	0                               ; 0x0
	.quad	l_.str.53
	.quad	l_.str.54
	.long	1                               ; 0x1
	.space	4
	.quad	_error_fields
	.quad	7                               ; 0x7
	.quad	l_.str.55
	.quad	l_.str.56
	.long	1                               ; 0x1
	.space	4
	.quad	_byte_fields
	.quad	2                               ; 0x2
	.quad	l_.str.30
	.quad	l_.str.57
	.long	2                               ; 0x2
	.space	4
	.quad	_OpenResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.38
	.quad	l_.str.58
	.long	2                               ; 0x2
	.space	4
	.quad	_WriteResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.42
	.quad	l_.str.59
	.long	2                               ; 0x2
	.space	4
	.quad	_PositionResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.46
	.quad	l_.str.60
	.long	2                               ; 0x2
	.space	4
	.quad	_ReadResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.50
	.quad	l_.str.61
	.long	2                               ; 0x2
	.space	4
	.quad	_CloseResult_cases
	.quad	2                               ; 0x2

	.section	__TEXT,__cstring,cstring_literals
l_.str.63:                              ; @.str.63
	.asciz	"nsi:nanolang/filesystem#FileError.status"

l_.str.64:                              ; @.str.64
	.asciz	"status"

l_.str.65:                              ; @.str.65
	.asciz	"nsi:nanolang/filesystem#FileError.host_errno"

l_.str.66:                              ; @.str.66
	.asciz	"host_errno"

l_.str.67:                              ; @.str.67
	.asciz	"nsi:nanolang/filesystem#FileError.cleanup_errno"

l_.str.68:                              ; @.str.68
	.asciz	"cleanup_errno"

l_.str.69:                              ; @.str.69
	.asciz	"nsi:nanolang/filesystem#FileError.bytes"

l_.str.70:                              ; @.str.70
	.asciz	"bytes"

l_.str.71:                              ; @.str.71
	.asciz	"nsi:nanolang/filesystem#FileError.eof"

l_.str.72:                              ; @.str.72
	.asciz	"eof"

l_.str.73:                              ; @.str.73
	.asciz	"nsi:core/bool"

l_.str.74:                              ; @.str.74
	.asciz	"nsi:nanolang/filesystem#FileError.consumed"

l_.str.75:                              ; @.str.75
	.asciz	"consumed"

l_.str.76:                              ; @.str.76
	.asciz	"nsi:nanolang/filesystem#FileError.cleanup_failed"

l_.str.77:                              ; @.str.77
	.asciz	"cleanup_failed"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @error_fields
_error_fields:
	.quad	l_.str.63
	.quad	l_.str.64
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.65
	.quad	l_.str.66
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.67
	.quad	l_.str.68
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.69
	.quad	l_.str.70
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.71
	.quad	l_.str.72
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.74
	.quad	l_.str.75
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.76
	.quad	l_.str.77
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.79:                              ; @.str.79
	.asciz	"nsi:nanolang/filesystem#ReadByte.value"

l_.str.80:                              ; @.str.80
	.asciz	"nsi:nanolang/filesystem#ReadByte.eof"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @byte_fields
_byte_fields:
	.quad	l_.str.79
	.quad	l_.str.35
	.quad	l_.str.36
	.long	1                               ; 0x1
	.space	4
	.quad	l_.str.80
	.quad	l_.str.72
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.82:                              ; @.str.82
	.asciz	"nsi:nanolang/filesystem#OpenResult.Ok"

l_.str.83:                              ; @.str.83
	.asciz	"Ok"

l_.str.84:                              ; @.str.84
	.asciz	"nsi:nanolang/filesystem#OpenResult.Error"

l_.str.85:                              ; @.str.85
	.asciz	"Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @OpenResult_cases
_OpenResult_cases:
	.quad	l_.str.82
	.quad	l_.str.83
	.quad	l_.str.10
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.84
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.87:                              ; @.str.87
	.asciz	"nsi:nanolang/filesystem#WriteResult.Ok"

l_.str.88:                              ; @.str.88
	.asciz	"nsi:nanolang/filesystem#WriteResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @WriteResult_cases
_WriteResult_cases:
	.quad	l_.str.87
	.quad	l_.str.83
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.88
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.90:                              ; @.str.90
	.asciz	"nsi:nanolang/filesystem#PositionResult.Ok"

l_.str.91:                              ; @.str.91
	.asciz	"nsi:nanolang/filesystem#PositionResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @PositionResult_cases
_PositionResult_cases:
	.quad	l_.str.90
	.quad	l_.str.83
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.91
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.93:                              ; @.str.93
	.asciz	"nsi:nanolang/filesystem#ReadResult.Ok"

l_.str.94:                              ; @.str.94
	.asciz	"nsi:nanolang/filesystem#ReadResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ReadResult_cases
_ReadResult_cases:
	.quad	l_.str.93
	.quad	l_.str.83
	.quad	l_.str.55
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.94
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.96:                              ; @.str.96
	.asciz	"nsi:nanolang/filesystem#CloseResult.Ok"

l_.str.97:                              ; @.str.97
	.asciz	"nsi:nanolang/filesystem#CloseResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @CloseResult_cases
_CloseResult_cases:
	.quad	l_.str.96
	.quad	l_.str.83
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.97
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

.subsections_via_symbols
