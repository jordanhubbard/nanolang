
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <errno.h>
static int traced_system(const char *command) {
 static unsigned sequence;
 unsigned index=sequence++;
 const char *directory=getenv("NANO_SYSTEM_TRACE");
 char path[4096];
 if (directory && command) {
  snprintf(path,sizeof path,"%s/%u.command",directory,index);
  FILE *f=fopen(path,"wb");if(f){fwrite(command,1,strlen(command),f);fclose(f);}
  if (strstr(command," -std=c11 ")) {
   const char *first=strchr(command,'\'');const char *last=first?strchr(first+1,'\''):NULL;
   if(first&&last&&(size_t)(last-first)<sizeof path){memcpy(path,first+1,(size_t)(last-first-1));path[last-first-1]=0;
    FILE *in=fopen(path,"rb");snprintf(path,sizeof path,"%s/%u.input.c",directory,index);FILE *copy=in?fopen(path,"wb"):NULL;
    if(copy){unsigned char buffer[16384];size_t n;while((n=fread(buffer,1,sizeof buffer,in)))fwrite(buffer,1,n,copy);fclose(copy);}if(in)fclose(in);
   }
  }
 }
 int (*original)(const char *)=(int(*)(const char *))dlsym(RTLD_NEXT,"system");
 int value=original?original(command):-1;int error=errno;
 if(directory){snprintf(path,sizeof path,"%s/%u.result",directory,index);FILE *f=fopen(path,"w");if(f){fprintf(f,"%d %d\n",value,error);fclose(f);}}
 errno=error;return value;
}
__attribute__((used)) static struct { const void *replacement; const void *original; } hooks[]
 __attribute__((section("__DATA,__interpose"))) = {{(const void *)traced_system,(const void *)system}};
