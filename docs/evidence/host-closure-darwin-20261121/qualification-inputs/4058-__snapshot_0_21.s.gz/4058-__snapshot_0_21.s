	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_crc32                      ; -- Begin function nvm_crc32
	.p2align	2
_nvm_crc32:                             ; @nvm_crc32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	bl	_crc32_init
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB0_1
LBB0_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	w9, [x29, #-12]
	subs	w8, w8, w9
	b.hs	LBB0_4
	b	LBB0_2
LBB0_2:                                 ;   in Loop: Header=BB0_1 Depth=1
	ldr	w9, [sp, #16]
	ldr	w8, [sp, #16]
	ldur	x10, [x29, #-8]
	ldr	w11, [sp, #12]
                                        ; kill: def $x11 killed $w11
	ldrb	w10, [x10, x11]
	eor	w8, w8, w10
	and	w10, w8, #0xff
	adrp	x8, _crc32_table@PAGE
	add	x8, x8, _crc32_table@PAGEOFF
	ldr	w8, [x8, w10, uxtw #2]
	eor	w8, w8, w9, lsr #8
	str	w8, [sp, #16]
	b	LBB0_3
LBB0_3:                                 ;   in Loop: Header=BB0_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB0_1
LBB0_4:
	ldr	w8, [sp, #16]
	mvn	w0, w8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function crc32_init
_crc32_init:                            ; @crc32_init
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	adrp	x8, _crc32_initialized@PAGE
	ldrb	w8, [x8, _crc32_initialized@PAGEOFF]
	tbz	w8, #0, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_14
LBB1_2:
	str	wzr, [sp, #12]
	b	LBB1_3
LBB1_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_5 Depth 2
	ldr	w8, [sp, #12]
	subs	w8, w8, #256
	b.hs	LBB1_13
	b	LBB1_4
LBB1_4:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	w8, [sp, #12]
	str	w8, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB1_5
LBB1_5:                                 ;   Parent Loop BB1_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #4]
	subs	w8, w8, #8
	b.ge	LBB1_11
	b	LBB1_6
LBB1_6:                                 ;   in Loop: Header=BB1_5 Depth=2
	ldr	w8, [sp, #8]
	tbz	w8, #0, LBB1_8
	b	LBB1_7
LBB1_7:                                 ;   in Loop: Header=BB1_5 Depth=2
	ldr	w9, [sp, #8]
	mov	w8, #33568                      ; =0x8320
	movk	w8, #60856, lsl #16
	eor	w8, w8, w9, lsr #1
	str	w8, [sp, #8]
	b	LBB1_9
LBB1_8:                                 ;   in Loop: Header=BB1_5 Depth=2
	ldr	w8, [sp, #8]
	lsr	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_5 Depth=2
	b	LBB1_10
LBB1_10:                                ;   in Loop: Header=BB1_5 Depth=2
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB1_5
LBB1_11:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	mov	x10, x9
	adrp	x9, _crc32_table@PAGE
	add	x9, x9, _crc32_table@PAGEOFF
	str	w8, [x9, x10, lsl #2]
	b	LBB1_12
LBB1_12:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB1_3
LBB1_13:
	mov	w8, #1                          ; =0x1
	adrp	x9, _crc32_initialized@PAGE
	strb	w8, [x9, _crc32_initialized@PAGEOFF]
	b	LBB1_14
LBB1_14:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_module_new                 ; -- Begin function nvm_module_new
	.p2align	2
_nvm_module_new:                        ; @nvm_module_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, #1                          ; =0x1
	mov	x1, #480                        ; =0x1e0
	bl	_calloc
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB2_13
LBB2_2:
	ldur	x9, [x29, #-16]
	mov	w8, #78                         ; =0x4e
	strb	w8, [x9]
	ldur	x9, [x29, #-16]
	mov	w8, #86                         ; =0x56
	strb	w8, [x9, #1]
	ldur	x9, [x29, #-16]
	mov	w8, #77                         ; =0x4d
	strb	w8, [x9, #2]
	ldur	x9, [x29, #-16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #3]
	ldur	x9, [x29, #-16]
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #4]
	ldur	x9, [x29, #-16]
	mov	w8, #64                         ; =0x40
	str	w8, [x9, #252]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #252]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	bl	_calloc
	ldur	x8, [x29, #-16]
	str	x0, [x8, #232]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #252]
	mov	x0, x8
	mov	x1, #4                          ; =0x4
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	bl	_calloc
	ldur	x8, [x29, #-16]
	str	x0, [x8, #240]
	ldur	x9, [x29, #-16]
	mov	w8, #32                         ; =0x20
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	str	w8, [x9, #276]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #276]
	mov	x0, x8
	mov	x1, #24                         ; =0x18
	bl	_calloc
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	str	x0, [x8, #256]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #276]
	mov	x0, x8
	bl	_calloc
	ldur	x8, [x29, #-16]
	str	x0, [x8, #264]
	ldur	x9, [x29, #-16]
	mov	w8, #4096                       ; =0x1000
	str	w8, [x9, #292]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #292]
	mov	x0, x8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	ldur	x8, [x29, #-16]
	str	x0, [x8, #280]
	ldur	x9, [x29, #-16]
	mov	w8, #256                        ; =0x100
	str	w8, [x9, #388]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #388]
	mov	x0, x8
	mov	x1, #12                         ; =0xc
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	bl	_calloc
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x9, [x29, #-16]
	str	x0, [x9, #376]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #436]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #436]
	mov	x0, x8
	bl	_calloc
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	str	x0, [x8, #400]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #436]
	mov	x0, x8
	bl	_calloc
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	str	x0, [x8, #408]
	ldur	x9, [x29, #-16]
	mov	w8, #16                         ; =0x10
	str	w8, [x9, #452]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #452]
	mov	x0, x8
	bl	_calloc
	ldur	x8, [x29, #-16]
	str	x0, [x8, #440]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	cbz	x8, LBB2_11
	b	LBB2_3
LBB2_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	cbz	x8, LBB2_11
	b	LBB2_4
LBB2_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB2_11
	b	LBB2_5
LBB2_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	cbz	x8, LBB2_11
	b	LBB2_6
LBB2_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	cbz	x8, LBB2_11
	b	LBB2_7
LBB2_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #376]
	cbz	x8, LBB2_11
	b	LBB2_8
LBB2_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #400]
	cbz	x8, LBB2_11
	b	LBB2_9
LBB2_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	cbz	x8, LBB2_11
	b	LBB2_10
LBB2_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #440]
	cbnz	x8, LBB2_12
	b	LBB2_11
LBB2_11:
	ldur	x0, [x29, #-16]
	bl	_nvm_module_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB2_13
LBB2_12:
	ldur	x8, [x29, #-16]
	stur	x8, [x29, #-8]
	b	LBB2_13
LBB2_13:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_module_free                ; -- Begin function nvm_module_free
	.p2align	2
_nvm_module_free:                       ; @nvm_module_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	b	LBB3_21
LBB3_2:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	cbz	x8, LBB3_8
	b	LBB3_3
LBB3_3:
	stur	wzr, [x29, #-12]
	b	LBB3_4
LBB3_4:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB3_7
	b	LBB3_5
LBB3_5:                                 ;   in Loop: Header=BB3_4 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	b	LBB3_6
LBB3_6:                                 ;   in Loop: Header=BB3_4 Depth=1
	ldur	w8, [x29, #-12]
	add	w8, w8, #1
	stur	w8, [x29, #-12]
	b	LBB3_4
LBB3_7:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #232]
	bl	_free
	b	LBB3_8
LBB3_8:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #240]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #256]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #264]
	cbz	x8, LBB3_14
	b	LBB3_9
LBB3_9:
	str	wzr, [sp, #16]
	b	LBB3_10
LBB3_10:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB3_13
	b	LBB3_11
LBB3_11:                                ;   in Loop: Header=BB3_10 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	b	LBB3_12
LBB3_12:                                ;   in Loop: Header=BB3_10 Depth=1
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB3_10
LBB3_13:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #264]
	bl	_free
	b	LBB3_14
LBB3_14:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #280]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #376]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #408]
	cbz	x8, LBB3_20
	b	LBB3_15
LBB3_15:
	str	wzr, [sp, #12]
	b	LBB3_16
LBB3_16:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB3_19
	b	LBB3_17
LBB3_17:                                ;   in Loop: Header=BB3_16 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	b	LBB3_18
LBB3_18:                                ;   in Loop: Header=BB3_16 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB3_16
LBB3_19:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #408]
	bl	_free
	b	LBB3_20
LBB3_20:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #400]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #416]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #344]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #312]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #296]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #328]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #360]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #440]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #456]
	bl	_free
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB3_21
LBB3_21:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_metadata_source_key        ; -- Begin function nvm_metadata_source_key
	.p2align	2
_nvm_metadata_source_key:               ; @nvm_metadata_source_key
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB4_7
	b	LBB4_1
LBB4_1:
	ldr	w9, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #248]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hs	LBB4_7
	b	LBB4_2
LBB4_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #232]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB4_7
	b	LBB4_3
LBB4_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #240]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB4_7
	b	LBB4_4
LBB4_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB4_7
	b	LBB4_5
LBB4_5:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #16
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB4_7
	b	LBB4_6
LBB4_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _nvm_metadata_source_key.name@PAGE
	add	x1, x1, _nvm_metadata_source_key.name@PAGEOFF
	mov	x2, #16                         ; =0x10
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB4_7
LBB4_7:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_metadata_valid             ; -- Begin function nvm_metadata_valid
	.p2align	2
_nvm_metadata_valid:                    ; @nvm_metadata_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB5_3
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #368]
	cbz	w8, LBB5_4
	b	LBB5_2
LBB5_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #360]
	cbnz	x8, LBB5_4
	b	LBB5_3
LBB5_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_18
LBB5_4:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #392]
	str	w8, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB5_5
LBB5_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB5_17
	b	LBB5_6
LBB5_6:                                 ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp]
	ldr	x8, [sp]
	ldr	w8, [x8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB5_12
	b	LBB5_7
LBB5_7:                                 ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB5_12
	b	LBB5_8
LBB5_8:                                 ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #232]
	cbz	x8, LBB5_12
	b	LBB5_9
LBB5_9:                                 ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #240]
	cbz	x8, LBB5_12
	b	LBB5_10
LBB5_10:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #232]
	ldr	x9, [sp]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB5_12
	b	LBB5_11
LBB5_11:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #232]
	ldr	x9, [sp]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB5_13
	b	LBB5_12
LBB5_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_18
LBB5_13:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x0, [sp, #16]
	ldr	x8, [sp]
	ldr	w1, [x8]
	bl	_nvm_metadata_source_key
	tbz	w0, #0, LBB5_15
	b	LBB5_14
LBB5_14:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #4]
	str	w8, [sp, #12]
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_5 Depth=1
	b	LBB5_16
LBB5_16:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB5_5
LBB5_17:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #392]
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_18
LBB5_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_metadata               ; -- Begin function nvm_add_metadata
	.p2align	2
_nvm_add_metadata:                      ; @nvm_add_metadata
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB6_4
	b	LBB6_1
LBB6_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #368]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #372]
	subs	w8, w8, w9
	b.hi	LBB6_4
	b	LBB6_2
LBB6_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB6_4
	b	LBB6_3
LBB6_3:
	ldur	w8, [x29, #-24]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB6_5
	b	LBB6_4
LBB6_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_21
LBB6_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #368]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #372]
	subs	w8, w8, w9
	b.ne	LBB6_18
	b	LBB6_6
LBB6_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #372]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB6_8
	b	LBB6_7
LBB6_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_21
LBB6_8:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #372]
	cbz	w8, LBB6_10
	b	LBB6_9
LBB6_9:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #372]
	lsl	w8, w8, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB6_11
LBB6_10:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB6_11
LBB6_11:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-28]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #3
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	mov	x9, #8                          ; =0x8
	udiv	x8, x8, x9
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.eq	LBB6_13
	b	LBB6_12
LBB6_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_21
LBB6_13:
	ldr	x0, [sp, #24]
	bl	_malloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB6_15
	b	LBB6_14
LBB6_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_21
LBB6_15:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #368]
	cbz	w8, LBB6_17
	b	LBB6_16
LBB6_16:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #360]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #368]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB6_17
LBB6_17:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #360]
	bl	_free
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #360]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #372]
	b	LBB6_18
LBB6_18:
	ldur	x8, [x29, #-16]
	ldr	x9, [x8, #360]
	ldur	x11, [x29, #-16]
	ldr	w8, [x11, #368]
	mov	x10, x8
	mov	x8, x10
	add	w8, w8, #1
	str	w8, [x11, #368]
	ldur	w8, [x29, #-20]
	str	w8, [sp, #8]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #12]
	ldr	x8, [sp, #8]
	str	x8, [x9, x10, lsl #3]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_nvm_metadata_source_key
	tbz	w0, #0, LBB6_20
	b	LBB6_19
LBB6_19:
	ldur	w8, [x29, #-24]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #392]
	b	LBB6_20
LBB6_20:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_21
LBB6_21:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_function_purity            ; -- Begin function nvm_function_purity
	.p2align	2
_nvm_function_purity:                   ; @nvm_function_purity
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB7_2
	b	LBB7_1
LBB7_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB7_3
	b	LBB7_2
LBB7_2:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB7_16
LBB7_3:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB7_4
LBB7_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB7_15
	b	LBB7_5
LBB7_5:                                 ;   in Loop: Header=BB7_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	bl	_purity_entry
	tbnz	w0, #0, LBB7_7
	b	LBB7_6
LBB7_6:                                 ;   in Loop: Header=BB7_4 Depth=1
	b	LBB7_14
LBB7_7:                                 ;   in Loop: Header=BB7_4 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	add	x2, sp, #4
	mov	x3, sp
	bl	_purity_record
	tbnz	w0, #0, LBB7_9
	b	LBB7_8
LBB7_8:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB7_16
LBB7_9:                                 ;   in Loop: Header=BB7_4 Depth=1
	ldr	w8, [sp, #4]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB7_13
	b	LBB7_10
LBB7_10:                                ;   in Loop: Header=BB7_4 Depth=1
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB7_12
	b	LBB7_11
LBB7_11:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB7_16
LBB7_12:                                ;   in Loop: Header=BB7_4 Depth=1
	ldr	w8, [sp]
	str	w8, [sp, #24]
	b	LBB7_13
LBB7_13:                                ;   in Loop: Header=BB7_4 Depth=1
	b	LBB7_14
LBB7_14:                                ;   in Loop: Header=BB7_4 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB7_4
LBB7_15:
	ldr	w8, [sp, #24]
	stur	w8, [x29, #-4]
	b	LBB7_16
LBB7_16:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function purity_entry
_purity_entry:                          ; @purity_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #14
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB8_2
	b	LBB8_1
LBB8_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _purity_key@PAGE
	add	x1, x1, _purity_key@PAGEOFF
	mov	x2, #14                         ; =0xe
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB8_2
LBB8_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function purity_record
_purity_record:                         ; @purity_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #8
	b.eq	LBB9_2
	b	LBB9_1
LBB9_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB9_8
LBB9_2:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #24
	ldr	x9, [sp, #32]
	str	w8, [x9]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	ldr	x9, [sp, #24]
	str	w8, [x9]
	ldr	x8, [sp, #32]
	ldr	w9, [x8]
	ldr	x8, [sp, #48]
	ldr	w10, [x8, #272]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB9_7
	b	LBB9_3
LBB9_3:
	ldr	x8, [sp, #16]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.gt	LBB9_7
	b	LBB9_4
LBB9_4:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #5]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB9_7
	b	LBB9_5
LBB9_5:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #6]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB9_7
	b	LBB9_6
LBB9_6:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #7]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB9_7
LBB9_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB9_8
LBB9_8:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_function_purity        ; -- Begin function nvm_add_function_purity
	.p2align	2
_nvm_add_function_purity:               ; @nvm_add_function_purity
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	sturb	w2, [x29, #-37]
	ldur	x0, [x29, #-32]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB10_2
	b	LBB10_1
LBB10_1:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB10_3
	b	LBB10_2
LBB10_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB10_21
LBB10_3:
	stur	wzr, [x29, #-44]
	b	LBB10_4
LBB10_4:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB10_12
	b	LBB10_5
LBB10_5:                                ;   in Loop: Header=BB10_4 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #40]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	bl	_purity_entry
	tbnz	w0, #0, LBB10_7
	b	LBB10_6
LBB10_6:                                ;   in Loop: Header=BB10_4 Depth=1
	b	LBB10_11
LBB10_7:                                ;   in Loop: Header=BB10_4 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	add	x2, sp, #36
	add	x3, sp, #32
	bl	_purity_record
	tbz	w0, #0, LBB10_9
	b	LBB10_8
LBB10_8:                                ;   in Loop: Header=BB10_4 Depth=1
	ldr	w8, [sp, #36]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB10_10
	b	LBB10_9
LBB10_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB10_21
LBB10_10:                               ;   in Loop: Header=BB10_4 Depth=1
	b	LBB10_11
LBB10_11:                               ;   in Loop: Header=BB10_4 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB10_4
LBB10_12:
	stur	xzr, [x29, #-16]
	str	wzr, [sp, #28]
	b	LBB10_13
LBB10_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #4
	b.hs	LBB10_16
	b	LBB10_14
LBB10_14:                               ;   in Loop: Header=BB10_13 Depth=1
	ldur	w8, [x29, #-36]
	ldr	w10, [sp, #28]
	mov	w9, #8                          ; =0x8
	mul	w9, w9, w10
	lsr	w8, w8, w9
	ldr	w9, [sp, #28]
	mov	x10, x9
	sub	x9, x29, #16
	strb	w8, [x9, x10]
	b	LBB10_15
LBB10_15:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB10_13
LBB10_16:
	ldurb	w8, [x29, #-37]
	and	w8, w8, #0x1
	sturb	w8, [x29, #-12]
	ldur	x0, [x29, #-32]
	adrp	x1, _purity_key@PAGE
	add	x1, x1, _purity_key@PAGEOFF
	mov	w2, #14                         ; =0xe
	bl	_nvm_add_string
	str	w0, [sp, #24]
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.ne	LBB10_18
	b	LBB10_17
LBB10_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB10_21
LBB10_18:
	ldur	x0, [x29, #-32]
	sub	x1, x29, #16
	mov	w2, #8                          ; =0x8
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.eq	LBB10_20
	b	LBB10_19
LBB10_19:
	ldur	x0, [x29, #-32]
	ldr	w1, [sp, #24]
	ldr	w2, [sp, #20]
	bl	_nvm_add_metadata
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB10_20
LBB10_20:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB10_21
LBB10_21:
	ldurb	w8, [x29, #-17]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB10_23
	b	LBB10_22
LBB10_22:
	bl	___stack_chk_fail
LBB10_23:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_string                 ; -- Begin function nvm_add_string
	.p2align	2
_nvm_add_string:                        ; @nvm_add_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB11_3
	b	LBB11_1
LBB11_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB11_4
	b	LBB11_2
LBB11_2:
	ldur	w8, [x29, #-28]
	cbz	w8, LBB11_4
	b	LBB11_3
LBB11_3:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_4:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB11_6
	b	LBB11_5
LBB11_5:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB11_6
LBB11_6:
	stur	wzr, [x29, #-32]
	b	LBB11_7
LBB11_7:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB11_13
	b	LBB11_8
LBB11_8:                                ;   in Loop: Header=BB11_7 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.ne	LBB11_11
	b	LBB11_9
LBB11_9:                                ;   in Loop: Header=BB11_7 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldur	x1, [x29, #-24]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	bl	_memcmp
	cbnz	w0, LBB11_11
	b	LBB11_10
LBB11_10:
	ldur	w8, [x29, #-32]
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_11:                               ;   in Loop: Header=BB11_7 Depth=1
	b	LBB11_12
LBB11_12:                               ;   in Loop: Header=BB11_7 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB11_7
LBB11_13:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #248]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #252]
	subs	w8, w8, w9
	b.lo	LBB11_25
	b	LBB11_14
LBB11_14:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #252]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB11_16
	b	LBB11_15
LBB11_15:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_16:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #252]
	cbz	w8, LBB11_18
	b	LBB11_17
LBB11_17:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #252]
	lsl	w8, w8, #1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB11_19
LBB11_18:
	mov	w8, #16                         ; =0x10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB11_19
LBB11_19:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #3
	bl	_malloc
	str	x0, [sp, #32]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #2
	bl	_malloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB11_21
	b	LBB11_20
LBB11_20:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB11_22
	b	LBB11_21
LBB11_21:
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x0, [sp, #24]
	bl	_free
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_22:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #248]
	cbz	w8, LBB11_24
	b	LBB11_23
LBB11_23:
	ldr	x0, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #232]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #248]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #240]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #248]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #2
	bl	___memcpy_chk
	b	LBB11_24
LBB11_24:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #232]
	bl	_free
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #240]
	bl	_free
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #232]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #240]
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #252]
	b	LBB11_25
LBB11_25:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #248]
	str	w8, [sp, #20]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB11_27
	b	LBB11_26
LBB11_26:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_27:
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	add	x0, x8, #1
	bl	_malloc
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	str	x0, [x8, x9, lsl #3]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB11_29
	b	LBB11_28
LBB11_28:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_29:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldur	x1, [x29, #-24]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #240]
	ldr	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #248]
	add	w8, w8, #1
	str	w8, [x9, #248]
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB11_30
LBB11_30:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_function_effects           ; -- Begin function nvm_function_effects
	.p2align	2
_nvm_function_effects:                  ; @nvm_function_effects
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB12_2
	b	LBB12_1
LBB12_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB12_3
	b	LBB12_2
LBB12_2:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB12_16
LBB12_3:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB12_4
LBB12_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB12_15
	b	LBB12_5
LBB12_5:                                ;   in Loop: Header=BB12_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	bl	_effects_entry
	tbnz	w0, #0, LBB12_7
	b	LBB12_6
LBB12_6:                                ;   in Loop: Header=BB12_4 Depth=1
	b	LBB12_14
LBB12_7:                                ;   in Loop: Header=BB12_4 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	add	x2, sp, #4
	mov	x3, sp
	bl	_effects_record
	tbnz	w0, #0, LBB12_9
	b	LBB12_8
LBB12_8:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB12_16
LBB12_9:                                ;   in Loop: Header=BB12_4 Depth=1
	ldr	w8, [sp, #4]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB12_13
	b	LBB12_10
LBB12_10:                               ;   in Loop: Header=BB12_4 Depth=1
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB12_12
	b	LBB12_11
LBB12_11:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB12_16
LBB12_12:                               ;   in Loop: Header=BB12_4 Depth=1
	ldr	w8, [sp]
	str	w8, [sp, #24]
	b	LBB12_13
LBB12_13:                               ;   in Loop: Header=BB12_4 Depth=1
	b	LBB12_14
LBB12_14:                               ;   in Loop: Header=BB12_4 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB12_4
LBB12_15:
	ldr	w8, [sp, #24]
	stur	w8, [x29, #-4]
	b	LBB12_16
LBB12_16:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effects_entry
_effects_entry:                         ; @effects_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #15
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB13_2
	b	LBB13_1
LBB13_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _effects_key@PAGE
	add	x1, x1, _effects_key@PAGEOFF
	mov	x2, #15                         ; =0xf
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_2
LBB13_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effects_record
_effects_record:                        ; @effects_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #8
	b.eq	LBB14_2
	b	LBB14_1
LBB14_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB14_8
LBB14_2:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #24
	ldr	x9, [sp, #32]
	str	w8, [x9]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	ldr	x9, [sp, #24]
	str	w8, [x9]
	ldr	x8, [sp, #32]
	ldr	w9, [x8]
	ldr	x8, [sp, #48]
	ldr	w10, [x8, #272]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB14_7
	b	LBB14_3
LBB14_3:
	ldr	x8, [sp, #16]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #63
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.gt	LBB14_7
	b	LBB14_4
LBB14_4:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #5]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB14_7
	b	LBB14_5
LBB14_5:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #6]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB14_7
	b	LBB14_6
LBB14_6:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #7]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB14_7
LBB14_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB14_8
LBB14_8:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_function_effects       ; -- Begin function nvm_add_function_effects
	.p2align	2
_nvm_add_function_effects:              ; @nvm_add_function_effects
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	w2, [x29, #-40]
	ldur	w8, [x29, #-40]
	subs	w8, w8, #63
	b.hi	LBB15_3
	b	LBB15_1
LBB15_1:
	ldur	x0, [x29, #-32]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB15_3
	b	LBB15_2
LBB15_2:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB15_4
	b	LBB15_3
LBB15_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB15_22
LBB15_4:
	stur	wzr, [x29, #-44]
	b	LBB15_5
LBB15_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB15_13
	b	LBB15_6
LBB15_6:                                ;   in Loop: Header=BB15_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #40]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	bl	_effects_entry
	tbnz	w0, #0, LBB15_8
	b	LBB15_7
LBB15_7:                                ;   in Loop: Header=BB15_5 Depth=1
	b	LBB15_12
LBB15_8:                                ;   in Loop: Header=BB15_5 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	add	x2, sp, #36
	add	x3, sp, #32
	bl	_effects_record
	tbz	w0, #0, LBB15_10
	b	LBB15_9
LBB15_9:                                ;   in Loop: Header=BB15_5 Depth=1
	ldr	w8, [sp, #36]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB15_11
	b	LBB15_10
LBB15_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB15_22
LBB15_11:                               ;   in Loop: Header=BB15_5 Depth=1
	b	LBB15_12
LBB15_12:                               ;   in Loop: Header=BB15_5 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB15_5
LBB15_13:
	stur	xzr, [x29, #-16]
	str	wzr, [sp, #28]
	b	LBB15_14
LBB15_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #4
	b.hs	LBB15_17
	b	LBB15_15
LBB15_15:                               ;   in Loop: Header=BB15_14 Depth=1
	ldur	w8, [x29, #-36]
	ldr	w10, [sp, #28]
	mov	w9, #8                          ; =0x8
	mul	w9, w9, w10
	lsr	w8, w8, w9
	ldr	w9, [sp, #28]
	mov	x10, x9
	sub	x9, x29, #16
	strb	w8, [x9, x10]
	b	LBB15_16
LBB15_16:                               ;   in Loop: Header=BB15_14 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB15_14
LBB15_17:
	ldur	w8, [x29, #-40]
	sturb	w8, [x29, #-12]
	ldur	x0, [x29, #-32]
	adrp	x1, _effects_key@PAGE
	add	x1, x1, _effects_key@PAGEOFF
	mov	w2, #15                         ; =0xf
	bl	_nvm_add_string
	str	w0, [sp, #24]
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.ne	LBB15_19
	b	LBB15_18
LBB15_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB15_22
LBB15_19:
	ldur	x0, [x29, #-32]
	sub	x1, x29, #16
	mov	w2, #8                          ; =0x8
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.eq	LBB15_21
	b	LBB15_20
LBB15_20:
	ldur	x0, [x29, #-32]
	ldr	w1, [sp, #24]
	ldr	w2, [sp, #20]
	bl	_nvm_add_metadata
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB15_21
LBB15_21:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB15_22
LBB15_22:
	ldurb	w8, [x29, #-17]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB15_24
	b	LBB15_23
LBB15_23:
	bl	___stack_chk_fail
LBB15_24:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_function_affine            ; -- Begin function nvm_function_affine
	.p2align	2
_nvm_function_affine:                   ; @nvm_function_affine
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB16_2
	b	LBB16_1
LBB16_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB16_3
	b	LBB16_2
LBB16_2:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB16_16
LBB16_3:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB16_4
LBB16_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB16_15
	b	LBB16_5
LBB16_5:                                ;   in Loop: Header=BB16_4 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	bl	_affine_entry
	tbnz	w0, #0, LBB16_7
	b	LBB16_6
LBB16_6:                                ;   in Loop: Header=BB16_4 Depth=1
	b	LBB16_14
LBB16_7:                                ;   in Loop: Header=BB16_4 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	add	x2, sp, #4
	mov	x3, sp
	bl	_affine_record
	tbnz	w0, #0, LBB16_9
	b	LBB16_8
LBB16_8:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB16_16
LBB16_9:                                ;   in Loop: Header=BB16_4 Depth=1
	ldr	w8, [sp, #4]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB16_13
	b	LBB16_10
LBB16_10:                               ;   in Loop: Header=BB16_4 Depth=1
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB16_12
	b	LBB16_11
LBB16_11:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB16_16
LBB16_12:                               ;   in Loop: Header=BB16_4 Depth=1
	ldr	w8, [sp]
	str	w8, [sp, #24]
	b	LBB16_13
LBB16_13:                               ;   in Loop: Header=BB16_4 Depth=1
	b	LBB16_14
LBB16_14:                               ;   in Loop: Header=BB16_4 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB16_4
LBB16_15:
	ldr	w8, [sp, #24]
	stur	w8, [x29, #-4]
	b	LBB16_16
LBB16_16:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function affine_entry
_affine_entry:                          ; @affine_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #14
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB17_2
	b	LBB17_1
LBB17_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _affine_key@PAGE
	add	x1, x1, _affine_key@PAGEOFF
	mov	x2, #14                         ; =0xe
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB17_2
LBB17_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function affine_record
_affine_record:                         ; @affine_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #8
	b.eq	LBB18_2
	b	LBB18_1
LBB18_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB18_8
LBB18_2:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #24
	ldr	x9, [sp, #32]
	str	w8, [x9]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	ldr	x9, [sp, #24]
	str	w8, [x9]
	ldr	x8, [sp, #32]
	ldr	w9, [x8]
	ldr	x8, [sp, #48]
	ldr	w10, [x8, #272]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB18_7
	b	LBB18_3
LBB18_3:
	ldr	x8, [sp, #16]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.gt	LBB18_7
	b	LBB18_4
LBB18_4:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #5]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB18_7
	b	LBB18_5
LBB18_5:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #6]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB18_7
	b	LBB18_6
LBB18_6:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #7]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB18_7
LBB18_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB18_8
LBB18_8:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_function_affine        ; -- Begin function nvm_add_function_affine
	.p2align	2
_nvm_add_function_affine:               ; @nvm_add_function_affine
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	w2, [x29, #-40]
	ldur	w8, [x29, #-40]
	subs	w8, w8, #1
	b.hi	LBB19_3
	b	LBB19_1
LBB19_1:
	ldur	x0, [x29, #-32]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB19_3
	b	LBB19_2
LBB19_2:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB19_4
	b	LBB19_3
LBB19_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB19_22
LBB19_4:
	stur	wzr, [x29, #-44]
	b	LBB19_5
LBB19_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB19_13
	b	LBB19_6
LBB19_6:                                ;   in Loop: Header=BB19_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #40]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	bl	_affine_entry
	tbnz	w0, #0, LBB19_8
	b	LBB19_7
LBB19_7:                                ;   in Loop: Header=BB19_5 Depth=1
	b	LBB19_12
LBB19_8:                                ;   in Loop: Header=BB19_5 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	add	x2, sp, #36
	add	x3, sp, #32
	bl	_affine_record
	tbz	w0, #0, LBB19_10
	b	LBB19_9
LBB19_9:                                ;   in Loop: Header=BB19_5 Depth=1
	ldr	w8, [sp, #36]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB19_11
	b	LBB19_10
LBB19_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB19_22
LBB19_11:                               ;   in Loop: Header=BB19_5 Depth=1
	b	LBB19_12
LBB19_12:                               ;   in Loop: Header=BB19_5 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB19_5
LBB19_13:
	stur	xzr, [x29, #-16]
	str	wzr, [sp, #28]
	b	LBB19_14
LBB19_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #4
	b.hs	LBB19_17
	b	LBB19_15
LBB19_15:                               ;   in Loop: Header=BB19_14 Depth=1
	ldur	w8, [x29, #-36]
	ldr	w10, [sp, #28]
	mov	w9, #8                          ; =0x8
	mul	w9, w9, w10
	lsr	w8, w8, w9
	ldr	w9, [sp, #28]
	mov	x10, x9
	sub	x9, x29, #16
	strb	w8, [x9, x10]
	b	LBB19_16
LBB19_16:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB19_14
LBB19_17:
	ldur	w8, [x29, #-40]
	sturb	w8, [x29, #-12]
	ldur	x0, [x29, #-32]
	adrp	x1, _affine_key@PAGE
	add	x1, x1, _affine_key@PAGEOFF
	mov	w2, #14                         ; =0xe
	bl	_nvm_add_string
	str	w0, [sp, #24]
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.ne	LBB19_19
	b	LBB19_18
LBB19_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB19_22
LBB19_19:
	ldur	x0, [x29, #-32]
	sub	x1, x29, #16
	mov	w2, #8                          ; =0x8
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.eq	LBB19_21
	b	LBB19_20
LBB19_20:
	ldur	x0, [x29, #-32]
	ldr	w1, [sp, #24]
	ldr	w2, [sp, #20]
	bl	_nvm_add_metadata
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB19_21
LBB19_21:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB19_22
LBB19_22:
	ldurb	w8, [x29, #-17]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB19_24
	b	LBB19_23
LBB19_23:
	bl	___stack_chk_fail
LBB19_24:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_match_coverage_at          ; -- Begin function nvm_match_coverage_at
	.p2align	2
_nvm_match_coverage_at:                 ; @nvm_match_coverage_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB20_3
	b	LBB20_1
LBB20_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB20_3
	b	LBB20_2
LBB20_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.lo	LBB20_4
	b	LBB20_3
LBB20_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_18
LBB20_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_match_entry
	tbz	w0, #0, LBB20_6
	b	LBB20_5
LBB20_5:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #56
	bl	_match_record
	tbnz	w0, #0, LBB20_7
	b	LBB20_6
LBB20_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_18
LBB20_7:
	str	wzr, [sp, #52]
	b	LBB20_8
LBB20_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB20_17
	b	LBB20_9
LBB20_9:                                ;   in Loop: Header=BB20_8 Depth=1
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB20_11
	b	LBB20_10
LBB20_10:                               ;   in Loop: Header=BB20_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_match_entry
	tbnz	w0, #0, LBB20_12
	b	LBB20_11
LBB20_11:                               ;   in Loop: Header=BB20_8 Depth=1
	b	LBB20_16
LBB20_12:                               ;   in Loop: Header=BB20_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #8
	bl	_match_record
	tbz	w0, #0, LBB20_14
	b	LBB20_13
LBB20_13:                               ;   in Loop: Header=BB20_8 Depth=1
	add	x0, sp, #56
	add	x1, sp, #8
	bl	_same_match
	tbz	w0, #0, LBB20_15
	b	LBB20_14
LBB20_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_18
LBB20_15:                               ;   in Loop: Header=BB20_8 Depth=1
	b	LBB20_16
LBB20_16:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB20_8
LBB20_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #56
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_18
LBB20_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function match_entry
_match_entry:                           ; @match_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #13
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB21_2
	b	LBB21_1
LBB21_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _match_key@PAGE
	add	x1, x1, _match_key@PAGEOFF
	mov	x2, #13                         ; =0xd
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB21_2
LBB21_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function match_record
_match_record:                          ; @match_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	subs	w8, w8, #20
	b.hs	LBB22_2
	b	LBB22_1
LBB22_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_14
LBB22_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #48]
	ldr	x0, [sp, #48]
	bl	_le_read_u32
	str	w0, [sp, #8]
	ldr	x8, [sp, #48]
	add	x0, x8, #4
	bl	_le_read_u32
	str	w0, [sp, #12]
	ldr	x8, [sp, #48]
	add	x0, x8, #8
	bl	_le_read_u32
	str	w0, [sp, #16]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #12]
	str	w8, [sp, #20]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #13]
	str	w8, [sp, #24]
	str	wzr, [sp, #28]
	ldr	x8, [sp, #48]
	add	x8, x8, #20
	str	x8, [sp, #32]
	ldr	x8, [sp, #48]
	add	x0, x8, #16
	bl	_le_read_u32
	str	w0, [sp, #40]
	str	wzr, [sp, #44]
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB22_12
	b	LBB22_3
LBB22_3:
	ldr	w8, [sp, #12]
	cbz	w8, LBB22_12
	b	LBB22_4
LBB22_4:
	ldr	w8, [sp, #16]
	cbz	w8, LBB22_12
	b	LBB22_5
LBB22_5:
	ldr	w8, [sp, #20]
	subs	w8, w8, #2
	b.hi	LBB22_12
	b	LBB22_6
LBB22_6:
	ldr	w8, [sp, #24]
	subs	w8, w8, #1
	b.lo	LBB22_12
	b	LBB22_7
LBB22_7:
	ldr	w8, [sp, #24]
	subs	w8, w8, #2
	b.hi	LBB22_12
	b	LBB22_8
LBB22_8:
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #14]
	cbnz	w8, LBB22_12
	b	LBB22_9
LBB22_9:
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #15]
	cbnz	w8, LBB22_12
	b	LBB22_10
LBB22_10:
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #20
	subs	w8, w8, w9
	b.ne	LBB22_12
	b	LBB22_11
LBB22_11:
	ldr	x0, [sp, #32]
	ldr	w8, [sp, #40]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB22_13
	b	LBB22_12
LBB22_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_14
LBB22_13:
	ldur	x0, [x29, #-32]
	add	x1, sp, #8
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_14
LBB22_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_match
_same_match:                            ; @same_match
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	w9, [x8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB23_6
	b	LBB23_1
LBB23_1:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB23_6
	b	LBB23_2
LBB23_2:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB23_6
	b	LBB23_3
LBB23_3:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #16]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB23_6
	b	LBB23_4
LBB23_4:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #32]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #32]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB23_6
	b	LBB23_5
LBB23_5:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #24]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #24]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #32]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB23_6
LBB23_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_match_coverage         ; -- Begin function nvm_add_match_coverage
	.p2align	2
_nvm_add_match_coverage:                ; @nvm_add_match_coverage
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	stur	w3, [x29, #-28]
	stur	w4, [x29, #-32]
	stur	w5, [x29, #-36]
	stur	x6, [x29, #-48]
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB24_8
	b	LBB24_1
LBB24_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB24_8
	b	LBB24_2
LBB24_2:
	ldur	w8, [x29, #-24]
	cbz	w8, LBB24_8
	b	LBB24_3
LBB24_3:
	ldur	w8, [x29, #-28]
	cbz	w8, LBB24_8
	b	LBB24_4
LBB24_4:
	ldur	w8, [x29, #-32]
	subs	w8, w8, #2
	b.hi	LBB24_8
	b	LBB24_5
LBB24_5:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.lo	LBB24_8
	b	LBB24_6
LBB24_6:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #2
	b.hi	LBB24_8
	b	LBB24_7
LBB24_7:
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB24_9
	b	LBB24_8
LBB24_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB24_29
LBB24_9:
	ldur	x0, [x29, #-48]
	bl	_strlen
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	mov	x9, #65515                      ; =0xffeb
	movk	x9, #65535, lsl #16
	subs	x8, x8, x9
	b.ls	LBB24_11
	b	LBB24_10
LBB24_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB24_29
LBB24_11:
	ldur	w8, [x29, #-20]
	str	w8, [sp, #80]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #84]
	ldur	w8, [x29, #-28]
	str	w8, [sp, #88]
	ldur	w8, [x29, #-32]
	str	w8, [sp, #92]
	ldur	w8, [x29, #-36]
	str	w8, [sp, #96]
	str	wzr, [sp, #100]
	ldur	x8, [x29, #-48]
	str	x8, [sp, #104]
	ldur	x8, [x29, #-56]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #112]
	str	wzr, [sp, #116]
	str	wzr, [sp, #76]
	b	LBB24_12
LBB24_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB24_21
	b	LBB24_13
LBB24_13:                               ;   in Loop: Header=BB24_12 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_match_entry
	tbnz	w0, #0, LBB24_15
	b	LBB24_14
LBB24_14:                               ;   in Loop: Header=BB24_12 Depth=1
	b	LBB24_20
LBB24_15:                               ;   in Loop: Header=BB24_12 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #32
	bl	_match_record
	tbnz	w0, #0, LBB24_17
	b	LBB24_16
LBB24_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB24_29
LBB24_17:                               ;   in Loop: Header=BB24_12 Depth=1
	add	x0, sp, #80
	add	x1, sp, #32
	bl	_same_match
	tbz	w0, #0, LBB24_19
	b	LBB24_18
LBB24_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB24_29
LBB24_19:                               ;   in Loop: Header=BB24_12 Depth=1
	b	LBB24_20
LBB24_20:                               ;   in Loop: Header=BB24_12 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB24_12
LBB24_21:
	ldur	x8, [x29, #-56]
	add	x1, x8, #20
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB24_23
	b	LBB24_22
LBB24_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB24_29
LBB24_23:
	ldr	x0, [sp, #24]
	ldur	w1, [x29, #-20]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #4
	ldur	w1, [x29, #-24]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #8
	ldur	w1, [x29, #-28]
	bl	_le_write_u32
	ldur	w8, [x29, #-32]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #12]
	ldur	w8, [x29, #-36]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #13]
	ldr	x8, [sp, #24]
	add	x0, x8, #16
	ldur	x8, [x29, #-56]
	mov	x1, x8
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #20
	ldur	x1, [x29, #-48]
	ldur	x2, [x29, #-56]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	adrp	x1, _match_key@PAGE
	add	x1, x1, _match_key@PAGEOFF
	mov	w2, #13                         ; =0xd
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.ne	LBB24_25
	b	LBB24_24
LBB24_24:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB24_26
LBB24_25:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldur	x8, [x29, #-56]
                                        ; kill: def $w8 killed $w8 killed $x8
	add	w2, w8, #20
	bl	_nvm_add_string
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB24_26
LBB24_26:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	w8, [sp, #16]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB24_28
	b	LBB24_27
LBB24_27:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #20]
	ldr	w2, [sp, #16]
	bl	_nvm_add_metadata
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB24_28
LBB24_28:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB24_29
LBB24_29:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function le_write_u32
_le_write_u32:                          ; @le_write_u32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldrb	w8, [sp, #4]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #16
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #2]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #24
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #3]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_use_at              ; -- Begin function nvm_affine_use_at
	.p2align	2
_nvm_affine_use_at:                     ; @nvm_affine_use_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB26_3
	b	LBB26_1
LBB26_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB26_3
	b	LBB26_2
LBB26_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.lo	LBB26_4
	b	LBB26_3
LBB26_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_18
LBB26_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_affine_use_entry
	tbz	w0, #0, LBB26_6
	b	LBB26_5
LBB26_5:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #64
	bl	_affine_use_record
	tbnz	w0, #0, LBB26_7
	b	LBB26_6
LBB26_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_18
LBB26_7:
	str	wzr, [sp, #60]
	b	LBB26_8
LBB26_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB26_17
	b	LBB26_9
LBB26_9:                                ;   in Loop: Header=BB26_8 Depth=1
	ldr	w8, [sp, #60]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB26_11
	b	LBB26_10
LBB26_10:                               ;   in Loop: Header=BB26_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_affine_use_entry
	tbnz	w0, #0, LBB26_12
	b	LBB26_11
LBB26_11:                               ;   in Loop: Header=BB26_8 Depth=1
	b	LBB26_16
LBB26_12:                               ;   in Loop: Header=BB26_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #8
	bl	_affine_use_record
	tbz	w0, #0, LBB26_14
	b	LBB26_13
LBB26_13:                               ;   in Loop: Header=BB26_8 Depth=1
	add	x0, sp, #64
	add	x1, sp, #8
	bl	_same_affine_use
	tbz	w0, #0, LBB26_15
	b	LBB26_14
LBB26_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_18
LBB26_15:                               ;   in Loop: Header=BB26_8 Depth=1
	b	LBB26_16
LBB26_16:                               ;   in Loop: Header=BB26_8 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB26_8
LBB26_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #64
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_18
LBB26_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function affine_use_entry
_affine_use_entry:                      ; @affine_use_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #18
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB27_2
	b	LBB27_1
LBB27_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _affine_use_key@PAGE
	add	x1, x1, _affine_use_key@PAGEOFF
	mov	x2, #18                         ; =0x12
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB27_2
LBB27_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function affine_use_record
_affine_use_record:                     ; @affine_use_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	subs	w8, w8, #24
	b.hs	LBB28_2
	b	LBB28_1
LBB28_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB28_18
LBB28_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	add	x0, x8, #16
	bl	_le_read_u32
	stur	w0, [x29, #-52]
	ldur	x8, [x29, #-48]
	add	x0, x8, #20
	bl	_le_read_u32
	str	w0, [sp, #56]
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #24
	subs	w8, w8, w9
	b.hi	LBB28_5
	b	LBB28_3
LBB28_3:
	ldr	w8, [sp, #56]
	cbz	w8, LBB28_5
	b	LBB28_4
LBB28_4:
	ldr	w8, [sp, #56]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #24
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.eq	LBB28_6
	b	LBB28_5
LBB28_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB28_18
LBB28_6:
	ldur	x0, [x29, #-48]
	bl	_le_read_u32
	str	w0, [sp, #8]
	ldur	x8, [x29, #-48]
	add	x0, x8, #4
	bl	_le_read_u32
	str	w0, [sp, #12]
	ldur	x8, [x29, #-48]
	add	x0, x8, #8
	bl	_le_read_u32
	str	w0, [sp, #16]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #12]
	str	w8, [sp, #20]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #13]
	str	w8, [sp, #24]
	str	wzr, [sp, #28]
	ldur	x8, [x29, #-48]
	add	x8, x8, #24
	str	x8, [sp, #32]
	ldur	x8, [x29, #-48]
	add	x8, x8, #24
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldur	w8, [x29, #-52]
	str	w8, [sp, #48]
	ldr	w8, [sp, #56]
	str	w8, [sp, #52]
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB28_16
	b	LBB28_7
LBB28_7:
	ldr	w8, [sp, #12]
	cbz	w8, LBB28_16
	b	LBB28_8
LBB28_8:
	ldr	w8, [sp, #16]
	cbz	w8, LBB28_16
	b	LBB28_9
LBB28_9:
	ldr	w8, [sp, #20]
	subs	w8, w8, #2
	b.hi	LBB28_16
	b	LBB28_10
LBB28_10:
	ldr	w8, [sp, #24]
	subs	w8, w8, #1
	b.lo	LBB28_16
	b	LBB28_11
LBB28_11:
	ldr	w8, [sp, #24]
	subs	w8, w8, #2
	b.hi	LBB28_16
	b	LBB28_12
LBB28_12:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #14]
	cbnz	w8, LBB28_16
	b	LBB28_13
LBB28_13:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #15]
	cbnz	w8, LBB28_16
	b	LBB28_14
LBB28_14:
	ldr	x0, [sp, #32]
	ldur	w8, [x29, #-52]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB28_16
	b	LBB28_15
LBB28_15:
	ldr	x0, [sp, #40]
	ldr	w8, [sp, #56]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB28_17
	b	LBB28_16
LBB28_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB28_18
LBB28_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #8
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB28_18
LBB28_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_affine_use
_same_affine_use:                       ; @same_affine_use
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	w9, [x8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB29_6
	b	LBB29_1
LBB29_1:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB29_6
	b	LBB29_2
LBB29_2:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB29_6
	b	LBB29_3
LBB29_3:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #16]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB29_6
	b	LBB29_4
LBB29_4:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #40]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #40]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB29_6
	b	LBB29_5
LBB29_5:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #24]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #24]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #40]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB29_6
LBB29_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_affine_use             ; -- Begin function nvm_add_affine_use
	.p2align	2
_nvm_add_affine_use:                    ; @nvm_add_affine_use
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	stur	w3, [x29, #-28]
	stur	w4, [x29, #-32]
	stur	w5, [x29, #-36]
	stur	x6, [x29, #-48]
	stur	x7, [x29, #-56]
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB30_10
	b	LBB30_1
LBB30_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB30_10
	b	LBB30_2
LBB30_2:
	ldur	w8, [x29, #-24]
	cbz	w8, LBB30_10
	b	LBB30_3
LBB30_3:
	ldur	w8, [x29, #-28]
	cbz	w8, LBB30_10
	b	LBB30_4
LBB30_4:
	ldur	w8, [x29, #-32]
	subs	w8, w8, #2
	b.hi	LBB30_10
	b	LBB30_5
LBB30_5:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.lo	LBB30_10
	b	LBB30_6
LBB30_6:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #2
	b.hi	LBB30_10
	b	LBB30_7
LBB30_7:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB30_10
	b	LBB30_8
LBB30_8:
	ldur	x8, [x29, #-56]
	cbz	x8, LBB30_10
	b	LBB30_9
LBB30_9:
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8]
	cbnz	w8, LBB30_11
	b	LBB30_10
LBB30_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_31
LBB30_11:
	ldur	x0, [x29, #-48]
	bl	_strlen
	stur	x0, [x29, #-64]
	ldur	x0, [x29, #-56]
	bl	_strlen
	stur	x0, [x29, #-72]
	ldur	x8, [x29, #-64]
	mov	x9, #65511                      ; =0xffe7
	movk	x9, #65535, lsl #16
	subs	x8, x8, x9
	b.hi	LBB30_13
	b	LBB30_12
LBB30_12:
	ldur	x8, [x29, #-72]
	ldur	x10, [x29, #-64]
	mov	x9, #65511                      ; =0xffe7
	movk	x9, #65535, lsl #16
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB30_14
	b	LBB30_13
LBB30_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_31
LBB30_14:
	ldur	w8, [x29, #-20]
	str	w8, [sp, #104]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #108]
	ldur	w8, [x29, #-28]
	str	w8, [sp, #112]
	ldur	w8, [x29, #-32]
	str	w8, [sp, #116]
	ldur	w8, [x29, #-36]
	str	w8, [sp, #120]
	str	wzr, [sp, #124]
	ldur	x8, [x29, #-48]
	str	x8, [sp, #128]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #136]
	ldur	x8, [x29, #-64]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #144]
	ldur	x8, [x29, #-72]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #148]
	str	wzr, [sp, #100]
	b	LBB30_15
LBB30_15:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #100]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB30_23
	b	LBB30_16
LBB30_16:                               ;   in Loop: Header=BB30_15 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_affine_use_entry
	tbnz	w0, #0, LBB30_18
	b	LBB30_17
LBB30_17:                               ;   in Loop: Header=BB30_15 Depth=1
	b	LBB30_22
LBB30_18:                               ;   in Loop: Header=BB30_15 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #48
	bl	_affine_use_record
	tbz	w0, #0, LBB30_20
	b	LBB30_19
LBB30_19:                               ;   in Loop: Header=BB30_15 Depth=1
	add	x0, sp, #104
	add	x1, sp, #48
	bl	_same_affine_use
	tbz	w0, #0, LBB30_21
	b	LBB30_20
LBB30_20:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_31
LBB30_21:                               ;   in Loop: Header=BB30_15 Depth=1
	b	LBB30_22
LBB30_22:                               ;   in Loop: Header=BB30_15 Depth=1
	ldr	w8, [sp, #100]
	add	w8, w8, #1
	str	w8, [sp, #100]
	b	LBB30_15
LBB30_23:
	ldur	x8, [x29, #-64]
                                        ; kill: def $w8 killed $w8 killed $x8
	add	w8, w8, #24
	ldur	x9, [x29, #-72]
                                        ; kill: def $w9 killed $w9 killed $x9
	add	w8, w8, w9
	str	w8, [sp, #44]
	ldr	w8, [sp, #44]
	mov	x1, x8
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB30_25
	b	LBB30_24
LBB30_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_31
LBB30_25:
	ldr	x0, [sp, #32]
	ldur	w1, [x29, #-20]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #4
	ldur	w1, [x29, #-24]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	ldur	w1, [x29, #-28]
	bl	_le_write_u32
	ldur	w8, [x29, #-32]
	ldr	x9, [sp, #32]
	strb	w8, [x9, #12]
	ldur	w8, [x29, #-36]
	ldr	x9, [sp, #32]
	strb	w8, [x9, #13]
	ldr	x8, [sp, #32]
	add	x0, x8, #16
	ldur	x8, [x29, #-64]
	mov	x1, x8
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #20
	ldur	x8, [x29, #-72]
	mov	x1, x8
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #24
	ldur	x1, [x29, #-48]
	ldur	x2, [x29, #-64]
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]
	add	x8, x8, #24
	ldur	x9, [x29, #-64]
	add	x0, x8, x9
	ldur	x1, [x29, #-56]
	ldur	x2, [x29, #-72]
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	adrp	x1, _affine_use_key@PAGE
	add	x1, x1, _affine_use_key@PAGEOFF
	mov	w2, #18                         ; =0x12
	bl	_nvm_add_string
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	adds	w8, w8, #1
	b.ne	LBB30_27
	b	LBB30_26
LBB30_26:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB30_28
LBB30_27:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	ldr	w2, [sp, #44]
	bl	_nvm_add_string
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB30_28
LBB30_28:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #24]
	ldr	x0, [sp, #32]
	bl	_free
	ldr	w8, [sp, #24]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB30_30
	b	LBB30_29
LBB30_29:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #28]
	ldr	w2, [sp, #24]
	bl	_nvm_add_metadata
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB30_30
LBB30_30:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_31
LBB30_31:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_borrow_place_at            ; -- Begin function nvm_borrow_place_at
	.p2align	2
_nvm_borrow_place_at:                   ; @nvm_borrow_place_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB31_3
	b	LBB31_1
LBB31_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB31_3
	b	LBB31_2
LBB31_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.lo	LBB31_4
	b	LBB31_3
LBB31_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB31_18
LBB31_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_borrow_place_entry
	tbz	w0, #0, LBB31_6
	b	LBB31_5
LBB31_5:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #88
	bl	_borrow_place_record
	tbnz	w0, #0, LBB31_7
	b	LBB31_6
LBB31_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB31_18
LBB31_7:
	str	wzr, [sp, #84]
	b	LBB31_8
LBB31_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #84]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB31_17
	b	LBB31_9
LBB31_9:                                ;   in Loop: Header=BB31_8 Depth=1
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB31_11
	b	LBB31_10
LBB31_10:                               ;   in Loop: Header=BB31_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_borrow_place_entry
	tbnz	w0, #0, LBB31_12
	b	LBB31_11
LBB31_11:                               ;   in Loop: Header=BB31_8 Depth=1
	b	LBB31_16
LBB31_12:                               ;   in Loop: Header=BB31_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #8
	bl	_borrow_place_record
	tbz	w0, #0, LBB31_14
	b	LBB31_13
LBB31_13:                               ;   in Loop: Header=BB31_8 Depth=1
	add	x0, sp, #88
	add	x1, sp, #8
	bl	_same_borrow_place
	tbz	w0, #0, LBB31_15
	b	LBB31_14
LBB31_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB31_18
LBB31_15:                               ;   in Loop: Header=BB31_8 Depth=1
	b	LBB31_16
LBB31_16:                               ;   in Loop: Header=BB31_8 Depth=1
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB31_8
LBB31_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #88
	mov	x2, #72                         ; =0x48
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB31_18
LBB31_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_place_entry
_borrow_place_entry:                    ; @borrow_place_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #20
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB32_2
	b	LBB32_1
LBB32_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _borrow_place_key@PAGE
	add	x1, x1, _borrow_place_key@PAGEOFF
	mov	x2, #20                         ; =0x14
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB32_2
LBB32_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_place_record
_borrow_place_record:                   ; @borrow_place_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	subs	w8, w8, #40
	b.hs	LBB33_2
	b	LBB33_1
LBB33_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_24
LBB33_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	add	x0, x8, #28
	bl	_le_read_u32
	stur	w0, [x29, #-52]
	ldur	x8, [x29, #-48]
	add	x0, x8, #32
	bl	_le_read_u32
	stur	w0, [x29, #-56]
	ldur	x8, [x29, #-48]
	add	x0, x8, #36
	bl	_le_read_u32
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB33_7
	b	LBB33_3
LBB33_3:
	ldur	w8, [x29, #-56]
	cbz	w8, LBB33_7
	b	LBB33_4
LBB33_4:
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #40
	subs	w8, w8, w9
	b.hi	LBB33_7
	b	LBB33_5
LBB33_5:
	ldur	w8, [x29, #-56]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #40
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB33_7
	b	LBB33_6
LBB33_6:
	ldur	w8, [x29, #-60]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #40
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	ldur	w10, [x29, #-56]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.eq	LBB33_8
	b	LBB33_7
LBB33_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_24
LBB33_8:
	ldur	x0, [x29, #-48]
	bl	_le_read_u32
	str	w0, [sp, #8]
	ldur	x8, [x29, #-48]
	add	x0, x8, #4
	bl	_le_read_u32
	str	w0, [sp, #12]
	ldur	x8, [x29, #-48]
	add	x0, x8, #8
	bl	_le_read_u32
	str	w0, [sp, #16]
	ldur	x8, [x29, #-48]
	add	x0, x8, #12
	bl	_le_read_u32
	str	w0, [sp, #20]
	ldur	x8, [x29, #-48]
	add	x0, x8, #16
	bl	_le_read_u32
	str	w0, [sp, #24]
	ldur	x8, [x29, #-48]
	add	x0, x8, #20
	bl	_le_read_u32
	str	w0, [sp, #28]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #24]
	str	w8, [sp, #32]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #25]
	str	w8, [sp, #36]
	ldur	x8, [x29, #-48]
	add	x8, x8, #40
	str	x8, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x8, x8, #40
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldur	x8, [x29, #-48]
	add	x8, x8, #40
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #56]
	ldur	w8, [x29, #-52]
	str	w8, [sp, #64]
	ldur	w8, [x29, #-56]
	str	w8, [sp, #68]
	ldur	w8, [x29, #-60]
	str	w8, [sp, #72]
	str	wzr, [sp, #76]
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB33_22
	b	LBB33_9
LBB33_9:
	ldr	w8, [sp, #12]
	cbz	w8, LBB33_22
	b	LBB33_10
LBB33_10:
	ldr	w8, [sp, #16]
	cbz	w8, LBB33_22
	b	LBB33_11
LBB33_11:
	ldr	w8, [sp, #20]
	cbz	w8, LBB33_22
	b	LBB33_12
LBB33_12:
	ldr	w8, [sp, #24]
	cbz	w8, LBB33_22
	b	LBB33_13
LBB33_13:
	ldr	w8, [sp, #32]
	subs	w8, w8, #1
	b.lo	LBB33_22
	b	LBB33_14
LBB33_14:
	ldr	w8, [sp, #32]
	subs	w8, w8, #2
	b.hi	LBB33_22
	b	LBB33_15
LBB33_15:
	ldr	w8, [sp, #36]
	subs	w8, w8, #1
	b.lo	LBB33_22
	b	LBB33_16
LBB33_16:
	ldr	w8, [sp, #36]
	subs	w8, w8, #2
	b.hi	LBB33_22
	b	LBB33_17
LBB33_17:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #26]
	cbnz	w8, LBB33_22
	b	LBB33_18
LBB33_18:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #27]
	cbnz	w8, LBB33_22
	b	LBB33_19
LBB33_19:
	ldr	x0, [sp, #40]
	ldur	w8, [x29, #-52]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB33_22
	b	LBB33_20
LBB33_20:
	ldr	x0, [sp, #48]
	ldur	w8, [x29, #-56]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB33_22
	b	LBB33_21
LBB33_21:
	ldr	x0, [sp, #56]
	ldur	w8, [x29, #-60]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbnz	w0, #0, LBB33_23
	b	LBB33_22
LBB33_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_24
LBB33_23:
	ldur	x0, [x29, #-32]
	add	x1, sp, #8
	mov	x2, #72                         ; =0x48
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_24
LBB33_24:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_borrow_place
_same_borrow_place:                     ; @same_borrow_place
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	w9, [x8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_1
LBB34_1:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_2
LBB34_2:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_3
LBB34_3:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #12]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_4
LBB34_4:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #16]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_5
LBB34_5:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #20]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_6
LBB34_6:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #28]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #28]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_7
LBB34_7:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #56]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #56]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB34_9
	b	LBB34_8
LBB34_8:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #32]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #32]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #56]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB34_9
LBB34_9:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_borrow_place           ; -- Begin function nvm_add_borrow_place
	.p2align	2
_nvm_add_borrow_place:                  ; @nvm_add_borrow_place
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB35_16
	b	LBB35_1
LBB35_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB35_16
	b	LBB35_2
LBB35_2:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB35_16
	b	LBB35_3
LBB35_3:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	cbz	w8, LBB35_16
	b	LBB35_4
LBB35_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	cbz	w8, LBB35_16
	b	LBB35_5
LBB35_5:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	cbz	w8, LBB35_16
	b	LBB35_6
LBB35_6:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	cbz	w8, LBB35_16
	b	LBB35_7
LBB35_7:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.lo	LBB35_16
	b	LBB35_8
LBB35_8:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #24]
	subs	w8, w8, #2
	b.hi	LBB35_16
	b	LBB35_9
LBB35_9:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #28]
	subs	w8, w8, #1
	b.lo	LBB35_16
	b	LBB35_10
LBB35_10:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #28]
	subs	w8, w8, #2
	b.hi	LBB35_16
	b	LBB35_11
LBB35_11:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB35_16
	b	LBB35_12
LBB35_12:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	cbz	x8, LBB35_16
	b	LBB35_13
LBB35_13:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #48]
	cbz	x8, LBB35_16
	b	LBB35_14
LBB35_14:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #56]
	cbz	w8, LBB35_16
	b	LBB35_15
LBB35_15:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #60]
	cbnz	w8, LBB35_17
	b	LBB35_16
LBB35_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_41
LBB35_17:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #56]
	stur	w8, [x29, #-28]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #60]
	stur	w8, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #64]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-28]
	adds	w8, w8, #41
	b.hi	LBB35_23
	b	LBB35_18
LBB35_18:
	ldur	w8, [x29, #-32]
	ldur	w10, [x29, #-28]
	mov	w9, #-41                        ; =0xffffffd7
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB35_23
	b	LBB35_19
LBB35_19:
	ldur	w8, [x29, #-36]
	ldur	w10, [x29, #-28]
	mov	w9, #-41                        ; =0xffffffd7
	subs	w9, w9, w10
	ldur	w10, [x29, #-32]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB35_23
	b	LBB35_20
LBB35_20:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #32]
	ldur	w8, [x29, #-28]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB35_23
	b	LBB35_21
LBB35_21:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #40]
	ldur	w8, [x29, #-32]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB35_23
	b	LBB35_22
LBB35_22:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #48]
	ldur	w8, [x29, #-36]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbnz	w0, #0, LBB35_24
	b	LBB35_23
LBB35_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_41
LBB35_24:
	stur	wzr, [x29, #-40]
	b	LBB35_25
LBB35_25:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB35_33
	b	LBB35_26
LBB35_26:                               ;   in Loop: Header=BB35_25 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_borrow_place_entry
	tbnz	w0, #0, LBB35_28
	b	LBB35_27
LBB35_27:                               ;   in Loop: Header=BB35_25 Depth=1
	b	LBB35_32
LBB35_28:                               ;   in Loop: Header=BB35_25 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #48
	bl	_borrow_place_record
	tbz	w0, #0, LBB35_30
	b	LBB35_29
LBB35_29:                               ;   in Loop: Header=BB35_25 Depth=1
	ldur	x0, [x29, #-24]
	add	x1, sp, #48
	bl	_same_borrow_place
	tbz	w0, #0, LBB35_31
	b	LBB35_30
LBB35_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_41
LBB35_31:                               ;   in Loop: Header=BB35_25 Depth=1
	b	LBB35_32
LBB35_32:                               ;   in Loop: Header=BB35_25 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB35_25
LBB35_33:
	ldur	w8, [x29, #-28]
	add	w8, w8, #40
	ldur	w9, [x29, #-32]
	add	w8, w8, w9
	ldur	w9, [x29, #-36]
	add	w8, w8, w9
	str	w8, [sp, #44]
	ldr	w8, [sp, #44]
	mov	x1, x8
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB35_35
	b	LBB35_34
LBB35_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_41
LBB35_35:
	ldr	x0, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #4
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #4]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #8]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #12
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #12]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #16
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #16]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #20
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #20]
	bl	_le_write_u32
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #24]
	ldr	x9, [sp, #32]
	strb	w8, [x9, #24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #28]
	ldr	x9, [sp, #32]
	strb	w8, [x9, #25]
	ldr	x8, [sp, #32]
	add	x0, x8, #28
	ldur	w1, [x29, #-28]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #32
	ldur	w1, [x29, #-32]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #36
	ldur	w1, [x29, #-36]
	bl	_le_write_u32
	ldr	x8, [sp, #32]
	add	x0, x8, #40
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]
	add	x8, x8, #40
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #40]
	ldur	w8, [x29, #-32]
	mov	x2, x8
	bl	___memcpy_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]
	add	x8, x8, #40
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #48]
	ldur	w8, [x29, #-36]
	mov	x2, x8
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	adrp	x1, _borrow_place_key@PAGE
	add	x1, x1, _borrow_place_key@PAGEOFF
	mov	w2, #20                         ; =0x14
	bl	_nvm_add_string
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	adds	w8, w8, #1
	b.ne	LBB35_37
	b	LBB35_36
LBB35_36:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB35_38
LBB35_37:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	ldr	w2, [sp, #44]
	bl	_nvm_add_string
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB35_38
LBB35_38:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #24]
	ldr	x0, [sp, #32]
	bl	_free
	ldr	w8, [sp, #24]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB35_40
	b	LBB35_39
LBB35_39:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #28]
	ldr	w2, [sp, #24]
	bl	_nvm_add_metadata
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB35_40
LBB35_40:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_41
LBB35_41:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_place_utf8
_borrow_place_utf8:                     ; @borrow_place_utf8
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	str	xzr, [sp, #32]
	b	LBB36_1
LBB36_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_21 Depth 2
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.hs	LBB36_31
	b	LBB36_2
LBB36_2:                                ;   in Loop: Header=BB36_1 Depth=1
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #32]
	add	x10, x9, #1
	str	x10, [sp, #32]
	ldrb	w8, [x8, x9]
	str	w8, [sp, #28]
	str	wzr, [sp, #24]
	str	wzr, [sp, #20]
	str	wzr, [sp, #16]
	ldr	w8, [sp, #28]
	subs	w8, w8, #128
	b.hs	LBB36_6
	b	LBB36_3
LBB36_3:                                ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	cbnz	w8, LBB36_5
	b	LBB36_4
LBB36_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB36_32
LBB36_5:                                ;   in Loop: Header=BB36_1 Depth=1
	b	LBB36_1
LBB36_6:                                ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #194
	b.lo	LBB36_9
	b	LBB36_7
LBB36_7:                                ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #223
	b.hi	LBB36_9
	b	LBB36_8
LBB36_8:                                ;   in Loop: Header=BB36_1 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #24]
	ldr	w8, [sp, #28]
	and	w8, w8, #0x1f
	str	w8, [sp, #20]
	mov	w8, #128                        ; =0x80
	str	w8, [sp, #16]
	b	LBB36_18
LBB36_9:                                ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #224
	b.lo	LBB36_12
	b	LBB36_10
LBB36_10:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #239
	b.hi	LBB36_12
	b	LBB36_11
LBB36_11:                               ;   in Loop: Header=BB36_1 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #24]
	ldr	w8, [sp, #28]
	and	w8, w8, #0xf
	str	w8, [sp, #20]
	mov	w8, #2048                       ; =0x800
	str	w8, [sp, #16]
	b	LBB36_17
LBB36_12:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #240
	b.lo	LBB36_15
	b	LBB36_13
LBB36_13:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #244
	b.hi	LBB36_15
	b	LBB36_14
LBB36_14:                               ;   in Loop: Header=BB36_1 Depth=1
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #24]
	ldr	w8, [sp, #28]
	and	w8, w8, #0x7
	str	w8, [sp, #20]
	mov	w8, #65536                      ; =0x10000
	str	w8, [sp, #16]
	b	LBB36_16
LBB36_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB36_32
LBB36_16:                               ;   in Loop: Header=BB36_1 Depth=1
	b	LBB36_17
LBB36_17:                               ;   in Loop: Header=BB36_1 Depth=1
	b	LBB36_18
LBB36_18:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #40]
	ldr	x10, [sp, #32]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB36_20
	b	LBB36_19
LBB36_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB36_32
LBB36_20:                               ;   in Loop: Header=BB36_1 Depth=1
	b	LBB36_21
LBB36_21:                               ;   Parent Loop BB36_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #24]
	subs	w9, w8, #1
	str	w9, [sp, #24]
	cbz	w8, LBB36_25
	b	LBB36_22
LBB36_22:                               ;   in Loop: Header=BB36_21 Depth=2
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #32]
	add	x10, x9, #1
	str	x10, [sp, #32]
	ldrb	w8, [x8, x9]
	str	w8, [sp, #12]
	ldr	w8, [sp, #12]
	and	w8, w8, #0xc0
	subs	w8, w8, #128
	b.eq	LBB36_24
	b	LBB36_23
LBB36_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB36_32
LBB36_24:                               ;   in Loop: Header=BB36_21 Depth=2
	ldr	w9, [sp, #20]
	ldr	w8, [sp, #12]
	bfi	w8, w9, #6, #26
	str	w8, [sp, #20]
	b	LBB36_21
LBB36_25:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.lo	LBB36_29
	b	LBB36_26
LBB36_26:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #20]
	subs	w8, w8, #272, lsl #12           ; =1114112
	b.hs	LBB36_29
	b	LBB36_27
LBB36_27:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #20]
	mov	w9, #55296                      ; =0xd800
	subs	w8, w8, w9
	b.lo	LBB36_30
	b	LBB36_28
LBB36_28:                               ;   in Loop: Header=BB36_1 Depth=1
	ldr	w8, [sp, #20]
	subs	w8, w8, #14, lsl #12            ; =57344
	b.hs	LBB36_30
	b	LBB36_29
LBB36_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB36_32
LBB36_30:                               ;   in Loop: Header=BB36_1 Depth=1
	b	LBB36_1
LBB36_31:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB36_32
LBB36_32:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_field_read_at              ; -- Begin function nvm_field_read_at
	.p2align	2
_nvm_field_read_at:                     ; @nvm_field_read_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB37_3
	b	LBB37_1
LBB37_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB37_3
	b	LBB37_2
LBB37_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.lo	LBB37_4
	b	LBB37_3
LBB37_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_18
LBB37_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_field_read_entry
	tbz	w0, #0, LBB37_6
	b	LBB37_5
LBB37_5:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #80
	bl	_field_read_record
	tbnz	w0, #0, LBB37_7
	b	LBB37_6
LBB37_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_18
LBB37_7:
	str	wzr, [sp, #76]
	b	LBB37_8
LBB37_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB37_17
	b	LBB37_9
LBB37_9:                                ;   in Loop: Header=BB37_8 Depth=1
	ldr	w8, [sp, #76]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB37_11
	b	LBB37_10
LBB37_10:                               ;   in Loop: Header=BB37_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_field_read_entry
	tbnz	w0, #0, LBB37_12
	b	LBB37_11
LBB37_11:                               ;   in Loop: Header=BB37_8 Depth=1
	b	LBB37_16
LBB37_12:                               ;   in Loop: Header=BB37_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #8
	bl	_field_read_record
	tbz	w0, #0, LBB37_14
	b	LBB37_13
LBB37_13:                               ;   in Loop: Header=BB37_8 Depth=1
	add	x0, sp, #80
	add	x1, sp, #8
	bl	_same_field_read
	tbz	w0, #0, LBB37_15
	b	LBB37_14
LBB37_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_18
LBB37_15:                               ;   in Loop: Header=BB37_8 Depth=1
	b	LBB37_16
LBB37_16:                               ;   in Loop: Header=BB37_8 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB37_8
LBB37_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #80
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_18
LBB37_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_read_entry
_field_read_entry:                      ; @field_read_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #18
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB38_2
	b	LBB38_1
LBB38_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _field_read_key@PAGE
	add	x1, x1, _field_read_key@PAGEOFF
	mov	x2, #18                         ; =0x12
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB38_2
LBB38_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_read_record
_field_read_record:                     ; @field_read_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	subs	w8, w8, #28
	b.hs	LBB39_2
	b	LBB39_1
LBB39_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_24
LBB39_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	add	x0, x8, #16
	bl	_le_read_u32
	stur	w0, [x29, #-52]
	ldur	x8, [x29, #-48]
	add	x0, x8, #20
	bl	_le_read_u32
	stur	w0, [x29, #-56]
	ldur	x8, [x29, #-48]
	add	x0, x8, #24
	bl	_le_read_u32
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB39_7
	b	LBB39_3
LBB39_3:
	ldur	w8, [x29, #-56]
	cbz	w8, LBB39_7
	b	LBB39_4
LBB39_4:
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #28
	subs	w8, w8, w9
	b.hi	LBB39_7
	b	LBB39_5
LBB39_5:
	ldur	w8, [x29, #-56]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #28
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB39_7
	b	LBB39_6
LBB39_6:
	ldur	w8, [x29, #-60]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #28
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	ldur	w10, [x29, #-56]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.eq	LBB39_8
	b	LBB39_7
LBB39_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_24
LBB39_8:
	ldur	x0, [x29, #-48]
	bl	_le_read_u32
	str	w0, [sp]
	ldur	x8, [x29, #-48]
	add	x0, x8, #4
	bl	_le_read_u32
	str	w0, [sp, #4]
	ldur	x8, [x29, #-48]
	add	x0, x8, #8
	bl	_le_read_u32
	str	w0, [sp, #8]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #12]
	str	w8, [sp, #12]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #13]
	str	w8, [sp, #16]
	str	wzr, [sp, #20]
	ldur	x8, [x29, #-48]
	add	x8, x8, #28
	str	x8, [sp, #24]
	ldur	x8, [x29, #-48]
	add	x8, x8, #28
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldur	x8, [x29, #-48]
	add	x8, x8, #28
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldur	w8, [x29, #-52]
	str	w8, [sp, #48]
	ldur	w8, [x29, #-56]
	str	w8, [sp, #52]
	ldur	w8, [x29, #-60]
	str	w8, [sp, #56]
	str	wzr, [sp, #60]
	ldr	w8, [sp]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB39_22
	b	LBB39_9
LBB39_9:
	ldr	w8, [sp, #4]
	cbz	w8, LBB39_22
	b	LBB39_10
LBB39_10:
	ldr	w8, [sp, #8]
	cbz	w8, LBB39_22
	b	LBB39_11
LBB39_11:
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	b.lo	LBB39_22
	b	LBB39_12
LBB39_12:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	b.hi	LBB39_22
	b	LBB39_13
LBB39_13:
	ldr	w8, [sp, #16]
	subs	w8, w8, #1
	b.lo	LBB39_22
	b	LBB39_14
LBB39_14:
	ldr	w8, [sp, #16]
	subs	w8, w8, #2
	b.hi	LBB39_22
	b	LBB39_15
LBB39_15:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #14]
	cbnz	w8, LBB39_22
	b	LBB39_16
LBB39_16:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #15]
	cbnz	w8, LBB39_22
	b	LBB39_17
LBB39_17:
	ldur	w8, [x29, #-60]
	cbz	w8, LBB39_22
	b	LBB39_18
LBB39_18:
	ldr	x8, [sp, #40]
	ldrsb	w8, [x8]
	subs	w8, w8, #46
	b.ne	LBB39_22
	b	LBB39_19
LBB39_19:
	ldr	x0, [sp, #24]
	ldur	w8, [x29, #-52]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB39_22
	b	LBB39_20
LBB39_20:
	ldr	x0, [sp, #32]
	ldur	w8, [x29, #-56]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB39_22
	b	LBB39_21
LBB39_21:
	ldr	x0, [sp, #40]
	ldur	w8, [x29, #-60]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbnz	w0, #0, LBB39_23
	b	LBB39_22
LBB39_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_24
LBB39_23:
	ldur	x0, [x29, #-32]
	mov	x1, sp
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_24
LBB39_24:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_field_read
_same_field_read:                       ; @same_field_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	w9, [x8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB40_6
	b	LBB40_1
LBB40_1:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB40_6
	b	LBB40_2
LBB40_2:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB40_6
	b	LBB40_3
LBB40_3:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #16]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB40_6
	b	LBB40_4
LBB40_4:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #48]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #48]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB40_6
	b	LBB40_5
LBB40_5:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #24]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #24]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #48]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB40_6
LBB40_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_field_read             ; -- Begin function nvm_add_field_read
	.p2align	2
_nvm_add_field_read:                    ; @nvm_add_field_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB41_16
	b	LBB41_1
LBB41_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB41_16
	b	LBB41_2
LBB41_2:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB41_16
	b	LBB41_3
LBB41_3:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	cbz	w8, LBB41_16
	b	LBB41_4
LBB41_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	cbz	w8, LBB41_16
	b	LBB41_5
LBB41_5:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	subs	w8, w8, #1
	b.lo	LBB41_16
	b	LBB41_6
LBB41_6:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	subs	w8, w8, #3
	b.hi	LBB41_16
	b	LBB41_7
LBB41_7:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.lo	LBB41_16
	b	LBB41_8
LBB41_8:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #2
	b.hi	LBB41_16
	b	LBB41_9
LBB41_9:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	cbz	x8, LBB41_16
	b	LBB41_10
LBB41_10:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB41_16
	b	LBB41_11
LBB41_11:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	cbz	x8, LBB41_16
	b	LBB41_12
LBB41_12:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #48]
	cbz	w8, LBB41_16
	b	LBB41_13
LBB41_13:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #52]
	cbz	w8, LBB41_16
	b	LBB41_14
LBB41_14:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #56]
	cbz	w8, LBB41_16
	b	LBB41_15
LBB41_15:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldrsb	w8, [x8]
	subs	w8, w8, #46
	b.eq	LBB41_17
	b	LBB41_16
LBB41_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_41
LBB41_17:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #48]
	stur	w8, [x29, #-28]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #52]
	stur	w8, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #56]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-28]
	adds	w8, w8, #29
	b.hi	LBB41_23
	b	LBB41_18
LBB41_18:
	ldur	w8, [x29, #-32]
	ldur	w10, [x29, #-28]
	mov	w9, #-29                        ; =0xffffffe3
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB41_23
	b	LBB41_19
LBB41_19:
	ldur	w8, [x29, #-36]
	ldur	w10, [x29, #-28]
	mov	w9, #-29                        ; =0xffffffe3
	subs	w9, w9, w10
	ldur	w10, [x29, #-32]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB41_23
	b	LBB41_20
LBB41_20:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #24]
	ldur	w8, [x29, #-28]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB41_23
	b	LBB41_21
LBB41_21:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #32]
	ldur	w8, [x29, #-32]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB41_23
	b	LBB41_22
LBB41_22:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #40]
	ldur	w8, [x29, #-36]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbnz	w0, #0, LBB41_24
	b	LBB41_23
LBB41_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_41
LBB41_24:
	stur	wzr, [x29, #-40]
	b	LBB41_25
LBB41_25:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB41_33
	b	LBB41_26
LBB41_26:                               ;   in Loop: Header=BB41_25 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_field_read_entry
	tbnz	w0, #0, LBB41_28
	b	LBB41_27
LBB41_27:                               ;   in Loop: Header=BB41_25 Depth=1
	b	LBB41_32
LBB41_28:                               ;   in Loop: Header=BB41_25 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #40
	bl	_field_read_record
	tbz	w0, #0, LBB41_30
	b	LBB41_29
LBB41_29:                               ;   in Loop: Header=BB41_25 Depth=1
	ldur	x0, [x29, #-24]
	add	x1, sp, #40
	bl	_same_field_read
	tbz	w0, #0, LBB41_31
	b	LBB41_30
LBB41_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_41
LBB41_31:                               ;   in Loop: Header=BB41_25 Depth=1
	b	LBB41_32
LBB41_32:                               ;   in Loop: Header=BB41_25 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB41_25
LBB41_33:
	ldur	w8, [x29, #-28]
	add	w8, w8, #28
	ldur	w9, [x29, #-32]
	add	w8, w8, w9
	ldur	w9, [x29, #-36]
	add	w8, w8, w9
	str	w8, [sp, #36]
	ldr	w8, [sp, #36]
	mov	x1, x8
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB41_35
	b	LBB41_34
LBB41_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_41
LBB41_35:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #4
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #4]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #8
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #8]
	bl	_le_write_u32
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #12]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #13]
	ldr	x8, [sp, #24]
	add	x0, x8, #16
	ldur	w1, [x29, #-28]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #20
	ldur	w1, [x29, #-32]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #24
	ldur	w1, [x29, #-36]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #28
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #24]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #24]
	add	x8, x8, #28
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	ldur	w8, [x29, #-32]
	mov	x2, x8
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #24]
	add	x8, x8, #28
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #40]
	ldur	w8, [x29, #-36]
	mov	x2, x8
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	adrp	x1, _field_read_key@PAGE
	add	x1, x1, _field_read_key@PAGEOFF
	mov	w2, #18                         ; =0x12
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.ne	LBB41_37
	b	LBB41_36
LBB41_36:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB41_38
LBB41_37:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	w2, [sp, #36]
	bl	_nvm_add_string
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB41_38
LBB41_38:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	w8, [sp, #16]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB41_40
	b	LBB41_39
LBB41_39:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #20]
	ldr	w2, [sp, #16]
	bl	_nvm_add_metadata
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB41_40
LBB41_40:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_41
LBB41_41:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_field_write_at             ; -- Begin function nvm_field_write_at
	.p2align	2
_nvm_field_write_at:                    ; @nvm_field_write_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB42_3
	b	LBB42_1
LBB42_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB42_3
	b	LBB42_2
LBB42_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.lo	LBB42_4
	b	LBB42_3
LBB42_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_18
LBB42_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_field_write_entry
	tbz	w0, #0, LBB42_6
	b	LBB42_5
LBB42_5:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #80
	bl	_field_write_record
	tbnz	w0, #0, LBB42_7
	b	LBB42_6
LBB42_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_18
LBB42_7:
	str	wzr, [sp, #76]
	b	LBB42_8
LBB42_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB42_17
	b	LBB42_9
LBB42_9:                                ;   in Loop: Header=BB42_8 Depth=1
	ldr	w8, [sp, #76]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB42_11
	b	LBB42_10
LBB42_10:                               ;   in Loop: Header=BB42_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_field_write_entry
	tbnz	w0, #0, LBB42_12
	b	LBB42_11
LBB42_11:                               ;   in Loop: Header=BB42_8 Depth=1
	b	LBB42_16
LBB42_12:                               ;   in Loop: Header=BB42_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #8
	bl	_field_write_record
	tbz	w0, #0, LBB42_14
	b	LBB42_13
LBB42_13:                               ;   in Loop: Header=BB42_8 Depth=1
	add	x0, sp, #80
	add	x1, sp, #8
	bl	_same_field_write
	tbz	w0, #0, LBB42_15
	b	LBB42_14
LBB42_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_18
LBB42_15:                               ;   in Loop: Header=BB42_8 Depth=1
	b	LBB42_16
LBB42_16:                               ;   in Loop: Header=BB42_8 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB42_8
LBB42_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #80
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_18
LBB42_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_write_entry
_field_write_entry:                     ; @field_write_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #19
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB43_2
	b	LBB43_1
LBB43_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _field_write_key@PAGE
	add	x1, x1, _field_write_key@PAGEOFF
	mov	x2, #19                         ; =0x13
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB43_2
LBB43_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_write_record
_field_write_record:                    ; @field_write_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	subs	w8, w8, #28
	b.hs	LBB44_2
	b	LBB44_1
LBB44_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_23
LBB44_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	add	x0, x8, #16
	bl	_le_read_u32
	stur	w0, [x29, #-52]
	ldur	x8, [x29, #-48]
	add	x0, x8, #20
	bl	_le_read_u32
	stur	w0, [x29, #-56]
	ldur	x8, [x29, #-48]
	add	x0, x8, #24
	bl	_le_read_u32
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB44_7
	b	LBB44_3
LBB44_3:
	ldur	w8, [x29, #-56]
	cbz	w8, LBB44_7
	b	LBB44_4
LBB44_4:
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #28
	subs	w8, w8, w9
	b.hi	LBB44_7
	b	LBB44_5
LBB44_5:
	ldur	w8, [x29, #-56]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #28
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB44_7
	b	LBB44_6
LBB44_6:
	ldur	w8, [x29, #-60]
	ldur	w9, [x29, #-36]
	subs	w9, w9, #28
	ldur	w10, [x29, #-52]
	subs	w9, w9, w10
	ldur	w10, [x29, #-56]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.eq	LBB44_8
	b	LBB44_7
LBB44_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_23
LBB44_8:
	ldur	x0, [x29, #-48]
	bl	_le_read_u32
	str	w0, [sp]
	ldur	x8, [x29, #-48]
	add	x0, x8, #4
	bl	_le_read_u32
	str	w0, [sp, #4]
	ldur	x8, [x29, #-48]
	add	x0, x8, #8
	bl	_le_read_u32
	str	w0, [sp, #8]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #12]
	str	w8, [sp, #12]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #13]
	str	w8, [sp, #16]
	str	wzr, [sp, #20]
	ldur	x8, [x29, #-48]
	add	x8, x8, #28
	str	x8, [sp, #24]
	ldur	x8, [x29, #-48]
	add	x8, x8, #28
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldur	x8, [x29, #-48]
	add	x8, x8, #28
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldur	w8, [x29, #-52]
	str	w8, [sp, #48]
	ldur	w8, [x29, #-56]
	str	w8, [sp, #52]
	ldur	w8, [x29, #-60]
	str	w8, [sp, #56]
	str	wzr, [sp, #60]
	ldr	w8, [sp]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB44_21
	b	LBB44_9
LBB44_9:
	ldr	w8, [sp, #4]
	cbz	w8, LBB44_21
	b	LBB44_10
LBB44_10:
	ldr	w8, [sp, #8]
	cbz	w8, LBB44_21
	b	LBB44_11
LBB44_11:
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	b.ne	LBB44_21
	b	LBB44_12
LBB44_12:
	ldr	w8, [sp, #16]
	subs	w8, w8, #1
	b.lo	LBB44_21
	b	LBB44_13
LBB44_13:
	ldr	w8, [sp, #16]
	subs	w8, w8, #2
	b.hi	LBB44_21
	b	LBB44_14
LBB44_14:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #14]
	cbnz	w8, LBB44_21
	b	LBB44_15
LBB44_15:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #15]
	cbnz	w8, LBB44_21
	b	LBB44_16
LBB44_16:
	ldur	w8, [x29, #-60]
	cbz	w8, LBB44_21
	b	LBB44_17
LBB44_17:
	ldr	x8, [sp, #40]
	ldrsb	w8, [x8]
	subs	w8, w8, #46
	b.ne	LBB44_21
	b	LBB44_18
LBB44_18:
	ldr	x0, [sp, #24]
	ldur	w8, [x29, #-52]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB44_21
	b	LBB44_19
LBB44_19:
	ldr	x0, [sp, #32]
	ldur	w8, [x29, #-56]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB44_21
	b	LBB44_20
LBB44_20:
	ldr	x0, [sp, #40]
	ldur	w8, [x29, #-60]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbnz	w0, #0, LBB44_22
	b	LBB44_21
LBB44_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_23
LBB44_22:
	ldur	x0, [x29, #-32]
	mov	x1, sp
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_23
LBB44_23:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_field_write
_same_field_write:                      ; @same_field_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	w9, [x8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB45_6
	b	LBB45_1
LBB45_1:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB45_6
	b	LBB45_2
LBB45_2:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB45_6
	b	LBB45_3
LBB45_3:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #16]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB45_6
	b	LBB45_4
LBB45_4:
	ldur	x8, [x29, #-8]
	ldr	w9, [x8, #48]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #48]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB45_6
	b	LBB45_5
LBB45_5:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #24]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #24]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #48]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB45_6
LBB45_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_field_write            ; -- Begin function nvm_add_field_write
	.p2align	2
_nvm_add_field_write:                   ; @nvm_add_field_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB46_15
	b	LBB46_1
LBB46_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB46_15
	b	LBB46_2
LBB46_2:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB46_15
	b	LBB46_3
LBB46_3:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	cbz	w8, LBB46_15
	b	LBB46_4
LBB46_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	cbz	w8, LBB46_15
	b	LBB46_5
LBB46_5:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	subs	w8, w8, #1
	b.ne	LBB46_15
	b	LBB46_6
LBB46_6:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.lo	LBB46_15
	b	LBB46_7
LBB46_7:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #2
	b.hi	LBB46_15
	b	LBB46_8
LBB46_8:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	cbz	x8, LBB46_15
	b	LBB46_9
LBB46_9:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB46_15
	b	LBB46_10
LBB46_10:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	cbz	x8, LBB46_15
	b	LBB46_11
LBB46_11:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #48]
	cbz	w8, LBB46_15
	b	LBB46_12
LBB46_12:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #52]
	cbz	w8, LBB46_15
	b	LBB46_13
LBB46_13:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #56]
	cbz	w8, LBB46_15
	b	LBB46_14
LBB46_14:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldrsb	w8, [x8]
	subs	w8, w8, #46
	b.eq	LBB46_16
	b	LBB46_15
LBB46_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_40
LBB46_16:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #48]
	stur	w8, [x29, #-28]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #52]
	stur	w8, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #56]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-28]
	adds	w8, w8, #29
	b.hi	LBB46_22
	b	LBB46_17
LBB46_17:
	ldur	w8, [x29, #-32]
	ldur	w10, [x29, #-28]
	mov	w9, #-29                        ; =0xffffffe3
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB46_22
	b	LBB46_18
LBB46_18:
	ldur	w8, [x29, #-36]
	ldur	w10, [x29, #-28]
	mov	w9, #-29                        ; =0xffffffe3
	subs	w9, w9, w10
	ldur	w10, [x29, #-32]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB46_22
	b	LBB46_19
LBB46_19:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #24]
	ldur	w8, [x29, #-28]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB46_22
	b	LBB46_20
LBB46_20:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #32]
	ldur	w8, [x29, #-32]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbz	w0, #0, LBB46_22
	b	LBB46_21
LBB46_21:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #40]
	ldur	w8, [x29, #-36]
	mov	x1, x8
	bl	_borrow_place_utf8
	tbnz	w0, #0, LBB46_23
	b	LBB46_22
LBB46_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_40
LBB46_23:
	stur	wzr, [x29, #-40]
	b	LBB46_24
LBB46_24:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB46_32
	b	LBB46_25
LBB46_25:                               ;   in Loop: Header=BB46_24 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_field_write_entry
	tbnz	w0, #0, LBB46_27
	b	LBB46_26
LBB46_26:                               ;   in Loop: Header=BB46_24 Depth=1
	b	LBB46_31
LBB46_27:                               ;   in Loop: Header=BB46_24 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #40
	bl	_field_write_record
	tbz	w0, #0, LBB46_29
	b	LBB46_28
LBB46_28:                               ;   in Loop: Header=BB46_24 Depth=1
	ldur	x0, [x29, #-24]
	add	x1, sp, #40
	bl	_same_field_write
	tbz	w0, #0, LBB46_30
	b	LBB46_29
LBB46_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_40
LBB46_30:                               ;   in Loop: Header=BB46_24 Depth=1
	b	LBB46_31
LBB46_31:                               ;   in Loop: Header=BB46_24 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB46_24
LBB46_32:
	ldur	w8, [x29, #-28]
	add	w8, w8, #28
	ldur	w9, [x29, #-32]
	add	w8, w8, w9
	ldur	w9, [x29, #-36]
	add	w8, w8, w9
	str	w8, [sp, #36]
	ldr	w8, [sp, #36]
	mov	x1, x8
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB46_34
	b	LBB46_33
LBB46_33:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_40
LBB46_34:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #4
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #4]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #8
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #8]
	bl	_le_write_u32
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #12]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #13]
	ldr	x8, [sp, #24]
	add	x0, x8, #16
	ldur	w1, [x29, #-28]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #20
	ldur	w1, [x29, #-32]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #24
	ldur	w1, [x29, #-36]
	bl	_le_write_u32
	ldr	x8, [sp, #24]
	add	x0, x8, #28
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #24]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #24]
	add	x8, x8, #28
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	ldur	w8, [x29, #-32]
	mov	x2, x8
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #24]
	add	x8, x8, #28
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #40]
	ldur	w8, [x29, #-36]
	mov	x2, x8
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	adrp	x1, _field_write_key@PAGE
	add	x1, x1, _field_write_key@PAGEOFF
	mov	w2, #19                         ; =0x13
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.ne	LBB46_36
	b	LBB46_35
LBB46_35:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB46_37
LBB46_36:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	w2, [sp, #36]
	bl	_nvm_add_string
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB46_37
LBB46_37:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	w8, [sp, #16]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB46_39
	b	LBB46_38
LBB46_38:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #20]
	ldr	w2, [sp, #16]
	bl	_nvm_add_metadata
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB46_39
LBB46_39:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_40
LBB46_40:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_generic_binding_at         ; -- Begin function nvm_generic_binding_at
	.p2align	2
_nvm_generic_binding_at:                ; @nvm_generic_binding_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB47_3
	b	LBB47_1
LBB47_1:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB47_3
	b	LBB47_2
LBB47_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.lo	LBB47_4
	b	LBB47_3
LBB47_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_18
LBB47_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #64]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #64]
	bl	_generic_metadata_entry
	tbz	w0, #0, LBB47_6
	b	LBB47_5
LBB47_5:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #64]
	add	x2, sp, #72
	bl	_generic_metadata_record
	tbnz	w0, #0, LBB47_7
	b	LBB47_6
LBB47_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_18
LBB47_7:
	str	wzr, [sp, #60]
	b	LBB47_8
LBB47_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB47_17
	b	LBB47_9
LBB47_9:                                ;   in Loop: Header=BB47_8 Depth=1
	ldr	w8, [sp, #60]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB47_11
	b	LBB47_10
LBB47_10:                               ;   in Loop: Header=BB47_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_generic_metadata_entry
	tbnz	w0, #0, LBB47_12
	b	LBB47_11
LBB47_11:                               ;   in Loop: Header=BB47_8 Depth=1
	b	LBB47_16
LBB47_12:                               ;   in Loop: Header=BB47_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	mov	x2, sp
	bl	_generic_metadata_record
	tbz	w0, #0, LBB47_14
	b	LBB47_13
LBB47_13:                               ;   in Loop: Header=BB47_8 Depth=1
	add	x0, sp, #72
	mov	x1, sp
	bl	_generic_metadata_distinct
	tbnz	w0, #0, LBB47_15
	b	LBB47_14
LBB47_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_18
LBB47_15:                               ;   in Loop: Header=BB47_8 Depth=1
	b	LBB47_16
LBB47_16:                               ;   in Loop: Header=BB47_8 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB47_8
LBB47_17:
	ldur	x0, [x29, #-32]
	add	x1, sp, #72
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_18
LBB47_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function generic_metadata_entry
_generic_metadata_entry:                ; @generic_metadata_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #15
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB48_2
	b	LBB48_1
LBB48_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, _generic_key@PAGE
	add	x1, x1, _generic_key@PAGEOFF
	mov	x2, #15                         ; =0xf
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB48_2
LBB48_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function generic_metadata_record
_generic_metadata_record:               ; @generic_metadata_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-72]
	stur	x1, [x29, #-80]
	stur	x2, [x29, #-88]
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-92]
	ldur	w8, [x29, #-92]
	subs	w8, w8, #20
	b.hs	LBB49_2
	b	LBB49_1
LBB49_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB49_20
LBB49_2:
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #88]
	ldr	x0, [sp, #88]
	bl	_le_read_u32
	str	w0, [sp, #84]
	ldr	w8, [sp, #84]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB49_4
	b	LBB49_3
LBB49_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB49_20
LBB49_4:
	str	wzr, [sp, #80]
	b	LBB49_5
LBB49_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #80]
	subs	w8, w8, #4
	b.hs	LBB49_8
	b	LBB49_6
LBB49_6:                                ;   in Loop: Header=BB49_5 Depth=1
	ldr	x8, [sp, #88]
	add	x8, x8, #4
	ldr	w10, [sp, #80]
	mov	w9, #4                          ; =0x4
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	ldr	w8, [sp, #80]
	mov	x9, x8
	sub	x8, x29, #24
	str	w0, [x8, x9, lsl #2]
	b	LBB49_7
LBB49_7:                                ;   in Loop: Header=BB49_5 Depth=1
	ldr	w8, [sp, #80]
	add	w8, w8, #1
	str	w8, [sp, #80]
	b	LBB49_5
LBB49_8:
	ldr	x8, [sp, #88]
	add	x8, x8, #20
	str	x8, [sp, #88]
	ldur	w8, [x29, #-92]
	subs	w8, w8, #20
	stur	w8, [x29, #-92]
	str	wzr, [sp, #76]
	b	LBB49_9
LBB49_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	subs	w8, w8, #4
	b.hs	LBB49_17
	b	LBB49_10
LBB49_10:                               ;   in Loop: Header=BB49_9 Depth=1
	ldr	w8, [sp, #76]
	mov	x9, x8
	sub	x8, x29, #24
	ldr	w8, [x8, x9, lsl #2]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hi	LBB49_14
	b	LBB49_11
LBB49_11:                               ;   in Loop: Header=BB49_9 Depth=1
	ldr	w8, [sp, #76]
	mov	x9, x8
	sub	x8, x29, #24
	ldr	w8, [x8, x9, lsl #2]
	cbnz	w8, LBB49_13
	b	LBB49_12
LBB49_12:                               ;   in Loop: Header=BB49_9 Depth=1
	ldr	w8, [sp, #76]
	subs	w8, w8, #1
	b.ne	LBB49_14
	b	LBB49_13
LBB49_13:                               ;   in Loop: Header=BB49_9 Depth=1
	ldr	x0, [sp, #88]
	ldr	w8, [sp, #76]
	mov	x9, x8
	sub	x8, x29, #24
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB49_15
	b	LBB49_14
LBB49_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB49_20
LBB49_15:                               ;   in Loop: Header=BB49_9 Depth=1
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #76]
	mov	x10, x9
	sub	x9, x29, #56
	str	x8, [x9, x10, lsl #3]
	ldr	w8, [sp, #76]
	mov	x9, x8
	sub	x8, x29, #24
	ldr	w9, [x8, x9, lsl #2]
	mov	x10, x9
	ldr	x9, [sp, #88]
	add	x9, x9, x10
	str	x9, [sp, #88]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	ldr	w9, [x8, x9, lsl #2]
	ldur	w8, [x29, #-92]
	subs	w8, w8, w9
	stur	w8, [x29, #-92]
	b	LBB49_16
LBB49_16:                               ;   in Loop: Header=BB49_9 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB49_9
LBB49_17:
	ldur	w8, [x29, #-92]
	cbz	w8, LBB49_19
	b	LBB49_18
LBB49_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB49_20
LBB49_19:
	ldur	x0, [x29, #-88]
	ldr	w8, [sp, #84]
	add	x1, sp, #16
	str	w8, [sp, #16]
	str	wzr, [sp, #20]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #24]
	ldur	x8, [x29, #-48]
	str	x8, [sp, #32]
	ldur	x8, [x29, #-40]
	str	x8, [sp, #40]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #48]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #56]
	ldur	w8, [x29, #-20]
	str	w8, [sp, #60]
	ldur	w8, [x29, #-16]
	str	w8, [sp, #64]
	ldur	w8, [x29, #-12]
	str	w8, [sp, #68]
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB49_20
LBB49_20:
	ldurb	w8, [x29, #-57]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB49_22
	b	LBB49_21
LBB49_21:
	bl	___stack_chk_fail
LBB49_22:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function generic_metadata_distinct
_generic_metadata_distinct:             ; @generic_metadata_distinct
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	w8, [x8]
	ldr	x9, [sp, #8]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.eq	LBB50_2
	b	LBB50_1
LBB50_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB50_6
LBB50_2:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #40]
	ldr	x8, [sp, #8]
	ldr	x2, [x8, #8]
	ldr	x8, [sp, #8]
	ldr	w3, [x8, #40]
	bl	_generic_text_equal
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB50_5
	b	LBB50_3
LBB50_3:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #44]
	ldr	x8, [sp, #8]
	ldr	x2, [x8, #16]
	ldr	x8, [sp, #8]
	ldr	w3, [x8, #44]
	bl	_generic_text_equal
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB50_5
	b	LBB50_4
LBB50_4:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #24]
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #48]
	ldr	x8, [sp, #8]
	ldr	x2, [x8, #24]
	ldr	x8, [sp, #8]
	ldr	w3, [x8, #48]
	bl	_generic_text_equal
	eor	w8, w0, #0x1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB50_5
LBB50_5:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB50_6
LBB50_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_generic_binding        ; -- Begin function nvm_add_generic_binding
	.p2align	2
_nvm_add_generic_binding:               ; @nvm_add_generic_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #336
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-88]
	stur	w1, [x29, #-92]
	stur	x2, [x29, #-104]
	stur	x3, [x29, #-112]
	stur	x4, [x29, #-120]
	stur	x5, [x29, #-128]
	ldur	x0, [x29, #-88]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB51_2
	b	LBB51_1
LBB51_1:
	ldur	w8, [x29, #-92]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB51_3
	b	LBB51_2
LBB51_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-73]
	b	LBB51_34
LBB51_3:
	ldur	x8, [x29, #-104]
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-112]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-120]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-128]
	stur	x8, [x29, #-32]
	mov	w8, #20                         ; =0x14
	stur	w8, [x29, #-132]
	stur	wzr, [x29, #-136]
	b	LBB51_4
LBB51_4:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-136]
	subs	w8, w8, #4
	b.hs	LBB51_13
	b	LBB51_5
LBB51_5:                                ;   in Loop: Header=BB51_4 Depth=1
	ldur	w8, [x29, #-136]
	mov	x9, x8
	sub	x8, x29, #56
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB51_7
	b	LBB51_6
LBB51_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-73]
	b	LBB51_34
LBB51_7:                                ;   in Loop: Header=BB51_4 Depth=1
	ldur	w8, [x29, #-136]
	mov	x9, x8
	sub	x8, x29, #56
	ldr	x0, [x8, x9, lsl #3]
	bl	_strlen
	stur	x0, [x29, #-144]
	ldur	x8, [x29, #-144]
	cbnz	x8, LBB51_9
	b	LBB51_8
LBB51_8:                                ;   in Loop: Header=BB51_4 Depth=1
	ldur	w8, [x29, #-136]
	subs	w8, w8, #1
	b.ne	LBB51_10
	b	LBB51_9
LBB51_9:                                ;   in Loop: Header=BB51_4 Depth=1
	ldur	x8, [x29, #-144]
	ldur	w10, [x29, #-132]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ls	LBB51_11
	b	LBB51_10
LBB51_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-73]
	b	LBB51_34
LBB51_11:                               ;   in Loop: Header=BB51_4 Depth=1
	ldur	x9, [x29, #-144]
	ldur	w8, [x29, #-136]
	mov	x10, x8
	sub	x8, x29, #72
                                        ; kill: def $w9 killed $w9 killed $x9
	str	w9, [x8, x10, lsl #2]
	ldur	w9, [x29, #-136]
                                        ; kill: def $x9 killed $w9
	ldr	w9, [x8, x9, lsl #2]
	ldur	w8, [x29, #-132]
	add	w8, w8, w9
	stur	w8, [x29, #-132]
	b	LBB51_12
LBB51_12:                               ;   in Loop: Header=BB51_4 Depth=1
	ldur	w8, [x29, #-136]
	add	w8, w8, #1
	stur	w8, [x29, #-136]
	b	LBB51_4
LBB51_13:
	ldur	w8, [x29, #-92]
	str	w8, [sp, #120]
	str	wzr, [sp, #124]
	ldur	x8, [x29, #-104]
	str	x8, [sp, #128]
	ldur	x8, [x29, #-112]
	str	x8, [sp, #136]
	ldur	x8, [x29, #-120]
	str	x8, [sp, #144]
	ldur	x8, [x29, #-128]
	str	x8, [sp, #152]
	ldur	w8, [x29, #-72]
	str	w8, [sp, #160]
	ldur	w8, [x29, #-68]
	str	w8, [sp, #164]
	ldur	w8, [x29, #-64]
	str	w8, [sp, #168]
	ldur	w8, [x29, #-60]
	str	w8, [sp, #172]
	str	wzr, [sp, #116]
	b	LBB51_14
LBB51_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #116]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB51_22
	b	LBB51_15
LBB51_15:                               ;   in Loop: Header=BB51_14 Depth=1
	ldur	x0, [x29, #-88]
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #116]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_generic_metadata_entry
	tbnz	w0, #0, LBB51_17
	b	LBB51_16
LBB51_16:                               ;   in Loop: Header=BB51_14 Depth=1
	b	LBB51_21
LBB51_17:                               ;   in Loop: Header=BB51_14 Depth=1
	ldur	x0, [x29, #-88]
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #116]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #56
	bl	_generic_metadata_record
	tbz	w0, #0, LBB51_19
	b	LBB51_18
LBB51_18:                               ;   in Loop: Header=BB51_14 Depth=1
	add	x0, sp, #120
	add	x1, sp, #56
	bl	_generic_metadata_distinct
	tbnz	w0, #0, LBB51_20
	b	LBB51_19
LBB51_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-73]
	b	LBB51_34
LBB51_20:                               ;   in Loop: Header=BB51_14 Depth=1
	b	LBB51_21
LBB51_21:                               ;   in Loop: Header=BB51_14 Depth=1
	ldr	w8, [sp, #116]
	add	w8, w8, #1
	str	w8, [sp, #116]
	b	LBB51_14
LBB51_22:
	ldur	w8, [x29, #-132]
	mov	x0, x8
	bl	_malloc
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB51_24
	b	LBB51_23
LBB51_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-73]
	b	LBB51_34
LBB51_24:
	ldr	x0, [sp, #48]
	ldur	w1, [x29, #-92]
	bl	_le_write_u32
	mov	w8, #20                         ; =0x14
	str	w8, [sp, #44]
	str	wzr, [sp, #40]
	b	LBB51_25
LBB51_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #40]
	subs	w8, w8, #4
	b.hs	LBB51_28
	b	LBB51_26
LBB51_26:                               ;   in Loop: Header=BB51_25 Depth=1
	ldr	x8, [sp, #48]
	add	x8, x8, #4
	ldr	w10, [sp, #40]
	mov	w9, #4                          ; =0x4
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w8, [sp, #40]
	mov	x9, x8
	sub	x8, x29, #72
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w1, [x8, x9, lsl #2]
	bl	_le_write_u32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #48]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x0, x9, x10
	ldr	w9, [sp, #40]
	mov	x10, x9
	sub	x9, x29, #56
	ldr	x1, [x9, x10, lsl #3]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	ldr	w9, [x8, x9, lsl #2]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB51_27
LBB51_27:                               ;   in Loop: Header=BB51_25 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB51_25
LBB51_28:
	ldur	x0, [x29, #-88]
	adrp	x1, _generic_key@PAGE
	add	x1, x1, _generic_key@PAGEOFF
	mov	w2, #15                         ; =0xf
	bl	_nvm_add_string
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	adds	w8, w8, #1
	b.ne	LBB51_30
	b	LBB51_29
LBB51_29:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB51_31
LBB51_30:
	ldur	x0, [x29, #-88]
	ldr	x1, [sp, #48]
	ldur	w2, [x29, #-132]
	bl	_nvm_add_string
	str	w0, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB51_31
LBB51_31:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [sp, #32]
	ldr	x0, [sp, #48]
	bl	_free
	ldr	w8, [sp, #32]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.eq	LBB51_33
	b	LBB51_32
LBB51_32:
	ldur	x0, [x29, #-88]
	ldr	w1, [sp, #36]
	ldr	w2, [sp, #32]
	bl	_nvm_add_metadata
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB51_33
LBB51_33:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-73]
	b	LBB51_34
LBB51_34:
	ldurb	w8, [x29, #-73]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB51_36
	b	LBB51_35
LBB51_35:
	bl	___stack_chk_fail
LBB51_36:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_call_descriptors_reset     ; -- Begin function nvm_call_descriptors_reset
	.p2align	2
_nvm_call_descriptors_reset:            ; @nvm_call_descriptors_reset
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB52_2
	b	LBB52_1
LBB52_1:
	b	LBB52_3
LBB52_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #456]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #456]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #464]
	b	LBB52_3
LBB52_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_get_string                 ; -- Begin function nvm_get_string
	.p2align	2
_nvm_get_string:                        ; @nvm_get_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB53_2
	b	LBB53_1
LBB53_1:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB53_3
LBB53_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]
	b	LBB53_3
LBB53_3:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_get_string_len             ; -- Begin function nvm_get_string_len
	.p2align	2
_nvm_get_string_len:                    ; @nvm_get_string_len
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB54_2
	b	LBB54_1
LBB54_1:
	str	wzr, [sp, #28]
	b	LBB54_3
LBB54_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #28]
	b	LBB54_3
LBB54_3:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_function               ; -- Begin function nvm_add_function
	.p2align	2
_nvm_add_function:                      ; @nvm_add_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB55_2
	b	LBB55_1
LBB55_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB55_3
	b	LBB55_2
LBB55_2:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB55_18
LBB55_3:
	ldur	x8, [x29, #-24]
	ldr	q0, [x8]
	str	q0, [sp, #32]
	ldr	x8, [x8, #16]
	str	x8, [sp, #48]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #276]
	subs	w8, w8, w9
	b.lo	LBB55_17
	b	LBB55_4
LBB55_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #276]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB55_6
	b	LBB55_5
LBB55_5:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB55_18
LBB55_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #276]
	cbz	w8, LBB55_8
	b	LBB55_7
LBB55_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #276]
	lsl	w8, w8, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB55_9
LBB55_8:
	mov	w8, #32                         ; =0x20
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB55_9
LBB55_9:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #28]
	ldr	w8, [sp, #28]
	mov	x0, x8
	mov	x1, #24                         ; =0x18
	bl	_calloc
	str	x0, [sp, #16]
	ldr	w8, [sp, #28]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB55_11
	b	LBB55_10
LBB55_10:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB55_12
	b	LBB55_11
LBB55_11:
	ldr	x0, [sp, #16]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB55_18
LBB55_12:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB55_16
	b	LBB55_13
LBB55_13:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #256]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	cbz	x8, LBB55_15
	b	LBB55_14
LBB55_14:
	ldr	x0, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #264]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB55_15
LBB55_15:
	b	LBB55_16
LBB55_16:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #256]
	bl	_free
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #264]
	bl	_free
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #256]
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #264]
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #276]
	b	LBB55_17
LBB55_17:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	str	w8, [sp, #4]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	q0, [sp, #32]
	str	q0, [x9]
	ldr	x8, [sp, #48]
	str	x8, [x9, #16]
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #272]
	add	w8, w8, #1
	str	w8, [x9, #272]
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB55_18
LBB55_18:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_set_function_param_types   ; -- Begin function nvm_set_function_param_types
	.p2align	2
_nvm_set_function_param_types:          ; @nvm_set_function_param_types
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #32]
	strh	w3, [sp, #30]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB56_6
	b	LBB56_1
LBB56_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB56_6
	b	LBB56_2
LBB56_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	cbz	x8, LBB56_6
	b	LBB56_3
LBB56_3:
	ldrh	w8, [sp, #30]
	ldur	x9, [x29, #-16]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB56_6
	b	LBB56_4
LBB56_4:
	ldrh	w8, [sp, #30]
	cbz	w8, LBB56_7
	b	LBB56_5
LBB56_5:
	ldr	x8, [sp, #32]
	cbnz	x8, LBB56_7
	b	LBB56_6
LBB56_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB56_22
LBB56_7:
	strh	wzr, [sp, #28]
	b	LBB56_8
LBB56_8:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #28]
	ldrh	w9, [sp, #30]
	subs	w8, w8, w9
	b.ge	LBB56_13
	b	LBB56_9
LBB56_9:                                ;   in Loop: Header=BB56_8 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #16
	b.lt	LBB56_11
	b	LBB56_10
LBB56_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB56_22
LBB56_11:                               ;   in Loop: Header=BB56_8 Depth=1
	b	LBB56_12
LBB56_12:                               ;   in Loop: Header=BB56_8 Depth=1
	ldrh	w8, [sp, #28]
	add	w8, w8, #1
	strh	w8, [sp, #28]
	b	LBB56_8
LBB56_13:
	ldrh	w8, [sp, #30]
	cbz	w8, LBB56_15
	b	LBB56_14
LBB56_14:
	ldrh	w8, [sp, #30]
	mov	x0, x8
	bl	_malloc
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB56_16
LBB56_15:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB56_16
LBB56_16:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #16]
	ldrh	w8, [sp, #30]
	cbz	w8, LBB56_19
	b	LBB56_17
LBB56_17:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB56_19
	b	LBB56_18
LBB56_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB56_22
LBB56_19:
	ldrh	w8, [sp, #30]
	cbz	w8, LBB56_21
	b	LBB56_20
LBB56_20:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #32]
	ldrh	w8, [sp, #30]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB56_21
LBB56_21:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #264]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB56_22
LBB56_22:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_callback_shape_valid       ; -- Begin function nvm_callback_shape_valid
	.p2align	2
_nvm_callback_shape_valid:              ; @nvm_callback_shape_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	strb	w2, [sp, #13]
	ldrh	w8, [sp, #14]
	subs	w8, w8, #16
	b.gt	LBB57_5
	b	LBB57_1
LBB57_1:
	ldrh	w8, [sp, #14]
	cbz	w8, LBB57_3
	b	LBB57_2
LBB57_2:
	ldr	x8, [sp, #16]
	cbz	x8, LBB57_5
	b	LBB57_3
LBB57_3:
	ldrb	w8, [sp, #13]
	cbz	w8, LBB57_6
	b	LBB57_4
LBB57_4:
	ldrb	w0, [sp, #13]
	bl	_callback_scalar
	tbnz	w0, #0, LBB57_6
	b	LBB57_5
LBB57_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_13
LBB57_6:
	strh	wzr, [sp, #10]
	b	LBB57_7
LBB57_7:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ge	LBB57_12
	b	LBB57_8
LBB57_8:                                ;   in Loop: Header=BB57_7 Depth=1
	ldr	x8, [sp, #16]
	ldrh	w9, [sp, #10]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	bl	_callback_scalar
	tbnz	w0, #0, LBB57_10
	b	LBB57_9
LBB57_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_13
LBB57_10:                               ;   in Loop: Header=BB57_7 Depth=1
	b	LBB57_11
LBB57_11:                               ;   in Loop: Header=BB57_7 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB57_7
LBB57_12:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_13
LBB57_13:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function callback_scalar
_callback_scalar:                       ; @callback_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB58_5
	b	LBB58_1
LBB58_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB58_5
	b	LBB58_2
LBB58_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB58_5
	b	LBB58_3
LBB58_3:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB58_5
	b	LBB58_4
LBB58_4:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #14
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB58_5
LBB58_5:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_callback_contract      ; -- Begin function nvm_add_callback_contract
	.p2align	2
_nvm_add_callback_contract:             ; @nvm_add_callback_contract
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	ldr	x8, [sp, #48]
	cbz	x8, LBB59_5
	b	LBB59_1
LBB59_1:
	ldr	x8, [sp, #40]
	cbz	x8, LBB59_5
	b	LBB59_2
LBB59_2:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #1
	b.ne	LBB59_5
	b	LBB59_3
LBB59_3:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #11]
	subs	w8, w8, #1
	b.gt	LBB59_5
	b	LBB59_4
LBB59_4:
	ldr	x8, [sp, #40]
	add	x0, x8, #15
	ldr	x8, [sp, #40]
	ldrh	w1, [x8, #12]
	ldr	x8, [sp, #40]
	ldrb	w2, [x8, #14]
	bl	_nvm_callback_shape_valid
	tbnz	w0, #0, LBB59_6
	b	LBB59_5
LBB59_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-49]
	b	LBB59_28
LBB59_6:
	ldr	x8, [sp, #40]
	ldr	q0, [x8]
	stur	q0, [x29, #-48]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-32]
	ldurh	w8, [x29, #-40]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB59_10
	b	LBB59_7
LBB59_7:
	ldurh	w8, [x29, #-36]
	cbnz	w8, LBB59_9
	b	LBB59_8
LBB59_8:
	ldurb	w8, [x29, #-34]
	cbz	w8, LBB59_10
	b	LBB59_9
LBB59_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-49]
	b	LBB59_28
LBB59_10:
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #424]
	cbz	w8, LBB59_16
	b	LBB59_11
LBB59_11:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #416]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #424]
	subs	w9, w9, #1
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #32]
	ldur	w8, [x29, #-48]
	ldr	x9, [sp, #32]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB59_14
	b	LBB59_12
LBB59_12:
	ldur	w8, [x29, #-48]
	ldr	x9, [sp, #32]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB59_15
	b	LBB59_13
LBB59_13:
	ldurh	w8, [x29, #-40]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.gt	LBB59_15
	b	LBB59_14
LBB59_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-49]
	b	LBB59_28
LBB59_15:
	b	LBB59_16
LBB59_16:
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #424]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #428]
	subs	w8, w8, w9
	b.ne	LBB59_27
	b	LBB59_17
LBB59_17:
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #428]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB59_19
	b	LBB59_18
LBB59_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-49]
	b	LBB59_28
LBB59_19:
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #428]
	cbz	w8, LBB59_21
	b	LBB59_20
LBB59_20:
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #428]
	lsl	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB59_22
LBB59_21:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB59_22
LBB59_22:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #28]
	ldr	w8, [sp, #28]
	mov	x0, x8
	mov	x1, #32                         ; =0x20
	bl	_calloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB59_24
	b	LBB59_23
LBB59_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-49]
	b	LBB59_28
LBB59_24:
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #424]
	cbz	w8, LBB59_26
	b	LBB59_25
LBB59_25:
	ldr	x0, [sp, #16]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #416]
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #424]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #5
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB59_26
LBB59_26:
	ldr	x8, [sp, #48]
	ldr	x0, [x8, #416]
	bl	_free
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #48]
	str	x8, [x9, #416]
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #48]
	str	w8, [x9, #428]
	b	LBB59_27
LBB59_27:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #416]
	ldr	x12, [sp, #48]
	ldr	w9, [x12, #424]
	mov	x10, x9
	mov	x11, x10
	mov	w9, #1                          ; =0x1
	add	w11, w11, #1
	str	w11, [x12, #424]
	add	x8, x8, x10, lsl #5
	ldur	q0, [x29, #-48]
	str	q0, [x8]
	ldur	q0, [x29, #-32]
	str	q0, [x8, #16]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-49]
	b	LBB59_28
LBB59_28:
	ldurb	w8, [x29, #-49]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB59_30
	b	LBB59_29
LBB59_29:
	bl	___stack_chk_fail
LBB59_30:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_callback_contracts_valid   ; -- Begin function nvm_callback_contracts_valid
	.p2align	2
_nvm_callback_contracts_valid:          ; @nvm_callback_contracts_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB60_3
	b	LBB60_1
LBB60_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #424]
	cbz	w8, LBB60_4
	b	LBB60_2
LBB60_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #416]
	cbnz	x8, LBB60_4
	b	LBB60_3
LBB60_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_4:
	stur	wzr, [x29, #-20]
	b	LBB60_5
LBB60_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB60_15 Depth 2
                                        ;     Child Loop BB60_22 Depth 2
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #424]
	subs	w8, w8, w9
	b.hs	LBB60_55
	b	LBB60_6
LBB60_6:                                ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #416]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB60_8
	b	LBB60_7
LBB60_7:                                ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #400]
	cbnz	x8, LBB60_9
	b	LBB60_8
LBB60_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_9:                                ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #400]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #16
	b.gt	LBB60_13
	b	LBB60_10
LBB60_10:                               ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #8]
	cbz	w8, LBB60_14
	b	LBB60_11
LBB60_11:                               ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	cbz	x8, LBB60_13
	b	LBB60_12
LBB60_12:                               ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB60_14
	b	LBB60_13
LBB60_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_14:                               ;   in Loop: Header=BB60_5 Depth=1
	stur	wzr, [x29, #-44]
	str	wzr, [sp, #48]
	strh	wzr, [sp, #46]
	b	LBB60_15
LBB60_15:                               ;   Parent Loop BB60_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #46]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB60_21
	b	LBB60_16
LBB60_16:                               ;   in Loop: Header=BB60_15 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #45]
	ldrb	w8, [sp, #45]
	subs	w8, w8, #11
	b.eq	LBB60_18
	b	LBB60_17
LBB60_17:                               ;   in Loop: Header=BB60_15 Depth=2
	ldrb	w8, [sp, #45]
	subs	w8, w8, #15
	b.ne	LBB60_19
	b	LBB60_18
LBB60_18:                               ;   in Loop: Header=BB60_15 Depth=2
	ldrh	w9, [sp, #46]
	mov	w8, #1                          ; =0x1
	lsl	w9, w8, w9
	ldur	w8, [x29, #-44]
	orr	w8, w8, w9
	stur	w8, [x29, #-44]
	b	LBB60_19
LBB60_19:                               ;   in Loop: Header=BB60_15 Depth=2
	b	LBB60_20
LBB60_20:                               ;   in Loop: Header=BB60_15 Depth=2
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB60_15
LBB60_21:                               ;   in Loop: Header=BB60_5 Depth=1
	ldur	w8, [x29, #-20]
	str	w8, [sp, #40]
	b	LBB60_22
LBB60_22:                               ;   Parent Loop BB60_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w9, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	w10, [x8, #424]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.hs	LBB60_24
	b	LBB60_23
LBB60_23:                               ;   in Loop: Header=BB60_22 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #416]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #5
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB60_24
LBB60_24:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB60_50
	b	LBB60_25
LBB60_25:                               ;   in Loop: Header=BB60_22 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #416]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #1
	b.ne	LBB60_30
	b	LBB60_26
LBB60_26:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #11]
	subs	w8, w8, #1
	b.gt	LBB60_30
	b	LBB60_27
LBB60_27:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #11]
	ldur	x9, [x29, #-32]
	ldrb	w9, [x9, #11]
	subs	w8, w8, w9
	b.ne	LBB60_30
	b	LBB60_28
LBB60_28:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB60_30
	b	LBB60_29
LBB60_29:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	add	x0, x8, #15
	ldr	x8, [sp, #32]
	ldrh	w1, [x8, #12]
	ldr	x8, [sp, #32]
	ldrb	w2, [x8, #14]
	bl	_nvm_callback_shape_valid
	tbnz	w0, #0, LBB60_31
	b	LBB60_30
LBB60_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_31:                               ;   in Loop: Header=BB60_22 Depth=2
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #32]
	ldr	w1, [x8, #4]
	bl	_nvm_get_string
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbz	x8, LBB60_34
	b	LBB60_32
LBB60_32:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbz	w8, LBB60_34
	b	LBB60_33
LBB60_33:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x0, [sp, #24]
	bl	_strlen
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #32]
	ldr	w1, [x8, #4]
	bl	_nvm_get_string_len
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	subs	x8, x0, w8, uxtw
	b.eq	LBB60_35
	b	LBB60_34
LBB60_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_35:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ls	LBB60_38
	b	LBB60_36
LBB60_36:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #416]
	ldr	w10, [sp, #40]
	subs	w10, w10, #1
	mov	w10, w10
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.gt	LBB60_38
	b	LBB60_37
LBB60_37:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_38:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #8]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB60_45
	b	LBB60_39
LBB60_39:                               ;   in Loop: Header=BB60_22 Depth=2
	ldur	w8, [x29, #-44]
	cbnz	w8, LBB60_43
	b	LBB60_40
LBB60_40:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB60_43
	b	LBB60_41
LBB60_41:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #12]
	cbnz	w8, LBB60_43
	b	LBB60_42
LBB60_42:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #14]
	cbz	w8, LBB60_44
	b	LBB60_43
LBB60_43:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_44:                               ;   in Loop: Header=BB60_22 Depth=2
	b	LBB60_49
LBB60_45:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #8]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB60_47
	b	LBB60_46
LBB60_46:                               ;   in Loop: Header=BB60_22 Depth=2
	ldur	w8, [x29, #-44]
	ldr	x9, [sp, #32]
	ldrh	w10, [x9, #8]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbnz	w8, LBB60_48
	b	LBB60_47
LBB60_47:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_48:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w9, [x8, #8]
	mov	w8, #1                          ; =0x1
	lsl	w9, w8, w9
	ldr	w8, [sp, #48]
	orr	w8, w8, w9
	str	w8, [sp, #48]
	b	LBB60_49
LBB60_49:                               ;   in Loop: Header=BB60_22 Depth=2
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB60_22
LBB60_50:                               ;   in Loop: Header=BB60_5 Depth=1
	ldr	w8, [sp, #48]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.ne	LBB60_53
	b	LBB60_51
LBB60_51:                               ;   in Loop: Header=BB60_5 Depth=1
	ldr	w8, [sp, #40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #424]
	subs	w8, w8, w9
	b.hs	LBB60_54
	b	LBB60_52
LBB60_52:                               ;   in Loop: Header=BB60_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #416]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #5
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB60_54
	b	LBB60_53
LBB60_53:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_54:                               ;   in Loop: Header=BB60_5 Depth=1
	ldr	w8, [sp, #40]
	stur	w8, [x29, #-20]
	b	LBB60_5
LBB60_55:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_56
LBB60_56:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_find_function              ; -- Begin function nvm_find_function
	.p2align	2
_nvm_find_function:                     ; @nvm_find_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB61_2
	b	LBB61_1
LBB61_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB61_3
	b	LBB61_2
LBB61_2:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB61_11
LBB61_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	str	w8, [sp, #20]
	b	LBB61_4
LBB61_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	subs	w8, w8, #0
	b.ls	LBB61_10
	b	LBB61_5
LBB61_5:                                ;   in Loop: Header=BB61_4 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	ldr	w9, [sp, #20]
	subs	w9, w9, #1
	mov	w10, #24                        ; =0x18
	umull	x9, w9, w10
	ldr	w1, [x8, x9]
	bl	_nvm_get_string
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB61_8
	b	LBB61_6
LBB61_6:                                ;   in Loop: Header=BB61_4 Depth=1
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #24]
	bl	_strcmp
	cbnz	w0, LBB61_8
	b	LBB61_7
LBB61_7:
	ldr	w8, [sp, #20]
	subs	w8, w8, #1
	stur	w8, [x29, #-4]
	b	LBB61_11
LBB61_8:                                ;   in Loop: Header=BB61_4 Depth=1
	b	LBB61_9
LBB61_9:                                ;   in Loop: Header=BB61_4 Depth=1
	ldr	w8, [sp, #20]
	subs	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB61_4
LBB61_10:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB61_11
LBB61_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_append_code                ; -- Begin function nvm_append_code
	.p2align	2
_nvm_append_code:                       ; @nvm_append_code
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	w2, [sp, #20]
	ldr	w8, [sp, #20]
	cbnz	w8, LBB62_2
	b	LBB62_1
LBB62_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	stur	w8, [x29, #-4]
	b	LBB62_8
LBB62_2:
	b	LBB62_3
LBB62_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	ldr	w9, [sp, #20]
	add	w8, w8, w9
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #292]
	subs	w8, w8, w9
	b.ls	LBB62_7
	b	LBB62_4
LBB62_4:                                ;   in Loop: Header=BB62_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #292]
	lsl	w8, w8, #1
	str	w8, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #280]
	ldr	w8, [sp, #16]
	mov	x1, x8
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB62_6
	b	LBB62_5
LBB62_5:
	stur	wzr, [x29, #-4]
	b	LBB62_8
LBB62_6:                                ;   in Loop: Header=BB62_3 Depth=1
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #280]
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #292]
	b	LBB62_3
LBB62_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	str	w8, [sp, #4]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x1, [sp, #24]
	ldr	w8, [sp, #20]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	w10, [sp, #20]
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #288]
	add	w8, w8, w10
	str	w8, [x9, #288]
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB62_8
LBB62_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_debug_entry            ; -- Begin function nvm_add_debug_entry
	.p2align	2
_nvm_add_debug_entry:                   ; @nvm_add_debug_entry
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	w2, [sp, #24]
	str	w3, [sp, #20]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB63_2
	b	LBB63_1
LBB63_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #384]
	adds	w8, w8, #1
	b.ne	LBB63_3
	b	LBB63_2
LBB63_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_15
LBB63_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #384]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #388]
	subs	w8, w8, w9
	b.lo	LBB63_14
	b	LBB63_4
LBB63_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #388]
	cbz	w8, LBB63_6
	b	LBB63_5
LBB63_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #388]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB63_7
LBB63_6:
	mov	w8, #16                         ; =0x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB63_7
LBB63_7:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #16]
	ldr	w8, [sp, #16]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB63_9
	b	LBB63_8
LBB63_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_15
LBB63_9:
	ldr	w8, [sp, #16]
	lsl	w8, w8, #1
	str	w8, [sp, #16]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	adds	x8, x8, #1
	b.ls	LBB63_11
	b	LBB63_10
LBB63_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_15
LBB63_11:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #376]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB63_13
	b	LBB63_12
LBB63_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_15
LBB63_13:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #376]
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #388]
	b	LBB63_14
LBB63_14:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #376]
	ldur	x10, [x29, #-16]
	ldr	w10, [x10, #384]
	mov	x11, x10
	mov	x10, #12                        ; =0xc
	mov	x12, x10
                                        ; kill: def $w11 killed $w11 killed $x11
	umull	x11, w11, w12
	str	w8, [x9, x11]
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x12, [x9, #376]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #384]
                                        ; kill: def $x9 killed $w9
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	str	w8, [x9, #4]
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	ldr	x11, [x9, #376]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #384]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #8]
	ldur	x10, [x29, #-16]
	ldr	w8, [x10, #384]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #384]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB63_15
LBB63_15:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_strip_debug_info           ; -- Begin function nvm_strip_debug_info
	.p2align	2
_nvm_strip_debug_info:                  ; @nvm_strip_debug_info
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB64_2
	b	LBB64_1
LBB64_1:
	b	LBB64_9
LBB64_2:
	str	wzr, [sp, #4]
	str	wzr, [sp]
	b	LBB64_3
LBB64_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB64_8
	b	LBB64_4
LBB64_4:                                ;   in Loop: Header=BB64_3 Depth=1
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #360]
	ldr	w9, [sp]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldr	w1, [x8, x9]
	bl	_nvm_metadata_source_key
	tbnz	w0, #0, LBB64_6
	b	LBB64_5
LBB64_5:                                ;   in Loop: Header=BB64_3 Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [x8, #360]
	ldr	w8, [sp, #4]
	mov	x10, x8
	mov	x8, x10
	add	w8, w8, #1
	str	w8, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #360]
	ldr	w11, [sp]
                                        ; kill: def $x11 killed $w11
	ldr	x8, [x8, x11, lsl #3]
	str	x8, [x9, x10, lsl #3]
	b	LBB64_6
LBB64_6:                                ;   in Loop: Header=BB64_3 Depth=1
	b	LBB64_7
LBB64_7:                                ;   in Loop: Header=BB64_3 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB64_3
LBB64_8:
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	str	w8, [x9, #368]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #384]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #392]
	ldr	x9, [sp, #8]
	ldr	w8, [x9, #8]
	and	w8, w8, #0xfffffffb
	str	w8, [x9, #8]
	b	LBB64_9
LBB64_9:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_import                 ; -- Begin function nvm_add_import
	.p2align	2
_nvm_add_import:                        ; @nvm_add_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	sturh	w3, [x29, #-26]
	sturb	w4, [x29, #-27]
	str	x5, [sp, #40]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB65_2
	b	LBB65_1
LBB65_1:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB65_21
LBB65_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #436]
	subs	w8, w8, w9
	b.lo	LBB65_14
	b	LBB65_3
LBB65_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #436]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB65_5
	b	LBB65_4
LBB65_4:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB65_21
LBB65_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #436]
	cbz	w8, LBB65_7
	b	LBB65_6
LBB65_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #436]
	lsl	w8, w8, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB65_8
LBB65_7:
	mov	w8, #16                         ; =0x10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB65_8
LBB65_8:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #36]
	ldr	w8, [sp, #36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x0, w8, w9
	bl	_malloc
	str	x0, [sp, #24]
	ldr	w8, [sp, #36]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #3
	bl	_malloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB65_10
	b	LBB65_9
LBB65_9:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB65_11
	b	LBB65_10
LBB65_10:
	ldr	x0, [sp, #24]
	bl	_free
	ldr	x0, [sp, #16]
	bl	_free
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB65_21
LBB65_11:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
	cbz	w8, LBB65_13
	b	LBB65_12
LBB65_12:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #400]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp]                        ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #408]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	___memcpy_chk
	b	LBB65_13
LBB65_13:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #400]
	bl	_free
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #408]
	bl	_free
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #400]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #408]
	ldr	w8, [sp, #36]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #436]
	b	LBB65_14
LBB65_14:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
	str	w8, [sp, #12]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	x10, [x9, #400]
	ldr	w9, [sp, #12]
	mov	x11, x9
	mov	x9, #12                         ; =0xc
	mov	x12, x9
                                        ; kill: def $w11 killed $w11 killed $x11
	umull	x11, w11, w12
	str	w8, [x10, x11]
	ldur	w8, [x29, #-24]
	ldur	x10, [x29, #-16]
	ldr	x12, [x10, #400]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	str	w8, [x10, #4]
	ldurh	w8, [x29, #-26]
	ldur	x10, [x29, #-16]
	ldr	x12, [x10, #400]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	strh	w8, [x10, #8]
	ldurb	w8, [x29, #-27]
	ldur	x10, [x29, #-16]
	ldr	x12, [x10, #400]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	strb	w8, [x10, #10]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	strb	wzr, [x8, #11]
	ldurh	w8, [x29, #-26]
	subs	w8, w8, #0
	b.le	LBB65_19
	b	LBB65_15
LBB65_15:
	ldr	x8, [sp, #40]
	cbz	x8, LBB65_19
	b	LBB65_16
LBB65_16:
	ldurh	w8, [x29, #-26]
	mov	x0, x8
	bl	_malloc
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	str	x0, [x8, x9, lsl #3]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB65_18
	b	LBB65_17
LBB65_17:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB65_21
LBB65_18:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x1, [sp, #40]
	ldurh	w8, [x29, #-26]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB65_20
LBB65_19:
	ldur	x8, [x29, #-16]
	ldr	x9, [x8, #408]
	ldr	w8, [sp, #12]
	mov	x10, x8
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	b	LBB65_20
LBB65_20:
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #432]
	add	w8, w8, #1
	str	w8, [x9, #432]
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB65_21
LBB65_21:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_validate_header            ; -- Begin function nvm_validate_header
	.p2align	2
_nvm_validate_header:                   ; @nvm_validate_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	ldrb	w8, [x8]
	subs	w8, w8, #78
	b.ne	LBB66_4
	b	LBB66_1
LBB66_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #1]
	subs	w8, w8, #86
	b.ne	LBB66_4
	b	LBB66_2
LBB66_2:
	ldr	x8, [sp]
	ldrb	w8, [x8, #2]
	subs	w8, w8, #77
	b.ne	LBB66_4
	b	LBB66_3
LBB66_3:
	ldr	x8, [sp]
	ldrb	w8, [x8, #3]
	subs	w8, w8, #1
	b.eq	LBB66_5
	b	LBB66_4
LBB66_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB66_10
LBB66_5:
	ldr	x8, [sp]
	ldr	w8, [x8, #4]
	subs	w8, w8, #2
	b.eq	LBB66_7
	b	LBB66_6
LBB66_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB66_10
LBB66_7:
	ldr	x8, [sp]
	ldr	w8, [x8, #16]
	subs	w8, w8, #16
	b.ls	LBB66_9
	b	LBB66_8
LBB66_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB66_10
LBB66_9:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB66_10
LBB66_10:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_module_ref             ; -- Begin function nvm_add_module_ref
	.p2align	2
_nvm_add_module_ref:                    ; @nvm_add_module_ref
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB67_2
	b	LBB67_1
LBB67_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB67_3
	b	LBB67_2
LBB67_2:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB67_8
LBB67_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #448]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #452]
	subs	w8, w8, w9
	b.lo	LBB67_7
	b	LBB67_4
LBB67_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #452]
	lsl	w8, w8, #1
	str	w8, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #440]
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #2
	bl	_realloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB67_6
	b	LBB67_5
LBB67_5:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB67_8
LBB67_6:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #440]
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #452]
	b	LBB67_7
LBB67_7:
	ldur	x10, [x29, #-16]
	ldr	w8, [x10, #448]
	add	w9, w8, #1
	str	w9, [x10, #448]
	str	w8, [sp, #12]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #440]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB67_8
LBB67_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_instructions_present  ; -- Begin function nvm_file_instructions_present
	.p2align	2
_nvm_file_instructions_present:         ; @nvm_file_instructions_present
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB68_3
	b	LBB68_1
LBB68_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB68_3
	b	LBB68_2
LBB68_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #280]
	cbnz	x8, LBB68_4
	b	LBB68_3
LBB68_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB68_14
LBB68_4:
	str	wzr, [sp, #12]
	b	LBB68_5
LBB68_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB68_13
	b	LBB68_6
LBB68_6:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB68_8
	b	LBB68_7
LBB68_7:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #288]
	ldr	x10, [sp]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB68_9
	b	LBB68_8
LBB68_8:                                ;   in Loop: Header=BB68_5 Depth=1
	b	LBB68_12
LBB68_9:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #280]
	ldr	x9, [sp]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldr	w8, [x8, #12]
	mov	x1, x8
	bl	_isa_code_has_file_instructions
	tbz	w0, #0, LBB68_11
	b	LBB68_10
LBB68_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB68_14
LBB68_11:                               ;   in Loop: Header=BB68_5 Depth=1
	b	LBB68_12
LBB68_12:                               ;   in Loop: Header=BB68_5 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB68_5
LBB68_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB68_14
LBB68_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_serialize                  ; -- Begin function nvm_serialize
	.p2align	2
_nvm_serialize:                         ; @nvm_serialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-16]
	bl	_nvm_file_instructions_present
	tbnz	w0, #0, LBB69_8
	b	LBB69_1
LBB69_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #328]
	cbnz	x8, LBB69_8
	b	LBB69_2
LBB69_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #336]
	cbnz	w8, LBB69_8
	b	LBB69_3
LBB69_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #368]
	cbnz	w8, LBB69_8
	b	LBB69_4
LBB69_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #424]
	cbnz	w8, LBB69_8
	b	LBB69_5
LBB69_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB69_8
	b	LBB69_6
LBB69_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB69_8
	b	LBB69_7
LBB69_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbz	w8, LBB69_11
	b	LBB69_8
LBB69_8:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB69_10
	b	LBB69_9
LBB69_9:
	ldur	x8, [x29, #-24]
	str	wzr, [x8]
	b	LBB69_10
LBB69_10:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB69_68
LBB69_11:
	stur	wzr, [x29, #-28]
	b	LBB69_12
LBB69_12:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB69_19
	b	LBB69_13
LBB69_13:                               ;   in Loop: Header=BB69_12 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #11]
	cbz	w8, LBB69_17
	b	LBB69_14
LBB69_14:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB69_16
	b	LBB69_15
LBB69_15:
	ldur	x8, [x29, #-24]
	str	wzr, [x8]
	b	LBB69_16
LBB69_16:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB69_68
LBB69_17:                               ;   in Loop: Header=BB69_12 Depth=1
	b	LBB69_18
LBB69_18:                               ;   in Loop: Header=BB69_12 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB69_12
LBB69_19:
	stur	wzr, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #248]
	subs	w8, w8, #0
	cset	w8, hi
	sturb	w8, [x29, #-33]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	subs	w8, w8, #0
	cset	w8, hi
	sturb	w8, [x29, #-34]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	subs	w8, w8, #0
	cset	w8, hi
	sturb	w8, [x29, #-35]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #384]
	subs	w8, w8, #0
	cset	w8, hi
	sturb	w8, [x29, #-36]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
	subs	w8, w8, #0
	cset	w8, hi
	sturb	w8, [x29, #-37]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #448]
	subs	w8, w8, #0
	cset	w8, hi
	sturb	w8, [x29, #-38]
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB69_21
	b	LBB69_20
LBB69_20:
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB69_21
LBB69_21:
	ldurb	w8, [x29, #-34]
	tbz	w8, #0, LBB69_23
	b	LBB69_22
LBB69_22:
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB69_23
LBB69_23:
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB69_25
	b	LBB69_24
LBB69_24:
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB69_25
LBB69_25:
	ldurb	w8, [x29, #-36]
	tbz	w8, #0, LBB69_27
	b	LBB69_26
LBB69_26:
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB69_27
LBB69_27:
	ldurb	w8, [x29, #-37]
	tbz	w8, #0, LBB69_29
	b	LBB69_28
LBB69_28:
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB69_29
LBB69_29:
	ldurb	w8, [x29, #-38]
	tbz	w8, #0, LBB69_31
	b	LBB69_30
LBB69_30:
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB69_31
LBB69_31:
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB69_33
	b	LBB69_32
LBB69_32:
	ldur	x0, [x29, #-16]
	bl	_string_pool_size
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB69_34
LBB69_33:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB69_34
LBB69_34:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-44]
	ldurb	w8, [x29, #-34]
	tbz	w8, #0, LBB69_36
	b	LBB69_35
LBB69_35:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB69_37
LBB69_36:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB69_37
LBB69_37:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-48]
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB69_39
	b	LBB69_38
LBB69_38:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	mov	w9, #20                         ; =0x14
	mul	w8, w8, w9
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB69_40
LBB69_39:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB69_40
LBB69_40:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-52]
	ldurb	w8, [x29, #-36]
	tbz	w8, #0, LBB69_42
	b	LBB69_41
LBB69_41:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #384]
	mov	w9, #12                         ; =0xc
	mul	w8, w8, w9
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB69_43
LBB69_42:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB69_43
LBB69_43:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-56]
	ldurb	w8, [x29, #-37]
	tbz	w8, #0, LBB69_45
	b	LBB69_44
LBB69_44:
	ldur	x0, [x29, #-16]
	bl	_import_section_size
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB69_46
LBB69_45:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB69_46
LBB69_46:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-60]
	ldurb	w8, [x29, #-38]
	tbz	w8, #0, LBB69_48
	b	LBB69_47
LBB69_47:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #448]
	lsl	w8, w8, #2
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB69_49
LBB69_48:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB69_49
LBB69_49:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-64]
	ldur	w8, [x29, #-32]
	mov	w9, #12                         ; =0xc
	mul	w8, w8, w9
	stur	w8, [x29, #-68]
	ldur	w8, [x29, #-44]
	ldur	w9, [x29, #-48]
	add	w8, w8, w9
	ldur	w9, [x29, #-52]
	add	w8, w8, w9
	ldur	w9, [x29, #-56]
	add	w8, w8, w9
	ldur	w9, [x29, #-60]
	add	w8, w8, w9
	ldur	w9, [x29, #-64]
	add	w8, w8, w9
	str	w8, [sp, #72]
	ldur	w8, [x29, #-68]
	add	w8, w8, #32
	ldr	w9, [sp, #72]
	add	w8, w8, w9
	str	w8, [sp, #68]
	ldr	w8, [sp, #68]
	mov	x1, x8
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbnz	x8, LBB69_51
	b	LBB69_50
LBB69_50:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB69_68
LBB69_51:
	ldur	w9, [x29, #-68]
	mov	w8, #32                         ; =0x20
	add	w9, w9, #32
	str	w9, [sp, #52]
	str	w8, [sp, #48]
	ldr	w8, [sp, #52]
	str	w8, [sp, #44]
	str	wzr, [sp, #40]
	str	wzr, [sp, #36]
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB69_53
	b	LBB69_52
LBB69_52:
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	mov	w1, #2                          ; =0x2
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w1, [sp, #44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w1, [x29, #-44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	w8, [sp, #44]
	str	w8, [sp, #40]
	ldur	w8, [x29, #-44]
	str	w8, [sp, #36]
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_serialize_string_pool
	ldur	w9, [x29, #-44]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB69_53
LBB69_53:
	ldurb	w8, [x29, #-34]
	tbz	w8, #0, LBB69_55
	b	LBB69_54
LBB69_54:
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	mov	w1, #1                          ; =0x1
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w1, [sp, #44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w1, [x29, #-48]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #280]
	ldur	w8, [x29, #-48]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	w9, [x29, #-48]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB69_55
LBB69_55:
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB69_57
	b	LBB69_56
LBB69_56:
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	mov	w1, #3                          ; =0x3
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w1, [sp, #44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w1, [x29, #-52]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_serialize_functions
	ldur	w9, [x29, #-52]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB69_57
LBB69_57:
	ldurb	w8, [x29, #-36]
	tbz	w8, #0, LBB69_59
	b	LBB69_58
LBB69_58:
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	mov	w1, #9                          ; =0x9
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w1, [sp, #44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w1, [x29, #-56]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_serialize_debug
	ldur	w9, [x29, #-56]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB69_59
LBB69_59:
	ldurb	w8, [x29, #-37]
	tbz	w8, #0, LBB69_61
	b	LBB69_60
LBB69_60:
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	mov	w1, #8                          ; =0x8
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w1, [sp, #44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w1, [x29, #-60]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_serialize_imports
	ldur	w9, [x29, #-60]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB69_61
LBB69_61:
	ldurb	w8, [x29, #-38]
	tbz	w8, #0, LBB69_67
	b	LBB69_62
LBB69_62:
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	mov	w1, #11                         ; =0xb
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w1, [sp, #44]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w1, [x29, #-64]
	bl	_le_write_u32
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	str	wzr, [sp, #32]
	b	LBB69_63
LBB69_63:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #448]
	subs	w8, w8, w9
	b.hs	LBB69_66
	b	LBB69_64
LBB69_64:                               ;   in Loop: Header=BB69_63 Depth=1
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #440]
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	bl	_le_write_u32
	ldr	w8, [sp, #44]
	add	w8, w8, #4
	str	w8, [sp, #44]
	b	LBB69_65
LBB69_65:                               ;   in Loop: Header=BB69_63 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB69_63
LBB69_66:
	b	LBB69_67
LBB69_67:
	ldr	x9, [sp, #56]
	mov	w8, #78                         ; =0x4e
	strb	w8, [x9]
	ldr	x9, [sp, #56]
	mov	w8, #86                         ; =0x56
	strb	w8, [x9, #1]
	ldr	x9, [sp, #56]
	mov	w8, #77                         ; =0x4d
	strb	w8, [x9, #2]
	ldr	x9, [sp, #56]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #3]
	ldr	x8, [sp, #56]
	add	x0, x8, #4
	mov	w1, #2                          ; =0x2
	bl	_le_write_u32
	ldr	x8, [sp, #56]
	add	x0, x8, #8
	ldur	x8, [x29, #-16]
	ldr	w1, [x8, #8]
	bl	_le_write_u32
	ldr	x8, [sp, #56]
	add	x0, x8, #12
	ldur	x8, [x29, #-16]
	ldr	w1, [x8, #12]
	bl	_le_write_u32
	ldr	x8, [sp, #56]
	add	x0, x8, #16
	ldur	w1, [x29, #-32]
	bl	_le_write_u32
	ldr	x8, [sp, #56]
	add	x0, x8, #20
	ldr	w1, [sp, #40]
	bl	_le_write_u32
	ldr	x8, [sp, #56]
	add	x0, x8, #24
	ldr	w1, [sp, #36]
	bl	_le_write_u32
	ldr	x8, [sp, #56]
	add	x0, x8, #32
	ldr	w8, [sp, #68]
	subs	w1, w8, #32
	bl	_nvm_crc32
	str	w0, [sp, #28]
	ldr	x8, [sp, #56]
	add	x0, x8, #28
	ldr	w1, [sp, #28]
	bl	_le_write_u32
	ldr	w8, [sp, #68]
	ldur	x9, [x29, #-24]
	str	w8, [x9]
	ldr	x8, [sp, #56]
	stur	x8, [x29, #-8]
	b	LBB69_68
LBB69_68:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function string_pool_size
_string_pool_size:                      ; @string_pool_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	wzr, [sp, #4]
	str	wzr, [sp]
	b	LBB70_1
LBB70_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB70_4
	b	LBB70_2
LBB70_2:                                ;   in Loop: Header=BB70_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #240]
	ldr	w9, [sp]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	add	w9, w8, #4
	ldr	w8, [sp, #4]
	add	w8, w8, w9
	str	w8, [sp, #4]
	b	LBB70_3
LBB70_3:                                ;   in Loop: Header=BB70_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB70_1
LBB70_4:
	ldr	w0, [sp, #4]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function import_section_size
_import_section_size:                   ; @import_section_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	wzr, [sp, #4]
	str	wzr, [sp]
	b	LBB71_1
LBB71_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB71_4
	b	LBB71_2
LBB71_2:                                ;   in Loop: Header=BB71_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x10, [x8, #400]
	ldr	w8, [sp]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	add	w9, w8, #11
	ldr	w8, [sp, #4]
	add	w8, w8, w9
	str	w8, [sp, #4]
	b	LBB71_3
LBB71_3:                                ;   in Loop: Header=BB71_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB71_1
LBB71_4:
	ldr	w0, [sp, #4]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_string_pool
_serialize_string_pool:                 ; @serialize_string_pool
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB72_1
LBB72_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB72_4
	b	LBB72_2
LBB72_2:                                ;   in Loop: Header=BB72_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w9, [x8, x9, lsl #2]
	ldr	w8, [sp, #12]
	add	w8, w8, w9
	str	w8, [sp, #12]
	b	LBB72_3
LBB72_3:                                ;   in Loop: Header=BB72_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB72_1
LBB72_4:
	ldr	w0, [sp, #12]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_functions
_serialize_functions:                   ; @serialize_functions
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB73_1
LBB73_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB73_4
	b	LBB73_2
LBB73_2:                                ;   in Loop: Header=BB73_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldr	w1, [x8]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldrh	w1, [x8, #4]
	bl	_le_write_u16
	ldr	w8, [sp, #12]
	add	w8, w8, #2
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldr	w1, [x8, #8]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldr	w1, [x8, #12]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldrh	w1, [x8, #16]
	bl	_le_write_u16
	ldr	w8, [sp, #12]
	add	w8, w8, #2
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldrh	w1, [x8, #18]
	bl	_le_write_u16
	ldr	w8, [sp, #12]
	add	w8, w8, #2
	str	w8, [sp, #12]
	ldr	x8, [sp]
	ldrb	w8, [x8, #20]
	ldr	x9, [sp, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #12]
	add	x9, x9, x10
	strb	w8, [x9]
	ldr	x8, [sp]
	ldrb	w8, [x8, #21]
	ldr	x9, [sp, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #12]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB73_3
LBB73_3:                                ;   in Loop: Header=BB73_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB73_1
LBB73_4:
	ldr	w0, [sp, #12]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_debug
_serialize_debug:                       ; @serialize_debug
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB74_1
LBB74_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #384]
	subs	w8, w8, w9
	b.hs	LBB74_4
	b	LBB74_2
LBB74_2:                                ;   in Loop: Header=BB74_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #376]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
	str	x10, [sp]                       ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w1, [x8, x9]
	bl	_le_write_u32
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x0, x8, x10
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #376]
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w1, [x8, #4]
	bl	_le_write_u32
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x0, x8, x10
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #376]
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w1, [x8, #8]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	b	LBB74_3
LBB74_3:                                ;   in Loop: Header=BB74_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB74_1
LBB74_4:
	ldr	w0, [sp, #12]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_imports
_serialize_imports:                     ; @serialize_imports
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB75_1
LBB75_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB75_6
	b	LBB75_2
LBB75_2:                                ;   in Loop: Header=BB75_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldr	w1, [x8]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldr	w1, [x8, #4]
	bl	_le_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp]
	ldrh	w1, [x8, #8]
	bl	_le_write_u16
	ldr	w8, [sp, #12]
	add	w8, w8, #2
	str	w8, [sp, #12]
	ldr	x8, [sp]
	ldrb	w8, [x8, #10]
	ldr	x9, [sp, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #12]
	add	x9, x9, x10
	strb	w8, [x9]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB75_4
	b	LBB75_3
LBB75_3:                                ;   in Loop: Header=BB75_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	ldr	x8, [sp]
	ldrh	w8, [x8, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB75_4
LBB75_4:                                ;   in Loop: Header=BB75_1 Depth=1
	ldr	x8, [sp]
	ldrh	w9, [x8, #8]
	ldr	w8, [sp, #12]
	add	w8, w8, w9
	str	w8, [sp, #12]
	b	LBB75_5
LBB75_5:                                ;   in Loop: Header=BB75_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB75_1
LBB75_6:
	ldr	w0, [sp, #12]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_deserialize                ; -- Begin function nvm_deserialize
	.p2align	2
_nvm_deserialize:                       ; @nvm_deserialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #68
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	ldur	w8, [x29, #-36]
	subs	w8, w8, #32
	b.hs	LBB76_2
	b	LBB76_1
LBB76_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_2:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	sub	x9, x29, #68
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	sturb	w8, [x29, #-68]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #1]
	sturb	w8, [x29, #-67]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #2]
	sturb	w8, [x29, #-66]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #3]
	sturb	w8, [x29, #-65]
	ldur	x8, [x29, #-32]
	add	x0, x8, #4
	bl	_le_read_u32
	stur	w0, [x29, #-64]
	ldur	x8, [x29, #-32]
	add	x0, x8, #8
	bl	_le_read_u32
	stur	w0, [x29, #-60]
	ldur	x8, [x29, #-32]
	add	x0, x8, #12
	bl	_le_read_u32
	stur	w0, [x29, #-56]
	ldur	x8, [x29, #-32]
	add	x0, x8, #16
	bl	_le_read_u32
	stur	w0, [x29, #-52]
	ldur	x8, [x29, #-32]
	add	x0, x8, #20
	bl	_le_read_u32
	stur	w0, [x29, #-48]
	ldur	x8, [x29, #-32]
	add	x0, x8, #24
	bl	_le_read_u32
	stur	w0, [x29, #-44]
	ldur	x8, [x29, #-32]
	add	x0, x8, #28
	bl	_le_read_u32
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	stur	w8, [x29, #-40]
	bl	_nvm_validate_header
	tbnz	w0, #0, LBB76_4
	b	LBB76_3
LBB76_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_4:
	ldur	x8, [x29, #-32]
	add	x0, x8, #32
	ldur	w8, [x29, #-36]
	subs	w1, w8, #32
	bl	_nvm_crc32
	stur	w0, [x29, #-72]
	ldur	w8, [x29, #-72]
	ldur	w9, [x29, #-40]
	subs	w8, w8, w9
	b.eq	LBB76_6
	b	LBB76_5
LBB76_5:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_6:
	ldur	w8, [x29, #-52]
	mov	w9, #12                         ; =0xc
	mul	w8, w8, w9
	add	w8, w8, #32
	stur	w8, [x29, #-76]
	ldur	w8, [x29, #-76]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ls	LBB76_8
	b	LBB76_7
LBB76_7:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_8:
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-36]
	ldur	w2, [x29, #-52]
	ldur	w3, [x29, #-76]
	bl	_nvm_validate_section_directory
	tbnz	w0, #0, LBB76_10
	b	LBB76_9
LBB76_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_10:
	bl	_nvm_module_new
	stur	x0, [x29, #-88]
	ldur	x8, [x29, #-88]
	cbnz	x8, LBB76_12
	b	LBB76_11
LBB76_11:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_12:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-88]
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	q0, [x9, #16]
	str	q0, [x8, #16]
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-88]
	str	w8, [x9, #224]
	stur	wzr, [x29, #-92]
	b	LBB76_13
LBB76_13:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB76_59 Depth 2
                                        ;     Child Loop BB76_37 Depth 2
                                        ;     Child Loop BB76_43 Depth 2
                                        ;     Child Loop BB76_31 Depth 2
                                        ;     Child Loop BB76_24 Depth 2
	ldur	w8, [x29, #-92]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB76_68
	b	LBB76_14
LBB76_14:                               ;   in Loop: Header=BB76_13 Depth=1
	ldur	w8, [x29, #-92]
	mov	w9, #12                         ; =0xc
	mul	w8, w8, w9
	add	w8, w8, #32
	stur	w8, [x29, #-96]
	ldur	x8, [x29, #-32]
	ldur	w9, [x29, #-96]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	stur	w0, [x29, #-100]
	ldur	x8, [x29, #-32]
	ldur	w9, [x29, #-96]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x0, x8, #4
	bl	_le_read_u32
	stur	w0, [x29, #-104]
	ldur	x8, [x29, #-32]
	ldur	w9, [x29, #-96]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x0, x8, #8
	bl	_le_read_u32
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-104]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.hi	LBB76_16
	b	LBB76_15
LBB76_15:                               ;   in Loop: Header=BB76_13 Depth=1
	ldur	w8, [x29, #-108]
	ldur	w9, [x29, #-36]
	ldur	w10, [x29, #-104]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB76_17
	b	LBB76_16
LBB76_16:
	ldur	x0, [x29, #-88]
	bl	_nvm_module_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_17:                               ;   in Loop: Header=BB76_13 Depth=1
	ldur	w8, [x29, #-100]
	ldur	x9, [x29, #-88]
	add	x9, x9, #32
	ldur	w10, [x29, #-92]
	mov	x11, x10
	mov	x10, #12                        ; =0xc
	mov	x12, x10
                                        ; kill: def $w11 killed $w11 killed $x11
	umull	x11, w11, w12
	str	w8, [x9, x11]
	ldur	w8, [x29, #-104]
	ldur	x9, [x29, #-88]
	add	x12, x9, #32
	ldur	w9, [x29, #-92]
                                        ; kill: def $x9 killed $w9
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	str	w8, [x9, #4]
	ldur	w8, [x29, #-108]
	ldur	x9, [x29, #-88]
	add	x11, x9, #32
	ldur	w9, [x29, #-92]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #8]
	ldur	x8, [x29, #-32]
	ldur	w9, [x29, #-104]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	stur	x8, [x29, #-120]
	ldur	w8, [x29, #-100]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB76_29
	b	LBB76_18
LBB76_18:                               ;   in Loop: Header=BB76_13 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB76_23
	b	LBB76_19
LBB76_19:                               ;   in Loop: Header=BB76_13 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB76_30
	b	LBB76_20
LBB76_20:                               ;   in Loop: Header=BB76_13 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB76_42
	b	LBB76_21
LBB76_21:                               ;   in Loop: Header=BB76_13 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #9
	b.eq	LBB76_36
	b	LBB76_22
LBB76_22:                               ;   in Loop: Header=BB76_13 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #11
	b.eq	LBB76_58
	b	LBB76_65
LBB76_23:                               ;   in Loop: Header=BB76_13 Depth=1
	stur	wzr, [x29, #-124]
	b	LBB76_24
LBB76_24:                               ;   Parent Loop BB76_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-124]
	add	w8, w8, #4
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hi	LBB76_28
	b	LBB76_25
LBB76_25:                               ;   in Loop: Header=BB76_24 Depth=2
	ldur	x8, [x29, #-120]
	ldur	w9, [x29, #-124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #128]
	ldur	w8, [x29, #-124]
	add	w8, w8, #4
	stur	w8, [x29, #-124]
	ldr	w8, [sp, #128]
	ldur	w9, [x29, #-108]
	ldur	w10, [x29, #-124]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB76_27
	b	LBB76_26
LBB76_26:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_28
LBB76_27:                               ;   in Loop: Header=BB76_24 Depth=2
	ldur	x0, [x29, #-88]
	ldur	x8, [x29, #-120]
	ldur	w9, [x29, #-124]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	ldr	w2, [sp, #128]
	bl	_nvm_add_string
	ldr	w9, [sp, #128]
	ldur	w8, [x29, #-124]
	add	w8, w8, w9
	stur	w8, [x29, #-124]
	b	LBB76_24
LBB76_28:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_66
LBB76_29:                               ;   in Loop: Header=BB76_13 Depth=1
	ldur	x0, [x29, #-88]
	ldur	x1, [x29, #-120]
	ldur	w2, [x29, #-108]
	bl	_nvm_append_code
	b	LBB76_66
LBB76_30:                               ;   in Loop: Header=BB76_13 Depth=1
	str	wzr, [sp, #124]
	b	LBB76_31
LBB76_31:                               ;   Parent Loop BB76_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #124]
	add	w8, w8, #20
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hi	LBB76_35
	b	LBB76_32
LBB76_32:                               ;   in Loop: Header=BB76_31 Depth=2
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	add	x8, sp, #100
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	w0, [sp, #100]
	ldr	w8, [sp, #124]
	add	w8, w8, #4
	str	w8, [sp, #124]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u16
	strh	w0, [sp, #104]
	ldr	w8, [sp, #124]
	add	w8, w8, #2
	str	w8, [sp, #124]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #108]
	ldr	w8, [sp, #124]
	add	w8, w8, #4
	str	w8, [sp, #124]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #112]
	ldr	w8, [sp, #124]
	add	w8, w8, #4
	str	w8, [sp, #124]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u16
	strh	w0, [sp, #116]
	ldr	w8, [sp, #124]
	add	w8, w8, #2
	str	w8, [sp, #124]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u16
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	strh	w0, [sp, #118]
	ldr	w8, [sp, #124]
	add	w8, w8, #2
	str	w8, [sp, #124]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #124]
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #120]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #124]
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #121]
	ldur	x0, [x29, #-88]
	bl	_nvm_add_function
	adds	w8, w0, #1
	b.ne	LBB76_34
	b	LBB76_33
LBB76_33:
	ldur	x0, [x29, #-88]
	bl	_nvm_module_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_34:                               ;   in Loop: Header=BB76_31 Depth=2
	b	LBB76_31
LBB76_35:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_66
LBB76_36:                               ;   in Loop: Header=BB76_13 Depth=1
	str	wzr, [sp, #96]
	b	LBB76_37
LBB76_37:                               ;   Parent Loop BB76_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #96]
	add	w8, w8, #12
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hi	LBB76_41
	b	LBB76_38
LBB76_38:                               ;   in Loop: Header=BB76_37 Depth=2
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #96]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #92]
	ldr	w8, [sp, #96]
	add	w8, w8, #4
	str	w8, [sp, #96]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #96]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #88]
	ldr	w8, [sp, #96]
	add	w8, w8, #4
	str	w8, [sp, #96]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #96]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #84]
	ldr	w8, [sp, #96]
	add	w8, w8, #4
	str	w8, [sp, #96]
	ldur	x0, [x29, #-88]
	ldr	w1, [sp, #92]
	ldr	w2, [sp, #88]
	ldr	w3, [sp, #84]
	bl	_nvm_add_debug_entry
	tbnz	w0, #0, LBB76_40
	b	LBB76_39
LBB76_39:
	ldur	x0, [x29, #-88]
	bl	_nvm_module_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_40:                               ;   in Loop: Header=BB76_37 Depth=2
	b	LBB76_37
LBB76_41:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_66
LBB76_42:                               ;   in Loop: Header=BB76_13 Depth=1
	str	wzr, [sp, #80]
	b	LBB76_43
LBB76_43:                               ;   Parent Loop BB76_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #80]
	add	w8, w8, #11
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hi	LBB76_57
	b	LBB76_44
LBB76_44:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #432]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #436]
	subs	w8, w8, w9
	b.lo	LBB76_49
	b	LBB76_45
LBB76_45:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #436]
	lsl	w8, w8, #1
	str	w8, [sp, #76]
	ldur	x8, [x29, #-88]
	ldr	x0, [x8, #400]
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	bl	_realloc
	str	x0, [sp, #64]
	ldur	x8, [x29, #-88]
	ldr	x0, [x8, #408]
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	bl	_realloc
	str	x0, [sp, #56]
	ldr	x8, [sp, #64]
	cbz	x8, LBB76_47
	b	LBB76_46
LBB76_46:                               ;   in Loop: Header=BB76_43 Depth=2
	ldr	x8, [sp, #56]
	cbnz	x8, LBB76_48
	b	LBB76_47
LBB76_47:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_57
LBB76_48:                               ;   in Loop: Header=BB76_43 Depth=2
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-88]
	str	x8, [x9, #400]
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-88]
	str	x8, [x9, #408]
	ldr	w8, [sp, #76]
	ldur	x9, [x29, #-88]
	str	w8, [x9, #436]
	b	LBB76_49
LBB76_49:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #432]
	str	w8, [sp, #52]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #400]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	str	w0, [x8, x9]
	ldr	w8, [sp, #80]
	add	w8, w8, #4
	str	w8, [sp, #80]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x8, [x29, #-88]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	w0, [x8, #4]
	ldr	w8, [sp, #80]
	add	w8, w8, #4
	str	w8, [sp, #80]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u16
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-88]
	ldr	x11, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	strh	w0, [x8, #8]
	ldr	w8, [sp, #80]
	add	w8, w8, #2
	str	w8, [sp, #80]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	mov	x11, x9
	add	w11, w11, #1
	str	w11, [sp, #80]
	add	x8, x8, x9
	ldrb	w8, [x8]
	ldur	x9, [x29, #-88]
	ldr	x12, [x9, #400]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	strb	w8, [x9, #10]
	ldur	x8, [x29, #-88]
	ldr	x11, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	strb	wzr, [x8, #11]
	ldr	w8, [sp, #80]
	ldur	x9, [x29, #-88]
	ldr	x11, [x9, #400]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	add	w8, w8, w9
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.ls	LBB76_51
	b	LBB76_50
LBB76_50:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_57
LBB76_51:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	subs	w8, w8, #0
	b.le	LBB76_55
	b	LBB76_52
LBB76_52:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	mov	x0, x8
	bl	_malloc
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	str	x0, [x8, x9, lsl #3]
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB76_54
	b	LBB76_53
LBB76_53:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	ldur	x8, [x29, #-88]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB76_54
LBB76_54:                               ;   in Loop: Header=BB76_43 Depth=2
	b	LBB76_56
LBB76_55:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	x9, [x8, #408]
	ldr	w8, [sp, #52]
	mov	x10, x8
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	b	LBB76_56
LBB76_56:                               ;   in Loop: Header=BB76_43 Depth=2
	ldur	x8, [x29, #-88]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w9, [x8, #8]
	ldr	w8, [sp, #80]
	add	w8, w8, w9
	str	w8, [sp, #80]
	ldur	x9, [x29, #-88]
	ldr	w8, [x9, #432]
	add	w8, w8, #1
	str	w8, [x9, #432]
	b	LBB76_43
LBB76_57:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_66
LBB76_58:                               ;   in Loop: Header=BB76_13 Depth=1
	str	wzr, [sp, #48]
	b	LBB76_59
LBB76_59:                               ;   Parent Loop BB76_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #48]
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hs	LBB76_64
	b	LBB76_60
LBB76_60:                               ;   in Loop: Header=BB76_59 Depth=2
	ldur	x8, [x29, #-88]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x8, [x29, #-120]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_nvm_add_module_ref
	adds	w8, w0, #1
	b.ne	LBB76_62
	b	LBB76_61
LBB76_61:
	ldur	x0, [x29, #-88]
	bl	_nvm_module_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB76_69
LBB76_62:                               ;   in Loop: Header=BB76_59 Depth=2
	b	LBB76_63
LBB76_63:                               ;   in Loop: Header=BB76_59 Depth=2
	ldr	w8, [sp, #48]
	add	w8, w8, #4
	str	w8, [sp, #48]
	b	LBB76_59
LBB76_64:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_66
LBB76_65:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_66
LBB76_66:                               ;   in Loop: Header=BB76_13 Depth=1
	b	LBB76_67
LBB76_67:                               ;   in Loop: Header=BB76_13 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB76_13
LBB76_68:
	ldur	x8, [x29, #-88]
	stur	x8, [x29, #-24]
	b	LBB76_69
LBB76_69:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function le_read_u32
_le_read_u32:                           ; @le_read_u32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w0, w8, w9, lsl #24
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_validate_section_directory
_nvm_validate_section_directory:        ; @nvm_validate_section_directory
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #336
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #88]
	str	w1, [sp, #84]
	str	w2, [sp, #80]
	str	w3, [sp, #76]
	str	wzr, [sp, #72]
	ldr	w8, [sp, #80]
	subs	w8, w8, #16
	b.ls	LBB78_2
	b	LBB78_1
LBB78_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_2:
	str	wzr, [sp, #68]
	b	LBB78_3
LBB78_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB78_14 Depth 2
	ldr	w8, [sp, #68]
	ldr	w9, [sp, #80]
	subs	w8, w8, w9
	b.hs	LBB78_22
	b	LBB78_4
LBB78_4:                                ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #68]
	mov	w9, #12                         ; =0xc
	mul	w8, w8, w9
	add	w8, w8, #32
	str	w8, [sp, #64]
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_le_read_u32
	str	w0, [sp, #60]
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x0, x8, #4
	bl	_le_read_u32
	str	w0, [sp, #56]
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x0, x8, #8
	bl	_le_read_u32
	str	w0, [sp, #52]
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #84]
	subs	w8, w8, w9
	b.hi	LBB78_6
	b	LBB78_5
LBB78_5:                                ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #84]
	ldr	w10, [sp, #56]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB78_7
	b	LBB78_6
LBB78_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_7:                                ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #76]
	subs	w8, w8, w9
	b.hs	LBB78_9
	b	LBB78_8
LBB78_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_9:                                ;   in Loop: Header=BB78_3 Depth=1
	ldr	w0, [sp, #60]
	bl	_nvm_section_record_size
	str	w0, [sp, #48]
	ldr	w8, [sp, #48]
	cbz	w8, LBB78_12
	b	LBB78_10
LBB78_10:                               ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #52]
	ldr	w10, [sp, #48]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbz	w8, LBB78_12
	b	LBB78_11
LBB78_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_12:                               ;   in Loop: Header=BB78_3 Depth=1
	ldr	w0, [sp, #60]
	bl	_nvm_section_is_singleton
	tbz	w0, #0, LBB78_20
	b	LBB78_13
LBB78_13:                               ;   in Loop: Header=BB78_3 Depth=1
	str	wzr, [sp, #44]
	b	LBB78_14
LBB78_14:                               ;   Parent Loop BB78_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #72]
	subs	w8, w8, w9
	b.hs	LBB78_19
	b	LBB78_15
LBB78_15:                               ;   in Loop: Header=BB78_14 Depth=2
	ldr	w8, [sp, #44]
	mov	x9, x8
	sub	x8, x29, #88
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.ne	LBB78_17
	b	LBB78_16
LBB78_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_17:                               ;   in Loop: Header=BB78_14 Depth=2
	b	LBB78_18
LBB78_18:                               ;   in Loop: Header=BB78_14 Depth=2
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB78_14
LBB78_19:                               ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #60]
	ldr	w9, [sp, #72]
	mov	x10, x9
	mov	x9, x10
	add	w9, w9, #1
	str	w9, [sp, #72]
	sub	x9, x29, #88
	str	w8, [x9, x10, lsl #2]
	b	LBB78_20
LBB78_20:                               ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #68]
	mov	x10, x9
	sub	x9, x29, #152
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #68]
	mov	x10, x9
	add	x9, sp, #104
	str	w8, [x9, x10, lsl #2]
	b	LBB78_21
LBB78_21:                               ;   in Loop: Header=BB78_3 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB78_3
LBB78_22:
	ldr	w8, [sp, #76]
	str	w8, [sp, #40]
	str	wzr, [sp, #36]
	b	LBB78_23
LBB78_23:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB78_27 Depth 2
	ldr	w9, [sp, #40]
	ldr	w10, [sp, #84]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.hs	LBB78_25
	b	LBB78_24
LBB78_24:                               ;   in Loop: Header=BB78_23 Depth=1
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #80]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB78_25
LBB78_25:                               ;   in Loop: Header=BB78_23 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB78_36
	b	LBB78_26
LBB78_26:                               ;   in Loop: Header=BB78_23 Depth=1
	strb	wzr, [sp, #35]
	str	wzr, [sp, #28]
	b	LBB78_27
LBB78_27:                               ;   Parent Loop BB78_23 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #28]
	ldr	w9, [sp, #80]
	subs	w8, w8, w9
	b.hs	LBB78_33
	b	LBB78_28
LBB78_28:                               ;   in Loop: Header=BB78_27 Depth=2
	ldr	w8, [sp, #28]
	mov	x9, x8
	add	x8, sp, #104
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB78_31
	b	LBB78_29
LBB78_29:                               ;   in Loop: Header=BB78_27 Depth=2
	ldr	w8, [sp, #28]
	mov	x9, x8
	sub	x8, x29, #152
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.ne	LBB78_31
	b	LBB78_30
LBB78_30:                               ;   in Loop: Header=BB78_23 Depth=1
	ldr	w8, [sp, #28]
	mov	x9, x8
	add	x8, sp, #104
	ldr	w9, [x8, x9, lsl #2]
	ldr	w8, [sp, #40]
	add	w8, w8, w9
	str	w8, [sp, #40]
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #35]
	b	LBB78_33
LBB78_31:                               ;   in Loop: Header=BB78_27 Depth=2
	b	LBB78_32
LBB78_32:                               ;   in Loop: Header=BB78_27 Depth=2
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB78_27
LBB78_33:                               ;   in Loop: Header=BB78_23 Depth=1
	ldrb	w8, [sp, #35]
	tbnz	w8, #0, LBB78_35
	b	LBB78_34
LBB78_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_35:                               ;   in Loop: Header=BB78_23 Depth=1
	b	LBB78_23
LBB78_36:
	ldr	w8, [sp, #40]
	ldr	w9, [sp, #84]
	subs	w8, w8, w9
	b.eq	LBB78_38
	b	LBB78_37
LBB78_37:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_38:
	str	wzr, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB78_39
LBB78_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #80]
	subs	w8, w8, w9
	b.hs	LBB78_44
	b	LBB78_40
LBB78_40:                               ;   in Loop: Header=BB78_39 Depth=1
	ldr	w8, [sp, #20]
	mov	x9, x8
	add	x8, sp, #104
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB78_42
	b	LBB78_41
LBB78_41:                               ;   in Loop: Header=BB78_39 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB78_42
LBB78_42:                               ;   in Loop: Header=BB78_39 Depth=1
	b	LBB78_43
LBB78_43:                               ;   in Loop: Header=BB78_39 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB78_39
LBB78_44:
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.eq	LBB78_46
	b	LBB78_45
LBB78_45:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_46:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB78_47
LBB78_47:
	ldrb	w8, [sp, #103]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB78_49
	b	LBB78_48
LBB78_48:
	bl	___stack_chk_fail
LBB78_49:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function le_read_u16
_le_read_u16:                           ; @le_read_u16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	and	w0, w8, #0xffff
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function generic_text_equal
_generic_text_equal:                    ; @generic_text_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	str	w3, [sp, #4]
	ldur	w9, [x29, #-12]
	ldr	w10, [sp, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB80_2
	b	LBB80_1
LBB80_1:
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	ldur	w8, [x29, #-12]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB80_2
LBB80_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function le_write_u16
_le_write_u16:                          ; @le_write_u16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	ldrb	w8, [sp, #6]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldrh	w8, [sp, #6]
	asr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_section_record_size
_nvm_section_record_size:               ; @nvm_section_record_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #3
	b.eq	LBB82_3
	b	LBB82_1
LBB82_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #9
	b.eq	LBB82_4
	b	LBB82_2
LBB82_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #11
	b.eq	LBB82_5
	b	LBB82_6
LBB82_3:
	mov	w8, #20                         ; =0x14
	str	w8, [sp, #12]
	b	LBB82_7
LBB82_4:
	mov	w8, #12                         ; =0xc
	str	w8, [sp, #12]
	b	LBB82_7
LBB82_5:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]
	b	LBB82_7
LBB82_6:
	str	wzr, [sp, #12]
	b	LBB82_7
LBB82_7:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_section_is_singleton
_nvm_section_is_singleton:              ; @nvm_section_is_singleton
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	subs	w8, w8, #1
	subs	w8, w8, #10
	b.hi	LBB83_2
	b	LBB83_1
LBB83_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB83_3
LBB83_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB83_3
LBB83_3:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_crc32_table,1024,2 ; @crc32_table
	.section	__TEXT,__const
_nvm_metadata_source_key.name:          ; @nvm_metadata_source_key.name
	.asciz	"nano.source_file"

_purity_key:                            ; @purity_key
	.asciz	"nano.purity.v1"

_effects_key:                           ; @effects_key
	.asciz	"nano.effects.v1"

_affine_key:                            ; @affine_key
	.asciz	"nano.affine.v1"

_match_key:                             ; @match_key
	.asciz	"nano.match.v1"

_affine_use_key:                        ; @affine_use_key
	.asciz	"nano.affine-use.v1"

_borrow_place_key:                      ; @borrow_place_key
	.asciz	"nano.borrow-place.v1"

_field_read_key:                        ; @field_read_key
	.asciz	"nano.field-read.v1"

_field_write_key:                       ; @field_write_key
	.asciz	"nano.field-write.v1"

_generic_key:                           ; @generic_key
	.asciz	"nano.generic.v1"

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

.zerofill __DATA,__bss,_crc32_initialized,1,0 ; @crc32_initialized
.subsections_via_symbols
