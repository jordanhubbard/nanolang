from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal,tempfile,traceback
root=Path.cwd();out=root/'.test_output/darwin-host-closure';out.mkdir(exist_ok=False);sys.path.insert(0,str(root));from scripts.install_host_artifacts import declared_artifacts
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
matched=[]
for name,digest in b.manifest['sources'].items():
 if name.startswith('src_nano/'):
  assert sha(root/name)==sha(frozen/name);matched.append(name)
record=dict(pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),system=subprocess.check_output(['uname','-a'],text=True),cc=subprocess.check_output(['/usr/bin/cc','--version'],text=True),raw_input=str(frozen/'bin/nanoc_stage1.nvm'),raw_sha256=sha(frozen/'bin/nanoc_stage1.nvm'),matching_nano_sources=matched,steps=[],limits=['I retranslate the actual qualified bdffa4ccc Darwin raw Stage1 with my changed emitter and exact retained host bytes in a new source worktree. All NanoLang compiler inputs match. This qualifies development native deployment, not a new raw bootstrap/final release. I never modify either frozen qualification checkout or the primary dirty callable audit/stashes.'])
env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANO_BUILD_CACHE=str(out/'module-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10')
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_CC','NANO_AS_CAPTURE_HELPER','NANO_VM','NANO_CFLAGS','NANO_LDFLAGS','NANO_NATIVE_TEST_CC','NANOLANG_SELFHOST_COMPILER']:env.pop(key,None)
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,argv,cwd=root,child_env=env,expect=0,timeout=1800):
 entry=dict(label=label,argv=list(map(str,argv)),cwd=str(cwd));record['steps'].append(entry);save();t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as z:
  p=subprocess.Popen(entry['argv'],cwd=cwd,env=child_env,stdout=a,stderr=z,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);entry.update(returncode=p.wait(),timeout=True)
 entry['elapsed_seconds']=time.monotonic()-t;save();assert not entry.get('timeout') and (entry['returncode']==0 if expect==0 else entry['returncode']!=0),entry
try:
 run('build-tools',['make','-j8','CC=/usr/bin/cc','nano_virt','nano_vm','nanoisa_dump','nvm2c','nvm2c-runtime'])
 run('original-deployment-target',['make','CC=/usr/bin/cc','test-host-artifact-deployment'])
 run('verify-original-raw',[root/'bin/nano_vm','--verify-only',frozen/'bin/nanoc_stage1.nvm'])
 run('translate',[root/'bin/nvm2c',frozen/'bin/nanoc_stage1.nvm','-o',out/'compiler.c'])
 args=list(next(s['argv'] for s in b.manifest['steps'] if s['label']=='stage1-native'))
 replacements={str(b.work/'stage1.c'):str(out/'compiler.c'),str(b.work/'stage1'):str(out/'nanoc'),str(frozen/'bin/nano_aot_runtime.o'):str(root/'bin/nano_aot_runtime.o')};args=[replacements.get(a,a) for a in args]
 assert str(out/'compiler.c') in args and args[args.index('-o')+1]==str(out/'nanoc')
 run('native',args)
 compiler=out/'nanoc';record['compiler_sha256']=sha(compiler);record['host_inputs']={path:digest for digest,paths in declared_artifacts(compiler.read_bytes()).items() for path in paths};assert len(record['host_inputs'])==6;save()
 external=Path(tempfile.mkdtemp(prefix='nano-host-closure-darwin-')).resolve();first=external/'first-prefix';prefix=external/'relocated-prefix';client=external/'client';client.mkdir();record.update(external=str(external),prefix=str(prefix));save()
 run('actual-make-install',['make','CC=/usr/bin/cc','--old-file='+str(compiler),'COMPILER='+str(compiler),'PREFIX='+str(first),'install'])
 first.rename(prefix);assert sha(prefix/'bin/nanoc')==sha(compiler)
 source=client/'input.nano';source.write_text('fn answer()->int{return 42}\nshadow answer{assert (== (answer) 42)}\nfn main()->int{assert (== (answer) 42) (println "darwin-host-closure-ok") return 0}\n')
 provider=client/'provider';provider.mkdir();(provider/'module.json').write_text(json.dumps(dict(name='provider',c_sources=['api.c'])));(provider/'api.nano').write_text('extern fn path_basename(s: string) -> string\n');(provider/'api.c').write_text('const char *path_basename(const char *s) { (void)s; return "darwin-external-provider-ok"; }\n')
 foreign=client/'foreign.nano';foreign.write_text('import "provider/api.nano"\nfn main()->int { unsafe { (println (path_basename "input")) } return 0 }\nshadow main { assert true }\n')
 hidden=[p for p in [Path('/Users/jkh/.worktrees/nanolang'),Path('/Users/jkh/Src/nanolang'),Path('/Users/jkh/Src/nanolang-callable-ownership')] if p.is_dir()]
 for path in hidden:assert not prefix.is_relative_to(path)
 policy='(version 1) (allow default) '+' '.join('(deny file-read* (subpath '+json.dumps(str(p))+'))' for p in hidden)
 base=['/usr/bin/sandbox-exec','-p',policy];record.update(hidden_roots=list(map(str,hidden)),sandbox_policy=policy)
 clean=dict(env,PATH=str(prefix/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',NANO_CC='/bin/false',NANO_BUILD_CACHE=str(external/'external-cache'),TMPDIR=str(client))
 record['isolated_environment']={k:clean.get(k) for k in ['PATH','CC','NANO_CC','NANO_BUILD_CACHE','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER']};save()
 run('sandbox-setup',base+['/usr/bin/true'],cwd=client,child_env=clean,timeout=30)
 run('source-unavailable-control',base+['/bin/cat',root/'Makefile.gnu'],cwd=client,child_env=clean,expect=1,timeout=30)
 assert (out/'source-unavailable-control.stdout').read_bytes()==b''
 for label,input_,name,expected,driver in [('builtin',source,'builtin','darwin-host-closure-ok',prefix/'bin/nanoc'),('foreign',foreign,'foreign','darwin-external-provider-ok','nanoc')]:
  selected=clean if label=='builtin' else dict(clean,NANO_CC='/usr/bin/cc')
  run(label+'-compile-module',base+[driver,input_,'--emit-nvm','-o',client/(name+'.nvm')],cwd=client,child_env=selected,timeout=180)
  run(label+'-verify-module',base+[prefix/'bin/nano_vm','--verify-only',client/(name+'.nvm')],cwd=client,child_env=selected,timeout=30)
  run(label+'-execute-module',base+[prefix/'bin/nano_vm',client/(name+'.nvm')],cwd=client,child_env=selected,timeout=30)
  run(label+'-compile-native',base+[driver,input_,'--target','native','-o',client/(name+'.native')],cwd=client,child_env=dict(clean,NANO_CC='/usr/bin/cc'),timeout=180)
  run(label+'-execute-native',base+[client/(name+'.native')],cwd=client,child_env=selected,timeout=30)
  for kind in ['module','native']:assert (out/(label+'-execute-'+kind+'.stdout')).read_text()==expected+'\n'
 key=next(digest for path,digest in record['host_inputs'].items() if 'libfile_source_inputs.' in path);library=prefix/'lib/nanolang/hosts'/key;original=library.read_bytes();protected=client/'protected.nvm';protected.write_bytes(b'preserve-existing-output')
 try:
  library.write_bytes(original+b'changed')
  run('corrupt-installed-library',base+[prefix/'bin/nanoc',source,'--emit-nvm','-o',protected],cwd=client,child_env=clean,expect=1,timeout=180);assert protected.read_bytes()==b'preserve-existing-output'
 finally:library.write_bytes(original)
 absent=library.with_name('same-basename.dylib');library.rename(absent)
 try:
  run('missing-installed-library',base+[prefix/'bin/nanoc',source,'--emit-nvm','-o',protected],cwd=client,child_env=clean,expect=1,timeout=180);assert protected.read_bytes()==b'preserve-existing-output'
 finally:absent.rename(library)
 run('restored-installed-library',base+[prefix/'bin/nanoc',source,'--emit-nvm','-o',client/'restored.nvm'],cwd=client,child_env=clean,timeout=180)
 record['status']='passed'
except BaseException as error:
 record.update(status='failed',error=repr(error));traceback.print_exc()
finally:
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['original_bootstrap_guards_unchanged']=True
 if 'host_inputs' in record:record['host_inputs_unchanged']=all(sha(path)==digest for path,digest in record['host_inputs'].items())
 record['final_git_status']=subprocess.check_output(['git','status','--short'],cwd=root,text=True);save()
sys.exit(0 if record['status']=='passed' else 1)
