	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_socket_nominal_check ; -- Begin function nvm_socket_nominal_check
	.globl	_nvm_socket_nominal_check
	.p2align	2
_nvm_socket_nominal_check:              ; @nvm_socket_nominal_check
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_5
; %bb.1:
	ldr	w9, [x0]
	cmn	w9, #1
	b.eq	LBB0_4
; %bb.2:
	ldr	w10, [x0, #4]
	cmn	w10, #1
	ccmp	w9, w10, #4, ne
	b.eq	LBB0_4
; %bb.3:
	ldr	w11, [x0, #8]
	cmn	w11, #1
	ccmp	w9, w11, #4, ne
	ccmp	w10, w11, #4, ne
	b.ne	LBB0_6
LBB0_4:
	mov	w0, #8                          ; =0x8
	ret
LBB0_5:
	mov	w0, #1                          ; =0x1
	ret
LBB0_6:
	mov	x8, x0
	ldr	w12, [x0, #12]
	mov	w0, #8                          ; =0x8
	cmn	w12, #1
	b.eq	LBB0_52
; %bb.7:
	cmp	w9, w12
	b.eq	LBB0_52
; %bb.8:
	cmp	w10, w12
	b.eq	LBB0_52
; %bb.9:
	cmp	w11, w12
	b.eq	LBB0_52
; %bb.10:
	ldr	w13, [x8, #16]
	cmn	w13, #1
	b.eq	LBB0_52
; %bb.11:
	cmp	w9, w13
	b.eq	LBB0_52
; %bb.12:
	cmp	w10, w13
	b.eq	LBB0_52
; %bb.13:
	cmp	w11, w13
	b.eq	LBB0_52
; %bb.14:
	cmp	w12, w13
	b.eq	LBB0_52
; %bb.15:
	ldr	w9, [x8, #20]
	cmn	w9, #1
	b.eq	LBB0_52
; %bb.16:
	ldr	w10, [x8, #24]
	cmn	w10, #1
	b.eq	LBB0_52
; %bb.17:
	cmp	w9, w10
	b.eq	LBB0_52
; %bb.18:
	ldr	w11, [x8, #28]
	cmn	w11, #1
	b.eq	LBB0_52
; %bb.19:
	cmp	w9, w11
	b.eq	LBB0_52
; %bb.20:
	cmp	w10, w11
	b.eq	LBB0_52
; %bb.21:
	ldr	w12, [x8, #32]
	cmn	w12, #1
	b.eq	LBB0_52
; %bb.22:
	cmp	w9, w12
	b.eq	LBB0_52
; %bb.23:
	cmp	w10, w12
	b.eq	LBB0_52
; %bb.24:
	cmp	w11, w12
	b.eq	LBB0_52
; %bb.25:
	ldr	w13, [x8, #36]
	cmn	w13, #1
	b.eq	LBB0_52
; %bb.26:
	cmp	w9, w13
	b.eq	LBB0_52
; %bb.27:
	cmp	w10, w13
	b.eq	LBB0_52
; %bb.28:
	cmp	w11, w13
	b.eq	LBB0_52
; %bb.29:
	cmp	w12, w13
	b.eq	LBB0_52
; %bb.30:
	ldr	w14, [x8, #40]
	cmn	w14, #1
	b.eq	LBB0_52
; %bb.31:
	cmp	w9, w14
	b.eq	LBB0_52
; %bb.32:
	cmp	w10, w14
	b.eq	LBB0_52
; %bb.33:
	cmp	w11, w14
	b.eq	LBB0_52
; %bb.34:
	cmp	w12, w14
	b.eq	LBB0_52
; %bb.35:
	cmp	w13, w14
	b.eq	LBB0_52
; %bb.36:
	ldr	w15, [x8, #44]
	cmn	w15, #1
	b.eq	LBB0_52
; %bb.37:
	cmp	w9, w15
	b.eq	LBB0_52
; %bb.38:
	cmp	w10, w15
	b.eq	LBB0_52
; %bb.39:
	cmp	w11, w15
	b.eq	LBB0_52
; %bb.40:
	cmp	w12, w15
	b.eq	LBB0_52
; %bb.41:
	cmp	w13, w15
	b.eq	LBB0_52
; %bb.42:
	cmp	w14, w15
	b.eq	LBB0_52
; %bb.43:
	ldr	w16, [x8, #48]
	cmn	w16, #1
	b.eq	LBB0_52
; %bb.44:
	cmp	w9, w16
	b.eq	LBB0_52
; %bb.45:
	cmp	w10, w16
	b.eq	LBB0_52
; %bb.46:
	cmp	w11, w16
	b.eq	LBB0_52
; %bb.47:
	cmp	w12, w16
	b.eq	LBB0_52
; %bb.48:
	cmp	w13, w16
	b.eq	LBB0_52
; %bb.49:
	cmp	w14, w16
	b.eq	LBB0_52
; %bb.50:
	cmp	w15, w16
	b.eq	LBB0_52
; %bb.51:
	ldr	w8, [x8, #52]
	cmn	w8, #1
	ccmp	w9, w8, #4, ne
	ccmp	w10, w8, #4, ne
	ccmp	w11, w8, #4, ne
	ccmp	w12, w8, #4, ne
	ccmp	w13, w8, #4, ne
	ccmp	w14, w8, #4, ne
	ccmp	w15, w8, #4, ne
	ccmp	w16, w8, #4, ne
	cset	w8, eq
	tst	w8, #0x1
	mov	w8, #8                          ; =0x8
	csel	w0, w8, wzr, ne
LBB0_52:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_socket_nominal_decode ; -- Begin function nvm_socket_nominal_decode
	.globl	_nvm_socket_nominal_decode
	.p2align	2
_nvm_socket_nominal_decode:             ; @nvm_socket_nominal_decode
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	cbz	x0, LBB1_10
; %bb.1:
	cbz	x2, LBB1_10
; %bb.2:
	cmp	x1, #128
	b.ne	LBB1_9
; %bb.3:
	ldrh	w8, [x0]
	cmp	w8, #2
	b.ne	LBB1_11
; %bb.4:
	ldrh	w8, [x0, #2]
	cmp	w8, #2
	b.ne	LBB1_12
; %bb.5:
	ldr	w8, [x0, #4]
	cmp	w8, #5
	b.ne	LBB1_13
; %bb.6:
	ldr	w8, [x0, #8]
	cmp	w8, #9
	b.ne	LBB1_13
; %bb.7:
	ldr	w8, [x0, #12]
	cbz	w8, LBB1_14
; %bb.8:
	mov	w0, #6                          ; =0x6
	ret
LBB1_9:
	mov	w8, #2                          ; =0x2
LBB1_10:
	mov	x0, x8
	ret
LBB1_11:
	mov	w0, #3                          ; =0x3
	ret
LBB1_12:
	mov	w0, #4                          ; =0x4
	ret
LBB1_13:
	mov	w0, #5                          ; =0x5
	ret
LBB1_14:
	ldr	w8, [x0, #16]
	cbz	w8, LBB1_16
; %bb.15:
	mov	w0, #7                          ; =0x7
	ret
LBB1_16:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldp	w8, w9, [x0, #20]
	str	w8, [sp, #8]
	cmp	w9, #1
	b.ne	LBB1_31
; %bb.17:
	ldp	w8, w9, [x0, #28]
	str	w8, [sp, #12]
	cmp	w9, #2
	b.ne	LBB1_31
; %bb.18:
	ldp	w8, w9, [x0, #36]
	str	w8, [sp, #16]
	cmp	w9, #3
	b.ne	LBB1_31
; %bb.19:
	ldp	w8, w9, [x0, #44]
	str	w8, [sp, #20]
	cmp	w9, #4
	b.ne	LBB1_31
; %bb.20:
	ldp	w8, w9, [x0, #52]
	str	w8, [sp, #24]
	cbnz	w9, LBB1_31
; %bb.21:
	str	x2, [sp]                        ; 8-byte Folded Spill
	ldp	w8, w9, [x0, #60]
	str	w8, [sp, #28]
	cmp	w9, #1
	b.ne	LBB1_31
; %bb.22:
	ldp	w8, w9, [x0, #68]
	str	w8, [sp, #32]
	cmp	w9, #2
	b.ne	LBB1_31
; %bb.23:
	ldp	w8, w9, [x0, #76]
	str	w8, [sp, #36]
	cmp	w9, #3
	b.ne	LBB1_31
; %bb.24:
	ldp	w8, w9, [x0, #84]
	str	w8, [sp, #40]
	cmp	w9, #4
	b.ne	LBB1_31
; %bb.25:
	ldp	w8, w9, [x0, #92]
	str	w8, [sp, #44]
	cmp	w9, #5
	b.ne	LBB1_31
; %bb.26:
	ldp	w8, w9, [x0, #100]
	str	w8, [sp, #48]
	cmp	w9, #6
	b.ne	LBB1_31
; %bb.27:
	ldp	w8, w9, [x0, #108]
	str	w8, [sp, #52]
	cmp	w9, #7
	b.ne	LBB1_31
; %bb.28:
	ldp	w8, w9, [x0, #116]
	str	w8, [sp, #56]
	cmp	w9, #8
	b.ne	LBB1_31
; %bb.29:
	ldr	w8, [x0, #124]
	str	w8, [sp, #60]
	add	x0, sp, #8
	bl	_nvm_socket_nominal_check
	mov	x8, x0
	cbnz	w0, LBB1_32
; %bb.30:
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	stp	q0, q1, [x9]
	ldur	q0, [sp, #40]
	str	q0, [x9, #32]
	ldr	x10, [sp, #56]
	str	x10, [x9, #48]
	b	LBB1_32
LBB1_31:
	mov	w8, #7                          ; =0x7
LBB1_32:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_nominal_encode
lCPI2_0:
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	5                               ; 0x5
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_socket_nominal_encode
	.globl	_nvm_socket_nominal_encode
	.p2align	2
_nvm_socket_nominal_encode:             ; @nvm_socket_nominal_encode
	.cfi_startproc
; %bb.0:
	cbz	x3, LBB2_5
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x1
	mov	x21, x3
	mov	x22, x0
	bl	_nvm_socket_nominal_check
	cbnz	w0, LBB2_9
; %bb.2:
	cbz	x19, LBB2_6
; %bb.3:
	cmp	x20, #128
	b.hs	LBB2_6
; %bb.4:
	mov	w0, #2                          ; =0x2
	b	LBB2_9
LBB2_5:
	mov	w0, #1                          ; =0x1
	ret
LBB2_6:
	cbz	x19, LBB2_8
; %bb.7:
	ldp	w3, w2, [x22]
	lsr	w4, w3, #8
	ldp	w1, w0, [x22, #8]
	ldp	w17, w16, [x22, #16]
	ldp	w15, w14, [x22, #24]
	ldp	w13, w12, [x22, #32]
	ldp	w11, w9, [x22, #40]
Lloh0:
	adrp	x10, lCPI2_0@PAGE
Lloh1:
	ldr	d0, [x10, lCPI2_0@PAGEOFF]
	ldp	w10, w8, [x22, #48]
	strb	w4, [x19, #21]
	lsr	w4, w3, #16
	strb	w4, [x19, #22]
	strb	w3, [x19, #20]
	lsr	w3, w3, #24
	strb	w3, [x19, #23]
	lsr	w3, w2, #8
	strb	w3, [x19, #29]
	lsr	w3, w2, #16
	strb	w3, [x19, #30]
	strb	w2, [x19, #28]
	lsr	w2, w2, #24
	strb	w2, [x19, #31]
	lsr	w2, w1, #8
	strb	w2, [x19, #37]
	lsr	w2, w1, #16
	strb	w2, [x19, #38]
	strb	w1, [x19, #36]
	lsr	w1, w1, #24
	strb	w1, [x19, #39]
	lsr	w1, w0, #8
	strb	w1, [x19, #45]
	lsr	w1, w0, #16
	strb	w1, [x19, #46]
	strb	w0, [x19, #44]
	lsr	w0, w0, #24
	strb	w0, [x19, #47]
	lsr	w0, w17, #8
	strb	w0, [x19, #53]
	lsr	w0, w17, #16
	strb	w0, [x19, #54]
	strb	w17, [x19, #52]
	lsr	w17, w17, #24
	strb	w17, [x19, #55]
	lsr	w17, w16, #8
	strb	w17, [x19, #61]
	lsr	w17, w16, #16
	strb	w17, [x19, #62]
	strb	w16, [x19, #60]
	lsr	w16, w16, #24
	strb	w16, [x19, #63]
	mov	w16, #1                         ; =0x1
	str	w16, [x19, #24]
	str	w16, [x19, #64]
	lsr	w16, w15, #8
	strb	w16, [x19, #69]
	lsr	w16, w15, #16
	strb	w16, [x19, #70]
	strb	w15, [x19, #68]
	lsr	w15, w15, #24
	strb	w15, [x19, #71]
	mov	w15, #2                         ; =0x2
	str	w15, [x19, #32]
	str	w15, [x19, #72]
	lsr	w15, w14, #8
	strb	w15, [x19, #77]
	lsr	w15, w14, #16
	strb	w15, [x19, #78]
	strb	w14, [x19, #76]
	lsr	w14, w14, #24
	strb	w14, [x19, #79]
	mov	w14, #3                         ; =0x3
	str	w14, [x19, #40]
	str	w14, [x19, #80]
	lsr	w14, w13, #8
	strb	w14, [x19, #85]
	lsr	w14, w13, #16
	strb	w14, [x19, #86]
	strb	w13, [x19, #84]
	lsr	w13, w13, #24
	strb	w13, [x19, #87]
	mov	w13, #4                         ; =0x4
	str	w13, [x19, #48]
	str	w13, [x19, #88]
	lsr	w13, w12, #8
	strb	w13, [x19, #93]
	lsr	w13, w12, #16
	strb	w13, [x19, #94]
	strb	w12, [x19, #92]
	lsr	w12, w12, #24
	strb	w12, [x19, #95]
	mov	w12, #5                         ; =0x5
	str	w12, [x19, #96]
	lsr	w12, w11, #8
	strb	w12, [x19, #101]
	lsr	w12, w11, #16
	strb	w12, [x19, #102]
	strb	w11, [x19, #100]
	lsr	w11, w11, #24
	strb	w11, [x19, #103]
	lsr	w11, w9, #8
	strb	w11, [x19, #109]
	lsr	w11, w9, #16
	strb	w11, [x19, #110]
	strb	w9, [x19, #108]
	lsr	w9, w9, #24
	strb	w9, [x19, #111]
	lsr	w9, w10, #8
	strb	w9, [x19, #117]
	lsr	w9, w10, #16
	strb	w9, [x19, #118]
	strb	w10, [x19, #116]
	lsr	w9, w10, #24
	strb	w9, [x19, #119]
	lsr	w9, w8, #8
	strb	w9, [x19, #125]
	lsr	w9, w8, #16
	strb	w9, [x19, #126]
	strb	w8, [x19, #124]
	lsr	w8, w8, #24
	strb	w8, [x19, #127]
	str	d0, [x19]
	movi.2s	v0, #9
	str	s0, [x19, #8]
	stur	xzr, [x19, #12]
	str	wzr, [x19, #56]
	movi.2s	v0, #6
	str	s0, [x19, #104]
	movi.2s	v0, #7
	str	s0, [x19, #112]
	movi.2s	v0, #8
	str	s0, [x19, #120]
LBB2_8:
	mov	w0, #0                          ; =0x0
	mov	w8, #128                        ; =0x80
	str	x8, [x21]
LBB2_9:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
