from pathlib import Path
import os,json,subprocess,time
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');state=json.loads((root/'.test_output/darwin-host-closure/manifest.json').read_text());out=root/'.test_output/darwin-host-system-trace';out.mkdir(exist_ok=False);prefix=Path(state['prefix']);client=Path(state['external'])/'client';trace=client/'system-trace';trace.mkdir(exist_ok=False)
source=trace/'interpose.c';library=trace/'interpose.dylib';source.write_text(r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <errno.h>
static int traced_system(const char *command) {
 static unsigned sequence;
 unsigned index=sequence++;
 const char *directory=getenv("NANO_SYSTEM_TRACE");
 char path[4096];
 if (directory && command) {
  snprintf(path,sizeof path,"%s/%u.command",directory,index);
  FILE *f=fopen(path,"wb");if(f){fwrite(command,1,strlen(command),f);fclose(f);}
  if (strstr(command," -std=c11 ")) {
   const char *first=strchr(command,'\'');const char *last=first?strchr(first+1,'\''):NULL;
   if(first&&last&&(size_t)(last-first)<sizeof path){memcpy(path,first+1,(size_t)(last-first-1));path[last-first-1]=0;
    FILE *in=fopen(path,"rb");snprintf(path,sizeof path,"%s/%u.input.c",directory,index);FILE *copy=in?fopen(path,"wb"):NULL;
    if(copy){unsigned char buffer[16384];size_t n;while((n=fread(buffer,1,sizeof buffer,in)))fwrite(buffer,1,n,copy);fclose(copy);}if(in)fclose(in);
   }
  }
 }
 int (*original)(const char *)=(int(*)(const char *))dlsym(RTLD_NEXT,"system");
 int value=original?original(command):-1;int error=errno;
 if(directory){snprintf(path,sizeof path,"%s/%u.result",directory,index);FILE *f=fopen(path,"w");if(f){fprintf(f,"%d %d\n",value,error);fclose(f);}}
 errno=error;return value;
}
__attribute__((used)) static struct { const void *replacement; const void *original; } hooks[]
 __attribute__((section("__DATA,__interpose"))) = {{(const void *)traced_system,(const void *)system}};
''')
r=subprocess.run(['/usr/bin/cc','-shared','-fPIC','-Wall','-Wextra','-Werror',str(source),'-o',str(library)],capture_output=True,text=True,timeout=60);assert r.returncode==0,r.stderr
# I keep the actual compiler selection, nonverbose mode and original deadlines.
env=dict(os.environ,PATH=str(prefix/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANO_CC='/usr/bin/cc',NANO_BUILD_CACHE=str(Path(state['external'])/'trace-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',TMPDIR=str(client),DYLD_INSERT_LIBRARIES=str(library),NANO_SYSTEM_TRACE=str(trace))
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM','NANO_CFLAGS','NANO_LDFLAGS']:env.pop(key,None)
args=['/usr/bin/sandbox-exec','-p',state['sandbox_policy'],str(prefix/'bin/nanoc'),str(client/'input.nano'),'--target','native','-o',str(client/'system-traced.native')];start=time.monotonic();r=subprocess.run(args,cwd=client,env=env,capture_output=True,text=True,timeout=180);record=dict(argv=args,returncode=r.returncode,elapsed_seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr,trace=[dict(path=str(p),text=p.read_text()) for p in trace.iterdir() if p.suffix in ('.command','.result')],diagnostic_only='I interpose the actual system call without changing its command or compiler selection. System-protected launchers may remove DYLD variables; I verify whether trace files exist before inferring any observation.');(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
