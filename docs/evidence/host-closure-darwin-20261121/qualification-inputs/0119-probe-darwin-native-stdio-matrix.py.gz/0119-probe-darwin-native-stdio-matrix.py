from pathlib import Path
import os,json,subprocess,time
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');state=json.loads((root/'.test_output/darwin-host-closure/manifest.json').read_text());out=root/'.test_output/darwin-native-stdio-matrix';out.mkdir(exist_ok=False);prefix=Path(state['prefix']);client=Path(state['external'])/'client';allowed=client/'stdio-control';allowed.mkdir(exist_ok=False);plain=allowed/'plain.c';plain.write_text('int main(void) { return 0; }\n');env=dict(os.environ,PATH=str(prefix/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANO_CC='/usr/bin/cc',NANO_BUILD_CACHE=str(Path(state['external'])/'stdio-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',TMPDIR=str(client))
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM','NANO_CFLAGS','NANO_LDFLAGS','DYLD_INSERT_LIBRARIES','NANO_SYSTEM_TRACE']:env.pop(key,None)
rows=[]
for driver in ('plain','nanoc'):
 for sandbox in (False,True):
  for location in ('allowed','denied'):
   label=f'{driver}-{int(sandbox)}-{location}';logs=allowed if location=='allowed' else out
   args=(['/usr/bin/cc',str(plain),'-o',str(allowed/(label+'.native'))] if driver=='plain' else [str(prefix/'bin/nanoc'),str(client/'input.nano'),'--target','native','-o',str(allowed/(label+'.native'))]);args=(['/usr/bin/sandbox-exec','-p',state['sandbox_policy']] if sandbox else [])+args;t=time.monotonic()
   with (logs/(label+'.stdout')).open('wb') as a,(logs/(label+'.stderr')).open('wb') as b:
    p=subprocess.Popen(args,cwd=client,env=env,stdout=a,stderr=b,start_new_session=True);status=p.wait(timeout=180)
   rows.append(dict(driver=driver,sandbox=sandbox,stdio_location=location,argv=args,stdout_path=str(logs/(label+'.stdout')),stderr_path=str(logs/(label+'.stderr')),returncode=status,elapsed_seconds=time.monotonic()-t,stdout=(logs/(label+'.stdout')).read_text(),stderr=(logs/(label+'.stderr')).read_text()));(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
