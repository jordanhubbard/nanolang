from pathlib import Path
import os,json,subprocess,time
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');state=json.loads((root/'.test_output/darwin-host-closure/manifest.json').read_text());out=root/'.test_output/darwin-host-native-wrapper';out.mkdir(exist_ok=False);prefix=Path(state['prefix']);client=Path(state['external'])/'client';capture=client/'cc-capture';capture.mkdir(exist_ok=False)
wrapper=client/'capture-cc';wrapper.write_text('''#!/opt/homebrew/bin/python3
import os,sys,json,subprocess,time,hashlib
from pathlib import Path
out=Path(__file__).parent/'cc-capture'/str(time.time_ns());out.mkdir()
argv=['/usr/bin/cc',*sys.argv[1:]];inputs=[]
for i,arg in enumerate(argv[1:]):
 p=Path(arg)
 if p.is_file() and p.suffix in ('.c','.o'):
  data=p.read_bytes();(out/(str(i)+'-'+p.name)).write_bytes(data);inputs.append(dict(path=arg,sha256=hashlib.sha256(data).hexdigest()))
r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr);(out/'manifest.json').write_text(json.dumps(dict(argv=argv,cwd=os.getcwd(),returncode=r.returncode,inputs=inputs),indent=2)+'\\n')
os.write(1,r.stdout);os.write(2,r.stderr);sys.exit(r.returncode if r.returncode>=0 else 128-r.returncode)
''');wrapper.chmod(0o755)
env=dict(os.environ,PATH=str(prefix/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANO_CC=str(wrapper),NANO_BUILD_CACHE=str(Path(state['external'])/'wrapper-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',TMPDIR=str(client))
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM','NANO_CFLAGS','NANO_LDFLAGS']:env.pop(key,None)
args=['/usr/bin/sandbox-exec','-p',state['sandbox_policy'],str(prefix/'bin/nanoc'),str(client/'input.nano'),'--target','native','-o',str(client/'wrapped.native')];start=time.monotonic();r=subprocess.run(args,cwd=client,env=env,capture_output=True,text=True,timeout=180);record=dict(argv=args,returncode=r.returncode,elapsed_seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr,diagnostic_only='I capture actual delegated system-compiler argv/input/status under the same source-denial policy. This wrapper is an observation tool, not a qualified compiler substitute.',compiler_records=[json.loads(p.read_text()) for p in capture.glob('*/manifest.json')]);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
