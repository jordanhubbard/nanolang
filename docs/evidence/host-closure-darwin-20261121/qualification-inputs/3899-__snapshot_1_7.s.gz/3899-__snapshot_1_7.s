	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_result_name     ; -- Begin function nvm_v2_result_name
	.globl	_nvm_v2_result_name
	.p2align	2
_nvm_v2_result_name:                    ; @nvm_v2_result_name
	.cfi_startproc
; %bb.0:
	cmp	w0, #14
	b.hi	LBB0_2
; %bb.1:
Lloh0:
	adrp	x8, l_switch.table.nvm_v2_result_name@PAGE
Lloh1:
	add	x8, x8, l_switch.table.nvm_v2_result_name@PAGEOFF
	ldr	x0, [x8, w0, uxtw #3]
	ret
LBB0_2:
Lloh2:
	adrp	x0, l_.str.15@PAGE
Lloh3:
	add	x0, x0, l_.str.15@PAGEOFF
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_v2_read_header
lCPI1_0:
	.byte	78                              ; 0x4e
	.byte	86                              ; 0x56
	.byte	77                              ; 0x4d
	.byte	2                               ; 0x2
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_read_header
	.globl	_nvm_v2_read_header
	.p2align	2
_nvm_v2_read_header:                    ; @nvm_v2_read_header
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cmp	x1, #40
	b.lo	LBB1_10
; %bb.1:
	cbz	x8, LBB1_10
; %bb.2:
	cbz	x2, LBB1_10
; %bb.3:
	ldr	w9, [x8]
	mov	w10, #22094                     ; =0x564e
	movk	w10, #589, lsl #16
	cmp	w9, w10
	b.ne	LBB1_11
; %bb.4:
	ldrh	w9, [x8, #4]
	cmp	w9, #1
	b.ne	LBB1_12
; %bb.5:
	ldr	w9, [x8, #20]
	cmp	w9, #40
	b.ne	LBB1_13
; %bb.6:
	ldr	w9, [x8, #8]
	cmp	w9, #1023
	b.hi	LBB1_14
; %bb.7:
	ldur	x10, [x8, #12]
	cmp	x10, x1
	b.ne	LBB1_15
; %bb.8:
	ldr	w10, [x8, #32]
	cbz	w10, LBB1_16
; %bb.9:
	mov	w0, #7                          ; =0x7
LBB1_10:
	ret
LBB1_11:
	mov	w0, #2                          ; =0x2
	ret
LBB1_12:
	mov	w0, #3                          ; =0x3
	ret
LBB1_13:
	mov	w0, #4                          ; =0x4
	ret
LBB1_14:
	mov	w0, #5                          ; =0x5
	ret
LBB1_15:
	mov	w0, #6                          ; =0x6
	ret
LBB1_16:
	mov	w0, #0                          ; =0x0
	ldrh	w10, [x8, #6]
	ldr	d0, [x8, #24]
	ldr	w8, [x8, #36]
Lloh4:
	adrp	x11, lCPI1_0@PAGE
Lloh5:
	ldr	d1, [x11, lCPI1_0@PAGEOFF]
	mov	w11, #1                         ; =0x1
	strh	w11, [x2, #4]
	str	s1, [x2]
	strh	w10, [x2, #6]
	str	w9, [x2, #8]
	str	x1, [x2, #16]
	mov	w9, #40                         ; =0x28
	str	w9, [x2, #24]
	stur	d0, [x2, #28]
	stp	wzr, w8, [x2, #36]
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_read_section    ; -- Begin function nvm_v2_read_section
	.globl	_nvm_v2_read_section
	.p2align	2
_nvm_v2_read_section:                   ; @nvm_v2_read_section
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB2_7
; %bb.1:
	cbz	x2, LBB2_7
; %bb.2:
	cbz	x4, LBB2_7
; %bb.3:
	ldr	w9, [x2, #28]
	cmp	w3, w9
	b.hs	LBB2_7
; %bb.4:
	subs	x10, x1, #40
	b.lo	LBB2_7
; %bb.5:
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #3
	cmp	x9, x10
	b.hi	LBB2_7
; %bb.6:
	mov	w0, #0                          ; =0x0
	mov	w9, #24                         ; =0x18
	umaddl	x8, w3, w9, x8
	ldr	w9, [x8, #40]
	str	w9, [x4]
	ldr	w9, [x8, #44]
	str	w9, [x4, #4]
	ldr	x9, [x8, #48]
	str	x9, [x4, #8]
	ldr	x8, [x8, #56]
	str	x8, [x4, #16]
LBB2_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_validate        ; -- Begin function nvm_v2_validate
	.globl	_nvm_v2_validate
	.p2align	2
_nvm_v2_validate:                       ; @nvm_v2_validate
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	cbz	x0, LBB3_10
; %bb.1:
	subs	x10, x1, #40
	b.lo	LBB3_10
; %bb.2:
	ldr	w8, [x0]
	mov	w9, #22094                      ; =0x564e
	movk	w9, #589, lsl #16
	cmp	w8, w9
	b.ne	LBB3_9
; %bb.3:
	ldrh	w8, [x0, #4]
	cmp	w8, #1
	b.ne	LBB3_11
; %bb.4:
	ldr	w8, [x0, #20]
	cmp	w8, #40
	b.ne	LBB3_12
; %bb.5:
	ldr	w8, [x0, #8]
	cmp	w8, #1023
	b.hi	LBB3_13
; %bb.6:
	ldur	x8, [x0, #12]
	cmp	x8, x1
	b.ne	LBB3_14
; %bb.7:
	ldr	w8, [x0, #32]
	cbz	w8, LBB3_15
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB3_9:
	mov	w8, #2                          ; =0x2
LBB3_10:
	mov	x0, x8
	ret
LBB3_11:
	mov	w0, #3                          ; =0x3
	ret
LBB3_12:
	mov	w0, #4                          ; =0x4
	ret
LBB3_13:
	mov	w0, #5                          ; =0x5
	ret
LBB3_14:
	mov	w0, #6                          ; =0x6
	ret
LBB3_15:
	ldr	w9, [x0, #24]
	add	x8, x9, x9, lsl #1
	lsl	x8, x8, #3
	cmp	x8, x10
	b.ls	LBB3_17
; %bb.16:
	mov	w0, #1                          ; =0x1
	ret
LBB3_17:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	w19, [x0, #36]
	cbz	w9, LBB3_40
; %bb.18:
	mov	x11, #0                         ; =0x0
	add	x12, x8, #40
	add	x10, x0, #40
	add	x13, x0, #56
	mov	w14, #1                         ; =0x1
	mov	x15, x9
	b	LBB3_20
LBB3_19:                                ;   in Loop: Header=BB3_20 Depth=1
	add	x13, x13, #24
	orr	x11, x16, x11
	subs	x15, x15, #1
	b.eq	LBB3_30
LBB3_20:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x13, #-12]
	cbnz	w8, LBB3_27
; %bb.21:                               ;   in Loop: Header=BB3_20 Depth=1
	ldur	w8, [x13, #-16]
	sub	w16, w8, #15
	cmn	w16, #14
	b.lo	LBB3_28
; %bb.22:                               ;   in Loop: Header=BB3_20 Depth=1
	lsl	x16, x14, x8
	tst	x16, x11
	b.ne	LBB3_29
; %bb.23:                               ;   in Loop: Header=BB3_20 Depth=1
	ldur	x17, [x13, #-8]
	mov	w8, #9                          ; =0x9
	subs	x3, x1, x17
	b.lo	LBB3_41
; %bb.24:                               ;   in Loop: Header=BB3_20 Depth=1
	ldr	x2, [x13]
	cmp	x2, x3
	b.hi	LBB3_41
; %bb.25:                               ;   in Loop: Header=BB3_20 Depth=1
	cbz	x2, LBB3_19
; %bb.26:                               ;   in Loop: Header=BB3_20 Depth=1
	cmp	x17, x12
	b.hs	LBB3_19
	b	LBB3_39
LBB3_27:
	mov	w8, #7                          ; =0x7
	b	LBB3_41
LBB3_28:
	mov	w8, #8                          ; =0x8
	b	LBB3_41
LBB3_29:
	mov	w8, #11                         ; =0xb
	b	LBB3_41
LBB3_30:
	mov	x8, #0                          ; =0x0
	add	x11, x0, #80
	sub	w12, w9, #1
	mov	w13, #24                        ; =0x18
	b	LBB3_32
LBB3_31:                                ;   in Loop: Header=BB3_32 Depth=1
	add	x11, x11, #24
	sub	w12, w12, #1
	cmp	x8, x9
	b.eq	LBB3_40
LBB3_32:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_35 Depth 2
	madd	x15, x8, x13, x10
	ldr	x14, [x15, #16]
	add	x8, x8, #1
	cmp	x14, #0
	ccmp	x8, x9, #2, ne
	b.hs	LBB3_31
; %bb.33:                               ;   in Loop: Header=BB3_32 Depth=1
	ldr	x15, [x15, #8]
	mov	x16, x12
	mov	x17, x11
	b	LBB3_35
LBB3_34:                                ;   in Loop: Header=BB3_35 Depth=2
	add	x17, x17, #24
	subs	w16, w16, #1
	b.eq	LBB3_31
LBB3_35:                                ;   Parent Loop BB3_32 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x3, [x17]
	cbz	x3, LBB3_34
; %bb.36:                               ;   in Loop: Header=BB3_35 Depth=2
	ldur	x2, [x17, #-8]
	subs	x4, x15, x2
	ccmp	x4, x3, #0, hs
	b.hs	LBB3_34
; %bb.37:                               ;   in Loop: Header=BB3_35 Depth=2
	subs	x2, x2, x15
	b.lo	LBB3_39
; %bb.38:                               ;   in Loop: Header=BB3_35 Depth=2
	cmp	x2, x14
	b.hs	LBB3_34
LBB3_39:
	mov	w8, #10                         ; =0xa
	b	LBB3_41
LBB3_40:
	sub	w1, w1, #40
	add	x0, x0, #40
	bl	_nvm_crc32
	mov	w8, #12                         ; =0xc
	cmp	w0, w19
	csel	w8, wzr, w8, eq
LBB3_41:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_write_header    ; -- Begin function nvm_v2_write_header
	.globl	_nvm_v2_write_header
	.p2align	2
_nvm_v2_write_header:                   ; @nvm_v2_write_header
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_3
; %bb.1:
	cbz	x1, LBB4_3
; %bb.2:
	ldrb	w8, [x1]
	strb	w8, [x0]
	ldrb	w8, [x1, #1]
	strb	w8, [x0, #1]
	ldrb	w8, [x1, #2]
	strb	w8, [x0, #2]
	ldrb	w8, [x1, #3]
	strb	w8, [x0, #3]
	ldrh	w8, [x1, #4]
	strh	w8, [x0, #4]
	ldrh	w8, [x1, #6]
	strh	w8, [x0, #6]
	ldr	w8, [x1, #8]
	str	w8, [x0, #8]
	ldr	x8, [x1, #16]
	stur	x8, [x0, #12]
	ldr	w8, [x1, #24]
	str	w8, [x0, #20]
	ldr	w8, [x1, #28]
	str	w8, [x0, #24]
	ldr	w8, [x1, #32]
	str	w8, [x0, #28]
	ldr	w8, [x1, #36]
	str	w8, [x0, #32]
	ldr	w8, [x1, #40]
	str	w8, [x0, #36]
LBB4_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_write_section   ; -- Begin function nvm_v2_write_section
	.globl	_nvm_v2_write_section
	.p2align	2
_nvm_v2_write_section:                  ; @nvm_v2_write_section
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_3
; %bb.1:
	cbz	x1, LBB5_3
; %bb.2:
	ldr	w8, [x1]
	str	w8, [x0]
	ldr	w8, [x1, #4]
	str	w8, [x0, #4]
	ldr	x8, [x1, #8]
	str	x8, [x0, #8]
	ldr	x8, [x1, #16]
	str	x8, [x0, #16]
LBB5_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"ok"

l_.str.1:                               ; @.str.1
	.asciz	"truncated"

l_.str.2:                               ; @.str.2
	.asciz	"bad-magic"

l_.str.3:                               ; @.str.3
	.asciz	"unsupported-format-version"

l_.str.4:                               ; @.str.4
	.asciz	"bad-header-size"

l_.str.5:                               ; @.str.5
	.asciz	"unknown-feature-bit"

l_.str.6:                               ; @.str.6
	.asciz	"total-size-mismatch"

l_.str.7:                               ; @.str.7
	.asciz	"reserved-flags-set"

l_.str.8:                               ; @.str.8
	.asciz	"unknown-section-type"

l_.str.9:                               ; @.str.9
	.asciz	"section-out-of-range"

l_.str.10:                              ; @.str.10
	.asciz	"section-overlap"

l_.str.11:                              ; @.str.11
	.asciz	"duplicate-section"

l_.str.12:                              ; @.str.12
	.asciz	"checksum-mismatch"

l_.str.13:                              ; @.str.13
	.asciz	"index-out-of-range"

l_.str.14:                              ; @.str.14
	.asciz	"feature-bits-mismatch"

l_.str.15:                              ; @.str.15
	.asciz	"unknown"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @switch.table.nvm_v2_result_name
l_switch.table.nvm_v2_result_name:
	.quad	l_.str
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	l_.str.5
	.quad	l_.str.6
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.9
	.quad	l_.str.10
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13
	.quad	l_.str.14

.subsections_via_symbols
