from pathlib import Path
import os,sys,json,subprocess,time,hashlib,signal,traceback
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');old=root/'.test_output/darwin-host-closure';state=json.loads((old/'manifest.json').read_text());assert state['status']=='failed';out=root/'.test_output/darwin-host-closure-controls';out.mkdir(exist_ok=False);prefix=Path(state['prefix']);client=Path(state['external'])/'client';base=['/usr/bin/sandbox-exec','-p',state['sandbox_policy']];env=dict(os.environ,PATH=str(prefix/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANO_CC='/usr/bin/cc',NANO_BUILD_CACHE=str(Path(state['external'])/'controls-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',TMPDIR=str(client))
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM','NANO_CFLAGS','NANO_LDFLAGS']:env.pop(key,None)
sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();record=dict(pin=state['pin'],original_failure='I preserve the original failed terminal/archive unchanged under #1173. This is one bounded original-mode native check after actual delegated compiler capture, followed by previously unrun foreign and negative controls. Passing cannot classify the historical refusal.',steps=[],compiler_sha256=sha(prefix/'bin/nanoc'),sandbox_policy=state['sandbox_policy'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,expected=0):
 entry=dict(label=label,argv=list(map(str,base+args)));record['steps'].append(entry);save();t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as z:
  p=subprocess.Popen(entry['argv'],cwd=client,env=env,stdout=a,stderr=z,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=180)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);entry.update(returncode=p.wait(),timeout=True)
 entry['elapsed_seconds']=time.monotonic()-t;save();assert not entry.get('timeout') and (entry['returncode']==0 if expected==0 else entry['returncode']!=0),entry
try:
 run('original-mode-builtin-native',[prefix/'bin/nanoc',client/'input.nano','--target','native','-o',client/'controlled-builtin.native'])
 run('execute-builtin-native',[client/'controlled-builtin.native']);assert (out/'execute-builtin-native.stdout').read_text()=='darwin-host-closure-ok\n'
 run('foreign-compile-module',['nanoc',client/'foreign.nano','--emit-nvm','-o',client/'foreign.nvm'])
 run('foreign-verify-module',[prefix/'bin/nano_vm','--verify-only',client/'foreign.nvm'])
 run('foreign-execute-module',[prefix/'bin/nano_vm',client/'foreign.nvm'])
 run('foreign-compile-native',['nanoc',client/'foreign.nano','--target','native','-o',client/'foreign.native'])
 run('foreign-execute-native',[client/'foreign.native'])
 for kind in ['module','native']:assert (out/('foreign-execute-'+kind+'.stdout')).read_text()=='darwin-external-provider-ok\n'
 key=next(digest for path,digest in state['host_inputs'].items() if 'libfile_source_inputs.' in path);library=prefix/'lib/nanolang/hosts'/key;original=library.read_bytes();protected=client/'protected.nvm';protected.write_bytes(b'preserve-existing-output');env['NANO_CC']='/bin/false'
 try:
  library.write_bytes(original+b'changed')
  run('corrupt-installed-library',[prefix/'bin/nanoc',client/'input.nano','--emit-nvm','-o',protected],expected=1);assert protected.read_bytes()==b'preserve-existing-output'
 finally:library.write_bytes(original)
 absent=library.with_name('same-basename.dylib');library.rename(absent)
 try:
  run('missing-installed-library',[prefix/'bin/nanoc',client/'input.nano','--emit-nvm','-o',protected],expected=1);assert protected.read_bytes()==b'preserve-existing-output'
 finally:absent.rename(library)
 run('restored-installed-library',[prefix/'bin/nanoc',client/'input.nano','--emit-nvm','-o',client/'restored.nvm'])
 record['status']='passed'
except BaseException as error:
 record.update(status='failed',error=repr(error));traceback.print_exc()
finally:
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['original_bootstrap_guards_unchanged']=True;record['host_inputs_unchanged']=all(sha(path)==digest for path,digest in state['host_inputs'].items());save()
sys.exit(0 if record['status']=='passed' else 1)
