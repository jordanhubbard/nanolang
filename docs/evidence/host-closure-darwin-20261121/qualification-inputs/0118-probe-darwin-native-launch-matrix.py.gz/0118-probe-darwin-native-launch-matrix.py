from pathlib import Path
import os,json,subprocess,time
root=Path('/Users/jkh/.worktrees/nanolang/host-closure-20261121');state=json.loads((root/'.test_output/darwin-host-closure/manifest.json').read_text());out=root/'.test_output/darwin-native-launch-matrix';out.mkdir(exist_ok=False);prefix=Path(state['prefix']);client=Path(state['external'])/'client';env=dict(os.environ,PATH=str(prefix/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANO_CC='/usr/bin/cc',NANO_BUILD_CACHE=str(Path(state['external'])/'matrix-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',TMPDIR=str(client))
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM','NANO_CFLAGS','NANO_LDFLAGS','DYLD_INSERT_LIBRARIES','NANO_SYSTEM_TRACE']:env.pop(key,None)
rows=[]
for sandbox in (False,True):
 for session in (False,True):
  label=f'{int(sandbox)}{int(session)}';args=([ '/usr/bin/sandbox-exec','-p',state['sandbox_policy']] if sandbox else [])+[str(prefix/'bin/nanoc'),str(client/'input.nano'),'--target','native','-o',str(client/('cell'+label+'.native'))];t=time.monotonic()
  p=subprocess.Popen(args,cwd=client,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=session)
  process=dict(pid=p.pid,pgid=os.getpgid(p.pid),sid=os.getsid(p.pid));stdout,stderr=p.communicate(timeout=180);rows.append(dict(sandbox=sandbox,start_new_session=session,argv=args,returncode=p.returncode,elapsed_seconds=time.monotonic()-t,stdout=stdout,stderr=stderr,**process));(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
