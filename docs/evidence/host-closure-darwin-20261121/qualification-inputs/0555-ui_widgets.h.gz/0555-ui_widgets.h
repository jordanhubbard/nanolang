#ifndef UI_WIDGETS_H
#define UI_WIDGETS_H

#include <stdint.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "../../src/runtime/dyn_array.h"

/* My array widgets require canonical string arrays and counts in
 * [0, min(length, INT_MAX)]. Scroll offsets must be in [0, count].
 * Invalid arrays/offsets or null renderer/font return -1 before SDL calls.
 * I skip null entries. Geometry and input scaling require a separate audit. */

/* My slider/progress bars clamp fractions to [0,1], with NaN mapped to zero.
 * They require positive SDL-int dimensions and representable endpoints (plus
 * four pixels of margin for the slider handle). Invalid geometry or a null
 * renderer skips drawing: sliders return the clamped value, seek bars -1. */

/* My spinner returns the unchanged value for an inverted range. Otherwise I
 * clamp the initial value to its range. Invalid geometry skips drawing and
 * returns that value; I require width >= 40, height >= 10 and SDL-int endpoints.
 * Unrepresentable centered text is skipped, with texture/surface cleanup. */

/* My panels and labels clamp RGBA channels to [0,255]. Invalid panel geometry
 * skips drawing. Labels reject unrepresentable coordinates/endpoints and
 * nonpositive surface dimensions, releasing any surface already created. */

/* My text buttons reject invalid geometry or null renderers before interaction.
 * Unrepresentable centered text is skipped with surface/texture cleanup; the
 * button's valid hit area still determines its click result. */

/* My checkbox/radio controls validate their 20-pixel bounds before interaction
 * (with one pixel of margin for radio borders). Invalid geometry preserves
 * checkbox state or returns no radio click. Unplaceable labels are skipped
 * with cleanup; valid controls retain their normal interaction behavior. */

/* My time display formats signed MM:SS with unbounded minute digits over the
 * int64 range (negative durations have one leading minus). It uses my label
 * geometry/color checks and cleanup contract. */

/* My tooltips skip invalid hit areas, failed text measurements and
 * unrepresentable padded placement. Rendered surfaces are checked separately
 * and released when their placement is rejected. */

/* My scrollable list requires width >= 10; the file selector requires >= 16.
 * Both reject invalid SDL geometry before interaction and skip unplaceable
 * row text with cleanup. The scrollable list restores the caller's clip state. */

/* My dropdown requires at least 30x8 pixels and representable SDL endpoints,
 * including its expanded rows when open. Invalid geometry returns -1 before
 * interaction; unplaceable text is skipped with cleanup. */

/* My syntax-colored code display requires valid geometry (at least 10x5),
 * scroll in [0,INT_MAX], line height in [1,INT_MAX], and source < INT_MAX bytes.
 * I preserve complete tokens and restore clipping even if allocation fails.
 * Failed measurements do not advance the pen. Multiline layout remains work. */

/* My ANSI viewer uses the same geometry/source/scroll limits. Numeric SGR
 * overflow or malformed parameters leave colors unchanged; supported numeric
 * parameters are applied in sequence. This is not a complete terminal parser.
 * Both viewers saturate horizontal advances beyond SDL's coordinate range. */

/* My code-editor renderer requires at least 56x5 pixels, the viewer's source
 * and scroll limits, cursor row in [-1,INT_MAX] and column in [0,INT_MAX].
 * Tokens and measured prefixes are complete; allocation failure stops drawing
 * and restores clipping. This renderer does not itself implement editing. */

// Update widget mouse state - CALL THIS ONCE PER FRAME before rendering widgets!
// This allows all widgets to see the same mouse transition
void nl_ui_update_mouse_state();

// Set UI scale factor used for input hit-testing (mouse coordinates are divided by this value).
// I use 1.0 for non-finite scales or scales <= 0.01. Scaled mouse coordinates
// saturate to the host int range before conversion, truncating toward zero.
void nl_ui_set_scale(double scale);

// Create a button and check for mouse interaction
// Returns: 1 if clicked (mouse released over button), 0 otherwise
// Uses SDL mouse state internally
int64_t nl_ui_button(SDL_Renderer* renderer, TTF_Font* font,
                     const char* text, int64_t x, int64_t y, int64_t w, int64_t h);

// Draw a label (just text)
void nl_ui_label(SDL_Renderer* renderer, TTF_Font* font,
                 const char* text, int64_t x, int64_t y,
                 int64_t r, int64_t g, int64_t b, int64_t a);

// Slider widget - horizontal slider control
// Returns: new value (0.0 to 1.0)
// Uses SDL mouse state internally
double nl_ui_slider(SDL_Renderer* renderer, int64_t x, int64_t y, int64_t w, int64_t h,
                    double value);

// Draw a progress bar
void nl_ui_progress_bar(SDL_Renderer* renderer, int64_t x, int64_t y, int64_t w, int64_t h,
                        double progress);

// Checkbox widget - toggleable boolean state
// Returns: new state (1 for checked, 0 for unchecked)
// checked parameter is the current state
int64_t nl_ui_checkbox(SDL_Renderer* renderer, TTF_Font* font,
                       const char* label, int64_t x, int64_t y, int64_t checked);

// Radio button widget - selectable option in a group
// Returns: 1 if this button was clicked (should become selected), 0 otherwise
// selected parameter indicates if this button is currently selected
int64_t nl_ui_radio_button(SDL_Renderer* renderer, TTF_Font* font,
                           const char* label, int64_t x, int64_t y, int64_t selected);

// Panel widget - draws a styled container for grouping widgets
// Just draws the panel background/border - you place widgets inside manually
void nl_ui_panel(SDL_Renderer* renderer, int64_t x, int64_t y, int64_t w, int64_t h,
                 int64_t r, int64_t g, int64_t b, int64_t a);

// Scrollable list widget - displays a list of items with scrolling
// Returns index of clicked item, or -1 if none
int64_t nl_ui_scrollable_list(SDL_Renderer* renderer, TTF_Font* font,
                               DynArray* items, int64_t item_count,
                               int64_t x, int64_t y, int64_t w, int64_t h,
                               int64_t scroll_offset, int64_t selected_index);

// Time display widget - shows time in MM:SS format
void nl_ui_time_display(SDL_Renderer* renderer, TTF_Font* font,
                        int64_t seconds, int64_t x, int64_t y,
                        int64_t r, int64_t g, int64_t b, int64_t a);

// Seekable progress bar - interactive progress bar
// Returns new position if clicked, or -1.0 if not
double nl_ui_seekable_progress_bar(SDL_Renderer* renderer, int64_t x, int64_t y, int64_t w, int64_t h,
                                    double progress);

/* Single-line UTF-8 input. I mutate an ELEM_U8 array up to buffer_size bytes,
 * remove one code point on Backspace and return 1 when Enter is observed.
 * Invalid arrays/UTF-8/geometry make no drawing or event-consumption calls. */
int64_t nl_ui_text_input(SDL_Renderer* renderer, TTF_Font* font,
                          DynArray* buffer, int64_t buffer_size,
                          int64_t x, int64_t y, int64_t w, int64_t h,
                          int64_t is_focused);

// Dropdown/Combo box widget - shows selected item, expands when clicked
// Returns index of newly selected item, or -1 if no change
int64_t nl_ui_dropdown(SDL_Renderer* renderer, TTF_Font* font,
                       DynArray* items, int64_t item_count,
                       int64_t x, int64_t y, int64_t w, int64_t h,
                       int64_t selected_index, int64_t is_open);

// Number spinner widget - increment/decrement numeric value with +/- buttons
// Returns new value (clamped between min_val and max_val)
int64_t nl_ui_number_spinner(SDL_Renderer* renderer, TTF_Font* font,
                              int64_t value, int64_t min_val, int64_t max_val,
                              int64_t x, int64_t y, int64_t w, int64_t h);

// Tooltip widget - shows informational text when hovering over a widget area
// Call this after drawing the widget you want to add a tooltip to
void nl_ui_tooltip(SDL_Renderer* renderer, TTF_Font* font,
                   const char* text, int64_t widget_x, int64_t widget_y,
                   int64_t widget_w, int64_t widget_h);

// File selector widget - browse and select files from a directory
int64_t nl_ui_file_selector(SDL_Renderer* renderer, TTF_Font* font,
                             DynArray* files, int64_t file_count,
                             int64_t x, int64_t y, int64_t w, int64_t h,
                             int64_t scroll_offset, int64_t selected_index);

// Image button widget - clickable button with image texture
// Returns: 1 if button was clicked (mouse released over button), 0 otherwise
// Handles hover effect and click detection
// Parameters:
//   renderer: SDL renderer
//   texture_id: SDL texture ID (from SDL_image, cast to int64_t)
//   x, y: button position
//   w, h: button size (image will be scaled to fit)
//   hover_brightness: multiplier clamped to [0,2]; non-finite means 1.
// I brighten with an additive texture pass where supported; color modulation
// handles dimming. I restore saved texture settings and pressed-overlay blend
// mode through SDL calls. Invalid geometry or failed texture queries returns 0.
int64_t nl_ui_image_button(SDL_Renderer* renderer, int64_t texture_id,
                             int64_t x, int64_t y, int64_t w, int64_t h,
                             double hover_brightness);

// Code display widget - syntax-highlighted code viewer
// Shows NanoLang source code with syntax highlighting and scrolling
// Parameters:
//   renderer: SDL renderer
//   font: TTF font for text rendering
//   code: source code string to display
//   x, y, w, h: display area rectangle
//   scroll_offset: number of lines to scroll from top
//   line_height: height of each line in pixels (typically font size + 4-6px)
void nl_ui_code_display(SDL_Renderer* renderer, TTF_Font* font,
                         const char* code, int64_t x, int64_t y,
                         int64_t w, int64_t h, int64_t scroll_offset,
                         int64_t line_height);

// Code display widget - ANSI-colored code viewer
// Expects ANSI color codes (e.g., "\x1b[35m") in the input string.
void nl_ui_code_display_ansi(SDL_Renderer* renderer, TTF_Font* font,
                             const char* code, int64_t x, int64_t y,
                             int64_t w, int64_t h, int64_t scroll_offset,
                             int64_t line_height);

// Code editor widget - syntax-highlighted code with line numbers and cursor
void nl_ui_code_editor(SDL_Renderer* renderer, TTF_Font* font,
                       const char* code, int64_t x, int64_t y,
                       int64_t w, int64_t h, int64_t scroll_offset,
                       int64_t line_height, int64_t cursor_row, int64_t cursor_col);

#endif // UI_WIDGETS_H
