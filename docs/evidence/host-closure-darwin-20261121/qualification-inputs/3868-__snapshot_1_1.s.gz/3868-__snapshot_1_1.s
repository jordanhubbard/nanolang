	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_affine_has_complete_unions ; -- Begin function nvm_affine_has_complete_unions
	.globl	_nvm_affine_has_complete_unions
	.p2align	2
_nvm_affine_has_complete_unions:        ; @nvm_affine_has_complete_unions
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_8
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #16]
	cbz	w9, LBB0_7
; %bb.2:
	mov	x10, #0                         ; =0x0
	ldr	x11, [x8, #8]
	b	LBB0_4
LBB0_3:                                 ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x10, #1
	cmp	x9, x10
	b.eq	LBB0_7
LBB0_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x11], #16
	cmp	w12, #2
	b.ne	LBB0_3
; %bb.5:                                ;   in Loop: Header=BB0_4 Depth=1
	ldr	x12, [x8, #24]
	ldrb	w12, [x12, x10]
	tbz	w12, #0, LBB0_3
; %bb.6:
	mov	w0, #1                          ; =0x1
	ret
LBB0_7:
	mov	w0, #0                          ; =0x0
LBB0_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_state_free  ; -- Begin function nvm_affine_state_free
	.globl	_nvm_affine_state_free
	.p2align	2
_nvm_affine_state_free:                 ; @nvm_affine_state_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_10
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x0, [x0, #24]
	cbz	x0, LBB1_6
; %bb.2:
	ldr	w8, [x19, #32]
	cbz	w8, LBB1_6
; %bb.3:
	mov	x20, #0                         ; =0x0
	mov	w21, #32                        ; =0x20
LBB1_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #24]
	ldr	x0, [x8, x21]
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x19, #32]
	add	x21, x21, #56
	cmp	x20, x8
	b.lo	LBB1_4
; %bb.5:
	ldr	x0, [x19, #24]
LBB1_6:
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #8]
	bl	_free
	ldr	x20, [x19]
	cbz	x20, LBB1_9
; %bb.7:
	ldr	w8, [x20]
	subs	w8, w8, #1
	str	w8, [x20]
	b.ne	LBB1_9
; %bb.8:
	add	x0, x20, #8
	bl	_nvm_v2_layouts_free
	ldr	x0, [x20, #24]
	bl	_free
	ldr	x0, [x20, #40]
	bl	_free
	ldr	x0, [x20, #48]
	bl	_free
	mov	x0, x20
	bl	_free
LBB1_9:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB1_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_state_create ; -- Begin function nvm_affine_state_create
	.globl	_nvm_affine_state_create
	.p2align	2
_nvm_affine_state_create:               ; @nvm_affine_state_create
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_7
; %bb.1:
	ldr	w8, [x0, #304]
	cbz	w8, LBB2_6
; %bb.2:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	b.hs	LBB2_6
; %bb.3:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x1
	mov	x25, x2
	sub	x1, x29, #81
	mov	x21, x0
	bl	_nvm_ownership_contracts_validate
	cbz	w0, LBB2_8
LBB2_4:
	mov	x0, #0                          ; =0x0
LBB2_5:
	add	sp, sp, #2128
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB2_6:
	mov	x0, #0                          ; =0x0
LBB2_7:
	ret
LBB2_8:
	mov	w0, #1                          ; =0x1
	mov	w1, #200                        ; =0xc8
	bl	_calloc
	cbz	x0, LBB2_5
; %bb.9:
	mov	w23, #1                         ; =0x1
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #80                         ; =0x50
	bl	_calloc
	mov	x20, x0
	mov	x0, x19
	str	x20, [x19]
	cbz	x20, LBB2_21
; %bb.10:
	str	w23, [x20]
	str	x21, [x20, #64]
	str	w22, [x20, #72]
	str	x23, [x0, #56]
	add	x1, sp, #72
	mov	x0, x21
	bl	_nvm_ownership_effect_types
	cmp	w0, #13
	b.eq	LBB2_12
; %bb.11:
	cbnz	w0, LBB2_20
LBB2_12:
	cbnz	w0, LBB2_16
; %bb.13:
	ldr	w8, [sp, #72]
	cbz	w8, LBB2_16
; %bb.14:
	mov	w0, #2052                       ; =0x804
	bl	_malloc
	str	x0, [x20, #48]
	cbz	x0, LBB2_20
; %bb.15:
	add	x1, sp, #72
	mov	w2, #2052                       ; =0x804
	bl	_memcpy
LBB2_16:
	ldr	x0, [x21, #312]
	ldr	w1, [x21, #320]
	add	x2, x20, #8
	bl	_nvm_v2_layouts_decode
	cbnz	w0, LBB2_20
; %bb.17:
	ldr	x1, [x21, #296]
	ldr	w2, [x21, #304]
	add	x0, sp, #48
	bl	_nvm_v2_cursor_init
	add	x0, sp, #48
	add	x1, sp, #44
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_20
; %bb.18:
	add	x0, sp, #48
	add	x1, sp, #40
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_20
; %bb.19:
	ldr	w1, [sp, #40]
	add	x0, sp, #48
	add	x2, sp, #32
	bl	_nvm_v2_take
	cbz	w0, LBB2_22
LBB2_20:
	mov	x0, x19
	bl	_nvm_affine_state_free
	b	LBB2_4
LBB2_21:
	bl	_free
	b	LBB2_4
LBB2_22:
	ldr	w21, [sp, #40]
	cmp	w21, #1
	csinc	w0, w21, wzr, hi
	bl	_malloc
	str	x0, [x20, #24]
	cbz	x0, LBB2_20
; %bb.23:
	ldr	x1, [sp, #32]
	mov	x2, x21
	bl	_memcpy
	add	x0, sp, #48
	bl	_nvm_v2_align4
	cbnz	w0, LBB2_20
; %bb.24:
	add	x0, sp, #48
	add	x1, sp, #44
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_20
; %bb.25:
	mov	w21, #0                         ; =0x0
	strh	wzr, [sp, #30]
	b	LBB2_27
LBB2_26:                                ;   in Loop: Header=BB2_27 Depth=1
	add	w21, w21, #1
	cmp	w21, w22
	b.hi	LBB2_43
LBB2_27:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_39 Depth 2
	add	x0, sp, #48
	add	x1, sp, #28
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_20
; %bb.28:                               ;   in Loop: Header=BB2_27 Depth=1
	add	x0, sp, #48
	add	x1, sp, #30
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_20
; %bb.29:                               ;   in Loop: Header=BB2_27 Depth=1
	add	x0, sp, #48
	add	x1, sp, #16
	bl	_slot_read
	cbz	w0, LBB2_20
; %bb.30:                               ;   in Loop: Header=BB2_27 Depth=1
	cmp	w21, w22
	b.ne	LBB2_34
; %bb.31:                               ;   in Loop: Header=BB2_27 Depth=1
	ldrb	w8, [sp, #16]
	cbz	w8, LBB2_33
; %bb.32:                               ;   in Loop: Header=BB2_27 Depth=1
	ldr	x1, [sp, #16]
	mov	x0, x20
	bl	_supported
	cbz	w0, LBB2_20
LBB2_33:                                ;   in Loop: Header=BB2_27 Depth=1
	ldrh	w23, [sp, #28]
	strh	w23, [x20, #56]
	ldrh	w8, [sp, #30]
	strh	w8, [x20, #58]
	ldr	x8, [sp, #16]
	str	x8, [x20, #32]
	cmp	w23, #1
	csinc	w0, w23, wzr, hi
	mov	w1, #8                          ; =0x8
	bl	_calloc
	str	x0, [x20, #40]
	cbnz	x0, LBB2_35
	b	LBB2_20
LBB2_34:                                ;   in Loop: Header=BB2_27 Depth=1
	ldrh	w23, [sp, #28]
LBB2_35:                                ;   in Loop: Header=BB2_27 Depth=1
	cbz	w23, LBB2_26
; %bb.36:                               ;   in Loop: Header=BB2_27 Depth=1
	mov	x23, #0                         ; =0x0
	b	LBB2_39
LBB2_37:                                ;   in Loop: Header=BB2_39 Depth=2
	cbz	w0, LBB2_20
LBB2_38:                                ;   in Loop: Header=BB2_39 Depth=2
	add	x23, x23, #1
	ldrh	w8, [sp, #28]
	cmp	x23, x8
	b.hs	LBB2_26
LBB2_39:                                ;   Parent Loop BB2_27 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #48
	add	x1, sp, #8
	bl	_slot_read
	cmp	w21, w22
	b.ne	LBB2_37
; %bb.40:                               ;   in Loop: Header=BB2_39 Depth=2
	cbz	w0, LBB2_37
; %bb.41:                               ;   in Loop: Header=BB2_39 Depth=2
	ldr	x1, [sp, #8]
	mov	x0, x20
	bl	_supported
	tbz	w0, #0, LBB2_20
; %bb.42:                               ;   in Loop: Header=BB2_39 Depth=2
	ldr	x8, [x20, #40]
	ldr	x9, [sp, #8]
	str	x9, [x8, x23, lsl #3]
	b	LBB2_38
LBB2_43:
	str	w25, [x19, #32]
	ldrh	w26, [x20, #56]
	cmp	w26, #0
	csinc	x0, x26, xzr, ne
	lsl	x23, x26, #1
	mov	w8, #2                          ; =0x2
	csel	x22, x8, x23, eq
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x21, x0
	str	x0, [x19, #8]
	mov	x0, x22
	bl	_malloc
	mov	x24, x0
	str	x0, [x19, #16]
	cmp	w25, #1
	csinc	w0, w25, wzr, hi
	mov	w1, #56                         ; =0x38
	bl	_calloc
	str	x0, [x19, #24]
	cbz	x21, LBB2_20
; %bb.44:
	cbz	x24, LBB2_20
; %bb.45:
	mov	x22, x0
	cbz	x0, LBB2_20
; %bb.46:
	cbz	w26, LBB2_48
; %bb.47:
	mov	x0, x24
	mov	w1, #255                        ; =0xff
	mov	x2, x23
	bl	_memset
LBB2_48:
	ldrh	w11, [sp, #30]
	cbz	x11, LBB2_54
; %bb.49:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20, #40]
	add	x10, x10, #4
	lsl	x12, x11, #6
	sub	x11, x12, x11, lsl #3
	mov	w12, #1                         ; =0x1
	movi	d0, #0x000000ffffffff
	b	LBB2_52
LBB2_50:                                ;   in Loop: Header=BB2_52 Depth=1
	add	x15, x22, x8
	strb	w12, [x15]
	stur	wzr, [x15, #1]
	str	wzr, [x15, #4]
	str	d0, [x15, #8]
	str	x12, [x15, #16]
	strh	w9, [x15, #24]
	strh	wzr, [x15, #26]
	str	w14, [x15, #28]
	str	xzr, [x15, #32]
	stp	wzr, w14, [x15, #40]
	stp	w13, wzr, [x15, #48]
LBB2_51:                                ;   in Loop: Header=BB2_52 Depth=1
	add	x10, x10, #8
	add	x9, x9, #1
	add	x8, x8, #56
	cmp	x11, x8
	b.eq	LBB2_54
LBB2_52:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x10, #-3]
	ldr	w14, [x10]
	strb	w12, [x21, x9]
	cbz	w13, LBB2_51
; %bb.53:                               ;   in Loop: Header=BB2_52 Depth=1
	cmp	w25, w9
	b.hi	LBB2_50
	b	LBB2_20
LBB2_54:
	mov	x0, x19
	b	LBB2_5
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function slot_read
_slot_read:                             ; @slot_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
	bl	_nvm_v2_u8
	cbnz	w0, LBB3_3
; %bb.1:
	add	x1, x20, #1
	mov	x0, x19
	bl	_nvm_v2_u8
	cbnz	w0, LBB3_3
; %bb.2:
	add	x1, sp, #14
	mov	x0, x19
	bl	_nvm_v2_u16
	cbz	w0, LBB3_5
LBB3_3:
	mov	w0, #0                          ; =0x0
LBB3_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB3_5:
	add	x1, x20, #4
	mov	x0, x19
	bl	_nvm_v2_u32
	cmp	w0, #0
	cset	w0, eq
	b	LBB3_4
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function supported
_supported:                             ; @supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	and	w8, w1, #0xff
	lsr	x19, x1, #32
	tst	x1, #0xff00
	b.ne	LBB4_5
; %bb.1:
	cmp	w8, #7
	b.ne	LBB4_5
; %bb.2:
	ldr	x9, [x0, #48]
	cbz	x9, LBB4_5
; %bb.3:
	sub	w10, w8, #1
	mov	w8, #1                          ; =0x1
	cmp	w10, #4
	b.lo	LBB4_11
; %bb.4:
	ldr	w9, [x9]
	cmp	w9, w19
	b.ls	LBB4_12
	b	LBB4_11
LBB4_5:
	sub	w9, w8, #1
	cmp	w9, #4
	b.lo	LBB4_10
; %bb.6:
	mov	w9, #-1                         ; =0xffffffff
	cmp	x19, x9
	b.ne	LBB4_8
; %bb.7:
	cmp	w8, #5
	b.eq	LBB4_10
LBB4_8:
	mov	w9, #-1                         ; =0xffffffff
	cmp	x19, x9
	b.eq	LBB4_12
; %bb.9:
	cmp	w8, #8
	b.ne	LBB4_12
LBB4_10:
	mov	w8, #1                          ; =0x1
LBB4_11:
	mov	x0, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB4_12:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB4_11
; %bb.13:
	and	x9, x1, #0xffff
	cmp	x9, #10
	b.ne	LBB4_11
; %bb.14:
	ldr	w8, [x0, #16]
	cmp	w8, w19
	b.ls	LBB4_33
; %bb.15:
	ldr	x8, [x0, #8]
	lsl	x9, x19, #4
	ldrb	w9, [x8, x9]
	cmp	w9, #2
	b.ne	LBB4_33
; %bb.16:
	cbnz	x19, LBB4_18
; %bb.17:
	mov	w1, #0                          ; =0x0
	b	LBB4_32
LBB4_18:
	lsr	x9, x1, #35
	cbnz	x9, LBB4_20
; %bb.19:
	mov	w1, #0                          ; =0x0
	b	LBB4_30
LBB4_20:
	lsr	x9, x1, #38
	cbnz	x9, LBB4_22
; %bb.21:
	mov	w1, #0                          ; =0x0
	b	LBB4_27
LBB4_22:
	movi.2d	v0, #0000000000000000
	and	x9, x19, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x10, x8
	mov	x11, x9
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB4_23:                                ; =>This Inner Loop Header: Depth=1
	add	x12, x10, #16
	ldr	b26, [x10]
	ld1.b	{ v26 }[1], [x12]
	add	x12, x10, #32
	ld1.b	{ v26 }[2], [x12]
	add	x12, x10, #48
	ld1.b	{ v26 }[3], [x12]
	add	x12, x10, #64
	ld1.b	{ v26 }[4], [x12]
	add	x12, x10, #80
	ld1.b	{ v26 }[5], [x12]
	add	x12, x10, #96
	ld1.b	{ v26 }[6], [x12]
	add	x12, x10, #112
	ld1.b	{ v26 }[7], [x12]
	add	x12, x10, #144
	ldur	b28, [x10, #128]
	ld1.b	{ v28 }[1], [x12]
	add	x12, x10, #160
	ld1.b	{ v28 }[2], [x12]
	add	x12, x10, #176
	ld1.b	{ v28 }[3], [x12]
	add	x12, x10, #192
	ld1.b	{ v28 }[4], [x12]
	add	x12, x10, #208
	ld1.b	{ v28 }[5], [x12]
	add	x12, x10, #224
	ld1.b	{ v28 }[6], [x12]
	add	x12, x10, #240
	ld1.b	{ v28 }[7], [x12]
	add	x12, x10, #272
	ldr	b27, [x10, #256]
	ld1.b	{ v27 }[1], [x12]
	add	x12, x10, #288
	ld1.b	{ v27 }[2], [x12]
	add	x12, x10, #304
	ld1.b	{ v27 }[3], [x12]
	add	x12, x10, #320
	ld1.b	{ v27 }[4], [x12]
	add	x12, x10, #336
	ld1.b	{ v27 }[5], [x12]
	add	x12, x10, #352
	ld1.b	{ v27 }[6], [x12]
	add	x12, x10, #368
	ld1.b	{ v27 }[7], [x12]
	add	x12, x10, #400
	ldr	b29, [x10, #384]
	ld1.b	{ v29 }[1], [x12]
	add	x12, x10, #416
	ld1.b	{ v29 }[2], [x12]
	add	x12, x10, #432
	ld1.b	{ v29 }[3], [x12]
	add	x12, x10, #448
	ld1.b	{ v29 }[4], [x12]
	add	x12, x10, #464
	ld1.b	{ v29 }[5], [x12]
	add	x12, x10, #480
	ld1.b	{ v29 }[6], [x12]
	add	x12, x10, #496
	ld1.b	{ v29 }[7], [x12]
	add	x12, x10, #528
	ldr	b30, [x10, #512]
	ld1.b	{ v30 }[1], [x12]
	add	x12, x10, #544
	ld1.b	{ v30 }[2], [x12]
	add	x12, x10, #560
	ld1.b	{ v30 }[3], [x12]
	add	x12, x10, #576
	ld1.b	{ v30 }[4], [x12]
	add	x12, x10, #592
	ld1.b	{ v30 }[5], [x12]
	add	x12, x10, #608
	ld1.b	{ v30 }[6], [x12]
	add	x12, x10, #624
	ld1.b	{ v30 }[7], [x12]
	add	x12, x10, #656
	ldr	b31, [x10, #640]
	ld1.b	{ v31 }[1], [x12]
	add	x12, x10, #672
	ld1.b	{ v31 }[2], [x12]
	add	x12, x10, #688
	ld1.b	{ v31 }[3], [x12]
	add	x12, x10, #704
	ld1.b	{ v31 }[4], [x12]
	add	x12, x10, #720
	ld1.b	{ v31 }[5], [x12]
	add	x12, x10, #736
	ld1.b	{ v31 }[6], [x12]
	add	x12, x10, #752
	ld1.b	{ v31 }[7], [x12]
	add	x12, x10, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x10, #768]
	ld1.b	{ v26 }[1], [x12]
	add	x12, x10, #800
	ld1.b	{ v26 }[2], [x12]
	add	x12, x10, #816
	ld1.b	{ v26 }[3], [x12]
	add	x12, x10, #832
	ld1.b	{ v26 }[4], [x12]
	add	x12, x10, #848
	ld1.b	{ v26 }[5], [x12]
	add	x12, x10, #864
	ld1.b	{ v26 }[6], [x12]
	add	x12, x10, #880
	ld1.b	{ v26 }[7], [x12]
	add	x12, x10, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x10, #896]
	ld1.b	{ v29 }[1], [x12]
	add	x12, x10, #928
	ld1.b	{ v29 }[2], [x12]
	add	x12, x10, #944
	ld1.b	{ v29 }[3], [x12]
	add	x12, x10, #960
	ld1.b	{ v29 }[4], [x12]
	add	x12, x10, #976
	ld1.b	{ v29 }[5], [x12]
	add	x12, x10, #992
	ld1.b	{ v29 }[6], [x12]
	add	x12, x10, #1008
	ld1.b	{ v29 }[7], [x12]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x10, x10, #1024
	subs	x11, x11, #64
	b.ne	LBB4_23
; %bb.24:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w10, s0
	cmp	x19, x9
	b.ne	LBB4_26
; %bb.25:
	mov	x1, x10
	b	LBB4_32
LBB4_26:
	tst	x1, #0x3800000000
	mov	x1, x10
	b.eq	LBB4_30
LBB4_27:
	mov	x11, x9
	and	x9, x19, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x10, x11, x9
	add	x11, x8, x11, lsl #4
	add	x11, x11, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB4_28:                                ; =>This Inner Loop Header: Depth=1
	sub	x12, x11, #48
	sub	x13, x11, #32
	sub	x14, x11, #16
	add	x15, x11, #16
	add	x16, x11, #32
	add	x17, x11, #48
	ldur	b4, [x11, #-64]
	ld1.b	{ v4 }[1], [x12]
	ld1.b	{ v4 }[2], [x13]
	ld1.b	{ v4 }[3], [x14]
	ld1.b	{ v4 }[4], [x11]
	ld1.b	{ v4 }[5], [x15]
	ld1.b	{ v4 }[6], [x16]
	ld1.b	{ v4 }[7], [x17]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x11, x11, #128
	adds	x10, x10, #8
	b.ne	LBB4_28
; %bb.29:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x19, x9
	b.eq	LBB4_32
LBB4_30:
	sub	x10, x19, x9
	add	x8, x8, x9, lsl #4
LBB4_31:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x8], #16
	cmp	w9, #2
	cinc	w1, w1, eq
	subs	x10, x10, #1
	b.ne	LBB4_31
LBB4_32:
	ldr	x0, [x0, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbz	w0, LBB4_34
LBB4_33:
	mov	w8, #0                          ; =0x0
	b	LBB4_11
LBB4_34:
	ldr	w8, [sp, #4]
	cmp	w8, w19
	cset	w8, eq
	b	LBB4_11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_state_clone ; -- Begin function nvm_affine_state_clone
	.globl	_nvm_affine_state_clone
	.p2align	2
_nvm_affine_state_clone:                ; @nvm_affine_state_clone
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x0, LBB5_13
; %bb.1:
	mov	x20, x0
	ldr	x21, [x0]
	ldr	w22, [x21]
	cmn	w22, #1
	b.eq	LBB5_13
; %bb.2:
	mov	w0, #1                          ; =0x1
	mov	w1, #200                        ; =0xc8
	bl	_calloc
	mov	x19, x0
	cbz	x0, LBB5_14
; %bb.3:
	str	x21, [x19]
	add	w8, w22, #1
	str	w8, [x21]
	ldr	d0, [x20, #32]
	ldr	w25, [x20, #32]
	str	d0, [x19, #32]
	ldp	w8, w9, [x20, #40]
	stp	w8, w9, [x19, #40]
	ldr	q0, [x20, #48]
	str	q0, [x19, #48]
	ldrh	w8, [x20, #64]
	strh	w8, [x19, #64]
	ldur	q0, [x20, #72]
	ldur	q1, [x20, #88]
	ldur	q2, [x20, #104]
	ldur	q3, [x20, #120]
	stur	q3, [x19, #120]
	stur	q2, [x19, #104]
	stur	q1, [x19, #88]
	stur	q0, [x19, #72]
	ldur	q0, [x20, #136]
	ldur	q1, [x20, #152]
	ldur	q2, [x20, #168]
	ldur	q3, [x20, #184]
	stur	q3, [x19, #184]
	stur	q2, [x19, #168]
	stur	q1, [x19, #152]
	ldrh	w21, [x21, #56]
	cmp	w21, #0
	csinc	x0, x21, xzr, ne
	stur	q0, [x19, #136]
	lsl	x22, x21, #1
	mov	w8, #2                          ; =0x2
	csel	x23, x8, x22, eq
	bl	_malloc
	mov	x24, x0
	str	x0, [x19, #8]
	mov	x0, x23
	bl	_malloc
	mov	x23, x0
	str	x0, [x19, #16]
	cmp	w25, #1
	csinc	w0, w25, wzr, hi
	mov	w1, #56                         ; =0x38
	bl	_calloc
	str	x0, [x19, #24]
	cbz	x24, LBB5_12
; %bb.4:
	cbz	x23, LBB5_12
; %bb.5:
	cbz	x0, LBB5_12
; %bb.6:
	mov	x26, x0
	ldr	x1, [x20, #8]
	mov	x0, x24
	mov	x2, x21
	bl	_memcpy
	ldr	x1, [x20, #16]
	mov	x0, x23
	mov	x2, x22
	bl	_memcpy
	cbz	w25, LBB5_14
; %bb.7:
	ldr	x8, [x20, #24]
	add	x22, x26, #32
	add	x23, x8, #40
	b	LBB5_10
LBB5_8:                                 ;   in Loop: Header=BB5_10 Depth=1
	mov	x21, x0
	ldur	x1, [x23, #-8]
	mov	x2, x20
	bl	_memcpy
	str	x21, [x22]
LBB5_9:                                 ;   in Loop: Header=BB5_10 Depth=1
	add	x22, x22, #56
	add	x23, x23, #56
	subs	x25, x25, #1
	b.eq	LBB5_14
LBB5_10:                                ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x23, #-40]
	ldur	q1, [x23, #-24]
	ldr	x8, [x23, #8]
	ldur	q2, [x23, #-8]
	stp	q1, q2, [x22, #-16]
	str	x8, [x22, #16]
	stur	q0, [x22, #-32]
	str	xzr, [x22]
	ldrh	w8, [x23]
	cbz	x8, LBB5_9
; %bb.11:                               ;   in Loop: Header=BB5_10 Depth=1
	lsl	x20, x8, #1
	mov	x0, x20
	bl	_malloc
	cbnz	x0, LBB5_8
LBB5_12:
	mov	x0, x19
	bl	_nvm_affine_state_free
LBB5_13:
	mov	x19, #0                         ; =0x0
LBB5_14:
	mov	x0, x19
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_handler_enter ; -- Begin function nvm_affine_handler_enter
	.globl	_nvm_affine_handler_enter
	.p2align	2
_nvm_affine_handler_enter:              ; @nvm_affine_handler_enter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_4
; %bb.1:
	ldr	w8, [x0, #36]
	cbnz	w8, LBB6_3
; %bb.2:
	ldrb	w8, [x0, #40]
	tbz	w8, #0, LBB6_5
LBB6_3:
	mov	x0, #0                          ; =0x0
LBB6_4:
	ret
LBB6_5:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #2064
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w2, w9
	b.hi	LBB6_14
; %bb.6:
	ldrb	w9, [x0, #41]
	cmp	w9, #1
	b.ne	LBB6_8
; %bb.7:
	ldrh	w9, [x0, #42]
	cmp	w2, w9
	b.lo	LBB6_14
LBB6_8:
	ldr	w9, [x0, #32]
	cbz	w9, LBB6_12
; %bb.9:
	ldr	x10, [x0, #24]
LBB6_10:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #56
	tbnz	w11, #0, LBB6_14
; %bb.11:                               ;   in Loop: Header=BB6_10 Depth=1
	subs	x9, x9, #1
	b.ne	LBB6_10
LBB6_12:
	mov	x20, x0
	mov	x19, x2
	ldr	x0, [x8, #64]
	mov	x2, sp
	bl	_nvm_ownership_effect
	cbnz	w0, LBB6_14
; %bb.13:
	ldrh	w8, [sp, #4]
	ldr	x9, [x20]
	ldrh	w11, [x9, #56]
	sub	w11, w11, w19
	cmp	w11, w8
	b.ge	LBB6_16
LBB6_14:
	mov	x0, #0                          ; =0x0
LBB6_15:
	add	sp, sp, #2064
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB6_16:
	mov	x0, x20
	cbz	w8, LBB6_28
; %bb.17:
	mov	x10, x19
	mov	w11, #0                         ; =0x0
	mov	x12, sp
	add	x12, x12, #16
	ldr	x13, [x9, #40]
LBB6_18:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_21 Depth 2
	add	w14, w11, w10
	ldr	x16, [x13, w14, uxtw #3]
	tst	x16, #0xff00
	b.ne	LBB6_14
; %bb.19:                               ;   in Loop: Header=BB6_18 Depth=1
	add	x15, x12, w11, uxtw #3
	ldrb	w17, [x15]
	cmp	w17, w16, uxtb
	b.ne	LBB6_14
; %bb.20:                               ;   in Loop: Header=BB6_18 Depth=1
	mov	w14, #0                         ; =0x0
	ldr	w15, [x15, #4]
	lsr	x16, x16, #32
LBB6_21:                                ;   Parent Loop BB6_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w17, #7
	b.ne	LBB6_26
; %bb.22:                               ;   in Loop: Header=BB6_21 Depth=2
	ldr	x17, [x9, #48]
	cbz	x17, LBB6_14
; %bb.23:                               ;   in Loop: Header=BB6_21 Depth=2
	ldr	w0, [x17]
	cmp	x16, x0
	ccmp	x15, x0, #2, lo
	b.hs	LBB6_14
; %bb.24:                               ;   in Loop: Header=BB6_21 Depth=2
	mov	x0, #0                          ; =0x0
	cmp	w14, #255
	b.hi	LBB6_15
; %bb.25:                               ;   in Loop: Header=BB6_21 Depth=2
	add	x1, x17, #4
	add	x16, x1, x16, lsl #3
	ldrb	w17, [x16]
	ldr	w16, [x16, #4]
	add	x15, x1, x15, lsl #3
	ldrb	w1, [x15]
	ldr	w15, [x15, #4]
	add	w14, w14, #1
	cmp	w17, w1
	b.eq	LBB6_21
	b	LBB6_15
LBB6_26:                                ;   in Loop: Header=BB6_18 Depth=1
	cmp	x16, x15
	b.ne	LBB6_14
; %bb.27:                               ;   in Loop: Header=BB6_18 Depth=1
	mov	x0, x20
	add	w11, w11, #1
	cmp	w11, w8
	b.lo	LBB6_18
LBB6_28:
	bl	_nvm_affine_state_clone
	cbz	x0, LBB6_15
; %bb.29:
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #41]
	mov	x8, x19
	strh	w19, [x0, #42]
	ldr	w9, [sp]
	str	w9, [x0, #44]
	ldrb	w9, [sp, #8]
	ldr	w10, [sp, #12]
	strb	w9, [x0, #48]
	sturh	wzr, [x0, #49]
	strb	wzr, [x0, #51]
	str	w10, [x0, #52]
	ldr	x9, [x0]
	ldrh	w12, [x9, #56]
	cbz	w12, LBB6_44
; %bb.30:
	mov	x10, #0                         ; =0x0
	ldr	x11, [x9, #40]
	mov	w13, w8
	mov	w14, #65535                     ; =0xffff
	b	LBB6_33
LBB6_31:                                ;   in Loop: Header=BB6_33 Depth=1
	ldp	x12, x15, [x0, #8]
	strb	wzr, [x12, x10]
	strh	w14, [x15, x10, lsl #1]
	ldrh	w12, [x9, #56]
LBB6_32:                                ;   in Loop: Header=BB6_33 Depth=1
	add	x10, x10, #1
	cmp	x10, w12, uxtw
	b.hs	LBB6_44
LBB6_33:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_39 Depth 2
	cmp	x10, x13
	b.hs	LBB6_31
; %bb.34:                               ;   in Loop: Header=BB6_33 Depth=1
	add	x15, x11, x10, lsl #3
	ldrb	w16, [x15, #1]
	cbnz	w16, LBB6_31
; %bb.35:                               ;   in Loop: Header=BB6_33 Depth=1
	ldrh	w16, [x15, #6]
	ldur	w17, [x15, #2]
	orr	x16, x17, x16, lsl #32
	ldrb	w3, [x15]
	lsr	x15, x16, #16
	cmp	w3, #7
	b.ne	LBB6_41
; %bb.36:                               ;   in Loop: Header=BB6_33 Depth=1
	ldr	x1, [x9, #48]
	cbz	x1, LBB6_32
; %bb.37:                               ;   in Loop: Header=BB6_33 Depth=1
	ldr	w16, [x1]
	cmp	x16, x15
	b.ls	LBB6_32
; %bb.38:                               ;   in Loop: Header=BB6_33 Depth=1
	add	x17, x1, #4
	add	x1, x1, #8
	mov	w2, #255                        ; =0xff
LBB6_39:                                ;   Parent Loop BB6_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x15, x15, #3
	ldrb	w3, [x17, x15]
	ldr	w15, [x1, x15]
	cmp	w3, #7
	b.ne	LBB6_41
; %bb.40:                               ;   in Loop: Header=BB6_39 Depth=2
	cmp	x15, x16
	ccmp	w2, #0, #4, lo
	sub	w2, w2, #1
	b.ne	LBB6_39
	b	LBB6_32
LBB6_41:                                ;   in Loop: Header=BB6_33 Depth=1
	and	w16, w3, #0xfffffffd
	cmp	w16, #8
	b.ne	LBB6_32
; %bb.42:                               ;   in Loop: Header=BB6_33 Depth=1
	ldr	w16, [x9, #16]
	cmp	x15, x16
	b.hs	LBB6_32
; %bb.43:                               ;   in Loop: Header=BB6_33 Depth=1
	ldr	x16, [x9, #24]
	ldrb	w15, [x16, x15]
	tbnz	w15, #1, LBB6_31
	b	LBB6_32
LBB6_44:
	ldrh	w2, [sp, #4]
	cbz	x2, LBB6_15
; %bb.45:
	ldr	x9, [x0, #8]
	add	x8, x9, w8, uxtw
	mov	x19, x0
	mov	x0, x8
	mov	w1, #1                          ; =0x1
	bl	_memset
	mov	x0, x19
	b	LBB6_15
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function resource
_resource:                              ; @resource
	.cfi_startproc
; %bb.0:
	and	w8, w1, #0xff
	lsr	x9, x1, #32
	cmp	w8, #7
	b.ne	LBB7_8
; %bb.1:
	tst	x1, #0xff00
	b.ne	LBB7_11
; %bb.2:
	ldr	x8, [x0, #48]
	cbz	x8, LBB7_7
; %bb.3:
	ldr	w10, [x8]
	cmp	w10, w9
	b.ls	LBB7_11
; %bb.4:
	add	x11, x8, #4
	add	x12, x8, #8
	mov	w13, #255                       ; =0xff
LBB7_5:                                 ; =>This Inner Loop Header: Depth=1
	lsl	x9, x9, #3
	ldrb	w8, [x11, x9]
	ldr	w9, [x12, x9]
	cmp	w8, #7
	b.ne	LBB7_8
; %bb.6:                                ;   in Loop: Header=BB7_5 Depth=1
	mov	w8, #0                          ; =0x0
	cmp	w9, w10
	ccmp	w13, #0, #4, lo
	sub	w13, w13, #1
	b.ne	LBB7_5
LBB7_7:
	mov	x0, x8
	ret
LBB7_8:
	and	w8, w8, #0xfffffffd
	cmp	w8, #8
	b.ne	LBB7_11
; %bb.9:
	ldr	w8, [x0, #16]
	cmp	w9, w8
	b.hs	LBB7_11
; %bb.10:
	ldr	x8, [x0, #24]
	ldrb	w8, [x8, w9, uxtw]
	ubfx	w8, w8, #1, #1
	mov	x0, x8
	ret
LBB7_11:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_can_suspend ; -- Begin function nvm_affine_can_suspend
	.globl	_nvm_affine_can_suspend
	.p2align	2
_nvm_affine_can_suspend:                ; @nvm_affine_can_suspend
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_3
; %bb.1:
	ldr	w8, [x0, #36]
	cbz	w8, LBB8_4
LBB8_2:
	mov	w0, #0                          ; =0x0
LBB8_3:
	ret
LBB8_4:
	ldr	w8, [x0, #32]
	cbz	w8, LBB8_8
; %bb.5:
	ldr	x9, [x0, #24]
LBB8_6:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #56
	tbnz	w10, #0, LBB8_2
; %bb.7:                                ;   in Loop: Header=BB8_6 Depth=1
	subs	x8, x8, #1
	b.ne	LBB8_6
LBB8_8:
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cbz	x9, LBB8_22
; %bb.9:
	mov	x10, #0                         ; =0x0
	ldr	x11, [x0, #8]
	b	LBB8_12
LBB8_10:                                ;   in Loop: Header=BB8_12 Depth=1
	tst	x13, #0xff00
	b.eq	LBB8_17
LBB8_11:                                ;   in Loop: Header=BB8_12 Depth=1
	add	x10, x10, #1
	cmp	x10, x9
	b.eq	LBB8_22
LBB8_12:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB8_20 Depth 2
	ldrb	w12, [x11, x10]
	cmp	w12, #1
	b.ne	LBB8_11
; %bb.13:                               ;   in Loop: Header=BB8_12 Depth=1
	ldr	x12, [x8, #40]
	ldr	x13, [x12, x10, lsl #3]
	and	w17, w13, #0xff
	lsr	x12, x13, #32
	cmp	w17, #7
	b.eq	LBB8_10
LBB8_14:                                ;   in Loop: Header=BB8_12 Depth=1
	and	w13, w17, #0xfffffffd
	cmp	w13, #8
	b.ne	LBB8_11
; %bb.15:                               ;   in Loop: Header=BB8_12 Depth=1
	ldr	w13, [x8, #16]
	cmp	x12, x13
	b.hs	LBB8_11
; %bb.16:                               ;   in Loop: Header=BB8_12 Depth=1
	ldr	x13, [x8, #24]
	ldrb	w12, [x13, x12]
	tbz	w12, #1, LBB8_11
	b	LBB8_2
LBB8_17:                                ;   in Loop: Header=BB8_12 Depth=1
	ldr	x15, [x8, #48]
	cbz	x15, LBB8_11
; %bb.18:                               ;   in Loop: Header=BB8_12 Depth=1
	ldr	w13, [x15]
	cmp	x13, x12
	b.ls	LBB8_11
; %bb.19:                               ;   in Loop: Header=BB8_12 Depth=1
	add	x14, x15, #4
	add	x15, x15, #8
	mov	w16, #255                       ; =0xff
LBB8_20:                                ;   Parent Loop BB8_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x12, x12, #3
	ldrb	w17, [x14, x12]
	ldr	w12, [x15, x12]
	cmp	w17, #7
	b.ne	LBB8_14
; %bb.21:                               ;   in Loop: Header=BB8_20 Depth=2
	cmp	x12, x13
	ccmp	w16, #0, #4, lo
	sub	w16, w16, #1
	b.ne	LBB8_20
	b	LBB8_11
LBB8_22:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_can_resume  ; -- Begin function nvm_affine_can_resume
	.globl	_nvm_affine_can_resume
	.p2align	2
_nvm_affine_can_resume:                 ; @nvm_affine_can_resume
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_11
; %bb.1:
	ldrb	w8, [x0, #41]
	cmp	w8, #1
	b.ne	LBB9_11
; %bb.2:
	ldrb	w11, [x0, #48]
	cmp	w11, w1, uxtb
	b.ne	LBB9_11
; %bb.3:
	mov	w8, #0                          ; =0x0
	mov	x12, x0
	ldr	x9, [x12], #52
	lsr	x10, x1, #32
LBB9_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x12]
	cmp	w11, #7
	b.ne	LBB9_9
; %bb.5:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	x11, [x9, #48]
	cbz	x11, LBB9_11
; %bb.6:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	w13, [x11]
	cmp	x12, x13
	ccmp	x10, x13, #2, lo
	b.hs	LBB9_11
; %bb.7:                                ;   in Loop: Header=BB9_4 Depth=1
	cmp	w8, #255
	b.hi	LBB9_11
; %bb.8:                                ;   in Loop: Header=BB9_4 Depth=1
	add	x13, x11, #4
	add	x12, x13, x12, lsl #3
	ldrb	w11, [x12], #4
	add	x10, x13, x10, lsl #3
	ldrb	w13, [x10]
	ldr	w10, [x10, #4]
	add	w8, w8, #1
	cmp	w11, w13
	b.eq	LBB9_4
	b	LBB9_11
LBB9_9:
	cmp	x12, x10
	b.ne	LBB9_11
; %bb.10:
	b	_nvm_affine_can_suspend
LBB9_11:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_state_equal ; -- Begin function nvm_affine_state_equal
	.globl	_nvm_affine_state_equal
	.p2align	2
_nvm_affine_state_equal:                ; @nvm_affine_state_equal
	.cfi_startproc
; %bb.0:
	mov	w2, #0                          ; =0x0
	b	_state_equal
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function state_equal
_state_equal:                           ; @state_equal
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB11_27
; %bb.1:
	cbz	x1, LBB11_27
; %bb.2:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x19, [x0]
	ldr	x8, [x1]
	cmp	x19, x8
	b.ne	LBB11_25
; %bb.3:
	ldr	w8, [x0, #36]
	ldr	w9, [x1, #36]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.4:
	ldr	w20, [x0, #32]
	ldr	w8, [x1, #32]
	cmp	w20, w8
	b.ne	LBB11_25
; %bb.5:
	ldrb	w8, [x0, #40]
	ldrb	w9, [x1, #40]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.6:
	ldr	x8, [x0, #56]
	ldr	x9, [x1, #56]
	cmp	x8, x9
	b.ne	LBB11_25
; %bb.7:
	ldrh	w21, [x0, #64]
	ldrh	w8, [x1, #64]
	cmp	w21, w8
	b.ne	LBB11_25
; %bb.8:
	ldrb	w8, [x0, #41]
	ldrb	w9, [x1, #41]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.9:
	ldrh	w8, [x0, #42]
	ldrh	w9, [x1, #42]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.10:
	ldr	w8, [x0, #44]
	ldr	w9, [x1, #44]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.11:
	ldrb	w8, [x0, #48]
	ldrb	w9, [x1, #48]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.12:
	ldr	w8, [x0, #52]
	ldr	w9, [x1, #52]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.13:
	ldrh	w24, [x19, #56]
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	x23, x0
	cbz	x24, LBB11_28
; %bb.14:
	mov	x25, #0                         ; =0x0
	ldr	x8, [x19, #40]
	add	x26, x8, #2
	mov	w27, #1                         ; =0x1
	b	LBB11_16
LBB11_15:                               ;   in Loop: Header=BB11_16 Depth=1
	add	x25, x25, #1
	add	x26, x26, #8
	cmp	x24, x25
	b.eq	LBB11_28
LBB11_16:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w28, [x26, #-2]
	cbz	w2, LBB11_21
; %bb.17:                               ;   in Loop: Header=BB11_16 Depth=1
	ldurb	w8, [x26, #-1]
	cmp	w8, #0
	ccmp	w28, #10, #2, eq
	b.hi	LBB11_21
; %bb.18:                               ;   in Loop: Header=BB11_16 Depth=1
	lsl	w8, w27, w28
	tst	w8, #0x3e
	b.ne	LBB11_15
; %bb.19:                               ;   in Loop: Header=BB11_16 Depth=1
	mov	w9, #1408                       ; =0x580
	tst	w8, w9
	b.eq	LBB11_21
; %bb.20:                               ;   in Loop: Header=BB11_16 Depth=1
	ldrh	w8, [x26, #4]
	ldr	w9, [x26]
	orr	x8, x9, x8, lsl #32
	orr	x1, x28, x8, lsl #16
	mov	x0, x19
	mov	x22, x2
	bl	_resource
	mov	x2, x22
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x8, x0
	mov	x0, x23
	cbz	w8, LBB11_15
LBB11_21:                               ;   in Loop: Header=BB11_16 Depth=1
	ldr	x8, [x0, #8]
	ldrb	w8, [x8, x25]
	ldr	x9, [x1, #8]
	ldrb	w9, [x9, x25]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.22:                               ;   in Loop: Header=BB11_16 Depth=1
	tbnz	w2, #0, LBB11_15
; %bb.23:                               ;   in Loop: Header=BB11_16 Depth=1
	cmp	w28, #10
	ccmp	w8, #0, #4, eq
	b.eq	LBB11_15
; %bb.24:                               ;   in Loop: Header=BB11_16 Depth=1
	ldr	x8, [x0, #16]
	ldrh	w8, [x8, x25, lsl #1]
	ldr	x9, [x1, #16]
	ldrh	w9, [x9, x25, lsl #1]
	cmp	w8, w9
	b.eq	LBB11_15
LBB11_25:
	mov	w8, #0                          ; =0x0
LBB11_26:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB11_27:
	mov	x0, x8
	ret
LBB11_28:
	cbz	w21, LBB11_34
; %bb.29:
	add	x8, x0, #84
	add	x9, x1, #84
LBB11_30:                               ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x8, #-12]
	ldur	x11, [x9, #-12]
	cmp	x10, x11
	b.ne	LBB11_25
; %bb.31:                               ;   in Loop: Header=BB11_30 Depth=1
	ldurh	w10, [x8, #-4]
	ldurh	w11, [x9, #-4]
	cmp	w10, w11
	b.ne	LBB11_25
; %bb.32:                               ;   in Loop: Header=BB11_30 Depth=1
	ldr	w10, [x8], #16
	ldr	w11, [x9], #16
	cmp	w10, w11
	b.ne	LBB11_25
; %bb.33:                               ;   in Loop: Header=BB11_30 Depth=1
	subs	x21, x21, #1
	b.ne	LBB11_30
LBB11_34:
	cbz	w20, LBB11_49
; %bb.35:
	mov	x19, #0                         ; =0x0
	ldr	x21, [x23, #24]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x22, [x8, #24]
	lsl	x8, x20, #6
	sub	x20, x8, x20, lsl #3
	b	LBB11_37
LBB11_36:                               ;   in Loop: Header=BB11_37 Depth=1
	add	x19, x19, #56
	mov	w8, #1                          ; =0x1
	cmp	x20, x19
	b.eq	LBB11_26
LBB11_37:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x21, x19]
	ldrb	w9, [x22, x19]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.38:                               ;   in Loop: Header=BB11_37 Depth=1
	cbz	w8, LBB11_36
; %bb.39:                               ;   in Loop: Header=BB11_37 Depth=1
	add	x8, x21, x19
	add	x9, x22, x19
	ldr	w10, [x8, #4]
	ldr	w11, [x9, #4]
	cmp	w10, w11
	b.ne	LBB11_25
; %bb.40:                               ;   in Loop: Header=BB11_37 Depth=1
	ldr	w10, [x8, #8]
	ldr	w11, [x9, #8]
	cmp	w10, w11
	b.ne	LBB11_25
; %bb.41:                               ;   in Loop: Header=BB11_37 Depth=1
	ldr	x8, [x8, #16]
	ldr	x9, [x9, #16]
	cmp	x8, x9
	b.ne	LBB11_25
; %bb.42:                               ;   in Loop: Header=BB11_37 Depth=1
	add	x8, x21, x19
	ldrh	w10, [x8, #24]
	add	x9, x22, x19
	ldrh	w11, [x9, #24]
	cmp	w10, w11
	b.ne	LBB11_25
; %bb.43:                               ;   in Loop: Header=BB11_37 Depth=1
	ldr	w8, [x8, #28]
	ldr	w9, [x9, #28]
	cmp	w8, w9
	b.ne	LBB11_25
; %bb.44:                               ;   in Loop: Header=BB11_37 Depth=1
	add	x9, x21, x19
	ldrh	w8, [x9, #40]
	add	x10, x22, x19
	ldrh	w11, [x10, #40]
	cmp	w8, w11
	b.ne	LBB11_25
; %bb.45:                               ;   in Loop: Header=BB11_37 Depth=1
	ldr	w9, [x9, #44]
	ldr	w10, [x10, #44]
	cmp	w9, w10
	b.ne	LBB11_25
; %bb.46:                               ;   in Loop: Header=BB11_37 Depth=1
	add	x9, x21, x19
	ldr	w9, [x9, #48]
	add	x10, x22, x19
	ldr	w10, [x10, #48]
	cmp	w9, w10
	b.ne	LBB11_25
; %bb.47:                               ;   in Loop: Header=BB11_37 Depth=1
	cbz	w8, LBB11_36
; %bb.48:                               ;   in Loop: Header=BB11_37 Depth=1
	add	x9, x21, x19
	ldr	x0, [x9, #32]
	add	x9, x22, x19
	ldr	x1, [x9, #32]
	lsl	x2, x8, #1
	bl	_memcmp
	cbz	w0, LBB11_36
	b	LBB11_25
LBB11_49:
	mov	w8, #1                          ; =0x1
	b	LBB11_26
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_state_meet_initialization ; -- Begin function nvm_affine_state_meet_initialization
	.globl	_nvm_affine_state_meet_initialization
	.p2align	2
_nvm_affine_state_meet_initialization:  ; @nvm_affine_state_meet_initialization
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB12_27
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	strb	wzr, [x2]
	mov	w2, #1                          ; =0x1
	bl	_state_equal
	cbz	w0, LBB12_29
; %bb.2:
	ldr	x8, [x21]
	ldrh	w9, [x8, #56]
	mov	w0, #1                          ; =0x1
	cbz	w9, LBB12_29
; %bb.3:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x8, #40]
	mov	w11, #65535                     ; =0xffff
	mov	w12, #1408                      ; =0x580
	b	LBB12_5
LBB12_4:                                ;   in Loop: Header=BB12_5 Depth=1
	add	x9, x9, #1
	ldrh	w13, [x8, #56]
	cmp	x9, x13
	b.hs	LBB12_28
LBB12_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_22 Depth 2
	add	x14, x10, x9, lsl #3
	ldrb	w13, [x14]
	ldrb	w15, [x14, #1]
	cmp	w15, #0
	ccmp	w13, #10, #2, eq
	b.hi	LBB12_4
; %bb.6:                                ;   in Loop: Header=BB12_5 Depth=1
	lsl	w15, w0, w13
	tst	w15, #0x3e
	b.eq	LBB12_17
LBB12_7:                                ;   in Loop: Header=BB12_5 Depth=1
	ldr	x14, [x21, #8]
	ldrb	w15, [x14, x9]
	cmp	w15, #1
	b.ne	LBB12_12
; %bb.8:                                ;   in Loop: Header=BB12_5 Depth=1
	ldr	x15, [x20, #8]
	ldrb	w15, [x15, x9]
	tbnz	w15, #0, LBB12_12
; %bb.9:                                ;   in Loop: Header=BB12_5 Depth=1
	strb	wzr, [x14, x9]
	cmp	w13, #10
	b.ne	LBB12_11
; %bb.10:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	x14, [x21, #16]
	strh	w11, [x14, x9, lsl #1]
LBB12_11:                               ;   in Loop: Header=BB12_5 Depth=1
	strb	w0, [x19]
LBB12_12:                               ;   in Loop: Header=BB12_5 Depth=1
	cmp	w13, #10
	b.ne	LBB12_4
; %bb.13:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	x13, [x21, #8]
	ldrb	w13, [x13, x9]
	cmp	w13, #1
	b.ne	LBB12_4
; %bb.14:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	x13, [x20, #8]
	ldrb	w13, [x13, x9]
	cmp	w13, #1
	b.ne	LBB12_4
; %bb.15:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	x13, [x21, #16]
	ldrh	w14, [x13, x9, lsl #1]
	ldr	x15, [x20, #16]
	ldrh	w15, [x15, x9, lsl #1]
	cmp	w14, w11
	ccmp	w14, w15, #4, ne
	b.eq	LBB12_4
; %bb.16:                               ;   in Loop: Header=BB12_5 Depth=1
	strh	w11, [x13, x9, lsl #1]
	strb	w0, [x19]
	b	LBB12_4
LBB12_17:                               ;   in Loop: Header=BB12_5 Depth=1
	tst	w15, w12
	b.eq	LBB12_4
; %bb.18:                               ;   in Loop: Header=BB12_5 Depth=1
	ldrh	w15, [x14, #6]
	ldur	w14, [x14, #2]
	orr	x14, x14, x15, lsl #32
	ubfx	x14, x14, #16, #32
	mov	x2, x13
	cmp	w13, #7
	b.ne	LBB12_24
; %bb.19:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	x17, [x8, #48]
	cbz	x17, LBB12_7
; %bb.20:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	w15, [x17]
	cmp	x15, x14
	b.ls	LBB12_7
; %bb.21:                               ;   in Loop: Header=BB12_5 Depth=1
	add	x16, x17, #4
	add	x17, x17, #8
	mov	w1, #255                        ; =0xff
LBB12_22:                               ;   Parent Loop BB12_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x14, #3
	ldrb	w2, [x16, x14]
	ldr	w14, [x17, x14]
	cmp	w2, #7
	b.ne	LBB12_24
; %bb.23:                               ;   in Loop: Header=BB12_22 Depth=2
	cmp	x14, x15
	ccmp	w1, #0, #4, lo
	sub	w1, w1, #1
	b.ne	LBB12_22
	b	LBB12_7
LBB12_24:                               ;   in Loop: Header=BB12_5 Depth=1
	and	w15, w2, #0xfffffffd
	cmp	w15, #8
	b.ne	LBB12_7
; %bb.25:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	w15, [x8, #16]
	cmp	x14, x15
	b.hs	LBB12_7
; %bb.26:                               ;   in Loop: Header=BB12_5 Depth=1
	ldr	x15, [x8, #24]
	ldrb	w14, [x15, x14]
	tbz	w14, #1, LBB12_7
	b	LBB12_12
LBB12_27:
	mov	w0, #0                          ; =0x0
	ret
LBB12_28:
	mov	w0, #1                          ; =0x1
LBB12_29:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_affine_owner_access
lCPI13_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_affine_owner_access
	.globl	_nvm_affine_owner_access
	.p2align	2
_nvm_affine_owner_access:               ; @nvm_affine_owner_access
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_25
; %bb.1:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB13_23
; %bb.2:
	ldr	x19, [x8, #40]
	add	x9, x19, w1, uxtw #3
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB13_23
; %bb.3:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB13_15
; %bb.4:
	ldrh	w10, [x0, #42]
	cmp	w1, w10
	b.hs	LBB13_15
; %bb.5:
	ldr	x10, [x9]
	and	w14, w10, #0xff
	lsr	x9, x10, #32
	cmp	w14, #7
	b.ne	LBB13_12
; %bb.6:
	tst	x10, #0xff00
	b.ne	LBB13_15
; %bb.7:
	ldr	x12, [x8, #48]
	cbz	x12, LBB13_15
; %bb.8:
	ldr	w10, [x12]
	cmp	w10, w9
	b.ls	LBB13_15
; %bb.9:
	add	x11, x12, #4
	add	x12, x12, #8
	mov	w13, #255                       ; =0xff
LBB13_10:                               ; =>This Inner Loop Header: Depth=1
	lsl	x9, x9, #3
	ldrb	w14, [x11, x9]
	ldr	w9, [x12, x9]
	cmp	w14, #7
	b.ne	LBB13_12
; %bb.11:                               ;   in Loop: Header=BB13_10 Depth=1
	cmp	w9, w10
	ccmp	w13, #0, #4, lo
	sub	w13, w13, #1
	b.ne	LBB13_10
	b	LBB13_15
LBB13_12:
	and	w10, w14, #0xfffffffd
	cmp	w10, #8
	b.ne	LBB13_15
; %bb.13:
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB13_15
; %bb.14:
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, w9, uxtw]
	tbnz	w8, #1, LBB13_23
LBB13_15:
	mov	w22, w1
	ldr	x8, [x0, #8]
	ldrb	w8, [x8, x22]
	cmp	w8, #1
	b.ne	LBB13_23
; %bb.16:
	mov	x20, x4
	add	x4, sp, #40
	mov	x21, x0
	mov	x25, x1
	mov	x24, x2
	mov	x23, x3
	bl	_resolve
	cbz	w0, LBB13_24
; %bb.17:
	ldr	x9, [x21, #56]
	str	x9, [sp]
	strh	w25, [sp, #8]
	strh	wzr, [sp, #10]
	add	x9, x19, x22, lsl #3
	ldr	w9, [x9, #4]
	str	w9, [sp, #12]
	str	x24, [sp, #16]
	strh	w23, [sp, #24]
	strh	wzr, [sp, #26]
	ldr	w9, [sp, #44]
	str	w9, [sp, #28]
Lloh0:
	adrp	x9, lCPI13_0@PAGE
Lloh1:
	ldr	d0, [x9, lCPI13_0@PAGEOFF]
	str	d0, [sp, #32]
	ldr	w9, [x21, #32]
	cbz	w9, LBB13_26
; %bb.18:
	mov	x8, x21
	mov	x19, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	x2, x20
	b	LBB13_20
LBB13_19:                               ;   in Loop: Header=BB13_20 Depth=1
	add	x22, x22, #1
	add	x19, x19, #56
	cmp	x22, x9
	b.hs	LBB13_26
LBB13_20:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8, #24]
	ldrb	w11, [x10, x19]
	cmp	w11, #1
	b.ne	LBB13_19
; %bb.21:                               ;   in Loop: Header=BB13_20 Depth=1
	add	x8, x10, x19
	add	x0, x8, #16
	mov	x1, sp
	bl	_nvm_reference_owner_access_conflicts
	tbnz	w0, #0, LBB13_23
; %bb.22:                               ;   in Loop: Header=BB13_20 Depth=1
	mov	x8, x21
	ldr	w9, [x21, #32]
	mov	x2, x20
	b	LBB13_19
LBB13_23:
	mov	w0, #0                          ; =0x0
LBB13_24:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
LBB13_25:
	ret
LBB13_26:
	mov	w0, #1                          ; =0x1
	b	LBB13_24
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function resolve
_resolve:                               ; @resolve
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB14_21
; %bb.1:
	ldr	x12, [x0]
	ldrh	w8, [x12, #56]
	cmp	w1, w8
	b.hs	LBB14_24
; %bb.2:
	cbnz	x2, LBB14_4
; %bb.3:
	cbnz	w3, LBB14_24
LBB14_4:
	ldr	x8, [x12, #40]
	add	x10, x8, w1, uxtw #3
	ldrb	w16, [x10, #1]
	ldrh	w9, [x10, #2]
	ldr	w8, [x10, #4]
	ldrb	w11, [x10]
	cmp	w3, #0
	cset	w13, ne
	cbz	w3, LBB14_23
; %bb.5:
	cmp	w11, #8
	b.ne	LBB14_23
; %bb.6:
	ldr	w10, [x12, #16]
	cmp	x8, x10
	b.hs	LBB14_24
; %bb.7:
	ldr	x12, [x12, #8]
	add	x8, x12, x8, lsl #4
	ldrb	w9, [x8]
	cbnz	w9, LBB14_24
; %bb.8:
	ldrh	w11, [x2]
	ldrh	w9, [x8, #2]
	cmp	w11, w9
	b.hs	LBB14_24
; %bb.9:
	mov	w9, #0                          ; =0x0
	ldr	x8, [x8, #8]
	mov	w13, #12                        ; =0xc
	umaddl	x11, w11, w13, x8
	ldr	w8, [x11, #4]
	ldrb	w11, [x11]
	cmp	w3, #1
	cset	w13, hi
	cmp	w3, #2
	b.lo	LBB14_22
; %bb.10:
	cmp	w11, #8
	b.ne	LBB14_17
; %bb.11:
	add	x14, x2, #2
	mov	w15, #2                         ; =0x2
	mov	w17, #12                        ; =0xc
	mov	w0, w3
LBB14_12:                               ; =>This Inner Loop Header: Depth=1
	cmp	x8, x10
	b.hs	LBB14_24
; %bb.13:                               ;   in Loop: Header=BB14_12 Depth=1
	add	x8, x12, x8, lsl #4
	ldrb	w9, [x8]
	cbnz	w9, LBB14_24
; %bb.14:                               ;   in Loop: Header=BB14_12 Depth=1
	ldrh	w11, [x14], #2
	ldrh	w9, [x8, #2]
	cmp	w11, w9
	b.hs	LBB14_24
; %bb.15:                               ;   in Loop: Header=BB14_12 Depth=1
	mov	w9, #0                          ; =0x0
	ldr	x8, [x8, #8]
	umaddl	x11, w11, w17, x8
	ldr	w8, [x11, #4]
	ldrb	w11, [x11]
	cmp	x15, x0
	cset	w13, lo
	b.hs	LBB14_17
; %bb.16:                               ;   in Loop: Header=BB14_12 Depth=1
	add	x15, x15, #1
	mov	x16, x9
	cmp	w11, #8
	b.eq	LBB14_12
	b	LBB14_23
LBB14_17:
	mov	x16, x9
	tbnz	w13, #0, LBB14_24
LBB14_18:
	strb	w11, [x4]
	strb	w16, [x4, #1]
	strh	w9, [x4, #2]
	str	w8, [x4, #4]
	sub	w9, w11, #1
	cmp	w9, #4
	b.hs	LBB14_20
; %bb.19:
	mov	w0, #1                          ; =0x1
	ret
LBB14_20:
	cmp	w11, #5
	mov	w9, #-1                         ; =0xffffffff
	ccmp	x8, x9, #0, ne
	cset	w0, ne
LBB14_21:
	ret
LBB14_22:
	mov	x16, x9
LBB14_23:
	tbz	w13, #0, LBB14_18
LBB14_24:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_scalar_define ; -- Begin function nvm_affine_scalar_define
	.globl	_nvm_affine_scalar_define
	.p2align	2
_nvm_affine_scalar_define:              ; @nvm_affine_scalar_define
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	bl	_destination
	cbz	w0, LBB15_4
; %bb.1:
	ldr	x8, [x20]
	ldr	x8, [x8, #40]
	ubfiz	x9, x19, #3, #32
	ldrb	w8, [x8, x9]
	sub	w8, w8, #1
	cmp	w8, #3
	b.hi	LBB15_3
; %bb.2:
	ldr	x8, [x20, #8]
	mov	w0, #1                          ; =0x1
	strb	w0, [x8, w19, uxtw]
	b	LBB15_4
LBB15_3:
	mov	w0, #0                          ; =0x0
LBB15_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function destination
_destination:                           ; @destination
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_35
; %bb.1:
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB16_3
; %bb.2:
	ldr	x9, [x8, #40]
	add	x9, x9, w1, uxtw #3
	ldrb	w10, [x9, #1]
	cbz	w10, LBB16_4
LBB16_3:
	mov	w0, #0                          ; =0x0
	ret
LBB16_4:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB16_16
; %bb.5:
	ldrh	w10, [x0, #42]
	cmp	w1, w10
	b.hs	LBB16_16
; %bb.6:
	ldr	x11, [x9]
	and	w15, w11, #0xff
	lsr	x10, x11, #32
	cmp	w15, #7
	b.ne	LBB16_13
; %bb.7:
	tst	x11, #0xff00
	b.ne	LBB16_16
; %bb.8:
	ldr	x13, [x8, #48]
	cbz	x13, LBB16_16
; %bb.9:
	ldr	w11, [x13]
	cmp	w11, w10
	b.ls	LBB16_16
; %bb.10:
	add	x12, x13, #4
	add	x13, x13, #8
	mov	w14, #255                       ; =0xff
LBB16_11:                               ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w15, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w15, #7
	b.ne	LBB16_13
; %bb.12:                               ;   in Loop: Header=BB16_11 Depth=1
	cmp	w10, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB16_11
	b	LBB16_16
LBB16_13:
	and	w11, w15, #0xfffffffd
	cmp	w11, #8
	b.ne	LBB16_16
; %bb.14:
	ldr	w11, [x8, #16]
	cmp	w10, w11
	b.hs	LBB16_16
; %bb.15:
	ldr	x11, [x8, #24]
	ldrb	w10, [x11, w10, uxtw]
	tbnz	w10, #1, LBB16_3
LBB16_16:
	ldr	x10, [x0, #8]
	ldrb	w10, [x10, w1, uxtw]
	cmp	w10, #1
	b.ne	LBB16_36
; %bb.17:
	ldrb	w12, [x9]
	ldr	x11, [x9]
	and	w10, w11, #0xff
	lsr	x9, x11, #32
	cmp	w12, #10
	b.ne	LBB16_25
; %bb.18:
	cmp	w10, #7
	b.ne	LBB16_32
; %bb.19:
	tst	x11, #0xff00
	b.ne	LBB16_36
; %bb.20:
	ldr	x10, [x8, #48]
	cbz	x10, LBB16_36
; %bb.21:
	ldr	w11, [x10]
	cmp	w11, w9
	b.ls	LBB16_36
; %bb.22:
	add	x12, x10, #4
	add	x13, x10, #8
	mov	w14, #255                       ; =0xff
	mov	w0, #1                          ; =0x1
LBB16_23:                               ; =>This Inner Loop Header: Depth=1
	lsl	x9, x9, #3
	ldrb	w10, [x12, x9]
	ldr	w9, [x13, x9]
	cmp	w10, #7
	b.ne	LBB16_32
; %bb.24:                               ;   in Loop: Header=BB16_23 Depth=1
	cmp	w9, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB16_23
	b	LBB16_35
LBB16_25:
	cmp	w10, #7
	b.ne	LBB16_37
; %bb.26:
	tst	x11, #0xff00
	b.ne	LBB16_40
; %bb.27:
	ldr	x10, [x8, #48]
	cbz	x10, LBB16_40
; %bb.28:
	ldr	w11, [x10]
	cmp	w11, w9
	b.ls	LBB16_40
; %bb.29:
	add	x12, x10, #4
	add	x13, x10, #8
	mov	w14, #255                       ; =0xff
LBB16_30:                               ; =>This Inner Loop Header: Depth=1
	lsl	x9, x9, #3
	ldrb	w10, [x12, x9]
	ldr	w9, [x13, x9]
	cmp	w10, #7
	b.ne	LBB16_37
; %bb.31:                               ;   in Loop: Header=BB16_30 Depth=1
	cmp	w9, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB16_30
	b	LBB16_40
LBB16_32:
	and	w10, w10, #0xfffffffd
	cmp	w10, #8
	b.ne	LBB16_36
; %bb.33:
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB16_36
; %bb.34:
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, w9, uxtw]
	tst	w8, #0x2
	cset	w0, eq
LBB16_35:
	ret
LBB16_36:
	mov	w0, #1                          ; =0x1
	ret
LBB16_37:
	and	w10, w10, #0xfffffffd
	cmp	w10, #8
	b.ne	LBB16_40
; %bb.38:
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB16_40
; %bb.39:
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, w9, uxtw]
	tbnz	w8, #1, LBB16_3
LBB16_40:
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #1                          ; =0x1
	b	_nvm_affine_owner_access
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_string_define ; -- Begin function nvm_affine_string_define
	.globl	_nvm_affine_string_define
	.p2align	2
_nvm_affine_string_define:              ; @nvm_affine_string_define
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	bl	_destination
	cbz	w0, LBB17_4
; %bb.1:
	ldr	x8, [x20]
	ldr	x8, [x8, #40]
	add	x8, x8, w19, uxtw #3
	ldrb	w9, [x8]
	cmp	w9, #5
	b.ne	LBB17_3
; %bb.2:
	ldr	w8, [x8, #4]
	cmn	w8, #1
	b.eq	LBB17_5
LBB17_3:
	mov	w0, #0                          ; =0x0
LBB17_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB17_5:
	ldr	x8, [x20, #8]
	mov	w0, #1                          ; =0x1
	strb	w0, [x8, w19, uxtw]
	b	LBB17_4
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_union_define ; -- Begin function nvm_affine_union_define
	.globl	_nvm_affine_union_define
	.p2align	2
_nvm_affine_union_define:               ; @nvm_affine_union_define
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x19, x3
	mov	x22, x2
	mov	x20, x1
	mov	x21, x0
	bl	_destination
	cbz	w0, LBB18_53
; %bb.1:
	ldr	x8, [x21]
	ldr	x9, [x8, #40]
	add	x9, x9, w20, uxtw #3
	ldr	w10, [x9, #4]
	cmp	w10, w22
	b.ne	LBB18_52
; %bb.2:
	ldr	x11, [x9]
	and	x9, x11, #0xffff
	cmp	x9, #10
	b.ne	LBB18_52
; %bb.3:
	lsr	x23, x11, #32
	ldr	w9, [x8, #16]
	cmp	w9, w23
	b.ls	LBB18_52
; %bb.4:
	ldr	x9, [x8, #8]
	lsl	x10, x23, #4
	ldrb	w10, [x9, x10]
	cmp	w10, #2
	b.ne	LBB18_52
; %bb.5:
	cbnz	x23, LBB18_7
; %bb.6:
	mov	w1, #0                          ; =0x0
	b	LBB18_20
LBB18_7:
	lsr	x10, x11, #35
	cbnz	x10, LBB18_9
; %bb.8:
	mov	w1, #0                          ; =0x0
	b	LBB18_18
LBB18_9:
	lsr	x10, x11, #38
	cbnz	x10, LBB18_11
; %bb.10:
	mov	w1, #0                          ; =0x0
	b	LBB18_15
LBB18_11:
	movi.2d	v0, #0000000000000000
	and	x10, x23, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x9
	mov	x13, x10
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB18_12:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB18_12
; %bb.13:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x23, x10
	b.eq	LBB18_20
; %bb.14:
	tst	x11, #0x3800000000
	b.eq	LBB18_18
LBB18_15:
	mov	x12, x10
	and	x10, x23, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x11, x12, x10
	add	x12, x9, x12, lsl #4
	add	x12, x12, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB18_16:                               ; =>This Inner Loop Header: Depth=1
	sub	x13, x12, #48
	sub	x14, x12, #32
	sub	x15, x12, #16
	add	x16, x12, #16
	add	x17, x12, #32
	add	x0, x12, #48
	ldur	b4, [x12, #-64]
	ld1.b	{ v4 }[1], [x13]
	ld1.b	{ v4 }[2], [x14]
	ld1.b	{ v4 }[3], [x15]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x16]
	ld1.b	{ v4 }[6], [x17]
	ld1.b	{ v4 }[7], [x0]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x12, x12, #128
	adds	x11, x11, #8
	b.ne	LBB18_16
; %bb.17:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x23, x10
	b.eq	LBB18_20
LBB18_18:
	sub	x11, x23, x10
	add	x9, x9, x10, lsl #4
LBB18_19:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #16
	cmp	w10, #2
	cinc	w1, w1, eq
	subs	x11, x11, #1
	b.ne	LBB18_19
LBB18_20:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB18_52
; %bb.21:
	ldr	w8, [sp, #4]
	cmp	w8, w23
	b.ne	LBB18_52
; %bb.22:
	ldr	x8, [x21]
	ldr	x9, [x8, #40]
	ldr	x10, [x9, w20, uxtw #3]
	and	w14, w10, #0xff
	lsr	x9, x10, #32
	cmp	w14, #7
	b.ne	LBB18_29
; %bb.23:
	tst	x10, #0xff00
	b.ne	LBB18_33
; %bb.24:
	ldr	x12, [x8, #48]
	cbz	x12, LBB18_33
; %bb.25:
	ldr	w10, [x12]
	cmp	w10, w9
	b.ls	LBB18_33
; %bb.26:
	add	x11, x12, #4
	add	x12, x12, #8
	mov	w13, #255                       ; =0xff
LBB18_27:                               ; =>This Inner Loop Header: Depth=1
	lsl	x9, x9, #3
	ldrb	w14, [x11, x9]
	ldr	w9, [x12, x9]
	cmp	w14, #7
	b.ne	LBB18_29
; %bb.28:                               ;   in Loop: Header=BB18_27 Depth=1
	cmp	w9, w10
	ccmp	w13, #0, #4, lo
	sub	w13, w13, #1
	b.ne	LBB18_27
	b	LBB18_32
LBB18_29:
	and	w10, w14, #0xfffffffd
	cmp	w10, #8
	b.ne	LBB18_32
; %bb.30:
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB18_33
; %bb.31:
	ldr	x10, [x8, #24]
	ldrb	w9, [x10, w9, uxtw]
	tbnz	w9, #1, LBB18_52
	b	LBB18_33
LBB18_32:
	cbz	x8, LBB18_52
LBB18_33:
	ldr	w9, [x8, #16]
	cmp	w22, w9
	b.hs	LBB18_52
; %bb.34:
	ldr	x9, [x8, #8]
	ubfiz	x10, x22, #4, #32
	ldrb	w10, [x9, x10]
	cmp	w10, #2
	b.ne	LBB18_52
; %bb.35:
	cbz	w22, LBB18_38
; %bb.36:
	mov	w10, w22
	cmp	w22, #8
	b.hs	LBB18_39
; %bb.37:
	mov	x11, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB18_48
LBB18_38:
	mov	w1, #0                          ; =0x0
	b	LBB18_50
LBB18_39:
	cmp	w22, #64
	b.hs	LBB18_41
; %bb.40:
	mov	x11, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB18_45
LBB18_41:
	movi.2d	v0, #0000000000000000
	and	x11, x10, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x9
	mov	x13, x11
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB18_42:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB18_42
; %bb.43:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x11, x10
	b.eq	LBB18_50
; %bb.44:
	tst	x10, #0x38
	b.eq	LBB18_48
LBB18_45:
	mov	x13, x11
	and	x11, x10, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x12, x13, x11
	add	x13, x9, x13, lsl #4
	add	x13, x13, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB18_46:                               ; =>This Inner Loop Header: Depth=1
	sub	x14, x13, #48
	sub	x15, x13, #32
	sub	x16, x13, #16
	add	x17, x13, #16
	add	x0, x13, #32
	add	x1, x13, #48
	ldur	b4, [x13, #-64]
	ld1.b	{ v4 }[1], [x14]
	ld1.b	{ v4 }[2], [x15]
	ld1.b	{ v4 }[3], [x16]
	ld1.b	{ v4 }[4], [x13]
	ld1.b	{ v4 }[5], [x17]
	ld1.b	{ v4 }[6], [x0]
	ld1.b	{ v4 }[7], [x1]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x13, x13, #128
	adds	x12, x12, #8
	b.ne	LBB18_46
; %bb.47:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x11, x10
	b.eq	LBB18_50
LBB18_48:
	sub	x10, x10, x11
	add	x9, x9, x11, lsl #4
LBB18_49:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9], #16
	cmp	w11, #2
	cinc	w1, w1, eq
	subs	x10, x10, #1
	b.ne	LBB18_49
LBB18_50:
	mov	w9, #65535                      ; =0xffff
	cmp	w19, w9
	b.eq	LBB18_54
; %bb.51:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	mov	x2, x19
	bl	_nvm_ownership_union_variant
	ldr	w8, [sp, #4]
	cmp	w0, #0
	ccmp	w8, w22, #0, eq
	b.eq	LBB18_54
LBB18_52:
	mov	w0, #0                          ; =0x0
LBB18_53:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB18_54:
	ldr	x8, [x21, #8]
	mov	w0, #1                          ; =0x1
	strb	w0, [x8, w20, uxtw]
	ldr	x8, [x21, #16]
	strh	w19, [x8, w20, uxtw #1]
	b	LBB18_53
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_value
_union_value:                           ; @union_value
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB19_23
; %bb.1:
	and	x9, x1, #0xffff
	cmp	x9, #10
	b.ne	LBB19_23
; %bb.2:
	sub	sp, sp, #64
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	lsr	x19, x1, #32
	ldr	w8, [x0, #16]
	cmp	w8, w19
	b.ls	LBB19_21
; %bb.3:
	ldr	x8, [x0, #8]
	lsl	x9, x19, #4
	ldrb	w9, [x8, x9]
	cmp	w9, #2
	b.ne	LBB19_21
; %bb.4:
	cbnz	x19, LBB19_6
; %bb.5:
	mov	w1, #0                          ; =0x0
	b	LBB19_20
LBB19_6:
	lsr	x9, x1, #35
	cbnz	x9, LBB19_8
; %bb.7:
	mov	w1, #0                          ; =0x0
	b	LBB19_18
LBB19_8:
	lsr	x9, x1, #38
	cbnz	x9, LBB19_10
; %bb.9:
	mov	w1, #0                          ; =0x0
	b	LBB19_15
LBB19_10:
	movi.2d	v0, #0000000000000000
	and	x9, x19, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x10, x8
	mov	x11, x9
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB19_11:                               ; =>This Inner Loop Header: Depth=1
	add	x12, x10, #16
	ldr	b26, [x10]
	ld1.b	{ v26 }[1], [x12]
	add	x12, x10, #32
	ld1.b	{ v26 }[2], [x12]
	add	x12, x10, #48
	ld1.b	{ v26 }[3], [x12]
	add	x12, x10, #64
	ld1.b	{ v26 }[4], [x12]
	add	x12, x10, #80
	ld1.b	{ v26 }[5], [x12]
	add	x12, x10, #96
	ld1.b	{ v26 }[6], [x12]
	add	x12, x10, #112
	ld1.b	{ v26 }[7], [x12]
	add	x12, x10, #144
	ldur	b28, [x10, #128]
	ld1.b	{ v28 }[1], [x12]
	add	x12, x10, #160
	ld1.b	{ v28 }[2], [x12]
	add	x12, x10, #176
	ld1.b	{ v28 }[3], [x12]
	add	x12, x10, #192
	ld1.b	{ v28 }[4], [x12]
	add	x12, x10, #208
	ld1.b	{ v28 }[5], [x12]
	add	x12, x10, #224
	ld1.b	{ v28 }[6], [x12]
	add	x12, x10, #240
	ld1.b	{ v28 }[7], [x12]
	add	x12, x10, #272
	ldr	b27, [x10, #256]
	ld1.b	{ v27 }[1], [x12]
	add	x12, x10, #288
	ld1.b	{ v27 }[2], [x12]
	add	x12, x10, #304
	ld1.b	{ v27 }[3], [x12]
	add	x12, x10, #320
	ld1.b	{ v27 }[4], [x12]
	add	x12, x10, #336
	ld1.b	{ v27 }[5], [x12]
	add	x12, x10, #352
	ld1.b	{ v27 }[6], [x12]
	add	x12, x10, #368
	ld1.b	{ v27 }[7], [x12]
	add	x12, x10, #400
	ldr	b29, [x10, #384]
	ld1.b	{ v29 }[1], [x12]
	add	x12, x10, #416
	ld1.b	{ v29 }[2], [x12]
	add	x12, x10, #432
	ld1.b	{ v29 }[3], [x12]
	add	x12, x10, #448
	ld1.b	{ v29 }[4], [x12]
	add	x12, x10, #464
	ld1.b	{ v29 }[5], [x12]
	add	x12, x10, #480
	ld1.b	{ v29 }[6], [x12]
	add	x12, x10, #496
	ld1.b	{ v29 }[7], [x12]
	add	x12, x10, #528
	ldr	b30, [x10, #512]
	ld1.b	{ v30 }[1], [x12]
	add	x12, x10, #544
	ld1.b	{ v30 }[2], [x12]
	add	x12, x10, #560
	ld1.b	{ v30 }[3], [x12]
	add	x12, x10, #576
	ld1.b	{ v30 }[4], [x12]
	add	x12, x10, #592
	ld1.b	{ v30 }[5], [x12]
	add	x12, x10, #608
	ld1.b	{ v30 }[6], [x12]
	add	x12, x10, #624
	ld1.b	{ v30 }[7], [x12]
	add	x12, x10, #656
	ldr	b31, [x10, #640]
	ld1.b	{ v31 }[1], [x12]
	add	x12, x10, #672
	ld1.b	{ v31 }[2], [x12]
	add	x12, x10, #688
	ld1.b	{ v31 }[3], [x12]
	add	x12, x10, #704
	ld1.b	{ v31 }[4], [x12]
	add	x12, x10, #720
	ld1.b	{ v31 }[5], [x12]
	add	x12, x10, #736
	ld1.b	{ v31 }[6], [x12]
	add	x12, x10, #752
	ld1.b	{ v31 }[7], [x12]
	add	x12, x10, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x10, #768]
	ld1.b	{ v26 }[1], [x12]
	add	x12, x10, #800
	ld1.b	{ v26 }[2], [x12]
	add	x12, x10, #816
	ld1.b	{ v26 }[3], [x12]
	add	x12, x10, #832
	ld1.b	{ v26 }[4], [x12]
	add	x12, x10, #848
	ld1.b	{ v26 }[5], [x12]
	add	x12, x10, #864
	ld1.b	{ v26 }[6], [x12]
	add	x12, x10, #880
	ld1.b	{ v26 }[7], [x12]
	add	x12, x10, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x10, #896]
	ld1.b	{ v29 }[1], [x12]
	add	x12, x10, #928
	ld1.b	{ v29 }[2], [x12]
	add	x12, x10, #944
	ld1.b	{ v29 }[3], [x12]
	add	x12, x10, #960
	ld1.b	{ v29 }[4], [x12]
	add	x12, x10, #976
	ld1.b	{ v29 }[5], [x12]
	add	x12, x10, #992
	ld1.b	{ v29 }[6], [x12]
	add	x12, x10, #1008
	ld1.b	{ v29 }[7], [x12]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x10, x10, #1024
	subs	x11, x11, #64
	b.ne	LBB19_11
; %bb.12:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w10, s0
	cmp	x19, x9
	b.ne	LBB19_14
; %bb.13:
	mov	x1, x10
	b	LBB19_20
LBB19_14:
	tst	x1, #0x3800000000
	mov	x1, x10
	b.eq	LBB19_18
LBB19_15:
	mov	x11, x9
	and	x9, x19, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x10, x11, x9
	add	x11, x8, x11, lsl #4
	add	x11, x11, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB19_16:                               ; =>This Inner Loop Header: Depth=1
	sub	x12, x11, #48
	sub	x13, x11, #32
	sub	x14, x11, #16
	add	x15, x11, #16
	add	x16, x11, #32
	add	x17, x11, #48
	ldur	b4, [x11, #-64]
	ld1.b	{ v4 }[1], [x12]
	ld1.b	{ v4 }[2], [x13]
	ld1.b	{ v4 }[3], [x14]
	ld1.b	{ v4 }[4], [x11]
	ld1.b	{ v4 }[5], [x15]
	ld1.b	{ v4 }[6], [x16]
	ld1.b	{ v4 }[7], [x17]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x11, x11, #128
	adds	x10, x10, #8
	b.ne	LBB19_16
; %bb.17:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x19, x9
	b.eq	LBB19_20
LBB19_18:
	sub	x10, x19, x9
	add	x8, x8, x9, lsl #4
LBB19_19:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x8], #16
	cmp	w9, #2
	cinc	w1, w1, eq
	subs	x10, x10, #1
	b.ne	LBB19_19
LBB19_20:
	ldr	x0, [x0, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbz	w0, LBB19_24
LBB19_21:
	mov	w8, #0                          ; =0x0
LBB19_22:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #64
LBB19_23:
	mov	x0, x8
	ret
LBB19_24:
	ldr	w8, [sp, #4]
	cmp	w8, w19
	cset	w8, eq
	b	LBB19_22
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_union_refine ; -- Begin function nvm_affine_union_refine
	.globl	_nvm_affine_union_refine
	.p2align	2
_nvm_affine_union_refine:               ; @nvm_affine_union_refine
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB20_59
; %bb.1:
	sub	sp, sp, #80
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB20_57
; %bb.2:
	ldr	x9, [x8, #40]
	add	x9, x9, w1, uxtw #3
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB20_57
; %bb.3:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB20_15
; %bb.4:
	ldrh	w10, [x0, #42]
	cmp	w1, w10
	b.hs	LBB20_15
; %bb.5:
	ldr	x11, [x9]
	and	w15, w11, #0xff
	lsr	x10, x11, #32
	cmp	w15, #7
	b.ne	LBB20_12
; %bb.6:
	tst	x11, #0xff00
	b.ne	LBB20_15
; %bb.7:
	ldr	x13, [x8, #48]
	cbz	x13, LBB20_15
; %bb.8:
	ldr	w11, [x13]
	cmp	w11, w10
	b.ls	LBB20_15
; %bb.9:
	add	x12, x13, #4
	add	x13, x13, #8
	mov	w14, #255                       ; =0xff
LBB20_10:                               ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w15, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w15, #7
	b.ne	LBB20_12
; %bb.11:                               ;   in Loop: Header=BB20_10 Depth=1
	cmp	w10, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB20_10
	b	LBB20_15
LBB20_12:
	and	w11, w15, #0xfffffffd
	cmp	w11, #8
	b.ne	LBB20_15
; %bb.13:
	ldr	w11, [x8, #16]
	cmp	w10, w11
	b.hs	LBB20_15
; %bb.14:
	ldr	x11, [x8, #24]
	ldrb	w10, [x11, w10, uxtw]
	tbnz	w10, #1, LBB20_57
LBB20_15:
	mov	w19, w1
	ldr	x10, [x0, #8]
	ldrb	w10, [x10, x19]
	cmp	w10, #1
	b.ne	LBB20_57
; %bb.16:
	cbz	x8, LBB20_57
; %bb.17:
	ldr	x11, [x9]
	and	x9, x11, #0xffff
	cmp	x9, #10
	b.ne	LBB20_57
; %bb.18:
	lsr	x21, x11, #32
	ldr	w9, [x8, #16]
	cmp	w9, w21
	b.ls	LBB20_57
; %bb.19:
	ldr	x9, [x8, #8]
	lsl	x10, x21, #4
	ldrb	w10, [x9, x10]
	cmp	w10, #2
	b.ne	LBB20_57
; %bb.20:
	mov	x20, x2
	cbnz	x21, LBB20_22
; %bb.21:
	mov	x22, x0
	mov	w1, #0                          ; =0x0
	b	LBB20_35
LBB20_22:
	lsr	x10, x11, #35
	cbnz	x10, LBB20_24
; %bb.23:
	mov	x22, x0
	mov	w1, #0                          ; =0x0
	b	LBB20_33
LBB20_24:
	lsr	x10, x11, #38
	cbnz	x10, LBB20_26
; %bb.25:
	mov	x22, x0
	mov	w1, #0                          ; =0x0
	b	LBB20_30
LBB20_26:
	movi.2d	v0, #0000000000000000
	and	x10, x21, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x9
	mov	x13, x10
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB20_27:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB20_27
; %bb.28:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	mov	x22, x0
	cmp	x21, x10
	b.eq	LBB20_35
; %bb.29:
	tst	x11, #0x3800000000
	b.eq	LBB20_33
LBB20_30:
	mov	x12, x10
	and	x10, x21, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x11, x12, x10
	add	x12, x9, x12, lsl #4
	add	x12, x12, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB20_31:                               ; =>This Inner Loop Header: Depth=1
	sub	x13, x12, #48
	sub	x14, x12, #32
	sub	x15, x12, #16
	add	x16, x12, #16
	add	x17, x12, #32
	add	x0, x12, #48
	ldur	b4, [x12, #-64]
	ld1.b	{ v4 }[1], [x13]
	ld1.b	{ v4 }[2], [x14]
	ld1.b	{ v4 }[3], [x15]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x16]
	ld1.b	{ v4 }[6], [x17]
	ld1.b	{ v4 }[7], [x0]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x12, x12, #128
	adds	x11, x11, #8
	b.ne	LBB20_31
; %bb.32:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x21, x10
	b.eq	LBB20_35
LBB20_33:
	sub	x11, x21, x10
	add	x9, x9, x10, lsl #4
LBB20_34:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #16
	cmp	w10, #2
	cinc	w1, w1, eq
	subs	x11, x11, #1
	b.ne	LBB20_34
LBB20_35:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB20_57
; %bb.36:
	ldr	w8, [sp, #4]
	cmp	w8, w21
	b.ne	LBB20_57
; %bb.37:
	mov	x2, x20
	ldr	x8, [x22, #16]
	ldrh	w8, [x8, x19, lsl #1]
	mov	w9, #65535                      ; =0xffff
	cmp	w8, w9
	ccmp	w8, w20, #4, ne
	b.ne	LBB20_57
; %bb.38:
	ldr	x8, [x22]
	ldr	x9, [x8, #40]
	add	x9, x9, x19, lsl #3
	ldr	w9, [x9, #4]
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB20_57
; %bb.39:
	ldr	x10, [x8, #8]
	lsl	x11, x9, #4
	ldrb	w11, [x10, x11]
	cmp	w11, #2
	b.ne	LBB20_57
; %bb.40:
	mov	x21, x22
	cbz	w9, LBB20_43
; %bb.41:
	cmp	w9, #8
	b.hs	LBB20_44
; %bb.42:
	mov	x11, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB20_54
LBB20_43:
	mov	w1, #0                          ; =0x0
	b	LBB20_56
LBB20_44:
	cmp	w9, #64
	b.hs	LBB20_46
; %bb.45:
	mov	x11, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB20_51
LBB20_46:
	movi.2d	v0, #0000000000000000
	and	x11, x9, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x10
	mov	x13, x11
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB20_47:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB20_47
; %bb.48:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x11, x9
	b.ne	LBB20_50
; %bb.49:
	mov	x2, x20
	b	LBB20_56
LBB20_50:
	tst	x9, #0x38
	mov	x2, x20
	b.eq	LBB20_54
LBB20_51:
	mov	x13, x11
	and	x11, x9, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x12, x13, x11
	add	x13, x10, x13, lsl #4
	add	x13, x13, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB20_52:                               ; =>This Inner Loop Header: Depth=1
	sub	x14, x13, #48
	sub	x15, x13, #32
	sub	x16, x13, #16
	add	x17, x13, #16
	add	x0, x13, #32
	add	x1, x13, #48
	ldur	b4, [x13, #-64]
	ld1.b	{ v4 }[1], [x14]
	ld1.b	{ v4 }[2], [x15]
	ld1.b	{ v4 }[3], [x16]
	ld1.b	{ v4 }[4], [x13]
	ld1.b	{ v4 }[5], [x17]
	ld1.b	{ v4 }[6], [x0]
	ld1.b	{ v4 }[7], [x1]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x13, x13, #128
	adds	x12, x12, #8
	b.ne	LBB20_52
; %bb.53:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x11, x9
	mov	x2, x20
	b.eq	LBB20_56
LBB20_54:
	sub	x9, x9, x11
	add	x10, x10, x11, lsl #4
LBB20_55:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #16
	cmp	w11, #2
	cinc	w1, w1, eq
	subs	x9, x9, #1
	b.ne	LBB20_55
LBB20_56:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	bl	_nvm_ownership_union_variant
	cbz	w0, LBB20_60
LBB20_57:
	mov	w0, #0                          ; =0x0
LBB20_58:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #80
LBB20_59:
	ret
LBB20_60:
	ldr	x8, [x21, #16]
	strh	w20, [x8, x19, lsl #1]
	mov	w0, #1                          ; =0x1
	b	LBB20_58
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_union_variant ; -- Begin function nvm_affine_union_variant
	.globl	_nvm_affine_union_variant
	.p2align	2
_nvm_affine_union_variant:              ; @nvm_affine_union_variant
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB21_43
; %bb.1:
	cbz	x2, LBB21_43
; %bb.2:
	sub	sp, sp, #80
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB21_41
; %bb.3:
	ldr	x9, [x8, #40]
	add	x9, x9, w1, uxtw #3
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB21_41
; %bb.4:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB21_16
; %bb.5:
	ldrh	w10, [x0, #42]
	cmp	w1, w10
	b.hs	LBB21_16
; %bb.6:
	ldr	x11, [x9]
	and	w15, w11, #0xff
	lsr	x10, x11, #32
	cmp	w15, #7
	b.ne	LBB21_13
; %bb.7:
	tst	x11, #0xff00
	b.ne	LBB21_16
; %bb.8:
	ldr	x13, [x8, #48]
	cbz	x13, LBB21_16
; %bb.9:
	ldr	w11, [x13]
	cmp	w11, w10
	b.ls	LBB21_16
; %bb.10:
	add	x12, x13, #4
	add	x13, x13, #8
	mov	w14, #255                       ; =0xff
LBB21_11:                               ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w15, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w15, #7
	b.ne	LBB21_13
; %bb.12:                               ;   in Loop: Header=BB21_11 Depth=1
	cmp	w10, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB21_11
	b	LBB21_16
LBB21_13:
	and	w11, w15, #0xfffffffd
	cmp	w11, #8
	b.ne	LBB21_16
; %bb.14:
	ldr	w11, [x8, #16]
	cmp	w10, w11
	b.hs	LBB21_16
; %bb.15:
	ldr	x11, [x8, #24]
	ldrb	w10, [x11, w10, uxtw]
	tbnz	w10, #1, LBB21_41
LBB21_16:
	ldr	x10, [x0, #8]
	ldrb	w10, [x10, w1, uxtw]
	cmp	w10, #1
	b.ne	LBB21_41
; %bb.17:
	cbz	x8, LBB21_41
; %bb.18:
	ldr	x11, [x9]
	and	x9, x11, #0xffff
	cmp	x9, #10
	b.ne	LBB21_41
; %bb.19:
	lsr	x19, x11, #32
	ldr	w9, [x8, #16]
	cmp	w9, w19
	b.ls	LBB21_41
; %bb.20:
	ldr	x9, [x8, #8]
	lsl	x10, x19, #4
	ldrb	w10, [x9, x10]
	cmp	w10, #2
	b.ne	LBB21_41
; %bb.21:
	cbnz	x19, LBB21_23
; %bb.22:
	mov	x21, x0
	mov	x20, x1
	mov	x22, x2
	mov	w1, #0                          ; =0x0
	b	LBB21_37
LBB21_23:
	lsr	x10, x11, #35
	cbnz	x10, LBB21_25
; %bb.24:
	mov	x21, x0
	mov	x20, x1
	mov	x22, x2
	mov	w1, #0                          ; =0x0
	b	LBB21_35
LBB21_25:
	lsr	x10, x11, #38
	cbnz	x10, LBB21_27
; %bb.26:
	mov	x21, x0
	mov	x20, x1
	mov	x22, x2
	mov	w1, #0                          ; =0x0
	b	LBB21_32
LBB21_27:
	movi.2d	v0, #0000000000000000
	and	x10, x19, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x9
	mov	x13, x10
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB21_28:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB21_28
; %bb.29:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w12, s0
	mov	x21, x0
	mov	x20, x1
	mov	x22, x2
	cmp	x19, x10
	b.ne	LBB21_31
; %bb.30:
	mov	x1, x12
	b	LBB21_37
LBB21_31:
	tst	x11, #0x3800000000
	mov	x1, x12
	b.eq	LBB21_35
LBB21_32:
	mov	x12, x10
	and	x10, x19, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x11, x12, x10
	add	x12, x9, x12, lsl #4
	add	x12, x12, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB21_33:                               ; =>This Inner Loop Header: Depth=1
	sub	x13, x12, #48
	sub	x14, x12, #32
	sub	x15, x12, #16
	add	x16, x12, #16
	add	x17, x12, #32
	add	x0, x12, #48
	ldur	b4, [x12, #-64]
	ld1.b	{ v4 }[1], [x13]
	ld1.b	{ v4 }[2], [x14]
	ld1.b	{ v4 }[3], [x15]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x16]
	ld1.b	{ v4 }[6], [x17]
	ld1.b	{ v4 }[7], [x0]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x12, x12, #128
	adds	x11, x11, #8
	b.ne	LBB21_33
; %bb.34:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x19, x10
	b.eq	LBB21_37
LBB21_35:
	sub	x11, x19, x10
	add	x9, x9, x10, lsl #4
LBB21_36:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #16
	cmp	w10, #2
	cinc	w1, w1, eq
	subs	x11, x11, #1
	b.ne	LBB21_36
LBB21_37:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB21_41
; %bb.38:
	ldr	w8, [sp, #4]
	cmp	w8, w19
	b.ne	LBB21_41
; %bb.39:
	ldr	x8, [x21, #16]
	ldrh	w8, [x8, w20, uxtw #1]
	mov	w9, #65535                      ; =0xffff
	cmp	w8, w9
	b.eq	LBB21_41
; %bb.40:
	strh	w8, [x22]
	mov	w8, #1                          ; =0x1
	b	LBB21_42
LBB21_41:
	mov	w8, #0                          ; =0x0
LBB21_42:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #80
LBB21_43:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_move        ; -- Begin function nvm_affine_move
	.globl	_nvm_affine_move
	.p2align	2
_nvm_affine_move:                       ; @nvm_affine_move
	.cfi_startproc
; %bb.0:
	cmp	w1, w2
	b.ne	LBB22_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB22_2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	x21, x2
	mov	x1, x2
	bl	_destination
	cbz	w0, LBB22_6
; %bb.3:
	mov	x0, x20
	mov	x1, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #1                          ; =0x1
	bl	_nvm_affine_owner_access
	cbz	w0, LBB22_6
; %bb.4:
	ldr	x10, [x20]
	ldr	x9, [x10, #40]
	ldr	x12, [x9, w19, uxtw #3]
	ldr	x13, [x9, w21, uxtw #3]
	eor	w9, w13, w12
	and	x11, x9, #0xff00
	and	w9, w12, #0xff
	and	w14, w13, #0xff
	cmp	x11, #0
	ccmp	w9, w14, #0, eq
	b.eq	LBB22_7
LBB22_5:
	mov	w0, #0                          ; =0x0
LBB22_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB22_7:
	mov	x8, x21
	mov	w11, #0                         ; =0x0
	lsr	x12, x12, #32
	lsr	x13, x13, #32
	mov	x14, x9
LBB22_8:                                ; =>This Inner Loop Header: Depth=1
	cmp	w14, #7
	b.ne	LBB22_13
; %bb.9:                                ;   in Loop: Header=BB22_8 Depth=1
	ldr	x14, [x10, #48]
	cbz	x14, LBB22_5
; %bb.10:                               ;   in Loop: Header=BB22_8 Depth=1
	ldr	w15, [x14]
	cmp	x12, x15
	mov	w0, #0                          ; =0x0
	ccmp	x13, x15, #2, lo
	b.hs	LBB22_6
; %bb.11:                               ;   in Loop: Header=BB22_8 Depth=1
	cmp	w11, #255
	b.hi	LBB22_6
; %bb.12:                               ;   in Loop: Header=BB22_8 Depth=1
	add	x15, x14, #4
	add	x12, x15, x12, lsl #3
	ldrb	w14, [x12]
	ldr	w12, [x12, #4]
	add	x13, x15, x13, lsl #3
	ldrb	w15, [x13]
	ldr	w13, [x13, #4]
	add	w11, w11, #1
	cmp	w14, w15
	b.eq	LBB22_8
	b	LBB22_6
LBB22_13:
	cmp	x12, x13
	b.ne	LBB22_5
; %bb.14:
	ldr	x10, [x20, #8]
	strb	wzr, [x10, w19, uxtw]
	mov	w0, #1                          ; =0x1
	strb	w0, [x10, w8, uxtw]
	cmp	w9, #10
	b.ne	LBB22_6
; %bb.15:
	ldr	x9, [x20, #16]
	ldrh	w10, [x9, w19, uxtw #1]
	strh	w10, [x9, w8, uxtw #1]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, w19, uxtw #1]
	b	LBB22_6
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_pack        ; -- Begin function nvm_affine_pack
	.globl	_nvm_affine_pack
	.p2align	2
_nvm_affine_pack:                       ; @nvm_affine_pack
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x22, x3
	mov	x20, x2
	mov	x19, x1
	mov	x21, x0
	mov	w4, #0                          ; =0x0
	bl	_fields_check
	cbz	w0, LBB23_16
; %bb.1:
	cbz	w22, LBB23_15
; %bb.2:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x21]
	ldr	x10, [x9, #40]
	mov	w11, w22
	mov	w12, #65535                     ; =0xffff
	b	LBB23_5
LBB23_3:                                ;   in Loop: Header=BB23_5 Depth=1
	tst	x15, #0xff00
	b.eq	LBB23_10
LBB23_4:                                ;   in Loop: Header=BB23_5 Depth=1
	add	x8, x8, #1
	cmp	x8, x11
	b.eq	LBB23_15
LBB23_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_13 Depth 2
	ldrh	w13, [x20, x8, lsl #1]
	ldr	x15, [x10, x13, lsl #3]
	and	w2, w15, #0xff
	lsr	x14, x15, #32
	cmp	w2, #7
	b.eq	LBB23_3
LBB23_6:                                ;   in Loop: Header=BB23_5 Depth=1
	and	w15, w2, #0xfffffffd
	cmp	w15, #8
	b.ne	LBB23_4
; %bb.7:                                ;   in Loop: Header=BB23_5 Depth=1
	ldr	w15, [x9, #16]
	cmp	x14, x15
	b.hs	LBB23_4
; %bb.8:                                ;   in Loop: Header=BB23_5 Depth=1
	ldr	x15, [x9, #24]
	ldrb	w14, [x15, x14]
	tbz	w14, #1, LBB23_4
; %bb.9:                                ;   in Loop: Header=BB23_5 Depth=1
	ldp	x14, x15, [x21, #8]
	strb	wzr, [x14, x13]
	strh	w12, [x15, x13, lsl #1]
	b	LBB23_4
LBB23_10:                               ;   in Loop: Header=BB23_5 Depth=1
	ldr	x17, [x9, #48]
	cbz	x17, LBB23_4
; %bb.11:                               ;   in Loop: Header=BB23_5 Depth=1
	ldr	w15, [x17]
	cmp	x15, x14
	b.ls	LBB23_4
; %bb.12:                               ;   in Loop: Header=BB23_5 Depth=1
	add	x16, x17, #4
	add	x17, x17, #8
	mov	w1, #255                        ; =0xff
LBB23_13:                               ;   Parent Loop BB23_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x14, #3
	ldrb	w2, [x16, x14]
	ldr	w14, [x17, x14]
	cmp	w2, #7
	b.ne	LBB23_6
; %bb.14:                               ;   in Loop: Header=BB23_13 Depth=2
	cmp	x14, x15
	ccmp	w1, #0, #4, lo
	sub	w1, w1, #1
	b.ne	LBB23_13
	b	LBB23_4
LBB23_15:
	ldr	x8, [x21, #8]
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, w19, uxtw]
LBB23_16:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fields_check
_fields_check:                          ; @fields_check
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_12
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB24_73
; %bb.2:
	ldr	x9, [x8, #40]
	add	x9, x9, w1, uxtw #3
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB24_73
; %bb.3:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB24_16
; %bb.4:
	ldrh	w10, [x0, #42]
	cmp	w1, w10
	b.hs	LBB24_16
; %bb.5:
	ldr	x11, [x9]
	and	w15, w11, #0xff
	lsr	x10, x11, #32
	cmp	w15, #7
	b.ne	LBB24_13
; %bb.6:
	tst	x11, #0xff00
	b.ne	LBB24_16
; %bb.7:
	ldr	x13, [x8, #48]
	cbz	x13, LBB24_16
; %bb.8:
	ldr	w11, [x13]
	cmp	w11, w10
	b.ls	LBB24_16
; %bb.9:
	add	x12, x13, #4
	add	x13, x13, #8
	mov	w14, #255                       ; =0xff
LBB24_10:                               ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w15, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w15, #7
	b.ne	LBB24_13
; %bb.11:                               ;   in Loop: Header=BB24_10 Depth=1
	cmp	w10, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB24_10
	b	LBB24_16
LBB24_12:
	mov	w0, #0                          ; =0x0
	ret
LBB24_13:
	and	w11, w15, #0xfffffffd
	cmp	w11, #8
	b.ne	LBB24_16
; %bb.14:
	ldr	w11, [x8, #16]
	cmp	w10, w11
	b.hs	LBB24_16
; %bb.15:
	ldr	x11, [x8, #24]
	ldrb	w10, [x11, w10, uxtw]
	tbnz	w10, #1, LBB24_73
LBB24_16:
	cbnz	x2, LBB24_18
; %bb.17:
	cbnz	w3, LBB24_73
LBB24_18:
	ldrb	w10, [x9]
	cmp	w10, #8
	b.ne	LBB24_73
; %bb.19:
	ldr	w9, [x9, #4]
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB24_73
; %bb.20:
	ldr	x8, [x8, #8]
	add	x21, x8, x9, lsl #4
	ldrb	w8, [x21]
	cbnz	w8, LBB24_73
; %bb.21:
	ldrh	w8, [x21, #2]
	cmp	w3, w8
	b.ne	LBB24_73
; %bb.22:
	mov	x24, x2
	mov	x22, x3
	mov	x23, x4
	mov	x20, x0
	mov	x19, x1
	cbz	w4, LBB24_24
; %bb.23:
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #1                          ; =0x1
	bl	_nvm_affine_owner_access
	b	LBB24_25
LBB24_24:
	bl	_destination
LBB24_25:
	mov	x8, x0
	cbz	w22, LBB24_74
; %bb.26:
	mov	x10, x23
	mov	x11, x24
	mov	x12, x19
	cbz	w8, LBB24_74
; %bb.27:
	mov	w14, #0                         ; =0x0
	mov	w25, #12                        ; =0xc
LBB24_28:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB24_38 Depth 2
                                        ;     Child Loop BB24_45 Depth 2
                                        ;     Child Loop BB24_54 Depth 2
                                        ;       Child Loop BB24_60 Depth 3
	ldrh	w19, [x11, w14, uxtw #1]
	cmp	w19, w12
	b.eq	LBB24_73
; %bb.29:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	x0, [x20]
	ldrh	w8, [x0, #56]
	cmp	w19, w8
	b.hs	LBB24_73
; %bb.30:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	x8, [x0, #40]
	add	x8, x8, x19, lsl #3
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB24_73
; %bb.31:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	x9, [x21, #8]
	umaddl	x13, w14, w25, x9
	ldrb	w9, [x13]
	ldr	w13, [x13, #4]
	ldrb	w15, [x20, #41]
	tbz	w15, #0, LBB24_41
; %bb.32:                               ;   in Loop: Header=BB24_28 Depth=1
	ldrh	w15, [x20, #42]
	ldr	x1, [x8]
	cmp	w19, w15
	b.hs	LBB24_42
; %bb.33:                               ;   in Loop: Header=BB24_28 Depth=1
	and	w17, w1, #0xff
	lsr	x8, x1, #32
	cmp	w17, #7
	b.ne	LBB24_70
; %bb.34:                               ;   in Loop: Header=BB24_28 Depth=1
	tst	x1, #0xff00
	b.ne	LBB24_42
; %bb.35:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	x15, [x0, #48]
	cbz	x15, LBB24_40
; %bb.36:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	w10, [x15]
	cmp	x10, x8
	b.ls	LBB24_40
; %bb.37:                               ;   in Loop: Header=BB24_28 Depth=1
	add	x11, x15, #4
	add	x15, x15, #8
	mov	w16, #255                       ; =0xff
LBB24_38:                               ;   Parent Loop BB24_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x8, x8, #3
	ldrb	w17, [x11, x8]
	ldr	w8, [x15, x8]
	cmp	w17, #7
	b.ne	LBB24_69
; %bb.39:                               ;   in Loop: Header=BB24_38 Depth=2
	cmp	x8, x10
	ccmp	w16, #0, #4, lo
	sub	w16, w16, #1
	b.ne	LBB24_38
LBB24_40:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	x10, x23
	mov	x11, x24
	b	LBB24_42
LBB24_41:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	x1, [x8]
LBB24_42:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	w8, #0                          ; =0x0
	tst	x1, #0xff00
	b.ne	LBB24_74
; %bb.43:                               ;   in Loop: Header=BB24_28 Depth=1
	and	w15, w1, #0xff
	cmp	w9, w15
	b.ne	LBB24_74
; %bb.44:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	w15, #0                         ; =0x0
	mov	w26, w14
	lsr	x14, x1, #32
	mov	x16, x14
	mov	x17, x9
LBB24_45:                               ;   Parent Loop BB24_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w17, #7
	b.ne	LBB24_50
; %bb.46:                               ;   in Loop: Header=BB24_45 Depth=2
	ldr	x17, [x0, #48]
	cbz	x17, LBB24_73
; %bb.47:                               ;   in Loop: Header=BB24_45 Depth=2
	ldr	w8, [x17]
	cmp	x16, x8
	ccmp	x13, x8, #2, lo
	b.hs	LBB24_73
; %bb.48:                               ;   in Loop: Header=BB24_45 Depth=2
	mov	w8, #0                          ; =0x0
	cmp	w15, #255
	b.hi	LBB24_74
; %bb.49:                               ;   in Loop: Header=BB24_45 Depth=2
	add	x2, x17, #4
	add	x16, x2, x16, lsl #3
	ldrb	w17, [x16]
	ldr	w16, [x16, #4]
	add	x13, x2, x13, lsl #3
	ldrb	w2, [x13]
	ldr	w13, [x13, #4]
	add	w15, w15, #1
	cmp	w17, w2
	b.eq	LBB24_45
	b	LBB24_74
LBB24_50:                               ;   in Loop: Header=BB24_28 Depth=1
	cmp	x16, x13
	b.ne	LBB24_73
; %bb.51:                               ;   in Loop: Header=BB24_28 Depth=1
	cbz	w26, LBB24_65
; %bb.52:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	x8, #0                          ; =0x0
	b	LBB24_54
LBB24_53:                               ;   in Loop: Header=BB24_54 Depth=2
	add	x8, x8, #1
	cmp	x8, x26
	b.eq	LBB24_65
LBB24_54:                               ;   Parent Loop BB24_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB24_60 Depth 3
	ldrh	w13, [x11, x8, lsl #1]
	cmp	w13, w19
	b.ne	LBB24_53
; %bb.55:                               ;   in Loop: Header=BB24_54 Depth=2
	tbnz	w10, #0, LBB24_73
; %bb.56:                               ;   in Loop: Header=BB24_54 Depth=2
	mov	x13, x14
	mov	x3, x9
	cmp	w9, #7
	b.ne	LBB24_62
; %bb.57:                               ;   in Loop: Header=BB24_54 Depth=2
	ldr	x13, [x0, #48]
	cbz	x13, LBB24_53
; %bb.58:                               ;   in Loop: Header=BB24_54 Depth=2
	ldr	w15, [x13]
	cmp	x15, x14
	b.ls	LBB24_53
; %bb.59:                               ;   in Loop: Header=BB24_54 Depth=2
	add	x16, x13, #4
	add	x17, x13, #8
	mov	w2, #255                        ; =0xff
	mov	x13, x14
LBB24_60:                               ;   Parent Loop BB24_28 Depth=1
                                        ;     Parent Loop BB24_54 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x13, x13, #3
	ldrb	w3, [x16, x13]
	ldr	w13, [x17, x13]
	cmp	w3, #7
	b.ne	LBB24_62
; %bb.61:                               ;   in Loop: Header=BB24_60 Depth=3
	cmp	x13, x15
	ccmp	w2, #0, #4, lo
	sub	w2, w2, #1
	b.ne	LBB24_60
	b	LBB24_53
LBB24_62:                               ;   in Loop: Header=BB24_54 Depth=2
	and	w15, w3, #0xfffffffd
	cmp	w15, #8
	b.ne	LBB24_53
; %bb.63:                               ;   in Loop: Header=BB24_54 Depth=2
	ldr	w15, [x0, #16]
	cmp	x13, x15
	b.hs	LBB24_53
; %bb.64:                               ;   in Loop: Header=BB24_54 Depth=2
	ldr	x15, [x0, #24]
	ldrb	w13, [x15, x13]
	tbz	w13, #1, LBB24_53
	b	LBB24_73
LBB24_65:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	x27, x12
	cbz	w10, LBB24_67
; %bb.66:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	x28, x20
	mov	x0, x20
	mov	x1, x19
	bl	_destination
	tbnz	w0, #0, LBB24_68
	b	LBB24_73
LBB24_67:                               ;   in Loop: Header=BB24_28 Depth=1
	bl	_resource
	mov	x4, x0
	mov	x28, x20
	mov	x0, x20
	mov	x1, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	cbz	w0, LBB24_73
LBB24_68:                               ;   in Loop: Header=BB24_28 Depth=1
	add	w14, w26, #1
	mov	w8, #1                          ; =0x1
	cmp	w14, w22
	mov	x10, x23
	mov	x11, x24
	mov	x12, x27
	mov	x20, x28
	b.lo	LBB24_28
	b	LBB24_74
LBB24_69:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	x10, x23
	mov	x11, x24
LBB24_70:                               ;   in Loop: Header=BB24_28 Depth=1
	and	w15, w17, #0xfffffffd
	cmp	w15, #8
	b.ne	LBB24_42
; %bb.71:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	w15, [x0, #16]
	cmp	x8, x15
	b.hs	LBB24_42
; %bb.72:                               ;   in Loop: Header=BB24_28 Depth=1
	ldr	x15, [x0, #24]
	ldrb	w8, [x15, x8]
	tbz	w8, #1, LBB24_42
LBB24_73:
	mov	w8, #0                          ; =0x0
LBB24_74:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_unpack      ; -- Begin function nvm_affine_unpack
	.globl	_nvm_affine_unpack
	.p2align	2
_nvm_affine_unpack:                     ; @nvm_affine_unpack
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x19, x2
	mov	x22, x1
	mov	x21, x0
	mov	w4, #1                          ; =0x1
	bl	_fields_check
	cbz	w0, LBB25_4
; %bb.1:
	ldr	x8, [x21, #8]
	strb	wzr, [x8, w22, uxtw]
	cbz	w20, LBB25_4
; %bb.2:
	ldr	x9, [x21, #16]
	mov	w10, w20
	mov	w11, #1                         ; =0x1
	mov	w12, #65535                     ; =0xffff
LBB25_3:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w13, [x19], #2
	strb	w11, [x8, x13]
	strh	w12, [x9, x13, lsl #1]
	subs	x10, x10, #1
	b.ne	LBB25_3
LBB25_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_union_pack  ; -- Begin function nvm_affine_union_pack
	.globl	_nvm_affine_union_pack
	.p2align	2
_nvm_affine_union_pack:                 ; @nvm_affine_union_pack
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x23, x4
	mov	x22, x3
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	w5, #0                          ; =0x0
	bl	_union_fields_check
	cbz	w0, LBB26_16
; %bb.1:
	cbz	w23, LBB26_15
; %bb.2:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x21]
	ldr	x10, [x9, #40]
	mov	w11, w23
	mov	w12, #65535                     ; =0xffff
	b	LBB26_5
LBB26_3:                                ;   in Loop: Header=BB26_5 Depth=1
	tst	x15, #0xff00
	b.eq	LBB26_10
LBB26_4:                                ;   in Loop: Header=BB26_5 Depth=1
	add	x8, x8, #1
	cmp	x8, x11
	b.eq	LBB26_15
LBB26_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_13 Depth 2
	ldrh	w13, [x22, x8, lsl #1]
	ldr	x15, [x10, x13, lsl #3]
	and	w2, w15, #0xff
	lsr	x14, x15, #32
	cmp	w2, #7
	b.eq	LBB26_3
LBB26_6:                                ;   in Loop: Header=BB26_5 Depth=1
	and	w15, w2, #0xfffffffd
	cmp	w15, #8
	b.ne	LBB26_4
; %bb.7:                                ;   in Loop: Header=BB26_5 Depth=1
	ldr	w15, [x9, #16]
	cmp	x14, x15
	b.hs	LBB26_4
; %bb.8:                                ;   in Loop: Header=BB26_5 Depth=1
	ldr	x15, [x9, #24]
	ldrb	w14, [x15, x14]
	tbz	w14, #1, LBB26_4
; %bb.9:                                ;   in Loop: Header=BB26_5 Depth=1
	ldp	x14, x15, [x21, #8]
	strb	wzr, [x14, x13]
	strh	w12, [x15, x13, lsl #1]
	b	LBB26_4
LBB26_10:                               ;   in Loop: Header=BB26_5 Depth=1
	ldr	x17, [x9, #48]
	cbz	x17, LBB26_4
; %bb.11:                               ;   in Loop: Header=BB26_5 Depth=1
	ldr	w15, [x17]
	cmp	x15, x14
	b.ls	LBB26_4
; %bb.12:                               ;   in Loop: Header=BB26_5 Depth=1
	add	x16, x17, #4
	add	x17, x17, #8
	mov	w1, #255                        ; =0xff
LBB26_13:                               ;   Parent Loop BB26_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x14, #3
	ldrb	w2, [x16, x14]
	ldr	w14, [x17, x14]
	cmp	w2, #7
	b.ne	LBB26_6
; %bb.14:                               ;   in Loop: Header=BB26_13 Depth=2
	cmp	x14, x15
	ccmp	w1, #0, #4, lo
	sub	w1, w1, #1
	b.ne	LBB26_13
	b	LBB26_4
LBB26_15:
	mov	w8, #1                          ; =0x1
	ldp	x9, x10, [x21, #8]
	strb	w8, [x9, w20, uxtw]
	strh	w19, [x10, w20, uxtw #1]
LBB26_16:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_fields_check
_union_fields_check:                    ; @union_fields_check
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB27_19
; %bb.1:
	sub	sp, sp, #112
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset b8, -88
	.cfi_offset b9, -96
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB27_17
; %bb.2:
	ldr	x9, [x8, #40]
	add	x9, x9, w1, uxtw #3
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB27_17
; %bb.3:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB27_15
; %bb.4:
	ldrh	w10, [x0, #42]
	cmp	w1, w10
	b.hs	LBB27_15
; %bb.5:
	ldr	x11, [x9]
	and	w15, w11, #0xff
	lsr	x10, x11, #32
	cmp	w15, #7
	b.ne	LBB27_12
; %bb.6:
	tst	x11, #0xff00
	b.ne	LBB27_15
; %bb.7:
	ldr	x13, [x8, #48]
	cbz	x13, LBB27_15
; %bb.8:
	ldr	w11, [x13]
	cmp	w11, w10
	b.ls	LBB27_15
; %bb.9:
	add	x12, x13, #4
	add	x13, x13, #8
	mov	w14, #255                       ; =0xff
LBB27_10:                               ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w15, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w15, #7
	b.ne	LBB27_12
; %bb.11:                               ;   in Loop: Header=BB27_10 Depth=1
	cmp	w10, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB27_10
	b	LBB27_15
LBB27_12:
	and	w11, w15, #0xfffffffd
	cmp	w11, #8
	b.ne	LBB27_15
; %bb.13:
	ldr	w11, [x8, #16]
	cmp	w10, w11
	b.hs	LBB27_15
; %bb.14:
	ldr	x11, [x8, #24]
	ldrb	w10, [x11, w10, uxtw]
	tbnz	w10, #1, LBB27_17
LBB27_15:
	cbnz	x3, LBB27_20
; %bb.16:
	cbz	w4, LBB27_20
LBB27_17:
	mov	w0, #0                          ; =0x0
LBB27_18:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #112
LBB27_19:
	ret
LBB27_20:
	cbz	x8, LBB27_17
; %bb.21:
	ldr	x11, [x9]
	and	x9, x11, #0xffff
	cmp	x9, #10
	b.ne	LBB27_17
; %bb.22:
	lsr	x20, x11, #32
	ldr	w9, [x8, #16]
	cmp	w9, w20
	b.ls	LBB27_17
; %bb.23:
	ldr	x9, [x8, #8]
	lsl	x10, x20, #4
	ldrb	w10, [x9, x10]
	cmp	w10, #2
	b.ne	LBB27_17
; %bb.24:
	mov	x21, x4
	mov	x22, x3
	mov	x19, x0
	mov	x23, x2
	cbnz	x20, LBB27_26
; %bb.25:
	mov	x24, x1
	mov	x25, x5
	mov	w1, #0                          ; =0x0
	b	LBB27_40
LBB27_26:
	lsr	x10, x11, #35
	cbnz	x10, LBB27_28
; %bb.27:
	mov	x24, x1
	mov	x25, x5
	mov	w1, #0                          ; =0x0
	b	LBB27_38
LBB27_28:
	lsr	x10, x11, #38
	cbnz	x10, LBB27_30
; %bb.29:
	mov	x24, x1
	mov	x25, x5
	mov	w1, #0                          ; =0x0
	b	LBB27_35
LBB27_30:
	movi.2d	v0, #0000000000000000
	and	x10, x20, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x9
	mov	x13, x10
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB27_31:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB27_31
; %bb.32:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w12, s0
	mov	x24, x1
	mov	x25, x5
	cmp	x20, x10
	b.ne	LBB27_34
; %bb.33:
	mov	x1, x12
	b	LBB27_40
LBB27_34:
	tst	x11, #0x3800000000
	mov	x1, x12
	b.eq	LBB27_38
LBB27_35:
	mov	x12, x10
	and	x10, x20, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x11, x12, x10
	add	x12, x9, x12, lsl #4
	add	x12, x12, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB27_36:                               ; =>This Inner Loop Header: Depth=1
	sub	x13, x12, #48
	sub	x14, x12, #32
	sub	x15, x12, #16
	add	x16, x12, #16
	add	x17, x12, #32
	add	x0, x12, #48
	ldur	b4, [x12, #-64]
	ld1.b	{ v4 }[1], [x13]
	ld1.b	{ v4 }[2], [x14]
	ld1.b	{ v4 }[3], [x15]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x16]
	ld1.b	{ v4 }[6], [x17]
	ld1.b	{ v4 }[7], [x0]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x12, x12, #128
	adds	x11, x11, #8
	b.ne	LBB27_36
; %bb.37:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x20, x10
	b.eq	LBB27_40
LBB27_38:
	sub	x11, x20, x10
	add	x9, x9, x10, lsl #4
LBB27_39:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #16
	cmp	w10, #2
	cinc	w1, w1, eq
	subs	x11, x11, #1
	b.ne	LBB27_39
LBB27_40:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB27_17
; %bb.41:
	ldr	w9, [sp, #4]
	cmp	w9, w20
	b.ne	LBB27_17
; %bb.42:
	mov	x11, x25
	mov	w25, w24
	ldr	x8, [x19]
	ldr	x9, [x8, #40]
	add	x9, x9, x25, lsl #3
	ldr	w9, [x9, #4]
	ldr	w10, [x8, #16]
	cmp	w9, w10
	b.hs	LBB27_17
; %bb.43:
	ldr	x10, [x8, #8]
	lsl	x12, x9, #4
	ldrb	w12, [x10, x12]
	cmp	w12, #2
	b.ne	LBB27_17
; %bb.44:
	mov	x2, x23
	mov	x20, x24
	mov	x24, x11
	cbz	w9, LBB27_47
; %bb.45:
	cmp	w9, #8
	b.hs	LBB27_48
; %bb.46:
	mov	x11, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB27_58
LBB27_47:
	mov	w1, #0                          ; =0x0
	b	LBB27_60
LBB27_48:
	cmp	w9, #64
	b.hs	LBB27_50
; %bb.49:
	mov	x11, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB27_55
LBB27_50:
	movi.2d	v0, #0000000000000000
	and	x11, x9, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x12, x10
	mov	x13, x11
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB27_51:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x12, #16
	ldr	b26, [x12]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #32
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #48
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #64
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #80
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #96
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #112
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #144
	ldur	b28, [x12, #128]
	ld1.b	{ v28 }[1], [x14]
	add	x14, x12, #160
	ld1.b	{ v28 }[2], [x14]
	add	x14, x12, #176
	ld1.b	{ v28 }[3], [x14]
	add	x14, x12, #192
	ld1.b	{ v28 }[4], [x14]
	add	x14, x12, #208
	ld1.b	{ v28 }[5], [x14]
	add	x14, x12, #224
	ld1.b	{ v28 }[6], [x14]
	add	x14, x12, #240
	ld1.b	{ v28 }[7], [x14]
	add	x14, x12, #272
	ldr	b27, [x12, #256]
	ld1.b	{ v27 }[1], [x14]
	add	x14, x12, #288
	ld1.b	{ v27 }[2], [x14]
	add	x14, x12, #304
	ld1.b	{ v27 }[3], [x14]
	add	x14, x12, #320
	ld1.b	{ v27 }[4], [x14]
	add	x14, x12, #336
	ld1.b	{ v27 }[5], [x14]
	add	x14, x12, #352
	ld1.b	{ v27 }[6], [x14]
	add	x14, x12, #368
	ld1.b	{ v27 }[7], [x14]
	add	x14, x12, #400
	ldr	b29, [x12, #384]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #416
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #432
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #448
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #464
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #480
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #496
	ld1.b	{ v29 }[7], [x14]
	add	x14, x12, #528
	ldr	b30, [x12, #512]
	ld1.b	{ v30 }[1], [x14]
	add	x14, x12, #544
	ld1.b	{ v30 }[2], [x14]
	add	x14, x12, #560
	ld1.b	{ v30 }[3], [x14]
	add	x14, x12, #576
	ld1.b	{ v30 }[4], [x14]
	add	x14, x12, #592
	ld1.b	{ v30 }[5], [x14]
	add	x14, x12, #608
	ld1.b	{ v30 }[6], [x14]
	add	x14, x12, #624
	ld1.b	{ v30 }[7], [x14]
	add	x14, x12, #656
	ldr	b31, [x12, #640]
	ld1.b	{ v31 }[1], [x14]
	add	x14, x12, #672
	ld1.b	{ v31 }[2], [x14]
	add	x14, x12, #688
	ld1.b	{ v31 }[3], [x14]
	add	x14, x12, #704
	ld1.b	{ v31 }[4], [x14]
	add	x14, x12, #720
	ld1.b	{ v31 }[5], [x14]
	add	x14, x12, #736
	ld1.b	{ v31 }[6], [x14]
	add	x14, x12, #752
	ld1.b	{ v31 }[7], [x14]
	add	x14, x12, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x12, #768]
	ld1.b	{ v26 }[1], [x14]
	add	x14, x12, #800
	ld1.b	{ v26 }[2], [x14]
	add	x14, x12, #816
	ld1.b	{ v26 }[3], [x14]
	add	x14, x12, #832
	ld1.b	{ v26 }[4], [x14]
	add	x14, x12, #848
	ld1.b	{ v26 }[5], [x14]
	add	x14, x12, #864
	ld1.b	{ v26 }[6], [x14]
	add	x14, x12, #880
	ld1.b	{ v26 }[7], [x14]
	add	x14, x12, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x12, #896]
	ld1.b	{ v29 }[1], [x14]
	add	x14, x12, #928
	ld1.b	{ v29 }[2], [x14]
	add	x14, x12, #944
	ld1.b	{ v29 }[3], [x14]
	add	x14, x12, #960
	ld1.b	{ v29 }[4], [x14]
	add	x14, x12, #976
	ld1.b	{ v29 }[5], [x14]
	add	x14, x12, #992
	ld1.b	{ v29 }[6], [x14]
	add	x14, x12, #1008
	ld1.b	{ v29 }[7], [x14]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x12, x12, #1024
	subs	x13, x13, #64
	b.ne	LBB27_51
; %bb.52:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x11, x9
	b.ne	LBB27_54
; %bb.53:
	mov	x2, x23
	b	LBB27_60
LBB27_54:
	tst	x9, #0x38
	mov	x2, x23
	b.eq	LBB27_58
LBB27_55:
	mov	x13, x11
	and	x11, x9, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x12, x13, x11
	add	x13, x10, x13, lsl #4
	add	x13, x13, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB27_56:                               ; =>This Inner Loop Header: Depth=1
	sub	x14, x13, #48
	sub	x15, x13, #32
	sub	x16, x13, #16
	add	x17, x13, #16
	add	x0, x13, #32
	add	x1, x13, #48
	ldur	b4, [x13, #-64]
	ld1.b	{ v4 }[1], [x14]
	ld1.b	{ v4 }[2], [x15]
	ld1.b	{ v4 }[3], [x16]
	ld1.b	{ v4 }[4], [x13]
	ld1.b	{ v4 }[5], [x17]
	ld1.b	{ v4 }[6], [x0]
	ld1.b	{ v4 }[7], [x1]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x13, x13, #128
	adds	x12, x12, #8
	b.ne	LBB27_56
; %bb.57:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x11, x9
	b.eq	LBB27_60
LBB27_58:
	sub	x9, x9, x11
	add	x10, x10, x11, lsl #4
LBB27_59:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #16
	cmp	w11, #2
	cinc	w1, w1, eq
	subs	x9, x9, #1
	b.ne	LBB27_59
LBB27_60:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	bl	_nvm_ownership_union_variant
	ldrh	w8, [sp, #14]
	cmp	w0, #0
	ccmp	w8, w21, #0, eq
	b.ne	LBB27_17
; %bb.61:
	cbz	w24, LBB27_65
; %bb.62:
	ldr	x9, [x19, #8]
	ldrb	w9, [x9, x25]
	cmp	w9, #1
	b.ne	LBB27_17
; %bb.63:
	ldr	x8, [x19, #16]
	ldrh	w8, [x8, x25, lsl #1]
	cmp	w8, w23
	b.ne	LBB27_17
; %bb.64:
	mov	x0, x19
	mov	x1, x20
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #1                          ; =0x1
	bl	_nvm_affine_owner_access
	cbnz	w21, LBB27_66
	b	LBB27_18
LBB27_65:
	mov	x0, x19
	mov	x1, x20
	bl	_destination
	cbz	w21, LBB27_18
LBB27_66:
	cbz	w0, LBB27_18
; %bb.67:
	mov	w10, #0                         ; =0x0
	ldr	w8, [sp, #4]
	ldr	x9, [x19]
	ldr	x9, [x9, #8]
	add	x23, x9, x8, lsl #4
	mov	w26, #12                        ; =0xc
LBB27_68:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB27_78 Depth 2
                                        ;     Child Loop BB27_84 Depth 2
                                        ;     Child Loop BB27_93 Depth 2
                                        ;       Child Loop BB27_99 Depth 3
                                        ;     Child Loop BB27_113 Depth 2
	ldrh	w1, [x22, w10, uxtw #1]
	cmp	w1, w20
	b.eq	LBB27_17
; %bb.69:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	x8, [x19]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB27_17
; %bb.70:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	x9, [x8, #40]
	add	x12, x9, x1, lsl #3
	ldrb	w9, [x12, #1]
	cbnz	w9, LBB27_17
; %bb.71:                               ;   in Loop: Header=BB27_68 Depth=1
	ldur	x9, [x23, #8]
	ldrh	w11, [sp, #12]
	umaddl	x9, w11, w26, x9
	umaddl	x11, w10, w26, x9
	ldrb	w9, [x11]
	ldr	w11, [x11, #4]
	ldrb	w13, [x19, #41]
	tbz	w13, #0, LBB27_80
; %bb.72:                               ;   in Loop: Header=BB27_68 Depth=1
	ldrh	w13, [x19, #42]
	ldr	x12, [x12]
	cmp	w1, w13
	b.hs	LBB27_81
; %bb.73:                               ;   in Loop: Header=BB27_68 Depth=1
	and	w0, w12, #0xff
	lsr	x13, x12, #32
	cmp	w0, #7
	b.ne	LBB27_106
; %bb.74:                               ;   in Loop: Header=BB27_68 Depth=1
	tst	x12, #0xff00
	b.ne	LBB27_81
; %bb.75:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	x16, [x8, #48]
	cbz	x16, LBB27_81
; %bb.76:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	w14, [x16]
	cmp	x14, x13
	b.ls	LBB27_81
; %bb.77:                               ;   in Loop: Header=BB27_68 Depth=1
	add	x15, x16, #4
	add	x16, x16, #8
	mov	w17, #255                       ; =0xff
LBB27_78:                               ;   Parent Loop BB27_68 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x13, x13, #3
	ldrb	w0, [x15, x13]
	ldr	w13, [x16, x13]
	cmp	w0, #7
	b.ne	LBB27_106
; %bb.79:                               ;   in Loop: Header=BB27_78 Depth=2
	cmp	x13, x14
	ccmp	w17, #0, #4, lo
	sub	w17, w17, #1
	b.ne	LBB27_78
	b	LBB27_81
LBB27_80:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	x12, [x12]
LBB27_81:                               ;   in Loop: Header=BB27_68 Depth=1
	mov	w0, #0                          ; =0x0
	tst	x12, #0xff00
	b.ne	LBB27_18
; %bb.82:                               ;   in Loop: Header=BB27_68 Depth=1
	and	w13, w12, #0xff
	cmp	w9, w13
	b.ne	LBB27_18
; %bb.83:                               ;   in Loop: Header=BB27_68 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w25, w10
	lsr	x10, x12, #32
	mov	x12, x10
	mov	x14, x9
LBB27_84:                               ;   Parent Loop BB27_68 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w14, #7
	b.ne	LBB27_89
; %bb.85:                               ;   in Loop: Header=BB27_84 Depth=2
	ldr	x14, [x8, #48]
	cbz	x14, LBB27_17
; %bb.86:                               ;   in Loop: Header=BB27_84 Depth=2
	ldr	w15, [x14]
	cmp	x12, x15
	mov	w0, #0                          ; =0x0
	ccmp	x11, x15, #2, lo
	b.hs	LBB27_18
; %bb.87:                               ;   in Loop: Header=BB27_84 Depth=2
	cmp	w13, #255
	b.hi	LBB27_18
; %bb.88:                               ;   in Loop: Header=BB27_84 Depth=2
	add	x15, x14, #4
	add	x12, x15, x12, lsl #3
	ldrb	w14, [x12]
	ldr	w12, [x12, #4]
	add	x11, x15, x11, lsl #3
	ldrb	w15, [x11]
	ldr	w11, [x11, #4]
	add	w13, w13, #1
	cmp	w14, w15
	b.eq	LBB27_84
	b	LBB27_18
LBB27_89:                               ;   in Loop: Header=BB27_68 Depth=1
	cmp	x12, x11
	b.ne	LBB27_17
; %bb.90:                               ;   in Loop: Header=BB27_68 Depth=1
	mov	x13, x25
	cbz	w13, LBB27_104
; %bb.91:                               ;   in Loop: Header=BB27_68 Depth=1
	mov	x12, x22
	mov	x11, #0                         ; =0x0
	b	LBB27_93
LBB27_92:                               ;   in Loop: Header=BB27_93 Depth=2
	add	x11, x11, #1
	cmp	x11, x13
	b.eq	LBB27_104
LBB27_93:                               ;   Parent Loop BB27_68 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB27_99 Depth 3
	ldrh	w14, [x12, x11, lsl #1]
	cmp	w14, w1
	b.ne	LBB27_92
; %bb.94:                               ;   in Loop: Header=BB27_93 Depth=2
	tbnz	w24, #0, LBB27_17
; %bb.95:                               ;   in Loop: Header=BB27_93 Depth=2
	mov	x14, x10
	mov	x2, x9
	cmp	w9, #7
	b.ne	LBB27_101
; %bb.96:                               ;   in Loop: Header=BB27_93 Depth=2
	ldr	x14, [x8, #48]
	mov	x12, x22
	mov	x13, x25
	cbz	x14, LBB27_92
; %bb.97:                               ;   in Loop: Header=BB27_93 Depth=2
	ldr	w15, [x14]
	cmp	x15, x10
	b.ls	LBB27_92
; %bb.98:                               ;   in Loop: Header=BB27_93 Depth=2
	add	x16, x14, #4
	add	x17, x14, #8
	mov	w0, #255                        ; =0xff
	mov	x14, x10
LBB27_99:                               ;   Parent Loop BB27_68 Depth=1
                                        ;     Parent Loop BB27_93 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x14, x14, #3
	ldrb	w2, [x16, x14]
	ldr	w14, [x17, x14]
	cmp	w2, #7
	b.ne	LBB27_101
; %bb.100:                              ;   in Loop: Header=BB27_99 Depth=3
	cmp	x14, x15
	ccmp	w0, #0, #4, lo
	sub	w0, w0, #1
	b.ne	LBB27_99
	b	LBB27_92
LBB27_101:                              ;   in Loop: Header=BB27_93 Depth=2
	and	w12, w2, #0xfffffffd
	cmp	w12, #8
	mov	x12, x22
	mov	x13, x25
	b.ne	LBB27_92
; %bb.102:                              ;   in Loop: Header=BB27_93 Depth=2
	ldr	w15, [x8, #16]
	cmp	x14, x15
	b.hs	LBB27_92
; %bb.103:                              ;   in Loop: Header=BB27_93 Depth=2
	ldr	x15, [x8, #24]
	ldrb	w14, [x15, x14]
	tbz	w14, #1, LBB27_92
	b	LBB27_17
LBB27_104:                              ;   in Loop: Header=BB27_68 Depth=1
	cbz	w24, LBB27_109
; %bb.105:                              ;   in Loop: Header=BB27_68 Depth=1
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_destination
	tbnz	w0, #0, LBB27_120
	b	LBB27_17
LBB27_106:                              ;   in Loop: Header=BB27_68 Depth=1
	and	w14, w0, #0xfffffffd
	cmp	w14, #8
	b.ne	LBB27_81
; %bb.107:                              ;   in Loop: Header=BB27_68 Depth=1
	ldr	w14, [x8, #16]
	cmp	x13, x14
	b.hs	LBB27_81
; %bb.108:                              ;   in Loop: Header=BB27_68 Depth=1
	ldr	x14, [x8, #24]
	ldrb	w13, [x14, x13]
	tbz	w13, #1, LBB27_81
	b	LBB27_17
LBB27_109:                              ;   in Loop: Header=BB27_68 Depth=1
	cmp	w9, #7
	b.ne	LBB27_115
; %bb.110:                              ;   in Loop: Header=BB27_68 Depth=1
	ldr	x9, [x8, #48]
	cbz	x9, LBB27_118
; %bb.111:                              ;   in Loop: Header=BB27_68 Depth=1
	ldr	w11, [x9]
	cmp	x11, x10
	b.ls	LBB27_118
; %bb.112:                              ;   in Loop: Header=BB27_68 Depth=1
	add	x12, x9, #4
	add	x13, x9, #8
	mov	w14, #255                       ; =0xff
LBB27_113:                              ;   Parent Loop BB27_68 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x10, #3
	ldrb	w9, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w9, #7
	b.ne	LBB27_115
; %bb.114:                              ;   in Loop: Header=BB27_113 Depth=2
	cmp	x10, x11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB27_113
	b	LBB27_118
LBB27_115:                              ;   in Loop: Header=BB27_68 Depth=1
	and	w9, w9, #0xfffffffd
	cmp	w9, #8
	b.ne	LBB27_118
; %bb.116:                              ;   in Loop: Header=BB27_68 Depth=1
	ldr	w9, [x8, #16]
	cmp	x10, x9
	b.hs	LBB27_118
; %bb.117:                              ;   in Loop: Header=BB27_68 Depth=1
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, x10]
	ubfx	w4, w8, #1, #1
	b	LBB27_119
LBB27_118:                              ;   in Loop: Header=BB27_68 Depth=1
	mov	w4, #0                          ; =0x0
LBB27_119:                              ;   in Loop: Header=BB27_68 Depth=1
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	cbz	w0, LBB27_18
LBB27_120:                              ;   in Loop: Header=BB27_68 Depth=1
	add	w10, w25, #1
	mov	w0, #1                          ; =0x1
	cmp	w10, w21
	b.lo	LBB27_68
	b	LBB27_18
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_union_unpack ; -- Begin function nvm_affine_union_unpack
	.globl	_nvm_affine_union_unpack
	.p2align	2
_nvm_affine_union_unpack:               ; @nvm_affine_union_unpack
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x4
	mov	x19, x3
	mov	x21, x1
	mov	x22, x0
	mov	w5, #1                          ; =0x1
	bl	_union_fields_check
	cbz	w0, LBB28_4
; %bb.1:
	ldp	x8, x9, [x22, #8]
	strb	wzr, [x8, w21, uxtw]
	mov	w10, #65535                     ; =0xffff
	strh	w10, [x9, w21, uxtw #1]
	cbz	w20, LBB28_4
; %bb.2:
	mov	w11, w20
	mov	w12, #1                         ; =0x1
LBB28_3:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w13, [x19], #2
	strb	w12, [x8, x13]
	strh	w10, [x9, x13, lsl #1]
	subs	x11, x11, #1
	b.ne	LBB28_3
LBB28_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_region_begin ; -- Begin function nvm_affine_region_begin
	.globl	_nvm_affine_region_begin
	.p2align	2
_nvm_affine_region_begin:               ; @nvm_affine_region_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB29_3
; %bb.1:
	ldr	w8, [x0, #36]
	cmn	w8, #1
	b.eq	LBB29_4
; %bb.2:
	add	w8, w8, #1
	str	w8, [x0, #36]
	mov	w0, #1                          ; =0x1
LBB29_3:
	ret
LBB29_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_region_end  ; -- Begin function nvm_affine_region_end
	.globl	_nvm_affine_region_end
	.p2align	2
_nvm_affine_region_end:                 ; @nvm_affine_region_end
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB30_12
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	w9, [x0, #36]
	cbz	w9, LBB30_10
; %bb.2:
	ldr	w8, [x19, #32]
	cbz	w8, LBB30_9
; %bb.3:
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB30_5
LBB30_4:                                ;   in Loop: Header=BB30_5 Depth=1
	add	x21, x21, #1
	add	x20, x20, #56
	cmp	x21, x8
	b.hs	LBB30_8
LBB30_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19, #24]
	ldrb	w10, [x9, x20]
	cmp	w10, #1
	b.ne	LBB30_4
; %bb.6:                                ;   in Loop: Header=BB30_5 Depth=1
	add	x9, x9, x20
	ldr	w10, [x9, #4]
	ldr	w11, [x19, #36]
	cmp	w10, w11
	b.ne	LBB30_4
; %bb.7:                                ;   in Loop: Header=BB30_5 Depth=1
	ldr	x0, [x9, #32]
	bl	_free
	ldr	x8, [x19, #24]
	add	x8, x8, x20
	str	xzr, [x8, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	ldr	w8, [x19, #32]
	b	LBB30_4
LBB30_8:
	ldr	w9, [x19, #36]
LBB30_9:
	sub	w8, w9, #1
	str	w8, [x19, #36]
	mov	w0, #1                          ; =0x1
	b	LBB30_11
LBB30_10:
	mov	w0, #0                          ; =0x0
LBB30_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB30_12:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_borrow      ; -- Begin function nvm_affine_borrow
	.globl	_nvm_affine_borrow
	.p2align	2
_nvm_affine_borrow:                     ; @nvm_affine_borrow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB31_19
; %bb.1:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x9, [x0]
	ldrh	w8, [x9, #56]
	cmp	w2, w8
	b.hs	LBB31_17
; %bb.2:
	ldr	x20, [x9, #40]
	add	x8, x20, w2, uxtw #3
	ldrb	w10, [x8, #1]
	cbnz	w10, LBB31_17
; %bb.3:
	ldrb	w10, [x0, #41]
	cmp	w10, #1
	b.ne	LBB31_15
; %bb.4:
	ldrh	w10, [x0, #42]
	cmp	w2, w10
	b.hs	LBB31_15
; %bb.5:
	ldr	x11, [x8]
	and	w15, w11, #0xff
	lsr	x10, x11, #32
	cmp	w15, #7
	b.ne	LBB31_12
; %bb.6:
	tst	x11, #0xff00
	b.ne	LBB31_15
; %bb.7:
	ldr	x13, [x9, #48]
	cbz	x13, LBB31_15
; %bb.8:
	ldr	w11, [x13]
	cmp	w11, w10
	b.ls	LBB31_15
; %bb.9:
	add	x12, x13, #4
	add	x13, x13, #8
	mov	w14, #255                       ; =0xff
LBB31_10:                               ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w15, [x12, x10]
	ldr	w10, [x13, x10]
	cmp	w15, #7
	b.ne	LBB31_12
; %bb.11:                               ;   in Loop: Header=BB31_10 Depth=1
	cmp	w10, w11
	ccmp	w14, #0, #4, lo
	sub	w14, w14, #1
	b.ne	LBB31_10
	b	LBB31_15
LBB31_12:
	and	w11, w15, #0xfffffffd
	cmp	w11, #8
	b.ne	LBB31_15
; %bb.13:
	ldr	w11, [x9, #16]
	cmp	w10, w11
	b.hs	LBB31_15
; %bb.14:
	ldr	x9, [x9, #24]
	ldrb	w9, [x9, w10, uxtw]
	tbnz	w9, #1, LBB31_17
LBB31_15:
	mov	w22, w2
	ldr	x9, [x0, #8]
	ldrb	w9, [x9, x22]
	cmp	w9, #1
	b.ne	LBB31_17
; %bb.16:
	ldrb	w8, [x8]
	cmp	w8, #7
	b.ne	LBB31_20
LBB31_17:
	mov	w0, #0                          ; =0x0
LBB31_18:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
LBB31_19:
	ret
LBB31_20:
	mov	x21, x5
	mov	x19, x1
	mov	x8, x4
	add	x4, sp, #40
	mov	x26, x0
	mov	x25, x2
	mov	x1, x2
	mov	x24, x3
	mov	x2, x3
	mov	x23, x8
	mov	x3, x8
	bl	_resolve
	cbz	w0, LBB31_18
; %bb.21:
	mov	x0, x26
	ldr	x8, [x26, #56]
	add	x9, x20, x22, lsl #3
	ldr	w9, [x9, #4]
	ldr	w10, [sp, #44]
	str	x8, [sp]
	strh	w25, [sp, #8]
	strh	wzr, [sp, #10]
	str	w9, [sp, #12]
	str	x24, [sp, #16]
	strh	w23, [sp, #24]
	strh	wzr, [sp, #26]
	stp	w10, w21, [sp, #28]
	str	wzr, [sp, #36]
	mov	x2, sp
	mov	x1, x19
	mov	w3, #-1                         ; =0xffffffff
	bl	_borrow_install
	b	LBB31_18
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_install
_borrow_install:                        ; @borrow_install
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB32_6
; %bb.1:
	ldr	w8, [x0, #36]
	cbz	w8, LBB32_5
; %bb.2:
	ldr	w8, [x0, #32]
	cmp	w1, w8
	b.hs	LBB32_5
; %bb.3:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x8, [x0, #24]
	mov	w9, #56                         ; =0x38
	umull	x9, w1, w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB32_7
LBB32_4:
	mov	w0, #0                          ; =0x0
	b	LBB32_36
LBB32_5:
	mov	w0, #0                          ; =0x0
LBB32_6:
	ret
LBB32_7:
	ldr	x8, [x0]
	ldr	x9, [x2]
	ldr	x10, [x0, #56]
	cmp	x9, x10
	mov	x21, x0
	mov	x22, x1
	b.ne	LBB32_10
; %bb.8:
	ldrh	w10, [x2, #8]
	ldrh	w11, [x8, #56]
	cmp	w10, w11
	b.hs	LBB32_10
; %bb.9:
	mov	x19, x3
	ldr	x9, [x8, #40]
	add	x9, x9, x10, lsl #3
	ldr	w1, [x9, #4]
	b	LBB32_17
LBB32_10:
	ldrh	w10, [x0, #64]
	cbz	x10, LBB32_16
; %bb.11:
	add	x11, x0, #84
	b	LBB32_13
LBB32_12:                               ;   in Loop: Header=BB32_13 Depth=1
	add	x11, x11, #16
	subs	x10, x10, #1
	b.eq	LBB32_16
LBB32_13:                               ; =>This Inner Loop Header: Depth=1
	ldur	x12, [x11, #-12]
	cmp	x12, x9
	b.ne	LBB32_12
; %bb.14:                               ;   in Loop: Header=BB32_13 Depth=1
	ldurh	w12, [x11, #-4]
	ldrh	w13, [x2, #8]
	cmp	w12, w13
	b.ne	LBB32_12
; %bb.15:
	mov	x19, x3
	ldr	w1, [x11]
	b	LBB32_17
LBB32_16:
	mov	x19, x3
	mov	w1, #-1                         ; =0xffffffff
LBB32_17:
	add	x0, x8, #8
	mov	x24, x2
	bl	_nvm_reference_place_valid
	cbz	w0, LBB32_36
; %bb.18:
	ldr	x10, [x21]
	ldr	w9, [x24, #28]
	ldr	w11, [x10, #16]
	cmp	w9, w11
	b.hs	LBB32_4
; %bb.19:
	ldr	x10, [x10, #24]
	ldrb	w9, [x10, x9]
	tbz	w9, #1, LBB32_4
; %bb.20:
	mov	x8, x21
	mov	x1, x24
	mov	w23, w19
	ldr	w10, [x21, #32]
	mov	x9, x22
	cbz	w10, LBB32_31
; %bb.21:
	mov	x19, #0                         ; =0x0
	mov	w20, #-1                        ; =0xffffffff
	cmp	x23, x20
	cset	w25, ne
	mov	w26, #56                        ; =0x38
	b	LBB32_23
LBB32_22:                               ;   in Loop: Header=BB32_23 Depth=1
	add	x19, x19, #1
	cmp	x19, w10, uxtw
	b.hs	LBB32_31
LBB32_23:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_27 Depth 2
	ldr	x11, [x8, #24]
	mul	x12, x19, x26
	ldrb	w12, [x11, x12]
	cmp	w12, #1
	b.ne	LBB32_22
; %bb.24:                               ;   in Loop: Header=BB32_23 Depth=1
	mov	x13, x25
	cmp	x23, x20
	b.eq	LBB32_28
; %bb.25:                               ;   in Loop: Header=BB32_23 Depth=1
	mov	x13, x25
	cmp	x19, x23
	b.eq	LBB32_28
; %bb.26:                               ;   in Loop: Header=BB32_23 Depth=1
	mov	w12, #1                         ; =0x1
	mov	x14, x23
LBB32_27:                               ;   Parent Loop BB32_23 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	madd	x13, x14, x26, x11
	ldr	w14, [x13, #8]
	cmp	w12, w10
	ccmn	w14, #1, #4, lo
	cset	w13, ne
	add	w12, w12, #1
	cmp	w13, #1
	ccmp	x19, x14, #4, eq
	b.ne	LBB32_27
LBB32_28:                               ;   in Loop: Header=BB32_23 Depth=1
	tbnz	w13, #0, LBB32_22
; %bb.29:                               ;   in Loop: Header=BB32_23 Depth=1
	madd	x8, x19, x26, x11
	add	x0, x8, #16
	bl	_nvm_reference_holds_conflict
	tbnz	w0, #0, LBB32_4
; %bb.30:                               ;   in Loop: Header=BB32_23 Depth=1
	mov	x8, x21
	ldr	w10, [x21, #32]
	mov	x1, x24
	mov	x9, x22
	b	LBB32_22
LBB32_31:
	ldrh	w10, [x1, #24]
	cbz	x10, LBB32_34
; %bb.32:
	lsl	x20, x10, #1
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB32_36
; %bb.33:
	mov	x19, x0
	ldr	x1, [x24, #16]
	mov	x2, x20
	bl	_memcpy
	mov	x1, x24
	mov	x8, x21
	mov	x9, x22
	b	LBB32_35
LBB32_34:
	mov	x19, #0                         ; =0x0
LBB32_35:
	str	x19, [x1, #16]
	ldr	x10, [x8, #24]
	mov	w9, w9
	mov	w11, #56                        ; =0x38
	umaddl	x9, w9, w11, x10
	ldr	w8, [x8, #36]
	ldr	x10, [x1, #32]
	str	x10, [sp, #32]
	ldp	q0, q1, [x1]
	stp	q0, q1, [sp]
	mov	w0, #1                          ; =0x1
	strb	w0, [x9]
	sturh	wzr, [x9, #1]
	strb	wzr, [x9, #3]
	stp	w8, w23, [x9, #4]
	str	wzr, [x9, #12]
	stp	q0, q1, [x9, #16]
	str	x10, [x9, #48]
LBB32_36:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_reborrow    ; -- Begin function nvm_affine_reborrow
	.globl	_nvm_affine_reborrow
	.p2align	2
_nvm_affine_reborrow:                   ; @nvm_affine_reborrow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB33_7
; %bb.1:
	ldr	w8, [x0, #32]
	cmp	w2, w8
	b.hs	LBB33_8
; %bb.2:
	ldr	x8, [x0, #24]
	mov	w9, #56                         ; =0x38
	umaddl	x9, w2, w9, x8
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB33_8
; %bb.3:
	ldr	w10, [x9, #4]
	ldr	w11, [x0, #36]
	cmp	w10, w11
	b.hs	LBB33_8
; %bb.4:
	cmp	w3, #2
	b.ne	LBB33_6
; %bb.5:
	ldr	w9, [x9, #48]
	cmp	w9, #2
	b.ne	LBB33_8
LBB33_6:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, w2
	mov	w10, #56                        ; =0x38
	umaddl	x8, w9, w10, x8
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [sp]
	ldr	w8, [x8, #52]
	stp	w3, w8, [sp, #32]
	mov	x3, x2
	mov	x2, sp
	bl	_borrow_install
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
LBB33_7:
	ret
LBB33_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_reference_access ; -- Begin function nvm_affine_reference_access
	.globl	_nvm_affine_reference_access
	.p2align	2
_nvm_affine_reference_access:           ; @nvm_affine_reference_access
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB34_17
; %bb.1:
	ldr	w8, [x0, #32]
	cmp	w1, w8
	b.hs	LBB34_16
; %bb.2:
	ldr	x9, [x0, #24]
	mov	w10, #56                        ; =0x38
	umaddl	x10, w1, w10, x9
	ldrb	w11, [x10]
	cmp	w11, #1
	b.ne	LBB34_16
; %bb.3:
	ldr	x11, [x0]
	ldr	x11, [x11, #8]
	ldr	w12, [x10, #44]
	add	x11, x11, x12, lsl #4
	ldrh	w12, [x11, #2]
	cmp	w2, w12
	b.hs	LBB34_16
; %bb.4:
	ldr	x11, [x11, #8]
	mov	w12, #12                        ; =0xc
	umull	x12, w2, w12
	ldrb	w11, [x11, x12]
	sub	w11, w11, #1
	cmp	w11, #3
	b.hi	LBB34_16
; %bb.5:
	cbz	w3, LBB34_7
; %bb.6:
	ldr	w10, [x10, #48]
	cmp	w10, #2
	b.ne	LBB34_16
LBB34_7:
	mov	x10, #0                         ; =0x0
	mov	w11, w1
	mov	w12, #56                        ; =0x38
	mov	w0, #1                          ; =0x1
	b	LBB34_9
LBB34_8:                                ;   in Loop: Header=BB34_9 Depth=1
	add	x10, x10, #1
	cmp	x10, x8
	b.eq	LBB34_17
LBB34_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB34_12 Depth 2
	cmp	x10, x11
	b.eq	LBB34_8
; %bb.10:                               ;   in Loop: Header=BB34_9 Depth=1
	mul	x13, x10, x12
	ldrb	w13, [x9, x13]
	cmp	w13, #1
	b.ne	LBB34_8
; %bb.11:                               ;   in Loop: Header=BB34_9 Depth=1
	mov	x14, x10
LBB34_12:                               ;   Parent Loop BB34_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umaddl	x14, w14, w12, x9
	ldr	w14, [x14, #8]
	cmp	w13, w8
	ccmn	w14, #1, #4, lo
	cset	w15, ne
	add	w13, w13, #1
	cmp	w15, #1
	ccmp	w14, w1, #4, eq
	b.ne	LBB34_12
; %bb.13:                               ;   in Loop: Header=BB34_9 Depth=1
	cbz	w15, LBB34_8
; %bb.14:                               ;   in Loop: Header=BB34_9 Depth=1
	tbnz	w3, #0, LBB34_16
; %bb.15:                               ;   in Loop: Header=BB34_9 Depth=1
	madd	x13, x10, x12, x9
	ldr	w13, [x13, #48]
	cmp	w13, #2
	b.ne	LBB34_8
LBB34_16:
	mov	w0, #0                          ; =0x0
LBB34_17:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_reference_field ; -- Begin function nvm_affine_reference_field
	.globl	_nvm_affine_reference_field
	.p2align	2
_nvm_affine_reference_field:            ; @nvm_affine_reference_field
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB35_18
; %bb.1:
	cbz	x4, LBB35_18
; %bb.2:
	ldr	w9, [x8, #32]
	cmp	w1, w9
	b.hs	LBB35_17
; %bb.3:
	ldr	x10, [x8, #24]
	mov	w11, #56                        ; =0x38
	umaddl	x11, w1, w11, x10
	ldrb	w12, [x11]
	cmp	w12, #1
	b.ne	LBB35_17
; %bb.4:
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w12, [x11, #44]
	add	x8, x8, x12, lsl #4
	ldrh	w12, [x8, #2]
	cmp	w2, w12
	b.hs	LBB35_17
; %bb.5:
	ldr	x8, [x8, #8]
	mov	w12, #12                        ; =0xc
	umull	x12, w2, w12
	ldrb	w8, [x8, x12]
	sub	w12, w8, #1
	cmp	w12, #3
	b.hi	LBB35_17
; %bb.6:
	cbz	w3, LBB35_8
; %bb.7:
	ldr	w11, [x11, #48]
	cmp	w11, #2
	b.ne	LBB35_17
LBB35_8:
	mov	x11, #0                         ; =0x0
	mov	w12, w1
	mov	w13, #56                        ; =0x38
	b	LBB35_10
LBB35_9:                                ;   in Loop: Header=BB35_10 Depth=1
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB35_19
LBB35_10:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB35_13 Depth 2
	cmp	x11, x12
	b.eq	LBB35_9
; %bb.11:                               ;   in Loop: Header=BB35_10 Depth=1
	mul	x14, x11, x13
	ldrb	w14, [x10, x14]
	cmp	w14, #1
	b.ne	LBB35_9
; %bb.12:                               ;   in Loop: Header=BB35_10 Depth=1
	mov	x15, x11
LBB35_13:                               ;   Parent Loop BB35_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umaddl	x15, w15, w13, x10
	ldr	w15, [x15, #8]
	cmp	w14, w9
	ccmn	w15, #1, #4, lo
	cset	w16, ne
	add	w14, w14, #1
	cmp	w16, #1
	ccmp	w15, w1, #4, eq
	b.ne	LBB35_13
; %bb.14:                               ;   in Loop: Header=BB35_10 Depth=1
	cbz	w16, LBB35_9
; %bb.15:                               ;   in Loop: Header=BB35_10 Depth=1
	tbnz	w3, #0, LBB35_17
; %bb.16:                               ;   in Loop: Header=BB35_10 Depth=1
	madd	x14, x11, x13, x10
	ldr	w14, [x14, #48]
	cmp	w14, #2
	b.ne	LBB35_9
LBB35_17:
	mov	w0, #0                          ; =0x0
LBB35_18:
	ret
LBB35_19:
	strb	w8, [x4]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_can_exit    ; -- Begin function nvm_affine_can_exit
	.globl	_nvm_affine_can_exit
	.p2align	2
_nvm_affine_can_exit:                   ; @nvm_affine_can_exit
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB36_2
; %bb.1:
	ldr	w8, [x0, #36]
	cbz	w8, LBB36_4
LBB36_2:
	mov	w8, #0                          ; =0x0
LBB36_3:
	mov	x0, x8
	ret
LBB36_4:
	ldr	x9, [x0]
	mov	w8, #65535                      ; =0xffff
	cmp	w1, w8
	b.ne	LBB36_9
; %bb.5:
	ldrb	w8, [x9, #32]
	cbnz	w8, LBB36_2
; %bb.6:
	ldrh	w10, [x9, #56]
LBB36_7:
	cbz	w10, LBB36_34
; %bb.8:
	mov	x11, #0                         ; =0x0
	mov	w12, w1
	mov	w10, w10
	b	LBB36_22
LBB36_9:
	ldrh	w10, [x9, #56]
	cmp	w1, w10
	b.hs	LBB36_2
; %bb.10:
	ldr	x8, [x9, #40]
	add	x8, x8, w1, uxtw #3
	ldrb	w11, [x8, #1]
	cbnz	w11, LBB36_2
; %bb.11:
	ldrb	w11, [x0, #41]
	cmp	w11, #1
	b.ne	LBB36_38
; %bb.12:
	ldrh	w11, [x0, #42]
	cmp	w1, w11
	b.hs	LBB36_38
; %bb.13:
	ldr	x12, [x8]
	and	w16, w12, #0xff
	lsr	x11, x12, #32
	cmp	w16, #7
	b.ne	LBB36_35
; %bb.14:
	tst	x12, #0xff00
	b.ne	LBB36_38
; %bb.15:
	ldr	x14, [x9, #48]
	cbz	x14, LBB36_38
; %bb.16:
	ldr	w12, [x14]
	cmp	w12, w11
	b.ls	LBB36_38
; %bb.17:
	add	x13, x14, #4
	add	x14, x14, #8
	mov	w15, #255                       ; =0xff
LBB36_18:                               ; =>This Inner Loop Header: Depth=1
	lsl	x11, x11, #3
	ldrb	w16, [x13, x11]
	ldr	w11, [x14, x11]
	cmp	w16, #7
	b.ne	LBB36_35
; %bb.19:                               ;   in Loop: Header=BB36_18 Depth=1
	cmp	w11, w12
	ccmp	w15, #0, #4, lo
	sub	w15, w15, #1
	b.ne	LBB36_18
	b	LBB36_38
LBB36_20:                               ;   in Loop: Header=BB36_22 Depth=1
	tst	x13, #0xff00
	b.eq	LBB36_29
LBB36_21:                               ;   in Loop: Header=BB36_22 Depth=1
	add	x11, x11, #1
	mov	w8, #1                          ; =0x1
	cmp	x11, x10
	b.eq	LBB36_3
LBB36_22:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_32 Depth 2
	cmp	x11, x12
	b.eq	LBB36_21
; %bb.23:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	x8, [x0, #8]
	ldrb	w8, [x8, x11]
	cmp	w8, #1
	b.ne	LBB36_21
; %bb.24:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	x8, [x9, #40]
	add	x8, x8, x11, lsl #3
	ldrb	w13, [x8, #1]
	cbnz	w13, LBB36_21
; %bb.25:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	x13, [x8]
	and	w17, w13, #0xff
	lsr	x8, x13, #32
	cmp	w17, #7
	b.eq	LBB36_20
LBB36_26:                               ;   in Loop: Header=BB36_22 Depth=1
	and	w13, w17, #0xfffffffd
	cmp	w13, #8
	b.ne	LBB36_21
; %bb.27:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	w13, [x9, #16]
	cmp	x8, x13
	b.hs	LBB36_21
; %bb.28:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	x13, [x9, #24]
	ldrb	w8, [x13, x8]
	tbz	w8, #1, LBB36_21
	b	LBB36_2
LBB36_29:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	x15, [x9, #48]
	cbz	x15, LBB36_21
; %bb.30:                               ;   in Loop: Header=BB36_22 Depth=1
	ldr	w13, [x15]
	cmp	x13, x8
	b.ls	LBB36_21
; %bb.31:                               ;   in Loop: Header=BB36_22 Depth=1
	add	x14, x15, #4
	add	x15, x15, #8
	mov	w16, #255                       ; =0xff
LBB36_32:                               ;   Parent Loop BB36_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x8, x8, #3
	ldrb	w17, [x14, x8]
	ldr	w8, [x15, x8]
	cmp	w17, #7
	b.ne	LBB36_26
; %bb.33:                               ;   in Loop: Header=BB36_32 Depth=2
	cmp	x8, x13
	ccmp	w16, #0, #4, lo
	sub	w16, w16, #1
	b.ne	LBB36_32
	b	LBB36_21
LBB36_34:
	mov	w0, #1                          ; =0x1
	ret
LBB36_35:
	and	w12, w16, #0xfffffffd
	cmp	w12, #8
	b.ne	LBB36_38
; %bb.36:
	ldr	w12, [x9, #16]
	cmp	w11, w12
	b.hs	LBB36_38
; %bb.37:
	ldr	x12, [x9, #24]
	ldrb	w11, [x12, w11, uxtw]
	tbnz	w11, #1, LBB36_2
LBB36_38:
	ldr	x11, [x0, #8]
	ldrb	w11, [x11, w1, uxtw]
	cmp	w11, #1
	b.ne	LBB36_2
; %bb.39:
	ldr	x12, [x8]
	ldr	x8, [x9, #32]
	eor	w11, w8, w12
	tst	x11, #0xff00
	b.ne	LBB36_2
; %bb.40:
	and	w14, w8, #0xff
	cmp	w14, w12, uxtb
	b.ne	LBB36_2
; %bb.41:
	mov	w11, #0                         ; =0x0
	lsr	x12, x12, #32
	lsr	x13, x8, #32
LBB36_42:                               ; =>This Inner Loop Header: Depth=1
	cmp	w14, #7
	b.ne	LBB36_47
; %bb.43:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x14, [x9, #48]
	cbz	x14, LBB36_2
; %bb.44:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	w8, [x14]
	cmp	x12, x8
	ccmp	x13, x8, #2, lo
	b.hs	LBB36_2
; %bb.45:                               ;   in Loop: Header=BB36_42 Depth=1
	mov	w8, #0                          ; =0x0
	cmp	w11, #255
	b.hi	LBB36_3
; %bb.46:                               ;   in Loop: Header=BB36_42 Depth=1
	add	x15, x14, #4
	add	x12, x15, x12, lsl #3
	ldrb	w14, [x12]
	ldr	w12, [x12, #4]
	add	x13, x15, x13, lsl #3
	ldrb	w15, [x13]
	ldr	w13, [x13, #4]
	add	w11, w11, #1
	cmp	w14, w15
	b.eq	LBB36_42
	b	LBB36_3
LBB36_47:
	cmp	x12, x13
	b.ne	LBB36_2
	b	LBB36_7
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_local_info  ; -- Begin function nvm_affine_local_info
	.globl	_nvm_affine_local_info
	.p2align	2
_nvm_affine_local_info:                 ; @nvm_affine_local_info
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB37_9
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x9, [x0]
	ldrh	w8, [x9, #56]
	cmp	w1, w8
	b.hs	LBB37_7
; %bb.2:
	mov	w8, #0                          ; =0x0
	cbz	x3, LBB37_8
; %bb.3:
	cbz	x2, LBB37_8
; %bb.4:
	ldr	x11, [x0, #8]
	mov	w10, w1
	ldrb	w11, [x11, x10]
	tbz	w11, #0, LBB37_8
; %bb.5:
	ldr	x8, [x9, #40]
	add	x8, x8, x10, lsl #3
	ldrb	w20, [x8]
	ldrb	w19, [x8, #1]
	ldrb	w8, [x0, #40]
	cmp	w8, #1
	b.ne	LBB37_10
; %bb.6:
	cbz	w19, LBB37_10
LBB37_7:
	mov	w8, #0                          ; =0x0
LBB37_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB37_9:
	mov	w0, #0                          ; =0x0
	ret
LBB37_10:
	cmp	w19, #0
	ccmp	w20, #10, #4, eq
	b.eq	LBB37_12
; %bb.11:
	mov	x21, x2
	mov	x2, #0                          ; =0x0
	mov	x22, x3
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	mov	x2, x21
	mov	x3, x22
	cbz	w0, LBB37_7
LBB37_12:
	strb	w20, [x2]
	strb	w19, [x3]
	mov	w8, #1                          ; =0x1
	b	LBB37_8
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_scalar_field ; -- Begin function nvm_affine_scalar_field
	.globl	_nvm_affine_scalar_field
	.p2align	2
_nvm_affine_scalar_field:               ; @nvm_affine_scalar_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	strh	w2, [sp, #14]
	cbz	x0, LBB38_13
; %bb.1:
	ldr	x9, [x0]
	ldrh	w8, [x9, #56]
	cmp	w1, w8
	b.hs	LBB38_13
; %bb.2:
	mov	w8, #0                          ; =0x0
	cbz	x3, LBB38_14
; %bb.3:
	ldr	x11, [x0, #8]
	mov	w10, w1
	ldrb	w11, [x11, x10]
	tbz	w11, #0, LBB38_14
; %bb.4:
	ldr	x8, [x9, #40]
	add	x8, x8, x10, lsl #3
	ldrb	w10, [x8]
	cmp	w10, #8
	b.ne	LBB38_13
; %bb.5:
	ldr	w10, [x8, #4]
	ldr	w11, [x9, #16]
	cmp	w10, w11
	b.hs	LBB38_13
; %bb.6:
	ldr	x9, [x9, #8]
	add	x20, x9, x10, lsl #4
	ldrh	w9, [x20, #2]
	cmp	w2, w9
	b.hs	LBB38_13
; %bb.7:
	ldr	x9, [x20, #8]
	mov	w10, #12                        ; =0xc
	umull	x10, w2, w10
	ldrb	w21, [x9, x10]
	sub	w9, w21, #1
	cmp	w9, #3
	b.hi	LBB38_13
; %bb.8:
	mov	x19, x3
	ldrb	w8, [x8, #1]
	cbz	w8, LBB38_10
; %bb.9:
	mov	w3, #0                          ; =0x0
	bl	_nvm_affine_reference_access
	tbnz	w0, #0, LBB38_12
	b	LBB38_13
LBB38_10:
	add	x2, sp, #14
	mov	w3, #1                          ; =0x1
	mov	w4, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	cbz	w0, LBB38_13
; %bb.11:
	ldr	x8, [x20, #8]
	ldrh	w9, [sp, #14]
	mov	w10, #12                        ; =0xc
	umull	x9, w9, w10
	ldrb	w21, [x8, x9]
LBB38_12:
	strb	w21, [x19]
	mov	w8, #1                          ; =0x1
	b	LBB38_14
LBB38_13:
	mov	w8, #0                          ; =0x0
LBB38_14:
	mov	x0, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_string_field ; -- Begin function nvm_affine_string_field
	.globl	_nvm_affine_string_field
	.p2align	2
_nvm_affine_string_field:               ; @nvm_affine_string_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	strh	w2, [sp, #14]
	cbz	x0, LBB39_11
; %bb.1:
	ldr	x9, [x0]
	ldrh	w8, [x9, #56]
	cmp	w1, w8
	b.hs	LBB39_11
; %bb.2:
	mov	w8, #0                          ; =0x0
	cbz	x3, LBB39_12
; %bb.3:
	ldr	x11, [x0, #8]
	mov	w10, w1
	ldrb	w11, [x11, x10]
	tbz	w11, #0, LBB39_12
; %bb.4:
	ldr	x8, [x9, #40]
	add	x8, x8, x10, lsl #3
	ldrb	w10, [x8]
	ldrb	w11, [x8, #1]
	cmp	w11, #0
	ccmp	w10, #8, #0, eq
	b.ne	LBB39_11
; %bb.5:
	ldr	w8, [x8, #4]
	ldr	w10, [x9, #16]
	cmp	w8, w10
	b.hs	LBB39_11
; %bb.6:
	ldr	x9, [x9, #8]
	add	x8, x9, x8, lsl #4
	ldrh	w9, [x8, #2]
	cmp	w2, w9
	b.hs	LBB39_11
; %bb.7:
	ldr	x8, [x8, #8]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w2, w9, x8
	ldrb	w9, [x8]
	cmp	w9, #5
	b.ne	LBB39_11
; %bb.8:
	ldr	w8, [x8, #4]
	cmn	w8, #1
	b.ne	LBB39_11
; %bb.9:
	mov	x19, x3
	add	x2, sp, #14
	mov	w3, #1                          ; =0x1
	mov	w4, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	cbz	w0, LBB39_11
; %bb.10:
	mov	w8, #5                          ; =0x5
	strb	w8, [x19]
	mov	w8, #1                          ; =0x1
	b	LBB39_12
LBB39_11:
	mov	w8, #0                          ; =0x0
LBB39_12:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_can_exit_scalar ; -- Begin function nvm_affine_can_exit_scalar
	.globl	_nvm_affine_can_exit_scalar
	.p2align	2
_nvm_affine_can_exit_scalar:            ; @nvm_affine_can_exit_scalar
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB40_20
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cmp	w1, #4
	b.hi	LBB40_20
; %bb.2:
	ldr	w9, [x8, #36]
	cbnz	w9, LBB40_20
; %bb.3:
	ldr	x9, [x8]
	ldrb	w10, [x9, #32]
	cmp	w10, w1
	b.ne	LBB40_19
; %bb.4:
	ldrh	w10, [x9, #56]
	cbz	x10, LBB40_21
; %bb.5:
	mov	x11, #0                         ; =0x0
	ldr	x8, [x8, #8]
	b	LBB40_8
LBB40_6:                                ;   in Loop: Header=BB40_8 Depth=1
	tst	x13, #0xff00
	b.eq	LBB40_14
LBB40_7:                                ;   in Loop: Header=BB40_8 Depth=1
	add	x11, x11, #1
	cmp	x11, x10
	b.eq	LBB40_21
LBB40_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB40_17 Depth 2
	ldrb	w12, [x8, x11]
	cmp	w12, #1
	b.ne	LBB40_7
; %bb.9:                                ;   in Loop: Header=BB40_8 Depth=1
	ldr	x12, [x9, #40]
	add	x12, x12, x11, lsl #3
	ldrb	w13, [x12, #1]
	cbnz	w13, LBB40_7
; %bb.10:                               ;   in Loop: Header=BB40_8 Depth=1
	ldr	x13, [x12]
	and	w17, w13, #0xff
	lsr	x12, x13, #32
	cmp	w17, #7
	b.eq	LBB40_6
LBB40_11:                               ;   in Loop: Header=BB40_8 Depth=1
	and	w13, w17, #0xfffffffd
	cmp	w13, #8
	b.ne	LBB40_7
; %bb.12:                               ;   in Loop: Header=BB40_8 Depth=1
	ldr	w13, [x9, #16]
	cmp	x12, x13
	b.hs	LBB40_7
; %bb.13:                               ;   in Loop: Header=BB40_8 Depth=1
	ldr	x13, [x9, #24]
	ldrb	w12, [x13, x12]
	tbz	w12, #1, LBB40_7
	b	LBB40_19
LBB40_14:                               ;   in Loop: Header=BB40_8 Depth=1
	ldr	x15, [x9, #48]
	cbz	x15, LBB40_7
; %bb.15:                               ;   in Loop: Header=BB40_8 Depth=1
	ldr	w13, [x15]
	cmp	x13, x12
	b.ls	LBB40_7
; %bb.16:                               ;   in Loop: Header=BB40_8 Depth=1
	add	x14, x15, #4
	add	x15, x15, #8
	mov	w16, #255                       ; =0xff
LBB40_17:                               ;   Parent Loop BB40_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x12, x12, #3
	ldrb	w17, [x14, x12]
	ldr	w12, [x15, x12]
	cmp	w17, #7
	b.ne	LBB40_11
; %bb.18:                               ;   in Loop: Header=BB40_17 Depth=2
	cmp	x12, x13
	ccmp	w16, #0, #4, lo
	sub	w16, w16, #1
	b.ne	LBB40_17
	b	LBB40_7
LBB40_19:
	mov	w0, #0                          ; =0x0
LBB40_20:
	ret
LBB40_21:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_local_type  ; -- Begin function nvm_affine_local_type
	.globl	_nvm_affine_local_type
	.p2align	2
_nvm_affine_local_type:                 ; @nvm_affine_local_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB41_6
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB41_6
; %bb.2:
	ldr	x8, [x8]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB41_6
; %bb.3:
	ldr	x8, [x8, #40]
	add	x8, x8, w1, uxtw #3
	ldrb	w9, [x8, #1]
	cbz	w9, LBB41_5
; %bb.4:
	mov	w0, #0                          ; =0x0
	ret
LBB41_5:
	ldr	w9, [x8, #4]
	ldrb	w8, [x8]
	strb	w8, [x2]
	sturh	wzr, [x2, #1]
	strb	wzr, [x2, #3]
	str	w9, [x2, #4]
	mov	w0, #1                          ; =0x1
LBB41_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_type_is_owned ; -- Begin function nvm_affine_type_is_owned
	.globl	_nvm_affine_type_is_owned
	.p2align	2
_nvm_affine_type_is_owned:              ; @nvm_affine_type_is_owned
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	lsr	x19, x1, #32
	and	w11, w1, #0xff
	cbz	x0, LBB42_9
; %bb.1:
	cmp	w11, #7
	b.ne	LBB42_9
; %bb.2:
	mov	x21, x0
	ldr	x0, [x0]
	mov	x20, x1
	and	x1, x1, #0xffffffff000000ff
	bl	_supported
	cbz	w0, LBB42_27
; %bb.3:
	ldr	x8, [x21]
	and	w13, w20, #0xff
	cmp	w13, #7
	b.ne	LBB42_22
; %bb.4:
	ldr	x11, [x8, #48]
	cbz	x11, LBB42_26
; %bb.5:
	ldr	w9, [x11]
	cmp	w9, w19
	b.ls	LBB42_26
; %bb.6:
	add	x10, x11, #4
	add	x11, x11, #8
	mov	w12, #255                       ; =0xff
LBB42_7:                                ; =>This Inner Loop Header: Depth=1
	lsl	x14, x19, #3
	ldrb	w13, [x10, x14]
	ldr	w19, [x11, x14]
	cmp	w13, #7
	b.ne	LBB42_22
; %bb.8:                                ;   in Loop: Header=BB42_7 Depth=1
	mov	w0, #0                          ; =0x0
	cmp	w19, w9
	ccmp	w12, #0, #4, lo
	sub	w12, w12, #1
	b.ne	LBB42_7
	b	LBB42_27
LBB42_9:
	cbz	x0, LBB42_27
; %bb.10:
	ldr	x10, [x0]
	ldr	w9, [x10, #16]
	cmp	w9, w19
	b.ls	LBB42_26
; %bb.11:
	ldr	x8, [x10, #24]
	ldrb	w12, [x8, x19]
	tbz	w12, #0, LBB42_26
; %bb.12:
	ldr	x12, [x10, #8]
	lsl	x13, x19, #4
	ldrb	w12, [x12, x13]
	cmp	w11, #8
	b.ne	LBB42_14
; %bb.13:
	cbz	w12, LBB42_16
LBB42_14:
	mov	w0, #0                          ; =0x0
	cmp	w11, #10
	b.ne	LBB42_27
; %bb.15:
	cmp	w12, #2
	b.ne	LBB42_27
LBB42_16:
	and	w14, w1, #0xff
	cmp	w14, #7
	b.ne	LBB42_25
; %bb.17:
	ldr	x12, [x10, #48]
	cbz	x12, LBB42_26
; %bb.18:
	ldr	w10, [x12]
	cmp	w10, w19
	b.ls	LBB42_26
; %bb.19:
	add	x11, x12, #4
	add	x12, x12, #8
	mov	w13, #255                       ; =0xff
LBB42_20:                               ; =>This Inner Loop Header: Depth=1
	lsl	x15, x19, #3
	ldrb	w14, [x11, x15]
	ldr	w19, [x12, x15]
	cmp	w14, #7
	b.ne	LBB42_25
; %bb.21:                               ;   in Loop: Header=BB42_20 Depth=1
	mov	w0, #0                          ; =0x0
	cmp	w19, w10
	ccmp	w13, #0, #4, lo
	sub	w13, w13, #1
	b.ne	LBB42_20
	b	LBB42_27
LBB42_22:
	and	w9, w13, #0xfffffffd
	cmp	w9, #8
	b.ne	LBB42_26
; %bb.23:
	ldr	w9, [x8, #16]
	cmp	w19, w9
	b.hs	LBB42_26
; %bb.24:
	ldr	x8, [x8, #24]
	b	LBB42_28
LBB42_25:
	and	w10, w14, #0xfffffffd
	cmp	w10, #8
	ccmp	w19, w9, #2, eq
	b.lo	LBB42_28
LBB42_26:
	mov	w0, #0                          ; =0x0
LBB42_27:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB42_28:
	ldrb	w8, [x8, w19, uxtw]
	ubfx	w0, w8, #1, #1
	b	LBB42_27
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_has_array_types ; -- Begin function nvm_affine_has_array_types
	.globl	_nvm_affine_has_array_types
	.p2align	2
_nvm_affine_has_array_types:            ; @nvm_affine_has_array_types
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB43_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x8, [x8, #48]
	cmp	x8, #0
	cset	w0, ne
LBB43_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_types_equal ; -- Begin function nvm_affine_types_equal
	.globl	_nvm_affine_types_equal
	.p2align	2
_nvm_affine_types_equal:                ; @nvm_affine_types_equal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB44_8
; %bb.1:
	and	w12, w2, #0xff
	cmp	w12, w1, uxtb
	b.ne	LBB44_9
; %bb.2:
	mov	w8, #0                          ; =0x0
	ldr	x9, [x0]
	lsr	x10, x1, #32
	lsr	x11, x2, #32
LBB44_3:                                ; =>This Inner Loop Header: Depth=1
	cmp	w12, #7
	b.ne	LBB44_10
; %bb.4:                                ;   in Loop: Header=BB44_3 Depth=1
	ldr	x12, [x9, #48]
	cbz	x12, LBB44_9
; %bb.5:                                ;   in Loop: Header=BB44_3 Depth=1
	ldr	w13, [x12]
	cmp	x10, x13
	mov	w0, #0                          ; =0x0
	ccmp	x11, x13, #2, lo
	b.hs	LBB44_8
; %bb.6:                                ;   in Loop: Header=BB44_3 Depth=1
	cmp	w8, #255
	b.hi	LBB44_8
; %bb.7:                                ;   in Loop: Header=BB44_3 Depth=1
	add	x13, x12, #4
	add	x10, x13, x10, lsl #3
	ldrb	w12, [x10]
	ldr	w10, [x10, #4]
	add	x11, x13, x11, lsl #3
	ldrb	w13, [x11]
	ldr	w11, [x11, #4]
	add	w8, w8, #1
	cmp	w12, w13
	b.eq	LBB44_3
LBB44_8:
	ret
LBB44_9:
	mov	w0, #0                          ; =0x0
	ret
LBB44_10:
	cmp	x10, x11
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_array_define ; -- Begin function nvm_affine_array_define
	.globl	_nvm_affine_array_define
	.p2align	2
_nvm_affine_array_define:               ; @nvm_affine_array_define
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB45_22
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	w21, w2
	ldr	x0, [x0]
	mov	w8, #7                          ; =0x7
	orr	x1, x8, x21, lsl #32
	bl	_supported
	cbz	w0, LBB45_21
; %bb.2:
	ldr	x8, [x20]
	ldr	x10, [x8, #48]
	cbz	x10, LBB45_10
; %bb.3:
	ldr	w9, [x10]
	cmp	x9, x21
	b.ls	LBB45_10
; %bb.4:
	add	x11, x10, #4
	add	x12, x10, #8
	mov	w13, #255                       ; =0xff
	mov	x10, x21
LBB45_5:                                ; =>This Inner Loop Header: Depth=1
	lsl	x10, x10, #3
	ldrb	w14, [x11, x10]
	ldr	w10, [x12, x10]
	cmp	w14, #7
	b.ne	LBB45_7
; %bb.6:                                ;   in Loop: Header=BB45_5 Depth=1
	cmp	x10, x9
	ccmp	w13, #0, #4, lo
	sub	w13, w13, #1
	b.ne	LBB45_5
	b	LBB45_10
LBB45_7:
	and	w9, w14, #0xfffffffd
	cmp	w9, #8
	b.ne	LBB45_10
; %bb.8:
	ldr	w9, [x8, #16]
	cmp	x10, x9
	b.hs	LBB45_10
; %bb.9:
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, x10]
	tbnz	w8, #1, LBB45_20
LBB45_10:
	mov	x0, x20
	mov	x1, x19
	bl	_destination
	cbz	w0, LBB45_21
; %bb.11:
	ldr	x10, [x20]
	ldr	x8, [x10, #40]
	ldr	x9, [x8, w19, uxtw #3]
	and	x8, x9, #0xffff
	cmp	x8, #7
	b.ne	LBB45_20
; %bb.12:
	mov	w8, #0                          ; =0x0
	lsr	x9, x9, #32
	ldr	x10, [x10, #48]
	add	x11, x10, #4
	mov	w12, #7                         ; =0x7
LBB45_13:                               ; =>This Inner Loop Header: Depth=1
	cmp	w12, #7
	b.ne	LBB45_18
; %bb.14:                               ;   in Loop: Header=BB45_13 Depth=1
	cbz	x10, LBB45_20
; %bb.15:                               ;   in Loop: Header=BB45_13 Depth=1
	ldr	w12, [x10]
	cmp	x9, x12
	mov	w0, #0                          ; =0x0
	ccmp	x21, x12, #2, lo
	b.hs	LBB45_21
; %bb.16:                               ;   in Loop: Header=BB45_13 Depth=1
	cmp	w8, #255
	b.hi	LBB45_21
; %bb.17:                               ;   in Loop: Header=BB45_13 Depth=1
	add	x9, x11, x9, lsl #3
	ldrb	w12, [x9]
	ldr	w9, [x9, #4]
	add	x13, x11, x21, lsl #3
	ldrb	w14, [x13]
	ldr	w21, [x13, #4]
	add	w8, w8, #1
	cmp	w12, w14
	b.eq	LBB45_13
	b	LBB45_21
LBB45_18:
	cmp	x9, x21
	b.ne	LBB45_20
; %bb.19:
	ldr	x8, [x20, #8]
	mov	w0, #1                          ; =0x1
	strb	w0, [x8, w19, uxtw]
	b	LBB45_21
LBB45_20:
	mov	w0, #0                          ; =0x0
LBB45_21:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB45_22:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_array_element ; -- Begin function nvm_affine_array_element
	.globl	_nvm_affine_array_element
	.p2align	2
_nvm_affine_array_element:              ; @nvm_affine_array_element
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB46_6
; %bb.1:
	cbz	x2, LBB46_6
; %bb.2:
	and	x9, x1, #0xff
	cmp	x9, #7
	b.ne	LBB46_6
; %bb.3:
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	cbz	x8, LBB46_7
; %bb.4:
	lsr	x9, x1, #32
	ldr	w10, [x8]
	cmp	w10, w9
	b.ls	LBB46_7
; %bb.5:
	add	x8, x8, x9, lsl #3
	ldrb	w9, [x8, #4]
	ldr	w8, [x8, #8]
	strb	w9, [x2]
	sturh	wzr, [x2, #1]
	strb	wzr, [x2, #3]
	str	w8, [x2, #4]
	mov	w0, #1                          ; =0x1
LBB46_6:
	ret
LBB46_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_array_type  ; -- Begin function nvm_affine_array_type
	.globl	_nvm_affine_array_type
	.p2align	2
_nvm_affine_array_type:                 ; @nvm_affine_array_type
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB47_15
; %bb.1:
	cbz	x2, LBB47_15
; %bb.2:
	ldr	x8, [x8]
	ldr	x13, [x8, #48]
	cbz	x13, LBB47_13
; %bb.3:
	ldr	w9, [x13]
	cbz	w9, LBB47_13
; %bb.4:
	mov	x8, #0                          ; =0x0
	add	x10, x13, #4
	and	w11, w1, #0xff
	lsr	x12, x1, #32
	add	x13, x13, #8
	b	LBB47_7
LBB47_5:                                ;   in Loop: Header=BB47_7 Depth=1
	cmp	x15, x16
	b.eq	LBB47_14
LBB47_6:                                ;   in Loop: Header=BB47_7 Depth=1
	add	x8, x8, #1
	cmp	x8, x9
	b.eq	LBB47_13
LBB47_7:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB47_9 Depth 2
	lsl	x14, x8, #3
	ldrb	w14, [x10, x14]
	cmp	w14, w11
	b.ne	LBB47_6
; %bb.8:                                ;   in Loop: Header=BB47_7 Depth=1
	mov	w14, #0                         ; =0x0
	mov	x15, x8
	mov	x17, x11
	mov	x16, x12
LBB47_9:                                ;   Parent Loop BB47_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x15, x15, #3
	ldr	w15, [x13, x15]
	cmp	w17, #7
	b.ne	LBB47_5
; %bb.10:                               ;   in Loop: Header=BB47_9 Depth=2
	cmp	x15, x9
	ccmp	x16, x9, #2, lo
	b.hs	LBB47_6
; %bb.11:                               ;   in Loop: Header=BB47_9 Depth=2
	cmp	w14, #255
	b.hi	LBB47_6
; %bb.12:                               ;   in Loop: Header=BB47_9 Depth=2
	lsl	x17, x15, #3
	ldrb	w17, [x10, x17]
	add	x16, x10, x16, lsl #3
	ldrb	w0, [x16]
	ldr	w16, [x16, #4]
	add	w14, w14, #1
	cmp	w17, w0
	b.eq	LBB47_9
	b	LBB47_6
LBB47_13:
	mov	w0, #0                          ; =0x0
	ret
LBB47_14:
	mov	w9, #7                          ; =0x7
	strb	w9, [x2]
	sturh	wzr, [x2, #1]
	strb	wzr, [x2, #3]
	str	w8, [x2, #4]
	mov	w0, #1                          ; =0x1
LBB47_15:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_array_tag_type ; -- Begin function nvm_affine_array_tag_type
	.globl	_nvm_affine_array_tag_type
	.p2align	2
_nvm_affine_array_tag_type:             ; @nvm_affine_array_tag_type
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB48_19
; %bb.1:
	cbz	x2, LBB48_19
; %bb.2:
	ldr	x8, [x8]
	ldr	x10, [x8, #48]
	cbz	x10, LBB48_17
; %bb.3:
	ldr	w8, [x10], #4
	cbz	w8, LBB48_17
; %bb.4:
	mov	x9, #0                          ; =0x0
	mov	w12, #-1                        ; =0xffffffff
	mov	w11, #-1                        ; =0xffffffff
	b	LBB48_7
LBB48_5:                                ;   in Loop: Header=BB48_7 Depth=1
	mov	x11, x9
LBB48_6:                                ;   in Loop: Header=BB48_7 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB48_16
LBB48_7:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB48_10 Depth 2
	lsl	x13, x9, #3
	ldrb	w13, [x10, x13]
	cmp	w13, w1
	b.ne	LBB48_6
; %bb.8:                                ;   in Loop: Header=BB48_7 Depth=1
	cmp	x11, x12
	b.eq	LBB48_5
; %bb.9:                                ;   in Loop: Header=BB48_7 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w15, #7                         ; =0x7
	mov	x14, x9
LBB48_10:                               ;   Parent Loop BB48_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w15, #7
	b.ne	LBB48_15
; %bb.11:                               ;   in Loop: Header=BB48_10 Depth=2
	mov	w0, #0                          ; =0x0
	cmp	x11, x8
	b.hs	LBB48_19
; %bb.12:                               ;   in Loop: Header=BB48_10 Depth=2
	cmp	x14, x8
	b.hs	LBB48_19
; %bb.13:                               ;   in Loop: Header=BB48_10 Depth=2
	mov	w0, #0                          ; =0x0
	cmp	w13, #255
	b.hi	LBB48_19
; %bb.14:                               ;   in Loop: Header=BB48_10 Depth=2
	add	x11, x10, x11, lsl #3
	ldrb	w15, [x11]
	ldr	w11, [x11, #4]
	add	x14, x10, x14, lsl #3
	ldrb	w16, [x14]
	ldr	w14, [x14, #4]
	add	w13, w13, #1
	cmp	w15, w16
	b.eq	LBB48_10
	b	LBB48_19
LBB48_15:                               ;   in Loop: Header=BB48_7 Depth=1
	cmp	x11, x14
	mov	x11, x9
	b.eq	LBB48_6
	b	LBB48_17
LBB48_16:
	mov	w8, #-1                         ; =0xffffffff
	cmp	x11, x8
	b.ne	LBB48_18
LBB48_17:
	mov	w0, #0                          ; =0x0
	ret
LBB48_18:
	mov	w8, #7                          ; =0x7
	strb	w8, [x2]
	sturh	wzr, [x2, #1]
	strb	wzr, [x2, #3]
	str	w11, [x2, #4]
	mov	w0, #1                          ; =0x1
LBB48_19:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_record_is_copyable ; -- Begin function nvm_affine_record_is_copyable
	.globl	_nvm_affine_record_is_copyable
	.p2align	2
_nvm_affine_record_is_copyable:         ; @nvm_affine_record_is_copyable
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w1 killed $w1 def $x1
	cbz	x0, LBB49_5
; %bb.1:
	ldr	x8, [x0]
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB49_3
; %bb.2:
	ldr	x9, [x8, #8]
	ubfiz	x10, x1, #4, #32
	ldrb	w9, [x9, x10]
	cbz	w9, LBB49_4
LBB49_3:
	mov	w0, #0                          ; =0x0
	ret
LBB49_4:
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, w1, uxtw]
	and	w8, w8, #0x3
	cmp	w8, #1
	cset	w0, eq
LBB49_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_record_define ; -- Begin function nvm_affine_record_define
	.globl	_nvm_affine_record_define
	.p2align	2
_nvm_affine_record_define:              ; @nvm_affine_record_define
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB50_10
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	ldr	x8, [x0]
	ldr	w9, [x8, #16]
	cmp	w2, w9
	b.hs	LBB50_8
; %bb.2:
	ldr	x9, [x8, #8]
	ubfiz	x10, x19, #4, #32
	ldrb	w9, [x9, x10]
	cbnz	w9, LBB50_8
; %bb.3:
	ldr	x8, [x8, #24]
	ldrb	w8, [x8, w19, uxtw]
	and	w8, w8, #0x3
	cmp	w8, #1
	b.ne	LBB50_8
; %bb.4:
	mov	x21, x0
	mov	x20, x1
	bl	_destination
	cbz	w0, LBB50_9
; %bb.5:
	ldr	x8, [x21]
	ldr	x10, [x8, #40]
	add	x10, x10, w20, uxtw #3
	ldrb	w11, [x10]
	cmp	w11, #8
	b.ne	LBB50_8
; %bb.6:
	ldr	w10, [x10, #4]
	cmp	w10, w19
	b.ne	LBB50_8
; %bb.7:
	ldr	x9, [x21, #8]
	mov	w0, #1                          ; =0x1
	strb	w0, [x9, w20, uxtw]
	b	LBB50_9
LBB50_8:
	mov	w0, #0                          ; =0x0
LBB50_9:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB50_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_owned_local_fields ; -- Begin function nvm_affine_owned_local_fields
	.globl	_nvm_affine_owned_local_fields
	.p2align	2
_nvm_affine_owned_local_fields:         ; @nvm_affine_owned_local_fields
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB51_5
; %bb.1:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB51_3
; %bb.2:
	ldr	x8, [x8, #40]
	add	x8, x8, w1, uxtw #3
	ldrb	w9, [x8, #1]
	cbz	w9, LBB51_6
LBB51_3:
	mov	w0, #0                          ; =0x0
LBB51_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
LBB51_5:
	ret
LBB51_6:
	mov	x24, x1
	mov	x21, x3
	mov	x22, x2
	mov	x20, x4
	ldr	w19, [x8, #4]
	ldrb	w25, [x8]
	orr	x1, x25, x19, lsl #32
	mov	x23, x0
	bl	_nvm_affine_type_is_owned
	cbz	w0, LBB51_4
; %bb.7:
	cmp	w25, #8
	b.eq	LBB51_11
; %bb.8:
	cmp	w25, #10
	b.ne	LBB51_3
; %bb.9:
	mov	x0, x23
	add	x2, sp, #14
	mov	x1, x24
	bl	_nvm_affine_union_variant
	cbz	w0, LBB51_4
; %bb.10:
	ldrh	w2, [sp, #14]
	mov	x0, x23
	mov	x1, x19
	mov	x3, x22
	mov	x4, x21
	mov	x5, x20
	bl	_nvm_affine_union_fields
	b	LBB51_4
LBB51_11:
	cbz	x20, LBB51_3
; %bb.12:
	ldr	x8, [x23]
	ldr	w9, [x8, #16]
	cmp	w19, w9
	b.hs	LBB51_3
; %bb.13:
	ldr	x9, [x8, #24]
	ldrb	w9, [x9, x19]
	tbz	w9, #0, LBB51_3
; %bb.14:
	ldr	x8, [x8, #8]
	add	x8, x8, x19, lsl #4
	ldrb	w9, [x8]
	cbnz	w9, LBB51_3
; %bb.15:
	ldrh	w9, [x8, #2]
	cmp	w9, w21
	b.hi	LBB51_3
; %bb.16:
	cbnz	x22, LBB51_18
; %bb.17:
	cbnz	w9, LBB51_3
LBB51_18:
	cbz	w9, LBB51_21
; %bb.19:
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB51_20:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8, #8]
	add	x11, x11, x9
	ldrb	w12, [x11]
	ldr	w11, [x11, #4]
	strb	w12, [x22]
	sturh	wzr, [x22, #1]
	strb	wzr, [x22, #3]
	str	w11, [x22, #4]
	add	x10, x10, #1
	ldrh	w11, [x8, #2]
	add	x9, x9, #12
	add	x22, x22, #8
	cmp	x10, x11
	b.lo	LBB51_20
	b	LBB51_22
LBB51_21:
	mov	w11, #0                         ; =0x0
LBB51_22:
	strh	w11, [x20]
	mov	w0, #1                          ; =0x1
	b	LBB51_4
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_union_fields ; -- Begin function nvm_affine_union_fields
	.globl	_nvm_affine_union_fields
	.p2align	2
_nvm_affine_union_fields:               ; @nvm_affine_union_fields
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB52_26
; %bb.1:
	cbz	x5, LBB52_26
; %bb.2:
	sub	sp, sp, #96
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x19, x1
	cbnz	x3, LBB52_4
; %bb.3:
	cbnz	w4, LBB52_24
LBB52_4:
	ldr	x8, [x0]
	cbz	x8, LBB52_25
; %bb.5:
	ldr	w9, [x8, #16]
	cmp	w19, w9
	b.hs	LBB52_24
; %bb.6:
	ldr	x9, [x8, #8]
	ubfiz	x10, x19, #4, #32
	ldrb	w10, [x9, x10]
	cmp	w10, #2
	b.ne	LBB52_24
; %bb.7:
	mov	w20, w19
	cbz	w19, LBB52_10
; %bb.8:
	cmp	w19, #8
	b.hs	LBB52_11
; %bb.9:
	mov	x24, x4
	mov	x22, x0
	mov	x23, x3
	mov	x21, x5
	mov	x10, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB52_20
LBB52_10:
	mov	x24, x4
	mov	x22, x0
	mov	x23, x3
	mov	x21, x5
	mov	w1, #0                          ; =0x0
	b	LBB52_22
LBB52_11:
	cmp	w19, #64
	b.hs	LBB52_13
; %bb.12:
	mov	x24, x4
	mov	x22, x0
	mov	x23, x3
	mov	x21, x5
	mov	x10, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB52_17
LBB52_13:
	movi.2d	v0, #0000000000000000
	and	x10, x20, #0xffffffc0
	movi.16b	v1, #2
	movi.4s	v2, #1
	mov	x11, x9
	mov	x12, x10
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB52_14:                               ; =>This Inner Loop Header: Depth=1
	add	x13, x11, #16
	ldr	b26, [x11]
	ld1.b	{ v26 }[1], [x13]
	add	x13, x11, #32
	ld1.b	{ v26 }[2], [x13]
	add	x13, x11, #48
	ld1.b	{ v26 }[3], [x13]
	add	x13, x11, #64
	ld1.b	{ v26 }[4], [x13]
	add	x13, x11, #80
	ld1.b	{ v26 }[5], [x13]
	add	x13, x11, #96
	ld1.b	{ v26 }[6], [x13]
	add	x13, x11, #112
	ld1.b	{ v26 }[7], [x13]
	add	x13, x11, #144
	ldur	b28, [x11, #128]
	ld1.b	{ v28 }[1], [x13]
	add	x13, x11, #160
	ld1.b	{ v28 }[2], [x13]
	add	x13, x11, #176
	ld1.b	{ v28 }[3], [x13]
	add	x13, x11, #192
	ld1.b	{ v28 }[4], [x13]
	add	x13, x11, #208
	ld1.b	{ v28 }[5], [x13]
	add	x13, x11, #224
	ld1.b	{ v28 }[6], [x13]
	add	x13, x11, #240
	ld1.b	{ v28 }[7], [x13]
	add	x13, x11, #272
	ldr	b27, [x11, #256]
	ld1.b	{ v27 }[1], [x13]
	add	x13, x11, #288
	ld1.b	{ v27 }[2], [x13]
	add	x13, x11, #304
	ld1.b	{ v27 }[3], [x13]
	add	x13, x11, #320
	ld1.b	{ v27 }[4], [x13]
	add	x13, x11, #336
	ld1.b	{ v27 }[5], [x13]
	add	x13, x11, #352
	ld1.b	{ v27 }[6], [x13]
	add	x13, x11, #368
	ld1.b	{ v27 }[7], [x13]
	add	x13, x11, #400
	ldr	b29, [x11, #384]
	ld1.b	{ v29 }[1], [x13]
	add	x13, x11, #416
	ld1.b	{ v29 }[2], [x13]
	add	x13, x11, #432
	ld1.b	{ v29 }[3], [x13]
	add	x13, x11, #448
	ld1.b	{ v29 }[4], [x13]
	add	x13, x11, #464
	ld1.b	{ v29 }[5], [x13]
	add	x13, x11, #480
	ld1.b	{ v29 }[6], [x13]
	add	x13, x11, #496
	ld1.b	{ v29 }[7], [x13]
	add	x13, x11, #528
	ldr	b30, [x11, #512]
	ld1.b	{ v30 }[1], [x13]
	add	x13, x11, #544
	ld1.b	{ v30 }[2], [x13]
	add	x13, x11, #560
	ld1.b	{ v30 }[3], [x13]
	add	x13, x11, #576
	ld1.b	{ v30 }[4], [x13]
	add	x13, x11, #592
	ld1.b	{ v30 }[5], [x13]
	add	x13, x11, #608
	ld1.b	{ v30 }[6], [x13]
	add	x13, x11, #624
	ld1.b	{ v30 }[7], [x13]
	add	x13, x11, #656
	ldr	b31, [x11, #640]
	ld1.b	{ v31 }[1], [x13]
	add	x13, x11, #672
	ld1.b	{ v31 }[2], [x13]
	add	x13, x11, #688
	ld1.b	{ v31 }[3], [x13]
	add	x13, x11, #704
	ld1.b	{ v31 }[4], [x13]
	add	x13, x11, #720
	ld1.b	{ v31 }[5], [x13]
	add	x13, x11, #736
	ld1.b	{ v31 }[6], [x13]
	add	x13, x11, #752
	ld1.b	{ v31 }[7], [x13]
	add	x13, x11, #784
	zip1.2d	v8, v26, v28
	ldr	b26, [x11, #768]
	ld1.b	{ v26 }[1], [x13]
	add	x13, x11, #800
	ld1.b	{ v26 }[2], [x13]
	add	x13, x11, #816
	ld1.b	{ v26 }[3], [x13]
	add	x13, x11, #832
	ld1.b	{ v26 }[4], [x13]
	add	x13, x11, #848
	ld1.b	{ v26 }[5], [x13]
	add	x13, x11, #864
	ld1.b	{ v26 }[6], [x13]
	add	x13, x11, #880
	ld1.b	{ v26 }[7], [x13]
	add	x13, x11, #912
	zip1.2d	v27, v27, v29
	ldr	b29, [x11, #896]
	ld1.b	{ v29 }[1], [x13]
	add	x13, x11, #928
	ld1.b	{ v29 }[2], [x13]
	add	x13, x11, #944
	ld1.b	{ v29 }[3], [x13]
	add	x13, x11, #960
	ld1.b	{ v29 }[4], [x13]
	add	x13, x11, #976
	ld1.b	{ v29 }[5], [x13]
	add	x13, x11, #992
	ld1.b	{ v29 }[6], [x13]
	add	x13, x11, #1008
	ld1.b	{ v29 }[7], [x13]
	zip1.2d	v28, v30, v31
	zip1.2d	v26, v26, v29
	cmeq.16b	v29, v8, v1
	ushll2.8h	v30, v29, #0
	ushll2.4s	v31, v30, #0
	and.16b	v31, v31, v2
	add.4s	v5, v5, v31
	ushll.8h	v29, v29, #0
	ushll.4s	v30, v30, #0
	and.16b	v30, v30, v2
	add.4s	v3, v3, v30
	ushll.4s	v30, v29, #0
	and.16b	v30, v30, v2
	ushll2.4s	v29, v29, #0
	and.16b	v29, v29, v2
	cmeq.16b	v27, v27, v1
	add.4s	v4, v4, v29
	ushll2.8h	v29, v27, #0
	add.4s	v0, v0, v30
	ushll2.4s	v30, v29, #0
	and.16b	v30, v30, v2
	add.4s	v23, v23, v30
	ushll.8h	v27, v27, #0
	ushll.4s	v29, v29, #0
	and.16b	v29, v29, v2
	add.4s	v17, v17, v29
	ushll.4s	v29, v27, #0
	and.16b	v29, v29, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v27
	add.4s	v6, v6, v29
	ushll2.8h	v27, v28, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v21, v21, v29
	ushll.8h	v28, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v24, v24, v27
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	ushll2.4s	v28, v28, #0
	cmeq.16b	v26, v26, v1
	and.16b	v28, v28, v2
	add.4s	v7, v7, v28
	ushll2.8h	v28, v26, #0
	add.4s	v18, v18, v27
	ushll2.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v25, v25, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v28, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x11, x11, #1024
	subs	x12, x12, #64
	b.ne	LBB52_14
; %bb.15:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	mov	x24, x4
	mov	x22, x0
	mov	x23, x3
	mov	x21, x5
	cmp	x10, x20
	b.eq	LBB52_22
; %bb.16:
	tst	x20, #0x38
	b.eq	LBB52_20
LBB52_17:
	mov	x12, x10
	and	x10, x20, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	movi.2d	v1, #0000000000000000
	sub	x11, x12, x10
	add	x12, x9, x12, lsl #4
	add	x12, x12, #64
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB52_18:                               ; =>This Inner Loop Header: Depth=1
	sub	x13, x12, #48
	sub	x14, x12, #32
	sub	x15, x12, #16
	add	x16, x12, #16
	add	x17, x12, #32
	add	x0, x12, #48
	ldur	b4, [x12, #-64]
	ld1.b	{ v4 }[1], [x13]
	ld1.b	{ v4 }[2], [x14]
	ld1.b	{ v4 }[3], [x15]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x16]
	ld1.b	{ v4 }[6], [x17]
	ld1.b	{ v4 }[7], [x0]
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v1, v1, v4
	add.4s	v0, v0, v5
	add	x12, x12, #128
	adds	x11, x11, #8
	b.ne	LBB52_18
; %bb.19:
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x10, x20
	b.eq	LBB52_22
LBB52_20:
	sub	x11, x20, x10
	add	x9, x9, x10, lsl #4
LBB52_21:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #16
	cmp	w10, #2
	cinc	w1, w1, eq
	subs	x11, x11, #1
	b.ne	LBB52_21
LBB52_22:
	ldr	x0, [x8, #64]
	add	x3, sp, #4
	bl	_nvm_ownership_union_variant
	ldr	w8, [sp, #4]
	cmp	w0, #0
	ccmp	w8, w19, #0, eq
	b.ne	LBB52_24
; %bb.23:
	ldrh	w8, [sp, #14]
	cmp	w8, w24
	b.ls	LBB52_27
LBB52_24:
	mov	w8, #0                          ; =0x0
LBB52_25:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #96
LBB52_26:
	mov	x0, x8
	ret
LBB52_27:
	cbz	w8, LBB52_30
; %bb.28:
	ldr	x9, [x22]
	ldr	x9, [x9, #8]
	add	x9, x9, x20, lsl #4
	ldrh	w10, [sp, #12]
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #2
	mov	x11, x8
LBB52_29:                               ; =>This Inner Loop Header: Depth=1
	ldur	x12, [x9, #8]
	add	x12, x12, x10
	ldrb	w13, [x12]
	ldr	w12, [x12, #4]
	strb	w13, [x23]
	sturh	wzr, [x23, #1]
	strb	wzr, [x23, #3]
	str	w12, [x23, #4]
	add	x10, x10, #12
	add	x23, x23, #8
	subs	x11, x11, #1
	b.ne	LBB52_29
LBB52_30:
	strh	w8, [x21]
	mov	w8, #1                          ; =0x1
	b	LBB52_25
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_record_fields ; -- Begin function nvm_affine_record_fields
	.globl	_nvm_affine_record_fields
	.p2align	2
_nvm_affine_record_fields:              ; @nvm_affine_record_fields
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB53_14
; %bb.1:
	cbz	x4, LBB53_14
; %bb.2:
	ldr	x8, [x8]
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB53_8
; %bb.3:
	ldr	x10, [x8, #24]
	mov	w9, w1
	ldrb	w10, [x10, x9]
	tbz	w10, #0, LBB53_8
; %bb.4:
	ldr	x8, [x8, #8]
	add	x8, x8, x9, lsl #4
	ldrb	w9, [x8]
	cbnz	w9, LBB53_8
; %bb.5:
	ldrh	w9, [x8, #2]
	cmp	w9, w3
	b.hi	LBB53_8
; %bb.6:
	cbnz	x2, LBB53_9
; %bb.7:
	cbz	w9, LBB53_9
LBB53_8:
	mov	w0, #0                          ; =0x0
	ret
LBB53_9:
	cbz	w9, LBB53_12
; %bb.10:
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB53_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8, #8]
	add	x11, x11, x9
	ldrb	w12, [x11]
	ldr	w11, [x11, #4]
	strb	w12, [x2]
	sturh	wzr, [x2, #1]
	strb	wzr, [x2, #3]
	str	w11, [x2, #4]
	add	x10, x10, #1
	ldrh	w11, [x8, #2]
	add	x2, x2, #8
	add	x9, x9, #12
	cmp	x10, x11
	b.lo	LBB53_11
	b	LBB53_13
LBB53_12:
	mov	w11, #0                         ; =0x0
LBB53_13:
	strh	w11, [x4]
	mov	w0, #1                          ; =0x1
LBB53_14:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_take_local  ; -- Begin function nvm_affine_take_local
	.globl	_nvm_affine_take_local
	.p2align	2
_nvm_affine_take_local:                 ; @nvm_affine_take_local
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB54_9
; %bb.1:
	cbz	x2, LBB54_9
; %bb.2:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB54_7
; %bb.3:
	ldr	x8, [x8, #40]
	add	x8, x8, w1, uxtw #3
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB54_7
; %bb.4:
	mov	x19, x1
	mov	x22, x2
	ldr	w23, [x8, #4]
	ldrb	w8, [x8]
	orr	x20, x8, x23, lsl #32
	mov	x21, x0
	mov	x1, x20
	bl	_nvm_affine_type_is_owned
	cmp	w0, #0
	ccmn	w23, #1, #4, ne
	b.eq	LBB54_7
; %bb.5:
	mov	x0, x21
	mov	x1, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #1                          ; =0x1
	bl	_nvm_affine_owner_access
	cbz	w0, LBB54_7
; %bb.6:
	ldp	x8, x9, [x21, #8]
	strb	wzr, [x8, w19, uxtw]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, w19, uxtw #1]
	str	x20, [x22]
	mov	w8, #1                          ; =0x1
	b	LBB54_8
LBB54_7:
	mov	w8, #0                          ; =0x0
LBB54_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB54_9:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_put_local   ; -- Begin function nvm_affine_put_local
	.globl	_nvm_affine_put_local
	.p2align	2
_nvm_affine_put_local:                  ; @nvm_affine_put_local
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB55_5
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x8, [x0]
	ldrh	w9, [x8, #56]
	cmp	w1, w9
	b.hs	LBB55_3
; %bb.2:
	ldr	x8, [x8, #40]
	add	x8, x8, w1, uxtw #3
	ldrb	w9, [x8, #1]
	cbz	w9, LBB55_6
LBB55_3:
	mov	w0, #0                          ; =0x0
LBB55_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB55_5:
	ret
LBB55_6:
	mov	x19, x1
	ldr	w21, [x8, #4]
	ldrb	w22, [x8]
	mov	x20, x0
	mov	x23, x2
	mov	x1, x2
	bl	_nvm_affine_type_is_owned
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB55_4
; %bb.7:
	mov	x8, #-4294967297                ; =0xfffffffeffffffff
	cmp	x23, x8
	b.hi	LBB55_4
; %bb.8:
	mov	x11, x23
	and	w8, w11, #0xff
	cmp	w22, w8
	b.ne	LBB55_4
; %bb.9:
	mov	x1, x19
	mov	x8, x20
	mov	w9, #0                          ; =0x0
	ldr	x10, [x20]
	lsr	x11, x11, #32
LBB55_10:                               ; =>This Inner Loop Header: Depth=1
	cmp	w22, #7
	b.ne	LBB55_15
; %bb.11:                               ;   in Loop: Header=BB55_10 Depth=1
	ldr	x12, [x10, #48]
	cbz	x12, LBB55_3
; %bb.12:                               ;   in Loop: Header=BB55_10 Depth=1
	ldr	w13, [x12], #4
	cmp	x21, x13
	mov	w0, #0                          ; =0x0
	ccmp	x11, x13, #2, lo
	b.hs	LBB55_4
; %bb.13:                               ;   in Loop: Header=BB55_10 Depth=1
	cmp	w9, #255
	b.hi	LBB55_4
; %bb.14:                               ;   in Loop: Header=BB55_10 Depth=1
	add	x13, x12, x21, lsl #3
	ldrb	w22, [x13]
	ldr	w21, [x13, #4]
	add	x11, x12, x11, lsl #3
	ldrb	w12, [x11]
	ldr	w11, [x11, #4]
	add	w9, w9, #1
	cmp	w22, w12
	b.eq	LBB55_10
	b	LBB55_4
LBB55_15:
	cmp	x21, x11
	b.ne	LBB55_3
; %bb.16:
	mov	x0, x8
	bl	_destination
	cbz	w0, LBB55_4
; %bb.17:
	mov	w0, #1                          ; =0x1
	ldp	x8, x9, [x20, #8]
	strb	w0, [x8, w19, uxtw]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, w19, uxtw #1]
	b	LBB55_4
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_can_exit_type ; -- Begin function nvm_affine_can_exit_type
	.globl	_nvm_affine_can_exit_type
	.p2align	2
_nvm_affine_can_exit_type:              ; @nvm_affine_can_exit_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB56_26
; %bb.1:
	ldr	w8, [x0, #36]
	cbnz	w8, LBB56_26
; %bb.2:
	ldr	x9, [x0]
	ldr	x8, [x9, #32]
	tst	x8, #0xff00
	b.ne	LBB56_26
; %bb.3:
	and	w13, w1, #0xff
	cmp	w13, w8, uxtb
	b.ne	LBB56_26
; %bb.4:
	mov	w10, #0                         ; =0x0
	lsr	x11, x8, #32
	lsr	x12, x1, #32
LBB56_5:                                ; =>This Inner Loop Header: Depth=1
	cmp	w13, #7
	b.ne	LBB56_10
; %bb.6:                                ;   in Loop: Header=BB56_5 Depth=1
	ldr	x13, [x9, #48]
	cbz	x13, LBB56_26
; %bb.7:                                ;   in Loop: Header=BB56_5 Depth=1
	ldr	w8, [x13]
	cmp	x11, x8
	ccmp	x12, x8, #2, lo
	b.hs	LBB56_26
; %bb.8:                                ;   in Loop: Header=BB56_5 Depth=1
	mov	w8, #0                          ; =0x0
	cmp	w10, #255
	b.hi	LBB56_27
; %bb.9:                                ;   in Loop: Header=BB56_5 Depth=1
	add	x14, x13, #4
	add	x11, x14, x11, lsl #3
	ldrb	w13, [x11]
	ldr	w11, [x11, #4]
	add	x12, x14, x12, lsl #3
	ldrb	w14, [x12]
	ldr	w12, [x12, #4]
	add	w10, w10, #1
	cmp	w13, w14
	b.eq	LBB56_5
	b	LBB56_27
LBB56_10:
	cmp	x11, x12
	b.ne	LBB56_26
; %bb.11:
	ldrh	w10, [x9, #56]
	cbz	x10, LBB56_28
; %bb.12:
	mov	x11, #0                         ; =0x0
	ldr	x12, [x0, #8]
	b	LBB56_15
LBB56_13:                               ;   in Loop: Header=BB56_15 Depth=1
	tst	x13, #0xff00
	b.eq	LBB56_21
LBB56_14:                               ;   in Loop: Header=BB56_15 Depth=1
	add	x11, x11, #1
	mov	w8, #1                          ; =0x1
	cmp	x11, x10
	b.eq	LBB56_27
LBB56_15:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB56_24 Depth 2
	ldrb	w8, [x12, x11]
	cmp	w8, #1
	b.ne	LBB56_14
; %bb.16:                               ;   in Loop: Header=BB56_15 Depth=1
	ldr	x8, [x9, #40]
	add	x8, x8, x11, lsl #3
	ldrb	w13, [x8, #1]
	cbnz	w13, LBB56_14
; %bb.17:                               ;   in Loop: Header=BB56_15 Depth=1
	ldr	x13, [x8]
	and	w17, w13, #0xff
	lsr	x8, x13, #32
	cmp	w17, #7
	b.eq	LBB56_13
LBB56_18:                               ;   in Loop: Header=BB56_15 Depth=1
	and	w13, w17, #0xfffffffd
	cmp	w13, #8
	b.ne	LBB56_14
; %bb.19:                               ;   in Loop: Header=BB56_15 Depth=1
	ldr	w13, [x9, #16]
	cmp	x8, x13
	b.hs	LBB56_14
; %bb.20:                               ;   in Loop: Header=BB56_15 Depth=1
	ldr	x13, [x9, #24]
	ldrb	w8, [x13, x8]
	tbz	w8, #1, LBB56_14
	b	LBB56_26
LBB56_21:                               ;   in Loop: Header=BB56_15 Depth=1
	ldr	x15, [x9, #48]
	cbz	x15, LBB56_14
; %bb.22:                               ;   in Loop: Header=BB56_15 Depth=1
	ldr	w13, [x15]
	cmp	x13, x8
	b.ls	LBB56_14
; %bb.23:                               ;   in Loop: Header=BB56_15 Depth=1
	add	x14, x15, #4
	add	x15, x15, #8
	mov	w16, #255                       ; =0xff
LBB56_24:                               ;   Parent Loop BB56_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x8, x8, #3
	ldrb	w17, [x14, x8]
	ldr	w8, [x15, x8]
	cmp	w17, #7
	b.ne	LBB56_18
; %bb.25:                               ;   in Loop: Header=BB56_24 Depth=2
	cmp	x8, x13
	ccmp	w16, #0, #4, lo
	sub	w16, w16, #1
	b.ne	LBB56_24
	b	LBB56_14
LBB56_26:
	mov	w8, #0                          ; =0x0
LBB56_27:
	mov	x0, x8
	ret
LBB56_28:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_bind_caller ; -- Begin function nvm_affine_bind_caller
	.globl	_nvm_affine_bind_caller
	.p2align	2
_nvm_affine_bind_caller:                ; @nvm_affine_bind_caller
	.cfi_startproc
; %bb.0:
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	sub	sp, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	w8, #0                          ; =0x0
Lloh2:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x9, [x9]
	stur	x9, [x29, #-112]
	cbz	x0, LBB57_11
; %bb.1:
	cbz	x1, LBB57_11
; %bb.2:
	ldrb	w8, [x0, #40]
	tbnz	w8, #0, LBB57_10
; %bb.3:
	ldrb	w8, [x1, #40]
	tbnz	w8, #0, LBB57_10
; %bb.4:
	ldr	x9, [x0]
	ldr	x10, [x9, #64]
	ldr	x8, [x1]
	ldr	x11, [x8, #64]
	cmp	x10, x11
	b.ne	LBB57_10
; %bb.5:
	ldr	w8, [x8, #72]
	cbnz	w8, LBB57_10
; %bb.6:
	ldr	w8, [x9, #72]
	cmp	w8, #1
	b.ne	LBB57_10
; %bb.7:
	ldr	w8, [x0, #36]
	cbnz	w8, LBB57_10
; %bb.8:
	ldrh	w20, [x9, #58]
	sub	w8, w20, #9
	mov	w10, #65528                     ; =0xfff8
	cmp	w10, w8, uxth
	b.hi	LBB57_10
; %bb.9:
	ldr	w10, [x0, #32]
	cmp	w10, w20
	b.hs	LBB57_13
LBB57_10:
	mov	w8, #0                          ; =0x0
LBB57_11:
	ldur	x9, [x29, #-112]
Lloh5:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB57_67
; %bb.12:
	mov	x0, x8
	add	sp, sp, #448
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	ret
LBB57_13:
	mov	w8, #0                          ; =0x0
	ldr	w11, [x1, #32]
	subs	w11, w11, w2
	b.lo	LBB57_11
; %bb.14:
	cmp	w11, w20
	b.lo	LBB57_11
; %bb.15:
	cmp	w10, w20
	b.ls	LBB57_19
; %bb.16:
	ldr	x8, [x0, #24]
	mov	w11, #56                        ; =0x38
	umaddl	x8, w20, w11, x8
	sub	x10, x10, x20
LBB57_17:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x8], #56
	tbnz	w11, #0, LBB57_10
; %bb.18:                               ;   in Loop: Header=BB57_17 Depth=1
	subs	x10, x10, #1
	b.ne	LBB57_17
LBB57_19:
	ldrh	w8, [x9, #56]
	subs	w10, w8, w20
	b.ls	LBB57_26
; %bb.20:
	ldr	x9, [x0, #8]
	ands	w12, w10, #0x3
	b.eq	LBB57_24
; %bb.21:
	mov	w13, #0                         ; =0x0
	mov	x11, x20
LBB57_22:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w14, [x9, x11]
	tbnz	w14, #0, LBB57_10
; %bb.23:                               ;   in Loop: Header=BB57_22 Depth=1
	add	x11, x11, #1
	add	w13, w13, #1
	cmp	w12, w13, uxth
	b.ne	LBB57_22
	b	LBB57_25
LBB57_24:
	mov	x11, x20
LBB57_25:
	sub	w10, w10, #1
	and	w10, w10, #0xffff
	cmp	w10, #3
	b.hs	LBB57_51
LBB57_26:
	cbz	w20, LBB57_66
; %bb.27:
	mov	x23, #0                         ; =0x0
	mov	w24, #56                        ; =0x38
	mov	w27, #-1                        ; =0xffffffff
	mov	x21, x1
LBB57_28:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB57_35 Depth 2
                                        ;       Child Loop BB57_39 Depth 3
                                        ;     Child Loop BB57_47 Depth 2
	add	w19, w2, w23, uxth
	ldr	x9, [x1, #24]
	umull	x8, w19, w24
	ldrb	w8, [x9, x8]
	cmp	w8, #1
	b.ne	LBB57_10
; %bb.29:                               ;   in Loop: Header=BB57_28 Depth=1
	ldr	x8, [x0]
	ldr	x8, [x8, #40]
	add	x10, x8, w23, uxth #3
	ldrb	w8, [x10, #1]
	ldr	w11, [x10, #4]
	ldrb	w10, [x10]
	umaddl	x9, w19, w24, x9
	ldr	x12, [x9, #48]
	ldp	q0, q1, [x9, #16]
	str	x12, [sp, #80]
	stp	q0, q1, [sp, #48]
	ldr	w9, [sp, #76]
	cmp	w10, #8
	ccmp	w8, #0, #4, eq
	ccmp	w11, w9, #0, ne
	b.ne	LBB57_10
; %bb.30:                               ;   in Loop: Header=BB57_28 Depth=1
	ldr	w9, [sp, #80]
	cmp	w8, #2
	ccmp	w9, #2, #4, eq
	b.ne	LBB57_10
; %bb.31:                               ;   in Loop: Header=BB57_28 Depth=1
	mov	x28, x2
	mov	x22, x0
	str	w8, [sp, #80]
	ldr	w8, [x1, #32]
	cbz	w8, LBB57_42
; %bb.32:                               ;   in Loop: Header=BB57_28 Depth=1
	mov	x25, #0                         ; =0x0
	cmn	w19, #1
	cset	w26, ne
	b	LBB57_35
LBB57_33:                               ;   in Loop: Header=BB57_35 Depth=2
	mov	x1, x21
	ldr	w8, [x21, #32]
LBB57_34:                               ;   in Loop: Header=BB57_35 Depth=2
	add	x25, x25, #1
	cmp	x25, w8, uxtw
	b.hs	LBB57_42
LBB57_35:                               ;   Parent Loop BB57_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB57_39 Depth 3
	ldr	x9, [x1, #24]
	mul	x10, x25, x24
	ldrb	w10, [x9, x10]
	cmp	w10, #1
	b.ne	LBB57_34
; %bb.36:                               ;   in Loop: Header=BB57_35 Depth=2
	mov	x11, x26
	cmn	w19, #1
	b.eq	LBB57_40
; %bb.37:                               ;   in Loop: Header=BB57_35 Depth=2
	mov	x11, x26
	cmp	x25, x19
	b.eq	LBB57_40
; %bb.38:                               ;   in Loop: Header=BB57_35 Depth=2
	mov	w10, #1                         ; =0x1
	mov	x12, x19
LBB57_39:                               ;   Parent Loop BB57_28 Depth=1
                                        ;     Parent Loop BB57_35 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umaddl	x11, w12, w24, x9
	ldr	w12, [x11, #8]
	cmp	w10, w8
	ccmp	x12, x27, #4, lo
	cset	w11, ne
	add	w10, w10, #1
	cmp	w11, #1
	ccmp	x25, x12, #4, eq
	b.ne	LBB57_39
LBB57_40:                               ;   in Loop: Header=BB57_35 Depth=2
	tbnz	w11, #0, LBB57_34
; %bb.41:                               ;   in Loop: Header=BB57_35 Depth=2
	madd	x8, x25, x24, x9
	add	x0, x8, #16
	add	x1, sp, #48
	bl	_nvm_reference_holds_conflict
	tbz	w0, #0, LBB57_33
	b	LBB57_10
LBB57_42:                               ;   in Loop: Header=BB57_28 Depth=1
	ldr	x8, [sp, #48]
	ldr	x9, [x1, #56]
	cmp	x8, x9
	b.ne	LBB57_10
; %bb.43:                               ;   in Loop: Header=BB57_28 Depth=1
	ldrh	w9, [sp, #56]
	ldr	x8, [x1]
	ldrh	w10, [x8, #56]
	cmp	w9, w10
	b.hs	LBB57_10
; %bb.44:                               ;   in Loop: Header=BB57_28 Depth=1
	ldr	x10, [x8, #40]
	add	x9, x10, x9, lsl #3
	ldr	w1, [x9, #4]
	add	x0, x8, #8
	add	x2, sp, #48
	bl	_nvm_reference_place_valid
	cbz	w0, LBB57_10
; %bb.45:                               ;   in Loop: Header=BB57_28 Depth=1
	mov	x1, x21
	and	x25, x23, #0xffff
	cbz	w25, LBB57_49
; %bb.46:                               ;   in Loop: Header=BB57_28 Depth=1
	add	x19, sp, #112
	mov	x26, x23
LBB57_47:                               ;   Parent Loop BB57_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x1, sp, #48
	mov	x0, x19
	bl	_nvm_reference_holds_conflict
	tbnz	w0, #0, LBB57_10
; %bb.48:                               ;   in Loop: Header=BB57_47 Depth=2
	mov	x1, x21
	add	x19, x19, #40
	subs	x26, x26, #1
	b.ne	LBB57_47
LBB57_49:                               ;   in Loop: Header=BB57_28 Depth=1
	mov	w8, #40                         ; =0x28
	add	x9, sp, #112
	umaddl	x8, w25, w8, x9
	ldp	q0, q1, [sp, #48]
	stp	q0, q1, [x8]
	ldr	x9, [sp, #80]
	str	x9, [x8, #32]
	add	x23, x23, #1
	cmp	w20, w23, uxth
	mov	x0, x22
	mov	x2, x28
	b.hi	LBB57_28
; %bb.50:
	mov	x23, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	add	x8, sp, #112
	add	x24, x8, #24
	add	x25, sp, #48
	b	LBB57_59
LBB57_51:
	add	x10, x11, #2
	add	x9, x11, x9
	add	x9, x9, #1
LBB57_52:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w11, [x9, #-1]
	tbnz	w11, #0, LBB57_10
; %bb.53:                               ;   in Loop: Header=BB57_52 Depth=1
	ldrb	w11, [x9]
	tbnz	w11, #0, LBB57_10
; %bb.54:                               ;   in Loop: Header=BB57_52 Depth=1
	ldrb	w11, [x9, #1]
	tbnz	w11, #0, LBB57_10
; %bb.55:                               ;   in Loop: Header=BB57_52 Depth=1
	ldrb	w11, [x9, #2]
	tbnz	w11, #0, LBB57_10
; %bb.56:                               ;   in Loop: Header=BB57_52 Depth=1
	add	w11, w10, #2
	add	x10, x10, #4
	add	x9, x9, #4
	cmp	w8, w11, uxth
	b.ne	LBB57_52
	b	LBB57_26
LBB57_57:                               ;   in Loop: Header=BB57_59 Depth=1
	ldur	x1, [x24, #-8]
	mov	x2, x19
	bl	_memcpy
LBB57_58:                               ;   in Loop: Header=BB57_59 Depth=1
	add	x23, x23, #1
	add	x24, x24, #40
	cmp	x20, x23
	b.eq	LBB57_64
LBB57_59:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [x24]
	cbz	x8, LBB57_58
; %bb.60:                               ;   in Loop: Header=BB57_59 Depth=1
	lsl	x19, x8, #1
	mov	x0, x19
	bl	_malloc
	str	x0, [x25, x23, lsl #3]
	cbnz	x0, LBB57_57
; %bb.61:
	cbz	x23, LBB57_10
; %bb.62:
	mov	x19, #0                         ; =0x0
	add	x20, sp, #48
LBB57_63:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19, lsl #3]
	bl	_free
	mov	w8, #0                          ; =0x0
	add	x19, x19, #1
	cmp	x23, x19
	b.ne	LBB57_63
	b	LBB57_11
LBB57_64:
	mov	x19, #0                         ; =0x0
	mov	x0, x22
	add	x23, x22, #84
	lsl	x8, x20, #6
	sub	x24, x8, x20, lsl #3
	add	x25, sp, #48
	add	x26, sp, #112
	mov	w27, #1                         ; =0x1
	movi	d8, #0x000000ffffffff
LBB57_65:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #24]
	add	x8, x8, x19
	ldr	x0, [x8, #32]
	bl	_free
	mov	x0, x22
	ldr	x8, [x25], #8
	str	x8, [x26, #16]
	ldr	x8, [x22, #24]
	add	x8, x8, x19
	ldr	x9, [x26, #32]
	str	x9, [sp, #32]
	ldp	q0, q1, [x26]
	stp	q0, q1, [sp]
	strb	w27, [x8]
	str	wzr, [x8, #4]
	stur	wzr, [x8, #1]
	str	d8, [x8, #8]
	str	x9, [x8, #48]
	stp	q0, q1, [x8, #16]
	ldr	x8, [x26]
	ldrh	w9, [x26, #8]
	ldr	x10, [x21]
	ldr	x10, [x10, #40]
	add	x10, x10, x9, lsl #3
	ldr	w10, [x10, #4]
	stur	x8, [x23, #-12]
	sturh	w9, [x23, #-4]
	sturh	wzr, [x23, #-2]
	str	w10, [x23], #16
	add	x26, x26, #40
	add	x19, x19, #56
	cmp	x24, x19
	b.ne	LBB57_65
LBB57_66:
	strh	w20, [x0, #64]
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #40]
	mov	w9, #2                          ; =0x2
	str	x9, [x0, #56]
	b	LBB57_11
LBB57_67:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_parameter_at ; -- Begin function nvm_affine_parameter_at
	.globl	_nvm_affine_parameter_at
	.p2align	2
_nvm_affine_parameter_at:               ; @nvm_affine_parameter_at
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB58_12
; %bb.1:
	cbz	x2, LBB58_12
; %bb.2:
	cbz	x3, LBB58_12
; %bb.3:
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x9, [x8]
	ldrh	w10, [x9, #58]
	sub	w11, w10, #1
	cmp	w1, w10
	ccmp	w11, #7, #2, lo
	b.hi	LBB58_10
; %bb.4:
	ldr	w10, [x8, #32]
	cmp	w10, w1
	b.ls	LBB58_10
; %bb.5:
	ldr	x8, [x8, #24]
	mov	w10, #56                        ; =0x38
	umull	x10, w1, w10
	ldrb	w8, [x8, x10]
	cmp	w8, #1
	b.ne	LBB58_10
; %bb.6:
	mov	w8, w1
	ldr	x10, [x9, #40]
	add	x8, x10, x8, lsl #3
	ldrb	w20, [x8, #1]
	cbz	w20, LBB58_10
; %bb.7:
	ldrb	w21, [x8]
	ldr	w19, [x8, #4]
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #8]
	strh	w1, [sp, #16]
	strh	wzr, [sp, #18]
	str	w19, [sp, #20]
	str	xzr, [sp, #24]
	stp	wzr, w19, [sp, #32]
	stp	w20, wzr, [sp, #40]
	and	w8, w21, #0xfffffffd
	cmp	w8, #8
	b.ne	LBB58_10
; %bb.8:
	ldr	w8, [x9, #16]
	cmp	w19, w8
	b.hs	LBB58_10
; %bb.9:
	ldr	x8, [x9, #24]
	ldrb	w8, [x8, w19, uxtw]
	tbnz	w8, #1, LBB58_13
LBB58_10:
	mov	w0, #0                          ; =0x0
LBB58_11:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB58_12:
	ret
LBB58_13:
	mov	x23, x2
	mov	x22, x3
	add	x0, x9, #8
	add	x2, sp, #8
	mov	x1, x19
	bl	_nvm_reference_place_valid
	cbz	w0, LBB58_11
; %bb.14:
	strb	w21, [x23]
	sturh	wzr, [x23, #1]
	strb	wzr, [x23, #3]
	str	w19, [x23, #4]
	mov	w0, #1                          ; =0x1
	str	w20, [x22]
	b	LBB58_11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_value_result ; -- Begin function nvm_affine_value_result
	.globl	_nvm_affine_value_result
	.p2align	2
_nvm_affine_value_result:               ; @nvm_affine_value_result
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB59_32
; %bb.1:
	cbz	x1, LBB59_32
; %bb.2:
	cbz	x2, LBB59_32
; %bb.3:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x0, [x0]
	ldrb	w8, [x0, #33]
	cbnz	w8, LBB59_30
; %bb.4:
	ldrb	w20, [x0, #32]
	ldr	x8, [x0, #64]
	ldr	x8, [x8, #256]
	ldr	w9, [x0, #72]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrb	w9, [x8, #20]
	cmp	w9, w20
	b.ne	LBB59_30
; %bb.5:
	ldrb	w8, [x8, #21]
	cmp	w20, #0
	cset	w9, ne
	cmp	w8, w9
	b.ne	LBB59_30
; %bb.6:
	ldrh	w8, [x0, #34]
	ldr	w19, [x0, #36]
	cmp	w20, #7
	mov	x21, x1
	b.eq	LBB59_15
; %bb.7:
	cmp	w20, #10
	b.eq	LBB59_14
; %bb.8:
	cmp	w20, #8
	b.ne	LBB59_17
; %bb.9:
	ldr	w8, [x0, #16]
	cmp	w19, w8
	b.hs	LBB59_30
; %bb.10:
	ldr	x8, [x0, #24]
	ldrb	w8, [x8, x19]
	tbz	w8, #0, LBB59_30
; %bb.11:
	ldr	x8, [x0, #8]
	add	x22, x8, x19, lsl #4
	ldrb	w8, [x22]
	cbnz	w8, LBB59_30
; %bb.12:
	mov	x9, x21
	ldrh	w10, [x22, #2]
	cbz	x10, LBB59_20
; %bb.13:
	mov	w13, #0                         ; =0x0
	ldr	x8, [x22, #8]
	add	x12, x8, #4
	mov	w14, #1                         ; =0x1
	mov	w15, #54                        ; =0x36
	mov	w16, #1280                      ; =0x500
	mov	x17, x10
	b	LBB59_23
LBB59_14:
	mov	x22, x2
	lsl	x9, x19, #32
	orr	x8, x9, x8, lsl #16
	mov	w9, #10                         ; =0xa
	orr	x1, x8, x9
	bl	_union_value
	tbz	w0, #0, LBB59_30
	b	LBB59_16
LBB59_15:
	mov	x22, x2
	lsl	x9, x19, #32
	orr	x8, x9, x8, lsl #16
	orr	x1, x8, #0x7
	bl	_supported
	tbz	w0, #0, LBB59_30
LBB59_16:
	mov	w10, #0                         ; =0x0
	mov	x2, x22
	mov	x9, x21
	b	LBB59_20
LBB59_17:
	cmp	w20, #4
	mov	w8, #0                          ; =0x0
	ccmp	w20, #2, #0, ne
	b.hi	LBB59_31
; %bb.18:
	cmn	w19, #1
	b.ne	LBB59_31
; %bb.19:
	mov	x9, x21
	mov	w10, #0                         ; =0x0
LBB59_20:
	strb	w20, [x9]
	sturh	wzr, [x9, #1]
	strb	wzr, [x9, #3]
	str	w19, [x9, #4]
	mov	w8, #1                          ; =0x1
	strh	w10, [x2]
	b	LBB59_31
LBB59_21:                               ;   in Loop: Header=BB59_23 Depth=1
	ldr	w8, [x12]
	cmn	w8, #1
	b.ne	LBB59_30
LBB59_22:                               ;   in Loop: Header=BB59_23 Depth=1
	add	x12, x12, #12
	subs	x17, x17, #1
	b.eq	LBB59_27
LBB59_23:                               ; =>This Inner Loop Header: Depth=1
	mov	w8, #0                          ; =0x0
	ldurb	w1, [x12, #-4]
	cmp	w1, #10
	b.hi	LBB59_31
; %bb.24:                               ;   in Loop: Header=BB59_23 Depth=1
	lsl	w1, w14, w1
	tst	w1, w15
	b.ne	LBB59_21
; %bb.25:                               ;   in Loop: Header=BB59_23 Depth=1
	tst	w1, w16
	b.eq	LBB59_31
; %bb.26:                               ;   in Loop: Header=BB59_23 Depth=1
	mov	w13, #1                         ; =0x1
	b	LBB59_22
LBB59_27:
	tbz	w13, #0, LBB59_20
; %bb.28:
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	x1, x19
	bl	_nested_result_tree
	cbz	w0, LBB59_30
; %bb.29:
	ldrh	w10, [x22, #2]
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	mov	x9, x21
	b	LBB59_20
LBB59_30:
	mov	w8, #0                          ; =0x0
LBB59_31:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
LBB59_32:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nested_result_tree
_nested_result_tree:                    ; @nested_result_tree
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x1
	mov	x19, x0
	mov	w22, w1
	mov	w20, #1                         ; =0x1
	add	x0, x22, #1
	mov	w1, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB60_20
; %bb.1:
	strb	w20, [x0, x22]
	adds	w8, w21, #1
	b.hs	LBB60_22
; %bb.2:
	ldr	x9, [x19, #24]
	ldrb	w10, [x9, x22]
	ubfx	w10, w10, #1, #1
	mov	w11, #1                         ; =0x1
	mov	w12, #54                        ; =0x36
	mov	w13, #1280                      ; =0x500
	b	LBB60_4
LBB60_3:                                ;   in Loop: Header=BB60_4 Depth=1
	cbz	x8, LBB60_24
LBB60_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB60_13 Depth 2
	sub	x8, x8, #1
	ldrb	w14, [x0, x8]
	cbz	w14, LBB60_3
; %bb.5:                                ;   in Loop: Header=BB60_4 Depth=1
	ldrb	w14, [x9, x8]
	tbz	w14, #0, LBB60_21
; %bb.6:                                ;   in Loop: Header=BB60_4 Depth=1
	ubfx	w14, w14, #1, #1
	cmp	w14, w10
	b.ne	LBB60_21
; %bb.7:                                ;   in Loop: Header=BB60_4 Depth=1
	ldr	x14, [x19, #8]
	add	x15, x14, x8, lsl #4
	ldrb	w14, [x15]
	tst	w14, #0xfffffffd
	b.ne	LBB60_21
; %bb.8:                                ;   in Loop: Header=BB60_4 Depth=1
	ldrh	w14, [x15, #2]
	cmp	w14, #256
	b.hi	LBB60_21
; %bb.9:                                ;   in Loop: Header=BB60_4 Depth=1
	cbz	w14, LBB60_3
; %bb.10:                               ;   in Loop: Header=BB60_4 Depth=1
	ldr	x15, [x15, #8]
	add	x15, x15, #4
	b	LBB60_13
LBB60_11:                               ;   in Loop: Header=BB60_13 Depth=2
	ldr	w16, [x15]
	cmn	w16, #1
	b.ne	LBB60_21
LBB60_12:                               ;   in Loop: Header=BB60_13 Depth=2
	add	x15, x15, #12
	subs	x14, x14, #1
	b.eq	LBB60_3
LBB60_13:                               ;   Parent Loop BB60_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w20, #0                         ; =0x0
	ldurb	w16, [x15, #-4]
	cmp	w16, #10
	b.hi	LBB60_22
; %bb.14:                               ;   in Loop: Header=BB60_13 Depth=2
	lsl	w16, w11, w16
	tst	w16, w12
	b.ne	LBB60_11
; %bb.15:                               ;   in Loop: Header=BB60_13 Depth=2
	tst	w16, w13
	b.eq	LBB60_22
; %bb.16:                               ;   in Loop: Header=BB60_13 Depth=2
	ldr	w16, [x15]
	cmp	x8, x16
	b.ls	LBB60_21
; %bb.17:                               ;   in Loop: Header=BB60_13 Depth=2
	ldrb	w17, [x0, x8]
	cmp	w17, #31
	b.hi	LBB60_21
; %bb.18:                               ;   in Loop: Header=BB60_13 Depth=2
	ldrb	w1, [x0, x16]
	cmp	w1, w17
	b.hi	LBB60_12
; %bb.19:                               ;   in Loop: Header=BB60_13 Depth=2
	add	w17, w17, #1
	strb	w17, [x0, x16]
	b	LBB60_12
LBB60_20:
	mov	w20, #0                         ; =0x0
	b	LBB60_23
LBB60_21:
	mov	w20, #0                         ; =0x0
LBB60_22:
	bl	_free
LBB60_23:
	mov	x0, x20
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB60_24:
	mov	w20, #1                         ; =0x1
	b	LBB60_22
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_value_parameters ; -- Begin function nvm_affine_value_parameters
	.globl	_nvm_affine_value_parameters
	.p2align	2
_nvm_affine_value_parameters:           ; @nvm_affine_value_parameters
	.cfi_startproc
; %bb.0:
	mov	w9, #0                          ; =0x0
	cbz	x0, LBB61_7
; %bb.1:
	cbz	x1, LBB61_7
; %bb.2:
	cbz	x3, LBB61_7
; %bb.3:
	sub	sp, sp, #96
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x8, x0
	ldr	x0, [x0]
	ldrh	w9, [x0, #58]
	cmp	w9, #8
	ccmp	w9, w2, #2, ls
	b.hi	LBB61_5
; %bb.4:
	ldrh	w10, [x0, #56]
	cmp	w9, w10
	b.ls	LBB61_8
LBB61_5:
	mov	w9, #0                          ; =0x0
LBB61_6:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #96
LBB61_7:
	mov	x0, x9
	ret
LBB61_8:
	cbz	w9, LBB61_45
; %bb.9:
	mov	x19, #0                         ; =0x0
	movi.8b	v8, #2
	movi.4s	v31, #1
	movi.16b	v9, #2
	mov	x20, x3
	mov	x21, x1
	mov	x22, x8
	b	LBB61_12
LBB61_10:                               ;   in Loop: Header=BB61_12 Depth=1
	sub	w11, w10, #1
	cmp	w11, #2
	ccmp	w10, #4, #4, hs
	b.ne	LBB61_20
LBB61_11:                               ;   in Loop: Header=BB61_12 Depth=1
	add	x19, x19, #1
	ldr	x0, [x8]
	ldrh	w9, [x0, #58]
	cmp	x19, x9
	b.hs	LBB61_42
LBB61_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB61_32 Depth 2
                                        ;     Child Loop BB61_36 Depth 2
                                        ;     Child Loop BB61_39 Depth 2
	ldr	x9, [x0, #40]
	add	x11, x9, x19, lsl #3
	ldrb	w9, [x11, #1]
	cbnz	w9, LBB61_5
; %bb.13:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	w23, [x11, #4]
	ldrb	w10, [x11]
	cmp	w10, #6
	b.le	LBB61_10
; %bb.14:                               ;   in Loop: Header=BB61_12 Depth=1
	cmp	w10, #7
	b.eq	LBB61_27
; %bb.15:                               ;   in Loop: Header=BB61_12 Depth=1
	cmp	w10, #10
	b.eq	LBB61_22
; %bb.16:                               ;   in Loop: Header=BB61_12 Depth=1
	cmp	w10, #8
	b.ne	LBB61_6
; %bb.17:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	w9, [x0, #16]
	cmp	w23, w9
	b.hs	LBB61_5
; %bb.18:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	x9, [x0, #8]
	lsl	x10, x23, #4
	ldrb	w9, [x9, x10]
	cbnz	w9, LBB61_5
; %bb.19:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	x9, [x0, #24]
	ldrb	w9, [x9, x23]
	tbnz	w9, #0, LBB61_11
	b	LBB61_5
LBB61_20:                               ;   in Loop: Header=BB61_12 Depth=1
	cmp	w10, #5
	b.ne	LBB61_6
; %bb.21:                               ;   in Loop: Header=BB61_12 Depth=1
	cmn	w23, #1
	b.eq	LBB61_11
	b	LBB61_5
LBB61_22:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	w8, [x0, #16]
	cmp	w8, w23
	b.ls	LBB61_5
; %bb.23:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	x8, [x0, #8]
	lsl	x9, x23, #4
	ldrb	w9, [x8, x9]
	cmp	w9, #2
	b.ne	LBB61_5
; %bb.24:                               ;   in Loop: Header=BB61_12 Depth=1
	cbz	w23, LBB61_28
; %bb.25:                               ;   in Loop: Header=BB61_12 Depth=1
	cmp	w23, #8
	b.hs	LBB61_29
; %bb.26:                               ;   in Loop: Header=BB61_12 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB61_38
LBB61_27:                               ;   in Loop: Header=BB61_12 Depth=1
	ldrh	w8, [x11, #2]
	lsl	x9, x23, #32
	orr	x8, x9, x8, lsl #16
	orr	x1, x8, #0x7
	bl	_supported
	movi.16b	v9, #2
	movi.4s	v31, #1
	mov	x1, x21
	mov	x3, x20
	mov	x8, x22
	cbnz	w0, LBB61_11
	b	LBB61_5
LBB61_28:                               ;   in Loop: Header=BB61_12 Depth=1
	mov	w1, #0                          ; =0x0
	b	LBB61_40
LBB61_29:                               ;   in Loop: Header=BB61_12 Depth=1
	cmp	w23, #64
	b.hs	LBB61_31
; %bb.30:                               ;   in Loop: Header=BB61_12 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB61_35
LBB61_31:                               ;   in Loop: Header=BB61_12 Depth=1
	movi.2d	v0, #0000000000000000
	and	x9, x23, #0xffffffc0
	movi.2d	v2, #0000000000000000
	mov	x10, x8
	movi.2d	v1, #0000000000000000
	mov	x11, x9
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB61_32:                               ;   Parent Loop BB61_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x10, #16
	ldr	b24, [x10]
	ld1.b	{ v24 }[1], [x12]
	add	x12, x10, #32
	ld1.b	{ v24 }[2], [x12]
	add	x12, x10, #48
	ld1.b	{ v24 }[3], [x12]
	add	x12, x10, #64
	ld1.b	{ v24 }[4], [x12]
	add	x12, x10, #80
	ld1.b	{ v24 }[5], [x12]
	add	x12, x10, #96
	ld1.b	{ v24 }[6], [x12]
	add	x12, x10, #112
	ld1.b	{ v24 }[7], [x12]
	add	x12, x10, #144
	ldur	b26, [x10, #128]
	ld1.b	{ v26 }[1], [x12]
	add	x12, x10, #160
	ld1.b	{ v26 }[2], [x12]
	add	x12, x10, #176
	ld1.b	{ v26 }[3], [x12]
	add	x12, x10, #192
	ld1.b	{ v26 }[4], [x12]
	add	x12, x10, #208
	ld1.b	{ v26 }[5], [x12]
	add	x12, x10, #224
	ld1.b	{ v26 }[6], [x12]
	add	x12, x10, #240
	ld1.b	{ v26 }[7], [x12]
	add	x12, x10, #272
	ldr	b25, [x10, #256]
	ld1.b	{ v25 }[1], [x12]
	add	x12, x10, #288
	ld1.b	{ v25 }[2], [x12]
	add	x12, x10, #304
	ld1.b	{ v25 }[3], [x12]
	add	x12, x10, #320
	ld1.b	{ v25 }[4], [x12]
	add	x12, x10, #336
	ld1.b	{ v25 }[5], [x12]
	add	x12, x10, #352
	ld1.b	{ v25 }[6], [x12]
	add	x12, x10, #368
	ld1.b	{ v25 }[7], [x12]
	add	x12, x10, #400
	ldr	b27, [x10, #384]
	ld1.b	{ v27 }[1], [x12]
	add	x12, x10, #416
	ld1.b	{ v27 }[2], [x12]
	add	x12, x10, #432
	ld1.b	{ v27 }[3], [x12]
	add	x12, x10, #448
	ld1.b	{ v27 }[4], [x12]
	add	x12, x10, #464
	ld1.b	{ v27 }[5], [x12]
	add	x12, x10, #480
	ld1.b	{ v27 }[6], [x12]
	add	x12, x10, #496
	ld1.b	{ v27 }[7], [x12]
	add	x12, x10, #528
	ldr	b28, [x10, #512]
	ld1.b	{ v28 }[1], [x12]
	add	x12, x10, #544
	ld1.b	{ v28 }[2], [x12]
	add	x12, x10, #560
	ld1.b	{ v28 }[3], [x12]
	add	x12, x10, #576
	ld1.b	{ v28 }[4], [x12]
	add	x12, x10, #592
	ld1.b	{ v28 }[5], [x12]
	add	x12, x10, #608
	ld1.b	{ v28 }[6], [x12]
	add	x12, x10, #624
	ld1.b	{ v28 }[7], [x12]
	add	x12, x10, #656
	ldr	b29, [x10, #640]
	ld1.b	{ v29 }[1], [x12]
	add	x12, x10, #672
	ld1.b	{ v29 }[2], [x12]
	add	x12, x10, #688
	ld1.b	{ v29 }[3], [x12]
	add	x12, x10, #704
	ld1.b	{ v29 }[4], [x12]
	add	x12, x10, #720
	ld1.b	{ v29 }[5], [x12]
	add	x12, x10, #736
	ld1.b	{ v29 }[6], [x12]
	add	x12, x10, #752
	ld1.b	{ v29 }[7], [x12]
	add	x12, x10, #784
	zip1.2d	v30, v24, v26
	ldr	b24, [x10, #768]
	ld1.b	{ v24 }[1], [x12]
	add	x12, x10, #800
	ld1.b	{ v24 }[2], [x12]
	add	x12, x10, #816
	ld1.b	{ v24 }[3], [x12]
	add	x12, x10, #832
	ld1.b	{ v24 }[4], [x12]
	add	x12, x10, #848
	ld1.b	{ v24 }[5], [x12]
	add	x12, x10, #864
	ld1.b	{ v24 }[6], [x12]
	add	x12, x10, #880
	ld1.b	{ v24 }[7], [x12]
	add	x12, x10, #912
	zip1.2d	v25, v25, v27
	ldr	b27, [x10, #896]
	ld1.b	{ v27 }[1], [x12]
	add	x12, x10, #928
	ld1.b	{ v27 }[2], [x12]
	add	x12, x10, #944
	ld1.b	{ v27 }[3], [x12]
	add	x12, x10, #960
	ld1.b	{ v27 }[4], [x12]
	add	x12, x10, #976
	ld1.b	{ v27 }[5], [x12]
	add	x12, x10, #992
	ld1.b	{ v27 }[6], [x12]
	add	x12, x10, #1008
	ld1.b	{ v27 }[7], [x12]
	zip1.2d	v26, v28, v29
	zip1.2d	v24, v24, v27
	cmeq.16b	v27, v30, v9
	ushll2.8h	v28, v27, #0
	ushll2.4s	v29, v28, #0
	and.16b	v29, v29, v31
	add.4s	v3, v3, v29
	ushll.8h	v27, v27, #0
	ushll.4s	v28, v28, #0
	and.16b	v28, v28, v31
	add.4s	v1, v1, v28
	ushll.4s	v28, v27, #0
	and.16b	v28, v28, v31
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v31
	cmeq.16b	v25, v25, v9
	add.4s	v2, v2, v27
	ushll2.8h	v27, v25, #0
	add.4s	v0, v0, v28
	ushll2.4s	v28, v27, #0
	and.16b	v28, v28, v31
	add.4s	v21, v21, v28
	ushll.8h	v25, v25, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v31
	add.4s	v7, v7, v27
	ushll.4s	v27, v25, #0
	and.16b	v27, v27, v31
	ushll2.4s	v25, v25, #0
	and.16b	v25, v25, v31
	cmeq.16b	v26, v26, v9
	add.4s	v18, v18, v25
	add.4s	v4, v4, v27
	ushll2.8h	v25, v26, #0
	ushll2.4s	v27, v25, #0
	and.16b	v27, v27, v31
	add.4s	v19, v19, v27
	ushll.8h	v26, v26, #0
	ushll.4s	v25, v25, #0
	and.16b	v25, v25, v31
	add.4s	v22, v22, v25
	ushll.4s	v25, v26, #0
	and.16b	v25, v25, v31
	ushll2.4s	v26, v26, #0
	cmeq.16b	v24, v24, v9
	and.16b	v26, v26, v31
	add.4s	v5, v5, v26
	ushll2.8h	v26, v24, #0
	add.4s	v16, v16, v25
	ushll2.4s	v25, v26, #0
	and.16b	v25, v25, v31
	add.4s	v23, v23, v25
	ushll.8h	v24, v24, #0
	ushll.4s	v25, v26, #0
	and.16b	v25, v25, v31
	add.4s	v17, v17, v25
	ushll2.4s	v25, v24, #0
	and.16b	v25, v25, v31
	add.4s	v20, v20, v25
	ushll.4s	v24, v24, #0
	and.16b	v24, v24, v31
	add.4s	v6, v6, v24
	add	x10, x10, #1024
	subs	x11, x11, #64
	b.ne	LBB61_32
; %bb.33:                               ;   in Loop: Header=BB61_12 Depth=1
	add.4s	v2, v18, v2
	add.4s	v3, v21, v3
	add.4s	v0, v4, v0
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v2, v5, v2
	add.4s	v2, v20, v2
	add.4s	v3, v23, v3
	add.4s	v0, v6, v0
	add.4s	v1, v17, v1
	add.4s	v0, v0, v1
	add.4s	v1, v2, v3
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x9, x23
	b.eq	LBB61_40
; %bb.34:                               ;   in Loop: Header=BB61_12 Depth=1
	tst	x23, #0x38
	b.eq	LBB61_38
LBB61_35:                               ;   in Loop: Header=BB61_12 Depth=1
	mov	x10, x9
	and	x9, x23, #0xfffffff8
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.s	v1[0], w1
	add	x11, x8, x10, lsl #4
	sub	x10, x10, x9
	add	x11, x11, #64
LBB61_36:                               ;   Parent Loop BB61_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x12, x11, #48
	sub	x13, x11, #32
	sub	x14, x11, #16
	add	x15, x11, #16
	add	x16, x11, #32
	add	x17, x11, #48
	ldur	b2, [x11, #-64]
	ld1.b	{ v2 }[1], [x12]
	ld1.b	{ v2 }[2], [x13]
	ld1.b	{ v2 }[3], [x14]
	ld1.b	{ v2 }[4], [x11]
	ld1.b	{ v2 }[5], [x15]
	ld1.b	{ v2 }[6], [x16]
	ld1.b	{ v2 }[7], [x17]
	cmeq.8b	v2, v2, v8
	ushll.8h	v2, v2, #0
	ushll.4s	v3, v2, #0
	and.16b	v3, v3, v31
	ushll2.4s	v2, v2, #0
	and.16b	v2, v2, v31
	add.4s	v0, v0, v2
	add.4s	v1, v1, v3
	add	x11, x11, #128
	adds	x10, x10, #8
	b.ne	LBB61_36
; %bb.37:                               ;   in Loop: Header=BB61_12 Depth=1
	add.4s	v0, v1, v0
	addv.4s	s0, v0
	fmov	w1, s0
	cmp	x9, x23
	b.eq	LBB61_40
LBB61_38:                               ;   in Loop: Header=BB61_12 Depth=1
	sub	x10, x23, x9
	add	x8, x8, x9, lsl #4
LBB61_39:                               ;   Parent Loop BB61_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x8], #16
	cmp	w9, #2
	cinc	w1, w1, eq
	subs	x10, x10, #1
	b.ne	LBB61_39
LBB61_40:                               ;   in Loop: Header=BB61_12 Depth=1
	ldr	x0, [x0, #64]
	add	x3, sp, #4
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	movi.16b	v9, #2
	movi.4s	v31, #1
	cbnz	w0, LBB61_5
; %bb.41:                               ;   in Loop: Header=BB61_12 Depth=1
	mov	x3, x20
	mov	x1, x21
	mov	x8, x22
	ldr	w9, [sp, #4]
	cmp	w9, w23
	b.eq	LBB61_11
	b	LBB61_5
LBB61_42:
	cbz	w9, LBB61_45
; %bb.43:
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB61_44:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x0, #40]
	add	x11, x11, x9
	ldrb	w12, [x11]
	ldr	w11, [x11, #4]
	strb	w12, [x1]
	sturh	wzr, [x1, #1]
	strb	wzr, [x1, #3]
	str	w11, [x1, #4]
	add	x10, x10, #1
	ldr	x0, [x8]
	ldrh	w11, [x0, #58]
	add	x1, x1, #8
	add	x9, x9, #8
	cmp	x10, x11
	b.lo	LBB61_44
	b	LBB61_46
LBB61_45:
	mov	w11, #0                         ; =0x0
LBB61_46:
	strh	w11, [x3]
	mov	w9, #1                          ; =0x1
	b	LBB61_6
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_consuming_parameters ; -- Begin function nvm_affine_consuming_parameters
	.globl	_nvm_affine_consuming_parameters
	.p2align	2
_nvm_affine_consuming_parameters:       ; @nvm_affine_consuming_parameters
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x21, x0
	mov	w0, #0                          ; =0x0
Lloh8:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh9:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh10:
	ldr	x8, [x8]
	str	x8, [sp, #72]
	strh	wzr, [sp, #6]
	cbz	x1, LBB62_9
; %bb.1:
	mov	x19, x3
	cbz	x3, LBB62_9
; %bb.2:
	mov	x22, x2
	mov	x20, x1
	add	x1, sp, #8
	add	x3, sp, #6
	mov	x0, x21
	mov	w2, #8                          ; =0x8
	bl	_nvm_affine_value_parameters
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB62_9
; %bb.3:
	ldrh	w23, [sp, #6]
	sub	w8, w23, #1
	cmp	w22, w8, uxth
	b.ls	LBB62_9
; %bb.4:
	mov	x24, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	add	x25, sp, #8
LBB62_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x1, [x25, x24, lsl #3]
	mov	x0, x21
	bl	_nvm_affine_type_is_owned
	orr	w22, w0, w22
	add	x24, x24, #1
	cmp	x23, x24
	b.ne	LBB62_5
; %bb.6:
	tbz	w22, #0, LBB62_8
; %bb.7:
	lsl	x2, x23, #3
	add	x1, sp, #8
	mov	x0, x20
	bl	_memcpy
	strh	w23, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB62_9
LBB62_8:
	mov	w0, #0                          ; =0x0
LBB62_9:
	ldr	x8, [sp, #72]
Lloh11:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh12:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh13:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB62_11
; %bb.10:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB62_11:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh8, Lloh9, Lloh10
	.loh AdrpLdrGotLdr	Lloh11, Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_owned_parameter_type ; -- Begin function nvm_affine_owned_parameter_type
	.globl	_nvm_affine_owned_parameter_type
	.p2align	2
_nvm_affine_owned_parameter_type:       ; @nvm_affine_owned_parameter_type
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB63_19
; %bb.1:
	cbz	x1, LBB63_19
; %bb.2:
	ldr	x8, [x8]
	ldrh	w9, [x8, #58]
	cmp	w9, #1
	b.ne	LBB63_6
; %bb.3:
	ldrh	w9, [x8, #56]
	cbz	w9, LBB63_6
; %bb.4:
	ldr	x9, [x8, #40]
	ldrb	w10, [x9]
	cmp	w10, #8
	b.ne	LBB63_6
; %bb.5:
	ldrb	w10, [x9, #1]
	cbz	w10, LBB63_7
LBB63_6:
	mov	w0, #0                          ; =0x0
	ret
LBB63_7:
	ldr	x12, [x9]
	and	w9, w12, #0xff
	lsr	x10, x12, #32
	mov	x11, x10
	mov	x16, x9
	cmp	w9, #7
	b.ne	LBB63_14
; %bb.8:
	tst	x12, #0xff00
	b.ne	LBB63_6
; %bb.9:
	ldr	x11, [x8, #48]
	cbz	x11, LBB63_6
; %bb.10:
	ldr	w12, [x11]
	cmp	w12, w10
	b.ls	LBB63_6
; %bb.11:
	add	x13, x11, #4
	add	x14, x11, #8
	mov	w15, #255                       ; =0xff
	mov	x11, x10
LBB63_12:                               ; =>This Inner Loop Header: Depth=1
	lsl	x11, x11, #3
	ldrb	w16, [x13, x11]
	ldr	w11, [x14, x11]
	cmp	w16, #7
	b.ne	LBB63_14
; %bb.13:                               ;   in Loop: Header=BB63_12 Depth=1
	mov	w0, #0                          ; =0x0
	cmp	w11, w12
	ccmp	w15, #0, #4, lo
	sub	w15, w15, #1
	b.ne	LBB63_12
	b	LBB63_19
LBB63_14:
	and	w12, w16, #0xfffffffd
	cmp	w12, #8
	b.ne	LBB63_6
; %bb.15:
	ldr	w12, [x8, #16]
	cmp	w11, w12
	b.hs	LBB63_6
; %bb.16:
	ldr	x8, [x8, #24]
	ldrb	w11, [x8, w11, uxtw]
	tbz	w11, #1, LBB63_6
; %bb.17:
	ldrb	w8, [x8, x10]
	tbz	w8, #0, LBB63_6
; %bb.18:
	strb	w9, [x1]
	sturh	wzr, [x1, #1]
	strb	wzr, [x1, #3]
	str	w10, [x1, #4]
	cmp	w9, #8
	cset	w0, eq
LBB63_19:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_parameter_type ; -- Begin function nvm_affine_parameter_type
	.globl	_nvm_affine_parameter_type
	.p2align	2
_nvm_affine_parameter_type:             ; @nvm_affine_parameter_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB64_3
; %bb.1:
	ldr	x8, [x0]
	ldrh	w8, [x8, #58]
	cmp	w8, #1
	b.ne	LBB64_3
; %bb.2:
	mov	x3, x2
	mov	x2, x1
	mov	w1, #0                          ; =0x0
	b	_nvm_affine_parameter_at
LBB64_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_proof_free ; -- Begin function nvm_mixed_samples_proof_free
	.globl	_nvm_mixed_samples_proof_free
	.p2align	2
_nvm_mixed_samples_proof_free:          ; @nvm_mixed_samples_proof_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB65_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_mixed_float_proof_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB65_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_analyze_mixed_samples
lCPI66_0:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI66_1:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI66_2:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_analyze_mixed_samples
	.globl	_nvm_analyze_mixed_samples
	.p2align	2
_nvm_analyze_mixed_samples:             ; @nvm_analyze_mixed_samples
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #12592                      ; =0x3130
Lloh14:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh15:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
Lloh16:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh17:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh18:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x1, LBB66_3
; %bb.1:
	mov	x20, x0
	stp	x1, xzr, [sp, #184]             ; 8-byte Folded Spill
	add	x8, sp, #256
	add	x1, sp, #192
	bl	_nvm_analyze_mixed_float_origins
	ldr	w8, [sp, #256]
	add	x9, sp, #5
	ldur	q0, [x9, #255]
	stur	q0, [x29, #-128]
	ldr	w9, [sp, #276]
	stur	w9, [x29, #-112]
	cbz	w8, LBB66_7
; %bb.2:
	str	w8, [x19]
	ldur	q0, [x29, #-128]
	stur	q0, [x19, #4]
	ldur	w8, [x29, #-112]
	b	LBB66_4
LBB66_3:
	mov	w8, #2                          ; =0x2
	str	w8, [x19]
Lloh19:
	adrp	x8, l___const.nvm_analyze_mixed_samples.error@PAGE+4
Lloh20:
	add	x8, x8, l___const.nvm_analyze_mixed_samples.error@PAGEOFF+4
	ldr	q0, [x8]
	stur	q0, [x19, #4]
	ldr	w8, [x8, #16]
LBB66_4:
	str	w8, [x19, #20]
LBB66_5:
	ldur	x8, [x29, #-96]
Lloh21:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh22:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh23:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB66_518
; %bb.6:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #304
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB66_7:
	mov	w0, #1                          ; =0x1
	mov	w1, #49408                      ; =0xc100
	movk	w1, #6, lsl #16
	bl	_calloc
	mov	x27, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #34864                      ; =0x8830
	movk	w1, #2, lsl #16
	bl	_calloc
	mov	x28, x0
	cbz	x27, LBB66_405
; %bb.8:
	cbz	x28, LBB66_405
; %bb.9:
	str	x19, [sp, #136]                 ; 8-byte Folded Spill
	add	x8, x27, #108, lsl #12          ; =442368
	add	x19, x8, #220
	add	x8, x27, #104, lsl #12          ; =425984
	add	x8, x8, #208
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	add	x23, x28, #1068
	stp	x20, x28, [x27]
	ldr	x21, [sp, #192]
	mov	x0, x28
	str	x21, [x0], #44
Lloh24:
	adrp	x8, lCPI66_1@PAGE
Lloh25:
	ldr	q0, [x8, lCPI66_1@PAGEOFF]
	mov	x9, x19
	str	q0, [x9, #12]!
Lloh26:
	adrp	x8, l_.str.2@PAGE
Lloh27:
	add	x8, x8, l_.str.2@PAGEOFF
	str	x9, [sp, #152]                  ; 8-byte Folded Spill
	str	x8, [x9, #16]
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
	mov	w1, #255                        ; =0xff
	mov	w2, #1024                       ; =0x400
	bl	_memset
	movi.2d	v0, #0xffffffffffffffff
	stp	q0, q0, [x23]
	stp	q0, q0, [x23, #32]
	stp	q0, q0, [x23, #64]
	stp	q0, q0, [x23, #96]
	stp	q0, q0, [x23, #128]
	stp	q0, q0, [x23, #160]
	stp	q0, q0, [x23, #192]
	stp	q0, q0, [x23, #224]
	stp	q0, q0, [x23, #256]
	stp	q0, q0, [x23, #288]
	stp	q0, q0, [x23, #320]
	stp	q0, q0, [x23, #352]
	stp	q0, q0, [x23, #384]
	stp	q0, q0, [x23, #416]
	stp	q0, q0, [x23, #448]
	stp	q0, q0, [x23, #480]
	stp	q0, q0, [x23, #512]
	stp	q0, q0, [x23, #544]
	stp	q0, q0, [x23, #576]
	stp	q0, q0, [x23, #608]
	stp	q0, q0, [x23, #640]
	stp	q0, q0, [x23, #672]
	stp	q0, q0, [x23, #704]
	stp	q0, q0, [x23, #736]
	stp	q0, q0, [x23, #768]
	stp	q0, q0, [x23, #800]
	stp	q0, q0, [x23, #832]
	stp	q0, q0, [x23, #864]
	stp	q0, q0, [x23, #896]
	stp	q0, q0, [x23, #928]
	stp	q0, q0, [x23, #960]
	stp	q0, q0, [x23, #992]
	ldr	w8, [x20, #272]
	str	x28, [sp, #144]                 ; 8-byte Folded Spill
	str	x27, [sp, #168]                 ; 8-byte Folded Spill
	cbz	w8, LBB66_188
; %bb.10:
	mov	x26, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	ldr	x25, [x21]
	add	x11, x27, #16
	add	x22, x27, #24
	add	x27, x27, #208
	add	x12, x25, #24
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #112]                  ; 4-byte Folded Spill
LBB66_11:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_25 Depth 2
                                        ;       Child Loop BB66_42 Depth 3
                                        ;     Child Loop BB66_59 Depth 2
                                        ;     Child Loop BB66_72 Depth 2
                                        ;       Child Loop BB66_92 Depth 3
                                        ;       Child Loop BB66_81 Depth 3
                                        ;     Child Loop BB66_103 Depth 2
                                        ;     Child Loop BB66_109 Depth 2
                                        ;       Child Loop BB66_129 Depth 3
                                        ;       Child Loop BB66_140 Depth 3
	ldr	x9, [x20, #256]
	add	x10, x26, x26, lsl #1
	lsl	x10, x10, #3
	add	x14, x9, x10
	add	x13, x11, x10
	str	w8, [x13]
	ldr	w8, [x14, #12]
	cbz	w8, LBB66_410
; %bb.12:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	w9, [x14, #8]
	ldr	w10, [x20, #288]
	subs	w9, w10, w9
	ccmp	w8, w9, #2, hs
	b.hi	LBB66_410
; %bb.13:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	w8, [x14]
	ldr	w9, [x20, #248]
	cmp	w8, w9
	b.hs	LBB66_410
; %bb.14:                               ;   in Loop: Header=BB66_11 Depth=1
	ldrb	w8, [x14, #20]
	cmp	w8, #15
	b.hi	LBB66_410
; %bb.15:                               ;   in Loop: Header=BB66_11 Depth=1
	stp	x12, x14, [sp, #88]             ; 16-byte Folded Spill
	stp	x11, x13, [sp, #72]             ; 16-byte Folded Spill
	str	x22, [sp, #104]                 ; 8-byte Folded Spill
	str	x19, [sp, #128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldp	x19, x8, [x8]
	ldr	x22, [x19, #256]
	ldr	x8, [x8]
	ldr	x21, [x8]
	mov	w0, #1                          ; =0x1
	mov	w1, #200                        ; =0xc8
	bl	_calloc
	cbz	x0, LBB66_464
; %bb.16:                               ;   in Loop: Header=BB66_11 Depth=1
	mov	x24, x0
	str	x25, [sp, #64]                  ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #80                         ; =0x50
	bl	_calloc
	str	x0, [x24]
	cbz	x0, LBB66_463
; %bb.17:                               ;   in Loop: Header=BB66_11 Depth=1
	mov	x25, x0
	str	x27, [sp, #56]                  ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	str	x19, [x0, #64]
	str	x26, [sp, #176]                 ; 8-byte Folded Spill
	str	w26, [x0, #72]
	str	x8, [x24, #56]
	ldr	x0, [x19, #312]
	ldr	w1, [x19, #320]
	add	x2, x25, #8
	bl	_nvm_v2_layouts_decode
	cbnz	w0, LBB66_407
; %bb.18:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	w26, [x21, #8]
	cmp	w26, #0
	csinc	x0, x26, xzr, ne
	bl	_malloc
	str	x0, [x25, #24]
	cbz	x0, LBB66_407
; %bb.19:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	x27, [x21, #5144]
	add	x1, x27, #8
	mov	x2, x26
	bl	_memcpy
	ldr	w2, [x21, #5152]
	add	x0, sp, #256
	mov	x1, x27
	bl	_nvm_v2_cursor_init
	add	x0, sp, #256
	add	x1, sp, #224
	bl	_nvm_v2_u32
	cbnz	w0, LBB66_407
; %bb.20:                               ;   in Loop: Header=BB66_11 Depth=1
	add	x0, sp, #256
	add	x1, sp, #220
	bl	_nvm_v2_u32
	cbnz	w0, LBB66_407
; %bb.21:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	w1, [sp, #220]
	add	x0, sp, #256
	add	x2, sp, #232
	bl	_nvm_v2_take
	cbnz	w0, LBB66_407
; %bb.22:                               ;   in Loop: Header=BB66_11 Depth=1
	add	x0, sp, #256
	bl	_nvm_v2_align4
	cbnz	w0, LBB66_407
; %bb.23:                               ;   in Loop: Header=BB66_11 Depth=1
	add	x0, sp, #256
	add	x1, sp, #224
	bl	_nvm_v2_u32
	cbnz	w0, LBB66_407
; %bb.24:                               ;   in Loop: Header=BB66_11 Depth=1
	mov	x26, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	mov	w9, #24                         ; =0x18
	madd	x8, x8, x9, x22
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
LBB66_25:                               ;   Parent Loop BB66_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB66_42 Depth 3
	add	x0, sp, #256
	add	x1, sp, #218
	bl	_nvm_v2_u16
	cbnz	w0, LBB66_406
; %bb.26:                               ;   in Loop: Header=BB66_25 Depth=2
	add	x0, sp, #256
	add	x1, sp, #216
	bl	_nvm_v2_u16
	cbnz	w0, LBB66_406
; %bb.27:                               ;   in Loop: Header=BB66_25 Depth=2
	add	x0, sp, #256
	add	x1, sp, #208
	bl	_nvm_v2_u8
	cbnz	w0, LBB66_406
; %bb.28:                               ;   in Loop: Header=BB66_25 Depth=2
	add	x0, sp, #256
	add	x8, sp, #208
	orr	x1, x8, #0x1
	bl	_nvm_v2_u8
	cbnz	w0, LBB66_406
; %bb.29:                               ;   in Loop: Header=BB66_25 Depth=2
	add	x0, sp, #256
	add	x1, sp, #200
	bl	_nvm_v2_u16
	cbnz	w0, LBB66_406
; %bb.30:                               ;   in Loop: Header=BB66_25 Depth=2
	add	x0, sp, #256
	add	x8, sp, #208
	orr	x1, x8, #0x4
	bl	_nvm_v2_u32
	cbnz	w0, LBB66_406
; %bb.31:                               ;   in Loop: Header=BB66_25 Depth=2
	mov	w22, w21
	ldrh	w19, [sp, #218]
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	cmp	x8, x22
	b.ne	LBB66_38
; %bb.32:                               ;   in Loop: Header=BB66_25 Depth=2
	strh	w19, [x25, #56]
	ldrh	w8, [sp, #216]
	strh	w8, [x25, #58]
	ldr	x8, [sp, #208]
	str	x8, [x25, #32]
	cmp	w19, #1
	csinc	w27, w19, wzr, hi
	mov	x0, x27
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x28, x0
	str	x0, [x25, #40]
	mov	x0, x27
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x26, x0
	str	x0, [x24, #8]
	ubfiz	x0, x27, #1, #32
	bl	_malloc
	mov	x27, x0
	str	x0, [x24, #16]
	mov	w0, #1                          ; =0x1
	mov	w1, #56                         ; =0x38
	bl	_calloc
	str	x0, [x24, #24]
	cbz	x28, LBB66_406
; %bb.33:                               ;   in Loop: Header=BB66_25 Depth=2
	cbz	x26, LBB66_406
; %bb.34:                               ;   in Loop: Header=BB66_25 Depth=2
	cbz	x27, LBB66_406
; %bb.35:                               ;   in Loop: Header=BB66_25 Depth=2
	cbz	x0, LBB66_406
; %bb.36:                               ;   in Loop: Header=BB66_25 Depth=2
	cbz	w19, LBB66_48
; %bb.37:                               ;   in Loop: Header=BB66_25 Depth=2
	lsl	x2, x19, #1
	mov	x0, x27
	mov	w1, #255                        ; =0xff
	bl	_memset
	mov	x19, #0                         ; =0x0
	b	LBB66_42
LBB66_38:                               ;   in Loop: Header=BB66_25 Depth=2
	cbz	w19, LBB66_48
; %bb.39:                               ;   in Loop: Header=BB66_25 Depth=2
	mov	x19, #0                         ; =0x0
	b	LBB66_42
LBB66_40:                               ;   in Loop: Header=BB66_42 Depth=3
	cbnz	w0, LBB66_406
LBB66_41:                               ;   in Loop: Header=BB66_42 Depth=3
	add	x19, x19, #1
	ldrh	w8, [sp, #218]
	cmp	x19, x8
	b.hs	LBB66_48
LBB66_42:                               ;   Parent Loop BB66_11 Depth=1
                                        ;     Parent Loop BB66_25 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x0, sp, #256
	add	x1, sp, #200
	bl	_nvm_v2_u8
	cbnz	w0, LBB66_406
; %bb.43:                               ;   in Loop: Header=BB66_42 Depth=3
	add	x0, sp, #256
	add	x8, sp, #200
	orr	x1, x8, #0x1
	bl	_nvm_v2_u8
	cbnz	w0, LBB66_406
; %bb.44:                               ;   in Loop: Header=BB66_42 Depth=3
	add	x0, sp, #256
	add	x1, sp, #230
	bl	_nvm_v2_u16
	cbnz	w0, LBB66_406
; %bb.45:                               ;   in Loop: Header=BB66_42 Depth=3
	add	x0, sp, #256
	add	x8, sp, #200
	orr	x1, x8, #0x4
	bl	_nvm_v2_u32
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	cmp	x8, x22
	b.ne	LBB66_40
; %bb.46:                               ;   in Loop: Header=BB66_42 Depth=3
	cbnz	w0, LBB66_40
; %bb.47:                               ;   in Loop: Header=BB66_42 Depth=3
	ldr	x8, [x25, #40]
	ldr	x9, [sp, #200]
	str	x9, [x8, x19, lsl #3]
	ldrh	w8, [sp, #216]
	cmp	x19, x8
	cset	w8, lo
	strb	w8, [x26, x19]
	b	LBB66_41
LBB66_48:                               ;   in Loop: Header=BB66_25 Depth=2
	add	w21, w21, #1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	cmp	w21, w8
	b.ne	LBB66_25
; %bb.49:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	x26, [sp, #176]                 ; 8-byte Folded Reload
	mov	w8, #24                         ; =0x18
	mul	x8, x26, x8
	ldr	x22, [sp, #104]                 ; 8-byte Folded Reload
	str	x24, [x22, x8]
	ldr	x8, [x24]
	ldrh	w9, [x8, #56]
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	ldrh	w10, [x0, #16]
	cmp	w9, w10
	b.ne	LBB66_476
; %bb.50:                               ;   in Loop: Header=BB66_11 Depth=1
	ldrh	w10, [x8, #58]
	ldrh	w11, [x0, #4]
	cmp	w10, w11
	ldp	x17, x16, [sp, #160]            ; 16-byte Folded Reload
	mov	w1, #22                         ; =0x16
	ldr	x19, [sp, #96]                  ; 8-byte Folded Reload
	b.ne	LBB66_476
; %bb.51:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	x13, [x8, #32]
	tst	x13, #0xff00
	b.ne	LBB66_476
; %bb.52:                               ;   in Loop: Header=BB66_11 Depth=1
	lsr	x12, x13, #32
	and	w11, w13, #0xff
	and	w13, w13, #0xff
	cmp	w13, #8
	b.ne	LBB66_62
; %bb.53:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	x13, [x16, #8]
	ldr	x13, [x13]
	ldr	x13, [x13]
	ldr	w14, [x13, #8]
	cmp	w14, w12
	b.ls	LBB66_476
; %bb.54:                               ;   in Loop: Header=BB66_11 Depth=1
	add	x14, x13, x12, lsl #2
	ldr	w14, [x14, #4120]
	cmp	w14, #1
	b.ne	LBB66_476
; %bb.55:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	x13, [x13]
	add	x13, x13, x12, lsl #4
	ldrb	w12, [x13]
	cbnz	w12, LBB66_476
; %bb.56:                               ;   in Loop: Header=BB66_11 Depth=1
	ldrh	w12, [x13, #2]
	cmp	w12, #256
	b.hi	LBB66_476
; %bb.57:                               ;   in Loop: Header=BB66_11 Depth=1
	cbz	w12, LBB66_66
; %bb.58:                               ;   in Loop: Header=BB66_11 Depth=1
	ldr	x13, [x13, #8]
	add	x13, x13, #4
LBB66_59:                               ;   Parent Loop BB66_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w14, [x13, #-4]
	cmp	w14, #4
	mov	w15, #1                         ; =0x1
	lsl	w14, w15, w14
	and	w14, w14, w1
	ccmp	w14, #0, #4, ls
	b.eq	LBB66_476
; %bb.60:                               ;   in Loop: Header=BB66_59 Depth=2
	ldr	w14, [x13], #12
	cmn	w14, #1
	b.ne	LBB66_476
; %bb.61:                               ;   in Loop: Header=BB66_59 Depth=2
	subs	x12, x12, #1
	b.ne	LBB66_59
	b	LBB66_66
LBB66_62:                               ;   in Loop: Header=BB66_11 Depth=1
	mov	w14, #-1                        ; =0xffffffff
	cmp	x12, x14
	b.ne	LBB66_476
; %bb.63:                               ;   in Loop: Header=BB66_11 Depth=1
	cmp	w11, #4
	b.hi	LBB66_65
; %bb.64:                               ;   in Loop: Header=BB66_11 Depth=1
	mov	w12, #1                         ; =0x1
	lsl	w12, w12, w11
	tst	w12, w1
	b.ne	LBB66_66
LBB66_65:                               ;   in Loop: Header=BB66_11 Depth=1
	cbnz	w13, LBB66_476
LBB66_66:                               ;   in Loop: Header=BB66_11 Depth=1
	ldrb	w12, [x0, #20]
	cmp	w12, w11
	b.ne	LBB66_476
; %bb.67:                               ;   in Loop: Header=BB66_11 Depth=1
	ldrb	w12, [x0, #21]
	cmp	w11, #0
	cset	w11, ne
	cmp	w12, w11
	b.ne	LBB66_476
; %bb.68:                               ;   in Loop: Header=BB66_11 Depth=1
	cbz	w9, LBB66_100
; %bb.69:                               ;   in Loop: Header=BB66_11 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x12, [x8, #40]
	b	LBB66_72
LBB66_70:                               ;   in Loop: Header=BB66_72 Depth=2
	and	w8, w13, #0xfffffffe
	cmp	w8, #2
	b.ne	LBB66_478
LBB66_71:                               ;   in Loop: Header=BB66_72 Depth=2
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB66_100
LBB66_72:                               ;   Parent Loop BB66_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB66_92 Depth 3
                                        ;       Child Loop BB66_81 Depth 3
	add	x8, x12, x11, lsl #3
	ldrb	w13, [x8]
	ldrb	w14, [x8, #1]
	ldr	w8, [x8, #4]
	cmp	x11, x10
	b.hs	LBB66_84
; %bb.73:                               ;   in Loop: Header=BB66_72 Depth=2
	cbnz	w14, LBB66_478
; %bb.74:                               ;   in Loop: Header=BB66_72 Depth=2
	cmp	w13, #8
	b.ne	LBB66_95
; %bb.75:                               ;   in Loop: Header=BB66_72 Depth=2
	ldr	x13, [x16, #8]
	ldr	x13, [x13]
	ldr	x13, [x13]
	ldr	w14, [x13, #8]
	cmp	w14, w8
	b.ls	LBB66_478
; %bb.76:                               ;   in Loop: Header=BB66_72 Depth=2
	add	x14, x13, x8, lsl #2
	ldr	w14, [x14, #4120]
	cmp	w14, #1
	b.ne	LBB66_478
; %bb.77:                               ;   in Loop: Header=BB66_72 Depth=2
	ldr	x13, [x13]
	add	x13, x13, x8, lsl #4
	ldrb	w8, [x13]
	cbnz	w8, LBB66_478
; %bb.78:                               ;   in Loop: Header=BB66_72 Depth=2
	ldrh	w8, [x13, #2]
	cmp	w8, #256
	b.hi	LBB66_478
; %bb.79:                               ;   in Loop: Header=BB66_72 Depth=2
	cbz	w8, LBB66_71
; %bb.80:                               ;   in Loop: Header=BB66_72 Depth=2
	ldr	x13, [x13, #8]
	add	x13, x13, #4
LBB66_81:                               ;   Parent Loop BB66_11 Depth=1
                                        ;     Parent Loop BB66_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w14, [x13, #-4]
	cmp	w14, #4
	mov	w15, #1                         ; =0x1
	lsl	w14, w15, w14
	and	w14, w14, w1
	ccmp	w14, #0, #4, ls
	b.eq	LBB66_478
; %bb.82:                               ;   in Loop: Header=BB66_81 Depth=3
	ldr	w14, [x13], #12
	cmn	w14, #1
	b.ne	LBB66_478
; %bb.83:                               ;   in Loop: Header=BB66_81 Depth=3
	subs	x8, x8, #1
	b.ne	LBB66_81
	b	LBB66_71
LBB66_84:                               ;   in Loop: Header=BB66_72 Depth=2
	cbnz	w14, LBB66_478
; %bb.85:                               ;   in Loop: Header=BB66_72 Depth=2
	cmp	w13, #8
	b.ne	LBB66_98
; %bb.86:                               ;   in Loop: Header=BB66_72 Depth=2
	ldr	x13, [x16, #8]
	ldr	x13, [x13]
	ldr	x14, [x13]
	ldr	w13, [x14, #8]
	cmp	w8, w13
	b.hs	LBB66_478
; %bb.87:                               ;   in Loop: Header=BB66_72 Depth=2
	add	x13, x14, x8, lsl #2
	ldr	w13, [x13, #4120]
	cmp	w13, #1
	b.ne	LBB66_70
; %bb.88:                               ;   in Loop: Header=BB66_72 Depth=2
	ldr	x14, [x14]
	add	x14, x14, x8, lsl #4
	ldrb	w8, [x14]
	cbnz	w8, LBB66_478
; %bb.89:                               ;   in Loop: Header=BB66_72 Depth=2
	ldrh	w8, [x14, #2]
	cmp	w8, #256
	b.hi	LBB66_478
; %bb.90:                               ;   in Loop: Header=BB66_72 Depth=2
	cbz	w8, LBB66_71
; %bb.91:                               ;   in Loop: Header=BB66_72 Depth=2
	ldr	x14, [x14, #8]
	add	x14, x14, #4
LBB66_92:                               ;   Parent Loop BB66_11 Depth=1
                                        ;     Parent Loop BB66_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w15, [x14, #-4]
	cmp	w15, #4
	mov	w0, #1                          ; =0x1
	lsl	w15, w0, w15
	and	w15, w15, w1
	ccmp	w15, #0, #4, ls
	b.eq	LBB66_70
; %bb.93:                               ;   in Loop: Header=BB66_92 Depth=3
	ldr	w15, [x14], #12
	cmn	w15, #1
	b.ne	LBB66_70
; %bb.94:                               ;   in Loop: Header=BB66_92 Depth=3
	subs	x8, x8, #1
	b.ne	LBB66_92
	b	LBB66_71
LBB66_95:                               ;   in Loop: Header=BB66_72 Depth=2
	cmn	w8, #1
	b.ne	LBB66_478
; %bb.96:                               ;   in Loop: Header=BB66_72 Depth=2
	mov	w8, #1                          ; =0x1
	cmp	w13, #4
	b.hi	LBB66_512
; %bb.97:                               ;   in Loop: Header=BB66_72 Depth=2
	mov	w14, #1                         ; =0x1
	lsl	w13, w14, w13
	tst	w13, w1
	b.ne	LBB66_71
	b	LBB66_512
LBB66_98:                               ;   in Loop: Header=BB66_72 Depth=2
	cmn	w8, #1
	b.ne	LBB66_478
; %bb.99:                               ;   in Loop: Header=BB66_72 Depth=2
	sub	w8, w13, #1
	cmp	w8, #4
	ccmp	w13, #7, #4, hs
	b.eq	LBB66_71
	b	LBB66_478
LBB66_100:                              ;   in Loop: Header=BB66_11 Depth=1
	cbz	x26, LBB66_105
; %bb.101:                              ;   in Loop: Header=BB66_11 Depth=1
	ldr	x9, [x20, #256]
	ldr	w8, [x19, #8]
	add	x9, x9, #12
	mov	x10, x26
	b	LBB66_103
LBB66_102:                              ;   in Loop: Header=BB66_103 Depth=2
	add	x9, x9, #24
	subs	x10, x10, #1
	b.eq	LBB66_105
LBB66_103:                              ;   Parent Loop BB66_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	w11, w12, [x9, #-4]
	add	x12, x12, x11
	cmp	x12, x8
	b.ls	LBB66_102
; %bb.104:                              ;   in Loop: Header=BB66_103 Depth=2
	ldr	w12, [x19, #12]
	add	x12, x12, x8
	cmp	x12, x11
	b.ls	LBB66_102
	b	LBB66_493
LBB66_105:                              ;   in Loop: Header=BB66_11 Depth=1
	ldr	w9, [x19, #12]
	ldr	w8, [x17]
	cbz	w9, LBB66_150
; %bb.106:                              ;   in Loop: Header=BB66_11 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB66_109
LBB66_107:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrb	w8, [x24, #8]
	cmp	w8, #3
	b.ne	LBB66_515
LBB66_108:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	x17, [sp, #160]                 ; 8-byte Folded Reload
	ldr	w8, [x17]
	str	w8, [x24, #72]
	ldr	w9, [x19, #12]
	add	w27, w25, w27
	cmp	w27, w9
	ldr	x26, [sp, #176]                 ; 8-byte Folded Reload
	b.hs	LBB66_150
LBB66_109:                              ;   Parent Loop BB66_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB66_129 Depth 3
                                        ;       Child Loop BB66_140 Depth 3
	cmp	w8, #1, lsl #12                 ; =4096
	b.eq	LBB66_502
; %bb.110:                              ;   in Loop: Header=BB66_109 Depth=2
	add	w10, w8, #1
	str	w10, [x17]
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	mov	w11, #104                       ; =0x68
	umaddl	x24, w8, w11, x10
	stp	w26, w27, [x24, #64]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x24, #80]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x24, #76]
	ldr	x8, [x20, #280]
	ldr	w10, [x19, #8]
	add	x8, x8, x10
	add	x0, x8, w27, uxtw
	sub	w1, w9, w27
	mov	x2, x24
	bl	_isa_decode
	cbz	w0, LBB66_503
; %bb.111:                              ;   in Loop: Header=BB66_109 Depth=2
	mov	x25, x0
	ldrb	w26, [x24]
	add	x1, sp, #256
	mov	x0, x26
	bl	_mc_scalar_op
	tbz	w0, #31, LBB66_114
; %bb.112:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #252
	b.hi	LBB66_521
; %bb.113:                              ;   in Loop: Header=BB66_109 Depth=2
Lloh28:
	adrp	x10, lJTI66_0@PAGE
Lloh29:
	add	x10, x10, lJTI66_0@PAGEOFF
	adr	x8, LBB66_114
	ldrh	w9, [x10, x26, lsl #1]
	add	x8, x8, x9, lsl #2
	br	x8
LBB66_114:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #59
	mov	w12, #22                        ; =0x16
	b.hi	LBB66_132
; %bb.115:                              ;   in Loop: Header=BB66_109 Depth=2
	mov	w8, #1                          ; =0x1
	lsl	x8, x8, x26
	mov	w9, #22528                      ; =0x5800
	movk	w9, #3, lsl #16
	tst	x8, x9
	b.eq	LBB66_118
; %bb.116:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrh	w8, [x24, #8]
	ldrh	w9, [x19, #16]
	cmp	w8, w9
	b.hs	LBB66_508
; %bb.117:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #13
	b.ne	LBB66_134
	b	LBB66_123
LBB66_118:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	x26, #13
	b.eq	LBB66_123
; %bb.119:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	x26, #59
	b.ne	LBB66_132
; %bb.120:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	w8, [x24, #8]
	cbz	w8, LBB66_514
; %bb.121:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	w9, [x20, #272]
	cmp	w8, w9
	b.hs	LBB66_514
; %bb.122:                              ;   in Loop: Header=BB66_109 Depth=2
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldrb	w9, [x10, #16]
	orr	w8, w9, w8
	strb	w8, [x10, #16]
	ldp	x19, x22, [sp, #96]             ; 16-byte Folded Reload
	b	LBB66_108
LBB66_123:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	w8, [x24, #8]
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	w10, [x9, #8]
	cmp	w8, w10
	b.hs	LBB66_488
; %bb.124:                              ;   in Loop: Header=BB66_109 Depth=2
	add	x10, x9, x8, lsl #2
	ldr	w10, [x10, #4120]
	cmp	w10, #1
	b.ne	LBB66_488
; %bb.125:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	x9, [x9]
	add	x9, x9, x8, lsl #4
	ldrb	w8, [x9]
	cbnz	w8, LBB66_488
; %bb.126:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrh	w8, [x9, #2]
	cmp	w8, #256
	b.hi	LBB66_488
; %bb.127:                              ;   in Loop: Header=BB66_109 Depth=2
	cbz	w8, LBB66_108
; %bb.128:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	x9, [x9, #8]
	add	x9, x9, #4
LBB66_129:                              ;   Parent Loop BB66_11 Depth=1
                                        ;     Parent Loop BB66_109 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w10, [x9, #-4]
	cmp	w10, #4
	mov	w11, #1                         ; =0x1
	lsl	w10, w11, w10
	and	w10, w10, w12
	ccmp	w10, #0, #4, ls
	b.eq	LBB66_488
; %bb.130:                              ;   in Loop: Header=BB66_129 Depth=3
	ldr	w10, [x9], #12
	cmn	w10, #1
	b.ne	LBB66_488
; %bb.131:                              ;   in Loop: Header=BB66_129 Depth=3
	subs	x8, x8, #1
	b.ne	LBB66_129
	b	LBB66_134
LBB66_132:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #3
	b.ne	LBB66_134
; %bb.133:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrb	w8, [x24, #8]
	cmp	w8, #1
	b.ls	LBB66_108
	b	LBB66_516
LBB66_134:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #80
	b.eq	LBB66_137
; %bb.135:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #251
	b.eq	LBB66_137
; %bb.136:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #88
	b.ne	LBB66_108
LBB66_137:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	w9, [x8, #8]
	cbz	w9, LBB66_143
; %bb.138:                              ;   in Loop: Header=BB66_109 Depth=2
	mov	x10, #0                         ; =0x0
	add	x11, x8, #32
	b	LBB66_140
LBB66_139:                              ;   in Loop: Header=BB66_140 Depth=3
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB66_143
LBB66_140:                              ;   Parent Loop BB66_11 Depth=1
                                        ;     Parent Loop BB66_109 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w12, [x11, #-4]
	ldr	x13, [sp, #176]                 ; 8-byte Folded Reload
	cmp	x13, x12
	b.ne	LBB66_139
; %bb.141:                              ;   in Loop: Header=BB66_140 Depth=3
	ldr	w12, [x11]
	cmp	w12, w27
	b.ne	LBB66_139
; %bb.142:                              ;   in Loop: Header=BB66_140 Depth=3
	strh	w10, [x24, #80]
	b	LBB66_139
LBB66_143:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrsh	x9, [x24, #80]
	tbnz	x9, #63, LBB66_513
; %bb.144:                              ;   in Loop: Header=BB66_109 Depth=2
	cmp	w26, #251
	b.ne	LBB66_107
; %bb.145:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrb	w10, [x24, #8]
	cbnz	w10, LBB66_504
; %bb.146:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrh	w10, [x24, #24]
	cbnz	w10, LBB66_504
; %bb.147:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	w10, [x24, #16]
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	ldr	w11, [x11, #16]
	cmp	w10, w11
	b.hs	LBB66_504
; %bb.148:                              ;   in Loop: Header=BB66_109 Depth=2
	ldr	x11, [sp, #88]                  ; 8-byte Folded Reload
	ldr	w10, [x11, x10, lsl #2]
	mov	w11, #24                        ; =0x18
	smaddl	x8, w9, w11, x8
	ldr	w9, [x8, #36]
	cmp	w10, w9
	b.ne	LBB66_504
; %bb.149:                              ;   in Loop: Header=BB66_109 Depth=2
	ldrh	w9, [x24, #32]
	ldurh	w8, [x8, #48]
	cmp	w9, w8
	ldp	x19, x22, [sp, #96]             ; 16-byte Folded Reload
	b.eq	LBB66_108
	b	LBB66_504
LBB66_150:                              ;   in Loop: Header=BB66_11 Depth=1
	ldp	x11, x9, [sp, #72]              ; 16-byte Folded Reload
	str	w8, [x9, #4]
	add	x26, x26, #1
	ldr	w21, [x20, #272]
	ldr	w9, [sp, #112]                  ; 4-byte Folded Reload
	add	w9, w9, #1
	str	w9, [sp, #112]                  ; 4-byte Folded Spill
	cmp	x26, x21
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x19, [sp, #128]                 ; 8-byte Folded Reload
	ldp	x27, x25, [sp, #56]             ; 16-byte Folded Reload
	ldr	x12, [sp, #88]                  ; 8-byte Folded Reload
	b.lo	LBB66_11
; %bb.151:
	ldr	x27, [sp, #168]                 ; 8-byte Folded Reload
	cbz	w21, LBB66_188
; %bb.152:
	mov	x24, #0                         ; =0x0
	add	x22, x27, #276
	mov	w25, #24                        ; =0x18
	mov	w26, #104                       ; =0x68
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
LBB66_153:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_156 Depth 2
                                        ;       Child Loop BB66_159 Depth 3
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	madd	x9, x24, x25, x8
	ldp	w8, w9, [x9]
	cmp	w8, w9
	b.hs	LBB66_165
; %bb.154:                              ;   in Loop: Header=BB66_153 Depth=1
	umaddl	x10, w8, w26, x22
	mov	x11, x8
	b	LBB66_156
LBB66_155:                              ;   in Loop: Header=BB66_156 Depth=2
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB66_165
LBB66_156:                              ;   Parent Loop BB66_153 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB66_159 Depth 3
	ldr	x12, [sp, #56]                  ; 8-byte Folded Reload
	madd	x12, x11, x26, x12
	ldrb	w13, [x12]
	sub	w14, w13, #56
	cmp	w14, #2
	b.hi	LBB66_162
; %bb.157:                              ;   in Loop: Header=BB66_156 Depth=2
	ldr	w27, [x12, #68]
	ldrsw	x14, [x12, #8]
	add	x14, x14, x27
	mov	x15, x10
	mov	x16, x8
	b	LBB66_159
LBB66_158:                              ;   in Loop: Header=BB66_159 Depth=3
	add	x16, x16, #1
	cmp	x9, x16
	b.eq	LBB66_161
LBB66_159:                              ;   Parent Loop BB66_153 Depth=1
                                        ;     Parent Loop BB66_156 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w17, [x15], #104
	cmp	x14, x17
	b.ne	LBB66_158
; %bb.160:                              ;   in Loop: Header=BB66_159 Depth=3
	str	w16, [x12, #76]
	b	LBB66_158
LBB66_161:                              ;   in Loop: Header=BB66_156 Depth=2
	ldr	w14, [x12, #76]
	cmn	w14, #1
	b.eq	LBB66_517
LBB66_162:                              ;   in Loop: Header=BB66_156 Depth=2
	ldr	w14, [x12, #72]
	cmp	w14, w9
	b.ne	LBB66_155
; %bb.163:                              ;   in Loop: Header=BB66_156 Depth=2
	cmp	w13, #56
	b.eq	LBB66_155
; %bb.164:                              ;   in Loop: Header=BB66_156 Depth=2
	cmp	w13, #61
	b.eq	LBB66_155
	b	LBB66_519
LBB66_165:                              ;   in Loop: Header=BB66_153 Depth=1
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	x1, x24
	bl	_mc_graph
	cbz	w0, LBB66_410
; %bb.166:                              ;   in Loop: Header=BB66_153 Depth=1
	add	x24, x24, #1
	cmp	x24, x21
	b.lo	LBB66_153
; %bb.167:
	mov	x21, #0                         ; =0x0
	add	x22, sp, #256
	orr	x24, x22, #0x2
	mov	w25, #24                        ; =0x18
	mov	w26, #1                         ; =0x1
LBB66_168:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_169 Depth 2
                                        ;     Child Loop BB66_172 Depth 2
                                        ;       Child Loop BB66_183 Depth 3
	ldr	x19, [x20, #256]
	add	x8, x21, x21, lsl #1
	lsl	x27, x8, #3
	add	x8, x19, x27
	ldrh	w28, [x8, #16]
	add	x0, sp, #256
	mov	w1, #12288                      ; =0x3000
	bl	_bzero
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	add	x8, x8, x27
	ldr	x9, [x8, #8]
	stp	x9, x22, [sp, #232]
	str	xzr, [sp, #248]
	mov	x10, x24
	cbz	x28, LBB66_170
LBB66_169:                              ;   Parent Loop BB66_168 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sturh	w26, [x10, #-2]
	stp	xzr, xzr, [x10]
	stur	xzr, [x10, #14]
	add	x10, x10, #24
	subs	x28, x28, #1
	b.ne	LBB66_169
LBB66_170:                              ;   in Loop: Header=BB66_168 Depth=1
	madd	x10, x21, x25, x19
	ldrh	w12, [x10, #4]!
	cbz	w12, LBB66_186
; %bb.171:                              ;   in Loop: Header=BB66_168 Depth=1
	mov	x11, #0                         ; =0x0
LBB66_172:                              ;   Parent Loop BB66_168 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB66_183 Depth 3
	ldr	x13, [x9]
	ldrh	w14, [x13, #56]
	ldr	x13, [x13, #40]
	cmp	x11, x14
	b.hs	LBB66_179
; %bb.173:                              ;   in Loop: Header=BB66_172 Depth=2
	add	x14, x13, x11, lsl #3
	ldrb	w15, [x14, #1]
	cbnz	w15, LBB66_179
; %bb.174:                              ;   in Loop: Header=BB66_172 Depth=2
	ldrb	w15, [x14]
	cmp	w15, #8
	b.ne	LBB66_179
; %bb.175:                              ;   in Loop: Header=BB66_172 Depth=2
	ldr	w14, [x14, #4]
	ldr	x15, [sp, #168]                 ; 8-byte Folded Reload
	ldr	x15, [x15, #8]
	ldr	x15, [x15]
	ldr	x15, [x15]
	ldr	w16, [x15, #8]
	cmp	w14, w16
	b.hs	LBB66_179
; %bb.176:                              ;   in Loop: Header=BB66_172 Depth=2
	add	x16, x15, x14, lsl #2
	ldr	w16, [x16, #4120]
	cmp	w16, #1
	b.ne	LBB66_179
; %bb.177:                              ;   in Loop: Header=BB66_172 Depth=2
	ldr	x15, [x15]
	add	x15, x15, x14, lsl #4
	ldrb	w14, [x15]
	cbnz	w14, LBB66_179
; %bb.178:                              ;   in Loop: Header=BB66_172 Depth=2
	ldrh	w14, [x15, #2]
	cmp	w14, #256
	b.ls	LBB66_181
LBB66_179:                              ;   in Loop: Header=BB66_172 Depth=2
	madd	x12, x11, x25, x22
	lsl	x14, x11, #3
	ldrb	w13, [x13, x14]
	lsl	w13, w26, w13
	strh	w13, [x12]
	stur	xzr, [x12, #10]
	stur	xzr, [x12, #2]
	str	xzr, [x12, #16]
	ldrh	w12, [x10]
LBB66_180:                              ;   in Loop: Header=BB66_172 Depth=2
	add	x11, x11, #1
	cmp	x11, w12, uxth
	b.lo	LBB66_172
	b	LBB66_186
LBB66_181:                              ;   in Loop: Header=BB66_172 Depth=2
	cbz	w14, LBB66_180
; %bb.182:                              ;   in Loop: Header=BB66_172 Depth=2
	ldr	x15, [x15, #8]
	add	x15, x15, #4
LBB66_183:                              ;   Parent Loop BB66_168 Depth=1
                                        ;     Parent Loop BB66_172 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w16, [x15, #-4]
	cmp	w16, #4
	lsl	w16, w26, w16
	mov	w17, #22                        ; =0x16
	and	w16, w16, w17
	ccmp	w16, #0, #4, ls
	b.eq	LBB66_179
; %bb.184:                              ;   in Loop: Header=BB66_183 Depth=3
	ldr	w16, [x15], #12
	cmn	w16, #1
	b.ne	LBB66_179
; %bb.185:                              ;   in Loop: Header=BB66_183 Depth=3
	subs	x14, x14, #1
	b.ne	LBB66_183
	b	LBB66_180
LBB66_186:                              ;   in Loop: Header=BB66_168 Depth=1
	ldr	w1, [x8]
	add	x2, sp, #232
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	bl	_mc_join
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x19, [sp, #128]                 ; 8-byte Folded Reload
	tbz	w0, #0, LBB66_410
; %bb.187:                              ;   in Loop: Header=BB66_168 Depth=1
	add	x21, x21, #1
	ldr	w8, [x20, #272]
	cmp	x21, x8
	ldr	x27, [sp, #168]                 ; 8-byte Folded Reload
	b.lo	LBB66_168
LBB66_188:
	ldr	w8, [x19, #8]
	cbz	w8, LBB66_422
; %bb.189:
	add	x9, x27, #104, lsl #12          ; =425984
	add	x21, x9, #220
	add	x9, x27, #208
	str	x9, [sp, #96]                   ; 8-byte Folded Spill
	add	x10, x27, #24
	add	x9, sp, #232
	orr	x9, x9, #0x2
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	add	x9, sp, #256
	add	x9, x9, #12
	stp	x10, x9, [sp, #16]              ; 16-byte Folded Spill
	mov	w26, #24                        ; =0x18
	str	x21, [sp, #56]                  ; 8-byte Folded Spill
LBB66_190:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_231 Depth 2
                                        ;     Child Loop BB66_242 Depth 2
                                        ;     Child Loop BB66_245 Depth 2
                                        ;     Child Loop BB66_286 Depth 2
                                        ;     Child Loop BB66_397 Depth 2
                                        ;     Child Loop BB66_381 Depth 2
                                        ;     Child Loop BB66_318 Depth 2
                                        ;     Child Loop BB66_374 Depth 2
                                        ;     Child Loop BB66_341 Depth 2
                                        ;     Child Loop BB66_326 Depth 2
                                        ;     Child Loop BB66_389 Depth 2
                                        ;     Child Loop BB66_208 Depth 2
                                        ;       Child Loop BB66_215 Depth 3
	ldr	x11, [sp, #160]                 ; 8-byte Folded Reload
	ldr	w9, [x11, #8]
	add	w10, w9, #1
	str	w10, [x11, #8]
	cmp	w9, #64, lsl #12                ; =262144
	b.eq	LBB66_465
; %bb.191:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w9, [x19]
	ldr	w10, [x21, x9, lsl #2]
	add	w9, w9, #1
	and	w9, w9, #0xfff
	str	w9, [x19]
	sub	w8, w8, #1
	str	w8, [x19, #8]
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	mov	w9, #104                        ; =0x68
	umaddl	x25, w10, w9, x8
	strb	wzr, [x25, #96]
	ldr	x0, [x25, #88]
	ldr	x8, [x20, #256]
	ldr	w9, [x25, #64]
	umaddl	x8, w9, w26, x8
	ldrh	w1, [x8, #16]
	bl	_mc_frame_clone
	ldr	w22, [x25, #64]
	cbz	x0, LBB66_466
; %bb.192:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x24, x0
	ldr	x8, [x27]
	ldr	x8, [x8, #256]
	umaddl	x8, w22, w26, x8
	mov	w9, #24                         ; =0x18
	ldrh	w26, [x8, #16]
	ldp	x10, x8, [x0]
	str	x10, [sp, #88]                  ; 8-byte Folded Spill
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	umaddl	x8, w26, w9, x8
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
	ldrb	w28, [x25]
	mov	x0, x28
	bl	_isa_get_info
	mov	x2, x28
	mov	x28, x25
	ldrh	w1, [x28, #8]!
	cmp	w2, #251
	b.eq	LBB66_195
; %bb.193:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w2, #88
	b.ne	LBB66_222
; %bb.194:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w3, #0                          ; =0x0
	ldrh	w9, [x25, #16]
	b	LBB66_196
LBB66_195:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w3, #0                          ; =0x0
	ldrh	w9, [x25, #32]
LBB66_196:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w10, #1                         ; =0x1
LBB66_197:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #2                          ; =0x2
Lloh30:
	adrp	x13, l_.str.38@PAGE
Lloh31:
	add	x13, x13, l_.str.38@PAGEOFF
	tbnz	w9, #31, LBB66_472
; %bb.198:                              ;   in Loop: Header=BB66_190 Depth=1
	tbnz	w10, #31, LBB66_472
; %bb.199:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w21, [x24, #16]
	subs	w8, w21, w9
	b.lo	LBB66_467
; %bb.200:                              ;   in Loop: Header=BB66_190 Depth=1
	add	w9, w8, w10
	cmp	w9, #256
	b.hi	LBB66_468
; %bb.201:                              ;   in Loop: Header=BB66_190 Depth=1
	stp	x8, x24, [sp, #104]             ; 16-byte Folded Spill
	mov	x24, x3
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	str	w9, [sp, #72]                   ; 4-byte Folded Spill
	str	w10, [sp, #80]                  ; 4-byte Folded Spill
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	add	x1, sp, #200
	mov	x0, x2
	mov	x27, x2
	bl	_mc_scalar_op
	tbnz	w0, #31, LBB66_258
; %bb.202:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x6, x27
	ldp	x30, x24, [sp, #104]            ; 16-byte Folded Reload
	cmp	w21, w30
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	mov	w2, #24                         ; =0x18
	mov	w3, #1                          ; =0x1
	mov	w4, #20                         ; =0x14
	mov	w5, #9                          ; =0x9
	movk	w5, #8, lsl #16
	ldr	x7, [sp, #176]                  ; 8-byte Folded Reload
	b.ls	LBB66_247
; %bb.203:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [sp, #200]
	cmp	w8, #16
	b.eq	LBB66_460
; %bb.204:                              ;   in Loop: Header=BB66_190 Depth=1
	lsl	w9, w3, w8
	and	w9, w9, #0xffff
	mov	x10, x30
	b	LBB66_208
LBB66_205:                              ;   in Loop: Header=BB66_208 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	w15, [x25, #68]
LBB66_206:                              ;   in Loop: Header=BB66_208 Depth=2
	add	w14, w14, #1
	str	w14, [x13, #20]
	umaddl	x13, w16, w4, x13
	str	w12, [x13, #2092]
	add	x12, x13, #2092
	str	w15, [x13, #2096]
	strh	w11, [x13, #2100]
	stur	w5, [x12, #10]
	strh	wzr, [x13, #2106]
	str	wzr, [x13, #2108]
LBB66_207:                              ;   in Loop: Header=BB66_208 Depth=2
	add	x10, x10, #1
	cmp	x10, x21
	b.eq	LBB66_247
LBB66_208:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB66_215 Depth 3
	madd	x12, x10, x2, x7
	ldrh	w11, [x12]
	ldr	x13, [x12, #8]
	ldrb	w12, [x12, #20]
	sub	w14, w11, #1
	cmp	w12, #0
	ccmp	x13, #0, #0, eq
	ccmp	w14, #31, #2, eq
	b.hs	LBB66_460
; %bb.209:                              ;   in Loop: Header=BB66_208 Depth=2
	cmp	w11, w9
	b.eq	LBB66_207
; %bb.210:                              ;   in Loop: Header=BB66_208 Depth=2
	cmp	w8, #3
	b.ne	LBB66_462
; %bb.211:                              ;   in Loop: Header=BB66_208 Depth=2
	cmp	w11, #9
	b.ne	LBB66_462
; %bb.212:                              ;   in Loop: Header=BB66_208 Depth=2
	sub	x11, x10, x30
	ldr	x12, [sp, #168]                 ; 8-byte Folded Reload
	ldr	x13, [x12, #8]
	ldr	w14, [x13, #20]
	ldr	w12, [x25, #64]
	cbz	w14, LBB66_205
; %bb.213:                              ;   in Loop: Header=BB66_208 Depth=2
	add	x15, x13, #2108
	mov	x16, x14
	b	LBB66_215
LBB66_214:                              ;   in Loop: Header=BB66_215 Depth=3
	add	x15, x15, #20
	subs	x16, x16, #1
	b.eq	LBB66_220
LBB66_215:                              ;   Parent Loop BB66_190 Depth=1
                                        ;     Parent Loop BB66_208 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w17, [x15, #-16]
	cmp	w17, w12
	b.ne	LBB66_214
; %bb.216:                              ;   in Loop: Header=BB66_215 Depth=3
	ldur	w17, [x15, #-12]
	ldr	w1, [x25, #68]
	cmp	w17, w1
	b.ne	LBB66_214
; %bb.217:                              ;   in Loop: Header=BB66_215 Depth=3
	ldurh	w17, [x15, #-8]
	cmp	x11, x17
	b.ne	LBB66_214
; %bb.218:                              ;   in Loop: Header=BB66_215 Depth=3
	ldr	w17, [x15]
	cbnz	w17, LBB66_214
; %bb.219:                              ;   in Loop: Header=BB66_208 Depth=2
	ldurh	w11, [x15, #-6]
	mov	w12, #9                         ; =0x9
	orr	w11, w11, w12
	sturh	w11, [x15, #-6]
	ldurh	w11, [x15, #-4]
	cmp	w11, #8
	b.eq	LBB66_207
	b	LBB66_475
LBB66_220:                              ;   in Loop: Header=BB66_208 Depth=2
	ldr	w15, [x25, #68]
	cmp	w14, #2, lsl #12                ; =8192
	b.eq	LBB66_469
; %bb.221:                              ;   in Loop: Header=BB66_208 Depth=2
	mov	x16, x14
	b	LBB66_206
LBB66_222:                              ;   in Loop: Header=BB66_190 Depth=1
	sub	w8, w2, #13
	and	w8, w8, #0xff
	cmp	w8, #1
	b.hi	LBB66_272
; %bb.223:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x8, x28
	cmp	w2, #13
	b.eq	LBB66_225
; %bb.224:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	add	x8, x8, x1, lsl #3
	add	x8, x8, #4
LBB66_225:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w8, [x8]
	ldr	x9, [x27, #8]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	w10, [x9, #8]
	cmp	w8, w10
	b.hs	LBB66_461
; %bb.226:                              ;   in Loop: Header=BB66_190 Depth=1
	add	x10, x9, x8, lsl #2
	ldr	w10, [x10, #4120]
	cmp	w10, #1
	b.ne	LBB66_461
; %bb.227:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x9, [x9]
	add	x10, x9, x8, lsl #4
	ldrb	w9, [x10]
	cbnz	w9, LBB66_461
; %bb.228:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w9, [x10, #2]
	cmp	w9, #256
	b.hi	LBB66_461
; %bb.229:                              ;   in Loop: Header=BB66_190 Depth=1
	cbz	w9, LBB66_234
; %bb.230:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x10, [x10, #8]
	add	x10, x10, #4
LBB66_231:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x10, #-4]
	cmp	w11, #4
	mov	w12, #1                         ; =0x1
	lsl	w11, w12, w11
	mov	w12, #22                        ; =0x16
	and	w11, w11, w12
	ccmp	w11, #0, #4, ls
	b.eq	LBB66_461
; %bb.232:                              ;   in Loop: Header=BB66_231 Depth=2
	ldr	w11, [x10], #12
	cmn	w11, #1
	b.ne	LBB66_461
; %bb.233:                              ;   in Loop: Header=BB66_231 Depth=2
	subs	x9, x9, #1
	b.ne	LBB66_231
LBB66_234:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	cbz	x9, LBB66_461
; %bb.235:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x9, [x9]
	ldr	w10, [x9, #16]
	cmp	w8, w10
	b.hs	LBB66_461
; %bb.236:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x10, [x9, #24]
	ldrb	w10, [x10, x8]
	tbz	w10, #0, LBB66_461
; %bb.237:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x9, [x9, #8]
	add	x8, x9, x8, lsl #4
	ldrb	w9, [x8]
	cbnz	w9, LBB66_461
; %bb.238:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w3, [x8, #2]
	and	w9, w3, #0xffff
	cmp	w9, #256
	b.hi	LBB66_461
; %bb.239:                              ;   in Loop: Header=BB66_190 Depth=1
	tst	w3, #0xffff
	ldr	x27, [sp, #168]                 ; 8-byte Folded Reload
	b.eq	LBB66_246
; %bb.240:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x8, #8]
	and	x12, x3, #0xffff
	and	w13, w3, #0xffff
	sub	x8, x12, #1
	mov	x11, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x11, #43691
	umulh	x11, x8, x11
	lsr	x11, x11, #1
	add	x11, x11, x11, lsl #1
	sub	x8, x8, x11
	add	x11, x8, #1
	cmp	x11, #3
	csinc	x8, xzr, x8, eq
	cmp	w13, #3
	add	x0, sp, #256
	b.lo	LBB66_243
; %bb.241:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x9, #0                          ; =0x0
	sub	x12, x12, x8
	add	x13, x10, #16
	ldr	x14, [sp, #24]                  ; 8-byte Folded Reload
LBB66_242:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w15, [x13, #-16]
	ldur	w16, [x13, #-12]
	sturb	w15, [x14, #-12]
	add	x15, x0, x9, lsl #3
	strb	wzr, [x15, #3]
	sturh	wzr, [x15, #1]
	stur	w16, [x14, #-8]
	ldurb	w16, [x13, #-4]
	ldr	w17, [x13]
	sturb	w16, [x14, #-4]
	strb	wzr, [x15, #11]
	sturh	wzr, [x15, #9]
	str	w17, [x14]
	ldrb	w16, [x13, #8]
	ldr	w17, [x13, #12]
	strb	w16, [x14, #4]
	strb	wzr, [x15, #19]
	sturh	wzr, [x15, #17]
	str	w17, [x14, #8]
	add	x9, x9, #3
	add	x14, x14, #24
	add	x13, x13, #36
	cmp	x12, x9
	b.ne	LBB66_242
LBB66_243:                              ;   in Loop: Header=BB66_190 Depth=1
	add	x12, sp, #256
	cmp	x11, #3
	b.eq	LBB66_246
; %bb.244:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w11, #12                        ; =0xc
	madd	x10, x9, x11, x10
	add	x10, x10, #4
	add	x9, x12, x9, lsl #3
LBB66_245:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x10, #-4]
	ldr	w12, [x10], #12
	strb	w11, [x9]
	sturh	wzr, [x9, #1]
	strb	wzr, [x9, #3]
	str	w12, [x9, #4]
	add	x9, x9, #8
	subs	x8, x8, #1
	b.ne	LBB66_245
LBB66_246:                              ;   in Loop: Header=BB66_190 Depth=1
	and	w8, w3, #0xffff
	cmp	w2, #13
	csel	w9, w8, wzr, eq
	csinc	w10, w8, wzr, ne
	b	LBB66_273
LBB66_247:                              ;   in Loop: Header=BB66_190 Depth=1
	str	x22, [sp, #64]                  ; 8-byte Folded Spill
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	lsl	w15, w3, w0
	mov	x17, x6
LBB66_248:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	strh	w8, [x24, #16]
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
	mov	w26, #24                        ; =0x18
	ldr	w8, [sp, #80]                   ; 4-byte Folded Reload
	cbz	w8, LBB66_250
; %bb.249:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w30, w26, x8
	strh	w15, [x8]
	strh	w27, [x8, #2]
	str	w14, [x8, #4]
	str	x12, [x8, #8]
	str	w13, [x8, #16]
	strb	w22, [x8, #20]
	ldrh	w9, [sp, #208]
	sturh	w9, [x8, #21]
	ldrb	w9, [sp, #210]
	strb	w9, [x8, #23]
LBB66_250:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w8, [x24, #16]
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [x9, #8]
	add	x9, x9, #24
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	ldrh	w10, [x9, x11, lsl #1]
	cmp	w8, w10
	b.ls	LBB66_252
; %bb.251:                              ;   in Loop: Header=BB66_190 Depth=1
	strh	w8, [x9, x11, lsl #1]
LBB66_252:                              ;   in Loop: Header=BB66_190 Depth=1
	sub	w8, w17, #56
	cmp	w8, #2
	b.hi	LBB66_255
; %bb.253:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w1, [x25, #76]
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	x22, x17
	mov	x2, x24
	bl	_mc_join
	mov	x27, x0
	cmp	w22, #56
	b.eq	LBB66_256
; %bb.254:                              ;   in Loop: Header=BB66_190 Depth=1
	cbz	w27, LBB66_256
LBB66_255:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w1, [x25, #72]
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	x2, x24
	bl	_mc_join
	mov	x27, x0
LBB66_256:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x0, [x24]
	bl	_nvm_affine_state_free
	ldr	x0, [x24, #8]
	bl	_free
	mov	x0, x24
	bl	_free
	tbz	w27, #0, LBB66_410
LBB66_257:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w8, [x19, #8]
	ldr	x27, [sp, #168]                 ; 8-byte Folded Reload
	cbnz	w8, LBB66_190
	b	LBB66_422
LBB66_258:                              ;   in Loop: Header=BB66_190 Depth=1
	str	x22, [sp, #64]                  ; 8-byte Folded Spill
	cmp	w27, #252
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	b.hi	LBB66_498
; %bb.259:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x17, x27
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
Lloh32:
	adrp	x10, lJTI66_1@PAGE
Lloh33:
	add	x10, x10, lJTI66_1@PAGEOFF
	adr	x8, LBB66_248
	ldrh	w9, [x10, x17, lsl #1]
	add	x8, x8, x9, lsl #2
	br	x8
LBB66_260:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x10, w30, w8, x9
	ldrb	w8, [x10, #20]
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	cbnz	w8, LBB66_480
; %bb.261:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x10, #8]
	cbnz	x8, LBB66_480
; %bb.262:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w3, [x10]
	sub	w9, w3, #1
	and	w8, w9, #0xffff
	cmp	w8, #30
	b.hi	LBB66_480
; %bb.263:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [x10, #44]
	cbnz	w8, LBB66_480
; %bb.264:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x10, #32]
	cbnz	x8, LBB66_480
; %bb.265:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w27, [x10, #24]
	sub	w10, w27, #1
	cmp	w10, #30
	b.hi	LBB66_268
; %bb.266:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w3, w27
	b.ne	LBB66_268
; %bb.267:                              ;   in Loop: Header=BB66_190 Depth=1
	tst	w3, w9
	cset	w8, eq
LBB66_268:                              ;   in Loop: Header=BB66_190 Depth=1
	and	w9, w17, #0xfe
	cmp	w9, #40
	b.ne	LBB66_293
; %bb.269:                              ;   in Loop: Header=BB66_190 Depth=1
	and	w10, w10, #0xffff
	cmp	w10, #30
	b.hi	LBB66_293
; %bb.270:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w10, #22                        ; =0x16
	and	w10, w3, w10
	cbnz	w10, LBB66_293
; %bb.271:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w9, #22                         ; =0x16
	tst	w27, w9
	csinc	w8, w8, wzr, ne
	tbnz	w8, #0, LBB66_296
	b	LBB66_480
LBB66_272:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w3, #0                          ; =0x0
	ldrsb	w9, [x0, #28]
	ldrsb	w10, [x0, #29]
LBB66_273:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w2, #61
	b.eq	LBB66_276
; %bb.274:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w2, #59
	b.ne	LBB66_197
; %bb.275:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x27]
	ldr	x8, [x8, #256]
	ldr	w9, [x28]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w9, [x8, #4]
	ldrb	w10, [x8, #21]
	b	LBB66_197
LBB66_276:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w8, [x24, #16]
	ldr	x9, [x27]
	ldr	x9, [x9, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w22, w10, x9
	ldrb	w9, [x9, #21]
	cmp	w8, w9
	b.ne	LBB66_470
; %bb.277:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x11, [x9]
	ldrb	w9, [x11, #32]
	ldr	w10, [x11, #36]
	cbz	w8, LBB66_314
; %bb.278:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [x11, #35]
	ldurh	w11, [x11, #33]
	orr	w8, w11, w8, lsl #16
	tst	w8, #0xff
	b.ne	LBB66_470
; %bb.279:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x16, [sp, #176]                 ; 8-byte Folded Reload
	ldrh	w11, [x16]
	ldr	x12, [x16, #8]
	ldrb	w13, [x16, #20]
	cmp	w9, #8
	mov	w17, #1                         ; =0x1
	b.ne	LBB66_309
; %bb.280:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x27, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	w14, [x8, #8]
	cmp	w14, w10
	b.ls	LBB66_470
; %bb.281:                              ;   in Loop: Header=BB66_190 Depth=1
	add	x14, x8, x10, lsl #2
	ldr	w14, [x14, #4120]
	cmp	w14, #1
	b.ne	LBB66_470
; %bb.282:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x8]
	add	x15, x8, x10, lsl #4
	ldrb	w8, [x15]
	cbnz	w8, LBB66_470
; %bb.283:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w8, [x15, #2]
	cmp	w8, #256
	b.hi	LBB66_470
; %bb.284:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w14, [x16, #16]
	cbz	w8, LBB66_289
; %bb.285:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x15, [x15, #8]
	add	x15, x15, #4
LBB66_286:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w16, [x15, #-4]
	cmp	w16, #4
	lsl	w16, w17, w16
	mov	w0, #22                         ; =0x16
	and	w16, w16, w0
	ccmp	w16, #0, #4, ls
	b.eq	LBB66_470
; %bb.287:                              ;   in Loop: Header=BB66_286 Depth=2
	ldr	w16, [x15], #12
	cmn	w16, #1
	b.ne	LBB66_470
; %bb.288:                              ;   in Loop: Header=BB66_286 Depth=2
	subs	x8, x8, #1
	b.ne	LBB66_286
LBB66_289:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #1                          ; =0x1
	cmp	w13, #1
	b.ne	LBB66_471
; %bb.290:                              ;   in Loop: Header=BB66_190 Depth=1
Lloh34:
	adrp	x13, l_.str.37@PAGE
Lloh35:
	add	x13, x13, l_.str.37@PAGEOFF
	cmp	w11, #256
	b.ne	LBB66_472
; %bb.291:                              ;   in Loop: Header=BB66_190 Depth=1
	cbnz	x12, LBB66_472
; %bb.292:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w14, w10
	b.eq	LBB66_314
	b	LBB66_472
LBB66_293:                              ;   in Loop: Header=BB66_190 Depth=1
	tbz	w8, #0, LBB66_480
; %bb.294:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w9, #40
	b.eq	LBB66_296
; %bb.295:                              ;   in Loop: Header=BB66_190 Depth=1
	tbnz	w3, #0, LBB66_490
LBB66_296:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x21, x17
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	x1, x25
	mov	w2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	mov	w5, #1                          ; =0x1
	bl	_mc_check
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	cbz	w0, LBB66_475
; %bb.297:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	x1, x25
	mov	w2, #1                          ; =0x1
	mov	x3, x27
	mov	w4, #0                          ; =0x0
	mov	w5, #1                          ; =0x1
	bl	_mc_check
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	cbz	w0, LBB66_475
; %bb.298:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	mov	w15, #16                        ; =0x10
	mov	x17, x21
	b	LBB66_248
LBB66_299:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x22, x17
	mov	w8, #24                         ; =0x18
	ldp	x0, x9, [sp, #168]              ; 16-byte Folded Reload
	umaddl	x26, w30, w8, x9
	mov	x1, x26
	bl	_mc_array
	tbz	w0, #0, LBB66_491
; %bb.300:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x17, x22
	sub	w8, w17, #83
	and	w8, w8, #0xff
	cmp	w8, #1
	b.hi	LBB66_304
; %bb.301:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [x26, #44]
	cbnz	w8, LBB66_492
; %bb.302:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x26, #32]
	cbnz	x8, LBB66_492
; %bb.303:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w8, [x26, #24]
	cmp	w8, #2
	b.ne	LBB66_492
LBB66_304:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w17, #83
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	b.gt	LBB66_328
; %bb.305:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w17, #81
	b.ne	LBB66_333
	b	LBB66_330
LBB66_306:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w30, w8, x9
	ldrb	w9, [x8, #20]
	cbnz	w9, LBB66_486
; %bb.307:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x9, [x8, #8]
	cbnz	x9, LBB66_486
; %bb.308:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w8, [x8]
	cmp	w8, #16
	b.eq	LBB66_358
	b	LBB66_486
LBB66_309:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #1                          ; =0x1
	cbnz	w13, LBB66_471
; %bb.310:                              ;   in Loop: Header=BB66_190 Depth=1
Lloh36:
	adrp	x13, l_.str.37@PAGE
Lloh37:
	add	x13, x13, l_.str.37@PAGEOFF
	cbnz	x12, LBB66_472
; %bb.311:                              ;   in Loop: Header=BB66_190 Depth=1
	cmn	w10, #1
	b.ne	LBB66_472
; %bb.312:                              ;   in Loop: Header=BB66_190 Depth=1
	lsl	w10, w8, w9
	and	w10, w10, #0xffff
	cmp	w11, w10
	b.ne	LBB66_472
; %bb.313:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w10, #-1                        ; =0xffffffff
LBB66_314:                              ;   in Loop: Header=BB66_190 Depth=1
	orr	x1, x9, x10, lsl #32
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_nvm_affine_can_exit_type
	tbz	w0, #0, LBB66_470
; %bb.315:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x0, [x24]
	bl	_nvm_affine_state_free
	ldr	x0, [x24, #8]
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	mov	w26, #24                        ; =0x18
	b	LBB66_257
LBB66_316:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w21, w30
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x12, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b.ls	LBB66_321
; %bb.317:                              ;   in Loop: Header=BB66_190 Depth=1
	sub	x8, x21, w30, uxtw
	mov	w10, #24                        ; =0x18
	umull	x9, w26, w10
	umaddl	x9, w30, w10, x9
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	add	x9, x10, x9
LBB66_318:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x10, [x9, #8]
	ldrb	w11, [x9, #20]
	cmp	w11, #0
	ccmp	x10, #0, #0, eq
	b.ne	LBB66_473
; %bb.319:                              ;   in Loop: Header=BB66_318 Depth=2
	ldrh	w10, [x9], #24
	cmp	w10, #8
	b.ne	LBB66_473
; %bb.320:                              ;   in Loop: Header=BB66_318 Depth=2
	subs	x8, x8, #1
	b.ne	LBB66_318
LBB66_321:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	ldrsh	x8, [x25, #80]
	mov	w9, #1                          ; =0x1
	lsl	x12, x9, x8
	mov	w15, #128                       ; =0x80
	b	LBB66_248
LBB66_322:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	mov	x27, x17
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	mov	x2, x22
	bl	_mc_owned_local
	mov	x1, x22
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #64]                  ; 8-byte Folded Reload
	cbz	w0, LBB66_481
; %bb.323:                              ;   in Loop: Header=BB66_190 Depth=1
	cbz	w21, LBB66_335
; %bb.324:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	umaddl	x8, w26, w8, x9
	add	x8, x8, #20
	b	LBB66_326
LBB66_325:                              ;   in Loop: Header=BB66_326 Depth=2
	add	x8, x8, #24
	subs	x21, x21, #1
	b.eq	LBB66_335
LBB66_326:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x8]
	cmp	w9, #2
	b.ne	LBB66_325
; %bb.327:                              ;   in Loop: Header=BB66_326 Depth=2
	ldurh	w9, [x8, #-18]
	cmp	w9, w1
	b.ne	LBB66_325
	b	LBB66_481
LBB66_328:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w17, #85
	b.eq	LBB66_386
; %bb.329:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w17, #84
	b.ne	LBB66_338
LBB66_330:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w21, w8, x9
	ldurb	w9, [x8, #-4]
	cbnz	w9, LBB66_494
; %bb.331:                              ;   in Loop: Header=BB66_190 Depth=1
	ldur	x9, [x8, #-16]
	cbnz	x9, LBB66_494
; %bb.332:                              ;   in Loop: Header=BB66_190 Depth=1
	ldurh	w8, [x8, #-24]
	cmp	w8, #8
	b.ne	LBB66_494
LBB66_333:                              ;   in Loop: Header=BB66_190 Depth=1
	cmp	w17, #83
	b.ne	LBB66_338
; %bb.334:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	mov	w15, #9                         ; =0x9
	b	LBB66_248
LBB66_335:                              ;   in Loop: Header=BB66_190 Depth=1
	add	x2, sp, #232
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_take_local
	tbz	w0, #0, LBB66_481
; %bb.336:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x17, x27
	cmp	w17, #11
	b.ne	LBB66_387
; %bb.337:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	ldr	w13, [sp, #236]
	strh	wzr, [sp, #208]
	mov	w15, #256                       ; =0x100
	mov	w22, #1                         ; =0x1
	strb	wzr, [sp, #210]
	b	LBB66_404
LBB66_338:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w15, [x26]
	ldrh	w27, [x26, #2]
	ldr	w14, [x26, #4]
	ldr	x12, [x26, #8]
	ldr	w13, [x26, #16]
	ldrb	w22, [x26, #20]
	ldurh	w8, [x26, #21]
	strh	w8, [sp, #208]
	ldrb	w8, [x26, #23]
	strb	w8, [sp, #210]
	b	LBB66_248
LBB66_339:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x26, x24
	tst	w26, #0xffff
	ldr	x14, [sp, #64]                  ; 8-byte Folded Reload
	mov	w15, #24                        ; =0x18
	mov	w16, #1                         ; =0x1
	ldr	x0, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b.eq	LBB66_344
; %bb.340:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x8, x26
	and	x8, x8, #0xffff
	add	x9, sp, #256
	mov	x10, x30
LBB66_341:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umaddl	x11, w10, w15, x0
	ldr	x12, [x11, #8]
	ldrb	w13, [x11, #20]
	cmp	w13, #0
	ccmp	x12, #0, #0, eq
	b.ne	LBB66_484
; %bb.342:                              ;   in Loop: Header=BB66_341 Depth=2
	ldrh	w11, [x11]
	ldrb	w12, [x9], #8
	lsl	w12, w16, w12
	cmp	w11, w12, uxth
	b.ne	LBB66_484
; %bb.343:                              ;   in Loop: Header=BB66_341 Depth=2
	add	w10, w10, #1
	subs	x8, x8, #1
	b.ne	LBB66_341
LBB66_344:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	ldr	w13, [x28]
	strh	wzr, [sp, #208]
	mov	w15, #256                       ; =0x100
	mov	w22, #1                         ; =0x1
	strb	wzr, [sp, #210]
	b	LBB66_248
LBB66_345:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w26, #24                        ; =0x18
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w21, w26, x8
	ldp	w9, w10, [x8, #-24]
	ldur	x11, [x8, #-16]
	ldur	w12, [x8, #-8]
	ldurb	w13, [x8, #-4]
	ldurh	w14, [x8, #-3]
	strh	w14, [sp, #208]
	ldurb	w14, [x8, #-1]
	strb	w14, [sp, #210]
	ldur	x14, [x8, #-32]
	stur	x14, [x8, #-8]
	ldur	q0, [x8, #-48]
	stur	q0, [x8, #-24]
	stp	w9, w10, [x8, #-48]
	stur	x11, [x8, #-40]
	stur	w12, [x8, #-32]
	sturb	w13, [x8, #-28]
	ldrh	w9, [sp, #208]
	ldrb	w10, [sp, #210]
	sturb	w10, [x8, #-25]
	sturh	w9, [x8, #-27]
	b	LBB66_360
LBB66_346:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w26, #24                        ; =0x18
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w21, w26, x8
	ldurb	w9, [x8, #-4]
	cbnz	w9, LBB66_501
; %bb.347:                              ;   in Loop: Header=BB66_190 Depth=1
	ldur	q0, [x8, #-24]
	str	q0, [x8]
	ldur	x9, [x8, #-8]
	str	x9, [x8, #16]
	add	w8, w21, #1
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	strh	w8, [x24, #16]
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB66_250
LBB66_348:                              ;   in Loop: Header=BB66_190 Depth=1
	str	x17, [sp, #8]                   ; 8-byte Folded Spill
	str	x19, [sp, #128]                 ; 8-byte Folded Spill
	ldr	x27, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x8, [x27]
	ldr	x8, [x8, #40]
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	add	x19, x8, x22, lsl #3
	ldr	w24, [x19, #4]
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
	mov	x0, x21
	mov	x1, x27
	mov	x2, x22
	bl	_mc_owned_local
	cbz	w0, LBB66_390
; %bb.349:                              ;   in Loop: Header=BB66_190 Depth=1
	add	x2, sp, #232
	add	x3, sp, #224
	mov	x0, x27
	mov	x1, x22
	bl	_nvm_affine_local_info
	cbz	w0, LBB66_506
; %bb.350:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [sp, #232]
	cmp	w8, #8
	b.ne	LBB66_506
; %bb.351:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [sp, #224]
	cbnz	w8, LBB66_506
; %bb.352:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	mov	w15, #256                       ; =0x100
	mov	w22, #2                         ; =0x2
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	x27, x8
	ldr	x19, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x17, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	mov	x13, x24
	b	LBB66_248
LBB66_353:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x21, x17
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #88]                  ; 8-byte Folded Reload
	mov	x1, x26
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	mov	x2, x22
	bl	_mc_owned_local
	cbz	w0, LBB66_495
; %bb.354:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldp	x0, x9, [sp, #168]              ; 16-byte Folded Reload
	ldr	x10, [sp, #104]                 ; 8-byte Folded Reload
	umaddl	x27, w10, w8, x9
	ldr	x8, [x26]
	ldr	x8, [x8, #40]
	ldr	x2, [x8, x22, lsl #3]
	mov	x1, x27
	bl	_mc_type
	cbz	w0, LBB66_495
; %bb.355:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w8, [x27, #16]
	mov	w9, #8                          ; =0x8
	orr	x2, x9, x8, lsl #32
	mov	x0, x26
	mov	x1, x22
	bl	_nvm_affine_put_local
	tbz	w0, #0, LBB66_495
; %bb.356:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	mov	x17, x21
	b	LBB66_404
LBB66_357:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w30, w8, x9
	ldrb	w8, [x8, #20]
	cbnz	w8, LBB66_499
LBB66_358:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	b	LBB66_248
LBB66_359:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w26, #24                        ; =0x18
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w21, w26, x8
	ldp	w9, w10, [x8, #-24]
	ldur	x11, [x8, #-16]
	ldur	w12, [x8, #-8]
	ldurb	w13, [x8, #-4]
	ldurh	w14, [x8, #-3]
	strh	w14, [sp, #208]
	ldurb	w14, [x8, #-1]
	strb	w14, [sp, #210]
	ldur	x14, [x8, #-32]
	stur	x14, [x8, #-8]
	ldur	q0, [x8, #-48]
	stur	q0, [x8, #-24]
	ldur	x14, [x8, #-56]
	stur	x14, [x8, #-32]
	ldur	q0, [x8, #-72]
	stur	q0, [x8, #-48]
	stp	w9, w10, [x8, #-72]
	stur	x11, [x8, #-64]
	stur	w12, [x8, #-56]
	sturb	w13, [x8, #-52]
	ldrh	w9, [sp, #208]
	ldrb	w10, [sp, #210]
	sturb	w10, [x8, #-49]
	sturh	w9, [x8, #-51]
LBB66_360:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB66_250
LBB66_361:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x8, w30, w8, x9
	ldrb	w9, [x8, #20]
	cbz	w9, LBB66_392
; %bb.362:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x21, x19
	cmp	w9, #2
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	b.ne	LBB66_496
; %bb.363:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x26, x17
	ldrh	w27, [x8, #2]
	ldr	w19, [x8, #16]
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	mov	x2, x27
	bl	_mc_owned_local
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	cbz	w0, LBB66_496
; %bb.364:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x9]
	ldr	x8, [x8, #40]
	add	x8, x8, x27, lsl #3
	ldr	w8, [x8, #4]
	cmp	w8, w19
	b.ne	LBB66_496
; %bb.365:                              ;   in Loop: Header=BB66_190 Depth=1
	add	x3, sp, #232
	mov	x0, x9
	mov	x1, x27
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_affine_scalar_field
	cbz	w0, LBB66_496
; %bb.366:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	ldrb	w8, [sp, #232]
	strh	wzr, [sp, #208]
	strb	wzr, [sp, #210]
	mov	w9, #1                          ; =0x1
	lsl	w15, w9, w8
	mov	x19, x21
	mov	x17, x26
	b	LBB66_404
LBB66_367:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x28, x17
	mov	x26, x19
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x8, [x1]
	ldr	x8, [x8, #40]
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	add	x19, x8, x2, lsl #3
	ldrb	w27, [x19]
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
	mov	x0, x21
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_mc_owned_local
	tbnz	w0, #0, LBB66_497
; %bb.368:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	w3, [x19, #4]
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #104]                 ; 8-byte Folded Reload
	umaddl	x19, w10, w8, x9
	mov	x0, x21
	mov	x1, x19
	mov	x2, x27
	bl	_mc_field
	tbz	w0, #0, LBB66_497
; %bb.369:                              ;   in Loop: Header=BB66_190 Depth=1
	sub	w8, w27, #1
	and	w8, w8, #0xff
	cmp	w8, #3
	b.hi	LBB66_371
; %bb.370:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_scalar_define
	tbz	w0, #0, LBB66_507
LBB66_371:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	ldr	q0, [x19]
	ldr	x8, [x19, #16]
	mov	w9, #24                         ; =0x18
	ldp	x10, x11, [sp, #40]             ; 16-byte Folded Reload
	umaddl	x9, w10, w9, x11
	str	x8, [x9, #16]
	str	q0, [x9]
	mov	x19, x26
	mov	x17, x28
	b	LBB66_404
LBB66_372:                              ;   in Loop: Header=BB66_190 Depth=1
	str	x17, [sp, #8]                   ; 8-byte Folded Spill
	str	x19, [sp, #128]                 ; 8-byte Folded Spill
	ldr	w8, [x28]
	mov	w9, #24                         ; =0x18
	umull	x8, w8, w9
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x9, x8]
	ldr	x19, [x8]
	ldrh	w21, [x19, #58]
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x27, [sp, #168]                 ; 8-byte Folded Reload
	cbz	x21, LBB66_376
; %bb.373:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x22, [x19, #40]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	mov	x26, x8
LBB66_374:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	umaddl	x1, w26, w8, x9
	ldr	x2, [x22], #8
	mov	x0, x27
	bl	_mc_type
	tbz	w0, #0, LBB66_485
; %bb.375:                              ;   in Loop: Header=BB66_374 Depth=2
	add	w26, w26, #1
	subs	x21, x21, #1
	b.ne	LBB66_374
LBB66_376:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w8, [x19, #32]
	cmp	w8, #8
	b.ne	LBB66_402
; %bb.377:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	ldr	w13, [x19, #36]
	strh	wzr, [sp, #208]
	mov	w15, #256                       ; =0x100
	mov	w22, #1                         ; =0x1
	strb	wzr, [sp, #210]
	b	LBB66_403
LBB66_378:                              ;   in Loop: Header=BB66_190 Depth=1
	str	x17, [sp, #8]                   ; 8-byte Folded Spill
	str	x19, [sp, #128]                 ; 8-byte Folded Spill
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x0, #8]
	ldr	x19, [x8]
	ldrsh	x24, [x25, #80]
	mov	w8, #24                         ; =0x18
	smaddl	x21, w24, w8, x19
	ldr	x8, [x19]
	ldr	x26, [x8]
	ldr	w27, [x21, #36]
	mov	x1, x27
	bl	_mc_owned_layout
	tbnz	w0, #0, LBB66_500
; %bb.379:                              ;   in Loop: Header=BB66_190 Depth=1
	ldurh	w22, [x21, #48]
	cbz	x22, LBB66_385
; %bb.380:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x19, #1568]
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	ldur	w28, [x21, #44]
	add	x8, x26, x27, lsl #4
	ldr	x8, [x8, #8]
	add	x19, x8, #4
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	mov	x27, x8
LBB66_381:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w8, #24                         ; =0x18
	ldp	x0, x9, [sp, #168]              ; 16-byte Folded Reload
	umaddl	x8, w27, w8, x9
	ldrh	w21, [x8]
	ldur	w9, [x8, #2]
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	str	w9, [x10]
	ldrh	w9, [x8, #6]
	strh	w9, [x10, #4]
	ldurb	w2, [x19, #-4]
	ldr	w3, [x19], #12
	strh	w21, [sp, #232]
	ldur	q0, [x8, #8]
	ldr	x26, [x8, #8]
	stur	q0, [sp, #240]
	add	x1, sp, #232
	bl	_mc_field
	cbz	w0, LBB66_483
; %bb.382:                              ;   in Loop: Header=BB66_381 Depth=2
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	add	x8, x8, w28, uxtw #4
	ldrh	w9, [x8]
	bics	wzr, w21, w9
	b.ne	LBB66_483
; %bb.383:                              ;   in Loop: Header=BB66_381 Depth=2
	ldr	x8, [x8, #8]
	bics	xzr, x26, x8
	b.ne	LBB66_483
; %bb.384:                              ;   in Loop: Header=BB66_381 Depth=2
	add	w27, w27, #1
	add	w28, w28, #1
	subs	x22, x22, #1
	b.ne	LBB66_381
LBB66_385:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	mov	w8, #1                          ; =0x1
	lsl	x12, x8, x24
	mov	w15, #256                       ; =0x100
	b	LBB66_403
LBB66_386:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	mov	w15, #2                         ; =0x2
	b	LBB66_248
LBB66_387:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x8, x24
	tst	w8, #0xffff
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
	mov	w26, #24                        ; =0x18
	mov	w12, #1                         ; =0x1
	ldr	x13, [sp, #176]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b.eq	LBB66_250
; %bb.388:                              ;   in Loop: Header=BB66_190 Depth=1
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	and	x8, x8, #0xffff
	add	x9, sp, #256
LBB66_389:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w10, [x24, #16]
	add	w11, w10, #1
	strh	w11, [x24, #16]
	umaddl	x10, w10, w26, x13
	ldrb	w11, [x9], #8
	lsl	w11, w12, w11
	strh	w11, [x10]
	stur	xzr, [x10, #10]
	stur	xzr, [x10, #2]
	str	xzr, [x10, #16]
	subs	x8, x8, #1
	b.ne	LBB66_389
	b	LBB66_250
LBB66_390:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrb	w2, [x19]
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	umaddl	x8, w22, w8, x9
	ldrh	w12, [x8]
	mov	x0, x21
	ldrh	w27, [x8, #2]
	ldr	w11, [x8, #4]
	ldr	x10, [x8, #8]
	ldr	w19, [x8, #16]
	ldrb	w22, [x8, #20]
	ldurh	w9, [x8, #21]
	strh	w9, [sp, #208]
	ldrb	w9, [x8, #23]
	strb	w9, [sp, #210]
	mov	x26, x12
	strh	w12, [sp, #232]
	strh	w27, [sp, #234]
	mov	x28, x11
	str	w11, [sp, #236]
	mov	x21, x10
	str	x10, [sp, #240]
	str	w19, [sp, #248]
	strb	w22, [sp, #252]
	ldurh	w9, [x8, #21]
	add	x10, sp, #232
	sturh	w9, [x10, #21]
	ldrb	w8, [x8, #23]
	sturb	w8, [x10, #23]
	add	x1, sp, #232
	mov	x3, x24
	bl	_mc_field
	tbz	w0, #0, LBB66_505
; %bb.391:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x13, x19
	ldr	x19, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x17, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	mov	x12, x21
	mov	x14, x28
	mov	x15, x26
	b	LBB66_248
LBB66_392:                              ;   in Loop: Header=BB66_190 Depth=1
	ldrh	w9, [x8]
	cmp	w9, #256
	b.ne	LBB66_509
; %bb.393:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [x8, #8]
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	cbz	x8, LBB66_509
; %bb.394:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x24, [x8]
	ldr	w8, [x24, #8]
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	cbz	w8, LBB66_358
; %bb.395:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	x26, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	add	x28, x24, #50
	b	LBB66_397
LBB66_396:                              ;   in Loop: Header=BB66_397 Depth=2
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	add	x26, x26, #1
	add	x28, x28, #24
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	cmp	x8, x26
	b.eq	LBB66_248
LBB66_397:                              ;   Parent Loop BB66_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	lsr	x8, x8, x26
	tbz	w8, #0, LBB66_396
; %bb.398:                              ;   in Loop: Header=BB66_397 Depth=2
	ldrb	w8, [x28]
	cmp	w8, #8
	b.ne	LBB66_487
; %bb.399:                              ;   in Loop: Header=BB66_397 Depth=2
	ldurh	w8, [x28, #-2]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	cmp	w9, w8
	b.hs	LBB66_487
; %bb.400:                              ;   in Loop: Header=BB66_397 Depth=2
	mov	x21, x15
	mov	x27, x12
	mov	x22, x17
	ldur	w1, [x28, #-14]
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	bl	_mc_owned_layout
	tbnz	w0, #0, LBB66_487
; %bb.401:                              ;   in Loop: Header=BB66_397 Depth=2
	ldr	x8, [x24, #1568]
	ldur	w9, [x28, #-6]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #4
	ldrh	w9, [x8]
	orr	w15, w9, w21
	ldr	x8, [x8, #8]
	orr	x12, x8, x27
	mov	x17, x22
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	b	LBB66_396
LBB66_402:                              ;   in Loop: Header=BB66_190 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	strb	wzr, [sp, #210]
	strh	wzr, [sp, #208]
	mov	w9, #1                          ; =0x1
	lsl	w15, w9, w8
LBB66_403:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x19, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x17, [sp, #8]                   ; 8-byte Folded Reload
LBB66_404:                              ;   in Loop: Header=BB66_190 Depth=1
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
	b	LBB66_248
LBB66_405:
	mov	x0, x27
	bl	_free
	mov	x0, x28
	bl	_free
	ldr	x0, [sp, #192]
	bl	_nvm_mixed_float_proof_free
Lloh38:
	adrp	x8, lCPI66_0@PAGE
Lloh39:
	ldr	q0, [x8, lCPI66_0@PAGEOFF]
	str	q0, [x19]
Lloh40:
	adrp	x8, l_.str.1@PAGE
Lloh41:
	add	x8, x8, l_.str.1@PAGEOFF
	str	x8, [x19, #16]
	b	LBB66_5
LBB66_406:
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
LBB66_407:
	mov	x0, x24
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #176]                 ; 8-byte Folded Reload
LBB66_408:
	mov	w27, #0                         ; =0x0
Lloh42:
	adrp	x10, l_.str.27@PAGE
Lloh43:
	add	x10, x10, l_.str.27@PAGEOFF
	mov	w8, #4                          ; =0x4
LBB66_409:
	stp	w8, w26, [x9, #12]
	stp	w27, wzr, [x9, #20]
	stur	x10, [x9, #28]
LBB66_410:
	ldp	x24, x22, [sp, #160]            ; 16-byte Folded Reload
	ldr	w8, [x24]
	cbz	w8, LBB66_415
; %bb.411:
	mov	x19, #0                         ; =0x0
	add	x21, x22, #296
	b	LBB66_413
LBB66_412:                              ;   in Loop: Header=BB66_413 Depth=1
	add	x19, x19, #1
	cmp	x19, x8
	b.hs	LBB66_415
LBB66_413:                              ; =>This Inner Loop Header: Depth=1
	ldr	x23, [x21], #104
	cbz	x23, LBB66_412
; %bb.414:                              ;   in Loop: Header=BB66_413 Depth=1
	ldr	x0, [x23]
	bl	_nvm_affine_state_free
	ldr	x0, [x23, #8]
	bl	_free
	mov	x0, x23
	bl	_free
	ldr	w8, [x24]
	b	LBB66_412
LBB66_415:
	ldr	w8, [x20, #272]
	cbz	w8, LBB66_418
; %bb.416:
	mov	x19, #0                         ; =0x0
	add	x21, x22, #24
LBB66_417:                              ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x21], #24
	bl	_nvm_affine_state_free
	add	x19, x19, #1
	ldr	w8, [x20, #272]
	cmp	x19, x8
	b.lo	LBB66_417
LBB66_418:
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w19, [x8]
	ldur	q0, [x8, #4]
	stur	q0, [x29, #-128]
	ldur	w8, [x8, #20]
	stur	w8, [x29, #-112]
	mov	x0, x22
	bl	_free
	cbz	w19, LBB66_420
; %bb.419:
	ldr	x0, [x28]
	bl	_nvm_mixed_float_proof_free
	mov	x0, x28
	bl	_free
	b	LBB66_421
LBB66_420:
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	str	x28, [x8]
LBB66_421:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	str	w19, [x9]
	ldur	q0, [x29, #-128]
	stur	q0, [x9, #4]
	ldur	w8, [x29, #-112]
	str	w8, [x9, #20]
	b	LBB66_5
LBB66_422:
	ldr	x6, [sp, #160]                  ; 8-byte Folded Reload
	ldr	w8, [x6]
	cbz	w8, LBB66_426
; %bb.423:
	add	x9, x27, #272
	mov	x10, x8
LBB66_424:                              ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x9, #24]
	cbz	x11, LBB66_459
; %bb.425:                              ;   in Loop: Header=BB66_424 Depth=1
	add	x9, x9, #104
	subs	x10, x10, #1
	b.ne	LBB66_424
LBB66_426:
	mov	w9, #34860                      ; =0x882c
	movk	w9, #2, lsl #16
	ldr	x10, [sp, #192]
	ldr	x11, [x10]
	ldr	w13, [x11, #8]
	ldr	x7, [sp, #120]                  ; 8-byte Folded Reload
	cbz	w13, LBB66_458
; %bb.427:
	mov	x12, #0                         ; =0x0
	mov	w14, #4120                      ; =0x1018
	add	x14, x11, x14
	add	x15, x10, #36
	mov	w16, #24                        ; =0x18
	b	LBB66_429
LBB66_428:                              ;   in Loop: Header=BB66_429 Depth=1
	add	x12, x12, #1
	cmp	x12, x13
	b.hs	LBB66_458
LBB66_429:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_442 Depth 2
                                        ;     Child Loop BB66_436 Depth 2
	ldr	w0, [x14, x12, lsl #2]
	cmp	w0, #2
	cset	w17, eq
	cmp	w0, #3
	b.ne	LBB66_438
; %bb.430:                              ;   in Loop: Header=BB66_429 Depth=1
	ldr	w0, [x10, #8]
	cbz	w0, LBB66_428
; %bb.431:                              ;   in Loop: Header=BB66_429 Depth=1
	cmp	w0, #8
	b.hs	LBB66_440
; %bb.432:                              ;   in Loop: Header=BB66_429 Depth=1
	mov	x1, #0                          ; =0x0
	mov	w17, #0                         ; =0x0
LBB66_433:                              ;   in Loop: Header=BB66_429 Depth=1
	and	x0, x0, #0x7
	cbz	x0, LBB66_438
; %bb.434:                              ;   in Loop: Header=BB66_429 Depth=1
	madd	x1, x1, x16, x15
	b	LBB66_436
LBB66_435:                              ;   in Loop: Header=BB66_436 Depth=2
	add	x1, x1, #24
	subs	x0, x0, #1
	b.eq	LBB66_438
LBB66_436:                              ;   Parent Loop BB66_429 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w2, [x1, #14]
	cmp	w2, #8
	b.ne	LBB66_435
; %bb.437:                              ;   in Loop: Header=BB66_436 Depth=2
	ldr	w2, [x1]
	cmp	x12, x2
	cset	w2, eq
	orr	w17, w2, w17
	b	LBB66_435
LBB66_438:                              ;   in Loop: Header=BB66_429 Depth=1
	tbz	w17, #0, LBB66_428
; %bb.439:                              ;   in Loop: Header=BB66_429 Depth=1
	ldr	w13, [x28, #40]
	str	w13, [x7, x12, lsl #2]
	add	w17, w13, #1
	str	w17, [x28, #40]
	str	w12, [x23, x13, lsl #2]
	ldr	w13, [x11, #8]
	b	LBB66_428
LBB66_440:                              ;   in Loop: Header=BB66_429 Depth=1
	mov	x2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w17, #0                         ; =0x0
	lsr	x3, x0, #3
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #6
	b	LBB66_442
LBB66_441:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x1, x1, #8
	add	x2, x2, #192
	cmp	x3, x2
	b.eq	LBB66_433
LBB66_442:                              ;   Parent Loop BB66_429 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x4, x10, x2
	ldrb	w5, [x4, #50]
	cmp	w5, #8
	b.ne	LBB66_444
; %bb.443:                              ;   in Loop: Header=BB66_442 Depth=2
	ldr	w5, [x4, #36]
	cmp	x12, x5
	cset	w5, eq
	orr	w17, w5, w17
LBB66_444:                              ;   in Loop: Header=BB66_442 Depth=2
	ldrb	w4, [x4, #74]
	cmp	w4, #8
	b.ne	LBB66_446
; %bb.445:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldr	w4, [x4, #60]
	cmp	x12, x4
	cset	w4, eq
	orr	w17, w4, w17
LBB66_446:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldrb	w5, [x4, #98]
	cmp	w5, #8
	b.ne	LBB66_448
; %bb.447:                              ;   in Loop: Header=BB66_442 Depth=2
	ldr	w5, [x4, #84]
	cmp	x12, x5
	cset	w5, eq
	orr	w17, w5, w17
LBB66_448:                              ;   in Loop: Header=BB66_442 Depth=2
	ldrb	w4, [x4, #122]
	cmp	w4, #8
	b.ne	LBB66_450
; %bb.449:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldr	w4, [x4, #108]
	cmp	x12, x4
	cset	w4, eq
	orr	w17, w4, w17
LBB66_450:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldrb	w5, [x4, #146]
	cmp	w5, #8
	b.ne	LBB66_452
; %bb.451:                              ;   in Loop: Header=BB66_442 Depth=2
	ldr	w5, [x4, #132]
	cmp	x12, x5
	cset	w5, eq
	orr	w17, w5, w17
LBB66_452:                              ;   in Loop: Header=BB66_442 Depth=2
	ldrb	w4, [x4, #170]
	cmp	w4, #8
	b.ne	LBB66_454
; %bb.453:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldr	w4, [x4, #156]
	cmp	x12, x4
	cset	w4, eq
	orr	w17, w4, w17
LBB66_454:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldrb	w5, [x4, #194]
	cmp	w5, #8
	b.ne	LBB66_456
; %bb.455:                              ;   in Loop: Header=BB66_442 Depth=2
	ldr	w5, [x4, #180]
	cmp	x12, x5
	cset	w5, eq
	orr	w17, w5, w17
LBB66_456:                              ;   in Loop: Header=BB66_442 Depth=2
	ldrb	w4, [x4, #218]
	cmp	w4, #8
	b.ne	LBB66_441
; %bb.457:                              ;   in Loop: Header=BB66_442 Depth=2
	add	x4, x10, x2
	ldr	w4, [x4, #204]
	cmp	x12, x4
	cset	w4, eq
	orr	w17, w4, w17
	b	LBB66_441
LBB66_458:
	ldr	w10, [x20, #272]
	stp	w10, w8, [x28, #8]
	ldr	w8, [x6, #8]
	mov	w10, #1                         ; =0x1
	strb	w10, [x28, x9]
	str	w8, [x28, #16]
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	stp	xzr, xzr, [x8]
Lloh44:
	adrp	x8, l_.str.6@PAGE
Lloh45:
	add	x8, x8, l_.str.6@PAGEOFF
	stur	x8, [x19, #28]
	b	LBB66_410
LBB66_459:
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #12]
	ldr	d0, [x9]
	str	d0, [x19, #16]
	str	wzr, [x19, #24]
Lloh46:
	adrp	x8, l_.str.5@PAGE
Lloh47:
	add	x8, x8, l_.str.5@PAGEOFF
	stur	x8, [x19, #28]
	b	LBB66_410
LBB66_460:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w22, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh48:
	adrp	x8, l_.str.40@PAGE
Lloh49:
	add	x8, x8, l_.str.40@PAGEOFF
	b	LBB66_474
LBB66_461:
	mov	w8, #1                          ; =0x1
Lloh50:
	adrp	x13, l_.str.36@PAGE
Lloh51:
	add	x13, x13, l_.str.36@PAGEOFF
	b	LBB66_472
LBB66_462:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w22, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh52:
	adrp	x8, l_.str.41@PAGE
Lloh53:
	add	x8, x8, l_.str.41@PAGEOFF
	b	LBB66_474
LBB66_463:
	mov	x0, x24
	bl	_free
LBB66_464:
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	b	LBB66_408
LBB66_465:
Lloh54:
	adrp	x8, lCPI66_2@PAGE
Lloh55:
	ldr	q0, [x8, lCPI66_2@PAGEOFF]
	stur	q0, [x19, #12]
Lloh56:
	adrp	x8, l_.str.3@PAGE
Lloh57:
	add	x8, x8, l_.str.3@PAGEOFF
	stur	x8, [x19, #28]
	b	LBB66_410
LBB66_466:
	ldr	w8, [x25, #68]
	mov	w9, #4                          ; =0x4
	stp	w9, w22, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh58:
	adrp	x8, l_.str.4@PAGE
Lloh59:
	add	x8, x8, l_.str.4@PAGEOFF
	stur	x8, [x19, #28]
	b	LBB66_410
LBB66_467:
	mov	w8, #2                          ; =0x2
	b	LBB66_472
LBB66_468:
	mov	w8, #3                          ; =0x3
Lloh60:
	adrp	x13, l_.str.39@PAGE
Lloh61:
	add	x13, x13, l_.str.39@PAGEOFF
	b	LBB66_472
LBB66_469:
	mov	w8, #3                          ; =0x3
	stp	w8, w12, [x19, #12]
	stp	w15, wzr, [x19, #20]
Lloh62:
	adrp	x8, l_.str.65@PAGE
Lloh63:
	add	x8, x8, l_.str.65@PAGEOFF
	b	LBB66_474
LBB66_470:
	mov	w8, #1                          ; =0x1
LBB66_471:
Lloh64:
	adrp	x13, l_.str.37@PAGE
Lloh65:
	add	x13, x13, l_.str.37@PAGEOFF
LBB66_472:
	ldr	w9, [x25, #68]
	stp	w8, w22, [x19, #12]
	stp	w9, wzr, [x19, #20]
	stur	x13, [x19, #28]
	ldr	x0, [x24]
	bl	_nvm_affine_state_free
	ldr	x0, [x24, #8]
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	b	LBB66_410
LBB66_473:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w12, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh66:
	adrp	x8, l_.str.58@PAGE
Lloh67:
	add	x8, x8, l_.str.58@PAGEOFF
LBB66_474:
	stur	x8, [x19, #28]
LBB66_475:
	ldr	x0, [x24]
	bl	_nvm_affine_state_free
	ldr	x0, [x24, #8]
	bl	_free
	mov	x0, x24
	bl	_free
	b	LBB66_410
LBB66_476:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
Lloh68:
	adrp	x10, l_.str.28@PAGE
Lloh69:
	add	x10, x10, l_.str.28@PAGEOFF
LBB66_477:
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	b	LBB66_409
LBB66_478:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
LBB66_479:
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
Lloh70:
	adrp	x10, l_.str.29@PAGE
Lloh71:
	add	x10, x10, l_.str.29@PAGEOFF
	b	LBB66_409
LBB66_480:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w11, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh72:
	adrp	x8, l_.str.42@PAGE
Lloh73:
	add	x8, x8, l_.str.42@PAGEOFF
	b	LBB66_482
LBB66_481:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w22, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh74:
	adrp	x8, l_.str.50@PAGE
Lloh75:
	add	x8, x8, l_.str.50@PAGEOFF
LBB66_482:
	stur	x8, [x19, #28]
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB66_475
LBB66_483:
	ldr	w8, [x25, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10, #12]
	stp	w8, wzr, [x10, #20]
Lloh76:
	adrp	x8, l_.str.54@PAGE
Lloh77:
	add	x8, x8, l_.str.54@PAGEOFF
	stur	x8, [x10, #28]
	b	LBB66_511
LBB66_484:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w14, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh78:
	adrp	x8, l_.str.52@PAGE
Lloh79:
	add	x8, x8, l_.str.52@PAGEOFF
	stur	x8, [x19, #28]
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	b	LBB66_475
LBB66_485:
	ldr	w8, [x25, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10, #12]
	stp	w8, wzr, [x10, #20]
Lloh80:
	adrp	x8, l_.str.62@PAGE
Lloh81:
	add	x8, x8, l_.str.62@PAGEOFF
	stur	x8, [x10, #28]
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB66_475
LBB66_486:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh82:
	adrp	x8, l_.str.63@PAGE
Lloh83:
	add	x8, x8, l_.str.63@PAGEOFF
	b	LBB66_510
LBB66_487:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh84:
	adrp	x8, l_.str.57@PAGE
Lloh85:
	add	x8, x8, l_.str.57@PAGEOFF
	b	LBB66_510
LBB66_488:
	mov	w8, #1                          ; =0x1
Lloh86:
	adrp	x10, l_.str.21@PAGE
Lloh87:
	add	x10, x10, l_.str.21@PAGEOFF
LBB66_489:
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #176]                 ; 8-byte Folded Reload
	b	LBB66_409
LBB66_490:
	ldr	w8, [x25, #68]
	mov	w9, #1                          ; =0x1
	stp	w9, w11, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh88:
	adrp	x8, l_.str.43@PAGE
Lloh89:
	add	x8, x8, l_.str.43@PAGEOFF
	b	LBB66_482
LBB66_491:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh90:
	adrp	x8, l_.str.59@PAGE
Lloh91:
	add	x8, x8, l_.str.59@PAGEOFF
	b	LBB66_510
LBB66_492:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh92:
	adrp	x8, l_.str.60@PAGE
Lloh93:
	add	x8, x8, l_.str.60@PAGEOFF
	b	LBB66_510
LBB66_493:
	mov	w27, #0                         ; =0x0
	mov	w8, #2                          ; =0x2
Lloh94:
	adrp	x10, l_.str.14@PAGE
Lloh95:
	add	x10, x10, l_.str.14@PAGEOFF
	b	LBB66_477
LBB66_494:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh96:
	adrp	x8, l_.str.61@PAGE
Lloh97:
	add	x8, x8, l_.str.61@PAGEOFF
	b	LBB66_510
LBB66_495:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh98:
	adrp	x8, l_.str.51@PAGE
Lloh99:
	add	x8, x8, l_.str.51@PAGEOFF
	b	LBB66_510
LBB66_496:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x21, #12]
	stp	w8, wzr, [x21, #20]
Lloh100:
	adrp	x8, l_.str.55@PAGE
Lloh101:
	add	x8, x8, l_.str.55@PAGEOFF
	stur	x8, [x21, #28]
	b	LBB66_511
LBB66_497:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26, #12]
	stp	w8, wzr, [x26, #20]
Lloh102:
	adrp	x8, l_.str.48@PAGE
Lloh103:
	add	x8, x8, l_.str.48@PAGEOFF
	stur	x8, [x26, #28]
	b	LBB66_511
LBB66_498:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh104:
	adrp	x8, l_.str.64@PAGE
Lloh105:
	add	x8, x8, l_.str.64@PAGEOFF
	b	LBB66_510
LBB66_499:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh106:
	adrp	x8, l_.str.45@PAGE
Lloh107:
	add	x8, x8, l_.str.45@PAGEOFF
	b	LBB66_510
LBB66_500:
	ldr	w8, [x25, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10, #12]
	stp	w8, wzr, [x10, #20]
Lloh108:
	adrp	x8, l_.str.53@PAGE
Lloh109:
	add	x8, x8, l_.str.53@PAGEOFF
	stur	x8, [x10, #28]
	b	LBB66_511
LBB66_501:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh110:
	adrp	x8, l_.str.44@PAGE
Lloh111:
	add	x8, x8, l_.str.44@PAGEOFF
	b	LBB66_510
LBB66_502:
	mov	w8, #3                          ; =0x3
Lloh112:
	adrp	x10, l_.str.15@PAGE
Lloh113:
	add	x10, x10, l_.str.15@PAGEOFF
	b	LBB66_477
LBB66_503:
	mov	w8, #2                          ; =0x2
Lloh114:
	adrp	x10, l_.str.16@PAGE
Lloh115:
	add	x10, x10, l_.str.16@PAGEOFF
	b	LBB66_489
LBB66_504:
	mov	w8, #2                          ; =0x2
Lloh116:
	adrp	x10, l_.str.23@PAGE
Lloh117:
	add	x10, x10, l_.str.23@PAGEOFF
	b	LBB66_489
LBB66_505:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x26, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26, #12]
	stp	w8, wzr, [x26, #20]
Lloh118:
	adrp	x8, l_.str.47@PAGE
Lloh119:
	add	x8, x8, l_.str.47@PAGEOFF
	stur	x8, [x26, #28]
	b	LBB66_511
LBB66_506:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x26, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26, #12]
	stp	w8, wzr, [x26, #20]
Lloh120:
	adrp	x8, l_.str.46@PAGE
Lloh121:
	add	x8, x8, l_.str.46@PAGEOFF
	stur	x8, [x26, #28]
	b	LBB66_511
LBB66_507:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26, #12]
	stp	w8, wzr, [x26, #20]
Lloh122:
	adrp	x8, l_.str.49@PAGE
Lloh123:
	add	x8, x8, l_.str.49@PAGEOFF
	stur	x8, [x26, #28]
	b	LBB66_511
LBB66_508:
	mov	w8, #2                          ; =0x2
Lloh124:
	adrp	x10, l_.str.19@PAGE
Lloh125:
	add	x10, x10, l_.str.19@PAGEOFF
	b	LBB66_489
LBB66_509:
	ldr	w8, [x25, #68]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	w10, w9, [x19, #12]
	stp	w8, wzr, [x19, #20]
Lloh126:
	adrp	x8, l_.str.56@PAGE
Lloh127:
	add	x8, x8, l_.str.56@PAGEOFF
LBB66_510:
	stur	x8, [x19, #28]
LBB66_511:
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB66_475
LBB66_512:
	mov	w27, #0                         ; =0x0
	b	LBB66_479
LBB66_513:
	mov	w8, #1                          ; =0x1
Lloh128:
	adrp	x10, l_.str.22@PAGE
Lloh129:
	add	x10, x10, l_.str.22@PAGEOFF
	b	LBB66_489
LBB66_514:
	mov	w8, #2                          ; =0x2
Lloh130:
	adrp	x10, l_.str.20@PAGE
Lloh131:
	add	x10, x10, l_.str.20@PAGEOFF
	b	LBB66_489
LBB66_515:
	mov	w8, #1                          ; =0x1
Lloh132:
	adrp	x10, l_.str.24@PAGE
Lloh133:
	add	x10, x10, l_.str.24@PAGEOFF
	b	LBB66_489
LBB66_516:
	mov	w8, #2                          ; =0x2
Lloh134:
	adrp	x10, l_.str.18@PAGE
Lloh135:
	add	x10, x10, l_.str.18@PAGEOFF
	b	LBB66_489
LBB66_517:
Lloh136:
	adrp	x10, l_.str.25@PAGE
Lloh137:
	add	x10, x10, l_.str.25@PAGEOFF
	mov	w8, #2                          ; =0x2
	b	LBB66_520
LBB66_518:
	bl	___stack_chk_fail
LBB66_519:
	ldr	w27, [x12, #68]
Lloh138:
	adrp	x10, l_.str.26@PAGE
Lloh139:
	add	x10, x10, l_.str.26@PAGEOFF
	mov	w8, #1                          ; =0x1
LBB66_520:
	mov	x26, x24
	b	LBB66_477
LBB66_521:
Lloh140:
	adrp	x10, l_.str.17@PAGE
Lloh141:
	add	x10, x10, l_.str.17@PAGEOFF
	mov	w8, #1                          ; =0x1
	b	LBB66_489
	.loh AdrpLdrGotLdr	Lloh16, Lloh17, Lloh18
	.loh AdrpAdd	Lloh19, Lloh20
	.loh AdrpLdrGotLdr	Lloh21, Lloh22, Lloh23
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh108, Lloh109
	.loh AdrpAdd	Lloh110, Lloh111
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpLdrGot	Lloh14, Lloh15
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI66_0:
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_521-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.short	(LBB66_114-LBB66_114)>>2
	.p2align	1, 0x0
lJTI66_1:
	.short	(LBB66_248-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_346-LBB66_248)>>2
	.short	(LBB66_357-LBB66_248)>>2
	.short	(LBB66_345-LBB66_248)>>2
	.short	(LBB66_359-LBB66_248)>>2
	.short	(LBB66_322-LBB66_248)>>2
	.short	(LBB66_353-LBB66_248)>>2
	.short	(LBB66_339-LBB66_248)>>2
	.short	(LBB66_322-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_348-LBB66_248)>>2
	.short	(LBB66_367-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_260-LBB66_248)>>2
	.short	(LBB66_260-LBB66_248)>>2
	.short	(LBB66_260-LBB66_248)>>2
	.short	(LBB66_260-LBB66_248)>>2
	.short	(LBB66_260-LBB66_248)>>2
	.short	(LBB66_260-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_248-LBB66_248)>>2
	.short	(LBB66_306-LBB66_248)>>2
	.short	(LBB66_306-LBB66_248)>>2
	.short	(LBB66_372-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_316-LBB66_248)>>2
	.short	(LBB66_299-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_299-LBB66_248)>>2
	.short	(LBB66_299-LBB66_248)>>2
	.short	(LBB66_299-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_316-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_306-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_498-LBB66_248)>>2
	.short	(LBB66_378-LBB66_248)>>2
	.short	(LBB66_361-LBB66_248)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function mc_owned_local
_mc_owned_local:                        ; @mc_owned_local
	.cfi_startproc
; %bb.0:
	ldr	x8, [x1]
	ldrh	w9, [x8, #56]
	cmp	w2, w9
	b.hs	LBB67_7
; %bb.1:
	ldr	x8, [x8, #40]
	add	x8, x8, w2, uxtw #3
	ldrb	w9, [x8, #1]
	cbnz	w9, LBB67_7
; %bb.2:
	ldrb	w9, [x8]
	cmp	w9, #8
	b.ne	LBB67_7
; %bb.3:
	ldr	w8, [x8, #4]
	ldr	x9, [x0, #8]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	w10, [x9, #8]
	cmp	w8, w10
	b.hs	LBB67_7
; %bb.4:
	add	x10, x9, x8, lsl #2
	ldr	w10, [x10, #4120]
	cmp	w10, #1
	b.ne	LBB67_7
; %bb.5:
	ldr	x9, [x9]
	add	x10, x9, x8, lsl #4
	ldrb	w8, [x10]
	cbnz	w8, LBB67_7
; %bb.6:
	ldrh	w8, [x10, #2]
	cmp	w8, #256
	b.ls	LBB67_9
LBB67_7:
	mov	w0, #0                          ; =0x0
LBB67_8:
	ret
LBB67_9:
	mov	w9, #1                          ; =0x1
	cbz	w8, LBB67_14
; %bb.10:
	ldr	x10, [x10, #8]
	add	x10, x10, #4
	mov	w11, #22                        ; =0x16
	mov	w0, #1                          ; =0x1
LBB67_11:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-4]
	cmp	w12, #4
	lsl	w12, w9, w12
	and	w12, w12, w11
	ccmp	w12, #0, #4, ls
	b.eq	LBB67_7
; %bb.12:                               ;   in Loop: Header=BB67_11 Depth=1
	ldr	w12, [x10], #12
	cmn	w12, #1
	b.ne	LBB67_7
; %bb.13:                               ;   in Loop: Header=BB67_11 Depth=1
	subs	x8, x8, #1
	b.ne	LBB67_11
	b	LBB67_8
LBB67_14:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_join
_mc_join:                               ; @mc_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	add	x8, x0, #108, lsl #12           ; =442368
	add	x20, x8, #224
	mov	w8, #104                        ; =0x68
	umaddl	x9, w1, w8, x0
	add	x21, x9, #208
	ldr	x8, [x0]
	ldr	x10, [x8, #256]
	ldr	w8, [x9, #272]
	mov	w11, #24                        ; =0x18
	umaddl	x10, w8, w11, x10
	ldrh	w19, [x10, #16]
	strb	wzr, [sp, #15]
	ldr	x22, [x9, #296]
	cbz	x22, LBB68_8
; %bb.1:
	ldrh	w9, [x22, #16]
	ldrh	w10, [x2, #16]
	cmp	w9, w10
	b.ne	LBB68_10
; %bb.2:
	adds	w9, w9, w19
	b.eq	LBB68_11
; %bb.3:
	ldr	x10, [x22, #8]
	ldr	x11, [x2, #8]
	add	x10, x10, #16
	add	x11, x11, #16
	b	LBB68_5
LBB68_4:                                ;   in Loop: Header=BB68_5 Depth=1
	add	x10, x10, #24
	add	x11, x11, #24
	subs	x9, x9, #1
	b.eq	LBB68_11
LBB68_5:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x10, #4]
	ldrb	w13, [x11, #4]
	and	w13, w13, #0xff
	orr	w14, w12, w13
	cbz	w14, LBB68_4
; %bb.6:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	w14, [x11]
	ldurh	w15, [x11, #-14]
	ldurh	w16, [x11, #-16]
	ldr	w17, [x10]
	ldurh	w3, [x10, #-14]
	ldurh	w4, [x10, #-16]
	cmp	w12, w13
	ccmp	w4, w16, #0, eq
	ccmp	w17, w14, #0, eq
	ccmp	w3, w15, #0, eq
	b.eq	LBB68_4
; %bb.7:
	mov	w0, #0                          ; =0x0
	ldr	w9, [x21, #68]
	mov	w10, #1                         ; =0x1
	stp	w10, w8, [x20, #8]
	stp	w9, wzr, [x20, #16]
Lloh142:
	adrp	x8, l_.str.34@PAGE
Lloh143:
	add	x8, x8, l_.str.34@PAGEOFF
	b	LBB68_23
LBB68_8:
	mov	w22, #32980                     ; =0x80d4
	movk	w22, #6, lsl #16
	add	w23, w19, #256
	ldr	w9, [x0, x22]
	mov	w10, #1048576                   ; =0x100000
	sub	w9, w10, w9
	cmp	w23, w9
	b.ls	LBB68_17
; %bb.9:
	mov	w0, #0                          ; =0x0
	ldr	w9, [x21, #68]
	mov	w10, #3                         ; =0x3
	stp	w10, w8, [x20, #8]
	stp	w9, wzr, [x20, #16]
Lloh144:
	adrp	x8, l_.str.31@PAGE
Lloh145:
	add	x8, x8, l_.str.31@PAGEOFF
	b	LBB68_23
LBB68_10:
	mov	w0, #0                          ; =0x0
	ldr	w9, [x21, #68]
	mov	w10, #2                         ; =0x2
	stp	w10, w8, [x20, #8]
	stp	w9, wzr, [x20, #16]
Lloh146:
	adrp	x8, l_.str.33@PAGE
Lloh147:
	add	x8, x8, l_.str.33@PAGEOFF
	b	LBB68_23
LBB68_11:
	mov	x24, x0
	mov	x25, x1
	ldr	x0, [x22]
	mov	x23, x2
	ldr	x1, [x2]
	add	x2, sp, #15
	bl	_nvm_affine_state_meet_initialization
	cbz	w0, LBB68_21
; %bb.12:
	ldrh	w8, [x22, #16]
	ldrb	w10, [sp, #15]
	adds	w11, w8, w19
	mov	x8, x25
	mov	x9, x24
	b.eq	LBB68_15
; %bb.13:
	ldr	x12, [x22, #8]
	ldr	x13, [x23, #8]
	add	x12, x12, #8
	add	x13, x13, #8
LBB68_14:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w14, [x13, #-8]
	ldr	x15, [x13], #24
	ldurh	w16, [x12, #-8]
	ldr	x17, [x12]
	orr	w14, w16, w14
	orr	x15, x17, x15
	cmp	w16, w14, uxth
	ccmp	x17, x15, #0, eq
	cset	w16, ne
	sturh	w14, [x12, #-8]
	str	x15, [x12], #24
	orr	w10, w10, w16
	subs	x11, x11, #1
	b.ne	LBB68_14
LBB68_15:
	tbnz	w10, #0, LBB68_19
; %bb.16:
	mov	w0, #1                          ; =0x1
	b	LBB68_24
LBB68_17:
	mov	x25, x0
	mov	x24, x1
	mov	x0, x2
	mov	x1, x19
	bl	_mc_frame_clone
	str	x0, [x21, #88]
	cbz	x0, LBB68_22
; %bb.18:
	mov	x9, x25
	ldr	w8, [x25, x22]
	add	w8, w8, w23
	str	w8, [x25, x22]
	mov	x8, x24
LBB68_19:
	mov	w10, w8
	mov	w11, #104                       ; =0x68
	umull	x10, w10, w11
	add	x11, x9, #304
	ldrb	w12, [x11, x10]
	mov	w0, #1                          ; =0x1
	tbnz	w12, #0, LBB68_24
; %bb.20:
	strb	w0, [x11, x10]
	ldr	w10, [x20]
	add	x9, x9, x10, lsl #2
	mov	w10, #32988                     ; =0x80dc
	movk	w10, #6, lsl #16
	str	w8, [x9, x10]
	ldp	w8, w9, [x20]
	add	w8, w8, #1
	and	w8, w8, #0xfff
	add	w9, w9, #1
	stp	w8, w9, [x20]
	b	LBB68_24
LBB68_21:
	mov	w8, #1                          ; =0x1
	str	w8, [x20, #8]
	ldr	d0, [x21, #64]
	stur	d0, [x20, #12]
	str	wzr, [x20, #20]
Lloh148:
	adrp	x8, l_.str.35@PAGE
Lloh149:
	add	x8, x8, l_.str.35@PAGEOFF
	b	LBB68_23
LBB68_22:
	mov	w8, #4                          ; =0x4
	str	w8, [x20, #8]
	ldr	d0, [x21, #64]
	stur	d0, [x20, #12]
	str	wzr, [x20, #20]
Lloh150:
	adrp	x8, l_.str.32@PAGE
Lloh151:
	add	x8, x8, l_.str.32@PAGEOFF
LBB68_23:
	str	x8, [x20, #24]
LBB68_24:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_frame_clone
_mc_frame_clone:                        ; @mc_frame_clone
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #24                         ; =0x18
	bl	_calloc
	mov	x19, x0
	cbz	x0, LBB69_4
; %bb.1:
	ldr	x0, [x21]
	bl	_nvm_affine_state_clone
	mov	x22, x0
	str	x0, [x19]
	add	w0, w20, #256
	mov	w1, #24                         ; =0x18
	bl	_calloc
	str	x0, [x19, #8]
	cmp	x22, #0
	ccmp	x0, #0, #4, ne
	b.ne	LBB69_3
; %bb.2:
	mov	x20, x0
	mov	x0, x22
	bl	_nvm_affine_state_free
	mov	x0, x20
	bl	_free
	mov	x0, x19
	bl	_free
	mov	x19, #0                         ; =0x0
	b	LBB69_4
LBB69_3:
	ldrh	w8, [x21, #16]
	strh	w8, [x19, #16]
	ldr	x1, [x21, #8]
	add	w8, w8, w20
	add	w8, w8, w8, lsl #1
	lsl	w2, w8, #3
	bl	_memcpy
LBB69_4:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_lifetime_facts_free ; -- Begin function nvm_owned_array_lifetime_facts_free
	.globl	_nvm_owned_array_lifetime_facts_free
	.p2align	2
_nvm_owned_array_lifetime_facts_free:   ; @nvm_owned_array_lifetime_facts_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB70_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_owned_array_origins_free
	ldr	x0, [x19, #8]
	bl	_nvm_owned_array_layouts_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB70_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_analyze_owned_array_lifetimes
lCPI71_0:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI71_1:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI71_2:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_analyze_owned_array_lifetimes
	.globl	_nvm_analyze_owned_array_lifetimes
	.p2align	2
_nvm_analyze_owned_array_lifetimes:     ; @nvm_analyze_owned_array_lifetimes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #6496                       ; =0x1960
Lloh152:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh153:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2400
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
Lloh154:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh155:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh156:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x1, LBB71_5
; %bb.1:
	mov	x20, x0
	str	x1, [sp, #176]                  ; 8-byte Folded Spill
	str	xzr, [sp, #240]
	add	x8, sp, #216
	add	x1, sp, #240
	bl	_nvm_analyze_owned_array_origins
	ldr	w8, [sp, #216]
	sub	w9, w8, #2
	cmp	w9, #3
	b.lo	LBB71_7
; %bb.2:
	cbnz	w8, LBB71_6
; %bb.3:
	str	xzr, [sp, #208]
	add	x8, sp, #184
	add	x1, sp, #208
	mov	x0, x20
	bl	_nvm_describe_owned_array_layouts
	ldr	w8, [sp, #184]
	cbz	w8, LBB71_11
; %bb.4:
	ldr	x0, [sp, #240]
	bl	_nvm_owned_array_origins_free
	ldr	w8, [sp, #184]
	sub	w9, w8, #3
	cmp	w8, #2
	mov	w10, #1                         ; =0x1
	cinc	w10, w10, eq
	cmp	w9, #2
	csel	w8, w8, w10, lo
	stp	w8, wzr, [x19]
	str	xzr, [x19, #8]
	ldr	x8, [sp, #200]
	b	LBB71_8
LBB71_5:
Lloh157:
	adrp	x8, l___const.nvm_analyze_owned_array_lifetimes.invalid@PAGE
Lloh158:
	add	x8, x8, l___const.nvm_analyze_owned_array_lifetimes.invalid@PAGEOFF
	ldr	q0, [x8]
	str	q0, [x19]
	ldr	x8, [x8, #16]
	b	LBB71_8
LBB71_6:
	mov	w8, #1                          ; =0x1
LBB71_7:
	str	w8, [x19]
	ldur	d0, [sp, #220]
	stur	d0, [x19, #4]
	str	wzr, [x19, #12]
	ldr	x8, [sp, #232]
LBB71_8:
	str	x8, [x19, #16]
LBB71_9:
	ldur	x8, [x29, #-96]
Lloh159:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh160:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh161:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB71_396
; %bb.10:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2400
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB71_11:
	mov	w0, #1                          ; =0x1
	mov	w1, #49352                      ; =0xc0c8
	movk	w1, #6, lsl #16
	bl	_calloc
	mov	x25, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #9160                       ; =0x23c8
	movk	w1, #2, lsl #16
	bl	_calloc
	mov	x21, x0
	cbz	x25, LBB71_131
; %bb.12:
	cbz	x21, LBB71_131
; %bb.13:
	add	x8, x25, #108, lsl #12          ; =442368
	add	x27, x8, #160
	add	x8, x25, #104, lsl #12          ; =425984
	add	x26, x8, #144
	ldr	x0, [sp, #240]
	ldr	x8, [sp, #208]
	stp	x0, x8, [x21]
	stp	x20, x21, [x25]
Lloh162:
	adrp	x8, l___const.nvm_analyze_owned_array_lifetimes.invalid@PAGE
Lloh163:
	add	x8, x8, l___const.nvm_analyze_owned_array_lifetimes.invalid@PAGEOFF
	ldr	q0, [x8]
	str	q0, [x27, #16]
	ldr	x8, [x8, #16]
	str	x8, [x27, #32]
	add	x1, sp, #252
	bl	_nvm_owned_array_origin_counts
	ldr	x22, [x25]
	ldr	w8, [x22, #272]
	stp	x21, x26, [sp, #136]            ; 16-byte Folded Spill
	stp	x27, x25, [sp, #152]            ; 16-byte Folded Spill
	cbz	w8, LBB71_134
; %bb.14:
	str	xzr, [sp, #168]                 ; 8-byte Folded Spill
	add	x9, x25, #24
	add	x28, x25, #16
	add	x24, x25, #144
	mov	w8, #964                        ; =0x3c4
	stp	x8, x9, [sp, #104]              ; 16-byte Folded Spill
	mov	w8, #56                         ; =0x38
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
Lloh164:
	adrp	x8, l_.str.73@PAGE
Lloh165:
	add	x9, x8, l_.str.73@PAGEOFF
Lloh166:
	adrp	x8, l_.str.75@PAGE
Lloh167:
	add	x8, x8, l_.str.75@PAGEOFF
	stp	x9, x8, [sp, #80]               ; 16-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #120]                  ; 4-byte Folded Spill
LBB71_15:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB71_26 Depth 2
                                        ;       Child Loop BB71_43 Depth 3
                                        ;     Child Loop BB71_67 Depth 2
                                        ;       Child Loop BB71_76 Depth 3
                                        ;     Child Loop BB71_89 Depth 2
                                        ;     Child Loop BB71_116 Depth 2
	ldr	x21, [x22, #256]
	mov	w0, #1                          ; =0x1
	mov	w1, #200                        ; =0xc8
	bl	_calloc
	cbz	x0, LBB71_133
; %bb.16:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	x23, x0
	str	x24, [sp, #72]                  ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #80                         ; =0x50
	bl	_calloc
	str	x0, [x23]
	cbz	x0, LBB71_343
; %bb.17:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	x24, x0
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	str	x22, [x0, #64]
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	str	w8, [x0, #72]
	str	x9, [x23, #56]
	ldr	x8, [x25, #8]
	ldr	x0, [x8, #8]
	add	x1, sp, #336
	bl	_nvm_owned_array_transport
	ldr	x0, [sp, #336]
	ldr	w1, [sp, #352]
	add	x2, x24, #8
	bl	_nvm_v2_layouts_decode
	cbnz	w0, LBB71_132
; %bb.18:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x1, [sp, #344]
	ldr	w2, [sp, #356]
	add	x0, sp, #304
	bl	_nvm_v2_cursor_init
	add	x0, sp, #304
	add	x1, sp, #296
	bl	_nvm_v2_u32
	cbnz	w0, LBB71_132
; %bb.19:                               ;   in Loop: Header=BB71_15 Depth=1
	add	x0, sp, #304
	add	x1, sp, #300
	bl	_nvm_v2_u32
	cbnz	w0, LBB71_132
; %bb.20:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	w1, [sp, #300]
	ldr	w8, [x24, #16]
	cmp	w1, w8
	b.ne	LBB71_132
; %bb.21:                               ;   in Loop: Header=BB71_15 Depth=1
	add	x0, sp, #304
	add	x2, sp, #288
	bl	_nvm_v2_take
	cbnz	w0, LBB71_132
; %bb.22:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	w25, [sp, #300]
	cmp	w25, #1
	csinc	w0, w25, wzr, hi
	bl	_malloc
	str	x0, [x24, #24]
	cbz	x0, LBB71_132
; %bb.23:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x1, [sp, #288]
	mov	x2, x25
	bl	_memcpy
	add	x0, sp, #304
	bl	_nvm_v2_align4
	cbnz	w0, LBB71_132
; %bb.24:                               ;   in Loop: Header=BB71_15 Depth=1
	add	x0, sp, #304
	add	x1, sp, #296
	bl	_nvm_v2_u32
	cbnz	w0, LBB71_132
; %bb.25:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	x25, #0                         ; =0x0
	str	wzr, [sp, #128]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	mov	w9, #24                         ; =0x18
	madd	x8, x8, x9, x21
	stp	x28, x8, [sp, #56]              ; 16-byte Folded Spill
LBB71_26:                               ;   Parent Loop BB71_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB71_43 Depth 3
	add	x0, sp, #304
	add	x1, sp, #286
	bl	_nvm_v2_u16
	cbnz	w0, LBB71_132
; %bb.27:                               ;   in Loop: Header=BB71_26 Depth=2
	add	x0, sp, #304
	add	x1, sp, #284
	bl	_nvm_v2_u16
	cbnz	w0, LBB71_132
; %bb.28:                               ;   in Loop: Header=BB71_26 Depth=2
	add	x0, sp, #304
	add	x1, sp, #272
	bl	_nvm_v2_u8
	cbnz	w0, LBB71_132
; %bb.29:                               ;   in Loop: Header=BB71_26 Depth=2
	add	x0, sp, #304
	add	x8, sp, #272
	orr	x1, x8, #0x1
	bl	_nvm_v2_u8
	cbnz	w0, LBB71_132
; %bb.30:                               ;   in Loop: Header=BB71_26 Depth=2
	add	x0, sp, #304
	add	x1, sp, #264
	bl	_nvm_v2_u16
	cbnz	w0, LBB71_132
; %bb.31:                               ;   in Loop: Header=BB71_26 Depth=2
	add	x0, sp, #304
	add	x8, sp, #272
	orr	x1, x8, #0x4
	bl	_nvm_v2_u32
	cbnz	w0, LBB71_132
; %bb.32:                               ;   in Loop: Header=BB71_26 Depth=2
	ldr	w8, [sp, #128]                  ; 4-byte Folded Reload
	mov	w21, w8
	ldrh	w22, [sp, #286]
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	cmp	x8, x21
	b.ne	LBB71_39
; %bb.33:                               ;   in Loop: Header=BB71_26 Depth=2
	strh	w22, [x24, #56]
	ldrh	w8, [sp, #284]
	strh	w8, [x24, #58]
	ldr	x8, [sp, #272]
	str	x8, [x24, #32]
	cmp	w22, #1
	csinc	w27, w22, wzr, hi
	mov	x0, x27
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x28, x0
	str	x0, [x24, #40]
	mov	x0, x27
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x25, x0
	str	x0, [x23, #8]
	mov	w0, #1                          ; =0x1
	mov	w1, #56                         ; =0x38
	bl	_calloc
	mov	x26, x0
	str	x0, [x23, #24]
	ubfiz	x0, x27, #1, #32
	ldr	x27, [sp, #152]                 ; 8-byte Folded Reload
	bl	_malloc
	str	x0, [x23, #16]
	cbz	x28, LBB71_132
; %bb.34:                               ;   in Loop: Header=BB71_26 Depth=2
	cbz	x26, LBB71_132
; %bb.35:                               ;   in Loop: Header=BB71_26 Depth=2
	cbz	x25, LBB71_132
; %bb.36:                               ;   in Loop: Header=BB71_26 Depth=2
	cbz	x0, LBB71_132
; %bb.37:                               ;   in Loop: Header=BB71_26 Depth=2
	cbz	w22, LBB71_49
; %bb.38:                               ;   in Loop: Header=BB71_26 Depth=2
	lsl	x2, x22, #1
	mov	w1, #255                        ; =0xff
	bl	_memset
	mov	x22, #0                         ; =0x0
	b	LBB71_43
LBB71_39:                               ;   in Loop: Header=BB71_26 Depth=2
	cbz	w22, LBB71_49
; %bb.40:                               ;   in Loop: Header=BB71_26 Depth=2
	mov	x22, #0                         ; =0x0
	b	LBB71_43
LBB71_41:                               ;   in Loop: Header=BB71_43 Depth=3
	cbnz	w0, LBB71_132
LBB71_42:                               ;   in Loop: Header=BB71_43 Depth=3
	add	x22, x22, #1
	ldrh	w8, [sp, #286]
	cmp	x22, x8
	b.hs	LBB71_49
LBB71_43:                               ;   Parent Loop BB71_15 Depth=1
                                        ;     Parent Loop BB71_26 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x0, sp, #304
	add	x1, sp, #264
	bl	_nvm_v2_u8
	cbnz	w0, LBB71_132
; %bb.44:                               ;   in Loop: Header=BB71_43 Depth=3
	add	x0, sp, #304
	add	x8, sp, #264
	orr	x1, x8, #0x1
	bl	_nvm_v2_u8
	cbnz	w0, LBB71_132
; %bb.45:                               ;   in Loop: Header=BB71_43 Depth=3
	add	x0, sp, #304
	add	x1, sp, #334
	bl	_nvm_v2_u16
	cbnz	w0, LBB71_132
; %bb.46:                               ;   in Loop: Header=BB71_43 Depth=3
	add	x0, sp, #304
	add	x8, sp, #264
	orr	x1, x8, #0x4
	bl	_nvm_v2_u32
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	cmp	x8, x21
	b.ne	LBB71_41
; %bb.47:                               ;   in Loop: Header=BB71_43 Depth=3
	cbnz	w0, LBB71_41
; %bb.48:                               ;   in Loop: Header=BB71_43 Depth=3
	ldr	x8, [x24, #40]
	ldr	x9, [sp, #264]
	str	x9, [x8, x22, lsl #3]
	ldrh	w8, [sp, #284]
	cmp	x22, x8
	cset	w8, lo
	strb	w8, [x25, x22]
	b	LBB71_42
LBB71_49:                               ;   in Loop: Header=BB71_26 Depth=2
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	add	w9, w9, #1
	ldr	w8, [sp, #120]                  ; 4-byte Folded Reload
	str	w9, [sp, #128]                  ; 4-byte Folded Spill
	cmp	w9, w8
	b.ne	LBB71_26
; %bb.50:                               ;   in Loop: Header=BB71_15 Depth=1
	ldp	x22, x8, [sp, #160]             ; 16-byte Folded Reload
	lsl	x8, x8, #4
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	str	x23, [x9, x8]
	ldr	x23, [x23]
	ldrh	w8, [x23, #56]
	ldr	x14, [sp, #64]                  ; 8-byte Folded Reload
	ldrh	w9, [x14, #16]
	cmp	w8, w9
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
	mov	w28, #3                         ; =0x3
	b.ne	LBB71_362
; %bb.51:                               ;   in Loop: Header=BB71_15 Depth=1
	ldrh	w9, [x23, #58]
	ldrh	w10, [x14, #4]
	cmp	w9, w10
	b.ne	LBB71_362
; %bb.52:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x12, [x23, #32]
	tst	x12, #0xff00
	b.ne	LBB71_362
; %bb.53:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x25, [x22, #8]
	lsr	x11, x12, #32
	and	w10, w12, #0xff
	and	w12, w12, #0xff
	cmp	w12, #8
	b.ne	LBB71_57
; %bb.54:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	w12, [x23, #16]
	cmp	w12, w11
	b.ls	LBB71_362
; %bb.55:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x12, [x23, #24]
	ldrb	w12, [x12, x11]
	bics	wzr, w28, w12
	b.ne	LBB71_362
; %bb.56:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x12, [x23, #8]
	lsl	x11, x11, #4
	ldrb	w11, [x12, x11]
	cbz	w11, LBB71_61
	b	LBB71_362
LBB71_57:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	w13, #-1                        ; =0xffffffff
	cmp	x11, x13
	b.ne	LBB71_362
; %bb.58:                               ;   in Loop: Header=BB71_15 Depth=1
	cmp	w10, #4
	b.hi	LBB71_60
; %bb.59:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	w11, #1                         ; =0x1
	lsl	w11, w11, w10
	mov	w13, #22                        ; =0x16
	tst	w11, w13
	b.ne	LBB71_61
LBB71_60:                               ;   in Loop: Header=BB71_15 Depth=1
	cbnz	w12, LBB71_362
LBB71_61:                               ;   in Loop: Header=BB71_15 Depth=1
	ldrb	w11, [x14, #20]
	cmp	w11, w10
	b.ne	LBB71_362
; %bb.62:                               ;   in Loop: Header=BB71_15 Depth=1
	ldrb	w11, [x14, #21]
	cmp	w10, #0
	cset	w10, ne
	cmp	w11, w10
	b.ne	LBB71_362
; %bb.63:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	w10, [x23, #16]
	cbz	w10, LBB71_84
; %bb.64:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	x24, #0                         ; =0x0
	mov	w27, #4194304                   ; =0x400000
	b	LBB71_67
LBB71_65:                               ;   in Loop: Header=BB71_67 Depth=2
	ldr	w10, [x23, #16]
LBB71_66:                               ;   in Loop: Header=BB71_67 Depth=2
	add	x24, x24, #1
	cmp	x24, x10
	b.hs	LBB71_83
LBB71_67:                               ;   Parent Loop BB71_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB71_76 Depth 3
	ldr	x8, [x23, #24]
	ldrb	w8, [x8, x24]
	bics	wzr, w28, w8
	b.ne	LBB71_66
; %bb.68:                               ;   in Loop: Header=BB71_67 Depth=2
	ldr	x8, [x23, #8]
	add	x21, x8, x24, lsl #4
	ldrb	w8, [x21]
	cbnz	w8, LBB71_66
; %bb.69:                               ;   in Loop: Header=BB71_67 Depth=2
	ldr	x8, [x22, #8]
	ldr	x0, [x8, #8]
	add	x2, sp, #336
	mov	x1, x24
	bl	_nvm_owned_array_layout_fact
	cbz	w0, LBB71_379
; %bb.70:                               ;   in Loop: Header=BB71_67 Depth=2
	ldrb	w8, [sp, #361]
	cmp	w8, #31
	b.hi	LBB71_375
; %bb.71:                               ;   in Loop: Header=BB71_67 Depth=2
	ldrh	w8, [x21, #2]
	cmp	w8, #256
	mov	w12, #182                       ; =0xb6
	b.hi	LBB71_375
; %bb.72:                               ;   in Loop: Header=BB71_67 Depth=2
	ldr	w9, [x26, #12]
	sub	w10, w27, w9
	cmp	w10, w8
	b.lo	LBB71_382
; %bb.73:                               ;   in Loop: Header=BB71_67 Depth=2
	add	w9, w9, w8
	str	w9, [x26, #12]
	cbz	w8, LBB71_65
; %bb.74:                               ;   in Loop: Header=BB71_67 Depth=2
	ldr	x9, [x21, #8]
	add	x9, x9, #4
	b	LBB71_76
LBB71_75:                               ;   in Loop: Header=BB71_76 Depth=3
	add	x9, x9, #12
	subs	x8, x8, #1
	b.eq	LBB71_65
LBB71_76:                               ;   Parent Loop BB71_15 Depth=1
                                        ;     Parent Loop BB71_67 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w11, [x9, #-4]
	ldr	w10, [x9]
	cmp	w11, #8
	b.ne	LBB71_81
; %bb.77:                               ;   in Loop: Header=BB71_76 Depth=3
	cmp	x24, x10
	b.ls	LBB71_371
; %bb.78:                               ;   in Loop: Header=BB71_76 Depth=3
	ldr	w11, [x23, #16]
	cmp	w10, w11
	b.hs	LBB71_371
; %bb.79:                               ;   in Loop: Header=BB71_76 Depth=3
	ldr	x11, [x23, #24]
	ldrb	w11, [x11, x10]
	bics	wzr, w28, w11
	b.ne	LBB71_371
; %bb.80:                               ;   in Loop: Header=BB71_76 Depth=3
	ldr	x11, [x23, #8]
	lsl	x10, x10, #4
	ldrb	w10, [x11, x10]
	cbz	w10, LBB71_75
	b	LBB71_371
LBB71_81:                               ;   in Loop: Header=BB71_76 Depth=3
	cmn	w10, #1
	b.ne	LBB71_370
; %bb.82:                               ;   in Loop: Header=BB71_76 Depth=3
	cmp	w11, #7
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w11
	and	w10, w10, w12
	ccmp	w10, #0, #4, ls
	b.ne	LBB71_75
	b	LBB71_370
LBB71_83:                               ;   in Loop: Header=BB71_15 Depth=1
	ldrh	w8, [x23, #56]
	ldrh	w9, [x23, #58]
LBB71_84:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x10, [sp, #168]                 ; 8-byte Folded Reload
	mov	w11, #116                       ; =0x74
	madd	x21, x10, x11, x25
	sturh	w8, [x21, #36]
	sturh	w9, [x21, #38]
	ldr	x1, [x23, #32]
	mov	x0, x23
	bl	_la_declaration
	stur	x0, [x21, #44]
	stur	w1, [x21, #52]
	tbz	w1, #0, LBB71_86
; %bb.85:                               ;   in Loop: Header=BB71_15 Depth=1
	ldr	x8, [x23, #8]
	ldr	w9, [x23, #36]
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
	sturh	w8, [x21, #42]
LBB71_86:                               ;   in Loop: Header=BB71_15 Depth=1
	ldrh	w8, [x23, #56]
	ldr	x17, [sp, #160]                 ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	cbz	w8, LBB71_114
; %bb.87:                               ;   in Loop: Header=BB71_15 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldp	x10, x11, [sp, #96]             ; 16-byte Folded Reload
	add	x10, x25, x10
	b	LBB71_89
LBB71_88:                               ;   in Loop: Header=BB71_89 Depth=2
	add	x9, x9, #1
	ldrh	w12, [x23, #56]
	add	x11, x11, #12
	add	x10, x10, #12
	add	x8, x8, #8
	cmp	x9, x12
	b.hs	LBB71_114
LBB71_89:                               ;   Parent Loop BB71_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x12, [x23, #40]
	add	x14, x12, x8
	ldrb	w12, [x14]
	ldrb	w13, [x14, #1]
	ldr	w14, [x14, #4]
	ldrh	w15, [x23, #58]
	cmp	x9, x15
	b.hs	LBB71_95
; %bb.90:                               ;   in Loop: Header=BB71_89 Depth=2
	cbnz	w13, LBB71_363
; %bb.91:                               ;   in Loop: Header=BB71_89 Depth=2
	cmp	w12, #8
	b.ne	LBB71_100
; %bb.92:                               ;   in Loop: Header=BB71_89 Depth=2
	ldr	w15, [x23, #16]
	cmp	w15, w14
	b.ls	LBB71_363
; %bb.93:                               ;   in Loop: Header=BB71_89 Depth=2
	ldr	x15, [x23, #24]
	ldrb	w15, [x15, x14]
	bics	wzr, w0, w15
	b.ne	LBB71_363
; %bb.94:                               ;   in Loop: Header=BB71_89 Depth=2
	ldr	x15, [x23, #8]
	lsl	x16, x14, #4
	ldrb	w16, [x15, x16]
	mov	x15, x14
	cbz	w16, LBB71_107
	b	LBB71_363
LBB71_95:                               ;   in Loop: Header=BB71_89 Depth=2
	cbnz	w13, LBB71_363
; %bb.96:                               ;   in Loop: Header=BB71_89 Depth=2
	cmp	w12, #8
	b.ne	LBB71_104
; %bb.97:                               ;   in Loop: Header=BB71_89 Depth=2
	ldr	w15, [x23, #16]
	cmp	w14, w15
	b.hs	LBB71_363
; %bb.98:                               ;   in Loop: Header=BB71_89 Depth=2
	ldr	x15, [x23, #24]
	ldrb	w15, [x15, x14]
	bics	wzr, w0, w15
	b.ne	LBB71_363
; %bb.99:                               ;   in Loop: Header=BB71_89 Depth=2
	ldr	x15, [x23, #8]
	lsl	x16, x14, #4
	ldrb	w15, [x15, x16]
	cbz	w15, LBB71_106
	b	LBB71_363
LBB71_100:                              ;   in Loop: Header=BB71_89 Depth=2
	cmn	w14, #1
	b.ne	LBB71_363
; %bb.101:                              ;   in Loop: Header=BB71_89 Depth=2
	sub	w15, w12, #1
	and	w16, w15, #0xff
	cmp	w16, #4
	b.hi	LBB71_363
; %bb.102:                              ;   in Loop: Header=BB71_89 Depth=2
	mov	w16, #27                        ; =0x1b
	lsr	w15, w16, w15
	tbz	w15, #0, LBB71_363
; %bb.103:                              ;   in Loop: Header=BB71_89 Depth=2
	mov	w15, #-1                        ; =0xffffffff
	b	LBB71_107
LBB71_104:                              ;   in Loop: Header=BB71_89 Depth=2
	cmn	w14, #1
	b.ne	LBB71_363
; %bb.105:                              ;   in Loop: Header=BB71_89 Depth=2
	sub	w15, w12, #1
	cmp	w15, #5
	ccmp	w12, #7, #4, hs
	b.ne	LBB71_363
LBB71_106:                              ;   in Loop: Header=BB71_89 Depth=2
	mov	x15, x14
LBB71_107:                              ;   in Loop: Header=BB71_89 Depth=2
	cmp	w12, #8
	b.ne	LBB71_111
; %bb.108:                              ;   in Loop: Header=BB71_89 Depth=2
	ldr	w16, [x23, #16]
	cmp	w16, w14
	b.ls	LBB71_111
; %bb.109:                              ;   in Loop: Header=BB71_89 Depth=2
	ldr	x14, [x23, #24]
	ldrb	w14, [x14, x15]
	bics	wzr, w0, w14
	b.ne	LBB71_111
; %bb.110:                              ;   in Loop: Header=BB71_89 Depth=2
	ldr	x14, [x23, #8]
	lsl	x16, x15, #4
	ldrb	w14, [x14, x16]
	cmp	w14, #0
	cset	w14, eq
	b	LBB71_112
LBB71_111:                              ;   in Loop: Header=BB71_89 Depth=2
	mov	w14, #0                         ; =0x0
LBB71_112:                              ;   in Loop: Header=BB71_89 Depth=2
	ldr	x16, [x17, #8]
	orr	x12, x12, x13, lsl #8
	orr	x12, x12, x15, lsl #32
	add	x13, x16, x11
	str	x12, [x13]
	str	w14, [x13, #8]
	ldrh	w12, [x23, #58]
	cmp	x9, x12
	b.hs	LBB71_88
; %bb.113:                              ;   in Loop: Header=BB71_89 Depth=2
	ldr	x12, [x17, #8]
	add	x12, x12, x11
	ldr	x13, [x12]
	ldr	w12, [x12, #8]
	str	w12, [x10, #8]
	str	x13, [x10]
	b	LBB71_88
LBB71_114:                              ;   in Loop: Header=BB71_15 Depth=1
	ldr	x22, [x17]
	ldr	x8, [x22, #256]
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	mov	w10, #24                        ; =0x18
	madd	x26, x9, x10, x8
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x21, x8, x9, lsl #4
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w9, [x8]
	str	w9, [x21]
	ldr	w8, [x26, #12]
	cbz	w8, LBB71_127
; %bb.115:                              ;   in Loop: Header=BB71_15 Depth=1
	mov	w22, #0                         ; =0x0
	ldr	x27, [sp, #160]                 ; 8-byte Folded Reload
	ldr	x28, [sp, #144]                 ; 8-byte Folded Reload
LBB71_116:                              ;   Parent Loop BB71_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w9, #1, lsl #12                 ; =4096
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	b.eq	LBB71_385
; %bb.117:                              ;   in Loop: Header=BB71_116 Depth=2
	mov	w11, #104                       ; =0x68
	umaddl	x23, w9, w11, x10
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	stp	w9, w22, [x23, #64]
	ldr	x9, [x27]
	ldr	x9, [x9, #280]
	ldr	w10, [x26, #8]
	add	x9, x9, x10
	add	x0, x9, w22, uxtw
	sub	w1, w8, w22
	mov	x2, x23
	bl	_isa_decode
	cbz	w0, LBB71_387
; %bb.118:                              ;   in Loop: Header=BB71_116 Depth=2
	mov	x24, x0
	ldrb	w25, [x23]
	add	x1, sp, #336
	mov	x0, x25
	bl	_la_scalar
	tbz	w0, #31, LBB71_121
; %bb.119:                              ;   in Loop: Header=BB71_116 Depth=2
	cmp	w25, #252
	b.hi	LBB71_387
; %bb.120:                              ;   in Loop: Header=BB71_116 Depth=2
Lloh168:
	adrp	x10, lJTI71_0@PAGE
Lloh169:
	add	x10, x10, lJTI71_0@PAGEOFF
	adr	x8, LBB71_121
	ldrh	w9, [x10, x25, lsl #1]
	add	x8, x8, x9, lsl #2
	br	x8
LBB71_121:                              ;   in Loop: Header=BB71_116 Depth=2
	ldr	x8, [x27, #8]
	ldr	w1, [x28]
	mov	w9, #28                         ; =0x1c
	umaddl	x9, w1, w9, x8
	mov	w10, #25540                     ; =0x63c4
	add	x25, x9, x10
	ldr	x0, [x8]
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, x25
	bl	_nvm_owned_array_origin_obligation
	cbz	w0, LBB71_369
; %bb.122:                              ;   in Loop: Header=BB71_116 Depth=2
	ldr	w8, [x25]
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	cmp	x9, x8
	b.ne	LBB71_369
; %bb.123:                              ;   in Loop: Header=BB71_116 Depth=2
	ldr	w8, [x25, #4]
	cmp	w8, w22
	b.ne	LBB71_369
; %bb.124:                              ;   in Loop: Header=BB71_116 Depth=2
	ldrb	w8, [x25, #22]
	ldrb	w9, [x23]
	cmp	w8, w9
	b.ne	LBB71_369
; %bb.125:                              ;   in Loop: Header=BB71_116 Depth=2
	ldr	w8, [x28]
	add	w9, w8, #1
	str	w9, [x28]
	mov	w8, #-1                         ; =0xffffffff
	stp	w9, w8, [x23, #72]
	ldr	w8, [x26, #12]
	add	w22, w24, w22
	cmp	w22, w8
	b.lo	LBB71_116
; %bb.126:                              ;   in Loop: Header=BB71_15 Depth=1
	ldr	x22, [x27]
LBB71_127:                              ;   in Loop: Header=BB71_15 Depth=1
	str	w9, [x21, #4]
	ldp	x25, x10, [sp, #160]            ; 16-byte Folded Reload
	add	x10, x10, #1
	ldr	w8, [x22, #272]
	ldr	w11, [sp, #120]                 ; 4-byte Folded Reload
	add	w11, w11, #1
	str	w11, [sp, #120]                 ; 4-byte Folded Spill
	ldr	x11, [sp, #104]                 ; 8-byte Folded Reload
	add	x11, x11, #3072
	str	x11, [sp, #104]                 ; 8-byte Folded Spill
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
	add	x11, x11, #116
	str	x11, [sp, #96]                  ; 8-byte Folded Spill
	str	x10, [sp, #168]                 ; 8-byte Folded Spill
	cmp	x10, x8
	ldr	x27, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x28, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #72]                  ; 8-byte Folded Reload
	b.lo	LBB71_15
; %bb.128:
	ldr	w10, [sp, #260]
	cmp	w9, w10
	b.ne	LBB71_327
; %bb.129:
	cbz	w8, LBB71_135
; %bb.130:
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #160]                 ; 8-byte Folded Reload
	add	x10, x10, #212
	mov	w11, #104                       ; =0x68
	b	LBB71_399
LBB71_131:
	mov	x0, x25
	bl	_free
	mov	x0, x21
	bl	_free
	ldr	x0, [sp, #240]
	bl	_nvm_owned_array_origins_free
	ldr	x0, [sp, #208]
	bl	_nvm_owned_array_layouts_free
Lloh170:
	adrp	x8, lCPI71_0@PAGE
Lloh171:
	ldr	q0, [x8, lCPI71_0@PAGEOFF]
	str	q0, [x19]
Lloh172:
	adrp	x8, l_.str.8@PAGE
Lloh173:
	add	x8, x8, l_.str.8@PAGEOFF
	b	LBB71_8
LBB71_132:
	mov	x0, x23
	bl	_nvm_affine_state_free
LBB71_133:
	mov	w9, #4                          ; =0x4
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w9, w8, [x27, #16]
Lloh174:
	adrp	x8, l_.str.71@PAGE
Lloh175:
	add	x8, x8, l_.str.71@PAGEOFF
	stp	xzr, x8, [x27, #24]
	b	LBB71_414
LBB71_134:
	ldr	w8, [x26]
	ldr	w9, [sp, #260]
	cmp	w8, w9
	b.ne	LBB71_327
LBB71_135:
	ldr	w8, [x20, #272]
	cbz	w8, LBB71_146
; %bb.136:
	mov	x21, #0                         ; =0x0
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	add	x8, x8, #16
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	add	x8, sp, #336
	add	x24, x8, #8
	mov	w25, #24                        ; =0x18
	mov	w26, #1                         ; =0x1
	mov	x27, #-4294967295               ; =0xffffffff00000001
	mov	w28, #256                       ; =0x100
LBB71_137:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB71_138 Depth 2
                                        ;     Child Loop BB71_142 Depth 2
	ldr	x23, [x20, #256]
	madd	x8, x21, x25, x23
	ldrh	w22, [x8, #16]
	add	x0, sp, #336
	mov	w1, #6144                       ; =0x1800
	bl	_bzero
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	add	x8, x8, x21, lsl #4
	ldr	x9, [x8, #8]
	add	x10, sp, #336
	stp	x9, x10, [sp, #304]
	str	xzr, [sp, #320]
	mov	x10, x24
	cbz	x22, LBB71_139
LBB71_138:                              ;   Parent Loop BB71_137 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	stur	x27, [x10, #-8]
	str	w28, [x10], #12
	subs	x22, x22, #1
	b.ne	LBB71_138
LBB71_139:                              ;   in Loop: Header=BB71_137 Depth=1
	madd	x10, x21, x25, x23
	ldrh	w13, [x10, #4]!
	cbz	w13, LBB71_144
; %bb.140:                              ;   in Loop: Header=BB71_137 Depth=1
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x14, x24
	b	LBB71_142
LBB71_141:                              ;   in Loop: Header=BB71_142 Depth=2
	add	x12, x12, #1
	add	x14, x14, #12
	add	x11, x11, #8
	cmp	x12, w13, uxth
	b.hs	LBB71_144
LBB71_142:                              ;   Parent Loop BB71_137 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x15, [x9]
	ldr	x15, [x15, #40]
	ldrb	w15, [x15, x11]
	cmp	x15, #8
	b.eq	LBB71_141
; %bb.143:                              ;   in Loop: Header=BB71_142 Depth=2
	lsl	x13, x26, x15
	and	w13, w13, #0xffff
	orr	x13, x13, #0xffffffff00000000
	stur	x13, [x14, #-8]
	str	wzr, [x14]
	ldrh	w13, [x10]
	b	LBB71_141
LBB71_144:                              ;   in Loop: Header=BB71_137 Depth=1
	ldr	w1, [x8]
	add	x2, sp, #304
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
	bl	_la_join
	tbz	w0, #0, LBB71_414
; %bb.145:                              ;   in Loop: Header=BB71_137 Depth=1
	add	x21, x21, #1
	ldr	w8, [x20, #272]
	cmp	x21, x8
	b.lo	LBB71_137
LBB71_146:
	ldp	x1, x21, [sp, #152]             ; 16-byte Folded Reload
	ldr	w8, [x1, #8]
	cbz	w8, LBB71_328
; %bb.147:
	add	x9, x21, #104, lsl #12          ; =425984
	add	x10, x9, #160
	add	x9, x21, #144
	stp	x9, x10, [sp, #88]              ; 16-byte Folded Spill
	add	x11, x21, #24
	add	x9, sp, #336
	add	x10, x9, #12
	add	x9, x9, #4
	stp	x11, x9, [sp, #8]               ; 16-byte Folded Spill
	mov	x9, #-65408                     ; =0xffffffffffff0080
	movk	x9, #0, lsl #16
	sub	x9, x9, #96
	str	x9, [sp]                        ; 8-byte Folded Spill
Lloh176:
	adrp	x9, l_.str.84@PAGE
Lloh177:
	add	x9, x9, l_.str.84@PAGEOFF
	stp	x9, x10, [sp, #24]              ; 16-byte Folded Spill
LBB71_148:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB71_167 Depth 2
                                        ;     Child Loop BB71_170 Depth 2
                                        ;     Child Loop BB71_237 Depth 2
                                        ;     Child Loop BB71_253 Depth 2
                                        ;     Child Loop BB71_291 Depth 2
                                        ;     Child Loop BB71_232 Depth 2
                                        ;     Child Loop BB71_300 Depth 2
                                        ;     Child Loop BB71_196 Depth 2
	ldr	x25, [sp, #144]                 ; 8-byte Folded Reload
	ldr	w9, [x25, #8]
	add	w10, w9, #1
	str	w10, [x25, #8]
	cmp	w9, #64, lsl #12                ; =262144
	b.eq	LBB71_350
; %bb.149:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w9, [x1]
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	ldr	w10, [x10, x9, lsl #2]
	add	w9, w9, #1
	and	w9, w9, #0xfff
	str	w9, [x1]
	sub	w8, w8, #1
	str	w8, [x1, #8]
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	mov	w9, #104                        ; =0x68
	umaddl	x27, w10, w9, x8
	strb	wzr, [x27, #98]
	ldr	x8, [x20, #256]
	ldr	w9, [x27, #64]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w1, [x8, #16]
	ldr	x0, [x27, #80]
	ldrh	w8, [x0, #16]
	add	w8, w8, w1, lsl #1
	ldr	w9, [x25, #12]
	mov	w10, #4194304                   ; =0x400000
	sub	w10, w10, w9
	cmp	w8, w10
	b.hi	LBB71_351
; %bb.150:                              ;   in Loop: Header=BB71_148 Depth=1
	add	w8, w8, w9
	str	w8, [x25, #12]
	bl	_la_clone
	ldr	w8, [x27, #64]
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	cbz	x0, LBB71_352
; %bb.151:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x28, x0
	ldp	x8, x24, [x0]
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldr	x26, [x8]
	ldrh	w23, [x26, #56]
	ldrb	w22, [x27]
	mov	x0, x22
	bl	_isa_get_info
	cbz	x0, LBB71_353
; %bb.152:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	str	x24, [sp, #80]                  ; 8-byte Folded Spill
	umaddl	x8, w23, w8, x24
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	mov	x4, x27
	ldrh	w1, [x4, #8]!
	and	w5, w1, #0xff
	cmp	w22, #88
	str	x28, [sp, #168]                 ; 8-byte Folded Spill
	str	x27, [sp, #128]                 ; 8-byte Folded Spill
	b.ne	LBB71_154
; %bb.153:                              ;   in Loop: Header=BB71_148 Depth=1
	str	x23, [sp, #64]                  ; 8-byte Folded Spill
	mov	w3, #0                          ; =0x0
	ldrh	w28, [x27, #16]
	mov	w9, #1                          ; =0x1
	b	LBB71_185
LBB71_154:                              ;   in Loop: Header=BB71_148 Depth=1
	sub	w8, w22, #13
	and	w8, w8, #0xff
	cmp	w8, #1
	b.hi	LBB71_173
; %bb.155:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x8, x4
	cmp	w22, #13
	b.eq	LBB71_157
; %bb.156:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x26, #40]
	add	x8, x8, x1, lsl #3
	add	x8, x8, #4
LBB71_157:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w8, [x8]
	ldr	w9, [x26, #16]
	cmp	w8, w9
	add	x0, sp, #336
	b.hs	LBB71_347
; %bb.158:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [x26, #24]
	ldrb	w9, [x9, x8]
	mov	w10, #3                         ; =0x3
	bics	wzr, w10, w9
	b.ne	LBB71_347
; %bb.159:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [x26, #8]
	lsl	x10, x8, #4
	ldrb	w9, [x9, x10]
	cbnz	w9, LBB71_347
; %bb.160:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	ldr	w10, [x9, #16]
	cmp	w8, w10
	b.hs	LBB71_347
; %bb.161:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x10, [x9, #24]
	ldrb	w10, [x10, x8]
	tbz	w10, #0, LBB71_347
; %bb.162:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [x9, #8]
	add	x8, x9, x8, lsl #4
	ldrb	w9, [x8]
	cbnz	w9, LBB71_347
; %bb.163:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w3, [x8, #2]
	and	w9, w3, #0xffff
	cmp	w9, #256
	b.hi	LBB71_347
; %bb.164:                              ;   in Loop: Header=BB71_148 Depth=1
	tst	w3, #0xffff
	b.eq	LBB71_171
; %bb.165:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x8, #8]
	and	x12, x3, #0xffff
	and	w13, w3, #0xffff
	sub	x8, x12, #1
	mov	x11, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x11, #43691
	umulh	x11, x8, x11
	lsr	x11, x11, #1
	add	x11, x11, x11, lsl #1
	sub	x8, x8, x11
	add	x11, x8, #1
	cmp	x11, #3
	csinc	x8, xzr, x8, eq
	cmp	w13, #3
	b.lo	LBB71_168
; %bb.166:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x9, #0                          ; =0x0
	sub	x12, x12, x8
	add	x13, x10, #16
	ldr	x14, [sp, #32]                  ; 8-byte Folded Reload
LBB71_167:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w15, [x13, #-16]
	ldur	w16, [x13, #-12]
	sturb	w15, [x14, #-12]
	add	x15, x0, x9, lsl #3
	strb	wzr, [x15, #3]
	sturh	wzr, [x15, #1]
	stur	w16, [x14, #-8]
	ldurb	w16, [x13, #-4]
	ldr	w17, [x13]
	sturb	w16, [x14, #-4]
	strb	wzr, [x15, #11]
	sturh	wzr, [x15, #9]
	str	w17, [x14]
	ldrb	w16, [x13, #8]
	ldr	w17, [x13, #12]
	strb	w16, [x14, #4]
	strb	wzr, [x15, #19]
	sturh	wzr, [x15, #17]
	str	w17, [x14, #8]
	add	x9, x9, #3
	add	x14, x14, #24
	add	x13, x13, #36
	cmp	x12, x9
	b.ne	LBB71_167
LBB71_168:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	x11, #3
	b.eq	LBB71_171
; %bb.169:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w11, #12                        ; =0xc
	madd	x10, x9, x11, x10
	add	x10, x10, #4
	add	x9, x0, x9, lsl #3
LBB71_170:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x10, #-4]
	ldr	w12, [x10], #12
	strb	w11, [x9]
	sturh	wzr, [x9, #1]
	strb	wzr, [x9, #3]
	str	w12, [x9, #4]
	add	x9, x9, #8
	subs	x8, x8, #1
	b.ne	LBB71_170
LBB71_171:                              ;   in Loop: Header=BB71_148 Depth=1
	str	x23, [sp, #64]                  ; 8-byte Folded Spill
	and	w8, w3, #0xffff
	ldr	w9, [x25, #12]
	mov	w10, #4194304                   ; =0x400000
	sub	w10, w10, w9
	cmp	w10, w8
	b.lo	LBB71_364
; %bb.172:                              ;   in Loop: Header=BB71_148 Depth=1
	add	w9, w9, w8
	str	w9, [x25, #12]
	cmp	w22, #13
	csel	w28, w8, wzr, eq
	csinc	w9, w8, wzr, ne
	b	LBB71_185
LBB71_173:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w22, #61
	b.eq	LBB71_176
; %bb.174:                              ;   in Loop: Header=BB71_148 Depth=1
	str	x23, [sp, #64]                  ; 8-byte Folded Spill
	cmp	w22, #59
	b.ne	LBB71_184
; %bb.175:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w3, #0                          ; =0x0
	ldr	x8, [x21]
	ldr	x8, [x8, #256]
	ldr	w21, [x4]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w21, w9, x8
	ldrh	w28, [x8, #4]
	ldrb	w9, [x8, #21]
	and	w5, w21, #0xff
	mov	x23, x21
	b	LBB71_186
LBB71_176:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w8, [x25, #12]
	mov	w9, #4194304                    ; =0x400000
	sub	w9, w9, w8
	cmp	w9, w23
	b.lo	LBB71_364
; %bb.177:                              ;   in Loop: Header=BB71_148 Depth=1
	add	w8, w8, w23
	str	w8, [x25, #12]
	ldrh	w8, [x28, #16]
	ldr	x9, [x21]
	ldr	x9, [x9, #256]
	ldr	x10, [sp, #120]                 ; 8-byte Folded Reload
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	ldrb	w9, [x9, #21]
	cmp	w8, w9
	b.ne	LBB71_368
; %bb.178:                              ;   in Loop: Header=BB71_148 Depth=1
	cbz	w8, LBB71_218
; %bb.179:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x13, [x26, #32]
	tst	x13, #0xff00
	b.ne	LBB71_368
; %bb.180:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x11, [x8]
	ldr	w12, [x8, #8]
	lsr	x10, x13, #32
	and	x9, x13, #0xff
	cmp	x9, #8
	b.ne	LBB71_219
; %bb.181:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w8, [x26, #16]
	cmp	x8, x10
	b.ls	LBB71_242
; %bb.182:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x26, #24]
	ldrb	w8, [x8, x10]
	mov	w13, #3                         ; =0x3
	bics	wzr, w13, w8
	b.ne	LBB71_242
; %bb.183:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x26, #8]
	lsl	x13, x10, #4
	ldrb	w8, [x8, x13]
	cmp	w8, #0
	cset	w13, eq
	b	LBB71_243
LBB71_184:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w3, #0                          ; =0x0
	ldrsb	w28, [x0, #28]
	ldrsb	w9, [x0, #29]
LBB71_185:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x23, x1
LBB71_186:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #2                          ; =0x2
Lloh178:
	adrp	x11, l_.str.88@PAGE
Lloh179:
	add	x11, x11, l_.str.88@PAGEOFF
	tbnz	w28, #31, LBB71_357
; %bb.187:                              ;   in Loop: Header=BB71_148 Depth=1
	tbnz	w9, #31, LBB71_357
; %bb.188:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldrh	w25, [x8, #16]
	subs	w8, w25, w28
	b.lo	LBB71_354
; %bb.189:                              ;   in Loop: Header=BB71_148 Depth=1
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	add	w8, w8, w9
	stp	w8, w9, [sp, #52]               ; 8-byte Folded Spill
	cmp	w8, #256
	b.hi	LBB71_355
; %bb.190:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x24, x26
	mov	x21, x5
	mov	x27, x4
	mov	x26, x3
	add	x1, sp, #252
	mov	x0, x22
	bl	_la_scalar
	tbnz	w0, #31, LBB71_201
; %bb.191:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w28, #3
	mov	w1, #1                          ; =0x1
	ldr	x3, [sp, #104]                  ; 8-byte Folded Reload
	b.hs	LBB71_359
; %bb.192:                              ;   in Loop: Header=BB71_148 Depth=1
	lsl	w0, w1, w0
	ldr	x4, [sp, #128]                  ; 8-byte Folded Reload
	strb	w28, [x4, #96]
	cmp	w25, w3
	mov	x2, x22
	ldr	x14, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	b.ls	LBB71_214
; %bb.193:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #0                          ; =0x0
	add	x9, x4, #88
	ldrh	w10, [sp, #252]
	add	w12, w2, #40
	mov	w13, #12                        ; =0xc
	umull	x11, w11, w13
	umaddl	x11, w3, w13, x11
	add	x11, x14, x11
	add	x11, x11, #9
	and	w12, w12, #0xff
	mov	x13, x3
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
	b	LBB71_196
LBB71_194:                              ;   in Loop: Header=BB71_196 Depth=2
	lsl	w14, w1, w8
	ldrb	w15, [x4, #97]
	orr	w14, w15, w14
	strb	w14, [x4, #97]
LBB71_195:                              ;   in Loop: Header=BB71_196 Depth=2
	add	x11, x11, #12
	add	x13, x13, #1
	add	w8, w8, #1
	add	x9, x9, #2
	cmp	x13, x25
	b.hs	LBB71_215
LBB71_196:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w14, [x11, #-9]
	ldurb	w15, [x11, #-1]
	ldrb	w16, [x11]
	sub	w17, w14, #1
	cmp	w15, #0
	ccmp	w16, #0, #0, eq
	ccmp	w17, #31, #2, eq
	b.hs	LBB71_345
; %bb.197:                              ;   in Loop: Header=BB71_196 Depth=2
	ldrh	w15, [x9]
	orr	w15, w15, w14
	strh	w15, [x9]
	strh	w10, [x9, #4]
	cbz	w10, LBB71_195
; %bb.198:                              ;   in Loop: Header=BB71_196 Depth=2
	cmp	w14, w10
	b.eq	LBB71_195
; %bb.199:                              ;   in Loop: Header=BB71_196 Depth=2
	cmp	w12, #5
	b.hi	LBB71_348
; %bb.200:                              ;   in Loop: Header=BB71_196 Depth=2
	and	w14, w14, #0x1e
	cmp	w14, #8
	b.eq	LBB71_194
	b	LBB71_348
LBB71_201:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w22, #252
	mov	w11, #1                         ; =0x1
	ldr	x3, [sp, #104]                  ; 8-byte Folded Reload
	b.hi	LBB71_393
; %bb.202:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x2, x22
	mov	w13, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x0, #0                          ; =0x0
Lloh180:
	adrp	x12, lJTI71_1@PAGE
Lloh181:
	add	x12, x12, lJTI71_1@PAGEOFF
	adr	x9, LBB71_203
	ldrh	w10, [x12, x22, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB71_203:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w3, w8, x9
	ldrh	w9, [x8, #8]
	cbnz	w9, LBB71_374
; %bb.204:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w9, [x8]
	cmp	x9, #128
	b.ne	LBB71_374
; %bb.205:                              ;   in Loop: Header=BB71_148 Depth=1
	sub	w9, w2, #83
	and	w9, w9, #0xff
	cmp	w9, #1
	b.hi	LBB71_208
; %bb.206:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w9, [x8, #20]
	cbnz	w9, LBB71_381
; %bb.207:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w8, [x8, #12]
	cmp	x8, #2
	b.ne	LBB71_381
LBB71_208:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x8, #-65408                     ; =0xffffffffffff0080
	movk	x8, #0, lsl #16
	sub	x0, x8, #119
	cmp	w2, #84
	b.eq	LBB71_211
; %bb.209:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w2, #83
	b.eq	LBB71_214
; %bb.210:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w2, #81
	b.ne	LBB71_241
LBB71_211:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w25, w8, x9
	ldurh	w9, [x8, #-4]
	cbnz	w9, LBB71_386
; %bb.212:                              ;   in Loop: Header=BB71_148 Depth=1
	ldurh	w8, [x8, #-12]
	cmp	x8, #8
	b.ne	LBB71_386
; %bb.213:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w2, #83
	b.ne	LBB71_241
LBB71_214:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w28, #-1                        ; =0xffffffff
	b	LBB71_316
LBB71_215:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	lsr	w8, w0, #16
	mov	w28, #-1                        ; =0xffffffff
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB71_316
LBB71_216:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x12, [sp, #128]                 ; 8-byte Folded Reload
	strb	w11, [x12, #96]
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w3, w8, x9
	ldrh	w9, [x8]
	ldrh	w10, [x12, #88]
	orr	w9, w10, w9
	strh	w9, [x12, #88]
	mov	w9, #16                         ; =0x10
	strh	w9, [x12, #92]
	ldrh	w9, [x8, #8]
	cbnz	w9, LBB71_376
; %bb.217:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w8, [x8]
	cmp	x8, #16
	b.eq	LBB71_224
	b	LBB71_376
LBB71_218:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrb	w9, [x26, #32]
	ldr	w10, [x26, #36]
	b	LBB71_246
LBB71_219:                              ;   in Loop: Header=BB71_148 Depth=1
	and	x12, x12, #0xffff
	mov	w8, #1                          ; =0x1
	mov	w14, #-1                        ; =0xffffffff
	cmp	x10, x14
	ccmp	x12, #0, #0, eq
	b.ne	LBB71_378
; %bb.220:                              ;   in Loop: Header=BB71_148 Depth=1
	lsl	w10, w8, w13
	eor	w10, w10, w11
	tst	w10, #0xffff
	b.ne	LBB71_378
; %bb.221:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w10, #-1                        ; =0xffffffff
	ldr	x27, [sp, #128]                 ; 8-byte Folded Reload
	b	LBB71_246
LBB71_222:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x12, [sp, #128]                 ; 8-byte Folded Reload
	strb	w11, [x12, #96]
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w3, w8, x9
	ldrh	w9, [x8]
	ldrh	w10, [x12, #88]
	orr	w9, w10, w9
	strh	w9, [x12, #88]
	mov	w9, #2                          ; =0x2
	strh	w9, [x12, #92]
	ldrh	w9, [x8, #8]
	cbnz	w9, LBB71_380
; %bb.223:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w8, [x8]
	cmp	x8, #2
	b.ne	LBB71_380
LBB71_224:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x0, #0                          ; =0x0
	b	LBB71_316
LBB71_225:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	ldr	w8, [x10, #12]
	mov	w9, #4194304                    ; =0x400000
	sub	w9, w9, w8
	cmp	w9, w25
	b.lo	LBB71_389
; %bb.226:                              ;   in Loop: Header=BB71_148 Depth=1
	add	w8, w8, w25
	str	w8, [x10, #12]
	ldr	x8, [x24, #40]
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x1, lsl #3
	ldr	w8, [x8, #4]
	ldr	w9, [x24, #16]
	cmp	w8, w9
	b.hs	LBB71_366
; %bb.227:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [x24, #24]
	ldrb	w9, [x9, x8]
	mov	w10, #3                         ; =0x3
	bics	wzr, w10, w9
	b.ne	LBB71_366
; %bb.228:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [x24, #8]
	lsl	x8, x8, #4
	ldrb	w8, [x9, x8]
	cbnz	w8, LBB71_366
; %bb.229:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x22, x2
	cbz	w25, LBB71_248
; %bb.230:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #64]                  ; 8-byte Folded Reload
	umaddl	x8, w10, w8, x9
	add	x8, x8, #8
	b	LBB71_232
LBB71_231:                              ;   in Loop: Header=BB71_232 Depth=2
	add	x8, x8, #12
	subs	x25, x25, #1
	b.eq	LBB71_248
LBB71_232:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x8]
	cmp	w9, #2
	b.ne	LBB71_231
; %bb.233:                              ;   in Loop: Header=BB71_232 Depth=2
	ldurh	w9, [x8, #-6]
	cmp	w9, w1
	b.ne	LBB71_231
	b	LBB71_366
LBB71_234:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w21, #3
	b.ne	LBB71_390
; %bb.235:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w25, w3
	b.ls	LBB71_294
; %bb.236:                              ;   in Loop: Header=BB71_148 Depth=1
	sub	x8, x25, w3, uxtw
	mov	w10, #12                        ; =0xc
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	umull	x9, w9, w10
	umaddl	x9, w3, w10, x9
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	add	x9, x10, x9
	add	x9, x9, #8
LBB71_237:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w10, [x9]
	cbnz	w10, LBB71_365
; %bb.238:                              ;   in Loop: Header=BB71_237 Depth=2
	ldurh	w10, [x9, #-8]
	cmp	x10, #8
	b.ne	LBB71_365
; %bb.239:                              ;   in Loop: Header=BB71_237 Depth=2
	add	x9, x9, #12
	subs	x8, x8, #1
	b.ne	LBB71_237
; %bb.240:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w28, #-1                        ; =0xffffffff
	ldr	x3, [sp, #104]                  ; 8-byte Folded Reload
	b	LBB71_295
LBB71_241:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x10, #-65408                    ; =0xffffffffffff0080
	movk	x10, #0, lsl #16
	sub	x9, x10, #126
	cmp	w2, #85
	csel	x0, x9, x10, eq
	mov	w28, #-1                        ; =0xffffffff
	b	LBB71_316
LBB71_242:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
LBB71_243:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #1                          ; =0x1
	cbz	w13, LBB71_378
; %bb.244:                              ;   in Loop: Header=BB71_148 Depth=1
	and	x12, x12, #0xffff
	cmp	x12, #1
	b.ne	LBB71_378
; %bb.245:                              ;   in Loop: Header=BB71_148 Depth=1
	lsr	x12, x11, #32
	and	x11, x11, #0xffff
	cmp	x11, #256
	ccmp	x12, x10, #0, eq
Lloh182:
	adrp	x11, l_.str.87@PAGE
Lloh183:
	add	x11, x11, l_.str.87@PAGEOFF
	ldr	x27, [sp, #128]                 ; 8-byte Folded Reload
	b.ne	LBB71_357
LBB71_246:                              ;   in Loop: Header=BB71_148 Depth=1
	orr	x1, x9, x10, lsl #32
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_nvm_affine_can_exit_type
	tbz	w0, #0, LBB71_368
; %bb.247:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
	ldr	x0, [x21]
	bl	_nvm_affine_state_free
	ldr	x0, [x21, #8]
	bl	_free
	mov	x0, x21
	bl	_free
	b	LBB71_325
LBB71_248:                              ;   in Loop: Header=BB71_148 Depth=1
	add	x2, sp, #304
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_take_local
	tbz	w0, #0, LBB71_366
; %bb.249:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w22, #11
	b.ne	LBB71_296
; %bb.250:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #0                          ; =0x0
	ldr	w28, [sp, #308]
	mov	w9, #256                        ; =0x100
	orr	x0, x9, x28, lsl #32
	mov	w13, #1                         ; =0x1
	b	LBB71_309
LBB71_251:                              ;   in Loop: Header=BB71_148 Depth=1
	str	x2, [sp, #80]                   ; 8-byte Folded Spill
	mov	w28, #1                         ; =0x1
	ldr	w8, [x27]
	lsl	x8, x8, #4
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x9, x8]
	ldr	x21, [x8]
	ldrh	w22, [x21, #58]
	cbz	x22, LBB71_255
; %bb.252:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x26, x24
	ldr	x23, [x21, #40]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	mov	x24, x8
                                        ; implicit-def: $x25
LBB71_253:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w24, w8, x9
	ldr	x1, [x8]
	ldr	w8, [x8, #8]
	and	x9, x25, #0xffffffff00000000
	orr	x25, x9, x8
	ldr	x3, [x23], #8
	mov	x0, x26
	mov	x2, x25
	bl	_la_type
	tbz	w0, #0, LBB71_373
; %bb.254:                              ;   in Loop: Header=BB71_253 Depth=2
	add	w24, w24, #1
	subs	x22, x22, #1
	b.ne	LBB71_253
LBB71_255:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrb	w8, [x21, #32]
	cmp	x8, #8
	b.ne	LBB71_312
; %bb.256:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w8, [x21, #36]
	mov	w9, #256                        ; =0x100
	orr	x0, x9, x8, lsl #32
	mov	w13, #1                         ; =0x1
	b	LBB71_313
LBB71_257:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w12, #1                         ; =0x1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x9, w3, w8, x9
	ldrb	w8, [x9, #8]
	cmp	w8, #2
	b.ne	LBB71_377
; %bb.258:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrb	w8, [x9, #9]
	cbnz	w8, LBB71_377
; %bb.259:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrh	w8, [x9, #2]
	ldr	x10, [sp, #64]                  ; 8-byte Folded Reload
	cmp	w8, w10
	b.hs	LBB71_377
; %bb.260:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x10, [x10, #8]
	ldrb	w10, [x10, x8]
	cmp	w10, #1
	b.ne	LBB71_377
; %bb.261:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w9, [x9, #4]
	ldr	w10, [x24, #16]
	cmp	w9, w10
	b.hs	LBB71_377
; %bb.262:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x10, [x24, #24]
	ldrb	w10, [x10, x9]
	mov	w11, #3                         ; =0x3
	bics	wzr, w11, w10
	b.ne	LBB71_377
; %bb.263:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x10, [x24, #8]
	lsl	x11, x9, #4
	ldrb	w11, [x10, x11]
	cbnz	w11, LBB71_377
; %bb.264:                              ;   in Loop: Header=BB71_148 Depth=1
	add	x9, x10, x9, lsl #4
	ldrh	w10, [x9, #2]
	cmp	w10, w23, uxth
	b.ls	LBB71_377
; %bb.265:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [x9, #8]
	and	x10, x23, #0xffff
	mov	w11, #12                        ; =0xc
	umaddl	x10, w10, w11, x9
	ldrb	w9, [x10]
	cmp	w9, #8
	b.ne	LBB71_310
; %bb.266:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w10, [x10, #4]
	mov	w11, #256                       ; =0x100
	orr	x0, x11, x10, lsl #32
	mov	w13, #2                         ; =0x2
	b	LBB71_311
LBB71_267:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w25, w8, x9
	ldur	x9, [x8, #-12]
	ldur	w10, [x8, #-4]
	ldur	x11, [x8, #-24]
	stur	x11, [x8, #-12]
	ldur	w11, [x8, #-16]
	stur	w11, [x8, #-4]
	stur	x9, [x8, #-24]
	stur	w10, [x8, #-16]
	b	LBB71_318
LBB71_268:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w25, w8, x9
	ldurb	w9, [x8, #-4]
	cbnz	w9, LBB71_394
; %bb.269:                              ;   in Loop: Header=BB71_148 Depth=1
	ldur	x9, [x8, #-12]
	str	x9, [x8]
	ldur	w9, [x8, #-4]
	str	w9, [x8, #8]
	add	w8, w25, #1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	strh	w8, [x9, #16]
	b	LBB71_318
LBB71_270:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x22, x2
	ldr	x8, [x24, #40]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #3
	ldrb	w23, [x8]
	ldr	w28, [x8, #4]
	cmp	w23, #8
	b.ne	LBB71_303
; %bb.271:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w8, [x24, #16]
	cmp	w28, w8
	b.hs	LBB71_392
; %bb.272:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x24, #24]
	ldrb	w8, [x8, x28]
	mov	w9, #3                          ; =0x3
	bics	wzr, w9, w8
	b.ne	LBB71_392
; %bb.273:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x24, #8]
	lsl	x9, x28, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB71_392
; %bb.274:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	tbz	w0, #0, LBB71_392
; %bb.275:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #256                        ; =0x100
	orr	x0, x8, x28, lsl #32
	mov	w13, #2                         ; =0x2
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB71_309
LBB71_276:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w28, #-1                        ; =0xffffffff
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	b	LBB71_316
LBB71_277:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w25, w8, x9
	ldur	x9, [x8, #-12]
	ldur	w10, [x8, #-4]
	ldur	x11, [x8, #-24]
	stur	x11, [x8, #-12]
	ldur	w11, [x8, #-16]
	stur	w11, [x8, #-4]
	ldur	x11, [x8, #-36]
	stur	x11, [x8, #-24]
	ldur	w11, [x8, #-28]
	stur	w11, [x8, #-16]
	stur	x9, [x8, #-36]
	stur	w10, [x8, #-28]
	b	LBB71_318
LBB71_278:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w3, w8, x9
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB71_395
; %bb.279:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	b	LBB71_315
LBB71_280:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x24, #40]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #3
	ldrb	w9, [x8]
	cmp	w9, #8
	b.ne	LBB71_388
; %bb.281:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x22, x2
	mov	w9, #12                         ; =0xc
	ldp	x11, x10, [sp, #104]            ; 16-byte Folded Reload
	umaddl	x9, w11, w9, x10
	ldr	x28, [x9]
	ldr	w2, [x9, #8]
	ldr	x3, [x8]
	mov	x0, x24
	mov	x1, x28
	bl	_la_type
	cbz	w0, LBB71_388
; %bb.282:                              ;   in Loop: Header=BB71_148 Depth=1
	and	x8, x28, #0xffffffff00000000
	orr	x2, x8, #0x8
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_put_local
	tbz	w0, #0, LBB71_388
; %bb.283:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x0, #0                          ; =0x0
	b	LBB71_309
LBB71_284:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x8, [x24, #40]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #3
	ldrb	w26, [x8]
	cmp	w26, #8
	b.eq	LBB71_391
; %bb.285:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w9, #12                         ; =0xc
	ldp	x11, x10, [sp, #104]            ; 16-byte Folded Reload
	umaddl	x9, w11, w9, x10
	ldr	w23, [x9, #8]
	and	w10, w23, #0xff
	cbnz	w10, LBB71_391
; %bb.286:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x22, x2
	ldr	x1, [x9]
	ldrb	w9, [x8, #7]
	ldurh	w10, [x8, #5]
	orr	w9, w10, w9, lsl #16
	ldur	w8, [x8, #1]
	lsl	x8, x8, #8
	orr	x8, x8, x9, lsl #40
	orr	x3, x8, x26
	mov	x0, x24
	mov	x25, x1
	mov	x2, x23
	bl	_la_type
	tbz	w0, #0, LBB71_391
; %bb.287:                              ;   in Loop: Header=BB71_148 Depth=1
	sub	w8, w26, #1
	cmp	w8, #3
	b.hi	LBB71_306
; %bb.288:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_scalar_define
	tbnz	w0, #0, LBB71_308
	b	LBB71_408
LBB71_289:                              ;   in Loop: Header=BB71_148 Depth=1
	str	x2, [sp, #80]                   ; 8-byte Folded Spill
	tst	w26, #0xffff
	b.eq	LBB71_293
; %bb.290:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x8, x26
	and	x21, x8, #0xffff
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	mov	x22, x8
	ldr	x23, [sp, #16]                  ; 8-byte Folded Reload
                                        ; implicit-def: $x25
LBB71_291:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w8, #12                         ; =0xc
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	umaddl	x8, w22, w8, x9
	ldurb	w9, [x23, #-4]
	ldr	x1, [x8]
	ldr	w8, [x8, #8]
	and	x10, x25, #0xffffffff00000000
	orr	x25, x10, x8
	ldr	w8, [x23], #8
	orr	x3, x9, x8, lsl #32
	mov	x0, x24
	mov	x2, x25
	bl	_la_type
	tbz	w0, #0, LBB71_372
; %bb.292:                              ;   in Loop: Header=BB71_291 Depth=2
	add	w22, w22, #1
	subs	x21, x21, #1
	b.ne	LBB71_291
LBB71_293:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w8, #0                          ; =0x0
	ldr	w28, [x27]
	mov	w9, #256                        ; =0x100
	orr	x0, x9, x28, lsl #32
	mov	w13, #1                         ; =0x1
	b	LBB71_314
LBB71_294:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w28, #-1                        ; =0xffffffff
LBB71_295:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x0, #-65408                     ; =0xffffffffffff0080
	movk	x0, #0, lsl #16
	b	LBB71_316
LBB71_296:                              ;   in Loop: Header=BB71_148 Depth=1
	tst	w26, #0xffff
	ldr	x13, [sp, #168]                 ; 8-byte Folded Reload
	mov	w15, #1                         ; =0x1
	mov	w16, #256                       ; =0x100
	b.eq	LBB71_302
; %bb.297:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x8, x26
	and	x8, x8, #0xffff
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	b	LBB71_300
LBB71_298:                              ;   in Loop: Header=BB71_300 Depth=2
	mov	w11, #0                         ; =0x0
	lsl	x12, x15, x12
	and	w12, w12, #0xffff
	orr	x12, x12, #0xffffffff00000000
LBB71_299:                              ;   in Loop: Header=BB71_300 Depth=2
	mov	w14, #12                        ; =0xc
	ldr	x17, [sp, #112]                 ; 8-byte Folded Reload
	umaddl	x10, w10, w14, x17
	str	x12, [x10]
	str	w11, [x10, #8]
	add	x9, x9, #8
	subs	x8, x8, #1
	b.eq	LBB71_302
LBB71_300:                              ;   Parent Loop BB71_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w10, [x13, #16]
	add	w11, w10, #1
	strh	w11, [x13, #16]
	ldurb	w12, [x9, #-4]
	cmp	x12, #8
	b.ne	LBB71_298
; %bb.301:                              ;   in Loop: Header=BB71_300 Depth=2
	ldr	w11, [x9]
	orr	x12, x16, x11, lsl #32
	mov	w11, #1                         ; =0x1
	b	LBB71_299
LBB71_302:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x2, x22
	b	LBB71_318
LBB71_303:                              ;   in Loop: Header=BB71_148 Depth=1
	ldrb	w9, [x8, #3]
	ldurh	w8, [x8, #1]
	mov	w10, #12                        ; =0xc
	ldr	x11, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x12, [sp, #40]                  ; 8-byte Folded Reload
	umaddl	x10, w12, w10, x11
	ldr	x25, [x10]
	lsl	x8, x8, #8
	ldr	w21, [x10, #8]
	orr	x8, x8, x9, lsl #24
	orr	x9, x23, x28, lsl #32
	orr	x3, x9, x8
	mov	x0, x24
	mov	x1, x25
	mov	x2, x21
	bl	_la_type
	cbz	w0, LBB71_397
; %bb.304:                              ;   in Loop: Header=BB71_148 Depth=1
	lsr	x8, x25, #16
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	mov	x0, x25
	lsr	x28, x25, #32
	sub	w9, w23, #1
	cmp	w9, #4
	b.hi	LBB71_326
; %bb.305:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #8]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	ldrb	w9, [x9, x10]
	mov	x2, x22
	ldr	x3, [sp, #104]                  ; 8-byte Folded Reload
	mov	x13, x21
	tbnz	w9, #0, LBB71_316
	b	LBB71_397
LBB71_306:                              ;   in Loop: Header=BB71_148 Depth=1
	cmp	w26, #5
	b.ne	LBB71_308
; %bb.307:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_string_define
	tbz	w0, #0, LBB71_409
LBB71_308:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x0, x25
	lsr	x8, x25, #16
	lsr	x28, x25, #32
	mov	w9, #12                         ; =0xc
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	umaddl	x9, w11, w9, x10
	str	x25, [x9]
	str	w23, [x9, #8]
	mov	x13, x23
LBB71_309:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x2, x22
	b	LBB71_315
LBB71_310:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	lsl	x10, x12, x9
	and	w10, w10, #0xffff
	orr	x0, x10, #0xffffffff00000000
LBB71_311:                              ;   in Loop: Header=BB71_148 Depth=1
	lsr	x10, x0, #16
	lsr	x28, x0, #32
	cmp	w9, #8
	csel	w8, w8, w10, eq
	b	LBB71_315
LBB71_312:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w13, #0                         ; =0x0
	lsl	x8, x28, x8
	and	w8, w8, #0xffff
	orr	x0, x8, #0xffffffff00000000
LBB71_313:                              ;   in Loop: Header=BB71_148 Depth=1
	lsr	x8, x0, #16
	lsr	x28, x0, #32
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
LBB71_314:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x2, [sp, #80]                   ; 8-byte Folded Reload
LBB71_315:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x3, [sp, #104]                  ; 8-byte Folded Reload
LBB71_316:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	w10, [sp, #52]                  ; 4-byte Folded Reload
	strh	w10, [x9, #16]
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	cbz	w9, LBB71_318
; %bb.317:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	w9, #12                         ; =0xc
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	umaddl	x9, w3, w9, x10
	lsl	w8, w8, #16
	orr	x8, x8, x28, lsl #32
	bfxil	x8, x0, #0, #16
	str	x8, [x9]
	str	w13, [x9, #8]
LBB71_318:                              ;   in Loop: Header=BB71_148 Depth=1
	ldp	x21, x22, [sp, #160]            ; 16-byte Folded Reload
	ldrh	w8, [x22, #16]
	ldr	x10, [x21, #8]
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	mov	w11, #116                       ; =0x74
	umull	x9, w9, w11
	add	x10, x10, #40
	ldrh	w11, [x10, x9]
	cmp	w8, w11
	b.ls	LBB71_320
; %bb.319:                              ;   in Loop: Header=BB71_148 Depth=1
	strh	w8, [x10, x9]
LBB71_320:                              ;   in Loop: Header=BB71_148 Depth=1
	sub	w8, w2, #56
	cmp	w8, #2
	ldr	x24, [sp, #128]                 ; 8-byte Folded Reload
	b.hi	LBB71_323
; %bb.321:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w1, [x24, #76]
	mov	x0, x21
	mov	x23, x2
	mov	x2, x22
	bl	_la_join
	mov	x25, x0
	cmp	w23, #56
	b.eq	LBB71_324
; %bb.322:                              ;   in Loop: Header=BB71_148 Depth=1
	cbz	w25, LBB71_324
LBB71_323:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	w1, [x24, #72]
	mov	x0, x21
	mov	x2, x22
	bl	_la_join
	mov	x25, x0
LBB71_324:                              ;   in Loop: Header=BB71_148 Depth=1
	ldr	x0, [x22]
	bl	_nvm_affine_state_free
	ldr	x0, [x22, #8]
	bl	_free
	mov	x0, x22
	bl	_free
	cbz	w25, LBB71_414
LBB71_325:                              ;   in Loop: Header=BB71_148 Depth=1
	ldp	x1, x21, [sp, #152]             ; 16-byte Folded Reload
	ldr	w8, [x1, #8]
	cbnz	w8, LBB71_148
	b	LBB71_328
LBB71_326:                              ;   in Loop: Header=BB71_148 Depth=1
	mov	x2, x22
	ldr	x3, [sp, #104]                  ; 8-byte Folded Reload
	mov	x13, x21
	b	LBB71_316
LBB71_327:
Lloh184:
	adrp	x8, lCPI71_1@PAGE
Lloh185:
	ldr	q0, [x8, lCPI71_1@PAGEOFF]
	str	q0, [x27, #16]
Lloh186:
	adrp	x8, l_.str.69@PAGE
Lloh187:
	add	x8, x8, l_.str.69@PAGEOFF
	str	x8, [x27, #32]
	b	LBB71_414
LBB71_328:
	ldr	x2, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w8, [x2]
	cbz	w8, LBB71_341
; %bb.329:
	add	x9, x21, #224
	mov	x10, x8
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
LBB71_330:                              ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x9]
	cbz	x11, LBB71_344
; %bb.331:                              ;   in Loop: Header=BB71_330 Depth=1
	add	x9, x9, #104
	subs	x10, x10, #1
	b.ne	LBB71_330
; %bb.332:
	ldr	w9, [x2, #12]
	sub	w11, w9, #1024, lsl #12         ; =4194304
	sub	w11, w11, #1
	mov	w12, #104                       ; =0x68
	umull	x12, w8, w12
	mov	w13, #25564                     ; =0x63dc
	add	x13, x0, x13
LBB71_333:                              ; =>This Inner Loop Header: Depth=1
	cmn	w11, #2
	b.hs	LBB71_360
; %bb.334:                              ;   in Loop: Header=BB71_333 Depth=1
	add	w9, w9, #2
	str	w9, [x2, #12]
	ldurb	w15, [x13, #-1]
	add	x14, x21, x10
	ldrb	w16, [x14, #240]
	cmp	w15, w16
	b.ne	LBB71_346
; %bb.335:                              ;   in Loop: Header=BB71_333 Depth=1
	ldrb	w15, [x13]
	ldrb	w16, [x14, #241]
	cmp	w15, w16
	b.ne	LBB71_346
; %bb.336:                              ;   in Loop: Header=BB71_333 Depth=1
	ldurh	w16, [x13, #-10]
	add	x15, x21, x10
	ldrh	w17, [x15, #232]
	cmp	w16, w17
	b.ne	LBB71_346
; %bb.337:                              ;   in Loop: Header=BB71_333 Depth=1
	ldurh	w16, [x13, #-8]
	ldrh	w15, [x15, #234]
	cmp	w16, w15
	b.ne	LBB71_346
; %bb.338:                              ;   in Loop: Header=BB71_333 Depth=1
	ldurh	w16, [x13, #-6]
	add	x15, x21, x10
	ldrh	w17, [x15, #236]
	cmp	w16, w17
	b.ne	LBB71_346
; %bb.339:                              ;   in Loop: Header=BB71_333 Depth=1
	ldurh	w16, [x13, #-4]
	ldrh	w15, [x15, #238]
	cmp	w16, w15
	b.ne	LBB71_346
; %bb.340:                              ;   in Loop: Header=BB71_333 Depth=1
	add	x10, x10, #104
	add	w11, w11, #2
	add	x13, x13, #28
	cmp	x12, x10
	b.ne	LBB71_333
	b	LBB71_342
LBB71_341:
	ldr	w9, [x2, #12]
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
LBB71_342:
	ldr	w10, [x20, #272]
	stp	w10, w8, [x0, #16]
	ldur	d0, [x2, #4]
	str	d0, [x0, #24]
	str	w9, [x0, #32]
	stp	xzr, xzr, [x1, #16]
Lloh188:
	adrp	x8, l_.str.13@PAGE
Lloh189:
	add	x8, x8, l_.str.13@PAGEOFF
	b	LBB71_361
LBB71_343:
	mov	x0, x23
	bl	_free
	b	LBB71_133
LBB71_344:
	mov	w8, #1                          ; =0x1
	str	w8, [x1, #16]
	ldur	d0, [x9, #-16]
	stur	d0, [x1, #20]
	str	wzr, [x1, #28]
Lloh190:
	adrp	x8, l_.str.11@PAGE
Lloh191:
	add	x8, x8, l_.str.11@PAGEOFF
	b	LBB71_361
LBB71_345:
	ldr	w8, [x4, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh192:
	adrp	x8, l_.str.91@PAGE
Lloh193:
	add	x8, x8, l_.str.91@PAGEOFF
	b	LBB71_349
LBB71_346:
	mov	w8, #1                          ; =0x1
	str	w8, [x1, #16]
	ldr	d0, [x14, #208]
	stur	d0, [x1, #20]
	str	wzr, [x1, #28]
Lloh194:
	adrp	x8, l_.str.12@PAGE
Lloh195:
	add	x8, x8, l_.str.12@PAGEOFF
	b	LBB71_361
LBB71_347:
	mov	w8, #1                          ; =0x1
Lloh196:
	adrp	x11, l_.str.86@PAGE
Lloh197:
	add	x11, x11, l_.str.86@PAGEOFF
	b	LBB71_357
LBB71_348:
	ldr	w8, [x4, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh198:
	adrp	x8, l_.str.92@PAGE
Lloh199:
	add	x8, x8, l_.str.92@PAGEOFF
LBB71_349:
	str	x8, [x10, #32]
	b	LBB71_412
LBB71_350:
Lloh200:
	adrp	x8, lCPI71_2@PAGE
Lloh201:
	ldr	q0, [x8, lCPI71_2@PAGEOFF]
	str	q0, [x1, #16]
Lloh202:
	adrp	x8, l_.str.9@PAGE
Lloh203:
	add	x8, x8, l_.str.9@PAGEOFF
	b	LBB71_361
LBB71_351:
Lloh204:
	adrp	x8, lCPI71_2@PAGE
Lloh205:
	ldr	q0, [x8, lCPI71_2@PAGEOFF]
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	str	q0, [x8, #16]
Lloh206:
	adrp	x9, l_.str.84@PAGE
Lloh207:
	add	x9, x9, l_.str.84@PAGEOFF
	str	x9, [x8, #32]
	b	LBB71_414
LBB71_352:
	ldr	w8, [x27, #68]
	mov	w11, #4                         ; =0x4
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh208:
	adrp	x8, l_.str.10@PAGE
Lloh209:
	add	x8, x8, l_.str.10@PAGEOFF
	str	x8, [x10, #32]
	b	LBB71_414
LBB71_353:
	ldr	w8, [x27, #68]
	mov	w11, #2                         ; =0x2
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh210:
	adrp	x8, l_.str.85@PAGE
Lloh211:
	add	x8, x8, l_.str.85@PAGEOFF
	str	x8, [x10, #32]
	ldr	x0, [x28]
	bl	_nvm_affine_state_free
	ldr	x0, [x28, #8]
	bl	_free
	mov	x0, x28
	b	LBB71_413
LBB71_354:
	mov	w8, #2                          ; =0x2
	b	LBB71_357
LBB71_355:
	mov	w8, #3                          ; =0x3
Lloh212:
	adrp	x11, l_.str.89@PAGE
Lloh213:
	add	x11, x11, l_.str.89@PAGEOFF
LBB71_356:
	ldr	x27, [sp, #128]                 ; 8-byte Folded Reload
LBB71_357:
	ldr	w9, [x27, #68]
LBB71_358:
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	str	w8, [x10, #16]
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	stp	w8, w9, [x10, #20]
	str	wzr, [x10, #28]
	str	x11, [x10, #32]
	b	LBB71_411
LBB71_359:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #2                         ; =0x2
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh214:
	adrp	x8, l_.str.90@PAGE
Lloh215:
	add	x8, x8, l_.str.90@PAGEOFF
	b	LBB71_410
LBB71_360:
Lloh216:
	adrp	x8, lCPI71_2@PAGE
Lloh217:
	ldr	q0, [x8, lCPI71_2@PAGEOFF]
	str	q0, [x1, #16]
Lloh218:
	adrp	x8, l_.str.84@PAGE
Lloh219:
	add	x8, x8, l_.str.84@PAGEOFF
LBB71_361:
	str	x8, [x1, #32]
	b	LBB71_414
LBB71_362:
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w9, w8, [x27, #16]
Lloh220:
	adrp	x8, l_.str.72@PAGE
Lloh221:
	add	x8, x8, l_.str.72@PAGEOFF
	stp	xzr, x8, [x27, #24]
	b	LBB71_414
LBB71_363:
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w10, w8, [x9, #16]
Lloh222:
	adrp	x8, l_.str.77@PAGE
Lloh223:
	add	x8, x8, l_.str.77@PAGEOFF
	stp	xzr, x8, [x9, #24]
	b	LBB71_414
LBB71_364:
	str	xzr, [sp, #120]                 ; 8-byte Folded Spill
	mov	w9, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
Lloh224:
	adrp	x11, l_.str.84@PAGE
Lloh225:
	add	x11, x11, l_.str.84@PAGEOFF
	b	LBB71_358
LBB71_365:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh226:
	adrp	x8, l_.str.105@PAGE
Lloh227:
	add	x8, x8, l_.str.105@PAGEOFF
	b	LBB71_410
LBB71_366:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
Lloh228:
	adrp	x9, l_.str.100@PAGE
Lloh229:
	add	x9, x9, l_.str.100@PAGEOFF
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	mov	w9, #1                          ; =0x1
LBB71_367:
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	str	w9, [x10, #16]
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w9, w8, [x10, #20]
	str	wzr, [x10, #28]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	b	LBB71_410
LBB71_368:
	mov	w8, #1                          ; =0x1
Lloh230:
	adrp	x11, l_.str.87@PAGE
Lloh231:
	add	x11, x11, l_.str.87@PAGEOFF
	b	LBB71_357
LBB71_369:
	mov	w10, #2                         ; =0x2
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w10, w8, [x9, #16]
	stp	w22, wzr, [x9, #24]
Lloh232:
	adrp	x8, l_.str.68@PAGE
Lloh233:
	add	x8, x8, l_.str.68@PAGEOFF
	str	x8, [x9, #32]
	b	LBB71_414
LBB71_370:
Lloh234:
	adrp	x8, l_.str.76@PAGE
Lloh235:
	add	x8, x8, l_.str.76@PAGEOFF
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
LBB71_371:
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w10, w8, [x9, #16]
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	stp	xzr, x8, [x9, #24]
	b	LBB71_414
LBB71_372:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh236:
	adrp	x8, l_.str.102@PAGE
Lloh237:
	add	x8, x8, l_.str.102@PAGEOFF
	b	LBB71_410
LBB71_373:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh238:
	adrp	x8, l_.str.109@PAGE
Lloh239:
	add	x8, x8, l_.str.109@PAGEOFF
	b	LBB71_410
LBB71_374:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh240:
	adrp	x8, l_.str.106@PAGE
Lloh241:
	add	x8, x8, l_.str.106@PAGEOFF
	b	LBB71_410
LBB71_375:
	mov	w8, #3                          ; =0x3
Lloh242:
	adrp	x9, l_.str.74@PAGE
Lloh243:
	add	x9, x9, l_.str.74@PAGEOFF
	b	LBB71_383
LBB71_376:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh244:
	adrp	x8, l_.str.111@PAGE
Lloh245:
	add	x8, x8, l_.str.111@PAGEOFF
	b	LBB71_410
LBB71_377:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh246:
	adrp	x8, l_.str.103@PAGE
Lloh247:
	add	x8, x8, l_.str.103@PAGEOFF
	b	LBB71_410
LBB71_378:
Lloh248:
	adrp	x11, l_.str.87@PAGE
Lloh249:
	add	x11, x11, l_.str.87@PAGEOFF
	b	LBB71_356
LBB71_379:
	mov	w8, #2                          ; =0x2
	b	LBB71_384
LBB71_380:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh250:
	adrp	x8, l_.str.110@PAGE
Lloh251:
	add	x8, x8, l_.str.110@PAGEOFF
	b	LBB71_410
LBB71_381:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh252:
	adrp	x8, l_.str.107@PAGE
Lloh253:
	add	x8, x8, l_.str.107@PAGEOFF
	b	LBB71_410
LBB71_382:
	str	xzr, [sp, #168]                 ; 8-byte Folded Spill
	mov	w8, #3                          ; =0x3
Lloh254:
	adrp	x9, l_.str.84@PAGE
Lloh255:
	add	x9, x9, l_.str.84@PAGEOFF
LBB71_383:
	str	x9, [sp, #80]                   ; 8-byte Folded Spill
LBB71_384:
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	str	w8, [x9, #16]
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	str	w8, [x9, #20]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	stp	xzr, x8, [x9, #24]
	b	LBB71_414
LBB71_385:
	mov	w10, #3                         ; =0x3
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w10, w8, [x9, #16]
	stp	w22, wzr, [x9, #24]
Lloh256:
	adrp	x8, l_.str.66@PAGE
Lloh257:
	add	x8, x8, l_.str.66@PAGEOFF
	str	x8, [x9, #32]
	b	LBB71_414
LBB71_386:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh258:
	adrp	x8, l_.str.108@PAGE
Lloh259:
	add	x8, x8, l_.str.108@PAGEOFF
	b	LBB71_410
LBB71_387:
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	stp	w10, w8, [x9, #16]
	stp	w22, wzr, [x9, #24]
Lloh260:
	adrp	x8, l_.str.67@PAGE
Lloh261:
	add	x8, x8, l_.str.67@PAGEOFF
	str	x8, [x9, #32]
	b	LBB71_414
LBB71_388:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh262:
	adrp	x8, l_.str.101@PAGE
Lloh263:
	add	x8, x8, l_.str.101@PAGEOFF
	b	LBB71_410
LBB71_389:
	str	xzr, [sp, #120]                 ; 8-byte Folded Spill
	mov	w8, #0                          ; =0x0
	mov	w9, #3                          ; =0x3
	b	LBB71_367
LBB71_390:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh264:
	adrp	x8, l_.str.104@PAGE
Lloh265:
	add	x8, x8, l_.str.104@PAGEOFF
	b	LBB71_410
LBB71_391:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh266:
	adrp	x8, l_.str.97@PAGE
Lloh267:
	add	x8, x8, l_.str.97@PAGEOFF
	b	LBB71_410
LBB71_392:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh268:
	adrp	x8, l_.str.95@PAGE
Lloh269:
	add	x8, x8, l_.str.95@PAGEOFF
	b	LBB71_410
LBB71_393:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh270:
	adrp	x8, l_.str.112@PAGE
Lloh271:
	add	x8, x8, l_.str.112@PAGEOFF
	b	LBB71_410
LBB71_394:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh272:
	adrp	x8, l_.str.93@PAGE
Lloh273:
	add	x8, x8, l_.str.93@PAGEOFF
	b	LBB71_410
LBB71_395:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh274:
	adrp	x8, l_.str.94@PAGE
Lloh275:
	add	x8, x8, l_.str.94@PAGEOFF
	b	LBB71_410
LBB71_396:
	bl	___stack_chk_fail
LBB71_397:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh276:
	adrp	x8, l_.str.96@PAGE
Lloh277:
	add	x8, x8, l_.str.96@PAGEOFF
	b	LBB71_410
LBB71_398:                              ;   in Loop: Header=BB71_399 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB71_135
LBB71_399:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB71_403 Depth 2
                                        ;       Child Loop BB71_406 Depth 3
	ldr	x12, [sp, #56]                  ; 8-byte Folded Reload
	add	x13, x12, x9, lsl #4
	ldp	w12, w13, [x13]
	cmp	w12, w13
	b.hs	LBB71_398
; %bb.400:                              ;   in Loop: Header=BB71_399 Depth=1
	umaddl	x14, w12, w11, x10
	mov	x15, x12
	b	LBB71_403
LBB71_401:                              ;   in Loop: Header=BB71_403 Depth=2
	ldr	w17, [x17, #76]
	cmn	w17, #1
	b.eq	LBB71_425
LBB71_402:                              ;   in Loop: Header=BB71_403 Depth=2
	add	x15, x15, #1
	cmp	x15, x13
	b.eq	LBB71_398
LBB71_403:                              ;   Parent Loop BB71_399 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB71_406 Depth 3
	ldr	x16, [sp, #72]                  ; 8-byte Folded Reload
	madd	x17, x15, x11, x16
	ldrb	w16, [x17]
	sub	w16, w16, #56
	cmp	w16, #2
	b.hi	LBB71_402
; %bb.404:                              ;   in Loop: Header=BB71_403 Depth=2
	ldr	w16, [x17, #68]
	ldrsw	x0, [x17, #8]
	add	x0, x0, x16
	mov	x1, x14
	mov	x2, x12
	b	LBB71_406
LBB71_405:                              ;   in Loop: Header=BB71_406 Depth=3
	add	x2, x2, #1
	cmp	x13, x2
	b.eq	LBB71_401
LBB71_406:                              ;   Parent Loop BB71_399 Depth=1
                                        ;     Parent Loop BB71_403 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w3, [x1], #104
	cmp	x0, x3
	b.ne	LBB71_405
; %bb.407:                              ;   in Loop: Header=BB71_406 Depth=3
	str	w2, [x17, #76]
	b	LBB71_405
LBB71_408:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh278:
	adrp	x8, l_.str.98@PAGE
Lloh279:
	add	x8, x8, l_.str.98@PAGEOFF
	b	LBB71_410
LBB71_409:
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	stp	w11, w9, [x10, #16]
	stp	w8, wzr, [x10, #24]
Lloh280:
	adrp	x8, l_.str.99@PAGE
Lloh281:
	add	x8, x8, l_.str.99@PAGEOFF
LBB71_410:
	str	x8, [x10, #32]
LBB71_411:
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
LBB71_412:
	ldr	x0, [x21]
	bl	_nvm_affine_state_free
	ldr	x0, [x21, #8]
	bl	_free
	mov	x0, x21
LBB71_413:
	bl	_free
LBB71_414:
	ldr	x25, [sp, #144]                 ; 8-byte Folded Reload
	ldr	w8, [x25]
	ldr	x24, [sp, #160]                 ; 8-byte Folded Reload
	cbz	w8, LBB71_419
; %bb.415:
	mov	x21, #0                         ; =0x0
	add	x22, x24, #224
	b	LBB71_417
LBB71_416:                              ;   in Loop: Header=BB71_417 Depth=1
	add	x21, x21, #1
	cmp	x21, x8
	b.hs	LBB71_419
LBB71_417:                              ; =>This Inner Loop Header: Depth=1
	ldr	x23, [x22], #104
	cbz	x23, LBB71_416
; %bb.418:                              ;   in Loop: Header=BB71_417 Depth=1
	ldr	x0, [x23]
	bl	_nvm_affine_state_free
	ldr	x0, [x23, #8]
	bl	_free
	mov	x0, x23
	bl	_free
	ldr	w8, [x25]
	b	LBB71_416
LBB71_419:
	ldr	w8, [x20, #272]
	ldr	x23, [sp, #152]                 ; 8-byte Folded Reload
	cbz	w8, LBB71_422
; %bb.420:
	mov	x21, #0                         ; =0x0
	add	x22, x24, #24
LBB71_421:                              ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x22], #16
	bl	_nvm_affine_state_free
	add	x21, x21, #1
	ldr	w8, [x20, #272]
	cmp	x21, x8
	b.lo	LBB71_421
LBB71_422:
	ldur	q0, [x23, #16]
	str	q0, [x19]
	ldur	x8, [x23, #32]
	str	x8, [x19, #16]
	mov	x0, x24
	bl	_free
	ldr	w8, [x19]
	cbz	w8, LBB71_424
; %bb.423:
	ldr	x19, [sp, #136]                 ; 8-byte Folded Reload
	ldr	x0, [x19]
	bl	_nvm_owned_array_origins_free
	ldr	x0, [x19, #8]
	bl	_nvm_owned_array_layouts_free
	mov	x0, x19
	bl	_free
	b	LBB71_9
LBB71_424:
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	str	x9, [x8]
	b	LBB71_9
LBB71_425:
	mov	w8, #2                          ; =0x2
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	stp	w8, w9, [x10, #16]
	stp	w16, wzr, [x10, #24]
Lloh282:
	adrp	x8, l_.str.70@PAGE
Lloh283:
	add	x8, x8, l_.str.70@PAGEOFF
	str	x8, [x10, #32]
	b	LBB71_414
	.loh AdrpLdrGotLdr	Lloh154, Lloh155, Lloh156
	.loh AdrpAdd	Lloh157, Lloh158
	.loh AdrpLdrGotLdr	Lloh159, Lloh160, Lloh161
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh192, Lloh193
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdrp	Lloh200, Lloh202
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdrp	Lloh216, Lloh218
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdd	Lloh266, Lloh267
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpLdrGot	Lloh152, Lloh153
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI71_0:
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_387-LBB71_121)>>2
	.short	(LBB71_121-LBB71_121)>>2
	.p2align	1, 0x0
lJTI71_1:
	.short	(LBB71_316-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_276-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_268-LBB71_203)>>2
	.short	(LBB71_278-LBB71_203)>>2
	.short	(LBB71_267-LBB71_203)>>2
	.short	(LBB71_277-LBB71_203)>>2
	.short	(LBB71_225-LBB71_203)>>2
	.short	(LBB71_280-LBB71_203)>>2
	.short	(LBB71_289-LBB71_203)>>2
	.short	(LBB71_225-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_270-LBB71_203)>>2
	.short	(LBB71_284-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_316-LBB71_203)>>2
	.short	(LBB71_216-LBB71_203)>>2
	.short	(LBB71_216-LBB71_203)>>2
	.short	(LBB71_251-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_234-LBB71_203)>>2
	.short	(LBB71_203-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_203-LBB71_203)>>2
	.short	(LBB71_203-LBB71_203)>>2
	.short	(LBB71_203-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_234-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_222-LBB71_203)>>2
	.short	(LBB71_216-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_222-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_393-LBB71_203)>>2
	.short	(LBB71_257-LBB71_203)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function la_join
lCPI72_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI72_1:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_la_join:                               ; @la_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	add	x8, x0, #108, lsl #12           ; =442368
	add	x20, x8, #164
	add	x8, x0, #104, lsl #12           ; =425984
	add	x23, x8, #144
	ldr	w8, [x23]
	cmp	w1, w8
	b.hs	LBB72_3
; %bb.1:
	mov	w8, #104                        ; =0x68
	umaddl	x21, w1, w8, x0
	ldr	x8, [x0]
	ldr	x9, [x8, #256]
	ldr	w8, [x21, #208]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w8, w10, x9
	ldrh	w19, [x9, #16]
	ldrh	w9, [x2, #16]
	add	w10, w9, w19, lsl #1
	ldr	w11, [x23, #12]
	mov	w12, #4194304                   ; =0x400000
	sub	w12, w12, w11
	cmp	w10, w12
	b.ls	LBB72_6
; %bb.2:
	mov	w0, #0                          ; =0x0
Lloh284:
	adrp	x8, lCPI72_1@PAGE
Lloh285:
	ldr	q0, [x8, lCPI72_1@PAGEOFF]
	stur	q0, [x20, #12]
Lloh286:
	adrp	x8, l_.str.84@PAGE
Lloh287:
	add	x8, x8, l_.str.84@PAGEOFF
	b	LBB72_4
LBB72_3:
	mov	w0, #0                          ; =0x0
Lloh288:
	adrp	x8, lCPI72_0@PAGE
Lloh289:
	ldr	q0, [x8, lCPI72_0@PAGEOFF]
	stur	q0, [x20, #12]
Lloh290:
	adrp	x8, l_.str.78@PAGE
Lloh291:
	add	x8, x8, l_.str.78@PAGEOFF
LBB72_4:
	stur	x8, [x20, #28]
LBB72_5:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB72_6:
	add	w10, w10, w11
	str	w10, [x23, #12]
	ldur	x22, [x21, #224]
	cbz	x22, LBB72_14
; %bb.7:
	ldrh	w10, [x22, #16]
	cmp	w10, w9
	b.ne	LBB72_16
; %bb.8:
	adds	w9, w9, w19
	b.eq	LBB72_17
; %bb.9:
	ldr	x10, [x22, #8]
	ldr	x11, [x2, #8]
	add	x10, x10, #4
	add	x11, x11, #4
	b	LBB72_11
LBB72_10:                               ;   in Loop: Header=BB72_11 Depth=1
	add	x10, x10, #12
	add	x11, x11, #12
	subs	x9, x9, #1
	b.eq	LBB72_17
LBB72_11:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x10, #4]
	ldrb	w13, [x11, #4]
	and	w13, w13, #0xff
	orr	w14, w12, w13
	cbz	w14, LBB72_10
; %bb.12:                               ;   in Loop: Header=BB72_11 Depth=1
	ldrb	w14, [x11, #5]
	ldr	w15, [x11]
	ldurh	w16, [x11, #-2]
	ldurh	w17, [x11, #-4]
	ldrb	w3, [x10, #5]
	ldr	w4, [x10]
	ldurh	w5, [x10, #-2]
	ldurh	w6, [x10, #-4]
	cmp	w12, w13
	ccmp	w4, w15, #0, eq
	ccmp	w5, w16, #0, eq
	ccmp	w6, w17, #0, eq
	ccmp	w3, w14, #0, eq
	b.eq	LBB72_10
; %bb.13:
	mov	w0, #0                          ; =0x0
	ldur	w9, [x21, #212]
	mov	w10, #1                         ; =0x1
	stp	w10, w8, [x20, #12]
	stp	w9, wzr, [x20, #20]
Lloh292:
	adrp	x8, l_.str.82@PAGE
Lloh293:
	add	x8, x8, l_.str.82@PAGEOFF
	b	LBB72_4
LBB72_14:
	add	w22, w19, #256
	ldr	w9, [x23, #4]
	mov	w10, #1048576                   ; =0x100000
	sub	w9, w10, w9
	cmp	w22, w9
	b.ls	LBB72_21
; %bb.15:
	mov	w0, #0                          ; =0x0
	ldur	w9, [x21, #212]
	mov	w10, #3                         ; =0x3
	stp	w10, w8, [x20, #12]
	stp	w9, wzr, [x20, #20]
Lloh294:
	adrp	x8, l_.str.79@PAGE
Lloh295:
	add	x8, x8, l_.str.79@PAGEOFF
	b	LBB72_4
LBB72_16:
	mov	w0, #0                          ; =0x0
	ldur	w9, [x21, #212]
	mov	w10, #2                         ; =0x2
	stp	w10, w8, [x20, #12]
	stp	w9, wzr, [x20, #20]
Lloh296:
	adrp	x8, l_.str.81@PAGE
Lloh297:
	add	x8, x8, l_.str.81@PAGEOFF
	b	LBB72_4
LBB72_17:
	mov	x23, x0
	mov	x24, x1
	strb	wzr, [sp, #15]
	ldr	x0, [x22]
	mov	x25, x2
	ldr	x1, [x2]
	add	x2, sp, #15
	bl	_nvm_affine_state_meet_initialization
	tbz	w0, #0, LBB72_23
; %bb.18:
	ldrb	w10, [sp, #15]
	ldrh	w8, [x22, #16]
	adds	w11, w8, w19
	b.eq	LBB72_25
; %bb.19:
	ldr	x12, [x22, #8]
	ldr	x13, [x25, #8]
	mov	x8, x24
	mov	x9, x23
LBB72_20:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w14, [x12]
	ldrb	w15, [x12, #9]
	and	w16, w15, #0xff
	ldrh	w17, [x13]
	orr	w17, w17, w14
	ldrb	w0, [x13, #9]
	orr	w15, w15, w0
	and	w0, w15, #0xff
	cmp	w14, w17, uxth
	ccmp	w16, w0, #0, eq
	cset	w14, ne
	strh	w17, [x12]
	strb	w15, [x12, #9]
	orr	w10, w14, w10
	add	x12, x12, #12
	add	x13, x13, #12
	subs	x11, x11, #1
	b.ne	LBB72_20
	b	LBB72_26
LBB72_21:
	mov	x24, x0
	mov	x25, x1
	mov	x0, x2
	mov	x1, x19
	bl	_la_clone
	stur	x0, [x21, #224]
	cbz	x0, LBB72_24
; %bb.22:
	ldr	w8, [x23, #4]
	add	w8, w8, w22
	str	w8, [x23, #4]
	mov	x8, x25
	mov	x9, x24
	b	LBB72_27
LBB72_23:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	str	w8, [x20, #12]
	ldur	d0, [x21, #208]
	str	d0, [x20, #16]
	str	wzr, [x20, #24]
Lloh298:
	adrp	x8, l_.str.83@PAGE
Lloh299:
	add	x8, x8, l_.str.83@PAGEOFF
	b	LBB72_4
LBB72_24:
	mov	w8, #4                          ; =0x4
	str	w8, [x20, #12]
	ldur	d0, [x21, #208]
	str	d0, [x20, #16]
	str	wzr, [x20, #24]
Lloh300:
	adrp	x8, l_.str.80@PAGE
Lloh301:
	add	x8, x8, l_.str.80@PAGEOFF
	b	LBB72_4
LBB72_25:
	mov	x8, x24
	mov	x9, x23
LBB72_26:
	tbz	w10, #0, LBB72_29
LBB72_27:
	mov	w10, w8
	mov	w11, #104                       ; =0x68
	umull	x10, w10, w11
	add	x11, x9, #242
	ldrb	w12, [x11, x10]
	mov	w0, #1                          ; =0x1
	tbnz	w12, #0, LBB72_5
; %bb.28:
	strb	w0, [x11, x10]
	ldr	w10, [x20]
	add	x9, x9, x10, lsl #2
	mov	w10, #32928                     ; =0x80a0
	movk	w10, #6, lsl #16
	str	w8, [x9, x10]
	ldp	w8, w9, [x20]
	add	w8, w8, #1
	and	w8, w8, #0xfff
	add	w9, w9, #1
	stp	w8, w9, [x20]
	b	LBB72_5
LBB72_29:
	mov	w0, #1                          ; =0x1
	b	LBB72_5
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdrp	Lloh284, Lloh286
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdrp	Lloh288, Lloh290
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh300, Lloh301
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_clone
_la_clone:                              ; @la_clone
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #24                         ; =0x18
	bl	_calloc
	mov	x19, x0
	cbz	x0, LBB73_4
; %bb.1:
	ldr	x0, [x21]
	bl	_nvm_affine_state_clone
	mov	x22, x0
	str	x0, [x19]
	add	w0, w20, #256
	mov	w1, #12                         ; =0xc
	bl	_calloc
	str	x0, [x19, #8]
	cmp	x22, #0
	ccmp	x0, #0, #4, ne
	b.ne	LBB73_3
; %bb.2:
	mov	x20, x0
	mov	x0, x22
	bl	_nvm_affine_state_free
	mov	x0, x20
	bl	_free
	mov	x0, x19
	bl	_free
	mov	x19, #0                         ; =0x0
	b	LBB73_4
LBB73_3:
	ldrh	w8, [x21, #16]
	strh	w8, [x19, #16]
	ldr	x1, [x21, #8]
	add	w8, w8, w20
	add	w8, w8, w8, lsl #1
	lsl	w2, w8, #2
	bl	_memcpy
LBB73_4:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_owned_layout
_mc_owned_layout:                       ; @mc_owned_layout
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	w9, [x8, #8]
	cmp	w1, w9
	b.hs	LBB74_4
; %bb.1:
	add	x9, x8, w1, uxtw #2
	ldr	w9, [x9, #4120]
	cmp	w9, #1
	b.ne	LBB74_4
; %bb.2:
	mov	w9, w1
	ldr	x8, [x8]
	add	x10, x8, x9, lsl #4
	ldrb	w8, [x10]
	cbnz	w8, LBB74_4
; %bb.3:
	ldrh	w8, [x10, #2]
	cmp	w8, #256
	b.ls	LBB74_6
LBB74_4:
	mov	w0, #0                          ; =0x0
LBB74_5:
	ret
LBB74_6:
	mov	w9, #1                          ; =0x1
	cbz	w8, LBB74_11
; %bb.7:
	ldr	x10, [x10, #8]
	add	x10, x10, #4
	mov	w11, #22                        ; =0x16
	mov	w0, #1                          ; =0x1
LBB74_8:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-4]
	cmp	w12, #4
	lsl	w12, w9, w12
	and	w12, w12, w11
	ccmp	w12, #0, #4, ls
	b.eq	LBB74_4
; %bb.9:                                ;   in Loop: Header=BB74_8 Depth=1
	ldr	w12, [x10], #12
	cmn	w12, #1
	b.ne	LBB74_4
; %bb.10:                               ;   in Loop: Header=BB74_8 Depth=1
	subs	x8, x8, #1
	b.ne	LBB74_8
	b	LBB74_5
LBB74_11:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_graph
_mc_graph:                              ; @mc_graph
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	w8, #24                         ; =0x18
	umaddl	x21, w1, w8, x0
	ldrb	w8, [x21, #33]
	cmp	w8, #2
	b.eq	LBB75_10
; %bb.1:
	mov	x19, x0
	cmp	w8, #1
	b.ne	LBB75_3
; %bb.2:
	mov	w0, #0                          ; =0x0
	add	x8, x19, #108, lsl #12          ; =442368
	mov	w9, #1                          ; =0x1
	stp	w9, w1, [x8, #232]
Lloh302:
	adrp	x9, l_.str.30@PAGE
Lloh303:
	add	x9, x9, l_.str.30@PAGEOFF
	stp	xzr, x9, [x8, #240]
	b	LBB75_11
LBB75_3:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x21, #33]
	ldr	x8, [x19]
	ldr	w9, [x8, #272]
	cbz	w9, LBB75_9
; %bb.4:
	mov	w20, #0                         ; =0x0
	b	LBB75_6
LBB75_5:                                ;   in Loop: Header=BB75_6 Depth=1
	add	w20, w20, #1
	ldr	w9, [x8, #272]
	cmp	w20, w9
	b.hs	LBB75_9
LBB75_6:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w9, [x21, #32]
	lsr	w9, w9, w20
	tbz	w9, #0, LBB75_5
; %bb.7:                                ;   in Loop: Header=BB75_6 Depth=1
	mov	x0, x19
	mov	x1, x20
	bl	_mc_graph
	cbz	w0, LBB75_11
; %bb.8:                                ;   in Loop: Header=BB75_6 Depth=1
	ldr	x8, [x19]
	b	LBB75_5
LBB75_9:
	mov	w8, #2                          ; =0x2
	sturb	w8, [x21, #33]
LBB75_10:
	mov	w0, #1                          ; =0x1
LBB75_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh302, Lloh303
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_scalar_op
_mc_scalar_op:                          ; @mc_scalar_op
	.cfi_startproc
; %bb.0:
	mov	w8, #16                         ; =0x10
	strb	w8, [x1]
	sub	w8, w0, #1
	cmp	w8, #225
	b.hi	LBB76_9
; %bb.1:
Lloh304:
	adrp	x9, lJTI76_0@PAGE
Lloh305:
	add	x9, x9, lJTI76_0@PAGEOFF
	adr	x10, LBB76_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB76_2:
	mov	w0, #1                          ; =0x1
	strb	w0, [x1]
	ret
LBB76_3:
	mov	w8, #3                          ; =0x3
	b	LBB76_5
LBB76_4:
	mov	w8, #1                          ; =0x1
LBB76_5:
	strb	w8, [x1]
	mov	w0, #4                          ; =0x4
	ret
LBB76_6:
	mov	w0, #3                          ; =0x3
	strb	w0, [x1]
	ret
LBB76_7:
	mov	w0, #4                          ; =0x4
	strb	w0, [x1]
	ret
LBB76_8:
	mov	w0, #4                          ; =0x4
	ret
LBB76_9:
	mov	w0, #-1                         ; =0xffffffff
LBB76_10:
	ret
LBB76_11:
	mov	w0, #3                          ; =0x3
	ret
LBB76_12:
	mov	w0, #0                          ; =0x0
	ret
LBB76_13:
	mov	w0, #2                          ; =0x2
	ret
	.loh AdrpAdd	Lloh304, Lloh305
	.cfi_endproc
	.section	__TEXT,__const
lJTI76_0:
	.byte	(LBB76_10-LBB76_2)>>2
	.byte	(LBB76_11-LBB76_2)>>2
	.byte	(LBB76_8-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_12-LBB76_2)>>2
	.byte	(LBB76_13-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_2-LBB76_2)>>2
	.byte	(LBB76_2-LBB76_2)>>2
	.byte	(LBB76_2-LBB76_2)>>2
	.byte	(LBB76_2-LBB76_2)>>2
	.byte	(LBB76_2-LBB76_2)>>2
	.byte	(LBB76_2-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_6-LBB76_2)>>2
	.byte	(LBB76_6-LBB76_2)>>2
	.byte	(LBB76_6-LBB76_2)>>2
	.byte	(LBB76_6-LBB76_2)>>2
	.byte	(LBB76_6-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_4-LBB76_2)>>2
	.byte	(LBB76_4-LBB76_2)>>2
	.byte	(LBB76_4-LBB76_2)>>2
	.byte	(LBB76_4-LBB76_2)>>2
	.byte	(LBB76_4-LBB76_2)>>2
	.byte	(LBB76_4-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_3-LBB76_2)>>2
	.byte	(LBB76_3-LBB76_2)>>2
	.byte	(LBB76_3-LBB76_2)>>2
	.byte	(LBB76_3-LBB76_2)>>2
	.byte	(LBB76_3-LBB76_2)>>2
	.byte	(LBB76_3-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_9-LBB76_2)>>2
	.byte	(LBB76_7-LBB76_2)>>2
	.byte	(LBB76_7-LBB76_2)>>2
	.byte	(LBB76_7-LBB76_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function mc_type
_mc_type:                               ; @mc_type
	.cfi_startproc
; %bb.0:
	tst	x2, #0xff00
	b.eq	LBB77_2
LBB77_1:
	mov	w0, #0                          ; =0x0
	ret
LBB77_2:
	lsr	x8, x2, #32
	and	x9, x2, #0xff
	cmp	x9, #8
	b.ne	LBB77_16
; %bb.3:
	ldr	x9, [x0, #8]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	w10, [x9, #8]
	cmp	w10, w8
	b.ls	LBB77_1
; %bb.4:
	add	x10, x9, x8, lsl #2
	ldr	w10, [x10, #4120]
	cmp	w10, #1
	b.ne	LBB77_1
; %bb.5:
	ldr	x9, [x9]
	add	x10, x9, x8, lsl #4
	ldrb	w9, [x10]
	cbnz	w9, LBB77_1
; %bb.6:
	ldrh	w9, [x10, #2]
	cmp	w9, #256
	b.hi	LBB77_1
; %bb.7:
	cbz	w9, LBB77_12
; %bb.8:
	ldr	x10, [x10, #8]
	add	x10, x10, #4
	mov	w11, #1                         ; =0x1
	mov	w12, #22                        ; =0x16
LBB77_9:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x10, #-4]
	cmp	w13, #4
	lsl	w13, w11, w13
	and	w13, w13, w12
	ccmp	w13, #0, #4, ls
	b.eq	LBB77_1
; %bb.10:                               ;   in Loop: Header=BB77_9 Depth=1
	ldr	w13, [x10], #12
	cmn	w13, #1
	b.ne	LBB77_1
; %bb.11:                               ;   in Loop: Header=BB77_9 Depth=1
	subs	x9, x9, #1
	b.ne	LBB77_9
LBB77_12:
	ldrb	w9, [x1, #20]
	cmp	w9, #1
	b.ne	LBB77_1
; %bb.13:
	ldrh	w9, [x1]
	cmp	w9, #256
	b.ne	LBB77_1
; %bb.14:
	ldr	x9, [x1, #8]
	cbnz	x9, LBB77_1
; %bb.15:
	ldr	w9, [x1, #16]
	cmp	w9, w8
	cset	w0, eq
	ret
LBB77_16:
	ldr	x9, [x1, #8]
	ldrb	w10, [x1, #20]
	cmp	w10, #0
	ccmp	x9, #0, #0, eq
	b.eq	LBB77_18
; %bb.17:
	mov	w9, #0                          ; =0x0
	b	LBB77_19
LBB77_18:
	ldrh	w9, [x1]
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w2
	cmp	w9, w10, uxth
	cset	w9, eq
LBB77_19:
	mov	w10, #-1                        ; =0xffffffff
	cmp	x8, x10
	csel	w0, wzr, w9, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_check
_mc_check:                              ; @mc_check
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0, #8]
	ldr	w9, [x8, #20]
	cbz	w9, LBB78_10
; %bb.1:
	add	x10, x0, #108, lsl #12          ; =442368
	ldr	w12, [x1, #64]
	add	x11, x8, #2108
	mov	x13, x9
	b	LBB78_3
LBB78_2:                                ;   in Loop: Header=BB78_3 Depth=1
	add	x11, x11, #20
	subs	x13, x13, #1
	b.eq	LBB78_8
LBB78_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	w14, [x11, #-16]
	cmp	w14, w12
	b.ne	LBB78_2
; %bb.4:                                ;   in Loop: Header=BB78_3 Depth=1
	ldur	w14, [x11, #-12]
	ldr	w15, [x1, #68]
	cmp	w14, w15
	b.ne	LBB78_2
; %bb.5:                                ;   in Loop: Header=BB78_3 Depth=1
	ldurh	w14, [x11, #-8]
	cmp	w14, w2
	b.ne	LBB78_2
; %bb.6:                                ;   in Loop: Header=BB78_3 Depth=1
	ldr	w14, [x11]
	cmp	w14, w5
	b.ne	LBB78_2
; %bb.7:
	ldurh	w8, [x11, #-6]
	orr	w8, w8, w3
	sturh	w8, [x11, #-6]
	ldurh	w8, [x11, #-4]
	cmp	w8, w4
	cset	w0, eq
	ret
LBB78_8:
	cmp	w9, #2, lsl #12                 ; =8192
	b.ne	LBB78_10
; %bb.9:
	mov	w0, #0                          ; =0x0
	ldr	d0, [x1, #64]
	mov	w8, #3                          ; =0x3
	str	w8, [x10, #232]
	stur	d0, [x10, #236]
	str	wzr, [x10, #244]
Lloh306:
	adrp	x8, l_.str.65@PAGE
Lloh307:
	add	x8, x8, l_.str.65@PAGEOFF
	str	x8, [x10, #248]
	ret
LBB78_10:
	mov	w10, #20                        ; =0x14
	add	w11, w9, #1
	str	w11, [x8, #20]
	ldr	d0, [x1, #64]
	umaddl	x8, w9, w10, x8
	add	x9, x8, #2092
	str	d0, [x9]
	strh	w2, [x8, #2100]
	strh	w3, [x8, #2102]
	strh	w4, [x8, #2104]
	strh	wzr, [x8, #2106]
	str	w5, [x8, #2108]
	mov	w0, #1                          ; =0x1
	ret
	.loh AdrpAdd	Lloh306, Lloh307
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_field
_mc_field:                              ; @mc_field
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x1, #20]
	cbnz	w8, LBB79_20
; %bb.1:
	ldrh	w8, [x1]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w2
	cmp	w8, w9, uxth
	b.ne	LBB79_20
; %bb.2:
	cmp	w2, #8
	b.eq	LBB79_12
; %bb.3:
	cmp	w2, #7
	b.ne	LBB79_19
; %bb.4:
	cmn	w3, #1
	b.ne	LBB79_20
; %bb.5:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	cmp	w8, #128
	b.ne	LBB79_21
; %bb.6:
	ldr	x8, [x1, #8]
	cbz	x8, LBB79_21
; %bb.7:
	ldr	x9, [x9, #8]
	ldr	x11, [x9]
	ldr	w9, [x11, #8]
	cbz	w9, LBB79_23
; %bb.8:
	mov	x10, #0                         ; =0x0
	add	x11, x11, #50
	mov	w0, #1                          ; =0x1
	b	LBB79_10
LBB79_9:                                ;   in Loop: Header=BB79_10 Depth=1
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB79_21
LBB79_10:                               ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, x10
	tbz	w12, #0, LBB79_9
; %bb.11:                               ;   in Loop: Header=BB79_10 Depth=1
	ldrb	w12, [x11]
	cmp	w12, #7
	b.eq	LBB79_9
	b	LBB79_20
LBB79_12:
	ldr	x8, [x1, #8]
	cbz	x8, LBB79_20
; %bb.13:
	ldr	x9, [x0, #8]
	ldr	x11, [x9]
	ldr	w9, [x11, #8]
	cbz	w9, LBB79_23
; %bb.14:
	mov	x10, #0                         ; =0x0
	add	x11, x11, #36
	mov	w0, #1                          ; =0x1
	b	LBB79_16
LBB79_15:                               ;   in Loop: Header=BB79_16 Depth=1
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB79_21
LBB79_16:                               ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, x10
	tbz	w12, #0, LBB79_15
; %bb.17:                               ;   in Loop: Header=BB79_16 Depth=1
	ldrb	w12, [x11, #14]
	cmp	w12, #8
	b.ne	LBB79_20
; %bb.18:                               ;   in Loop: Header=BB79_16 Depth=1
	ldr	w12, [x11]
	cmp	w12, w3
	b.eq	LBB79_15
	b	LBB79_20
LBB79_19:
	cmn	w3, #1
	b.eq	LBB79_22
LBB79_20:
	mov	w0, #0                          ; =0x0
	ret
LBB79_21:
	ret
LBB79_22:
	ldr	x9, [x1, #8]
	sub	w8, w8, #1
	cmp	w8, #31
	ccmp	x9, #0, #0, lo
	cset	w0, eq
	ret
LBB79_23:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_array
_mc_array:                              ; @mc_array
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x1, #20]
	cbnz	w8, LBB80_8
; %bb.1:
	ldrh	w8, [x1]
	cmp	w8, #128
	b.ne	LBB80_8
; %bb.2:
	ldr	x8, [x1, #8]
	cbz	x8, LBB80_8
; %bb.3:
	ldr	x9, [x0, #8]
	ldr	x11, [x9]
	ldr	w9, [x11, #8]
	cbz	w9, LBB80_9
; %bb.4:
	mov	x10, #0                         ; =0x0
	add	x11, x11, #50
	b	LBB80_6
LBB80_5:                                ;   in Loop: Header=BB80_6 Depth=1
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB80_9
LBB80_6:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, x10
	tbz	w12, #0, LBB80_5
; %bb.7:                                ;   in Loop: Header=BB80_6 Depth=1
	ldrb	w12, [x11]
	cmp	w12, #7
	b.eq	LBB80_5
LBB80_8:
	mov	w0, #0                          ; =0x0
	ret
LBB80_9:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_declaration
_la_declaration:                        ; @la_declaration
	.cfi_startproc
; %bb.0:
	and	x8, x1, #0xff
	cmp	x8, #8
	b.ne	LBB81_4
; %bb.1:
	lsr	x8, x1, #32
	ldr	w9, [x0, #16]
	cmp	w9, w8
	b.ls	LBB81_4
; %bb.2:
	ldr	x9, [x0, #24]
	ldrb	w9, [x9, x8]
	mov	w10, #3                         ; =0x3
	bics	wzr, w10, w9
	b.ne	LBB81_4
; %bb.3:
	ldr	x9, [x0, #8]
	lsl	x8, x8, #4
	ldrb	w8, [x9, x8]
	cmp	w8, #0
	cset	w8, eq
	b	LBB81_5
LBB81_4:
	mov	x8, #0                          ; =0x0
LBB81_5:
	and	x0, x1, #0xffffffff0000ffff
	mov	x1, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_scalar
_la_scalar:                             ; @la_scalar
	.cfi_startproc
; %bb.0:
	strh	wzr, [x1]
	sub	w8, w0, #1
	cmp	w8, #225
	b.hi	LBB82_12
; %bb.1:
Lloh308:
	adrp	x9, lJTI82_0@PAGE
Lloh309:
	add	x9, x9, lJTI82_0@PAGEOFF
	adr	x10, LBB82_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB82_2:
	mov	w8, #2                          ; =0x2
	strh	w8, [x1]
	mov	w0, #1                          ; =0x1
	ret
LBB82_3:
	mov	w8, #2                          ; =0x2
	b	LBB82_8
LBB82_4:
	mov	w8, #8                          ; =0x8
	b	LBB82_8
LBB82_5:
	mov	w8, #8                          ; =0x8
	strh	w8, [x1]
	mov	w0, #3                          ; =0x3
	ret
LBB82_6:
	mov	w0, #4                          ; =0x4
	ret
LBB82_7:
	mov	w8, #16                         ; =0x10
LBB82_8:
	strh	w8, [x1]
	mov	w0, #4                          ; =0x4
	ret
LBB82_9:
	mov	w0, #3                          ; =0x3
	ret
LBB82_10:
	mov	w0, #0                          ; =0x0
	ret
LBB82_11:
	mov	w0, #2                          ; =0x2
	ret
LBB82_12:
	mov	w0, #-1                         ; =0xffffffff
LBB82_13:
	ret
	.loh AdrpAdd	Lloh308, Lloh309
	.cfi_endproc
	.section	__TEXT,__const
lJTI82_0:
	.byte	(LBB82_13-LBB82_2)>>2
	.byte	(LBB82_9-LBB82_2)>>2
	.byte	(LBB82_6-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_10-LBB82_2)>>2
	.byte	(LBB82_11-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_6-LBB82_2)>>2
	.byte	(LBB82_6-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_2-LBB82_2)>>2
	.byte	(LBB82_2-LBB82_2)>>2
	.byte	(LBB82_2-LBB82_2)>>2
	.byte	(LBB82_2-LBB82_2)>>2
	.byte	(LBB82_2-LBB82_2)>>2
	.byte	(LBB82_2-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_5-LBB82_2)>>2
	.byte	(LBB82_5-LBB82_2)>>2
	.byte	(LBB82_5-LBB82_2)>>2
	.byte	(LBB82_5-LBB82_2)>>2
	.byte	(LBB82_5-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_3-LBB82_2)>>2
	.byte	(LBB82_3-LBB82_2)>>2
	.byte	(LBB82_3-LBB82_2)>>2
	.byte	(LBB82_3-LBB82_2)>>2
	.byte	(LBB82_3-LBB82_2)>>2
	.byte	(LBB82_3-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_4-LBB82_2)>>2
	.byte	(LBB82_4-LBB82_2)>>2
	.byte	(LBB82_4-LBB82_2)>>2
	.byte	(LBB82_4-LBB82_2)>>2
	.byte	(LBB82_4-LBB82_2)>>2
	.byte	(LBB82_4-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_12-LBB82_2)>>2
	.byte	(LBB82_7-LBB82_2)>>2
	.byte	(LBB82_7-LBB82_2)>>2
	.byte	(LBB82_7-LBB82_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function la_type
_la_type:                               ; @la_type
	.cfi_startproc
; %bb.0:
	tst	x3, #0xff00
	b.eq	LBB83_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB83_2:
	lsr	x8, x3, #32
	and	x9, x3, #0xff
	cmp	x9, #8
	b.ne	LBB83_6
; %bb.3:
	lsr	x9, x1, #32
	ldr	w10, [x0, #16]
	cmp	w10, w8
	b.ls	LBB83_7
; %bb.4:
	ldr	x10, [x0, #24]
	ldrb	w10, [x10, x8]
	mov	w11, #3                         ; =0x3
	bics	wzr, w11, w10
	b.ne	LBB83_7
; %bb.5:
	ldr	x10, [x0, #8]
	lsl	x11, x8, #4
	ldrb	w10, [x10, x11]
	cmp	w10, #0
	cset	w10, eq
	b	LBB83_8
LBB83_6:
	and	x9, x2, #0xffff
	mov	w10, #-1                        ; =0xffffffff
	mov	w11, #1                         ; =0x1
	lsl	w11, w11, w3
	eor	w11, w11, w1
	tst	w11, #0xffff
	cset	w11, eq
	cmp	x9, #0
	csel	w9, wzr, w11, ne
	cmp	x8, x10
	csel	w0, wzr, w9, ne
	ret
LBB83_7:
	mov	w10, #0                         ; =0x0
LBB83_8:
	and	x11, x2, #0xffff
	cmp	x11, #1
	csel	w10, wzr, w10, ne
	and	x11, x1, #0xffff
	cmp	x11, #256
	ccmp	x9, x8, #0, eq
	csel	w0, wzr, w10, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require an immutable module and output for private composition."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_mixed_samples.error
l___const.nvm_analyze_mixed_samples.error:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"I could not allocate private composition."

l_.str.2:                               ; @.str.2
	.asciz	"I require complete independent mixed structure."

l_.str.3:                               ; @.str.3
	.asciz	"I reached my composed worklist bound."

l_.str.4:                               ; @.str.4
	.asciz	"I could not copy composed transfer state."

l_.str.5:                               ; @.str.5
	.asciz	"I require checked state for every declared mixed instruction."

l_.str.6:                               ; @.str.6
	.asciz	"I checked private mixed composition; runtime obligations and admission remain separate."

l_.str.7:                               ; @.str.7
	.asciz	"I require a complete immutable module and private output."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_owned_array_lifetimes.invalid
l___const.nvm_analyze_owned_array_lifetimes.invalid:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.7

	.section	__TEXT,__cstring,cstring_literals
l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate independent owner analysis."

l_.str.9:                               ; @.str.9
	.asciz	"I reached my independent transfer visit budget."

l_.str.10:                              ; @.str.10
	.asciz	"I could not copy independent transfer state."

l_.str.11:                              ; @.str.11
	.asciz	"I require independent state for every declared instruction."

l_.str.12:                              ; @.str.12
	.asciz	"I require independently matching per-operand obligations."

l_.str.13:                              ; @.str.13
	.asciz	"I checked origin, lifetime and scalar transfers; common structure and runtime admission remain separate."

l_.str.14:                              ; @.str.14
	.asciz	"I require distinct composed function ranges."

l_.str.15:                              ; @.str.15
	.asciz	"I reached my composed instruction bound."

l_.str.16:                              ; @.str.16
	.asciz	"I require a complete composed instruction."

l_.str.17:                              ; @.str.17
	.asciz	"I require an explicit independent composed transfer."

l_.str.18:                              ; @.str.18
	.asciz	"I require a Boolean literal."

l_.str.19:                              ; @.str.19
	.asciz	"I require an existing composed local."

l_.str.20:                              ; @.str.20
	.asciz	"I require an existing nonentry callee."

l_.str.21:                              ; @.str.21
	.asciz	"I refuse ordinary or unavailable owner construction."

l_.str.22:                              ; @.str.22
	.asciz	"I require this exact closed allocation origin."

l_.str.23:                              ; @.str.23
	.asciz	"I preserve constructor source and global identities."

l_.str.24:                              ; @.str.24
	.asciz	"I require packed FLOAT array origins."

l_.str.25:                              ; @.str.25
	.asciz	"I require an explicit instruction-boundary branch."

l_.str.26:                              ; @.str.26
	.asciz	"I require explicit composed termination."

l_.str.27:                              ; @.str.27
	.asciz	"I could not materialize checked mixed facts."

l_.str.28:                              ; @.str.28
	.asciz	"I require exact mixed value signatures."

l_.str.29:                              ; @.str.29
	.asciz	"I keep unavailable mixed local categories explicit."

l_.str.30:                              ; @.str.30
	.asciz	"I require acyclic composed calls."

l_.str.31:                              ; @.str.31
	.asciz	"I reached my composed state budget."

l_.str.32:                              ; @.str.32
	.asciz	"I could not allocate a composed edge."

l_.str.33:                              ; @.str.33
	.asciz	"I require equal composed stack heights."

l_.str.34:                              ; @.str.34
	.asciz	"I require exact owner stack and observation joins."

l_.str.35:                              ; @.str.35
	.asciz	"I require exact owner state at composed joins."

l_.str.36:                              ; @.str.36
	.asciz	"I require RESOURCE authority before owner field transfer."

l_.str.37:                              ; @.str.37
	.asciz	"I require an exact return and complete independent owner consumption."

l_.str.38:                              ; @.str.38
	.asciz	"I require a complete independent operand stack."

l_.str.39:                              ; @.str.39
	.asciz	"I reached my independent operand stack budget."

l_.str.40:                              ; @.str.40
	.asciz	"I refuse heap or owner scalar operands."

l_.str.41:                              ; @.str.41
	.asciz	"I require exact scalar inputs or an explicit FLOAT-or-VOID check."

l_.str.42:                              ; @.str.42
	.asciz	"I require supported scalar value comparisons, never owner or ordinary heap equality."

l_.str.43:                              ; @.str.43
	.asciz	"I keep VOID ordering outside my first composition."

l_.str.44:                              ; @.str.44
	.asciz	"I cannot duplicate an owner or observation."

l_.str.45:                              ; @.str.45
	.asciz	"I require explicit owner consumption rather than POP."

l_.str.46:                              ; @.str.46
	.asciz	"I require a live exact owner observation."

l_.str.47:                              ; @.str.47
	.asciz	"I require initialized exact ordinary local alternatives."

l_.str.48:                              ; @.str.48
	.asciz	"I refuse owner or mismatched ordinary local stores."

l_.str.49:                              ; @.str.49
	.asciz	"I require a checked scalar destination."

l_.str.50:                              ; @.str.50
	.asciz	"I require a live unobserved RESOURCE for move or unpack."

l_.str.51:                              ; @.str.51
	.asciz	"I require an available exact RESOURCE destination."

l_.str.52:                              ; @.str.52
	.asciz	"I require exact scalar fields before producing an owner token."

l_.str.53:                              ; @.str.53
	.asciz	"I never construct an owner through ordinary packing."

l_.str.54:                              ; @.str.54
	.asciz	"I require every independent ordinary field alternative in the closed proof."

l_.str.55:                              ; @.str.55
	.asciz	"I require an intact independent owner observation."

l_.str.56:                              ; @.str.56
	.asciz	"I require exact ordinary receiver alternatives."

l_.str.57:                              ; @.str.57
	.asciz	"I require a proved field on every ordinary receiver."

l_.str.58:                              ; @.str.58
	.asciz	"I require exact FLOAT elements for array construction."

l_.str.59:                              ; @.str.59
	.asciz	"I require closed FLOAT-array receiver alternatives."

l_.str.60:                              ; @.str.60
	.asciz	"I require exact integer array indices."

l_.str.61:                              ; @.str.61
	.asciz	"I require exact FLOAT alias writes."

l_.str.62:                              ; @.str.62
	.asciz	"I require exact positional call values before owner transfer."

l_.str.63:                              ; @.str.63
	.asciz	"I require an exact Boolean control operand."

l_.str.64:                              ; @.str.64
	.asciz	"I require an independent transfer for every mixed instruction."

l_.str.65:                              ; @.str.65
	.asciz	"I reached my scalar obligation budget."

l_.str.66:                              ; @.str.66
	.asciz	"I reached my independent instruction budget."

l_.str.67:                              ; @.str.67
	.asciz	"I require an explicit independent instruction transfer."

l_.str.68:                              ; @.str.68
	.asciz	"I require identical independent and origin instruction locations."

l_.str.69:                              ; @.str.69
	.asciz	"I require complete independent instruction coverage."

l_.str.70:                              ; @.str.70
	.asciz	"I require exact independent branch destinations."

l_.str.71:                              ; @.str.71
	.asciz	"I could not materialize checked owner Facts."

l_.str.72:                              ; @.str.72
	.asciz	"I retain exact existing owner value signatures."

l_.str.73:                              ; @.str.73
	.asciz	"I require the exact independently retained layout row."

l_.str.74:                              ; @.str.74
	.asciz	"I reached my owner depth or direct-field limit."

l_.str.75:                              ; @.str.75
	.asciz	"I require prior exact nested owners."

l_.str.76:                              ; @.str.76
	.asciz	"I keep unsupported owner fields outside authority."

l_.str.77:                              ; @.str.77
	.asciz	"I require modeled exact local declarations."

l_.str.78:                              ; @.str.78
	.asciz	"I require an existing independent state destination."

l_.str.79:                              ; @.str.79
	.asciz	"I reached my independent state-cell budget."

l_.str.80:                              ; @.str.80
	.asciz	"I could not allocate an independent join frame."

l_.str.81:                              ; @.str.81
	.asciz	"I require equal independent join heights."

l_.str.82:                              ; @.str.82
	.asciz	"I require compatible unique stack owners and observations."

l_.str.83:                              ; @.str.83
	.asciz	"I require compatible independent owner lifetimes at joins."

l_.str.84:                              ; @.str.84
	.asciz	"I reached my independent owner work budget."

l_.str.85:                              ; @.str.85
	.asciz	"I require complete instruction metadata."

l_.str.86:                              ; @.str.86
	.asciz	"I require exact owner authority before field transfer."

l_.str.87:                              ; @.str.87
	.asciz	"I require the exact return and complete independent owner consumption."

l_.str.88:                              ; @.str.88
	.asciz	"I require complete independent operand stacks."

l_.str.89:                              ; @.str.89
	.asciz	"I reached my independent stack budget."

l_.str.90:                              ; @.str.90
	.asciz	"I require bounded independent scalar operand rows."

l_.str.91:                              ; @.str.91
	.asciz	"I require independently modeled scalar operands."

l_.str.92:                              ; @.str.92
	.asciz	"I require independently exact operands or a checked optional FLOAT comparison."

l_.str.93:                              ; @.str.93
	.asciz	"I cannot copy a unique owner or observation."

l_.str.94:                              ; @.str.94
	.asciz	"I cannot discard an unconsumed owner or observation."

l_.str.95:                              ; @.str.95
	.asciz	"I require a live owner before observation."

l_.str.96:                              ; @.str.96
	.asciz	"I require independently initialized ordinary locals."

l_.str.97:                              ; @.str.97
	.asciz	"I cannot overwrite owner authority through an ordinary store."

l_.str.98:                              ; @.str.98
	.asciz	"I require a checked scalar initialization."

l_.str.99:                              ; @.str.99
	.asciz	"I require a checked STRING initialization."

l_.str.100:                             ; @.str.100
	.asciz	"I require a live unobserved owner before consuming it."

l_.str.101:                             ; @.str.101
	.asciz	"I require an empty exact owner destination."

l_.str.102:                             ; @.str.102
	.asciz	"I require exact transferred owner constructor fields."

l_.str.103:                             ; @.str.103
	.asciz	"I require an exact live owner observation path."

l_.str.104:                             ; @.str.104
	.asciz	"I require declared FLOAT array construction."

l_.str.105:                             ; @.str.105
	.asciz	"I require exact FLOAT initializer values."

l_.str.106:                             ; @.str.106
	.asciz	"I require an independently initialized ARRAY receiver."

l_.str.107:                             ; @.str.107
	.asciz	"I require exact INT indices."

l_.str.108:                             ; @.str.108
	.asciz	"I require exact FLOAT writes through aliases."

l_.str.109:                             ; @.str.109
	.asciz	"I require exact independently transferred call arguments."

l_.str.110:                             ; @.str.110
	.asciz	"I require independently exact INT output operands."

l_.str.111:                             ; @.str.111
	.asciz	"I require exact BOOL control operands."

l_.str.112:                             ; @.str.112
	.asciz	"I require an explicit independent lifetime transfer."

.subsections_via_symbols
