	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm2c_emit_services_indirect_bytes ; -- Begin function nvm2c_emit_services_indirect_bytes
	.p2align	2
_nvm2c_emit_services_indirect_bytes:    ; @nvm2c_emit_services_indirect_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1248
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x5
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x24, x0
	bl	_nvm_services_host_enter_query
	mov	x25, x0
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w25, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w25, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w25, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w25, #4                         ; =0x4
	b	LBB0_149
LBB0_5:
	cbz	w25, LBB0_10
; %bb.6:
	cmp	w25, #1
	b.eq	LBB0_149
LBB0_7:
	mov	w25, #2                         ; =0x2
	b	LBB0_149
LBB0_8:
	mov	w25, #11                        ; =0xb
	b	LBB0_149
LBB0_9:
	mov	w25, #5                         ; =0x5
	b	LBB0_149
LBB0_10:
	cbz	x23, LBB0_144
; %bb.11:
	cbz	x24, LBB0_144
; %bb.12:
	cbz	x21, LBB0_144
; %bb.13:
	cbnz	x20, LBB0_15
; %bb.14:
	cbnz	x19, LBB0_147
LBB0_15:
	cbz	x22, LBB0_144
; %bb.16:
	ldrb	w8, [x22]
	cbz	w8, LBB0_144
; %bb.17:
	and	w8, w8, #0xffffffdf
	sub	w8, w8, #65
	cmp	w8, #25
	b.hi	LBB0_144
; %bb.18:
	ldrb	w12, [x22, #1]
	cbz	w12, LBB0_24
; %bb.19:
	mov	w8, #1                          ; =0x1
	mov	w9, #2                          ; =0x2
	mov	w10, #223                       ; =0xdf
	mov	w11, #95                        ; =0x5f
LBB0_20:                                ; =>This Inner Loop Header: Depth=1
	and	w13, w12, w10
	sub	w13, w13, #65
	cmp	w13, #26
	b.lo	LBB0_22
; %bb.21:                               ;   in Loop: Header=BB0_20 Depth=1
	sub	w13, w12, #58
	cmn	w13, #10
	ccmp	w12, w11, #4, lo
	b.ne	LBB0_144
LBB0_22:                                ;   in Loop: Header=BB0_20 Depth=1
	cmp	x9, #64
	b.eq	LBB0_144
; %bb.23:                               ;   in Loop: Header=BB0_20 Depth=1
	add	x8, x8, #1
	ldrb	w12, [x22, x9]
	add	x9, x9, #1
	cbnz	w12, LBB0_20
LBB0_24:
	str	xzr, [sp, #160]
	add	x2, sp, #160
	mov	x0, x24
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_prepare
	mov	x25, x0
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB0_151
; %bb.25:
	cbnz	w25, LBB0_150
; %bb.26:
	ldr	x0, [sp, #160]
	add	x1, sp, #64
	bl	_nvm_services_indirect_hosted_startup
	cbz	w0, LBB0_154
; %bb.27:
	ldr	x25, [sp, #160]
	add	x1, sp, #544
	mov	x0, x25
	bl	_nvm_services_indirect_hosted_startup
	cbz	w0, LBB0_154
; %bb.28:
	ldrb	w8, [sp, #632]
	tbnz	w8, #0, LBB0_154
; %bb.29:
	ldr	w8, [sp, #556]
	cbz	w8, LBB0_137
; %bb.30:
	mov	w26, #0                         ; =0x0
LBB0_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;       Child Loop BB0_43 Depth 3
                                        ;         Child Loop BB0_92 Depth 4
                                        ;         Child Loop BB0_123 Depth 4
	add	x2, sp, #448
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB0_154
; %bb.32:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrb	w8, [sp, #528]
	cbnz	w8, LBB0_154
; %bb.33:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrh	w8, [sp, #456]
	cbz	w8, LBB0_136
; %bb.34:                               ;   in Loop: Header=BB0_31 Depth=1
	mov	w28, #0                         ; =0x0
LBB0_35:                                ;   Parent Loop BB0_31 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_43 Depth 3
                                        ;         Child Loop BB0_92 Depth 4
                                        ;         Child Loop BB0_123 Depth 4
	and	w2, w28, #0xffff
	add	x3, sp, #640
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_instruction
	cbz	w0, LBB0_154
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w0, [sp, #648]
	bl	_fcd_supported
	ldrb	w8, [sp, #716]
	cmp	w0, #0
	ccmp	w8, #2, #2, ne
	b.hi	LBB0_154
; %bb.37:                               ;   in Loop: Header=BB0_35 Depth=2
	and	w2, w28, #0xffff
	add	x3, sp, #447
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_154
; %bb.38:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w8, [sp, #447]
	cmp	w8, #16
	b.hi	LBB0_154
; %bb.39:                               ;   in Loop: Header=BB0_35 Depth=2
	tst	w28, #0xffff
	b.ne	LBB0_41
; %bb.40:                               ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_154
LBB0_41:                                ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_135
; %bb.42:                               ;   in Loop: Header=BB0_35 Depth=2
	mov	w9, #0                          ; =0x0
LBB0_43:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_92 Depth 4
                                        ;         Child Loop BB0_123 Depth 4
	and	w2, w28, #0xffff
	str	w9, [sp, #56]                   ; 4-byte Folded Spill
	and	w3, w9, #0xff
	add	x4, sp, #336
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_variant
	cbz	w0, LBB0_154
; %bb.44:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #356]
	tbz	w8, #0, LBB0_154
; %bb.45:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w27, [sp, #648]
	mov	x0, x27
	bl	_fcd_supported
	cbz	w0, LBB0_154
; %bb.46:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	cmp	w27, #147
	b.gt	LBB0_50
; %bb.47:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #60
	b.gt	LBB0_73
; %bb.48:                               ;   in Loop: Header=BB0_43 Depth=3
	sub	w9, w27, #59
	cmp	w9, #2
	b.lo	LBB0_52
; %bb.49:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #15
	b.eq	LBB0_52
	b	LBB0_53
LBB0_50:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #150
	b.le	LBB0_76
; %bb.51:                               ;   in Loop: Header=BB0_43 Depth=3
	sub	w9, w27, #151
	cmp	w9, #2
	b.hs	LBB0_80
LBB0_52:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #5                          ; =0x5
LBB0_53:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #368]
	cmp	w9, w8
	b.ne	LBB0_154
; %bb.54:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #358]
	cmp	w27, #146
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.55:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #357]
	cmp	w27, #61
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.56:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	sub	w9, w27, #59
	cmp	w9, #2
	b.lo	LBB0_59
; %bb.57:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #152
	b.eq	LBB0_59
; %bb.58:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #15
	mov	w8, #151                        ; =0x97
	ccmp	w27, w8, #4, ne
	cset	w8, eq
LBB0_59:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	ldrb	w9, [sp, #359]
	csinc	w8, w8, wzr, ne
	cmp	w9, w8
	b.ne	LBB0_154
; %bb.60:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w8, LBB0_72
; %bb.61:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #384]
	ldr	w9, [sp, #640]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.62:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #-1                         ; =0xffffffff
	cmp	w27, #60
	b.eq	LBB0_65
; %bb.63:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #152
	b.eq	LBB0_65
; %bb.64:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #656]
LBB0_65:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #388]
	cmp	w9, w8
	b.ne	LBB0_154
; %bb.66:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	cset	w8, ne
	ldr	w9, [sp, #380]
	cmp	w9, w8
	b.ne	LBB0_154
; %bb.67:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	b.ne	LBB0_79
; %bb.68:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w1, [sp, #1232]
	add	x2, sp, #256
	mov	x0, x25
	str	w1, [sp, #48]                   ; 4-byte Folded Spill
	bl	_nvm_services_indirect_hosted_import
	cbz	w0, LBB0_154
; %bb.69:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #256]
	ldr	w9, [sp, #388]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.70:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	ldr	w9, [sp, #48]                   ; 4-byte Folded Reload
	umull	x8, w9, w8
	lsr	x8, x8, #34
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	w8, w8, w8, lsl #3
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	add	w1, w8, #8
	add	x2, sp, #168
	mov	x0, x25
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB0_82
; %bb.71:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	w8, w8, w8, lsl #2
	ldr	w9, [sp, #48]                   ; 4-byte Folded Reload
	sub	w0, w9, w8
	bl	_nl_socket_catalog_method
	b	LBB0_87
LBB0_72:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #128                        ; =0x80
	b	LBB0_95
LBB0_73:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #61
	b.eq	LBB0_84
; %bb.74:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	b.ne	LBB0_53
; %bb.75:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #6                          ; =0x6
	b	LBB0_53
LBB0_76:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #148
	b.eq	LBB0_85
; %bb.77:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #149
	b.ne	LBB0_53
; %bb.78:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #2                          ; =0x2
	b	LBB0_53
LBB0_79:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #448                        ; =0x1c0
	mov	w8, #64                         ; =0x40
	b	LBB0_94
LBB0_80:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #161
	b.ne	LBB0_53
; %bb.81:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #3                          ; =0x3
	b	LBB0_53
LBB0_82:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	x0, x25
	ldr	w27, [sp, #48]                  ; 4-byte Folded Reload
	mov	x1, x27
	bl	_services_dispatch_websocket
	mov	x8, x0
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	w9, w9, w9, lsl #2
	sub	w0, w27, w9
	cbz	w8, LBB0_86
; %bb.83:                               ;   in Loop: Header=BB0_43 Depth=3
	bl	_nl_websocket_catalog_method
	b	LBB0_87
LBB0_84:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #4                          ; =0x4
	b	LBB0_53
LBB0_85:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_53
LBB0_86:                                ;   in Loop: Header=BB0_43 Depth=3
	bl	_nl_file_catalog_method
LBB0_87:                                ;   in Loop: Header=BB0_43 Depth=3
	cbz	x0, LBB0_154
; %bb.88:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #396]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.89:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #400]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.90:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [x0, #44]
	cmp	w8, #1
	mov	w8, #399                        ; =0x18f
	mov	w9, #415                        ; =0x19f
	csel	w27, w9, w8, eq
	ldr	x9, [x0, #56]
	cmp	x9, #2
	b.lo	LBB0_93
; %bb.91:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	x8, [x0, #48]
	add	x8, x8, #40
	sub	x9, x9, #1
LBB0_92:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ;       Parent Loop BB0_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w10, [x8], #48
	orr	w11, w27, #0x20
	cmp	w10, #1
	csel	w11, w11, w27, eq
	orr	w12, w11, #0x400
	cmp	w10, #5
	csel	w27, w12, w11, eq
	subs	x9, x9, #1
	b.ne	LBB0_92
LBB0_93:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	add	w1, w8, #8
	add	x2, sp, #168
	mov	x0, x25
	bl	_nvm_services_indirect_hosted_type
	mov	w8, #0                          ; =0x0
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	w9, w9, w9, lsl #2
	ldr	w10, [sp, #48]                  ; 4-byte Folded Reload
	cmp	w10, w9
	cset	w9, eq
	orr	w10, w27, #0x200
	tst	w9, w0
	csel	w9, w10, w27, ne
LBB0_94:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #392]
	cmp	w10, w9
	b.ne	LBB0_154
LBB0_95:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #372]
	cmp	w10, w8
	b.ne	LBB0_154
; %bb.96:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #376]
	bic	w8, w9, w8
	cmp	w10, w8
	b.ne	LBB0_154
; %bb.97:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #360]
	ldrh	w9, [sp, #338]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.98:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #362]
	ldrh	w9, [sp, #348]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.99:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #436]
	ldrb	w9, [sp, #716]
	lsr	w10, w8, w9
	cbnz	w10, LBB0_154
; %bb.100:                              ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #0, LBB0_102
; %bb.101:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w9, [sp, #437]
	cmp	w9, #255
	b.eq	LBB0_107
	b	LBB0_154
LBB0_102:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w9, LBB0_154
; %bb.103:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #712]
	ldrh	w8, [sp, #456]
	cmp	w2, w8
	b.hs	LBB0_154
; %bb.104:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #168
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_154
; %bb.105:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #437]
	ldrb	w9, [sp, #168]
	cmp	w8, w9
	b.hs	LBB0_154
; %bb.106:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #436]
LBB0_107:                               ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #1, LBB0_109
; %bb.108:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #438]
	cmp	w8, #255
	b.eq	LBB0_113
	b	LBB0_154
LBB0_109:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #716]
	cmp	w8, #2
	b.lo	LBB0_154
; %bb.110:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #714]
	ldrh	w8, [sp, #456]
	cmp	w2, w8
	b.hs	LBB0_154
; %bb.111:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #168
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_154
; %bb.112:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #438]
	ldrb	w9, [sp, #168]
	cmp	w8, w9
	b.hs	LBB0_154
LBB0_113:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #648]
	cmp	w8, #152
	b.eq	LBB0_115
; %bb.114:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #60
	b.ne	LBB0_129
LBB0_115:                               ;   in Loop: Header=BB0_43 Depth=3
	and	w2, w28, #0xffff
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	and	w3, w8, #0xff
	add	x4, sp, #256
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_services_indirect_hosted_call
	cbz	w0, LBB0_154
; %bb.116:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	x8, [sp, #264]
	cbz	x8, LBB0_154
; %bb.117:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	x9, [sp, #272]
	cmp	x8, x9
	b.ne	LBB0_154
; %bb.118:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #256]
	cmp	w8, w26
	b.ne	LBB0_154
; %bb.119:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #260]
	ldr	w9, [sp, #640]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.120:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #288]
	cmn	w8, #1
	b.ne	LBB0_154
; %bb.121:                              ;   in Loop: Header=BB0_43 Depth=3
	mov	x27, #0                         ; =0x0
	b	LBB0_123
LBB0_122:                               ;   in Loop: Header=BB0_123 Depth=4
	add	x27, x27, #1
	cmp	x27, #64
	b.eq	LBB0_128
LBB0_123:                               ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ;       Parent Loop BB0_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	x8, [sp, #264]
	lsr	x8, x8, x27
	tbz	w8, #0, LBB0_122
; %bb.124:                              ;   in Loop: Header=BB0_123 Depth=4
	add	x2, sp, #168
	mov	x0, x25
	mov	x1, x27
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB0_154
; %bb.125:                              ;   in Loop: Header=BB0_123 Depth=4
	ldrb	w8, [sp, #248]
	cbnz	w8, LBB0_154
; %bb.126:                              ;   in Loop: Header=BB0_123 Depth=4
	ldrh	w8, [sp, #180]
	ldrh	w9, [sp, #304]
	cmp	w8, w9
	b.ne	LBB0_154
; %bb.127:                              ;   in Loop: Header=BB0_123 Depth=4
	ldrb	w8, [sp, #184]
	ldrb	w9, [sp, #310]
	cmp	w8, w9
	b.eq	LBB0_122
	b	LBB0_154
LBB0_128:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #648]
LBB0_129:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #15
	b.eq	LBB0_132
; %bb.130:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #151
	b.eq	LBB0_132
; %bb.131:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #59
	b.ne	LBB0_134
LBB0_132:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w1, [sp, #656]
	add	x2, sp, #168
	mov	x0, x25
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB0_154
; %bb.133:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #248]
	cbnz	w8, LBB0_154
LBB0_134:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	add	w9, w9, #1
	ldrb	w8, [sp, #447]
	cmp	w8, w9, uxtb
	b.hi	LBB0_43
LBB0_135:                               ;   in Loop: Header=BB0_35 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #456]
	cmp	w8, w28, uxth
	b.hi	LBB0_35
LBB0_136:                               ;   in Loop: Header=BB0_31 Depth=1
	add	w26, w26, #1
	ldr	w8, [sp, #556]
	cmp	w26, w8
	b.lo	LBB0_31
LBB0_137:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #448]
	add	x0, sp, #448
	bl	_fn_preamble
Lloh0:
	adrp	x1, l_.str.5@PAGE
Lloh1:
	add	x1, x1, l_.str.5@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	mov	x26, #0                         ; =0x0
	mov	w27, #23                        ; =0x17
Lloh2:
	adrp	x28, l_.str.3@PAGE
Lloh3:
	add	x28, x28, l_.str.3@PAGEOFF
Lloh4:
	adrp	x25, l_.str.6@PAGE
Lloh5:
	add	x25, x25, l_.str.6@PAGEOFF
LBB0_138:                               ; =>This Inner Loop Header: Depth=1
	mov	x8, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x8, #43691
	umulh	x8, x26, x8
	lsr	x8, x8, #4
	mov	w9, #24                         ; =0x18
	madd	x8, x8, x9, x27
	ldrb	w9, [x24], #1
	cmp	x8, #0
Lloh6:
	adrp	x8, l_.str.7@PAGE
Lloh7:
	add	x8, x8, l_.str.7@PAGEOFF
	csel	x8, x8, x28, eq
	stp	x9, x8, [sp]
	add	x0, sp, #448
	mov	x1, x25
	bl	_fn_text
	add	x26, x26, #1
	sub	x27, x27, #1
	sub	x23, x23, #1
	cbnz	x23, LBB0_138
; %bb.139:
Lloh8:
	adrp	x1, l_.str.8@PAGE
Lloh9:
	add	x1, x1, l_.str.8@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	ldr	x1, [sp, #160]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [sp, #672]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [sp, #704]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [sp, #640]
	add	x0, sp, #448
	add	x2, sp, #640
	bl	_fn_agreement
	ldr	w8, [sp, #76]
	cbz	w8, LBB0_276
; %bb.140:
	mov	w24, #0                         ; =0x0
Lloh10:
	adrp	x23, l_.str.9@PAGE
Lloh11:
	add	x23, x23, l_.str.9@PAGEOFF
LBB0_141:                               ; =>This Inner Loop Header: Depth=1
	str	x24, [sp]
	add	x0, sp, #448
	mov	x1, x23
	bl	_fn_text
	add	w24, w24, #1
	ldr	w8, [sp, #76]
	cmp	w24, w8
	b.lo	LBB0_141
; %bb.142:
	cbz	w8, LBB0_276
; %bb.143:
	mov	w23, #0                         ; =0x0
Lloh12:
	adrp	x25, l_.str.186@PAGE
Lloh13:
	add	x25, x25, l_.str.186@PAGEOFF
	b	LBB0_158
LBB0_144:
	mov	w25, #1                         ; =0x1
	cbz	x20, LBB0_148
; %bb.145:
	cbz	x19, LBB0_148
; %bb.146:
Lloh14:
	adrp	x2, l_.str@PAGE
Lloh15:
	add	x2, x2, l_.str@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
LBB0_147:
	mov	w25, #1                         ; =0x1
LBB0_148:
	bl	_nvm_services_host_leave
LBB0_149:
	mov	x0, x25
	add	sp, sp, #1248
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_150:
	cmp	w25, #2
	mov	w8, #1                          ; =0x1
	cinc	w25, w8, eq
LBB0_151:
	cbz	x19, LBB0_148
; %bb.152:
	mov	x8, x25
Lloh16:
	adrp	x9, l_.str.3@PAGE
Lloh17:
	add	x9, x9, l_.str.3@PAGEOFF
	stp	x9, x8, [sp]
Lloh18:
	adrp	x2, l_.str.1@PAGE
Lloh19:
	add	x2, x2, l_.str.1@PAGEOFF
LBB0_153:
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
	b	LBB0_148
LBB0_154:
	ldr	x0, [sp, #160]
	bl	_nvm_services_indirect_hosted_free
	cbz	x19, LBB0_275
; %bb.155:
Lloh20:
	adrp	x8, l_.str.3@PAGE
Lloh21:
	add	x8, x8, l_.str.3@PAGEOFF
	str	x8, [sp]
Lloh22:
	adrp	x2, l_.str.4@PAGE
Lloh23:
	add	x2, x2, l_.str.4@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
	mov	w25, #2                         ; =0x2
	b	LBB0_148
LBB0_156:                               ;   in Loop: Header=BB0_158 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #472]
LBB0_157:                               ;   in Loop: Header=BB0_158 Depth=1
	add	w23, w23, #1
	ldr	w8, [sp, #76]
	cmp	w23, w8
	b.hs	LBB0_276
LBB0_158:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_161 Depth 2
                                        ;     Child Loop BB0_166 Depth 2
                                        ;       Child Loop BB0_256 Depth 3
                                        ;       Child Loop BB0_202 Depth 3
                                        ;       Child Loop BB0_187 Depth 3
                                        ;       Child Loop BB0_193 Depth 3
	ldr	x24, [sp, #160]
	add	x2, sp, #336
	mov	x0, x24
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_function
	tbz	w0, #0, LBB0_156
; %bb.159:                              ;   in Loop: Header=BB0_158 Depth=1
	mov	x8, x23
	str	x8, [sp]
	add	x0, sp, #448
Lloh24:
	adrp	x1, l_.str.185@PAGE
Lloh25:
	add	x1, x1, l_.str.185@PAGEOFF
	bl	_fn_text
	ldrh	w8, [sp, #344]
	cbz	w8, LBB0_162
; %bb.160:                              ;   in Loop: Header=BB0_158 Depth=1
	mov	w26, #0                         ; =0x0
LBB0_161:                               ;   Parent Loop BB0_158 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	x26, [sp]
	add	x0, sp, #448
	mov	x1, x25
	bl	_fn_text
	add	w26, w26, #1
	ldrh	w8, [sp, #344]
	cmp	w26, w8
	b.lo	LBB0_161
LBB0_162:                               ;   in Loop: Header=BB0_158 Depth=1
	add	x0, sp, #448
Lloh26:
	adrp	x1, l_.str.187@PAGE
Lloh27:
	add	x1, x1, l_.str.187@PAGEOFF
	bl	_fn_text
	ldrh	w8, [sp, #344]
	cbz	w8, LBB0_274
; %bb.163:                              ;   in Loop: Header=BB0_158 Depth=1
	mov	w28, #0                         ; =0x0
	b	LBB0_166
LBB0_164:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #472]
LBB0_165:                               ;   in Loop: Header=BB0_166 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #344]
	cmp	w28, w8
	b.hs	LBB0_274
LBB0_166:                               ;   Parent Loop BB0_158 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_256 Depth 3
                                        ;       Child Loop BB0_202 Depth 3
                                        ;       Child Loop BB0_187 Depth 3
                                        ;       Child Loop BB0_193 Depth 3
	add	x3, sp, #640
	mov	x0, x24
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_instruction
	cbz	w0, LBB0_156
; %bb.167:                              ;   in Loop: Header=BB0_166 Depth=2
	add	x3, sp, #256
	mov	x0, x24
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_156
; %bb.168:                              ;   in Loop: Header=BB0_166 Depth=2
	str	x28, [sp]
	add	x0, sp, #448
Lloh28:
	adrp	x1, l_.str.188@PAGE
Lloh29:
	add	x1, x1, l_.str.188@PAGEOFF
	bl	_fn_text
	ldrb	w8, [sp, #256]
	cbz	w8, LBB0_174
; %bb.169:                              ;   in Loop: Header=BB0_166 Depth=2
	mov	x8, x28
	stp	x23, x8, [sp, #16]
	add	x0, sp, #448
	stp	x23, x8, [sp]
Lloh30:
	adrp	x1, l_.str.190@PAGE
Lloh31:
	add	x1, x1, l_.str.190@PAGEOFF
	bl	_fn_text
	ldrb	w26, [sp, #648]
	cmp	w26, #255
	b.eq	LBB0_225
; %bb.170:                              ;   in Loop: Header=BB0_166 Depth=2
	mov	w27, #1                         ; =0x1
Lloh32:
	adrp	x10, lJTI0_0@PAGE
Lloh33:
	add	x10, x10, lJTI0_0@PAGEOFF
	adr	x8, LBB0_171
	ldrh	w9, [x10, x26, lsl #1]
	add	x8, x8, x9, lsl #2
	br	x8
LBB0_171:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh34:
	adrp	x1, l_.str.226@PAGE
Lloh35:
	add	x1, x1, l_.str.226@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	cmp	w26, #252
	b.eq	LBB0_173
; %bb.172:                              ;   in Loop: Header=BB0_166 Depth=2
	cmp	w26, #106
	b.ne	LBB0_210
LBB0_173:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #656]
	str	x8, [sp]
Lloh36:
	adrp	x1, l_.str.227@PAGE
Lloh37:
	add	x1, x1, l_.str.227@PAGEOFF
	b	LBB0_235
LBB0_174:                               ;   in Loop: Header=BB0_166 Depth=2
	add	x0, sp, #448
Lloh38:
	adrp	x1, l_.str.189@PAGE
Lloh39:
	add	x1, x1, l_.str.189@PAGEOFF
	b	LBB0_239
LBB0_175:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh40:
	adrp	x1, l_.str.218@PAGE
Lloh41:
	add	x1, x1, l_.str.218@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	cmp	w26, #161
	b.ne	LBB0_207
; %bb.176:                              ;   in Loop: Header=BB0_166 Depth=2
Lloh42:
	adrp	x1, l_.str.219@PAGE
Lloh43:
	add	x1, x1, l_.str.219@PAGEOFF
	b	LBB0_235
LBB0_177:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w8, #4                          ; =0x4
	cmp	w26, #3
	csel	w8, w8, wzr, eq
	cmp	w26, #1
	csinc	w8, w8, wzr, ne
	b.ne	LBB0_208
; %bb.178:                              ;   in Loop: Header=BB0_166 Depth=2
	ldr	x9, [sp, #656]
	b	LBB0_230
LBB0_179:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrb	w8, [sp, #716]
	cmp	w8, #1
	b.ne	LBB0_164
; %bb.180:                              ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #712]
	ldr	w9, [sp, #656]
	stp	x9, x8, [sp]
Lloh44:
	adrp	x1, l_.str.232@PAGE
Lloh45:
	add	x1, x1, l_.str.232@PAGEOFF
	add	x0, sp, #448
	b	LBB0_239
LBB0_181:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh46:
	adrp	x1, l_.str.207@PAGE
Lloh47:
	add	x1, x1, l_.str.207@PAGEOFF
	b	LBB0_235
LBB0_182:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh48:
	adrp	x1, l_.str.204@PAGE
Lloh49:
	add	x1, x1, l_.str.204@PAGEOFF
	b	LBB0_235
LBB0_183:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrb	w8, [sp, #716]
	cmp	w8, #1
	b.ne	LBB0_164
; %bb.184:                              ;   in Loop: Header=BB0_166 Depth=2
	add	x3, sp, #168
	mov	x0, x24
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_164
; %bb.185:                              ;   in Loop: Header=BB0_166 Depth=2
	ldrb	w8, [sp, #168]
	cbz	w8, LBB0_164
; %bb.186:                              ;   in Loop: Header=BB0_166 Depth=2
	mov	w27, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
LBB0_187:                               ;   Parent Loop BB0_158 Depth=1
                                        ;     Parent Loop BB0_166 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w3, w27, #0xff
	add	x4, sp, #544
	mov	x0, x24
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_call
	cbz	w0, LBB0_164
; %bb.188:                              ;   in Loop: Header=BB0_187 Depth=3
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #560]
	cmp	x8, x9
	b.ne	LBB0_164
; %bb.189:                              ;   in Loop: Header=BB0_187 Depth=3
	orr	x26, x8, x26
	add	w27, w27, #1
	ldrb	w8, [sp, #168]
	cmp	w8, w27, uxtb
	b.hi	LBB0_187
; %bb.190:                              ;   in Loop: Header=BB0_166 Depth=2
	cbz	x26, LBB0_164
; %bb.191:                              ;   in Loop: Header=BB0_166 Depth=2
Lloh50:
	adrp	x1, l_.str.229@PAGE
Lloh51:
	add	x1, x1, l_.str.229@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	mov	x27, #0                         ; =0x0
	b	LBB0_193
LBB0_192:                               ;   in Loop: Header=BB0_193 Depth=3
	add	x27, x27, #1
	cmp	x27, #64
	b.eq	LBB0_273
LBB0_193:                               ;   Parent Loop BB0_158 Depth=1
                                        ;     Parent Loop BB0_166 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x8, x26, x27
	tbz	w8, #0, LBB0_192
; %bb.194:                              ;   in Loop: Header=BB0_193 Depth=3
	stp	x27, x27, [sp]
Lloh52:
	adrp	x1, l_.str.230@PAGE
Lloh53:
	add	x1, x1, l_.str.230@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	b	LBB0_192
LBB0_195:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh54:
	adrp	x1, l_.str.198@PAGE
Lloh55:
	add	x1, x1, l_.str.198@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	cmp	w26, #8
	b.ne	LBB0_197
; %bb.196:                              ;   in Loop: Header=BB0_166 Depth=2
Lloh56:
	adrp	x1, l_.str.199@PAGE
Lloh57:
	add	x1, x1, l_.str.199@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
LBB0_197:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh58:
	adrp	x1, l_.str.200@PAGE
Lloh59:
	add	x1, x1, l_.str.200@PAGEOFF
	b	LBB0_235
LBB0_198:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #656]
	cmp	w26, #11
	cset	w9, eq
Lloh60:
	adrp	x10, l_.str.203@PAGE
Lloh61:
	add	x10, x10, l_.str.203@PAGEOFF
Lloh62:
	adrp	x11, l_.str.202@PAGE
Lloh63:
	add	x11, x11, l_.str.202@PAGEOFF
	csel	x10, x11, x10, eq
	stp	x9, x10, [sp, #8]
	str	x8, [sp]
Lloh64:
	adrp	x1, l_.str.201@PAGE
Lloh65:
	add	x1, x1, l_.str.201@PAGEOFF
	b	LBB0_235
LBB0_199:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #672]
	ldrh	w9, [sp, #664]
	cmp	w26, #251
	csel	w10, w8, w9, eq
	ldrh	w9, [sp, #680]
	csel	w8, w9, w8, eq
	and	w27, w8, #0xffff
	cmp	w27, #12
	b.hs	LBB0_164
; %bb.200:                              ;   in Loop: Header=BB0_166 Depth=2
	str	x10, [sp, #56]                  ; 8-byte Folded Spill
	cbz	w27, LBB0_233
; %bb.201:                              ;   in Loop: Header=BB0_166 Depth=2
	str	x27, [sp]
Lloh66:
	adrp	x1, l_.str.221@PAGE
Lloh67:
	add	x1, x1, l_.str.221@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	mov	w26, #0                         ; =0x0
	str	x27, [sp, #48]                  ; 8-byte Folded Spill
                                        ; kill: def $w27 killed $w27 killed $x27 def $x27
LBB0_202:                               ;   Parent Loop BB0_158 Depth=1
                                        ;     Parent Loop BB0_166 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	stp	x27, x26, [sp]
Lloh68:
	adrp	x1, l_.str.222@PAGE
Lloh69:
	add	x1, x1, l_.str.222@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	add	w26, w26, #1
	subs	w27, w27, #1
	b.ne	LBB0_202
; %bb.203:                              ;   in Loop: Header=BB0_166 Depth=2
Lloh70:
	adrp	x1, l_.str.223@PAGE
Lloh71:
	add	x1, x1, l_.str.223@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	ldr	w8, [sp, #1232]
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	str	x9, [sp, #16]
	b	LBB0_234
LBB0_204:                               ;   in Loop: Header=BB0_166 Depth=2
	cmp	w26, #68
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, eq
	stp	x8, x8, [sp]
Lloh72:
	adrp	x1, l_.str.192@PAGE
Lloh73:
	add	x1, x1, l_.str.192@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	cmp	w26, #68
	b.ne	LBB0_206
; %bb.205:                              ;   in Loop: Header=BB0_166 Depth=2
Lloh74:
	adrp	x1, l_.str.193@PAGE
Lloh75:
	add	x1, x1, l_.str.193@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
LBB0_206:                               ;   in Loop: Header=BB0_166 Depth=2
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	str	x26, [sp]
Lloh76:
	adrp	x1, l_.str.194@PAGE
Lloh77:
	add	x1, x1, l_.str.194@PAGEOFF
	b	LBB0_235
LBB0_207:                               ;   in Loop: Header=BB0_166 Depth=2
	cmp	w26, #57
	cset	w8, eq
	str	x8, [sp]
Lloh78:
	adrp	x1, l_.str.220@PAGE
Lloh79:
	add	x1, x1, l_.str.220@PAGEOFF
	b	LBB0_223
LBB0_208:                               ;   in Loop: Header=BB0_166 Depth=2
	cmp	w26, #3
	b.ne	LBB0_229
; %bb.209:                              ;   in Loop: Header=BB0_166 Depth=2
	ldrb	w9, [sp, #656]
	b	LBB0_230
LBB0_210:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh80:
	adrp	x1, l_.str.228@PAGE
Lloh81:
	add	x1, x1, l_.str.228@PAGEOFF
	b	LBB0_235
LBB0_211:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #656]
	str	x8, [sp]
Lloh82:
	adrp	x1, l_.str.209@PAGE
Lloh83:
	add	x1, x1, l_.str.209@PAGEOFF
	b	LBB0_235
LBB0_212:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh84:
	adrp	x1, l_.str.208@PAGE
Lloh85:
	add	x1, x1, l_.str.208@PAGEOFF
	b	LBB0_235
LBB0_213:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh86:
	adrp	x1, l_.str.196@PAGE
Lloh87:
	add	x1, x1, l_.str.196@PAGEOFF
	b	LBB0_235
LBB0_214:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh88:
	adrp	x1, l_.str.206@PAGE
Lloh89:
	add	x1, x1, l_.str.206@PAGEOFF
	b	LBB0_235
LBB0_215:                               ;   in Loop: Header=BB0_166 Depth=2
	ldr	w8, [sp, #1232]
	mov	w26, #52429                     ; =0xcccd
	movk	w26, #52428, lsl #16
	umull	x8, w8, w26
	lsr	x8, x8, #34
	add	w8, w8, w8, lsl #3
	add	w1, w8, #8
	add	x2, sp, #544
	mov	x0, x24
	bl	_nvm_services_indirect_hosted_type
	ldr	w1, [sp, #1232]
	cbz	w0, LBB0_231
; %bb.216:                              ;   in Loop: Header=BB0_166 Depth=2
	umull	x8, w1, w26
	lsr	x8, x8, #34
	add	w8, w8, w8, lsl #2
	sub	w0, w1, w8
	bl	_nl_socket_catalog_method
	b	LBB0_251
LBB0_217:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh90:
	adrp	x1, l_.str.233@PAGE
Lloh91:
	add	x1, x1, l_.str.233@PAGEOFF
	add	x0, sp, #448
	b	LBB0_239
LBB0_218:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh92:
	adrp	x1, l_.str.197@PAGE
Lloh93:
	add	x1, x1, l_.str.197@PAGEOFF
	b	LBB0_235
LBB0_219:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh94:
	adrp	x1, l_.str.191@PAGE
Lloh95:
	add	x1, x1, l_.str.191@PAGEOFF
	b	LBB0_235
LBB0_220:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh96:
	adrp	x1, l_.str.205@PAGE
Lloh97:
	add	x1, x1, l_.str.205@PAGEOFF
	b	LBB0_235
LBB0_221:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #656]
	ldrb	w9, [sp, #664]
	cmp	w9, #0
	mov	w9, #2                          ; =0x2
	cinc	x9, x9, ne
	stp	x8, x9, [sp]
Lloh98:
	adrp	x1, l_.str.211@PAGE
Lloh99:
	add	x1, x1, l_.str.211@PAGEOFF
	b	LBB0_235
LBB0_222:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #656]
	str	x8, [sp]
Lloh100:
	adrp	x1, l_.str.210@PAGE
Lloh101:
	add	x1, x1, l_.str.210@PAGEOFF
LBB0_223:                               ;   in Loop: Header=BB0_166 Depth=2
	add	x0, sp, #448
	bl	_fn_text
	ldrb	w8, [sp, #716]
	cmp	w8, #2
	b.ne	LBB0_164
; %bb.224:                              ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #714]
	ldrh	w9, [sp, #712]
	stp	x8, x9, [sp]
Lloh102:
	adrp	x1, l_.str.234@PAGE
Lloh103:
	add	x1, x1, l_.str.234@PAGEOFF
	add	x0, sp, #448
	b	LBB0_239
LBB0_225:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w27, #0                         ; =0x0
LBB0_226:                               ;   in Loop: Header=BB0_166 Depth=2
	and	w8, w26, #0xfe
	str	w8, [sp, #56]                   ; 4-byte Folded Spill
	cmp	w8, #48
	mov	w8, #50                         ; =0x32
	ccmp	w26, w8, #4, ne
	mov	w8, #4                          ; =0x4
	csinc	w8, w8, wzr, eq
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	sub	w8, w26, #32
	cmp	w8, #181
	b.hi	LBB0_268
; %bb.227:                              ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #1                         ; =0x1
Lloh104:
	adrp	x11, lJTI0_1@PAGE
Lloh105:
	add	x11, x11, lJTI0_1@PAGEOFF
	adr	x9, LBB0_228
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
Lloh106:
	adrp	x8, l_.str.236@PAGE
Lloh107:
	add	x8, x8, l_.str.236@PAGEOFF
	br	x9
LBB0_228:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #1                         ; =0x1
Lloh108:
	adrp	x8, l_.str.237@PAGE
Lloh109:
	add	x8, x8, l_.str.237@PAGEOFF
	b	LBB0_260
LBB0_229:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	x9, #0                          ; =0x0
LBB0_230:                               ;   in Loop: Header=BB0_166 Depth=2
	stp	x8, x9, [sp]
Lloh110:
	adrp	x1, l_.str.195@PAGE
Lloh111:
	add	x1, x1, l_.str.195@PAGEOFF
	b	LBB0_235
LBB0_231:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	x0, x24
	bl	_services_dispatch_websocket
	mov	x8, x0
	ldr	w9, [sp, #1232]
	mov	w10, #52429                     ; =0xcccd
	movk	w10, #52428, lsl #16
	umull	x10, w9, w10
	lsr	x10, x10, #34
	add	w10, w10, w10, lsl #2
	sub	w0, w9, w10
	cbz	w8, LBB0_250
; %bb.232:                              ;   in Loop: Header=BB0_166 Depth=2
	bl	_nl_websocket_catalog_method
	b	LBB0_251
LBB0_233:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh112:
	adrp	x1, l_.str.224@PAGE
Lloh113:
	add	x1, x1, l_.str.224@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	ldr	w8, [sp, #1232]
	str	x27, [sp, #16]
LBB0_234:                               ;   in Loop: Header=BB0_166 Depth=2
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	and	x9, x9, #0xffff
	stp	x8, x9, [sp]
Lloh114:
	adrp	x1, l_.str.225@PAGE
Lloh115:
	add	x1, x1, l_.str.225@PAGEOFF
LBB0_235:                               ;   in Loop: Header=BB0_166 Depth=2
	add	x0, sp, #448
LBB0_236:                               ;   in Loop: Header=BB0_166 Depth=2
	bl	_fn_text
LBB0_237:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrb	w8, [sp, #716]
	cmp	w8, #1
	b.ne	LBB0_164
; %bb.238:                              ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #712]
	str	x8, [sp]
	add	x0, sp, #448
Lloh116:
	adrp	x1, l_.str.235@PAGE
Lloh117:
	add	x1, x1, l_.str.235@PAGEOFF
LBB0_239:                               ;   in Loop: Header=BB0_166 Depth=2
	bl	_fn_text
	b	LBB0_165
LBB0_240:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh118:
	adrp	x8, l_.str.247@PAGE
Lloh119:
	add	x8, x8, l_.str.247@PAGEOFF
	b	LBB0_260
LBB0_241:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #1                         ; =0x1
Lloh120:
	adrp	x8, l_.str.240@PAGE
Lloh121:
	add	x8, x8, l_.str.240@PAGEOFF
	b	LBB0_260
LBB0_242:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #1                         ; =0x1
Lloh122:
	adrp	x8, l_.str.241@PAGE
Lloh123:
	add	x8, x8, l_.str.241@PAGEOFF
	b	LBB0_260
LBB0_243:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh124:
	adrp	x8, l_.str.245@PAGE
Lloh125:
	add	x8, x8, l_.str.245@PAGEOFF
	b	LBB0_260
LBB0_244:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #1                         ; =0x1
Lloh126:
	adrp	x8, l_.str.238@PAGE
Lloh127:
	add	x8, x8, l_.str.238@PAGEOFF
	b	LBB0_260
LBB0_245:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh128:
	adrp	x8, l_.str.242@PAGE
Lloh129:
	add	x8, x8, l_.str.242@PAGEOFF
	b	LBB0_260
LBB0_246:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #1                         ; =0x1
Lloh130:
	adrp	x8, l_.str.239@PAGE
Lloh131:
	add	x8, x8, l_.str.239@PAGEOFF
	b	LBB0_260
LBB0_247:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh132:
	adrp	x8, l_.str.243@PAGE
Lloh133:
	add	x8, x8, l_.str.243@PAGEOFF
	b	LBB0_260
LBB0_248:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh134:
	adrp	x8, l_.str.244@PAGE
Lloh135:
	add	x8, x8, l_.str.244@PAGEOFF
	b	LBB0_260
LBB0_249:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh136:
	adrp	x8, l_.str.246@PAGE
Lloh137:
	add	x8, x8, l_.str.246@PAGEOFF
	b	LBB0_260
LBB0_250:                               ;   in Loop: Header=BB0_166 Depth=2
	bl	_nl_file_catalog_method
LBB0_251:                               ;   in Loop: Header=BB0_166 Depth=2
	cbz	x0, LBB0_164
; %bb.252:                              ;   in Loop: Header=BB0_166 Depth=2
	ldr	x8, [x0, #56]
	cbz	x8, LBB0_164
; %bb.253:                              ;   in Loop: Header=BB0_166 Depth=2
	ldr	w9, [x0, #44]
	str	w9, [sp, #48]                   ; 4-byte Folded Spill
	cmp	w9, #1
	cset	w9, eq
	mvn	x9, x9
	add	x8, x9, x8
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	cmp	x8, #3
	b.hs	LBB0_164
; %bb.254:                              ;   in Loop: Header=BB0_166 Depth=2
Lloh138:
	adrp	x1, l_.str.212@PAGE
Lloh139:
	add	x1, x1, l_.str.212@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	cbz	x8, LBB0_269
; %bb.255:                              ;   in Loop: Header=BB0_166 Depth=2
	ldr	x26, [sp, #56]                  ; 8-byte Folded Reload
	str	x26, [sp]
Lloh140:
	adrp	x1, l_.str.213@PAGE
Lloh141:
	add	x1, x1, l_.str.213@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
Lloh142:
	adrp	x1, l_.str.214@PAGE
Lloh143:
	add	x1, x1, l_.str.214@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	mov	x27, #0                         ; =0x0
LBB0_256:                               ;   Parent Loop BB0_158 Depth=1
                                        ;     Parent Loop BB0_166 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	stp	x26, x27, [sp]
Lloh144:
	adrp	x1, l_.str.215@PAGE
Lloh145:
	add	x1, x1, l_.str.215@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	add	x27, x27, #1
	subs	x26, x26, #1
	b.ne	LBB0_256
	b	LBB0_270
LBB0_257:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh146:
	adrp	x8, l_.str.248@PAGE
Lloh147:
	add	x8, x8, l_.str.248@PAGEOFF
	b	LBB0_260
LBB0_258:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh148:
	adrp	x8, l_.str.250@PAGE
Lloh149:
	add	x8, x8, l_.str.250@PAGEOFF
	b	LBB0_260
LBB0_259:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w12, #4                         ; =0x4
Lloh150:
	adrp	x8, l_.str.249@PAGE
Lloh151:
	add	x8, x8, l_.str.249@PAGEOFF
LBB0_260:                               ;   in Loop: Header=BB0_166 Depth=2
	stp	x8, x12, [sp, #32]              ; 16-byte Folded Spill
	cmp	w27, #0
	mov	w8, #1                          ; =0x1
	cinc	x26, x8, eq
	str	x26, [sp]
	add	x0, sp, #448
Lloh152:
	adrp	x1, l_.str.221@PAGE
Lloh153:
	add	x1, x1, l_.str.221@PAGEOFF
	bl	_fn_text
	stp	xzr, xzr, [sp, #16]
	add	x0, sp, #448
	stp	x26, xzr, [sp]
Lloh154:
	adrp	x1, l_.str.251@PAGE
Lloh155:
	add	x1, x1, l_.str.251@PAGEOFF
	bl	_fn_text
	tbnz	w27, #0, LBB0_262
; %bb.261:                              ;   in Loop: Header=BB0_166 Depth=2
	mov	w8, #1                          ; =0x1
	stp	x8, x8, [sp, #16]
	add	x0, sp, #448
	stp	x8, x8, [sp]
Lloh156:
	adrp	x1, l_.str.251@PAGE
Lloh157:
	add	x1, x1, l_.str.251@PAGEOFF
	bl	_fn_text
LBB0_262:                               ;   in Loop: Header=BB0_166 Depth=2
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp]
	add	x0, sp, #448
Lloh158:
	adrp	x1, l_.str.252@PAGE
Lloh159:
	add	x1, x1, l_.str.252@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	cmp	w8, #40
Lloh160:
	adrp	x26, l_.str.254@PAGE
Lloh161:
	add	x26, x26, l_.str.254@PAGEOFF
	b.ne	LBB0_264
; %bb.263:                              ;   in Loop: Header=BB0_166 Depth=2
	add	x0, sp, #448
Lloh162:
	adrp	x1, l_.str.253@PAGE
Lloh163:
	add	x1, x1, l_.str.253@PAGEOFF
	bl	_fn_text
LBB0_264:                               ;   in Loop: Header=BB0_166 Depth=2
	str	xzr, [sp]
	add	x0, sp, #448
	mov	x1, x26
	bl	_fn_text
	tbz	w27, #0, LBB0_266
; %bb.265:                              ;   in Loop: Header=BB0_166 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
Lloh164:
	adrp	x8, l_.str.256@PAGE
Lloh165:
	add	x8, x8, l_.str.256@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #448
Lloh166:
	adrp	x1, l_.str.255@PAGE
Lloh167:
	add	x1, x1, l_.str.255@PAGEOFF
	bl	_fn_text
	mov	w8, #0                          ; =0x0
Lloh168:
	adrp	x27, l_.str.258@PAGE
Lloh169:
	add	x27, x27, l_.str.258@PAGEOFF
	b	LBB0_267
LBB0_266:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	x1, x26
	mov	w26, #1                         ; =0x1
	str	x26, [sp]
	add	x0, sp, #448
	bl	_fn_text
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
Lloh170:
	adrp	x8, l_.str.257@PAGE
Lloh171:
	add	x8, x8, l_.str.257@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #448
Lloh172:
	adrp	x1, l_.str.255@PAGE
Lloh173:
	add	x1, x1, l_.str.255@PAGEOFF
	bl	_fn_text
	str	xzr, [sp]
	add	x0, sp, #448
Lloh174:
	adrp	x27, l_.str.258@PAGE
Lloh175:
	add	x27, x27, l_.str.258@PAGEOFF
	mov	x1, x27
	bl	_fn_text
	mov	x8, x26
LBB0_267:                               ;   in Loop: Header=BB0_166 Depth=2
	str	x8, [sp]
	add	x0, sp, #448
	mov	x1, x27
	bl	_fn_text
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x8, [sp]
	add	x0, sp, #448
Lloh176:
	adrp	x1, l_.str.259@PAGE
Lloh177:
	add	x1, x1, l_.str.259@PAGEOFF
	b	LBB0_236
LBB0_268:                               ;   in Loop: Header=BB0_166 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #472]
	b	LBB0_237
LBB0_269:                               ;   in Loop: Header=BB0_166 Depth=2
Lloh178:
	adrp	x1, l_.str.214@PAGE
Lloh179:
	add	x1, x1, l_.str.214@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
LBB0_270:                               ;   in Loop: Header=BB0_166 Depth=2
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB0_272
; %bb.271:                              ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #664]
	str	x8, [sp]
Lloh180:
	adrp	x1, l_.str.216@PAGE
Lloh181:
	add	x1, x1, l_.str.216@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
LBB0_272:                               ;   in Loop: Header=BB0_166 Depth=2
	ldr	w8, [sp, #656]
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	stp	x9, x9, [sp, #8]
	str	x8, [sp]
Lloh182:
	adrp	x1, l_.str.217@PAGE
Lloh183:
	add	x1, x1, l_.str.217@PAGEOFF
	b	LBB0_235
LBB0_273:                               ;   in Loop: Header=BB0_166 Depth=2
	ldrh	w8, [sp, #712]
	str	x8, [sp]
Lloh184:
	adrp	x1, l_.str.231@PAGE
Lloh185:
	add	x1, x1, l_.str.231@PAGEOFF
	add	x0, sp, #448
	b	LBB0_239
LBB0_274:                               ;   in Loop: Header=BB0_158 Depth=1
	add	x0, sp, #448
Lloh186:
	adrp	x1, l_.str.35@PAGE
Lloh187:
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_fn_text
	b	LBB0_157
LBB0_275:
	mov	w25, #2                         ; =0x2
	b	LBB0_148
LBB0_276:
Lloh188:
	adrp	x8, l_.str.11@PAGE
Lloh189:
	add	x8, x8, l_.str.11@PAGEOFF
	str	x8, [sp]
Lloh190:
	adrp	x1, l_.str.10@PAGE
Lloh191:
	add	x1, x1, l_.str.10@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
Lloh192:
	adrp	x1, l_.str.13@PAGE
Lloh193:
	add	x1, x1, l_.str.13@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
Lloh194:
	adrp	x8, l_.str.15@PAGE
Lloh195:
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [sp]
Lloh196:
	adrp	x23, l_.str.14@PAGE
Lloh197:
	add	x23, x23, l_.str.14@PAGEOFF
	add	x0, sp, #448
	mov	x1, x23
	bl	_fn_text
Lloh198:
	adrp	x8, l_.str.16@PAGE
Lloh199:
	add	x8, x8, l_.str.16@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #448
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #76]
	cbz	w8, LBB0_279
; %bb.277:
	mov	w24, #0                         ; =0x0
Lloh200:
	adrp	x23, l_.str.17@PAGE
Lloh201:
	add	x23, x23, l_.str.17@PAGEOFF
LBB0_278:                               ; =>This Inner Loop Header: Depth=1
	str	x24, [sp]
	add	x0, sp, #448
	mov	x1, x23
	bl	_fn_text
	add	w24, w24, #1
	ldr	w8, [sp, #76]
	cmp	w24, w8
	b.lo	LBB0_278
LBB0_279:
	ldr	w8, [sp, #72]
	cmn	w8, #1
	b.eq	LBB0_281
; %bb.280:
	str	x8, [sp]
Lloh202:
	adrp	x1, l_.str.18@PAGE
Lloh203:
	add	x1, x1, l_.str.18@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
LBB0_281:
	ldr	w8, [sp, #68]
	stp	x8, x8, [sp]
Lloh204:
	adrp	x1, l_.str.19@PAGE
Lloh205:
	add	x1, x1, l_.str.19@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
Lloh206:
	adrp	x8, l_.str.21@PAGE
Lloh207:
	add	x8, x8, l_.str.21@PAGEOFF
	stp	x22, x8, [sp]
Lloh208:
	adrp	x1, l_.str.20@PAGE
Lloh209:
	add	x1, x1, l_.str.20@PAGEOFF
	add	x0, sp, #448
	bl	_fn_text
	ldr	x0, [sp, #160]
	bl	_nvm_services_indirect_hosted_free
	ldr	w25, [sp, #472]
	ldr	x0, [sp, #448]
	cbz	w25, LBB0_284
; %bb.282:
	bl	_free
	cbz	x19, LBB0_148
; %bb.283:
Lloh210:
	adrp	x8, l_.str.3@PAGE
Lloh211:
	add	x8, x8, l_.str.3@PAGEOFF
	stp	x8, x25, [sp]
Lloh212:
	adrp	x2, l_.str.22@PAGE
Lloh213:
	add	x2, x2, l_.str.22@PAGEOFF
	b	LBB0_153
LBB0_284:
	str	x0, [x21]
	cbz	x19, LBB0_148
; %bb.285:
	strb	wzr, [x20]
	b	LBB0_148
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh108, Lloh109
	.loh AdrpAdd	Lloh110, Lloh111
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh192, Lloh193
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh210, Lloh211
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_237-LBB0_171)>>2
	.short	(LBB0_177-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_177-LBB0_171)>>2
	.short	(LBB0_219-LBB0_171)>>2
	.short	(LBB0_177-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_218-LBB0_171)>>2
	.short	(LBB0_195-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_198-LBB0_171)>>2
	.short	(LBB0_182-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_179-LBB0_171)>>2
	.short	(LBB0_198-LBB0_171)>>2
	.short	(LBB0_182-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_220-LBB0_171)>>2
	.short	(LBB0_214-LBB0_171)>>2
	.short	(LBB0_181-LBB0_171)>>2
	.short	(LBB0_181-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_226-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_226-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_237-LBB0_171)>>2
	.short	(LBB0_175-LBB0_171)>>2
	.short	(LBB0_175-LBB0_171)>>2
	.short	(LBB0_179-LBB0_171)>>2
	.short	(LBB0_183-LBB0_171)>>2
	.short	(LBB0_217-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_204-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_204-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_199-LBB0_171)>>2
	.short	(LBB0_171-LBB0_171)>>2
	.short	(LBB0_171-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_215-LBB0_171)>>2
	.short	(LBB0_222-LBB0_171)>>2
	.short	(LBB0_221-LBB0_171)>>2
	.short	(LBB0_211-LBB0_171)>>2
	.short	(LBB0_195-LBB0_171)>>2
	.short	(LBB0_212-LBB0_171)>>2
	.short	(LBB0_179-LBB0_171)>>2
	.short	(LBB0_183-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_175-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_226-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_213-LBB0_171)>>2
	.short	(LBB0_199-LBB0_171)>>2
	.short	(LBB0_171-LBB0_171)>>2
	.short	(LBB0_225-LBB0_171)>>2
	.short	(LBB0_171-LBB0_171)>>2
lJTI0_1:
	.byte	(LBB0_260-LBB0_228)>>2
	.byte	(LBB0_228-LBB0_228)>>2
	.byte	(LBB0_244-LBB0_228)>>2
	.byte	(LBB0_246-LBB0_228)>>2
	.byte	(LBB0_241-LBB0_228)>>2
	.byte	(LBB0_242-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_245-LBB0_228)>>2
	.byte	(LBB0_247-LBB0_228)>>2
	.byte	(LBB0_248-LBB0_228)>>2
	.byte	(LBB0_243-LBB0_228)>>2
	.byte	(LBB0_249-LBB0_228)>>2
	.byte	(LBB0_240-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_257-LBB0_228)>>2
	.byte	(LBB0_259-LBB0_228)>>2
	.byte	(LBB0_258-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_260-LBB0_228)>>2
	.byte	(LBB0_228-LBB0_228)>>2
	.byte	(LBB0_244-LBB0_228)>>2
	.byte	(LBB0_246-LBB0_228)>>2
	.byte	(LBB0_241-LBB0_228)>>2
	.byte	(LBB0_242-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_268-LBB0_228)>>2
	.byte	(LBB0_245-LBB0_228)>>2
	.byte	(LBB0_247-LBB0_228)>>2
	.byte	(LBB0_248-LBB0_228)>>2
	.byte	(LBB0_243-LBB0_228)>>2
	.byte	(LBB0_249-LBB0_228)>>2
	.byte	(LBB0_240-LBB0_228)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fn_preamble
_fn_preamble:                           ; @fn_preamble
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh214:
	adrp	x8, l_.str.23@PAGE
Lloh215:
	add	x8, x8, l_.str.23@PAGEOFF
	str	x8, [sp]
Lloh216:
	adrp	x20, l_.str.14@PAGE
Lloh217:
	add	x20, x20, l_.str.14@PAGEOFF
	mov	x1, x20
	bl	_fn_text
Lloh218:
	adrp	x8, l_.str.24@PAGE
Lloh219:
	add	x8, x8, l_.str.24@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh220:
	adrp	x8, l_.str.27@PAGE
Lloh221:
	add	x8, x8, l_.str.27@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh222:
	adrp	x8, l_.str.28@PAGE
Lloh223:
	add	x8, x8, l_.str.28@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh224:
	adrp	x8, l_.str.29@PAGE
Lloh225:
	add	x8, x8, l_.str.29@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh226:
	adrp	x8, l_.str.30@PAGE
Lloh227:
	add	x8, x8, l_.str.30@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh228:
	adrp	x8, l_.str.31@PAGE
Lloh229:
	add	x8, x8, l_.str.31@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh230:
	adrp	x8, l_.str.32@PAGE
Lloh231:
	add	x8, x8, l_.str.32@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh232:
	adrp	x8, l_.str.33@PAGE
Lloh233:
	add	x8, x8, l_.str.33@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh234:
	adrp	x8, l_.str.34@PAGE
Lloh235:
	add	x8, x8, l_.str.34@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh236:
	adrp	x8, l_.str.35@PAGE
Lloh237:
	add	x8, x8, l_.str.35@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh238:
	adrp	x8, l_.str.36@PAGE
Lloh239:
	add	x8, x8, l_.str.36@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh214, Lloh215
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_text
_fn_text:                               ; @fn_text
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cbz	w8, LBB2_2
; %bb.1:
	ret
LBB2_2:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	add	x8, x29, #16
	stp	x8, x8, [sp]
	add	x3, x29, #16
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, x20
	bl	_vsnprintf
	tbnz	w0, #31, LBB2_17
; %bb.3:
	lsr	w8, w0, #27
	cbnz	w8, LBB2_5
; %bb.4:
	mov	w22, w0
	ldr	x8, [x19, #8]
	mov	w9, #134217727                  ; =0x7ffffff
	sub	x9, x9, x22
	cmp	x8, x9
	b.ls	LBB2_6
LBB2_5:
	mov	w8, #3                          ; =0x3
	b	LBB2_18
LBB2_6:
	ldr	x21, [x19, #16]
	add	x9, x8, x22
	cmp	x9, x21
	b.hs	LBB2_8
; %bb.7:
	mov	x23, x0
	ldr	x0, [x19]
	b	LBB2_15
LBB2_8:
	mov	w8, #4096                       ; =0x1000
	cmp	x21, #0
	csel	x21, x8, x21, eq
	cmp	x21, x9
	b.hi	LBB2_13
; %bb.9:
	mov	w8, #67108864                   ; =0x4000000
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	cmp	x21, x8
	b.hi	LBB2_12
; %bb.11:                               ;   in Loop: Header=BB2_10 Depth=1
	lsl	x21, x21, #1
	cmp	x21, x9
	b.ls	LBB2_10
	b	LBB2_13
LBB2_12:
	mov	w21, #134217728                 ; =0x8000000
LBB2_13:
	mov	x23, x0
	ldr	x0, [x19]
	mov	x1, x21
	bl	_realloc
	cbz	x0, LBB2_20
; %bb.14:
	str	x0, [x19]
	str	x21, [x19, #16]
	ldr	x8, [x19, #8]
LBB2_15:
	sub	x1, x21, x8
	ldr	x3, [sp, #8]
	add	x0, x0, x8
	mov	x2, x20
	bl	_vsnprintf
	cmp	w0, w23
	b.ne	LBB2_17
; %bb.16:
	ldr	x8, [x19, #8]
	add	x8, x8, x22
	str	x8, [x19, #8]
	b	LBB2_19
LBB2_17:
	mov	w8, #1                          ; =0x1
LBB2_18:
	str	w8, [x19, #24]
LBB2_19:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB2_20:
	mov	w8, #4                          ; =0x4
	b	LBB2_18
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_agreement
_fn_agreement:                          ; @fn_agreement
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1696
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	str	x2, [sp, #64]                   ; 8-byte Folded Spill
	ldr	w8, [x2, #12]
	str	x1, [sp, #168]                  ; 8-byte Folded Spill
	cbz	w8, LBB3_83
; %bb.1:
	mov	x21, x1
	mov	w22, #0                         ; =0x0
	add	x8, sp, #304
	add	x24, x8, #72
	add	x26, x8, #48
	add	x9, x8, #16
Lloh240:
	adrp	x25, l_.str.178@PAGE
Lloh241:
	add	x25, x25, l_.str.178@PAGEOFF
	add	x8, x8, #78
	stp	x9, x8, [sp, #88]               ; 16-byte Folded Spill
	mov	w20, #2                         ; =0x2
Lloh242:
	adrp	x27, l_.str.105@PAGE
Lloh243:
	add	x27, x27, l_.str.105@PAGEOFF
Lloh244:
	adrp	x23, l_.str.97@PAGE
Lloh245:
	add	x23, x23, l_.str.97@PAGEOFF
	stp	x26, x24, [sp, #72]             ; 16-byte Folded Spill
	b	LBB3_3
LBB3_2:                                 ;   in Loop: Header=BB3_3 Depth=1
	add	w22, w22, #1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cmp	w22, w8
	b.hs	LBB3_83
LBB3_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_8 Depth 2
                                        ;       Child Loop BB3_13 Depth 3
                                        ;       Child Loop BB3_18 Depth 3
                                        ;       Child Loop BB3_34 Depth 3
                                        ;       Child Loop BB3_38 Depth 3
                                        ;       Child Loop BB3_43 Depth 3
                                        ;         Child Loop BB3_53 Depth 4
                                        ;         Child Loop BB3_57 Depth 4
                                        ;         Child Loop BB3_62 Depth 4
                                        ;         Child Loop BB3_76 Depth 4
	add	x2, sp, #208
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB3_118
; %bb.4:                                ;   in Loop: Header=BB3_3 Depth=1
	ldrh	w8, [sp, #216]
	cbz	w8, LBB3_2
; %bb.5:                                ;   in Loop: Header=BB3_3 Depth=1
	mov	w28, #0                         ; =0x0
	mov	x8, x22
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	stp	x8, x8, [sp, #104]              ; 16-byte Folded Spill
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	b	LBB3_8
LBB3_6:                                 ;   in Loop: Header=BB3_8 Depth=2
	str	w20, [x19, #24]
LBB3_7:                                 ;   in Loop: Header=BB3_8 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #216]
	cmp	w28, w8
	b.hs	LBB3_2
LBB3_8:                                 ;   Parent Loop BB3_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_13 Depth 3
                                        ;       Child Loop BB3_18 Depth 3
                                        ;       Child Loop BB3_34 Depth 3
                                        ;       Child Loop BB3_38 Depth 3
                                        ;       Child Loop BB3_43 Depth 3
                                        ;         Child Loop BB3_53 Depth 4
                                        ;         Child Loop BB3_57 Depth 4
                                        ;         Child Loop BB3_62 Depth 4
                                        ;         Child Loop BB3_76 Depth 4
	mov	x8, x28
	stp	x22, x8, [sp]
	mov	x0, x19
Lloh246:
	adrp	x1, l_.str.89@PAGE
Lloh247:
	add	x1, x1, l_.str.89@PAGEOFF
	bl	_fn_text
	add	x3, sp, #304
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_instruction
	cbz	w0, LBB3_6
; %bb.9:                                ;   in Loop: Header=BB3_8 Depth=2
	add	x3, sp, #303
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB3_6
; %bb.10:                               ;   in Loop: Header=BB3_8 Depth=2
	add	x3, sp, #300
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_component
	tbz	w0, #0, LBB3_6
; %bb.11:                               ;   in Loop: Header=BB3_8 Depth=2
	ldrb	w8, [sp, #303]
	ldrh	w9, [sp, #300]
	mov	x10, x28
	stp	x10, x9, [sp, #48]
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	stp	x8, x9, [sp, #32]
	stp	x9, x10, [sp, #16]
	stp	x9, x10, [sp]
	mov	x0, x19
Lloh248:
	adrp	x1, l_.str.90@PAGE
Lloh249:
	add	x1, x1, l_.str.90@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #304]
	str	x8, [sp, #8]
Lloh250:
	adrp	x8, l_.str.91@PAGE
Lloh251:
	add	x8, x8, l_.str.91@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #312]
	str	x8, [sp, #8]
Lloh252:
	adrp	x8, l_.str.92@PAGE
Lloh253:
	add	x8, x8, l_.str.92@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #313]
	str	x8, [sp, #8]
Lloh254:
	adrp	x8, l_.str.93@PAGE
Lloh255:
	add	x8, x8, l_.str.93@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #368]
	str	x8, [sp, #8]
Lloh256:
	adrp	x8, l_.str.94@PAGE
Lloh257:
	add	x8, x8, l_.str.94@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #380]
	str	x8, [sp, #8]
Lloh258:
	adrp	x8, l_.str.95@PAGE
Lloh259:
	add	x8, x8, l_.str.95@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #896]
	str	x8, [sp, #8]
Lloh260:
	adrp	x8, l_.str.96@PAGE
Lloh261:
	add	x8, x8, l_.str.96@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #380]
	cbz	w8, LBB3_14
; %bb.12:                               ;   in Loop: Header=BB3_8 Depth=2
	mov	x20, #0                         ; =0x0
LBB3_13:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x24, x20, lsl #1]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	add	x20, x20, #1
	ldrb	w8, [sp, #380]
	cmp	x20, x8
	b.lo	LBB3_13
LBB3_14:                                ;   in Loop: Header=BB3_8 Depth=2
	ldrb	w8, [sp, #313]
	cbz	w8, LBB3_28
; %bb.15:                               ;   in Loop: Header=BB3_8 Depth=2
	mov	x20, #0                         ; =0x0
	ldr	x23, [sp, #88]                  ; 8-byte Folded Reload
	b	LBB3_18
LBB3_16:                                ;   in Loop: Header=BB3_18 Depth=3
	ldrsw	x9, [x23]
Lloh262:
	adrp	x10, l_.str.101@PAGE
Lloh263:
	add	x10, x10, l_.str.101@PAGEOFF
LBB3_17:                                ;   in Loop: Header=BB3_18 Depth=3
	stp	x10, x9, [sp, #24]
	stp	x8, x20, [sp, #8]
	str	x20, [sp]
	mov	x0, x19
Lloh264:
	adrp	x1, l_.str.103@PAGE
Lloh265:
	add	x1, x1, l_.str.103@PAGEOFF
	bl	_fn_text
	add	x20, x20, #1
	ldrb	w8, [sp, #313]
	add	x23, x23, #8
	cmp	x20, x8
	b.hs	LBB3_28
LBB3_18:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [x26, x20, lsl #2]
	cmp	w8, #2
	b.le	LBB3_23
; %bb.19:                               ;   in Loop: Header=BB3_18 Depth=3
	cmp	w8, #3
	b.eq	LBB3_27
; %bb.20:                               ;   in Loop: Header=BB3_18 Depth=3
	cmp	w8, #4
	b.eq	LBB3_16
; %bb.21:                               ;   in Loop: Header=BB3_18 Depth=3
	cmp	w8, #5
	b.ne	LBB3_82
; %bb.22:                               ;   in Loop: Header=BB3_18 Depth=3
	ldr	x9, [x23]
Lloh266:
	adrp	x10, l_.str.102@PAGE
Lloh267:
	add	x10, x10, l_.str.102@PAGEOFF
	b	LBB3_17
LBB3_23:                                ;   in Loop: Header=BB3_18 Depth=3
	cmp	w8, #1
	b.eq	LBB3_26
; %bb.24:                               ;   in Loop: Header=BB3_18 Depth=3
	cmp	w8, #2
	b.ne	LBB3_82
; %bb.25:                               ;   in Loop: Header=BB3_18 Depth=3
	ldrh	w9, [x23]
Lloh268:
	adrp	x10, l_.str.99@PAGE
Lloh269:
	add	x10, x10, l_.str.99@PAGEOFF
	b	LBB3_17
LBB3_26:                                ;   in Loop: Header=BB3_18 Depth=3
	ldrb	w9, [x23]
Lloh270:
	adrp	x10, l_.str.98@PAGE
Lloh271:
	add	x10, x10, l_.str.98@PAGEOFF
	b	LBB3_17
LBB3_27:                                ;   in Loop: Header=BB3_18 Depth=3
	ldr	w9, [x23]
Lloh272:
	adrp	x10, l_.str.100@PAGE
Lloh273:
	add	x10, x10, l_.str.100@PAGEOFF
	b	LBB3_17
LBB3_28:                                ;   in Loop: Header=BB3_8 Depth=2
	ldrb	w8, [sp, #312]
	cmp	w8, #15
Lloh274:
	adrp	x23, l_.str.104@PAGE
Lloh275:
	add	x23, x23, l_.str.104@PAGEOFF
	b.eq	LBB3_31
; %bb.29:                               ;   in Loop: Header=BB3_8 Depth=2
	cmp	w8, #151
	b.eq	LBB3_31
; %bb.30:                               ;   in Loop: Header=BB3_8 Depth=2
	cmp	w8, #59
	b.ne	LBB3_36
LBB3_31:                                ;   in Loop: Header=BB3_8 Depth=2
	ldr	w1, [sp, #320]
	add	x2, sp, #984
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB3_82
; %bb.32:                               ;   in Loop: Header=BB3_8 Depth=2
	ldrh	w8, [sp, #996]
	ldr	x27, [sp, #96]                  ; 8-byte Folded Reload
	cbz	w8, LBB3_35
; %bb.33:                               ;   in Loop: Header=BB3_8 Depth=2
	mov	x20, #0                         ; =0x0
LBB3_34:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x27, x20, lsl #1]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	add	x20, x20, #1
	ldrh	w8, [sp, #996]
	cmp	x20, x8
	b.lo	LBB3_34
LBB3_35:                                ;   in Loop: Header=BB3_8 Depth=2
	ldrb	w8, [sp, #312]
Lloh276:
	adrp	x27, l_.str.105@PAGE
Lloh277:
	add	x27, x27, l_.str.105@PAGEOFF
LBB3_36:                                ;   in Loop: Header=BB3_8 Depth=2
	ldrh	w9, [sp, #320]
	cmp	w8, #152
	ccmp	w9, #0, #4, eq
	ldr	x24, [sp, #96]                  ; 8-byte Folded Reload
	b.eq	LBB3_39
; %bb.37:                               ;   in Loop: Header=BB3_8 Depth=2
	mov	x20, #0                         ; =0x0
LBB3_38:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x24, x20, lsl #1]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	add	x20, x20, #1
	ldrh	w8, [sp, #320]
	cmp	x20, x8
	b.lo	LBB3_38
LBB3_39:                                ;   in Loop: Header=BB3_8 Depth=2
	ldrb	w8, [sp, #303]
	mov	w20, #2                         ; =0x2
Lloh278:
	adrp	x23, l_.str.97@PAGE
Lloh279:
	add	x23, x23, l_.str.97@PAGEOFF
	cbz	w8, LBB3_78
; %bb.40:                               ;   in Loop: Header=BB3_8 Depth=2
	mov	w26, #0                         ; =0x0
	mov	x8, x28
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	str	x8, [sp, #184]                  ; 8-byte Folded Spill
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	b	LBB3_43
LBB3_41:                                ;   in Loop: Header=BB3_43 Depth=3
	str	w20, [x19, #24]
LBB3_42:                                ;   in Loop: Header=BB3_43 Depth=3
	add	w26, w26, #1
	ldrb	w8, [sp, #303]
	cmp	w26, w8
	b.hs	LBB3_78
LBB3_43:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB3_53 Depth 4
                                        ;         Child Loop BB3_57 Depth 4
                                        ;         Child Loop BB3_62 Depth 4
                                        ;         Child Loop BB3_76 Depth 4
	sub	x4, x29, #192
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	mov	x3, x26
	bl	_nvm_services_indirect_hosted_variant
	tbz	w0, #0, LBB3_41
; %bb.44:                               ;   in Loop: Header=BB3_43 Depth=3
	mov	x8, x26
	stp	x28, x8, [sp, #8]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x27
	bl	_fn_text
	ldurh	w8, [x29, #-192]
	str	x8, [sp, #8]
Lloh280:
	adrp	x8, l_.str.106@PAGE
Lloh281:
	add	x8, x8, l_.str.106@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-190]
	str	x8, [sp, #8]
Lloh282:
	adrp	x8, l_.str.107@PAGE
Lloh283:
	add	x8, x8, l_.str.107@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-188]
	str	x8, [sp, #8]
Lloh284:
	adrp	x8, l_.str.108@PAGE
Lloh285:
	add	x8, x8, l_.str.108@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-186]
	str	x8, [sp, #8]
Lloh286:
	adrp	x8, l_.str.109@PAGE
Lloh287:
	add	x8, x8, l_.str.109@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-184]
	str	x8, [sp, #8]
Lloh288:
	adrp	x8, l_.str.110@PAGE
Lloh289:
	add	x8, x8, l_.str.110@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-182]
	str	x8, [sp, #8]
Lloh290:
	adrp	x8, l_.str.111@PAGE
Lloh291:
	add	x8, x8, l_.str.111@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-180]
	str	x8, [sp, #8]
Lloh292:
	adrp	x8, l_.str.112@PAGE
Lloh293:
	add	x8, x8, l_.str.112@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-178]
	str	x8, [sp, #8]
Lloh294:
	adrp	x8, l_.str.113@PAGE
Lloh295:
	add	x8, x8, l_.str.113@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-176]
	str	x8, [sp, #8]
Lloh296:
	adrp	x8, l_.str.114@PAGE
Lloh297:
	add	x8, x8, l_.str.114@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-174]
	str	x8, [sp, #8]
Lloh298:
	adrp	x8, l_.str.115@PAGE
Lloh299:
	add	x8, x8, l_.str.115@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-92]
	str	x8, [sp, #8]
Lloh300:
	adrp	x8, l_.str.116@PAGE
Lloh301:
	add	x8, x8, l_.str.116@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-91]
	str	x8, [sp, #8]
Lloh302:
	adrp	x8, l_.str.117@PAGE
Lloh303:
	add	x8, x8, l_.str.117@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-90]
	str	x8, [sp, #8]
Lloh304:
	adrp	x8, l_.str.118@PAGE
Lloh305:
	add	x8, x8, l_.str.118@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-172]
	str	x8, [sp, #8]
Lloh306:
	adrp	x8, l_.str.119@PAGE
Lloh307:
	add	x8, x8, l_.str.119@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-171]
	str	x8, [sp, #8]
Lloh308:
	adrp	x8, l_.str.120@PAGE
Lloh309:
	add	x8, x8, l_.str.120@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-170]
	str	x8, [sp, #8]
Lloh310:
	adrp	x8, l_.str.121@PAGE
Lloh311:
	add	x8, x8, l_.str.121@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-169]
	str	x8, [sp, #8]
Lloh312:
	adrp	x8, l_.str.122@PAGE
Lloh313:
	add	x8, x8, l_.str.122@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-168]
	str	x8, [sp, #8]
Lloh314:
	adrp	x8, l_.str.123@PAGE
Lloh315:
	add	x8, x8, l_.str.123@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-166]
	str	x8, [sp, #8]
Lloh316:
	adrp	x8, l_.str.124@PAGE
Lloh317:
	add	x8, x8, l_.str.124@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-164]
	str	x8, [sp, #8]
Lloh318:
	adrp	x8, l_.str.125@PAGE
Lloh319:
	add	x8, x8, l_.str.125@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-160]
	str	x8, [sp, #8]
Lloh320:
	adrp	x8, l_.str.126@PAGE
Lloh321:
	add	x8, x8, l_.str.126@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-156]
	str	x8, [sp, #8]
Lloh322:
	adrp	x8, l_.str.127@PAGE
Lloh323:
	add	x8, x8, l_.str.127@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-152]
	str	x8, [sp, #8]
Lloh324:
	adrp	x8, l_.str.128@PAGE
Lloh325:
	add	x8, x8, l_.str.128@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-169]
	cmp	w8, #1
	b.ne	LBB3_46
; %bb.45:                               ;   in Loop: Header=BB3_43 Depth=3
	ldur	w8, [x29, #-148]
	str	x8, [sp, #8]
Lloh326:
	adrp	x8, l_.str.129@PAGE
Lloh327:
	add	x8, x8, l_.str.129@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-144]
	str	x8, [sp, #8]
Lloh328:
	adrp	x8, l_.str.130@PAGE
Lloh329:
	add	x8, x8, l_.str.130@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-140]
	str	x8, [sp, #8]
Lloh330:
	adrp	x8, l_.str.131@PAGE
Lloh331:
	add	x8, x8, l_.str.131@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-136]
	str	x8, [sp, #8]
Lloh332:
	adrp	x8, l_.str.132@PAGE
Lloh333:
	add	x8, x8, l_.str.132@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-132]
	str	x8, [sp, #8]
Lloh334:
	adrp	x8, l_.str.133@PAGE
Lloh335:
	add	x8, x8, l_.str.133@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-128]
	str	x8, [sp, #8]
Lloh336:
	adrp	x8, l_.str.134@PAGE
Lloh337:
	add	x8, x8, l_.str.134@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-124]
	str	x8, [sp, #8]
Lloh338:
	adrp	x8, l_.str.135@PAGE
Lloh339:
	add	x8, x8, l_.str.135@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-122]
	str	x8, [sp, #8]
Lloh340:
	adrp	x8, l_.str.136@PAGE
Lloh341:
	add	x8, x8, l_.str.136@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-120]
	str	x8, [sp, #8]
Lloh342:
	adrp	x8, l_.str.137@PAGE
Lloh343:
	add	x8, x8, l_.str.137@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-118]
	str	x8, [sp, #8]
Lloh344:
	adrp	x8, l_.str.138@PAGE
Lloh345:
	add	x8, x8, l_.str.138@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-100]
	str	x8, [sp, #8]
Lloh346:
	adrp	x8, l_.str.139@PAGE
Lloh347:
	add	x8, x8, l_.str.139@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-96]
	str	x8, [sp, #8]
Lloh348:
	adrp	x8, l_.str.140@PAGE
Lloh349:
	add	x8, x8, l_.str.140@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	sub	x8, x29, #192
	ldur	x2, [x8, #76]
	ldur	x3, [x8, #84]
	mov	x0, x19
Lloh350:
	adrp	x1, l_.str.141@PAGE
Lloh351:
	add	x1, x1, l_.str.141@PAGEOFF
	bl	_fn_declaration
LBB3_46:                                ;   in Loop: Header=BB3_43 Depth=3
	add	x3, sp, #984
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_instruction
	tbz	w0, #0, LBB3_71
; %bb.47:                               ;   in Loop: Header=BB3_43 Depth=3
	ldrb	w8, [sp, #992]
	cmp	w8, #152
	b.eq	LBB3_49
; %bb.48:                               ;   in Loop: Header=BB3_43 Depth=3
	cmp	w8, #60
	b.ne	LBB3_51
LBB3_49:                                ;   in Loop: Header=BB3_43 Depth=3
	add	x4, sp, #904
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	mov	x3, x26
	bl	_nvm_services_indirect_hosted_call
	cbz	w0, LBB3_71
; %bb.50:                               ;   in Loop: Header=BB3_43 Depth=3
	mov	x8, x26
	str	x8, [sp, #16]
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh352:
	adrp	x1, l_.str.142@PAGE
Lloh353:
	add	x1, x1, l_.str.142@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #904]
	str	x8, [sp, #8]
Lloh354:
	adrp	x8, l_.str.143@PAGE
Lloh355:
	add	x8, x8, l_.str.143@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #908]
	str	x8, [sp, #8]
Lloh356:
	adrp	x8, l_.str.144@PAGE
Lloh357:
	add	x8, x8, l_.str.144@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	x9, [sp, #912]
Lloh358:
	adrp	x8, l_.str.145@PAGE
Lloh359:
	add	x8, x8, l_.str.145@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	x9, [sp, #920]
Lloh360:
	adrp	x8, l_.str.146@PAGE
Lloh361:
	add	x8, x8, l_.str.146@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #928]
	str	x8, [sp, #8]
Lloh362:
	adrp	x8, l_.str.147@PAGE
Lloh363:
	add	x8, x8, l_.str.147@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #932]
	str	x8, [sp, #8]
Lloh364:
	adrp	x8, l_.str.148@PAGE
Lloh365:
	add	x8, x8, l_.str.148@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #936]
	str	x8, [sp, #8]
Lloh366:
	adrp	x8, l_.str.149@PAGE
Lloh367:
	add	x8, x8, l_.str.149@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #940]
	str	x8, [sp, #8]
Lloh368:
	adrp	x8, l_.str.150@PAGE
Lloh369:
	add	x8, x8, l_.str.150@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #944]
	str	x8, [sp, #8]
Lloh370:
	adrp	x8, l_.str.151@PAGE
Lloh371:
	add	x8, x8, l_.str.151@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #948]
	str	x8, [sp, #8]
Lloh372:
	adrp	x8, l_.str.152@PAGE
Lloh373:
	add	x8, x8, l_.str.152@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrh	w8, [sp, #952]
	str	x8, [sp, #8]
Lloh374:
	adrp	x8, l_.str.153@PAGE
Lloh375:
	add	x8, x8, l_.str.153@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrh	w8, [sp, #954]
	str	x8, [sp, #8]
Lloh376:
	adrp	x8, l_.str.154@PAGE
Lloh377:
	add	x8, x8, l_.str.154@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrh	w8, [sp, #956]
	str	x8, [sp, #8]
Lloh378:
	adrp	x8, l_.str.155@PAGE
Lloh379:
	add	x8, x8, l_.str.155@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #958]
	str	x8, [sp, #8]
Lloh380:
	adrp	x8, l_.str.156@PAGE
Lloh381:
	add	x8, x8, l_.str.156@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #976]
	str	x8, [sp, #8]
Lloh382:
	adrp	x8, l_.str.157@PAGE
Lloh383:
	add	x8, x8, l_.str.157@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #980]
	str	x8, [sp, #8]
Lloh384:
	adrp	x8, l_.str.158@PAGE
Lloh385:
	add	x8, x8, l_.str.158@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	x2, [sp, #960]
	ldr	x3, [sp, #968]
	mov	x0, x19
Lloh386:
	adrp	x1, l_.str.159@PAGE
Lloh387:
	add	x1, x1, l_.str.159@PAGEOFF
	bl	_fn_declaration
	mov	x0, x19
Lloh388:
	adrp	x1, l_.str.35@PAGE
Lloh389:
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_fn_text
LBB3_51:                                ;   in Loop: Header=BB3_43 Depth=3
	ldurh	w8, [x29, #-192]
	cbz	w8, LBB3_55
; %bb.52:                               ;   in Loop: Header=BB3_43 Depth=3
	mov	w20, #0                         ; =0x0
LBB3_53:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ;       Parent Loop BB3_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x5, sp, #904
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	mov	x3, x26
	mov	x4, x20
	bl	_nvm_services_indirect_hosted_input_local
	cbz	w0, LBB3_72
; %bb.54:                               ;   in Loop: Header=BB3_53 Depth=4
	stp	x26, x20, [sp, #16]
	ldp	x8, x9, [sp, #192]              ; 16-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh390:
	adrp	x1, l_.str.160@PAGE
Lloh391:
	add	x1, x1, l_.str.160@PAGEOFF
	bl	_fn_text
	ldr	x2, [sp, #904]
	ldr	x3, [sp, #912]
	ldrb	w23, [sp, #920]
	ldr	x27, [sp, #928]
	ldr	w24, [sp, #936]
	mov	x0, x19
Lloh392:
	adrp	x1, l_.str.174@PAGE
Lloh393:
	add	x1, x1, l_.str.174@PAGEOFF
	bl	_fn_declaration
Lloh394:
	adrp	x8, l_.str.175@PAGE
Lloh395:
	add	x8, x8, l_.str.175@PAGEOFF
	stp	x8, x23, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
Lloh396:
	adrp	x8, l_.str.176@PAGE
Lloh397:
	add	x8, x8, l_.str.176@PAGEOFF
	stp	x8, x27, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
Lloh398:
	adrp	x8, l_.str.177@PAGE
Lloh399:
	add	x8, x8, l_.str.177@PAGEOFF
	stp	x8, x24, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	add	w20, w20, #1
	ldurh	w8, [x29, #-192]
	cmp	w20, w8
	b.lo	LBB3_53
LBB3_55:                                ;   in Loop: Header=BB3_43 Depth=3
	ldurh	w8, [x29, #-190]
	cbz	w8, LBB3_59
; %bb.56:                               ;   in Loop: Header=BB3_43 Depth=3
	mov	w20, #0                         ; =0x0
	mov	x23, x26
LBB3_57:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ;       Parent Loop BB3_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x5, sp, #904
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	mov	x3, x26
	mov	x4, x20
	bl	_nvm_services_indirect_hosted_input_stack
	cbz	w0, LBB3_72
; %bb.58:                               ;   in Loop: Header=BB3_57 Depth=4
	stp	x23, x20, [sp, #16]
	ldp	x8, x9, [sp, #176]              ; 16-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh400:
	adrp	x1, l_.str.161@PAGE
Lloh401:
	add	x1, x1, l_.str.161@PAGEOFF
	bl	_fn_text
	ldr	x2, [sp, #904]
	ldr	x3, [sp, #912]
	ldrb	w24, [sp, #920]
	ldr	x27, [sp, #928]
	ldr	w21, [sp, #936]
	mov	x0, x19
Lloh402:
	adrp	x1, l_.str.174@PAGE
Lloh403:
	add	x1, x1, l_.str.174@PAGEOFF
	bl	_fn_declaration
Lloh404:
	adrp	x8, l_.str.175@PAGE
Lloh405:
	add	x8, x8, l_.str.175@PAGEOFF
	stp	x8, x24, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
Lloh406:
	adrp	x8, l_.str.176@PAGE
Lloh407:
	add	x8, x8, l_.str.176@PAGEOFF
	stp	x8, x27, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	str	x21, [sp, #8]
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
Lloh408:
	adrp	x8, l_.str.177@PAGE
Lloh409:
	add	x8, x8, l_.str.177@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	add	w20, w20, #1
	ldurh	w8, [x29, #-190]
	cmp	w20, w8
	b.lo	LBB3_57
LBB3_59:                                ;   in Loop: Header=BB3_43 Depth=3
	mov	x8, x26
	str	x8, [sp, #16]
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh410:
	adrp	x1, l_.str.162@PAGE
Lloh411:
	add	x1, x1, l_.str.162@PAGEOFF
	bl	_fn_text
	mov	w20, #0                         ; =0x0
Lloh412:
	adrp	x27, l_.str.105@PAGE
Lloh413:
	add	x27, x27, l_.str.105@PAGEOFF
Lloh414:
	adrp	x23, l_.str.163@PAGE
Lloh415:
	add	x23, x23, l_.str.163@PAGEOFF
	b	LBB3_62
LBB3_60:                                ;   in Loop: Header=BB3_62 Depth=4
	str	x20, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrb	w8, [sp, #904]
	str	x8, [sp, #8]
Lloh416:
	adrp	x8, l_.str.164@PAGE
Lloh417:
	add	x8, x8, l_.str.164@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #905]
	str	x8, [sp, #8]
Lloh418:
	adrp	x8, l_.str.165@PAGE
Lloh419:
	add	x8, x8, l_.str.165@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrh	w8, [sp, #906]
	str	x8, [sp, #8]
Lloh420:
	adrp	x8, l_.str.166@PAGE
Lloh421:
	add	x8, x8, l_.str.166@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	x9, [sp, #912]
Lloh422:
	adrp	x8, l_.str.167@PAGE
Lloh423:
	add	x8, x8, l_.str.167@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	x9, [sp, #920]
Lloh424:
	adrp	x8, l_.str.168@PAGE
Lloh425:
	add	x8, x8, l_.str.168@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	x9, [sp, #928]
Lloh426:
	adrp	x8, l_.str.169@PAGE
Lloh427:
	add	x8, x8, l_.str.169@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #936]
	str	x8, [sp, #8]
Lloh428:
	adrp	x8, l_.str.170@PAGE
Lloh429:
	add	x8, x8, l_.str.170@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	mov	x0, x19
Lloh430:
	adrp	x1, l_.str.171@PAGE
Lloh431:
	add	x1, x1, l_.str.171@PAGEOFF
	bl	_fn_text
LBB3_61:                                ;   in Loop: Header=BB3_62 Depth=4
	add	w20, w20, #1
	cmp	w20, #256
	b.eq	LBB3_74
LBB3_62:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ;       Parent Loop BB3_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x5, sp, #904
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	mov	x3, x26
	mov	x4, x20
	bl	_nvm_services_indirect_hosted_input_reference
	cbz	w0, LBB3_70
; %bb.63:                               ;   in Loop: Header=BB3_62 Depth=4
	ldrb	w8, [sp, #904]
	tbnz	w8, #0, LBB3_60
; %bb.64:                               ;   in Loop: Header=BB3_62 Depth=4
	ldrb	w8, [sp, #905]
	tbnz	w8, #0, LBB3_70
; %bb.65:                               ;   in Loop: Header=BB3_62 Depth=4
	ldrh	w8, [sp, #906]
	cbnz	w8, LBB3_70
; %bb.66:                               ;   in Loop: Header=BB3_62 Depth=4
	ldr	x8, [sp, #912]
	cbnz	x8, LBB3_70
; %bb.67:                               ;   in Loop: Header=BB3_62 Depth=4
	ldr	x8, [sp, #920]
	cbnz	x8, LBB3_70
; %bb.68:                               ;   in Loop: Header=BB3_62 Depth=4
	ldr	x8, [sp, #928]
	cbnz	x8, LBB3_70
; %bb.69:                               ;   in Loop: Header=BB3_62 Depth=4
	ldrb	w8, [sp, #936]
	tbz	w8, #0, LBB3_61
LBB3_70:                                ;   in Loop: Header=BB3_43 Depth=3
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
	b	LBB3_73
LBB3_71:                                ;   in Loop: Header=BB3_43 Depth=3
	str	w20, [x19, #24]
	b	LBB3_73
LBB3_72:                                ;   in Loop: Header=BB3_43 Depth=3
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
Lloh432:
	adrp	x27, l_.str.105@PAGE
Lloh433:
	add	x27, x27, l_.str.105@PAGEOFF
LBB3_73:                                ;   in Loop: Header=BB3_43 Depth=3
	mov	w20, #2                         ; =0x2
Lloh434:
	adrp	x23, l_.str.97@PAGE
Lloh435:
	add	x23, x23, l_.str.97@PAGEOFF
	b	LBB3_42
LBB3_74:                                ;   in Loop: Header=BB3_43 Depth=3
	mov	x0, x19
Lloh436:
	adrp	x1, l_.str.172@PAGE
Lloh437:
	add	x1, x1, l_.str.172@PAGEOFF
	bl	_fn_text
	ldurh	w8, [x29, #-188]
	cbz	w8, LBB3_73
; %bb.75:                               ;   in Loop: Header=BB3_43 Depth=3
	mov	w20, #0                         ; =0x0
	mov	x23, x26
LBB3_76:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_8 Depth=2
                                        ;       Parent Loop BB3_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x5, sp, #904
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	mov	x3, x26
	mov	x4, x20
	bl	_nvm_services_indirect_hosted_input_region
	tbz	w0, #0, LBB3_70
; %bb.77:                               ;   in Loop: Header=BB3_76 Depth=4
	ldr	x8, [sp, #904]
	stp	x20, x8, [sp, #24]
	ldp	x8, x9, [sp, #144]              ; 16-byte Folded Reload
	stp	x9, x23, [sp, #8]
	str	x8, [sp]
	mov	x0, x19
Lloh438:
	adrp	x1, l_.str.173@PAGE
Lloh439:
	add	x1, x1, l_.str.173@PAGEOFF
	bl	_fn_text
	add	w20, w20, #1
	ldurh	w8, [x29, #-188]
	cmp	w20, w8
	b.lo	LBB3_76
	b	LBB3_73
LBB3_78:                                ;   in Loop: Header=BB3_8 Depth=2
	ldrb	w8, [sp, #312]
	cmp	w8, #145
	ldp	x26, x24, [sp, #72]             ; 16-byte Folded Reload
	b.ne	LBB3_81
; %bb.79:                               ;   in Loop: Header=BB3_8 Depth=2
	ldr	w1, [sp, #896]
	add	x2, sp, #984
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_import
	cbz	w0, LBB3_6
; %bb.80:                               ;   in Loop: Header=BB3_8 Depth=2
	ldr	w8, [sp, #896]
	ldr	w9, [sp, #984]
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh440:
	adrp	x1, l_.str.63@PAGE
Lloh441:
	add	x1, x1, l_.str.63@PAGEOFF
	bl	_fn_text
LBB3_81:                                ;   in Loop: Header=BB3_8 Depth=2
	mov	x0, x19
Lloh442:
	adrp	x1, l_.str.88@PAGE
Lloh443:
	add	x1, x1, l_.str.88@PAGEOFF
	bl	_fn_text
	b	LBB3_7
LBB3_82:                                ;   in Loop: Header=BB3_8 Depth=2
	mov	w20, #2                         ; =0x2
	str	w20, [x19, #24]
Lloh444:
	adrp	x23, l_.str.97@PAGE
Lloh445:
	add	x23, x23, l_.str.97@PAGEOFF
	b	LBB3_7
LBB3_83:
Lloh446:
	adrp	x1, l_.str.37@PAGE
Lloh447:
	add	x1, x1, l_.str.37@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	ldr	x21, [sp, #64]                  ; 8-byte Folded Reload
	ldr	w8, [x21]
Lloh448:
	adrp	x9, l_.str.38@PAGE
Lloh449:
	add	x9, x9, l_.str.38@PAGEOFF
	stp	x9, x8, [sp]
Lloh450:
	adrp	x20, l_.str.178@PAGE
Lloh451:
	add	x20, x20, l_.str.178@PAGEOFF
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #4]
Lloh452:
	adrp	x9, l_.str.39@PAGE
Lloh453:
	add	x9, x9, l_.str.39@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #8]
Lloh454:
	adrp	x9, l_.str.40@PAGE
Lloh455:
	add	x9, x9, l_.str.40@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #12]
Lloh456:
	adrp	x9, l_.str.41@PAGE
Lloh457:
	add	x9, x9, l_.str.41@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #16]
Lloh458:
	adrp	x9, l_.str.42@PAGE
Lloh459:
	add	x9, x9, l_.str.42@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #24]
Lloh460:
	adrp	x9, l_.str.43@PAGE
Lloh461:
	add	x9, x9, l_.str.43@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #32]
Lloh462:
	adrp	x9, l_.str.44@PAGE
Lloh463:
	add	x9, x9, l_.str.44@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrh	w8, [x21, #40]
Lloh464:
	adrp	x9, l_.str.45@PAGE
Lloh465:
	add	x9, x9, l_.str.45@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #44]
Lloh466:
	adrp	x9, l_.str.46@PAGE
Lloh467:
	add	x9, x9, l_.str.46@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #48]
Lloh468:
	adrp	x9, l_.str.47@PAGE
Lloh469:
	add	x9, x9, l_.str.47@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #56]
Lloh470:
	adrp	x9, l_.str.48@PAGE
Lloh471:
	add	x9, x9, l_.str.48@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #64]
Lloh472:
	adrp	x9, l_.str.49@PAGE
Lloh473:
	add	x9, x9, l_.str.49@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #72]
Lloh474:
	adrp	x9, l_.str.50@PAGE
Lloh475:
	add	x9, x9, l_.str.50@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #80]
Lloh476:
	adrp	x9, l_.str.51@PAGE
Lloh477:
	add	x9, x9, l_.str.51@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrb	w8, [x21, #88]
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
Lloh478:
	adrp	x9, l_.str.52@PAGE
Lloh479:
	add	x9, x9, l_.str.52@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh480:
	adrp	x1, l_.str.53@PAGE
Lloh481:
	add	x1, x1, l_.str.53@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	mov	w22, #0                         ; =0x0
Lloh482:
	adrp	x26, l_.str.59@PAGE
Lloh483:
	add	x26, x26, l_.str.59@PAGEOFF
Lloh484:
	adrp	x23, l_.str.60@PAGE
Lloh485:
	add	x23, x23, l_.str.60@PAGEOFF
Lloh486:
	adrp	x27, l_.str.61@PAGE
Lloh487:
	add	x27, x27, l_.str.61@PAGEOFF
	mov	w28, #36409                     ; =0x8e39
	movk	w28, #14563, lsl #16
Lloh488:
	adrp	x24, l_.str.54@PAGE
Lloh489:
	add	x24, x24, l_.str.54@PAGEOFF
	b	LBB3_86
LBB3_84:                                ;   in Loop: Header=BB3_86 Depth=1
	mov	x8, x22
	str	x8, [sp]
	mov	x0, x19
Lloh490:
	adrp	x1, l_.str.55@PAGE
Lloh491:
	add	x1, x1, l_.str.55@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #984]
	str	x8, [sp, #8]
Lloh492:
	adrp	x8, l_.str.56@PAGE
Lloh493:
	add	x8, x8, l_.str.56@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [sp, #988]
	str	x8, [sp, #8]
Lloh494:
	adrp	x8, l_.str.57@PAGE
Lloh495:
	add	x8, x8, l_.str.57@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [sp, #992]
	str	x8, [sp, #8]
Lloh496:
	adrp	x8, l_.str.58@PAGE
Lloh497:
	add	x8, x8, l_.str.58@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrb	w8, [sp, #996]
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrb	w8, [sp, #997]
	stp	x23, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [sp, #1000]
	stp	x27, x8, [sp]
	mov	x0, x19
	mov	x1, x20
LBB3_85:                                ;   in Loop: Header=BB3_86 Depth=1
	bl	_fn_text
	add	w22, w22, #1
LBB3_86:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_87 Depth 2
	mov	w25, #0                         ; =0x0
LBB3_87:                                ;   Parent Loop BB3_86 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, sp, #984
	mov	x0, x21
	mov	x1, x25
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB3_89
; %bb.88:                               ;   in Loop: Header=BB3_87 Depth=2
	add	w25, w25, #9
	cmp	w25, #576
	b.ne	LBB3_87
LBB3_89:                                ;   in Loop: Header=BB3_86 Depth=1
	cmp	w22, w25
	b.hs	LBB3_93
; %bb.90:                               ;   in Loop: Header=BB3_86 Depth=1
	add	x2, sp, #984
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_services_indirect_hosted_type
	tbnz	w0, #0, LBB3_84
; %bb.91:                               ;   in Loop: Header=BB3_86 Depth=1
	umull	x8, w22, w28
	lsr	x8, x8, #33
	add	w8, w8, w8, lsl #3
	sub	w8, w22, w8
	cmp	w8, #7
	b.lo	LBB3_118
; %bb.92:                               ;   in Loop: Header=BB3_86 Depth=1
	str	x22, [sp]
	mov	x0, x19
	mov	x1, x24
	b	LBB3_85
LBB3_93:
	mov	w20, #0                         ; =0x0
Lloh498:
	adrp	x22, l_.str.63@PAGE
Lloh499:
	add	x22, x22, l_.str.63@PAGEOFF
	mov	w25, #52429                     ; =0xcccd
	movk	w25, #52428, lsl #16
Lloh500:
	adrp	x23, l_.str.62@PAGE
Lloh501:
	add	x23, x23, l_.str.62@PAGEOFF
	b	LBB3_96
LBB3_94:                                ;   in Loop: Header=BB3_96 Depth=1
	ldr	w8, [sp, #304]
	mov	x9, x20
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x22
LBB3_95:                                ;   in Loop: Header=BB3_96 Depth=1
	bl	_fn_text
	add	w20, w20, #1
LBB3_96:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_97 Depth 2
	mov	w24, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
LBB3_97:                                ;   Parent Loop BB3_96 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, sp, #984
	mov	x0, x21
	mov	x1, x24
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB3_99
; %bb.98:                               ;   in Loop: Header=BB3_97 Depth=2
	add	w26, w26, #1
	add	w24, w24, #9
	cmp	w26, #64
	b.ne	LBB3_97
LBB3_99:                                ;   in Loop: Header=BB3_96 Depth=1
	add	w8, w26, w26, lsl #2
	cmp	w20, w8
	b.hs	LBB3_105
; %bb.100:                              ;   in Loop: Header=BB3_96 Depth=1
	add	x2, sp, #304
	mov	x0, x21
	mov	x1, x20
	bl	_nvm_services_indirect_hosted_import
	tbnz	w0, #0, LBB3_94
; %bb.101:                              ;   in Loop: Header=BB3_96 Depth=1
	umull	x8, w20, w25
	lsr	x24, x8, #34
	add	w26, w24, w24, lsl #3
	add	w1, w26, #6
	add	x2, sp, #984
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_type
	tbz	w0, #0, LBB3_118
; %bb.102:                              ;   in Loop: Header=BB3_96 Depth=1
	add	w1, w26, #7
	add	x2, sp, #984
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_type
	tbnz	w0, #0, LBB3_118
; %bb.103:                              ;   in Loop: Header=BB3_96 Depth=1
	add	w8, w24, w24, lsl #2
	sub	w8, w20, w8
	cmp	w8, #4
	b.ne	LBB3_118
; %bb.104:                              ;   in Loop: Header=BB3_96 Depth=1
	str	x20, [sp]
	mov	x0, x19
	mov	x1, x23
	b	LBB3_95
LBB3_105:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cbz	w8, LBB3_117
; %bb.106:
	mov	w22, #0                         ; =0x0
Lloh502:
	adrp	x28, l_.str.64@PAGE
Lloh503:
	add	x28, x28, l_.str.64@PAGEOFF
Lloh504:
	adrp	x24, l_.str.65@PAGE
Lloh505:
	add	x24, x24, l_.str.65@PAGEOFF
Lloh506:
	adrp	x23, l_.str.178@PAGE
Lloh507:
	add	x23, x23, l_.str.178@PAGEOFF
Lloh508:
	adrp	x26, l_.str.66@PAGE
Lloh509:
	add	x26, x26, l_.str.66@PAGEOFF
Lloh510:
	adrp	x20, l_.str.67@PAGE
Lloh511:
	add	x20, x20, l_.str.67@PAGEOFF
Lloh512:
	adrp	x25, l_.str.68@PAGE
Lloh513:
	add	x25, x25, l_.str.68@PAGEOFF
LBB3_107:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_111 Depth 2
                                        ;     Child Loop BB3_115 Depth 2
	add	x2, sp, #984
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB3_118
; %bb.108:                              ;   in Loop: Header=BB3_107 Depth=1
	sub	x2, x29, #192
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_services_indirect_hosted_function_order
	tbz	w0, #0, LBB3_118
; %bb.109:                              ;   in Loop: Header=BB3_107 Depth=1
	mov	x8, x22
	ldur	w9, [x29, #-192]
	stp	x9, x8, [sp, #8]
	str	x8, [sp]
	mov	x0, x19
	mov	x27, x28
	mov	x1, x28
	bl	_fn_text
	ldr	w8, [sp, #984]
	stp	x24, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #988]
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #992]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #996]
	stp	x25, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #998]
	str	x8, [sp, #8]
Lloh514:
	adrp	x8, l_.str.69@PAGE
Lloh515:
	add	x8, x8, l_.str.69@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrb	w8, [sp, #1000]
	str	x8, [sp, #8]
Lloh516:
	adrp	x8, l_.str.70@PAGE
Lloh517:
	add	x8, x8, l_.str.70@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	add	x8, sp, #984
	ldur	x2, [x8, #20]
	ldur	x3, [x8, #28]
	mov	x0, x19
Lloh518:
	adrp	x1, l_.str.71@PAGE
Lloh519:
	add	x1, x1, l_.str.71@PAGEOFF
	bl	_fn_declaration
	ldrh	w8, [sp, #1020]
	str	x8, [sp, #8]
Lloh520:
	adrp	x8, l_.str.72@PAGE
Lloh521:
	add	x8, x8, l_.str.72@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1022]
	str	x8, [sp, #8]
Lloh522:
	adrp	x8, l_.str.73@PAGE
Lloh523:
	add	x8, x8, l_.str.73@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1024]
	str	x8, [sp, #8]
Lloh524:
	adrp	x8, l_.str.74@PAGE
Lloh525:
	add	x8, x8, l_.str.74@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1026]
	str	x8, [sp, #8]
Lloh526:
	adrp	x8, l_.str.75@PAGE
Lloh527:
	add	x8, x8, l_.str.75@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1028]
	str	x8, [sp, #8]
Lloh528:
	adrp	x8, l_.str.76@PAGE
Lloh529:
	add	x8, x8, l_.str.76@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1030]
	str	x8, [sp, #8]
Lloh530:
	adrp	x8, l_.str.77@PAGE
Lloh531:
	add	x8, x8, l_.str.77@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1032]
	str	x8, [sp, #8]
Lloh532:
	adrp	x8, l_.str.78@PAGE
Lloh533:
	add	x8, x8, l_.str.78@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1034]
	str	x8, [sp, #8]
Lloh534:
	adrp	x8, l_.str.79@PAGE
Lloh535:
	add	x8, x8, l_.str.79@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #1036]
	str	x8, [sp, #8]
Lloh536:
	adrp	x8, l_.str.80@PAGE
Lloh537:
	add	x8, x8, l_.str.80@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #1040]
	str	x8, [sp, #8]
Lloh538:
	adrp	x8, l_.str.81@PAGE
Lloh539:
	add	x8, x8, l_.str.81@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	x9, [sp, #1048]
Lloh540:
	adrp	x8, l_.str.82@PAGE
Lloh541:
	add	x8, x8, l_.str.82@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	x9, [sp, #1056]
Lloh542:
	adrp	x8, l_.str.83@PAGE
Lloh543:
	add	x8, x8, l_.str.83@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrb	w8, [sp, #1064]
	str	x8, [sp, #8]
Lloh544:
	adrp	x8, l_.str.84@PAGE
Lloh545:
	add	x8, x8, l_.str.84@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #1024]
Lloh546:
	adrp	x20, l_.str.85@PAGE
Lloh547:
	add	x20, x20, l_.str.85@PAGEOFF
Lloh548:
	adrp	x25, l_.str.86@PAGE
Lloh549:
	add	x25, x25, l_.str.86@PAGEOFF
	cbz	w8, LBB3_113
; %bb.110:                              ;   in Loop: Header=BB3_107 Depth=1
	mov	w28, #0                         ; =0x0
LBB3_111:                               ;   Parent Loop BB3_107 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, sp, #304
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	bl	_nvm_services_indirect_hosted_local
	tbz	w0, #0, LBB3_118
; %bb.112:                              ;   in Loop: Header=BB3_111 Depth=2
	stp	x22, x28, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldp	x2, x3, [sp, #304]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_declaration
	add	w28, w28, #1
	ldrh	w8, [sp, #1024]
	cmp	w28, w8
	b.lo	LBB3_111
LBB3_113:                               ;   in Loop: Header=BB3_107 Depth=1
	mov	x25, x26
	mov	x26, x24
	mov	x24, x27
	ldrh	w8, [sp, #992]
Lloh550:
	adrp	x27, l_.str.87@PAGE
Lloh551:
	add	x27, x27, l_.str.87@PAGEOFF
	cbz	w8, LBB3_116
; %bb.114:                              ;   in Loop: Header=BB3_107 Depth=1
	mov	w28, #0                         ; =0x0
	mov	x20, x22
LBB3_115:                               ;   Parent Loop BB3_107 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	stp	x20, x28, [sp]
	mov	x0, x19
	mov	x1, x27
	bl	_fn_text
	add	w28, w28, #1
	ldrh	w8, [sp, #992]
	cmp	w28, w8
	b.lo	LBB3_115
LBB3_116:                               ;   in Loop: Header=BB3_107 Depth=1
	add	w22, w22, #1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cmp	w22, w8
	mov	x28, x24
	mov	x24, x26
	mov	x26, x25
Lloh552:
	adrp	x20, l_.str.67@PAGE
Lloh553:
	add	x20, x20, l_.str.67@PAGEOFF
Lloh554:
	adrp	x25, l_.str.68@PAGE
Lloh555:
	add	x25, x25, l_.str.68@PAGEOFF
	b.lo	LBB3_107
LBB3_117:
Lloh556:
	adrp	x1, l_.str.88@PAGE
Lloh557:
	add	x1, x1, l_.str.88@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	b	LBB3_119
LBB3_118:
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
LBB3_119:
	add	sp, sp, #1696
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdd	Lloh266, Lloh267
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh324, Lloh325
	.loh AdrpAdd	Lloh322, Lloh323
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh316, Lloh317
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh302, Lloh303
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdd	Lloh284, Lloh285
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh350, Lloh351
	.loh AdrpAdd	Lloh348, Lloh349
	.loh AdrpAdd	Lloh346, Lloh347
	.loh AdrpAdd	Lloh344, Lloh345
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpAdd	Lloh336, Lloh337
	.loh AdrpAdd	Lloh334, Lloh335
	.loh AdrpAdd	Lloh332, Lloh333
	.loh AdrpAdd	Lloh330, Lloh331
	.loh AdrpAdd	Lloh328, Lloh329
	.loh AdrpAdd	Lloh326, Lloh327
	.loh AdrpAdd	Lloh388, Lloh389
	.loh AdrpAdd	Lloh386, Lloh387
	.loh AdrpAdd	Lloh384, Lloh385
	.loh AdrpAdd	Lloh382, Lloh383
	.loh AdrpAdd	Lloh380, Lloh381
	.loh AdrpAdd	Lloh378, Lloh379
	.loh AdrpAdd	Lloh376, Lloh377
	.loh AdrpAdd	Lloh374, Lloh375
	.loh AdrpAdd	Lloh372, Lloh373
	.loh AdrpAdd	Lloh370, Lloh371
	.loh AdrpAdd	Lloh368, Lloh369
	.loh AdrpAdd	Lloh366, Lloh367
	.loh AdrpAdd	Lloh364, Lloh365
	.loh AdrpAdd	Lloh362, Lloh363
	.loh AdrpAdd	Lloh360, Lloh361
	.loh AdrpAdd	Lloh358, Lloh359
	.loh AdrpAdd	Lloh356, Lloh357
	.loh AdrpAdd	Lloh354, Lloh355
	.loh AdrpAdd	Lloh352, Lloh353
	.loh AdrpAdd	Lloh398, Lloh399
	.loh AdrpAdd	Lloh396, Lloh397
	.loh AdrpAdd	Lloh394, Lloh395
	.loh AdrpAdd	Lloh392, Lloh393
	.loh AdrpAdd	Lloh390, Lloh391
	.loh AdrpAdd	Lloh408, Lloh409
	.loh AdrpAdd	Lloh406, Lloh407
	.loh AdrpAdd	Lloh404, Lloh405
	.loh AdrpAdd	Lloh402, Lloh403
	.loh AdrpAdd	Lloh400, Lloh401
	.loh AdrpAdd	Lloh414, Lloh415
	.loh AdrpAdd	Lloh412, Lloh413
	.loh AdrpAdd	Lloh410, Lloh411
	.loh AdrpAdd	Lloh430, Lloh431
	.loh AdrpAdd	Lloh428, Lloh429
	.loh AdrpAdd	Lloh426, Lloh427
	.loh AdrpAdd	Lloh424, Lloh425
	.loh AdrpAdd	Lloh422, Lloh423
	.loh AdrpAdd	Lloh420, Lloh421
	.loh AdrpAdd	Lloh418, Lloh419
	.loh AdrpAdd	Lloh416, Lloh417
	.loh AdrpAdd	Lloh432, Lloh433
	.loh AdrpAdd	Lloh434, Lloh435
	.loh AdrpAdd	Lloh436, Lloh437
	.loh AdrpAdd	Lloh438, Lloh439
	.loh AdrpAdd	Lloh440, Lloh441
	.loh AdrpAdd	Lloh442, Lloh443
	.loh AdrpAdd	Lloh444, Lloh445
	.loh AdrpAdd	Lloh488, Lloh489
	.loh AdrpAdd	Lloh486, Lloh487
	.loh AdrpAdd	Lloh484, Lloh485
	.loh AdrpAdd	Lloh482, Lloh483
	.loh AdrpAdd	Lloh480, Lloh481
	.loh AdrpAdd	Lloh478, Lloh479
	.loh AdrpAdd	Lloh476, Lloh477
	.loh AdrpAdd	Lloh474, Lloh475
	.loh AdrpAdd	Lloh472, Lloh473
	.loh AdrpAdd	Lloh470, Lloh471
	.loh AdrpAdd	Lloh468, Lloh469
	.loh AdrpAdd	Lloh466, Lloh467
	.loh AdrpAdd	Lloh464, Lloh465
	.loh AdrpAdd	Lloh462, Lloh463
	.loh AdrpAdd	Lloh460, Lloh461
	.loh AdrpAdd	Lloh458, Lloh459
	.loh AdrpAdd	Lloh456, Lloh457
	.loh AdrpAdd	Lloh454, Lloh455
	.loh AdrpAdd	Lloh452, Lloh453
	.loh AdrpAdd	Lloh450, Lloh451
	.loh AdrpAdd	Lloh448, Lloh449
	.loh AdrpAdd	Lloh446, Lloh447
	.loh AdrpAdd	Lloh496, Lloh497
	.loh AdrpAdd	Lloh494, Lloh495
	.loh AdrpAdd	Lloh492, Lloh493
	.loh AdrpAdd	Lloh490, Lloh491
	.loh AdrpAdd	Lloh500, Lloh501
	.loh AdrpAdd	Lloh498, Lloh499
	.loh AdrpAdd	Lloh512, Lloh513
	.loh AdrpAdd	Lloh510, Lloh511
	.loh AdrpAdd	Lloh508, Lloh509
	.loh AdrpAdd	Lloh506, Lloh507
	.loh AdrpAdd	Lloh504, Lloh505
	.loh AdrpAdd	Lloh502, Lloh503
	.loh AdrpAdd	Lloh548, Lloh549
	.loh AdrpAdd	Lloh546, Lloh547
	.loh AdrpAdd	Lloh544, Lloh545
	.loh AdrpAdd	Lloh542, Lloh543
	.loh AdrpAdd	Lloh540, Lloh541
	.loh AdrpAdd	Lloh538, Lloh539
	.loh AdrpAdd	Lloh536, Lloh537
	.loh AdrpAdd	Lloh534, Lloh535
	.loh AdrpAdd	Lloh532, Lloh533
	.loh AdrpAdd	Lloh530, Lloh531
	.loh AdrpAdd	Lloh528, Lloh529
	.loh AdrpAdd	Lloh526, Lloh527
	.loh AdrpAdd	Lloh524, Lloh525
	.loh AdrpAdd	Lloh522, Lloh523
	.loh AdrpAdd	Lloh520, Lloh521
	.loh AdrpAdd	Lloh518, Lloh519
	.loh AdrpAdd	Lloh516, Lloh517
	.loh AdrpAdd	Lloh514, Lloh515
	.loh AdrpAdd	Lloh550, Lloh551
	.loh AdrpAdd	Lloh554, Lloh555
	.loh AdrpAdd	Lloh552, Lloh553
	.loh AdrpAdd	Lloh556, Lloh557
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fcd_supported
_fcd_supported:                         ; @fcd_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB4_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh558:
	adrp	x9, lJTI4_0@PAGE
Lloh559:
	add	x9, x9, lJTI4_0@PAGEOFF
	adr	x10, LBB4_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB4_2:
	ret
LBB4_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh558, Lloh559
	.cfi_endproc
	.section	__TEXT,__const
lJTI4_0:
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function services_dispatch_websocket
_services_dispatch_websocket:           ; @services_dispatch_websocket
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w1, w8
	lsr	x8, x8, #34
	add	w20, w8, w8, lsl #3
	add	w1, w20, #6
	add	x2, sp, #12
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB5_2
; %bb.1:
	add	w1, w20, #7
	add	x2, sp, #12
	mov	x0, x19
	bl	_nvm_services_indirect_hosted_type
	eor	w0, w0, #0x1
LBB5_2:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_declaration
_fn_declaration:                        ; @fn_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x3
	mov	x24, x2
	mov	x20, x1
	mov	x19, x0
Lloh560:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh561:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh562:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	lsr	x27, x2, #32
	lsr	x25, x3, #32
Lloh563:
	adrp	x8, l_.str.180@PAGE
Lloh564:
	add	x8, x8, l_.str.180@PAGEOFF
	stp	x1, x8, [sp]
Lloh565:
	adrp	x21, l_.str.179@PAGE
Lloh566:
	add	x21, x21, l_.str.179@PAGEOFF
	add	x26, sp, #24
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	and	x8, x24, #0xff
	stp	x26, x8, [sp]
Lloh567:
	adrp	x23, l_.str.178@PAGE
Lloh568:
	add	x23, x23, l_.str.178@PAGEOFF
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh569:
	adrp	x8, l_.str.181@PAGE
Lloh570:
	add	x8, x8, l_.str.181@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	ubfx	x8, x24, #8, #8
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh571:
	adrp	x8, l_.str.182@PAGE
Lloh572:
	add	x8, x8, l_.str.182@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	stp	x26, x27, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh573:
	adrp	x8, l_.str.183@PAGE
Lloh574:
	add	x8, x8, l_.str.183@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	mov	w8, w22
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh575:
	adrp	x8, l_.str.184@PAGE
Lloh576:
	add	x8, x8, l_.str.184@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	stp	x26, x25, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldur	x8, [x29, #-88]
Lloh577:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh578:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh579:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB6_2
; %bb.1:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB6_2:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh577, Lloh578, Lloh579
	.loh AdrpAdd	Lloh575, Lloh576
	.loh AdrpAdd	Lloh573, Lloh574
	.loh AdrpAdd	Lloh571, Lloh572
	.loh AdrpAdd	Lloh569, Lloh570
	.loh AdrpAdd	Lloh567, Lloh568
	.loh AdrpAdd	Lloh565, Lloh566
	.loh AdrpAdd	Lloh563, Lloh564
	.loh AdrpLdrGotLdr	Lloh560, Lloh561, Lloh562
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require exact mixed-service bytes and a valid entry identifier"

l_.str.1:                               ; @.str.1
	.asciz	"I refuse %sindirect mixed services preparation (%u)"

l_.str.3:                               ; @.str.3
	.space	1

l_.str.4:                               ; @.str.4
	.asciz	"I lack complete %sindirect mixed services instruction coverage"

l_.str.5:                               ; @.str.5
	.asciz	"static const uint8_t nf_module[]={\n"

l_.str.6:                               ; @.str.6
	.asciz	"%u,%s"

l_.str.7:                               ; @.str.7
	.asciz	"\n"

l_.str.8:                               ; @.str.8
	.asciz	"\n};\n"

l_.str.9:                               ; @.str.9
	.asciz	"static NvmServicesRuntimeStatus nf_function_%u(NvmServicesRuntime *);\n"

l_.str.10:                              ; @.str.10
	.asciz	"static NvmServicesIndirectExecutionReport nf_execute(const NvmServicesIndirectOptions *options,NvmServicesRuntimeView *out%s){\n"

l_.str.11:                              ; @.str.11
	.asciz	", NvmServicesHostGrant *grant"

l_.str.13:                              ; @.str.13
	.asciz	"if(!out || !options || options->revision!=NVM_SERVICES_INDIRECT_RUNTIME_REVISION || options->instruction_limit>NVM_SERVICES_INDIRECT_FUEL_MAX)return nf_refused(NVM_SERVICES_RUNTIME_INVALID,options);\nif(!nvm_services_runtime_indirect_native_abi(1u,sizeof(NvmServicesIndirectOptions),sizeof(NvmServicesIndirectExecutionReport),sizeof(NvmServicesIndirectFrameView),sizeof(NvmServicesRuntimeFrameView),sizeof(NvmServicesRuntimeView)))return nf_refused(NVM_SERVICES_RUNTIME_UNRESOLVED,options);\nNvmServicesRuntime *c=NULL;uint32_t root;\nNvmServicesRuntimeStatus status=nvm_services_runtime_indirect_create(nf_module,sizeof nf_module,NVM_SERVICES_RUNTIME_NATIVE,options,&c);\nif(status!=NVM_SERVICES_RUNTIME_OK)return nf_refused(status,options);\nif(!nf_agrees(nvm_services_runtime_indirect_plan(c))){(void)nvm_services_runtime_indirect_destroy(&c,NULL);return nf_refused(NVM_SERVICES_RUNTIME_UNRESOLVED,options);}\n"

l_.str.14:                              ; @.str.14
	.asciz	"%s"

l_.str.15:                              ; @.str.15
	.asciz	"status=nvm_services_public_configure(c,grant);\nif(status!=NVM_SERVICES_RUNTIME_OK){(void)nvm_services_runtime_indirect_destroy(&c,NULL);return nf_refused(status,options); }\n"

l_.str.16:                              ; @.str.16
	.asciz	"status=nvm_services_runtime_begin(c);\n(void)nf_bits;(void)nf_scalar;\n"

l_.str.17:                              ; @.str.17
	.asciz	"(void)nf_function_%u;\n"

l_.str.18:                              ; @.str.18
	.asciz	"if(status==NVM_SERVICES_RUNTIME_OK)status=nvm_services_runtime_frame_start(c);\nif(status==NVM_SERVICES_RUNTIME_OK)status=nf_function_%u(c);\n"

l_.str.19:                              ; @.str.19
	.asciz	"if(status==NVM_SERVICES_RUNTIME_OK && (!nvm_services_runtime_current_root(c,&root) || root!=%u))status=nf_bad(c);\nif(status==NVM_SERVICES_RUNTIME_OK)status=nvm_services_runtime_frame_start(c);\nif(status==NVM_SERVICES_RUNTIME_OK)status=nf_function_%u(c);\nif(status==NVM_SERVICES_RUNTIME_OK && nvm_services_runtime_current_root(c,&root))status=nf_bad(c);\nif(status!=NVM_SERVICES_RUNTIME_OK)(void)nvm_services_runtime_fail(c,status);\nreturn nvm_services_runtime_indirect_destroy(&c,out);\n}\n#undef NF_TRY\n"

l_.str.20:                              ; @.str.20
	.asciz	"NvmServicesIndirectExecutionReport nvm_services_indirect_program_%s(NvmServicesHostGrant *grant,const NvmServicesIndirectOptions *options,NvmServicesScalar *out){\nNvmServicesHostStatus entered=nvm_services_host_enter(grant,NVM_SERVICES_HOST_ABI,NVM_SERVICES_HOST_CATALOG);\nif(entered!=NVM_SERVICES_HOST_OK)return nvm_services_indirect_public_refused(nvm_services_public_grant_status(entered),entered==NVM_SERVICES_HOST_BUSY?NULL:options);\nNvmServicesIndirectExecutionReport report;\nif(!nvm_services_indirect_public_options(options) || !out)report=nvm_services_indirect_public_refused(NVM_SERVICES_RUNTIME_INVALID,options);\nelse {NvmServicesIndirectOptions copied=*options;NvmServicesRuntimeView view={0};\nif(!nvm_services_runtime_indirect_public_abi(1u,sizeof copied,sizeof report,sizeof *out))report=nvm_services_indirect_public_refused(NVM_SERVICES_RUNTIME_UNRESOLVED,&copied);\nelse {report=nf_execute(&copied,&view%s);report.runtime=nvm_services_public_publish(report.runtime,&view,out);}}\nnvm_services_host_leave();return report;}\n"

l_.str.21:                              ; @.str.21
	.asciz	",grant"

l_.str.22:                              ; @.str.22
	.asciz	"I refuse %sindirect mixed services emission (%u)"

l_.str.23:                              ; @.str.23
	.asciz	"#include <nanolang/services/nanoisa/services_indirect_native_public.h>\n#include <limits.h>\n#include <string.h>\n"

l_.str.24:                              ; @.str.24
	.asciz	"#if NVM_SERVICES_INDIRECT_PUBLIC_ABI != 1u || NVM_SERVICES_INDIRECT_NATIVE_ABI != 1u\n#error I require indirect public and native ABI revision 1\n#endif\n"

l_.str.27:                              ; @.str.27
	.asciz	"#define NF_TRY(expr) do { NvmServicesRuntimeStatus nf_status_=(expr); if(nf_status_!=NVM_SERVICES_RUNTIME_OK)return nf_status_; } while(0)\n"

l_.str.28:                              ; @.str.28
	.asciz	"static NvmServicesRuntimeStatus nf_bad(NvmServicesRuntime *c){return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_STATE);}\n"

l_.str.29:                              ; @.str.29
	.asciz	"static int64_t nf_bits(uint64_t x){int64_t y;memcpy(&y,&x,sizeof y);return y;}\n"

l_.str.30:                              ; @.str.30
	.asciz	"static bool nf_scalar(const NvmServicesRuntimeView *v,uint8_t tag){\n"

l_.str.31:                              ; @.str.31
	.asciz	" return v->initialized && !v->owning && !v->formal && !v->type.mode &&\n"

l_.str.32:                              ; @.str.32
	.asciz	" v->type.category==NVM_SERVICES_CATEGORY_UNKNOWN && v->type.tag==tag &&\n"

l_.str.33:                              ; @.str.33
	.asciz	" v->type.global_index==NVM_V2_NO_INDEX && v->type.catalog_ordinal==NVM_V2_NO_INDEX &&\n"

l_.str.34:                              ; @.str.34
	.asciz	" v->fields==(tag==TAG_VOID?0:1) && (tag!=TAG_BOOL || v->values[0]==0 || v->values[0]==1);\n"

l_.str.35:                              ; @.str.35
	.asciz	"}\n"

l_.str.36:                              ; @.str.36
	.asciz	"static NvmServicesIndirectExecutionReport nf_refused(NvmServicesRuntimeStatus status,const NvmServicesIndirectOptions *options){\nNvmServicesIndirectExecutionReport r={0};r.revision=1u;r.instruction_limit=options?options->instruction_limit:0;\nr.runtime.status=status;r.runtime.function=r.runtime.instruction=NVM_V2_NO_INDEX;return r;}\n"

l_.str.37:                              ; @.str.37
	.asciz	"static bool nf_agrees(const NvmServicesIndirectHostedPlan *p){\nNvmServicesIndirectHostedStartup s;NvmServicesIndirectHostedFunction f;NvmServicesFlowDeclaration l;\nNvmServicesNominalLayout t;uint32_t ordinal;uint8_t byte;\n(void)l;\nif(!nvm_services_indirect_hosted_startup(p,&s))return false;\n"

l_.str.38:                              ; @.str.38
	.asciz	"s.revision"

l_.str.39:                              ; @.str.39
	.asciz	"s.entry"

l_.str.40:                              ; @.str.40
	.asciz	"s.initializer"

l_.str.41:                              ; @.str.41
	.asciz	"s.functions"

l_.str.42:                              ; @.str.42
	.asciz	"s.features"

l_.str.43:                              ; @.str.43
	.asciz	"s.vm_value_slots"

l_.str.44:                              ; @.str.44
	.asciz	"s.native_value_slots"

l_.str.45:                              ; @.str.45
	.asciz	"s.frames"

l_.str.46:                              ; @.str.46
	.asciz	"s.reference_slots"

l_.str.47:                              ; @.str.47
	.asciz	"s.region_slots"

l_.str.48:                              ; @.str.48
	.asciz	"s.input_bytes"

l_.str.49:                              ; @.str.49
	.asciz	"s.allocation_bound"

l_.str.50:                              ; @.str.50
	.asciz	"s.query_storage_peak"

l_.str.51:                              ; @.str.51
	.asciz	"s.retained_bound"

l_.str.52:                              ; @.str.52
	.asciz	"s.runtime_admitted"

l_.str.53:                              ; @.str.53
	.asciz	"if(s.input_bytes!=sizeof nf_module)return false;\nfor(size_t n=0;n<sizeof nf_module;n++)if(!nvm_services_indirect_hosted_bytes(p,n,&byte,1) || byte!=nf_module[n])return false;\n"

l_.str.54:                              ; @.str.54
	.asciz	"if(nvm_services_indirect_hosted_type(p,%u,&t))return false;\n"

l_.str.55:                              ; @.str.55
	.asciz	"if(!nvm_services_indirect_hosted_type(p,%u,&t))return false;\n"

l_.str.56:                              ; @.str.56
	.asciz	"t.global_index"

l_.str.57:                              ; @.str.57
	.asciz	"t.catalog_ordinal"

l_.str.58:                              ; @.str.58
	.asciz	"t.source_ordinal"

l_.str.59:                              ; @.str.59
	.asciz	"t.layout_kind"

l_.str.60:                              ; @.str.60
	.asciz	"t.ownership_flags"

l_.str.61:                              ; @.str.61
	.asciz	"t.category"

l_.str.62:                              ; @.str.62
	.asciz	"if(nvm_services_indirect_hosted_import(p,%u,&ordinal))return false;\n"

l_.str.63:                              ; @.str.63
	.asciz	"if(!nvm_services_indirect_hosted_import(p,%u,&ordinal) || ordinal!=%u)return false;\n"

l_.str.64:                              ; @.str.64
	.asciz	"if(!nvm_services_indirect_hosted_function_order(p,%u,&ordinal) || ordinal!=%u || !nvm_services_indirect_hosted_function(p,%u,&f))return false;\n"

l_.str.65:                              ; @.str.65
	.asciz	"f.code.code_offset"

l_.str.66:                              ; @.str.66
	.asciz	"f.code.code_length"

l_.str.67:                              ; @.str.67
	.asciz	"f.code.instruction_count"

l_.str.68:                              ; @.str.68
	.asciz	"f.code.declaration.parameters"

l_.str.69:                              ; @.str.69
	.asciz	"f.code.declaration.locals"

l_.str.70:                              ; @.str.70
	.asciz	"f.code.declaration.result_count"

l_.str.71:                              ; @.str.71
	.asciz	"f.code.declaration.result."

l_.str.72:                              ; @.str.72
	.asciz	"f.declared_stack"

l_.str.73:                              ; @.str.73
	.asciz	"f.operand_peak"

l_.str.74:                              ; @.str.74
	.asciz	"f.locals"

l_.str.75:                              ; @.str.75
	.asciz	"f.staging_slots"

l_.str.76:                              ; @.str.76
	.asciz	"f.frames"

l_.str.77:                              ; @.str.77
	.asciz	"f.frame_owner_peak"

l_.str.78:                              ; @.str.78
	.asciz	"f.frame_reference_peak"

l_.str.79:                              ; @.str.79
	.asciz	"f.frame_region_peak"

l_.str.80:                              ; @.str.80
	.asciz	"f.reference_slots"

l_.str.81:                              ; @.str.81
	.asciz	"f.region_slots"

l_.str.82:                              ; @.str.82
	.asciz	"f.vm_value_slots"

l_.str.83:                              ; @.str.83
	.asciz	"f.native_value_slots"

l_.str.84:                              ; @.str.84
	.asciz	"f.entry_variant"

l_.str.85:                              ; @.str.85
	.asciz	"if(!nvm_services_indirect_hosted_local(p,%u,%u,&l))return false;\n"

l_.str.86:                              ; @.str.86
	.asciz	"l."

l_.str.87:                              ; @.str.87
	.asciz	"if(!nf_agrees_%u_%u(p))return false;\n"

l_.str.88:                              ; @.str.88
	.asciz	"return true;}\n"

l_.str.89:                              ; @.str.89
	.asciz	"static bool nf_agrees_%u_%u(const NvmServicesIndirectHostedPlan *p){\nNvmServicesCodeInstruction in;NvmServicesCyclicVariant variant;\nNvmServicesFlowValue value;NvmServicesFlowReference reference;\nuint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;\n(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;\n"

l_.str.90:                              ; @.str.90
	.asciz	"if(!nvm_services_indirect_hosted_instruction(p,%u,%u,&in) || !nvm_services_indirect_hosted_variant_count(p,%u,%u,&count) || count!=%u || !nvm_services_indirect_hosted_component(p,%u,%u,&component) || component!=%u)return false;\n"

l_.str.91:                              ; @.str.91
	.asciz	"in.byte_offset"

l_.str.92:                              ; @.str.92
	.asciz	"in.decoded.opcode"

l_.str.93:                              ; @.str.93
	.asciz	"in.decoded.operand_count"

l_.str.94:                              ; @.str.94
	.asciz	"in.decoded.byte_length"

l_.str.95:                              ; @.str.95
	.asciz	"in.successor_count"

l_.str.96:                              ; @.str.96
	.asciz	"in.catalog_ordinal"

l_.str.97:                              ; @.str.97
	.asciz	"if(in.successors[%u]!=%u)return false;\n"

l_.str.98:                              ; @.str.98
	.asciz	"u8"

l_.str.99:                              ; @.str.99
	.asciz	"u16"

l_.str.100:                             ; @.str.100
	.asciz	"u32"

l_.str.101:                             ; @.str.101
	.asciz	"i32"

l_.str.102:                             ; @.str.102
	.asciz	"i64"

l_.str.103:                             ; @.str.103
	.asciz	"if(in.decoded.operand_types[%u]!=%u || (uint64_t)in.decoded.operands[%u].%s!=UINT64_C(%llu))return false;\n"

l_.str.104:                             ; @.str.104
	.asciz	"if(in.call_references[%u]!=%u)return false;\n"

l_.str.105:                             ; @.str.105
	.asciz	"if(!nvm_services_indirect_hosted_variant(p,%u,%u,%u,&variant))return false;\n"

l_.str.106:                             ; @.str.106
	.asciz	"variant.input.locals"

l_.str.107:                             ; @.str.107
	.asciz	"variant.input.stack"

l_.str.108:                             ; @.str.108
	.asciz	"variant.input.regions"

l_.str.109:                             ; @.str.109
	.asciz	"variant.input.owners"

l_.str.110:                             ; @.str.110
	.asciz	"variant.input.references"

l_.str.111:                             ; @.str.111
	.asciz	"variant.output.locals"

l_.str.112:                             ; @.str.112
	.asciz	"variant.output.stack"

l_.str.113:                             ; @.str.113
	.asciz	"variant.output.regions"

l_.str.114:                             ; @.str.114
	.asciz	"variant.output.owners"

l_.str.115:                             ; @.str.115
	.asciz	"variant.output.references"

l_.str.116:                             ; @.str.116
	.asciz	"variant.edge_mask"

l_.str.117:                             ; @.str.117
	.asciz	"variant.edge_variants[0]"

l_.str.118:                             ; @.str.118
	.asciz	"variant.edge_variants[1]"

l_.str.119:                             ; @.str.119
	.asciz	"variant.body.reachable"

l_.str.120:                             ; @.str.120
	.asciz	"variant.body.exit_checked"

l_.str.121:                             ; @.str.121
	.asciz	"variant.body.refinement"

l_.str.122:                             ; @.str.122
	.asciz	"variant.body.has_obligation"

l_.str.123:                             ; @.str.123
	.asciz	"variant.body.input_stack"

l_.str.124:                             ; @.str.124
	.asciz	"variant.body.output_stack"

l_.str.125:                             ; @.str.125
	.asciz	"variant.body.cleanup_local"

l_.str.126:                             ; @.str.126
	.asciz	"variant.body.cleanup"

l_.str.127:                             ; @.str.127
	.asciz	"variant.body.discharged_checks"

l_.str.128:                             ; @.str.128
	.asciz	"variant.body.pending_checks"

l_.str.129:                             ; @.str.129
	.asciz	"variant.body.obligation.kind"

l_.str.130:                             ; @.str.130
	.asciz	"variant.body.obligation.site"

l_.str.131:                             ; @.str.131
	.asciz	"variant.body.obligation.target"

l_.str.132:                             ; @.str.132
	.asciz	"variant.body.obligation.checks"

l_.str.133:                             ; @.str.133
	.asciz	"variant.body.obligation.required_rights"

l_.str.134:                             ; @.str.134
	.asciz	"variant.body.obligation.acquired_rights"

l_.str.135:                             ; @.str.135
	.asciz	"variant.body.obligation.parameters"

l_.str.136:                             ; @.str.136
	.asciz	"variant.body.obligation.owned_inputs"

l_.str.137:                             ; @.str.137
	.asciz	"variant.body.obligation.borrowed_inputs"

l_.str.138:                             ; @.str.138
	.asciz	"variant.body.obligation.result_count"

l_.str.139:                             ; @.str.139
	.asciz	"variant.body.obligation.outcomes[0]"

l_.str.140:                             ; @.str.140
	.asciz	"variant.body.obligation.outcomes[1]"

l_.str.141:                             ; @.str.141
	.asciz	"variant.body.obligation.result."

l_.str.142:                             ; @.str.142
	.asciz	"{NvmServicesIndirectFlowCall call;if(!nvm_services_indirect_hosted_call(p,%u,%u,%u,&call))return false;\n"

l_.str.143:                             ; @.str.143
	.asciz	"call.function"

l_.str.144:                             ; @.str.144
	.asciz	"call.pc"

l_.str.145:                             ; @.str.145
	.asciz	"call.candidates"

l_.str.146:                             ; @.str.146
	.asciz	"call.checked_candidates"

l_.str.147:                             ; @.str.147
	.asciz	"call.common.kind"

l_.str.148:                             ; @.str.148
	.asciz	"call.common.site"

l_.str.149:                             ; @.str.149
	.asciz	"call.common.target"

l_.str.150:                             ; @.str.150
	.asciz	"call.common.checks"

l_.str.151:                             ; @.str.151
	.asciz	"call.common.required_rights"

l_.str.152:                             ; @.str.152
	.asciz	"call.common.acquired_rights"

l_.str.153:                             ; @.str.153
	.asciz	"call.common.parameters"

l_.str.154:                             ; @.str.154
	.asciz	"call.common.owned_inputs"

l_.str.155:                             ; @.str.155
	.asciz	"call.common.borrowed_inputs"

l_.str.156:                             ; @.str.156
	.asciz	"call.common.result_count"

l_.str.157:                             ; @.str.157
	.asciz	"call.common.outcomes[0]"

l_.str.158:                             ; @.str.158
	.asciz	"call.common.outcomes[1]"

l_.str.159:                             ; @.str.159
	.asciz	"call.common.result."

l_.str.160:                             ; @.str.160
	.asciz	"if(!nvm_services_indirect_hosted_input_local(p,%u,%u,%u,%u,&value))return false;\n"

l_.str.161:                             ; @.str.161
	.asciz	"if(!nvm_services_indirect_hosted_input_stack(p,%u,%u,%u,%u,&value))return false;\n"

l_.str.162:                             ; @.str.162
	.asciz	"for(uint16_t n=0;n<NVM_SERVICES_FLOW_REFERENCES;n++){\nif(!nvm_services_indirect_hosted_input_reference(p,%u,%u,%u,n,&reference))return false;\nswitch(n){\n"

l_.str.163:                             ; @.str.163
	.asciz	"case %u:\n"

l_.str.164:                             ; @.str.164
	.asciz	"reference.live"

l_.str.165:                             ; @.str.165
	.asciz	"reference.formal"

l_.str.166:                             ; @.str.166
	.asciz	"reference.local"

l_.str.167:                             ; @.str.167
	.asciz	"reference.owner"

l_.str.168:                             ; @.str.168
	.asciz	"reference.identity"

l_.str.169:                             ; @.str.169
	.asciz	"reference.region"

l_.str.170:                             ; @.str.170
	.asciz	"reference.shared"

l_.str.171:                             ; @.str.171
	.asciz	"break;\n"

l_.str.172:                             ; @.str.172
	.asciz	"default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}\n"

l_.str.173:                             ; @.str.173
	.asciz	"if(!nvm_services_indirect_hosted_input_region(p,%u,%u,%u,%u,&region) || region!=UINT64_C(%llu))return false;\n"

l_.str.174:                             ; @.str.174
	.asciz	"value.type."

l_.str.175:                             ; @.str.175
	.asciz	"value.initialized"

l_.str.176:                             ; @.str.176
	.asciz	"value.owner"

l_.str.177:                             ; @.str.177
	.asciz	"value.arm"

l_.str.178:                             ; @.str.178
	.asciz	"if((uint64_t)(%s)!=UINT64_C(%llu))return false;\n"

l_.str.179:                             ; @.str.179
	.asciz	"%s%s"

l_.str.180:                             ; @.str.180
	.asciz	"tag"

l_.str.181:                             ; @.str.181
	.asciz	"mode"

l_.str.182:                             ; @.str.182
	.asciz	"global_index"

l_.str.183:                             ; @.str.183
	.asciz	"catalog_ordinal"

l_.str.184:                             ; @.str.184
	.asciz	"category"

l_.str.185:                             ; @.str.185
	.asciz	"static NvmServicesRuntimeStatus nf_function_%u(NvmServicesRuntime *c){\nNvmServicesIndirectFrameView current;NvmServicesCyclicVariant variant;NvmServicesRuntimeFrameView f;\nNvmServicesRuntimeView value,values[2];NvmServicesFlowArm arm;\nuint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_SERVICES_RUNTIME_FIELDS];\nuint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;\n(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;\n(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;\n"

l_.str.186:                             ; @.str.186
	.asciz	"if(0)goto nf_label_%u;\n"

l_.str.187:                             ; @.str.187
	.asciz	"goto nf_label_0;\n"

l_.str.188:                             ; @.str.188
	.asciz	"nf_label_%u:\n"

l_.str.189:                             ; @.str.189
	.asciz	"return nf_bad(c);\n"

l_.str.190:                             ; @.str.190
	.asciz	"if(!nvm_services_runtime_indirect_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_SERVICES_RUNTIME_NATIVE || current.frame.function!=%u || current.frame.instruction!=%u || !nvm_services_indirect_hosted_variant(nvm_services_runtime_indirect_plan(c),%u,%u,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);\nf=current.frame;(void)f;NF_TRY(nvm_services_runtime_indirect_enter(c));\n"

l_.str.191:                             ; @.str.191
	.asciz	"if(!nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_services_runtime_string_literal(c,dst));\n"

l_.str.192:                             ; @.str.192
	.asciz	"{uint32_t other=NVM_SERVICES_RUNTIME_NO_SLOT;\nif(f.stack_count<%u || !nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&src))return nf_bad(c);\n"

l_.str.193:                             ; @.str.193
	.asciz	"if(!nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&other))return nf_bad(c);\n"

l_.str.194:                             ; @.str.194
	.asciz	"NF_TRY(nvm_services_runtime_string_operation(c,%u,src,other,src));}\n"

l_.str.195:                             ; @.str.195
	.asciz	"if(!nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_services_runtime_scalar(c,dst,%u,nf_bits(UINT64_C(%llu))));\n"

l_.str.196:                             ; @.str.196
	.asciz	"if(!nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_services_runtime_indirect_funcref(c,dst));\n"

l_.str.197:                             ; @.str.197
	.asciz	"if(!f.stack_count || !nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_services_runtime_copy(c,src,dst));\n"

l_.str.198:                             ; @.str.198
	.asciz	"if(!f.stack_count || !nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_services_runtime_view(c,src,&value))return nf_bad(c);\n"

l_.str.199:                             ; @.str.199
	.asciz	"if(value.owning || value.formal)return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_TYPE);\n"

l_.str.200:                             ; @.str.200
	.asciz	"NF_TRY(nvm_services_runtime_drop(c,src));\n"

l_.str.201:                             ; @.str.201
	.asciz	"if(!nvm_services_runtime_frame_local(c,%u,&src) || !nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_services_runtime_view(c,src,&value))return nf_bad(c);\nif(!value.initialized || value.formal || value.owning!=%u)return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_TYPE);\nNF_TRY(nvm_services_runtime_%s(c,src,dst));\n"

l_.str.202:                             ; @.str.202
	.asciz	"move"

l_.str.203:                             ; @.str.203
	.asciz	"copy"

l_.str.204:                             ; @.str.204
	.asciz	"NF_TRY(nvm_services_runtime_frame_store(c));\n"

l_.str.205:                             ; @.str.205
	.asciz	"NF_TRY(nvm_services_runtime_frame_region_begin(c));\n"

l_.str.206:                             ; @.str.206
	.asciz	"NF_TRY(nvm_services_runtime_frame_region_end(c));\n"

l_.str.207:                             ; @.str.207
	.asciz	"NF_TRY(nvm_services_runtime_frame_borrow(c));\n"

l_.str.208:                             ; @.str.208
	.asciz	"NF_TRY(nvm_services_runtime_frame_end_reference(c));\n"

l_.str.209:                             ; @.str.209
	.asciz	"if(!nvm_services_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_services_runtime_drop(c,src));\n"

l_.str.210:                             ; @.str.210
	.asciz	"if(!nvm_services_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_services_runtime_result_arm(c,src,&arm));\nedge=arm==NVM_SERVICES_FLOW_ARM_ERROR;\n"

l_.str.211:                             ; @.str.211
	.asciz	"if(!nvm_services_runtime_frame_local(c,%u,&src) || !nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_services_runtime_take(c,src,%u,dst));\n"

l_.str.212:                             ; @.str.212
	.asciz	"{uint32_t inputs[2]={0};reference=NVM_SERVICES_RUNTIME_NO_SLOT;\n"

l_.str.213:                             ; @.str.213
	.asciz	"if(f.stack_count<%zu)return nf_bad(c);\n"

l_.str.214:                             ; @.str.214
	.asciz	"if(!nvm_services_runtime_frame_scratch(c,&dst))return nf_bad(c);\n"

l_.str.215:                             ; @.str.215
	.asciz	"if(!nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-%zu),&inputs[%zu]))return nf_bad(c);\n"

l_.str.216:                             ; @.str.216
	.asciz	"if(!nvm_services_runtime_frame_reference(c,%u,&reference))return nf_bad(c);\n"

l_.str.217:                             ; @.str.217
	.asciz	"NF_TRY(nvm_services_runtime_service_args(c,%u,reference,inputs,%zu,dst));\nif(!nvm_services_runtime_frame_reserve(c,(uint16_t)(f.stack_count-%zu),&output))return nf_bad(c);\nNF_TRY(nvm_services_runtime_move(c,dst,output));}\n"

l_.str.218:                             ; @.str.218
	.asciz	"if(!f.stack_count || !nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_services_runtime_view(c,src,&value))return nf_bad(c);\nif(!nf_scalar(&value,TAG_BOOL))return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_TYPE);\nNF_TRY(nvm_services_runtime_drop(c,src));\n"

l_.str.219:                             ; @.str.219
	.asciz	"if(!value.values[0])return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_ASSERT);\n"

l_.str.220:                             ; @.str.220
	.asciz	"edge=(value.values[0]!=0)==%u;\n"

l_.str.221:                             ; @.str.221
	.asciz	"if(f.stack_count<%u)return nf_bad(c);\n"

l_.str.222:                             ; @.str.222
	.asciz	"if(!nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&inputs[%u]))return nf_bad(c);\n"

l_.str.223:                             ; @.str.223
	.asciz	"dst=inputs[0];\n"

l_.str.224:                             ; @.str.224
	.asciz	"if(!nvm_services_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n"

l_.str.225:                             ; @.str.225
	.asciz	"NF_TRY(nvm_services_runtime_construct(c,%u,%u,inputs,%u,dst));\n"

l_.str.226:                             ; @.str.226
	.asciz	"if(!f.stack_count || !nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src))return nf_bad(c);\n"

l_.str.227:                             ; @.str.227
	.asciz	"NF_TRY(nvm_services_runtime_project(c,src,%u,src));\n"

l_.str.228:                             ; @.str.228
	.asciz	"if(!nvm_services_runtime_view(c,src,&value))return nf_bad(c);\nif(value.owning || value.formal || value.type.category!=NVM_SERVICES_CATEGORY_SCALAR_RESULT)return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_TYPE);\nNF_TRY(nvm_services_runtime_result_arm(c,src,&arm));\nNF_TRY(nvm_services_runtime_drop(c,src));\nNF_TRY(nvm_services_runtime_scalar(c,src,TAG_INT,arm==NVM_SERVICES_FLOW_ARM_ERROR));\n"

l_.str.229:                             ; @.str.229
	.asciz	"NF_TRY(nvm_services_runtime_frame_call(c));\nif(!nvm_services_runtime_indirect_frame_view(c,&current))return nf_bad(c);\nswitch(current.frame.function){\n"

l_.str.230:                             ; @.str.230
	.asciz	"case %u:NF_TRY(nf_function_%u(c));break;\n"

l_.str.231:                             ; @.str.231
	.asciz	"default:return nf_bad(c);\n}\ngoto nf_label_%u;\n"

l_.str.232:                             ; @.str.232
	.asciz	"NF_TRY(nvm_services_runtime_frame_call(c));\nNF_TRY(nf_function_%u(c));\ngoto nf_label_%u;\n"

l_.str.233:                             ; @.str.233
	.asciz	"return nvm_services_runtime_frame_return(c);\n"

l_.str.234:                             ; @.str.234
	.asciz	"NF_TRY(nvm_services_runtime_frame_next(c,edge));\nif(edge)goto nf_label_%u;\ngoto nf_label_%u;\n"

l_.str.235:                             ; @.str.235
	.asciz	"NF_TRY(nvm_services_runtime_frame_next(c,0));\ngoto nf_label_%u;\n"

l_.str.236:                             ; @.str.236
	.asciz	"nf_bits((uint64_t)a+(uint64_t)z)"

l_.str.237:                             ; @.str.237
	.asciz	"nf_bits((uint64_t)a-(uint64_t)z)"

l_.str.238:                             ; @.str.238
	.asciz	"nf_bits((uint64_t)a*(uint64_t)z)"

l_.str.239:                             ; @.str.239
	.asciz	"!z?0:a==INT64_MIN&&z==-1?INT64_MIN:a/z"

l_.str.240:                             ; @.str.240
	.asciz	"!z||(a==INT64_MIN&&z==-1)?0:a%z"

l_.str.241:                             ; @.str.241
	.asciz	"nf_bits(UINT64_C(0)-(uint64_t)a)"

l_.str.242:                             ; @.str.242
	.asciz	"a==z"

l_.str.243:                             ; @.str.243
	.asciz	"a!=z"

l_.str.244:                             ; @.str.244
	.asciz	"a<z"

l_.str.245:                             ; @.str.245
	.asciz	"a<=z"

l_.str.246:                             ; @.str.246
	.asciz	"a>z"

l_.str.247:                             ; @.str.247
	.asciz	"a>=z"

l_.str.248:                             ; @.str.248
	.asciz	"a&&z"

l_.str.249:                             ; @.str.249
	.asciz	"a||z"

l_.str.250:                             ; @.str.250
	.asciz	"!a"

l_.str.251:                             ; @.str.251
	.asciz	"if(!nvm_services_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&roots[%u]) || !nvm_services_runtime_view(c,roots[%u],&values[%u]))return nf_bad(c);\n"

l_.str.252:                             ; @.str.252
	.asciz	"tag=%u;\n"

l_.str.253:                             ; @.str.253
	.asciz	"if(values[0].type.tag==TAG_BOOL)tag=TAG_BOOL;\n"

l_.str.254:                             ; @.str.254
	.asciz	"if(!nf_scalar(&values[%u],tag))return nvm_services_runtime_fail(c,NVM_SERVICES_RUNTIME_TYPE);\n"

l_.str.255:                             ; @.str.255
	.asciz	"a=values[0].values[0];z=%s;r=(%s);\n"

l_.str.256:                             ; @.str.256
	.asciz	"0"

l_.str.257:                             ; @.str.257
	.asciz	"values[1].values[0]"

l_.str.258:                             ; @.str.258
	.asciz	"NF_TRY(nvm_services_runtime_drop(c,roots[%u]));\n"

l_.str.259:                             ; @.str.259
	.asciz	"NF_TRY(nvm_services_runtime_scalar(c,roots[0],%u,r));\n"

.subsections_via_symbols
