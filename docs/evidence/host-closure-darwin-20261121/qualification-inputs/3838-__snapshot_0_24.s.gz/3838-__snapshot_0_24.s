	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_service_policy_read         ; -- Begin function nl_service_policy_read
	.p2align	2
_nl_service_policy_read:                ; @nl_service_policy_read
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #4704                       ; =0x1260
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #608
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w20, #0                         ; =0x0
	cbz	x0, LBB0_22
; %bb.1:
	cbz	x1, LBB0_22
; %bb.2:
	cbz	x5, LBB0_22
; %bb.3:
	mov	x23, x2
	mov	x24, x3
	mov	x25, x4
	mov	x19, x5
	add	x22, sp, #3912
	str	xzr, [x22, #776]
	add	x26, sp, #1, lsl #12            ; =4096
	add	x26, x26, #352
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x26, #208]
	stp	q0, q0, [x26, #176]
	stp	q0, q0, [x26, #144]
	stp	q0, q0, [x26, #112]
	stp	q0, q0, [x26, #80]
	stp	q0, q0, [x26, #48]
	stp	q0, q0, [x26, #16]
	str	q0, [x26]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #352
	mov	x21, x0
	mov	x20, x1
	bl	_nvm_v2_module_deserialize
	cbz	w0, LBB0_5
; %bb.4:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #352
	bl	_nvm_v2_module_free
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #352
	mov	x0, x21
	mov	x1, x20
	bl	_nvm_websocket_deserialize
	cbnz	w0, LBB0_21
LBB0_5:
	add	x0, sp, #3912
	mov	w1, #536                        ; =0x218
	bl	_bzero
	add	x0, sp, #68
	mov	w1, #3844                       ; =0xf04
	bl	_bzero
	ldr	w1, [sp, #4672]
	cmp	w1, #128
	b.eq	LBB0_12
; %bb.6:
	cmp	w1, #120
	b.eq	LBB0_10
; %bb.7:
	cmp	w1, #104
	b.ne	LBB0_14
; %bb.8:
	ldr	x0, [x26, #216]
	add	x2, sp, #12
	mov	w1, #104                        ; =0x68
	bl	_nvm_websocket_nominal_decode
	cbnz	w0, LBB0_13
; %bb.9:
	mov	w21, #4                         ; =0x4
	b	LBB0_17
LBB0_10:
	ldr	x0, [x26, #216]
	add	x2, sp, #12
	mov	w1, #120                        ; =0x78
	bl	_nvm_file_nominal_decode
	cbnz	w0, LBB0_13
; %bb.11:
	mov	w21, #1                         ; =0x1
	b	LBB0_17
LBB0_12:
	ldr	x0, [x26, #216]
	add	x2, sp, #12
	mov	w1, #128                        ; =0x80
	bl	_nvm_socket_nominal_decode
	cbz	w0, LBB0_16
LBB0_13:
	mov	w21, #0                         ; =0x0
	b	LBB0_18
LBB0_14:
	ldr	x0, [x26, #216]
	add	x2, sp, #68
	bl	_nvm_multi_nominal_decode
	cbz	w0, LBB0_32
; %bb.15:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #352
	bl	_nvm_v2_module_free
	mov	w20, #0                         ; =0x0
	b	LBB0_22
LBB0_16:
	mov	w21, #2                         ; =0x2
LBB0_17:
	str	w21, [sp, #3912]
LBB0_18:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #352
	bl	_nvm_v2_module_free
	cbz	w21, LBB0_21
; %bb.19:
	mov	w20, #1                         ; =0x1
	str	x20, [x22, #8]
	cmp	w21, #4
	b.ne	LBB0_23
; %bb.20:
	strb	w20, [x22, #531]
	strb	w25, [x22, #528]
	add	x1, sp, #3912
	mov	x0, x19
	mov	w2, #536                        ; =0x218
	bl	_memcpy
	b	LBB0_22
LBB0_21:
	mov	w20, #0                         ; =0x0
LBB0_22:
	mov	x0, x20
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #608
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_23:
	mov	w8, #0                          ; =0x0
	strb	w20, [x22, #528]
LBB0_24:
	mov	w9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	add	x12, sp, #68
	add	x13, x12, #4
	add	x12, sp, #3912
	add	x14, x12, #21
	mov	w12, #1                         ; =0x1
LBB0_25:                                ; =>This Inner Loop Header: Depth=1
	mov	x15, x21
	cbz	w8, LBB0_27
; %bb.26:                               ;   in Loop: Header=BB0_25 Depth=1
	ldr	w15, [x13]
LBB0_27:                                ;   in Loop: Header=BB0_25 Depth=1
	sub	w16, w15, #1
	cmp	w16, #2
	b.hi	LBB0_31
; %bb.28:                               ;   in Loop: Header=BB0_25 Depth=1
	cmp	w15, #2
	csel	w16, w24, w25, eq
	cset	w17, eq
	cmp	w15, #1
	csel	w16, w23, w16, eq
	cset	w1, eq
	stur	w15, [x14, #-5]
	sturb	w16, [x14, #-1]
	strh	wzr, [x14]
	cmp	w15, #3
	cset	w15, eq
	strb	wzr, [x14, #2]
	orr	w11, w11, w15
	orr	w10, w10, w1
	orr	w9, w9, w17
	tst	w12, #0xff
	csel	w12, wzr, w16, eq
	add	x14, x14, #8
	add	x13, x13, #60
	subs	x20, x20, #1
	b.ne	LBB0_25
; %bb.29:
	strb	w11, [x22, #531]
	strb	w10, [x22, #529]
	strb	w9, [x22, #530]
LBB0_30:
	strb	w12, [x22, #528]
	add	x1, sp, #3912
	mov	x0, x19
	mov	w2, #536                        ; =0x218
	bl	_memcpy
	mov	w20, #1                         ; =0x1
	b	LBB0_22
LBB0_31:
	mov	w20, #0                         ; =0x0
	strb	w12, [x22, #528]
	b	LBB0_22
LBB0_32:
	mov	w21, #3                         ; =0x3
	str	w21, [sp, #3912]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #352
	bl	_nvm_v2_module_free
	ldr	w20, [sp, #68]
	str	x20, [x22, #8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x22, #528]
	cbnz	w20, LBB0_24
; %bb.33:
	mov	w12, #1                         ; =0x1
	b	LBB0_30
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_policy_grant        ; -- Begin function nl_service_policy_grant
	.p2align	2
_nl_service_policy_grant:               ; @nl_service_policy_grant
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #1552
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	cbz	x0, LBB1_10
; %bb.1:
	ldr	w8, [x0]
	cmp	w8, #3
	b.ne	LBB1_10
; %bb.2:
	ldr	x19, [x0, #8]
	sub	x8, x19, #65
	cmn	x8, #64
	b.lo	LBB1_10
; %bb.3:
	cbz	x1, LBB1_13
; %bb.4:
	ldr	w8, [x1]
	cmp	w8, #1
	b.ne	LBB1_10
; %bb.5:
	ldr	w8, [x1, #8]
	mov	w9, #60000                      ; =0xea60
	cmp	w8, w9
	b.hi	LBB1_10
; %bb.6:
	ldrb	w9, [x1, #5]
	ldr	x8, [x1, #16]
	cmp	x8, #0
	cset	w10, ne
	cmp	w9, w10
	b.ne	LBB1_10
; %bb.7:
	cbz	x8, LBB1_13
; %bb.8:
	ldrb	w9, [x8]
	cmp	w9, #47
	b.ne	LBB1_10
; %bb.9:
	mov	x20, x0
	mov	x0, x8
	mov	x21, x2
	mov	x22, x1
	bl	_strlen
	mov	x1, x22
	mov	x2, x21
	mov	x8, x0
	mov	x0, x20
	cmp	x8, #4095
	b.ls	LBB1_13
LBB1_10:
	mov	w0, #1                          ; =0x1
LBB1_11:
	ldur	x8, [x29, #-56]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_52
; %bb.12:
	add	sp, sp, #1552
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB1_13:
	mov	x22, x0
	mov	x20, x1
	mov	x21, x2
	add	x23, sp, #8
	add	x0, sp, #8
	mov	w1, #1536                       ; =0x600
	bl	_bzero
	sub	x8, x19, #1
	and	x9, x19, #0x3
	cmp	x8, #3
	b.hs	LBB1_15
; %bb.14:
	mov	x12, #0                         ; =0x0
	mov	x2, x21
	mov	x8, x20
	mov	x10, x22
	b	LBB1_42
LBB1_15:
	mov	x11, #0                         ; =0x0
	add	x12, x23, #88
	and	x8, x19, #0x7c
	neg	x13, x8
	mov	x10, x22
	add	x14, x22, #24
	mov	w15, #1                         ; =0x1
	mov	x2, x21
	mov	x8, x20
	b	LBB1_19
LBB1_16:                                ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #4]
	sturb	w16, [x12, #-8]
LBB1_17:                                ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #5]
	sturb	w16, [x12, #-7]
	ldr	w16, [x8, #8]
	stur	w16, [x12, #-4]
	ldr	x16, [x8, #16]
	str	x16, [x12]
LBB1_18:                                ;   in Loop: Header=BB1_19 Depth=1
	add	x12, x12, #96
	sub	x11, x11, #4
	add	x14, x14, #32
	cmp	x13, x11
	b.eq	LBB1_41
LBB1_19:                                ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x14, #-8]
	ldurb	w16, [x14, #-4]
	stp	w15, w17, [x12, #-88]
	sturb	w16, [x12, #-80]
	stur	xzr, [x12, #-79]
	stur	xzr, [x12, #-72]
	cmp	w17, #3
	b.ne	LBB1_25
; %bb.20:                               ;   in Loop: Header=BB1_19 Depth=1
	cbz	x8, LBB1_23
; %bb.21:                               ;   in Loop: Header=BB1_19 Depth=1
	cbz	w16, LBB1_23
; %bb.22:                               ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #4]
	sturb	w16, [x12, #-80]
	b	LBB1_24
LBB1_23:                                ;   in Loop: Header=BB1_19 Depth=1
	sturb	wzr, [x12, #-80]
	cbz	x8, LBB1_25
LBB1_24:                                ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #5]
	sturb	w16, [x12, #-79]
	ldr	w16, [x8, #8]
	stur	w16, [x12, #-76]
	ldr	x16, [x8, #16]
	stur	x16, [x12, #-72]
LBB1_25:                                ;   in Loop: Header=BB1_19 Depth=1
	ldr	w17, [x14]
	ldrb	w16, [x14, #4]
	stp	w15, w17, [x12, #-64]
	sturb	w16, [x12, #-56]
	stur	xzr, [x12, #-55]
	stur	xzr, [x12, #-48]
	cmp	w17, #3
	b.ne	LBB1_31
; %bb.26:                               ;   in Loop: Header=BB1_19 Depth=1
	cbz	x8, LBB1_29
; %bb.27:                               ;   in Loop: Header=BB1_19 Depth=1
	tbz	w16, #0, LBB1_29
; %bb.28:                               ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #4]
	sturb	w16, [x12, #-56]
	b	LBB1_30
LBB1_29:                                ;   in Loop: Header=BB1_19 Depth=1
	sturb	wzr, [x12, #-56]
	cbz	x8, LBB1_31
LBB1_30:                                ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #5]
	sturb	w16, [x12, #-55]
	ldr	w16, [x8, #8]
	stur	w16, [x12, #-52]
	ldr	x16, [x8, #16]
	stur	x16, [x12, #-48]
LBB1_31:                                ;   in Loop: Header=BB1_19 Depth=1
	ldr	w17, [x14, #8]
	ldrb	w16, [x14, #12]
	stp	w15, w17, [x12, #-40]
	sturb	w16, [x12, #-32]
	stur	xzr, [x12, #-31]
	stur	xzr, [x12, #-24]
	cmp	w17, #3
	b.ne	LBB1_37
; %bb.32:                               ;   in Loop: Header=BB1_19 Depth=1
	cbz	x8, LBB1_35
; %bb.33:                               ;   in Loop: Header=BB1_19 Depth=1
	tbz	w16, #0, LBB1_35
; %bb.34:                               ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #4]
	sturb	w16, [x12, #-32]
	b	LBB1_36
LBB1_35:                                ;   in Loop: Header=BB1_19 Depth=1
	sturb	wzr, [x12, #-32]
	cbz	x8, LBB1_37
LBB1_36:                                ;   in Loop: Header=BB1_19 Depth=1
	ldrb	w16, [x8, #5]
	sturb	w16, [x12, #-31]
	ldr	w16, [x8, #8]
	stur	w16, [x12, #-28]
	ldr	x16, [x8, #16]
	stur	x16, [x12, #-24]
LBB1_37:                                ;   in Loop: Header=BB1_19 Depth=1
	ldr	w17, [x14, #16]
	ldrb	w16, [x14, #20]
	stp	w15, w17, [x12, #-16]
	sturb	w16, [x12, #-8]
	stur	xzr, [x12, #-7]
	str	xzr, [x12]
	cmp	w17, #3
	b.ne	LBB1_18
; %bb.38:                               ;   in Loop: Header=BB1_19 Depth=1
	cbz	x8, LBB1_40
; %bb.39:                               ;   in Loop: Header=BB1_19 Depth=1
	tbnz	w16, #0, LBB1_16
LBB1_40:                                ;   in Loop: Header=BB1_19 Depth=1
	sturb	wzr, [x12, #-8]
	cbnz	x8, LBB1_17
	b	LBB1_18
LBB1_41:
	neg	x12, x11
LBB1_42:
	cbz	x9, LBB1_51
; %bb.43:
	mov	x11, #0                         ; =0x0
	add	x10, x10, x12, lsl #3
	add	x10, x10, #20
	mov	w13, #24                        ; =0x18
	add	x14, sp, #8
	madd	x12, x12, x13, x14
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #3
	mov	w13, #1                         ; =0x1
	b	LBB1_47
LBB1_44:                                ;   in Loop: Header=BB1_47 Depth=1
	ldrb	w15, [x8, #4]
	strb	w15, [x14, #8]
LBB1_45:                                ;   in Loop: Header=BB1_47 Depth=1
	ldrb	w15, [x8, #5]
	strb	w15, [x14, #9]
	ldr	w15, [x8, #8]
	str	w15, [x14, #12]
	ldr	x15, [x8, #16]
	str	x15, [x14, #16]
LBB1_46:                                ;   in Loop: Header=BB1_47 Depth=1
	add	x10, x10, #8
	add	x11, x11, #24
	cmp	x9, x11
	b.eq	LBB1_51
LBB1_47:                                ; =>This Inner Loop Header: Depth=1
	add	x14, x12, x11
	ldur	w16, [x10, #-4]
	ldrb	w15, [x10]
	stp	w13, w16, [x14]
	strb	w15, [x14, #8]
	stur	xzr, [x14, #9]
	str	xzr, [x14, #16]
	cmp	w16, #3
	b.ne	LBB1_46
; %bb.48:                               ;   in Loop: Header=BB1_47 Depth=1
	cbz	x8, LBB1_50
; %bb.49:                               ;   in Loop: Header=BB1_47 Depth=1
	tbnz	w15, #0, LBB1_44
LBB1_50:                                ;   in Loop: Header=BB1_47 Depth=1
	strb	wzr, [x14, #8]
	cbnz	x8, LBB1_45
	b	LBB1_46
LBB1_51:
	add	x0, sp, #8
	mov	x1, x19
	bl	_nvm_services_host_grant_create_config
	b	LBB1_11
LBB1_52:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
